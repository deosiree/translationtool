<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>ComboboxTabWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/widget/combobox_tabwidget.cpp" line="113"/>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/widget/combobox_tabwidget.cpp" line="116"/>
        <source>应用列表</source>
        <translation type="unfinished">App list</translation>
    </message>
</context>
<context>
    <name>DlgPluginErrorInfo</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/widget/dlg_plugin_error_info.cpp" line="40"/>
        <source>插件错误信息</source>
        <translation type="unfinished">Plugin error message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/widget/dlg_plugin_error_info.cpp" line="71"/>
        <source>导航栏名称</source>
        <translation type="unfinished">Navigation bar name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/widget/dlg_plugin_error_info.cpp" line="71"/>
        <source>模块名称</source>
        <translation type="unfinished">Module name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/widget/dlg_plugin_error_info.cpp" line="71"/>
        <source>插件名称</source>
        <translation type="unfinished">Plugin name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/widget/dlg_plugin_error_info.cpp" line="71"/>
        <source>错误原因</source>
        <translation type="unfinished">Error reason</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/widget/dlg_plugin_error_info.cpp" line="71"/>
        <source>文件路径</source>
        <translation type="unfinished">File path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/widget/dlg_plugin_error_info.cpp" line="106"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
</context>
<context>
    <name>GuiIntegrateMainWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="393"/>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="395"/>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="399"/>
        <source>(节点名：</source>
        <translation type="unfinished">(Node:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="399"/>
        <source>集成工具</source>
        <translation type="unfinished">Integrated tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="484"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="99"/>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="132"/>
        <source>暂无权限，程序退出</source>
        <translation type="unfinished">No permission, program exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="100"/>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="118"/>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="133"/>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="295"/>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="484"/>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="657"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="117"/>
        <source>权限发生变化，程序退出</source>
        <translation type="unfinished">Permission changed, program exited</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="279"/>
        <source>确认退出</source>
        <translation type="unfinished">Confirm exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="281"/>
        <source>有未保存的更改，是否保存后退出？</source>
        <translation type="unfinished">Unsaved changes. Save &amp; exit?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="282"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="283"/>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="658"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="284"/>
        <source>放弃</source>
        <translation type="unfinished">Abort</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="292"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="294"/>
        <source>%1保存失败，无法退出</source>
        <translation type="unfinished">%1 save failed, unable to exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="317"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="319"/>
        <source>%1检查时发生错误，是否继续退出？</source>
        <translation type="unfinished">Error occurred during %1 check, whether to continue exiting?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="484"/>
        <source>xml文件错误，请检查</source>
        <translation type="unfinished">XML file error, please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="656"/>
        <source>切换用户，请确认</source>
        <translation type="unfinished">Switch users, please confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="97"/>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="115"/>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="130"/>
        <source>退出</source>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="320"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="321"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="654"/>
        <source>切换用户</source>
        <translation type="unfinished">Switch User</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/gui_integrate_mainwidget.cpp" line="680"/>
        <source> 登录时限：</source>
        <translation type="unfinished">Login time limit:</translation>
    </message>
</context>
<context>
    <name>MainWidgetCenter</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/main_widget_center.cpp" line="203"/>
        <source>未保存的更改</source>
        <translation type="unfinished">Unsaved changes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/main_widget_center.cpp" line="205"/>
        <source>有未保存的更改，是否保存？</source>
        <translation type="unfinished">Whether to save any unsaved changes?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/main_widget_center.cpp" line="206"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/main_widget_center.cpp" line="207"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/main_widget_center.cpp" line="208"/>
        <source>放弃</source>
        <translation type="unfinished">Abort</translation>
    </message>
</context>
<context>
    <name>PluginDisplayArea</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/plugin_display_area.cpp" line="328"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/plugin_display_area.cpp" line="328"/>
        <source>当前插件切换错误</source>
        <translation type="unfinished">Current plug-in switching error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/plugin_display_area.cpp" line="328"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/plugin_display_area.cpp" line="419"/>
        <source>未保存的更改</source>
        <translation type="unfinished">Unsaved changes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/plugin_display_area.cpp" line="421"/>
        <source>当前插件有未保存的更改，是否保存？</source>
        <translation type="unfinished">Plugin has unsaved changes. Save?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/plugin_display_area.cpp" line="422"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/plugin_display_area.cpp" line="423"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/src/plugin_display_area.cpp" line="424"/>
        <source>放弃</source>
        <translation type="unfinished">Abort</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/main.cpp" line="101"/>
        <source>参数解析失败</source>
        <comment>gui_integrate::main</comment>
        <translation type="unfinished">Params parsing failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/main.cpp" line="103"/>
        <source>请检查</source>
        <comment>gui_integrate::main</comment>
        <translation type="unfinished">Please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_integrate/main.cpp" line="104"/>
        <source>确定</source>
        <comment>gui_integrate::main</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
</context>
</TS>
