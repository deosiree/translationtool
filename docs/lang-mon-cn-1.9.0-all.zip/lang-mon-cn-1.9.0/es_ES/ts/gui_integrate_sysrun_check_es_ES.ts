<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>iasp::smg::ProcDialog</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysrun_check/src/proc_dialog.cpp" line="138"/>
        <source>执行详情</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>iasp::smg::SysrunCheck</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysrun_check/src/sysrun_check_widget.cpp" line="53"/>
        <source>应用异常信息：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysrun_check/src/sysrun_check_widget.cpp" line="57"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysrun_check/src/sysrun_check_widget.cpp" line="60"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysrun_check/src/sysrun_check_widget.cpp" line="229"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysrun_check/src/sysrun_check_widget.cpp" line="232"/>
        <source>一键查验</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysrun_check/src/sysrun_check_widget.cpp" line="201"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysrun_check/src/sysrun_check_widget.cpp" line="435"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysrun_check/src/sysrun_check_widget.cpp" line="201"/>
        <source>无异常应用</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysrun_check/src/sysrun_check_widget.cpp" line="225"/>
        <source>进程异常信息：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysrun_check/src/sysrun_check_widget.cpp" line="435"/>
        <source>无异常进程</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
