<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>BaseInfoWidget</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="206"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="210"/>
        <source>导入配置</source>
        <translation type="unfinished">Importar configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="51"/>
        <source>请选择导入的配置文件:</source>
        <translation type="unfinished">Por favor seleccione el archivo de configuración a importar:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="48"/>
        <source>导入配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Importar config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="53"/>
        <source>导出配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exportar config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="58"/>
        <source>设置系统数据标签</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Establecer etiquetas de datos del sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="61"/>
        <source>触发运行库更新数据时标</source>
        <translation type="unfinished">Activar RTDB para actualizar la marca de tiempo de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="63"/>
        <source>清除系统数据标签</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Borrar etiquetas de datos del sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="66"/>
        <source>触发运行库清除数据时标</source>
        <translation type="unfinished">Activar RTDB para borrar la marca de tiempo de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="68"/>
        <source>系统数据跨现场同步</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Sinc entre sitios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="143"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="147"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="158"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="162"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="173"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="177"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="143"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="158"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="173"/>
        <source>触发成功</source>
        <translation type="unfinished">Activado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="147"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="162"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="177"/>
        <source>触发失败</source>
        <translation type="unfinished">Activación fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="227"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="231"/>
        <source>导出配置</source>
        <translation type="unfinished">Exportar configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="56"/>
        <source>导出的配置文件:</source>
        <translation type="unfinished">Archivo de configuración exportado:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="71"/>
        <source>触发运行库同步数据到外现场</source>
        <translation type="unfinished">Disparar RTDB para sincronizar datos al sitio externo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="192"/>
        <source>无法导入配置</source>
        <translation type="unfinished">No se pudo importar la configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="192"/>
        <source>请在无系统下执行导入</source>
        <translation type="unfinished">Por favor, realice la importación sin sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="206"/>
        <source>导入失败</source>
        <translation type="unfinished">Importación falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="210"/>
        <source>%1导入成功，重启生效!</source>
        <translation type="unfinished">%1 importado con éxito, reinicio efectivo!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="227"/>
        <source>导出失败</source>
        <translation type="unfinished">Exportación falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="231"/>
        <source>%1导出成功</source>
        <translation type="unfinished">%1 exportado con éxito</translation>
    </message>
</context>
<context>
    <name>DlgAppDefDetails</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="40"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="41"/>
        <source>定义详情</source>
        <comment>toolName</comment>
        <translation type="unfinished">Detalles de la Definición</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="61"/>
        <source>现场依赖</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Dependencia del Sitio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="62"/>
        <source>现场依赖</source>
        <translation type="unfinished">Dependencia del sitio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="63"/>
        <source>节点依赖</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Dependencia de Nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="64"/>
        <source>节点依赖</source>
        <translation type="unfinished">Dependencia de nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="108"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="108"/>
        <source>获取应用定义表名失败</source>
        <translation type="unfinished">Fallo al obtener nombre de tabla defs app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="142"/>
        <source>选中状态</source>
        <translation type="unfinished">Estado seleccionado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="142"/>
        <source>oid</source>
        <translation type="unfinished">Oid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="142"/>
        <source>全应用名</source>
        <translation type="unfinished">Nombre completo App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="142"/>
        <source>基础应用名</source>
        <translation type="unfinished">Nombre de la aplicación base</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="142"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
</context>
<context>
    <name>DlgDefinitionDetails</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="41"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="42"/>
        <source>应用配置定义详情</source>
        <comment>toolName</comment>
        <translation type="unfinished">Detalles de la Definición de Config de la Aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="55"/>
        <source>名称:</source>
        <translation type="unfinished">Nombre:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="58"/>
        <source>别名:</source>
        <translation type="unfinished">Alias:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="61"/>
        <source>态类型:</source>
        <translation type="unfinished">Tipo de estado:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="74"/>
        <source>所属系统类型:</source>
        <translation type="unfinished">Tipo de sistema:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="77"/>
        <source>启动优先级:</source>
        <translation type="unfinished">Prioridad de inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="109"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="117"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="125"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="133"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="147"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="160"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="109"/>
        <source>获取应用进程表名失败</source>
        <translation type="unfinished">Fallo al obtener nombre tabla procesos app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="117"/>
        <source>获取应用库定义表名失败</source>
        <translation type="unfinished">Fallo al obtener nombre tabla defs BD app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="125"/>
        <source>获取应用模块定义表名失败</source>
        <translation type="unfinished">Fallo al obtener nombre tabla defs módulos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="133"/>
        <source>获取应用进程失败</source>
        <translation type="unfinished">Fallo al obtener procesos de app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="147"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="160"/>
        <source>获取应用库定义表失败</source>
        <translation type="unfinished">Fallo al obtener nombre tabla defs BD app</translation>
    </message>
</context>
<context>
    <name>DlgProgress</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="50"/>
        <source>任务切换</source>
        <comment>toolName</comment>
        <translation type="unfinished">Cambiar Tarea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="58"/>
        <source>失败详情:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Detalles del fallo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="77"/>
        <source>正在处理，请稍后...</source>
        <translation type="unfinished">Procesando, por favor espere</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="92"/>
        <source>正在执行操作，稍后可点击关闭!</source>
        <translation type="unfinished">Ejecutando operación, puede hacer clic para cerrar más tarde.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="95"/>
        <source>退出对话框</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="305"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="327"/>
        <source>显示详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Detalles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="321"/>
        <source>隐藏详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Detalles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="105"/>
        <source>点击强制退出，可关闭当前执行操作框!</source>
        <translation type="unfinished">¡Haga clic para forzar la salida y cerrar el cuadro de acción actual!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="152"/>
        <source>正在执行，请稍后...</source>
        <translation type="unfinished">Ejecutando, por favor espere…</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="358"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="417"/>
        <source>关闭</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="421"/>
        <source>正在执行操作，稍后可点击关闭</source>
        <translation type="unfinished">La operación está en curso. Puede hacer clic para cerrarlo más tarde.</translation>
    </message>
</context>
<context>
    <name>DlgSvcprocOrTdbrunInfo</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_svcproc_or_tdbrun_info.cpp" line="43"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_svcproc_or_tdbrun_info.cpp" line="44"/>
        <source>应用进程定义</source>
        <comment>toolName</comment>
        <translation type="unfinished">Definición del Proceso de la Aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_svcproc_or_tdbrun_info.cpp" line="50"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_svcproc_or_tdbrun_info.cpp" line="51"/>
        <source>应用库定义</source>
        <comment>toolName</comment>
        <translation type="unfinished">Definición de la BD de la Aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_svcproc_or_tdbrun_info.cpp" line="56"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_svcproc_or_tdbrun_info.cpp" line="57"/>
        <source>应用定义</source>
        <comment>toolName</comment>
        <translation type="unfinished">Definición de la Aplicación</translation>
    </message>
</context>
<context>
    <name>DlgSwichSystem</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_swich_system.cpp" line="38"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_swich_system.cpp" line="85"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_swich_system.cpp" line="95"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_swich_system.cpp" line="38"/>
        <source>获取系统类型列表错误</source>
        <translation type="unfinished">Fallo al obtener la lista de tipos del sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_swich_system.cpp" line="53"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_swich_system.cpp" line="54"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_swich_system.cpp" line="85"/>
        <source>新增系统失败</source>
        <translation type="unfinished">Fallo al agregar sistema nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_swich_system.cpp" line="95"/>
        <source>系统名称为空，请重新输入</source>
        <translation type="unfinished">Nombre de sistema vacío, ingrese de nuevo</translation>
    </message>
</context>
<context>
    <name>HandleTableData</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="261"/>
        <source>(*可编辑)</source>
        <translation type="unfinished">(*editable)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="267"/>
        <source>在线时运行</source>
        <translation type="unfinished">Ejecutar en línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="280"/>
        <source>进程类型</source>
        <translation type="unfinished">Tipo de proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="292"/>
        <source>操作</source>
        <translation type="unfinished">Operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="296"/>
        <source>节点IP</source>
        <translation type="unfinished">IP de nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="493"/>
        <source>不选择</source>
        <translation type="unfinished">No seleccionar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="913"/>
        <source>关键进程</source>
        <translation type="unfinished">Procesos clave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="917"/>
        <source>普通进程</source>
        <translation type="unfinished">Procesos normales</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="1070"/>
        <source>查看定义</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Definición</translation>
    </message>
</context>
<context>
    <name>LeftSysDeptTree</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="64"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="80"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="89"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="98"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="64"/>
        <source>获取现场部署失败</source>
        <translation type="unfinished">Fallo al obtener despliegue en sitio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="80"/>
        <source>获取现场表名称失败</source>
        <translation type="unfinished">Fallo al obtener nombre de tabla de sitio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="89"/>
        <source>获取节点表名称失败</source>
        <translation type="unfinished">Fallo al obtener nombre de tabla de nodos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="98"/>
        <source>获取应用部署表名称失败</source>
        <translation type="unfinished">Fallo al obtener nombre de tabla de despliegue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="156"/>
        <source>运行应用</source>
        <translation type="unfinished">Aplicación en ejecución</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="210"/>
        <source>维护应用</source>
        <translation type="unfinished">Aplicación de mantenimiento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="318"/>
        <source>获取系统列表错误</source>
        <translation type="unfinished">Error al obtener lista de sistemas</translation>
    </message>
</context>
<context>
    <name>RightSysdepInfoFrame</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="66"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="69"/>
        <source>新增</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="70"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="73"/>
        <source>批量增</source>
        <translation type="unfinished">Agregar en Lote</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="74"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="77"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="79"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="82"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="84"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="87"/>
        <source>刷新</source>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="172"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="237"/>
        <source>名称:</source>
        <translation type="unfinished">Nombre:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="192"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="254"/>
        <source>描述:</source>
        <translation type="unfinished">Descripción:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="211"/>
        <source>现场类型:</source>
        <translation type="unfinished">Tipo de sitio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="271"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="362"/>
        <source>部署应用:</source>
        <translation type="unfinished">Aplicaciones en implementación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="309"/>
        <source>关联的应用定义:</source>
        <translation type="unfinished">Definiciones de aplicaciones vinculadas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="314"/>
        <source>维护节点:</source>
        <translation type="unfinished">Nodos de mantenimiento:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="319"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="568"/>
        <source>部署节点:</source>
        <translation type="unfinished">Nodos de implementación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="399"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="407"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="469"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="477"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="846"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="871"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="899"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="925"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="958"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1034"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1056"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1079"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1111"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1140"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="399"/>
        <source>获取服务进程部署表名失败</source>
        <translation type="unfinished">Fallo al obtener nombre tabla despliegue serv.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="407"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="477"/>
        <source>获取运行库部署表名失败</source>
        <translation type="unfinished">Fallo al obtener nombre tabla despliegue runtime</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="469"/>
        <source>获取维护库表名失败</source>
        <translation type="unfinished">Fallo al obtener nombre tabla mant.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="529"/>
        <source>运行库值班信息</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Info de Turno de RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="530"/>
        <source>运行库值班信息</source>
        <translation type="unfinished">Info de Turno de RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="555"/>
        <source>核心进程</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Proceso Central</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="556"/>
        <source>核心进程</source>
        <translation type="unfinished">Proceso central</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="656"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="687"/>
        <source>值班节点名称</source>
        <translation type="unfinished">Nodo de turno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="656"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="687"/>
        <source>库名称</source>
        <translation type="unfinished">Nombre de la base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="656"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="687"/>
        <source>库描述</source>
        <translation type="unfinished">Descripción de base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="846"/>
        <source>获取服务进程失败</source>
        <translation type="unfinished">Fallo al obtener procesos de servicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="871"/>
        <source>获取运行库信息失败</source>
        <translation type="unfinished">Fallo al obtener info. de BD runtime</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="899"/>
        <source>获取维护库信息失败</source>
        <translation type="unfinished">Fallo al obtener info. de BD mantenimiento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="925"/>
        <source>获取维护进程信息失败</source>
        <translation type="unfinished">Fallo al obtener info. de procesos mant.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="958"/>
        <source>获取节点:{}的核心进程失败</source>
        <translation type="unfinished">Fallo al obtener procesos core de nodo:{}</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1034"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1111"/>
        <source>应用部署表失败</source>
        <translation type="unfinished">Fallo en tabla de despliegue app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1056"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1140"/>
        <source>节点表失败</source>
        <translation type="unfinished">Fallo en tabla de nodos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1079"/>
        <source>获取应用定义表失败</source>
        <translation type="unfinished">Fallo al obtener tabla de defs app</translation>
    </message>
</context>
<context>
    <name>RightSysdepInfoTable</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="359"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="395"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="431"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="445"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="474"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="488"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="516"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="541"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="574"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="634"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1111"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1207"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1217"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1272"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1294"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1740"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1865"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1891"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1922"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1945"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2358"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2689"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2706"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2840"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2856"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2920"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2932"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3115"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3126"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3612"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="359"/>
        <source>获取应用进程失败</source>
        <translation type="unfinished">Fallo al obtener procesos de app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="395"/>
        <source>获取应用库失败</source>
        <translation type="unfinished">Fallo al obtener BD de app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="431"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="474"/>
        <source>获取应用部署失败</source>
        <translation type="unfinished">Fallo al obtener despliegue de app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="445"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="488"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="516"/>
        <source>获取应用定义失败</source>
        <translation type="unfinished">Fallo al obtener def. de app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="541"/>
        <source>刷新系统类型失败</source>
        <translation type="unfinished">Refrescar el tipo de sistema falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="574"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="634"/>
        <source>验证失败</source>
        <translation type="unfinished">Validación fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="598"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="671"/>
        <source>整数输入</source>
        <translation type="unfinished">Entrada de número entero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="598"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="671"/>
        <source>请输入一个1-10整数:</source>
        <translation type="unfinished">Por favor, ingrese un número entero entre 1 y 10:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="898"/>
        <source>保存修改</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="898"/>
        <source>存在未保存更改，是否保存</source>
        <translation type="unfinished">Cambios sin guardar, ¿guardar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="939"/>
        <source>此操作将停止正在运行的应用或服务，是否删除</source>
        <translation type="unfinished">Esta operación detendrá la aplicación o servicio en ejecución. Desea eliminarlo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1075"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1157"/>
        <source>是否停应用</source>
        <translation type="unfinished">Detener aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1076"/>
        <source>修改值班优先级，需要停止节点应用，是否确认</source>
        <translation type="unfinished">Modif. prioridad, detiene nodo, ¿confirmar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1111"/>
        <source>检查节点应用是否停止失败</source>
        <translation type="unfinished">Verificar si la aplicación del nodo no se detiene</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1272"/>
        <source>%1节点正在运行，不可删除</source>
        <translation type="unfinished">Nodo %1 en ejecución, no eliminable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1294"/>
        <source>%1现场正在运行，不可删除!</source>
        <translation type="unfinished">¡Sitio %1 en ejecución, no eliminable!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="693"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="938"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1312"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1472"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2040"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2898"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3087"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3323"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1313"/>
        <source>删除配置项,会停止正在运行配置项的相关配置，是否确认</source>
        <translation type="unfinished">Eliminar config. detiene ejecución, ¿confirmar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1472"/>
        <source>当前无权限</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1629"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3993"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1629"/>
        <source>删除后不可恢复，是否继续</source>
        <translation type="unfinished">Eliminación irreparable, ¿continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1728"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2169"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2332"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2462"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2528"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2617"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2671"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2816"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3065"/>
        <source>失败</source>
        <translation type="unfinished">Fallo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1728"/>
        <source>无法删除</source>
        <translation type="unfinished">No se puede eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1736"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2079"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2143"/>
        <source>成功</source>
        <translation type="unfinished">Éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1736"/>
        <source>删除成功</source>
        <translation type="unfinished">Eliminado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1740"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Seleccione datos para operar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1865"/>
        <source>获取节点下的节点应用失败</source>
        <translation type="unfinished">No se pudo obtener la aplicación del nodo bajo el nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1891"/>
        <source>获取应用部署下的节点应用失败</source>
        <translation type="unfinished">No se pudo obtener la aplicación del nodo bajo el despliegue de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1922"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2689"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2840"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2920"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3115"/>
        <source>刷新应用部署失败</source>
        <translation type="unfinished">Fallo al actualizar despliegue app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1945"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2856"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2932"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3126"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3612"/>
        <source>刷新节点失败</source>
        <translation type="unfinished">Fallo al actualizar nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="693"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2040"/>
        <source>没有数据被修改</source>
        <translation type="unfinished">No se modificaron datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2079"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2143"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2332"/>
        <source>现场名称重复</source>
        <translation type="unfinished">Nombre de sitio duplicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2358"/>
        <source>刷新现场失败</source>
        <translation type="unfinished">Fallo al actualizar sitio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2169"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2365"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2373"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2496"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2504"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2714"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2963"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2971"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3157"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3165"/>
        <source>保存失败</source>
        <translation type="unfinished">Fallo al guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1158"/>
        <source>修改维护节点，需要停止维护节点应用，是否确认</source>
        <translation type="unfinished">Para modificar y mantener el nodo, es necesario detener la aplicación del nodo de maint. ¿Está seguro?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1207"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1217"/>
        <source>维护应用停止失败</source>
        <translation type="unfinished">No se pudo detener la aplicación de maint.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2280"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2297"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2406"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2420"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2595"/>
        <source>异常输出</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2280"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2297"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2406"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2420"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2595"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2365"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2496"/>
        <source>请检查!</source>
        <translation type="unfinished">¡Por favor, verifique!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2373"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2504"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2971"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3165"/>
        <source>名称不能为空</source>
        <translation type="unfinished">Se requiere nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2462"/>
        <source>名称重复</source>
        <translation type="unfinished">Nombre repetido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2528"/>
        <source>应用描述重复</source>
        <translation type="unfinished">Descripción de la aplicación duplicada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2617"/>
        <source>应用部署所属应用定义重复</source>
        <translation type="unfinished">Definiciones de aplicaciones duplicadas para implementación de aplicaciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2671"/>
        <source>应用部署重复</source>
        <translation type="unfinished">Implementación de aplicaciones duplicada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2706"/>
        <source>添加失败</source>
        <translation type="unfinished">Fallo al agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2714"/>
        <source>应用描述不可为空</source>
        <translation type="unfinished">Descripción de app no vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2816"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3065"/>
        <source>节点应用重复</source>
        <translation type="unfinished">Aplicación del nodo duplicada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2899"/>
        <source>修改模块会停止当前应用,是否确认</source>
        <translation type="unfinished">Modificar módulo detiene app, ¿confirmar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2963"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3157"/>
        <source>请检查</source>
        <translation type="unfinished">Revise</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3088"/>
        <source>此操作会停止当前应用,是否确认</source>
        <translation type="unfinished">Esta acción detiene app, ¿confirmar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3195"/>
        <source>刷新</source>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3197"/>
        <source>启动</source>
        <translation type="unfinished">Inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3199"/>
        <source>停止</source>
        <translation type="unfinished">Detener</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3201"/>
        <source>禁用</source>
        <translation type="unfinished">Deshabilitar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3203"/>
        <source>解除禁用</source>
        <translation type="unfinished">Habilitar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3205"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3921"/>
        <source>实时日志</source>
        <translation type="unfinished">Registro en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3208"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3948"/>
        <source>历史日志</source>
        <translation type="unfinished">Registro histórico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3211"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3964"/>
        <source>崩溃报告</source>
        <translation type="unfinished">Informe de fallo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3214"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3983"/>
        <source>数据交互</source>
        <translation type="unfinished">Interacción de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3236"/>
        <source>恢复</source>
        <translation type="unfinished">Recuperar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3323"/>
        <source>执行失败，应用部署下节点应用为空</source>
        <translation type="unfinished">Fallo ejecución, nodos app vacíos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3993"/>
        <source>%1打开失败</source>
        <translation type="unfinished">%1 no pudo abrirse</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="4181"/>
        <source>失败原因:%1</source>
        <translation type="unfinished">Razón de fallo: %1</translation>
    </message>
</context>
<context>
    <name>RunSwitchThread</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/thread/run_switch_thread.cpp" line="410"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/thread/run_switch_thread.cpp" line="411"/>
        <source>当前无其他可值班节点，是否确定切离线</source>
        <translation type="unfinished">Sin nodos disponibles, ¿cortar offline?</translation>
    </message>
</context>
<context>
    <name>SysDepMainWidget</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="79"/>
        <source>更新</source>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="80"/>
        <source>部署内容存在修改，是否更新</source>
        <translation type="unfinished">El contenido del despliegue ha sido modificado. ¿Debería actualizarse?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="85"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="285"/>
        <source>基础操作</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Operación Básica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="286"/>
        <source>基础操作</source>
        <translation type="unfinished">Operaciones básicas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="298"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="298"/>
        <source>获取现场部署失败</source>
        <translation type="unfinished">Fallo al obtener despliegue en sitio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="378"/>
        <source>现场基本信息</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Info del Sitio Local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="379"/>
        <source>现场基本信息</source>
        <translation type="unfinished">Info del Sitio Local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="380"/>
        <source>系统管理</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Gestión del Sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="381"/>
        <source>系统管理</source>
        <translation type="unfinished">Sysmgr</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="382"/>
        <source>运维管理</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Operaciones del Sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="383"/>
        <source>运维管理</source>
        <translation type="unfinished">Sysops</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="388"/>
        <source>维护库切换</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="389"/>
        <source>维护库切换</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="599"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="599"/>
        <source>%1存在更改，请检查</source>
        <translation type="unfinished">%1 tiene cambios, verifique</translation>
    </message>
</context>
<context>
    <name>SysDepPlugin</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_plugin.cpp" line="115"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_plugin.cpp" line="126"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_plugin.cpp" line="115"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_plugin.cpp" line="126"/>
        <source>%1存在修改项!</source>
        <translation type="unfinished">%1 tiene ítems modificados!</translation>
    </message>
</context>
<context>
    <name>SysRunPlugin</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysrun_pugin.cpp" line="115"/>
        <source>应用部署</source>
        <translation type="unfinished">Despliegue de la aplicación</translation>
    </message>
</context>
<context>
    <name>SysrunSiteNumberInfo</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="66"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="73"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="100"/>
        <source>信息展示:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Información:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="105"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="107"/>
        <source>别名</source>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="109"/>
        <source>现场类型</source>
        <translation type="unfinished">Tipo de sitio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="136"/>
        <source>是否是本现场</source>
        <translation type="unfinished">Sitio local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="138"/>
        <source>所属的系统</source>
        <translation type="unfinished">Sistema.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="141"/>
        <source>应用部署数量</source>
        <translation type="unfinished">Número de despliegues de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="143"/>
        <source>节点数量</source>
        <translation type="unfinished">Conteo de nodos</translation>
    </message>
</context>
</TS>
