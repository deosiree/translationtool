<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CIMEFile</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="39"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="215"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="224"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="231"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="248"/>
        <source>提示</source>
        <translation type="unfinished">Consejo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="39"/>
        <source>当前画面为空</source>
        <translation type="unfinished">La gráfica actual está vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="215"/>
        <source>获取画面文件名失败</source>
        <translation type="unfinished">No se pudo obtener el nombre del archivo de gráfica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="224"/>
        <source>创建CIME文件失败</source>
        <translation type="unfinished">Fallo al crear archivo CIME</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="231"/>
        <source>上传文件管理失败</source>
        <translation type="unfinished">Fallo al subir gestión de archivos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="248"/>
        <source>CIME文件导出成功</source>
        <translation type="unfinished">Exportación de archivo CIME exitosa</translation>
    </message>
</context>
<context>
    <name>ClearHistoryDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_clear_dlg.cpp" line="10"/>
        <source>清除历史G文件</source>
        <comment>toolName</comment>
        <translation type="unfinished">Borrar Historial G Giles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_clear_dlg.cpp" line="19"/>
        <source>清除历史G文件将清除历史版本</source>
        <translation type="unfinished">Limpiar archivos G hist. eliminará versiones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_clear_dlg.cpp" line="30"/>
        <source>不清除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No claro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_clear_dlg.cpp" line="31"/>
        <source>清除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Limpiar</translation>
    </message>
</context>
<context>
    <name>ExportGFileDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_choose_dlg.cpp" line="11"/>
        <source>全选</source>
        <translation type="unfinished">Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_choose_dlg.cpp" line="12"/>
        <source>导出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exportar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_choose_dlg.cpp" line="13"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_choose_dlg.cpp" line="15"/>
        <source>选择要导出的G文件</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar Archivo G para Exportar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_choose_dlg.cpp" line="23"/>
        <source>检索：</source>
        <translation type="unfinished">Buscar:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_choose_dlg.cpp" line="80"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_choose_dlg.cpp" line="80"/>
        <source>请选择要导出的G文件</source>
        <translation type="unfinished">Seleccione archivo G a exportar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_choose_dlg.cpp" line="143"/>
        <source>选中 %1 / %2 项</source>
        <translation type="unfinished">Seleccione los ítems %1 / %2</translation>
    </message>
</context>
<context>
    <name>GFile</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="77"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="135"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="374"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="1096"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="1258"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4798"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4807"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4818"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4832"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4989"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6185"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6194"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6202"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6227"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6247"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6272"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6359"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="77"/>
        <source>获取当前应用接口插件失败</source>
        <translation type="unfinished">Fallo al obtener plugin de app actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="135"/>
        <source>创建%1目录失败</source>
        <translation type="unfinished">Fallo al crear directorio %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="262"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="317"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="333"/>
        <source>此操作将改变目录 %1 下的G文件</source>
        <translation type="unfinished">Esta acción cambiará archivos G en dir. %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="344"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="432"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="456"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="487"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="498"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6167"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="374"/>
        <source>导出%1失败</source>
        <translation type="unfinished">Fallo al exportar %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="426"/>
        <source>%1.%2 失败原因:%3</source>
        <translation type="unfinished">%1.%2 fallo, razón: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="402"/>
        <source>图片</source>
        <translation type="unfinished">Imagen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="409"/>
        <source>图元</source>
        <translation type="unfinished">Iconos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="432"/>
        <source>使用的图片异常，是否继续</source>
        <translation type="unfinished">Imagen en uso anormal, ¿continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="456"/>
        <source>使用的图元导出失败，是否继续</source>
        <translation type="unfinished">No se pudo exportar los iconos utilizados. Si desea continuar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="562"/>
        <source>导出成功的画面：</source>
        <translation type="unfinished">Exportación de gráfica exitosa:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="574"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="594"/>
        <source>无</source>
        <translation type="unfinished">Ninguno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="578"/>
        <source>导出失败的画面：</source>
        <translation type="unfinished">Exportación de gráfica fallida:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="587"/>
        <source>%1. %2 失败原因：%3</source>
        <translation type="unfinished">%1. %2 fallo, razón: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="601"/>
        <source>导出%1个G文件到目录 %2</source>
        <translation type="unfinished">Exportar archivos G %1 a directorio %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="605"/>
        <source>导出%1个G文件到目录 %2, 失败%3个</source>
        <translation type="unfinished">Archivos G exportados %1 a directorio %2, fallaron %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="1404"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="2562"/>
        <source>%1 (大小: %2 字节)</source>
        <translation type="unfinished">%1 (tamaño: %2 bytes)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4807"/>
        <source>上传PROJ失败，%1</source>
        <translation type="unfinished">Fallo al subir PROJ, %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="1096"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="1258"/>
        <source>获取应用接口插件失败</source>
        <translation type="unfinished">Fallo al obtener plugin de interfaz</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="203"/>
        <source>标识错误:标识(-1)</source>
        <translation type="unfinished">Error de identificación: Identificación (-1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="210"/>
        <source>标识重复:标识(%1)</source>
        <translation type="unfinished">Identificador duplicado: identificador (%1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="487"/>
        <source>以下画面数据异常(详情请对该画面执行正确性检查)，是否继续</source>
        <translation type="unfinished">Los siguientes datos del gráfico son anormales (por favor realice una verificación de corrección en la pantalla para más detalles).``` Desea continuar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="498"/>
        <source>以下图片资源缺失，是否继续</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="508"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6346"/>
        <source>正在上传文件...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="514"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6371"/>
        <source>导出完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="556"/>
        <source>导出总结</source>
        <comment>toolName</comment>
        <translation type="unfinished">Resumen de Exportación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="612"/>
        <source>关闭</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="996"/>
        <source>正在复制图片 %1...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="1197"/>
        <source>正在生成图元 %1...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="1306"/>
        <source>正在解析画面 %1...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="1380"/>
        <source>正在生成G文件 %1...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4798"/>
        <source>压缩graph文件夹失败</source>
        <translation type="unfinished">Fallo al comprimir carpeta graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4863"/>
        <source>G文件上传文件服务失败的节点：</source>
        <translation type="unfinished">Nodos con fallo al subir G a servicio de archivos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4948"/>
        <source>继续</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Continuar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4949"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4989"/>
        <source>删除本地graph文件夹失败</source>
        <translation type="unfinished">Fallo al eliminar carpeta graph local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5042"/>
        <source>应用接口返回为空</source>
        <translation type="unfinished">Interfaz de app retorna vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5044"/>
        <source>写xml文件失败</source>
        <translation type="unfinished">Fallo al escribir archivo XML</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5046"/>
        <source>拷贝文件失败</source>
        <translation type="unfinished">Copia de archivo fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5048"/>
        <source>mmi库OID错误</source>
        <translation type="unfinished">Error OID en biblioteca mmi</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5050"/>
        <source>mmi库图元类型错误</source>
        <translation type="unfinished">Error de tipo de elemento en biblioteca mmi</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5052"/>
        <source>解析文件失败</source>
        <translation type="unfinished">Fallo al analizar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5054"/>
        <source>mmi库图版本为0</source>
        <translation type="unfinished">Versión de biblioteca mmi es 0</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5056"/>
        <source>文件大小超过</source>
        <translation type="unfinished">Tamaño de archivo excede</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5056"/>
        <source>字节</source>
        <translation type="unfinished">Bytes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5058"/>
        <source>未知</source>
        <translation type="unfinished">Desconocido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6087"/>
        <source>正在转换画面 %1...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6185"/>
        <source>删除graph目录失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6194"/>
        <source>创建graph目录失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6202"/>
        <source>创建image目录失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6215"/>
        <source>正在准备2016规范导出...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6227"/>
        <source>加载图元映射配置失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6235"/>
        <source>正在收集图元定义...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6247"/>
        <source>收集图元定义失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6255"/>
        <source>正在准备图元定义...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6272"/>
        <source>画面转换失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6280"/>
        <source>正在写入2016模板文件...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6331"/>
        <source>正在复制图片资源...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6359"/>
        <source>G文件上传文件服务失败（2016规范）</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6412"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6472"/>
        <source>此操作将覆盖目录 %1 下的G文件（2016规范），是否继续？</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GFileProgressDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_progress_dialog.cpp" line="11"/>
        <source>G文件导出</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_progress_dialog.cpp" line="22"/>
        <source>正在准备导出...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
