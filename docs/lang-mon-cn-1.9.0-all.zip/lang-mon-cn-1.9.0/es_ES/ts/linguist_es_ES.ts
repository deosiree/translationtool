<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>AboutDialog</name>
    <message>
        <source>Qt Linguist</source>
        <translation>Qt Lingüista</translation>
    </message>
</context>
<context>
    <name>BatchTranslationDialog</name>
    <message>
        <source>Qt Linguist - Batch Translation</source>
        <translation>Qt Lingüista - Traducción por lotes</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <source>Set translated entries to finished</source>
        <translation>Establecer entradas traducidas como terminadas</translation>
    </message>
    <message>
        <source>Retranslate entries with existing translation</source>
        <translation>Retraducir entradas con traducción existente</translation>
    </message>
    <message>
        <source>Note that the modified entries will be reset to unfinished if &apos;Set translated entries to finished&apos; above is unchecked</source>
        <translation>Tenga en cuenta que las entradas modificadas se restablecerán a no terminadas si &apos;Establecer entradas traducidas como terminadas&apos; arriba no está marcado</translation>
    </message>
    <message>
        <source>Translate also finished entries</source>
        <translation>Traducir también entradas terminadas</translation>
    </message>
    <message>
        <source>Phrase book preference</source>
        <translation>Preferencia del libro de frases</translation>
    </message>
    <message>
        <source>Move up</source>
        <translation>Mover arriba</translation>
    </message>
    <message>
        <source>Move down</source>
        <translation>Mover hacia Abajo</translation>
    </message>
    <message>
        <source>The batch translator will search through the selected phrase books in the order given above</source>
        <translation>El traductor por lotes buscará en los libros de frases seleccionados en el orden dado arriba</translation>
    </message>
    <message>
        <source>&amp;Run</source>
        <translation>&amp;Ejecutar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Batch Translation of &apos;%1&apos; - Qt Linguist</source>
        <translation>Traducción por lotes de &apos;%1&apos; - Qt Lingüista</translation>
    </message>
    <message>
        <source>Searching, please wait...</source>
        <translation>Buscando, por favor espere...</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>Linguist batch translator</source>
        <translation>Traductor por lotes de Lingüista</translation>
    </message>
    <message numerus="yes">
        <source>Batch translated %n entries</source>
        <translation>
            <numerusform>%n bejegyzés kötegelten lefordítva</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>DataModel</name>
    <message>
        <source>The translation file &apos;%1&apos; will not be loaded because it is empty.</source>
        <translation>El archivo de traducción &apos;%1&apos; no se cargará porque está vacío.</translation>
    </message>
    <message>
        <source>&lt;qt&gt;Duplicate messages found in &apos;%1&apos;:</source>
        <translation>&lt;qt&gt;Mensajes duplicados encontrados en &apos;%1&apos;:</translation>
    </message>
    <message>
        <source>&lt;p&gt;[more duplicates omitted]</source>
        <translation>&lt;p&gt; [se omitieron más duplicados]</translation>
    </message>
    <message>
        <source>&lt;p&gt;* ID: %1</source>
        <translation>&lt;p&gt;* ID: %1</translation>
    </message>
    <message>
        <source>&lt;p&gt;* Context: %1&lt;br&gt;* Source: %2</source>
        <translation>&lt;p&gt;* Contexto: %1&lt;br&gt;* Fuente: %2</translation>
    </message>
    <message>
        <source>&lt;br&gt;* Comment: %3</source>
        <translation>&lt;br&gt;* Comentario: %3</translation>
    </message>
    <message>
        <source>Linguist does not know the plural rules for &apos;%1&apos;.
Will assume a single universal form.</source>
        <translation>Lingüista no conoce las reglas de plural para &apos;%1&apos;.
Se asumirá una única forma universal.</translation>
    </message>
    <message>
        <source>Cannot create &apos;%2&apos;: %1</source>
        <translation>No se puede crear &apos;%2&apos;: %1</translation>
    </message>
    <message>
        <source>%1 (%2)</source>
        <extracomment>&lt;language&gt; (&lt;territory&gt;)</extracomment>
        <translation>%1 (%2)</translation>
    </message>
    <message>
        <source>Universal Form</source>
        <translation>Forma universal</translation>
    </message>
</context>
<context>
    <name>ErrorsView</name>
    <message>
        <source>Accelerator possibly superfluous in translation.</source>
        <translation>Acelerador posiblemente superfluo en la traducción.</translation>
    </message>
    <message>
        <source>Accelerator possibly missing in translation.</source>
        <translation>Acelerador posiblemente faltante en la traducción.</translation>
    </message>
    <message>
        <source>Translation does not have same leading and trailing whitespace as the source text.</source>
        <translation>La traducción no tiene el mismo espacio en blanco inicial y final que el texto fuente.</translation>
    </message>
    <message>
        <source>Translation does not end with the same punctuation as the source text.</source>
        <translation>La traducción no termina con la misma puntuación que el texto fuente.</translation>
    </message>
    <message>
        <source>A phrase book suggestion for &apos;%1&apos; was ignored.</source>
        <translation>Se ignoró una sugerencia de libro de frases para &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>Translation does not refer to the same place markers as in the source text.</source>
        <translation>La traducción no se refiere a los mismos marcadores de lugar que el texto fuente.</translation>
    </message>
    <message>
        <source>Translation does not contain the necessary %n/%Ln place marker.</source>
        <translation>La traducción no contiene el marcador de lugar necesario %n/%Ln.</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
</context>
<context>
    <name>FindDialog</name>
    <message>
        <source>Find</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>This window allows you to search for some text in the translation source file.</source>
        <translation>Esta ventana le permite buscar texto en el archivo fuente de traducción.</translation>
    </message>
    <message>
        <source>&amp;Find what:</source>
        <translation>&amp;Buscar qué:</translation>
    </message>
    <message>
        <source>Type in the text to search for.</source>
        <translation>Escriba el texto a buscar.</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <source>Source texts are searched when checked.</source>
        <translation>Los textos de origen se buscan cuando están marcados.</translation>
    </message>
    <message>
        <source>&amp;Source texts</source>
        <translation>&amp;Textos de &amp;origen</translation>
    </message>
    <message>
        <source>Translations are searched when checked.</source>
        <translation>Las traducciones se buscan cuando están marcadas.</translation>
    </message>
    <message>
        <source>&amp;Translations</source>
        <translation>&amp;Traducciones</translation>
    </message>
    <message>
        <source>Texts such as &apos;TeX&apos; and &apos;tex&apos; are considered as different when checked.</source>
        <translation>Textos como &apos;TeX&apos; y &apos;tex&apos; se consideran diferentes al verificarlos.</translation>
    </message>
    <message>
        <source>&amp;Match case</source>
        <translation>&amp;Coincidir mayúsculas y minúsculas</translation>
    </message>
    <message>
        <source>Comments and contexts are searched when checked.</source>
        <translation>Los comentarios y contextos se buscan cuando están marcados.</translation>
    </message>
    <message>
        <source>&amp;Comments</source>
        <translation>&amp;Comentarios</translation>
    </message>
    <message>
        <source>Ignore &amp;accelerators</source>
        <translation>Ignorar &amp;aceleradores</translation>
    </message>
    <message>
        <source>Obsoleted messages are skipped when checked.</source>
        <translation>Los mensajes obsoletos se omiten cuando está marcado.</translation>
    </message>
    <message>
        <source>Skip &amp;obsolete</source>
        <translation>Saltar &amp;obsoleto</translation>
    </message>
    <message>
        <source>Click here to find the next occurrence of the text you typed in.</source>
        <translation>Haga clic aquí para encontrar la siguiente ocurrencia del texto que escribió.</translation>
    </message>
    <message>
        <source>Find Next</source>
        <translation>Buscar siguiente</translation>
    </message>
    <message>
        <source>Click here to close this window.</source>
        <translation>Haga clic aquí para cerrar esta ventana.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source></source>
        <comment>Choose Edit|Find from the menu bar or press Ctrl+F to pop up the Find dialog</comment>
        <translation></translation>
    </message>
    <message>
        <source>Lets you use a Perl-compatible regular expression</source>
        <translation>Le permite usar una expresión regular compatible con Perl</translation>
    </message>
    <message>
        <source>Regular &amp;expression</source>
        <translation>Expresión &amp;regular</translation>
    </message>
    <message>
        <source>T&amp;ranslation status:</source>
        <translation>Estado de la t&amp;raducción:</translation>
    </message>
    <message>
        <source>Lets you filter the search target by translation status</source>
        <translation>Le permite filtrar el objetivo de búsqueda por estado de traducción</translation>
    </message>
    <message>
        <source>All</source>
        <translation>Todo</translation>
    </message>
    <message>
        <source>Finished</source>
        <translation>Terminado</translation>
    </message>
    <message>
        <source>Unfinished</source>
        <translation>Incompleto</translation>
    </message>
</context>
<context>
    <name>FormMultiWidget</name>
    <message>
        <source>Alt+Delete</source>
        <extracomment>translate, but don&apos;t change</extracomment>
        <translation>Alt+Eliminar</translation>
    </message>
    <message>
        <source>Shift+Alt+Insert</source>
        <extracomment>translate, but don&apos;t change</extracomment>
        <translation>Shift+Alt+Insertar</translation>
    </message>
    <message>
        <source>Alt+Insert</source>
        <extracomment>translate, but don&apos;t change</extracomment>
        <translation>Alt+Insertar</translation>
    </message>
    <message>
        <source>Confirmation - Qt Linguist</source>
        <translation>Confirmación - Qt Lingüista</translation>
    </message>
    <message>
        <source>Delete non-empty length variant?</source>
        <translation>¿Eliminar variante de longitud no vacía?</translation>
    </message>
</context>
<context>
    <name>LRelease</name>
    <message numerus="yes">
        <source>Dropped %n message(s) which had no ID.</source>
        <translation type="vanished">
            <numerusform>%n üzenet eldobva, amelynek nem volt azonosítója.</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>Excess context/disambiguation dropped from %n message(s).</source>
        <translation type="vanished">
            <numerusform>Többlet környezet vagy egyértelműség eldobva %n üzenetből.</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>    Generated %n translation(s) (%1 finished and %2 unfinished)</source>
        <translation type="vanished">
            <numerusform>%n fordítás előállítva (%1 befejezett és %2 befejezetlen)</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>    Ignored %n untranslated source text(s)</source>
        <translation type="vanished">
            <numerusform>%n lefordítatlan forrásszöveg figyelmen kívül hagyva</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>Linguist</name>
    <message>
        <source>GNU Gettext localization files</source>
        <translation type="vanished">Archivos de localización de GNU Gettext</translation>
    </message>
    <message>
        <source>GNU Gettext localization template files</source>
        <translation type="vanished">Archivos de plantilla de localización de GNU Gettext</translation>
    </message>
    <message>
        <source>Compiled Qt translations</source>
        <translation type="vanished">Traducciones compiladas de Qt</translation>
    </message>
    <message>
        <source>Qt Linguist &apos;Phrase Book&apos;</source>
        <translation type="vanished">&apos;Libro de frases&apos; de Qt Lingüista</translation>
    </message>
    <message>
        <source>Qt translation sources</source>
        <translation type="vanished">Fuentes de traducción de Qt</translation>
    </message>
    <message>
        <source>XLIFF localization files</source>
        <translation type="vanished">Archivos de localización XLIFF</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>MainWindow</source>
        <translation>VentanaPrincipal</translation>
    </message>
    <message>
        <source>&amp;Phrases</source>
        <translation>&amp;Frases</translation>
    </message>
    <message>
        <source>&amp;Close Phrase Book</source>
        <translation>&amp;Cerrar libro de frases</translation>
    </message>
    <message>
        <source>&amp;Edit Phrase Book</source>
        <translation>&amp;Editar libro de frases</translation>
    </message>
    <message>
        <source>&amp;Print Phrase Book</source>
        <translation>&amp;Imprimir Libro de Frases</translation>
    </message>
    <message>
        <source>V&amp;alidation</source>
        <translation>V&amp;alidación</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Ver</translation>
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation>Vi&amp;stas</translation>
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation>&amp;Barras de herramientas</translation>
    </message>
    <message>
        <source>&amp;Zoom</source>
        <translation>&amp;Zoom</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ayuda</translation>
    </message>
    <message>
        <source>&amp;Translation</source>
        <translation>&amp;Traducción</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Archivo</translation>
    </message>
    <message>
        <source>Recently Opened &amp;Files</source>
        <translation>&amp;Archivos Abiertos Recientemente</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation>&amp;Abrir...</translation>
    </message>
    <message>
        <source>Open a Qt translation source file (TS file) for editing</source>
        <translation>Abrir un archivo fuente de traducción de Qt (archivo TS) para editar</translation>
    </message>
    <message>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>Sa&amp;lir</translation>
    </message>
    <message>
        <source>Close this window and exit.</source>
        <translation>Cerrar esta ventana y salir.</translation>
    </message>
    <message>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>Save changes made to this Qt translation source file</source>
        <translation>Guardar los cambios realizados en este archivo fuente de traducción de Qt</translation>
    </message>
    <message>
        <source>Save &amp;As...</source>
        <translation>Guardar &amp;Como...</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation>Guardar como...</translation>
    </message>
    <message>
        <source>Save changes made to this Qt translation source file into a new file.</source>
        <translation>Guardar los cambios realizados en este archivo fuente de traducción de Qt en un nuevo archivo.</translation>
    </message>
    <message>
        <source>Release</source>
        <translation>Liberar</translation>
    </message>
    <message>
        <source>Create a Qt message file suitable for released applications from the current message file.</source>
        <translation>Crear un archivo de mensajes de Qt adecuado para aplicaciones liberadas a partir del archivo de mensajes actual.</translation>
    </message>
    <message>
        <source>&amp;Print...</source>
        <translation>&amp;Imprimir...</translation>
    </message>
    <message>
        <source>Print a list of all the translation units in the current translation source file.</source>
        <translation>Imprimir una lista de todas las unidades de traducción en el archivo fuente de traducción actual.</translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Deshacer</translation>
    </message>
    <message>
        <source>Undo the last editing operation performed on the current translation.</source>
        <translation>Deshacer la última operación de edición realizada en la traducción actual.</translation>
    </message>
    <message>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Rehacer</translation>
    </message>
    <message>
        <source>Redo an undone editing operation performed on the translation.</source>
        <translation>Rehacer una operación de edición deshecha realizada en la traducción.</translation>
    </message>
    <message>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>Cor&amp;tar</translation>
    </message>
    <message>
        <source>Copy the selected translation text to the clipboard and deletes it.</source>
        <translation>Copiar el texto de traducción seleccionado al portapapeles y eliminarlo.</translation>
    </message>
    <message>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <source>Copy the selected translation text to the clipboard.</source>
        <translation>Copiar el texto de traducción seleccionado al portapapeles.</translation>
    </message>
    <message>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Pegar</translation>
    </message>
    <message>
        <source>Paste the clipboard text into the translation.</source>
        <translation>Pegar el texto del portapapeles en la traducción.</translation>
    </message>
    <message>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <source>Select &amp;All</source>
        <translation>Seleccionar &amp;Todo</translation>
    </message>
    <message>
        <source>Select the whole translation text.</source>
        <translation>Seleccionar todo el texto de la traducción.</translation>
    </message>
    <message>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <source>&amp;Find...</source>
        <translation>&amp;Buscar...</translation>
    </message>
    <message>
        <source>Search for some text in the translation source file.</source>
        <translation>Buscar algún texto en el archivo fuente de traducción.</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <source>Find &amp;Next</source>
        <translation>Buscar &amp;Siguiente</translation>
    </message>
    <message>
        <source>Continue the search where it was left.</source>
        <translation>Continuar la búsqueda donde se dejó.</translation>
    </message>
    <message>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <source>&amp;Prev Unfinished</source>
        <translation>&amp;Anterior Sin Terminar</translation>
    </message>
    <message>
        <source>Previous unfinished item</source>
        <translation>Elemento anterior sin terminar</translation>
    </message>
    <message>
        <source>Move to the previous unfinished item.</source>
        <translation>Mover al elemento anterior sin terminar.</translation>
    </message>
    <message>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <source>&amp;Next Unfinished</source>
        <translation>&amp;Próximo sin terminar</translation>
    </message>
    <message>
        <source>Next unfinished item</source>
        <translation>Siguiente elemento sin terminar</translation>
    </message>
    <message>
        <source>Move to the next unfinished item.</source>
        <translation>Mover al siguiente elemento sin terminar.</translation>
    </message>
    <message>
        <source>Ctrl+J</source>
        <translation>Ctrl+J</translation>
    </message>
    <message>
        <source>P&amp;rev</source>
        <translation>&amp;Ant</translation>
    </message>
    <message>
        <source>Move to previous item</source>
        <translation>Mover al elemento anterior</translation>
    </message>
    <message>
        <source>Move to the previous item.</source>
        <translation>Mover al elemento anterior.</translation>
    </message>
    <message>
        <source>Ctrl+Shift+K</source>
        <translation>Ctrl+Shift+K</translation>
    </message>
    <message>
        <source>Ne&amp;xt</source>
        <translation>Si&amp;guiente</translation>
    </message>
    <message>
        <source>Next item</source>
        <translation>Siguiente elemento</translation>
    </message>
    <message>
        <source>Move to the next item.</source>
        <translation>Mover al siguiente elemento.</translation>
    </message>
    <message>
        <source>Ctrl+Shift+J</source>
        <translation>Ctrl+Shift+J</translation>
    </message>
    <message>
        <source>&amp;Done and Next</source>
        <translation>&amp;Hecho y Siguiente</translation>
    </message>
    <message>
        <source>Mark item as done and move to the next unfinished item</source>
        <translation>Marcar el elemento como hecho y pasar al siguiente elemento sin terminar</translation>
    </message>
    <message>
        <source>Mark this item as done and move to the next unfinished item.</source>
        <translation>Marcar este elemento como hecho y mover al siguiente elemento sin terminar.</translation>
    </message>
    <message>
        <source>Copy from source text</source>
        <translation>Copiar del texto fuente</translation>
    </message>
    <message>
        <source>Copies the source text into the translation field</source>
        <translation>Copia el texto fuente en el campo de traducción</translation>
    </message>
    <message>
        <source>Copies the source text into the translation field.</source>
        <translation>Copia el texto fuente en el campo de traducción.</translation>
    </message>
    <message>
        <source>Ctrl+B</source>
        <translation>Ctrl+B</translation>
    </message>
    <message>
        <source>&amp;Accelerators</source>
        <translation>&amp;Aceleradores</translation>
    </message>
    <message>
        <source>Toggle the validity check of accelerators</source>
        <translation type="vanished">Alterna la verificación de validez de los aceleradores</translation>
    </message>
    <message>
        <source>Toggle the validity check of accelerators, i.e. whether the number of ampersands in the source and translation text is the same. If the check fails, a message is shown in the warnings window.</source>
        <translation type="vanished">Alterna la verificación de validez de los aceleradores, es decir, si el número de ampersands en el texto fuente y de traducción es el mismo. Si la verificación falla, se muestra un mensaje en la ventana de advertencias.</translation>
    </message>
    <message>
        <source>&amp;Ending Punctuation</source>
        <translation>&amp;Puntuación final</translation>
    </message>
    <message>
        <source>Toggle the validity check of ending punctuation</source>
        <translation type="vanished">Alternar la verificación de validez de la puntuación final</translation>
    </message>
    <message>
        <source>Toggle the validity check of ending punctuation. If the check fails, a message is shown in the warnings window.</source>
        <translation type="vanished">Alterna la verificación de validez de la puntuación final. Si la verificación falla, se muestra un mensaje en la ventana de advertencias.</translation>
    </message>
    <message>
        <source>&amp;Phrase matches</source>
        <translation>&amp;Coincidencias de Frases</translation>
    </message>
    <message>
        <source>Toggle checking that phrase suggestions are used</source>
        <translation type="vanished">Alternar la verificación de que se usen las sugerencias de frases</translation>
    </message>
    <message>
        <source>Toggle checking that phrase suggestions are used. If the check fails, a message is shown in the warnings window.</source>
        <translation type="vanished">Alternar la verificación de que se usen las sugerencias de frases. Si la verificación falla, se muestra un mensaje en la ventana de advertencias.</translation>
    </message>
    <message>
        <source>Place &amp;Marker Matches</source>
        <translation>Coincidencias de &amp;Marcadores de posición</translation>
    </message>
    <message>
        <source>Toggle the validity check of place markers</source>
        <translation type="vanished">Alternar la verificación de validez de los marcadores de lugar</translation>
    </message>
    <message>
        <source>Toggle the validity check of place markers, i.e. whether %1, %2, ... are used consistently in the source text and translation text. If the check fails, a message is shown in the warnings window.</source>
        <translation type="vanished">Alterna la verificación de validez de los marcadores de posición, es decir, si %1, %2, ... se utilizan de manera consistente en el texto fuente y el texto de traducción. Si la verificación falla, se muestra un mensaje en la ventana de advertencias.</translation>
    </message>
    <message>
        <source>&amp;New Phrase Book...</source>
        <translation>&amp;Nuevo libro de frases...</translation>
    </message>
    <message>
        <source>Create a new phrase book.</source>
        <translation>Crear un nuevo libro de frases.</translation>
    </message>
    <message>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <source>&amp;Open Phrase Book...</source>
        <translation>&amp;Abrir Libro de Frases...</translation>
    </message>
    <message>
        <source>Open a phrase book to assist translation.</source>
        <translation>Abrir un libro de frases para asistir en la traducción.</translation>
    </message>
    <message>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <source>&amp;Reset Sorting</source>
        <translation>&amp;Restablecer orden</translation>
    </message>
    <message>
        <source>Sort the items back in the same order as in the message file.</source>
        <translation>Ordenar los elementos de nuevo en el mismo orden que en el archivo de mensajes.</translation>
    </message>
    <message>
        <source>&amp;Display guesses</source>
        <translation>&amp;Mostrar conjeturas</translation>
    </message>
    <message>
        <source>Set whether or not to display translation guesses.</source>
        <translation>Establecer si se deben mostrar o no las conjeturas de traducción.</translation>
    </message>
    <message>
        <source>&amp;Statistics</source>
        <translation>&amp;Estadísticas</translation>
    </message>
    <message>
        <source>Display translation statistics.</source>
        <translation>Mostrar estadísticas de traducción.</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation>&amp;Manual</translation>
    </message>
    <message>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <source>About Qt Linguist</source>
        <translation>Acerca de Qt Lingüista</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Acerca de Qt</translation>
    </message>
    <message>
        <source>Display information about the Qt toolkit by Digia.</source>
        <translation>Mostrar información sobre el kit de herramientas Qt por Digia.</translation>
    </message>
    <message>
        <source>&amp;What&apos;s This?</source>
        <translation>&amp;¿Qué es esto?</translation>
    </message>
    <message>
        <source>What&apos;s This?</source>
        <translation>¿Qué es esto?</translation>
    </message>
    <message>
        <source>Enter What&apos;s This? mode.</source>
        <translation>Entrar en modo ¿Qué es esto?</translation>
    </message>
    <message>
        <source>Shift+F1</source>
        <translation>Shift+F1</translation>
    </message>
    <message>
        <source>&amp;Search And Translate...</source>
        <translation>&amp;Buscar y Traducir...</translation>
    </message>
    <message>
        <source>Replace the translation on all entries that matches the search source text.</source>
        <translation>Reemplazar la traducción en todas las entradas que coincidan con el texto de búsqueda de origen.</translation>
    </message>
    <message>
        <source>&amp;Batch Translation...</source>
        <translation>&amp;Traducción por Lotes...</translation>
    </message>
    <message>
        <source>Batch translate all entries using the information in the phrase books.</source>
        <translation>Traducir en lote todas las entradas usando la información en los libros de frases.</translation>
    </message>
    <message>
        <source>Release As...</source>
        <translation>Liberar como...</translation>
    </message>
    <message>
        <source>Create a Qt message file suitable for released applications from the current message file. The filename will automatically be determined from the name of the TS file.</source>
        <translation>Crear un archivo de mensajes de Qt adecuado para aplicaciones liberadas a partir del archivo de mensajes actual. El nombre del archivo se determinará automáticamente a partir del nombre del archivo TS.</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Traducción</translation>
    </message>
    <message>
        <source>Validation</source>
        <translation>Validación</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>Open/Refresh Form &amp;Preview</source>
        <translation>Abrir/Actualizar Vista Previa de Formulario</translation>
    </message>
    <message>
        <source>Form Preview Tool</source>
        <translation>Herramienta de Vista Previa de Formulario</translation>
    </message>
    <message>
        <source>F5</source>
        <translation>F5</translation>
    </message>
    <message>
        <source>Translation File &amp;Settings...</source>
        <translation>Archivo de Traducción &amp;Configuraciones...</translation>
    </message>
    <message>
        <source>&amp;Add to Phrase Book</source>
        <translation>&amp;Agregar al libro de frases</translation>
    </message>
    <message>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <source>Open Read-O&amp;nly...</source>
        <translation>Abrir solo lectura...</translation>
    </message>
    <message>
        <source>&amp;Save All</source>
        <translation>&amp;Guardar Todo</translation>
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <source>&amp;Release All</source>
        <translation>&amp;Liberar Todo</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>&amp;Close All</source>
        <translation>&amp;Cerrar Todo</translation>
    </message>
    <message>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <source>Length Variants</source>
        <translation>Variantes de Longitud</translation>
    </message>
    <message>
        <source>Visualize whitespace</source>
        <translation>Visualizar espacios en blanco</translation>
    </message>
    <message>
        <source>Toggle visualize whitespace in editors</source>
        <translation type="vanished">Alternar visualización de espacios en blanco en editores</translation>
    </message>
    <message>
        <source>Increase</source>
        <translation>Aumentar</translation>
    </message>
    <message>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <source>Decrease</source>
        <translation>Disminuir</translation>
    </message>
    <message>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <source>Reset to default</source>
        <translation>Restablecer a los valores predeterminados</translation>
    </message>
    <message>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <source></source>
        <comment>This is the application&apos;s main window.</comment>
        <translation></translation>
    </message>
    <message>
        <source>Source text</source>
        <translation>Texto fuente</translation>
    </message>
    <message>
        <source>Index</source>
        <translation>Índice</translation>
    </message>
    <message>
        <source>Context</source>
        <translation>Contexto</translation>
    </message>
    <message>
        <source>Items</source>
        <translation>Elementos</translation>
    </message>
    <message>
        <source>This panel lists the source contexts.</source>
        <translation>Este panel lista los contextos de origen.</translation>
    </message>
    <message>
        <source>Strings</source>
        <translation>Cadenas</translation>
    </message>
    <message>
        <source>Phrases and guesses</source>
        <translation>Frases y conjeturas</translation>
    </message>
    <message>
        <source>Sources and Forms</source>
        <translation>Fuentes y Formularios</translation>
    </message>
    <message>
        <source>Warnings</source>
        <translation>Advertencias</translation>
    </message>
    <message>
        <source> MOD </source>
        <comment>status bar: file(s) modified</comment>
        <translation> MOD </translation>
    </message>
    <message>
        <source>Loading...</source>
        <translation>Cargando...</translation>
    </message>
    <message>
        <source>Loading File - Qt Linguist</source>
        <translation>Cargando archivo - Qt Lingüista</translation>
    </message>
    <message>
        <source>The file &apos;%1&apos; does not seem to be related to the currently open file(s) &apos;%2&apos;.

Close the open file(s) first?</source>
        <translation>El archivo &apos;%1&apos; no parece estar relacionado con el(los) archivo(s) actualmente abierto(s) &apos;%2&apos;.

¿Cerrar el(los) archivo(s) abierto(s) primero?</translation>
    </message>
    <message>
        <source>The file &apos;%1&apos; does not seem to be related to the file &apos;%2&apos; which is being loaded as well.

Skip loading the first named file?</source>
        <translation>El archivo &apos;%1&apos; no parece estar relacionado con el archivo &apos;%2&apos; que también se está cargando.

¿Omitir la carga del primer archivo nombrado?</translation>
    </message>
    <message numerus="yes">
        <source>%n translation unit(s) loaded.</source>
        <translation>
            <numerusform>%n fordítási egység betöltve.</numerusform>
        </translation>
    </message>
    <message>
        <source>Related files (%1);;</source>
        <translation>Archivos relacionados (%1);;</translation>
    </message>
    <message>
        <source>Open Translation Files</source>
        <translation>Abrir archivos de traducción</translation>
    </message>
    <message>
        <source>File saved.</source>
        <translation>Archivo guardado.</translation>
    </message>
    <message>
        <source>Qt message files for released applications (*.qm)
All files (*)</source>
        <translation>Archivos de mensajes de Qt para aplicaciones liberadas (*.qm)
Todos los archivos (*)</translation>
    </message>
    <message>
        <source>File created.</source>
        <translation>Archivo creado.</translation>
    </message>
    <message>
        <source>Printing...</source>
        <translation>Imprimiendo...</translation>
    </message>
    <message>
        <source>Context: %1</source>
        <translation>Contexto: %1</translation>
    </message>
    <message>
        <source>finished</source>
        <translation>terminado</translation>
    </message>
    <message>
        <source>unresolved</source>
        <translation>sin resolver</translation>
    </message>
    <message>
        <source>obsolete</source>
        <translation>obsoleto</translation>
    </message>
    <message>
        <source>Printing... (page %1)</source>
        <translation>Imprimiendo... (página %1)</translation>
    </message>
    <message>
        <source>Printing completed</source>
        <translation>Impresión completada</translation>
    </message>
    <message>
        <source>Printing aborted</source>
        <translation>Impresión abortada</translation>
    </message>
    <message>
        <source>Search wrapped.</source>
        <translation>Búsqueda envuelta.</translation>
    </message>
    <message>
        <source>Qt Linguist</source>
        <translation>Qt Lingüista</translation>
    </message>
    <message>
        <source>Cannot find the string &apos;%1&apos;.</source>
        <translation>No se puede encontrar la cadena &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>Search And Translate in &apos;%1&apos; - Qt Linguist</source>
        <translation>Buscar y Traducir en &apos;%1&apos; - Qt Lingüista</translation>
    </message>
    <message>
        <source>Translate - Qt Linguist</source>
        <translation>Traducir - Qt Lingüista</translation>
    </message>
    <message numerus="yes">
        <source>Translated %n entry(s)</source>
        <translation>
            <numerusform>%n bejegyzés lefordítva</numerusform>
        </translation>
    </message>
    <message>
        <source>No more occurrences of &apos;%1&apos;. Start over?</source>
        <translation>No hay más ocurrencias de &apos;%1&apos;. ¿Empezar de nuevo?</translation>
    </message>
    <message>
        <source>Create New Phrase Book</source>
        <translation>Crear nuevo libro de frases</translation>
    </message>
    <message>
        <source>Qt phrase books (*.qph)
All files (*)</source>
        <translation>Libros de frases de Qt (*.qph)
Todos los archivos (*)</translation>
    </message>
    <message>
        <source>Phrase book created.</source>
        <translation>Libro de frases creado.</translation>
    </message>
    <message>
        <source>Open Phrase Book</source>
        <translation>Abrir libro de frases</translation>
    </message>
    <message>
        <source>Qt phrase books (*.qph);;All files (*)</source>
        <translation>Libros de frases Qt (*.qph);;Todos los archivos (*)</translation>
    </message>
    <message numerus="yes">
        <source>%n phrase(s) loaded.</source>
        <translation>
            <numerusform>%n kifejezés betöltve.</numerusform>
        </translation>
    </message>
    <message>
        <source>Add to phrase book</source>
        <translation>Agregar al libro de frases</translation>
    </message>
    <message>
        <source>No appropriate phrasebook found.</source>
        <translation>No se encontró un libro de frases apropiado.</translation>
    </message>
    <message>
        <source>Adding entry to phrasebook %1</source>
        <translation>Agregando entrada al libro de frases %1</translation>
    </message>
    <message>
        <source>Select phrase book to add to</source>
        <translation>Seleccionar libro de frases para agregar</translation>
    </message>
    <message>
        <source>Unable to launch Qt Assistant (%1)</source>
        <translation>No se puede iniciar Qt Assistant (%1)</translation>
    </message>
    <message>
        <source>Version %1</source>
        <translation>Versión %1</translation>
    </message>
    <message>
        <source>Qt Linguist is a tool for adding translations to Qt applications.</source>
        <translation>Qt Lingüista es una herramienta para añadir traducciones a aplicaciones Qt.</translation>
    </message>
    <message>
        <source>Copyright (C) %1 The Qt Company Ltd.</source>
        <translation type="vanished">Copyright (C) %1 The Qt Company Ltd.</translation>
    </message>
    <message>
        <source>&lt;center&gt;&lt;img src=&quot;:/images/splash.png&quot;/&gt;&lt;/img&gt;&lt;p&gt;%1&lt;/p&gt;&lt;/center&gt;&lt;p&gt;Qt Linguist is a tool for adding translations to Qt applications.&lt;/p&gt;&lt;p&gt;Copyright (C) %2 The Qt Company Ltd.</source>
        <translation type="vanished">&lt;center&gt;&lt;img src=&quot;:/images/splash.png&quot;/&gt;&lt;/img&gt;&lt;p&gt;%1&lt;/p&gt;&lt;/center&gt;&lt;p&gt;Qt Lingüista es una herramienta para agregar traducciones a apps Qt.&lt;/p&gt;&lt;p&gt;Copyright (C) %2 The Qt Company Ltd.</translation>
    </message>
    <message>
        <source>Do you want to save the modified files?</source>
        <translation>¿Desea guardar los archivos modificados?</translation>
    </message>
    <message>
        <source>Do you want to save &apos;%1&apos;?</source>
        <translation>¿Desea guardar &apos;%1&apos;?</translation>
    </message>
    <message>
        <source>Qt Linguist[*]</source>
        <translation>Qt Lingüista[*]</translation>
    </message>
    <message>
        <source>%1[*] - Qt Linguist</source>
        <translation>%1[*] - Qt Lingüista</translation>
    </message>
    <message>
        <source>No untranslated translation units left.</source>
        <translation>No quedan unidades de traducción sin traducir.</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Ventana</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Minimizar</translation>
    </message>
    <message>
        <source>Ctrl+M</source>
        <translation>Ctrl+M</translation>
    </message>
    <message>
        <source>Display the manual for %1.</source>
        <translation>Mostrar el manual de %1.</translation>
    </message>
    <message>
        <source>Display information about %1.</source>
        <translation>Mostrar información sobre %1.</translation>
    </message>
    <message>
        <source>&amp;Save &apos;%1&apos;</source>
        <translation>&amp;Guardar &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Save &apos;%1&apos; &amp;As...</source>
        <translation>Guardar &apos;%1&apos; &amp;Como...</translation>
    </message>
    <message>
        <source>Release &apos;%1&apos;</source>
        <translation>Liberar &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Release &apos;%1&apos; As...</source>
        <translation>Liberar &apos;%1&apos; Como...</translation>
    </message>
    <message>
        <source>&amp;Close &apos;%1&apos;</source>
        <translation>&amp;Cerrar &apos;%1&apos;</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Guardar</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <source>Save All</source>
        <translation>Guardar Todo</translation>
    </message>
    <message>
        <source>Close All</source>
        <translation>Cerrar Todo</translation>
    </message>
    <message>
        <source>&amp;Release</source>
        <translation>&amp;Liberar</translation>
    </message>
    <message>
        <source>Translation File &amp;Settings for &apos;%1&apos;...</source>
        <translation>Archivo de Traducción &amp;Configuraciones para &apos;%1&apos;...</translation>
    </message>
    <message>
        <source>&amp;Batch Translation of &apos;%1&apos;...</source>
        <translation>&amp;Traducción por Lotes de &apos;%1&apos;...</translation>
    </message>
    <message>
        <source>Search And &amp;Translate in &apos;%1&apos;...</source>
        <translation>Buscar y &amp;Traducir en &apos;%1&apos;...</translation>
    </message>
    <message>
        <source>Search And &amp;Translate...</source>
        <translation>Buscar y &amp;Traducir...</translation>
    </message>
    <message>
        <source>Cannot read from phrase book &apos;%1&apos;.</source>
        <translation>No se puede leer del libro de frases &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>Close this phrase book.</source>
        <translation>Cerrar este libro de frases.</translation>
    </message>
    <message>
        <source>Enables you to add, modify, or delete entries in this phrase book.</source>
        <translation>Le permite agregar, modificar o eliminar entradas en este libro de frases.</translation>
    </message>
    <message>
        <source>Print the entries in this phrase book.</source>
        <translation>Imprimir las entradas en este libro de frases.</translation>
    </message>
    <message>
        <source>Cannot create phrase book &apos;%1&apos;.</source>
        <translation>No se puede crear el libro de frases &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>Do you want to save phrase book &apos;%1&apos;?</source>
        <translation>¿Desea guardar el libro de frases &apos;%1&apos;?</translation>
    </message>
    <message numerus="yes">
        <source>%n unfinished message(s) left.</source>
        <translation>
            <numerusform>%n befejezetlen üzenet van hátra.</numerusform>
        </translation>
    </message>
    <message>
        <source>All</source>
        <translation>Todo</translation>
    </message>
    <message>
        <source>Guesses</source>
        <translation>Sugerencias</translation>
    </message>
    <message>
        <source>Toggles the validity check of accelerators</source>
        <translation>Alterna la verificación de validez de los aceleradores</translation>
    </message>
    <message>
        <source>Toggles the validity check of accelerators, i.e. whether the number of ampersands in the source and translation text is the same. If the check fails, a message is shown in the warnings window.</source>
        <translation>Alterna la verificación de validez de los aceleradores, es decir, si el número de ampersands en el texto fuente y el texto de traducción es el mismo. Si la verificación falla, se muestra un mensaje en la ventana de advertencias.</translation>
    </message>
    <message>
        <source>Surrounding &amp;Whitespace</source>
        <translation>Espacio en blanco &amp;circundante</translation>
    </message>
    <message>
        <source>Toggles the validity check of surrounding whitespace.</source>
        <translation>Alterna la verificación de validez del espacio en blanco circundante.</translation>
    </message>
    <message>
        <source>Toggles the validity check of surrounding whitespace. If the check fails, a message is shown in the warnings window.</source>
        <translation>Alterna la verificación de validez del espacio en blanco circundante. Si la verificación falla, se muestra un mensaje en la ventana de advertencias.</translation>
    </message>
    <message>
        <source>Toggles the validity check of ending punctuation</source>
        <translation>Alterna la verificación de validez de la puntuación final</translation>
    </message>
    <message>
        <source>Toggles the validity check of ending punctuation. If the check fails, a message is shown in the warnings window.</source>
        <translation>Alterna la verificación de validez de la puntuación final. Si la verificación falla, se muestra un mensaje en la ventana de advertencias.</translation>
    </message>
    <message>
        <source>Toggles checking that phrase suggestions are used</source>
        <translation>Alterna la verificación de que se usen las sugerencias de frases</translation>
    </message>
    <message>
        <source>Toggles checking that phrase suggestions are used. If the check fails, a message is shown in the warnings window.</source>
        <translation>Alternar la verificación de que se usen las sugerencias de frases. Si la verificación falla, se muestra un mensaje en la ventana de advertencias.</translation>
    </message>
    <message>
        <source>Toggles the validity check of place markers</source>
        <translation>Alterna la verificación de validez de los marcadores de posición</translation>
    </message>
    <message>
        <source>Toggles the validity check of place markers, i.e. whether %1, %2, ... are used consistently in the source text and translation text. If the check fails, a message is shown in the warnings window.</source>
        <translation>Alterna la verificación de validez de los marcadores de posición, es decir, si %1, %2, ... se utilizan de manera consistente en el texto fuente y el texto de traducción. Si la verificación falla, se muestra un mensaje en la ventana de advertencias.</translation>
    </message>
    <message>
        <source>Toggles visualize whitespace in editors</source>
        <translation>Alterna la visualización de espacios en blanco en los editores</translation>
    </message>
    <message>
        <source>Show more</source>
        <translation>Mostrar más</translation>
    </message>
    <message>
        <source>Alt++</source>
        <translation>Alt++</translation>
    </message>
    <message>
        <source>Show fewer</source>
        <translation>Mostrar menos</translation>
    </message>
    <message>
        <source>Alt+-</source>
        <translation>Alt+-</translation>
    </message>
    <message>
        <source>Alt+0</source>
        <translation>Alt+0</translation>
    </message>
    <message>
        <source>D&amp;one</source>
        <translation>H&amp;echo</translation>
    </message>
    <message>
        <source>Mark item as done</source>
        <translation>Marcar elemento como hecho</translation>
    </message>
    <message>
        <source>Mark this item as done.</source>
        <translation>Marcar este elemento como hecho.</translation>
    </message>
    <message>
        <source>Find P&amp;revious</source>
        <translation>Buscar A&amp;nterior</translation>
    </message>
    <message>
        <source>Shift+F3</source>
        <translation>Shift+F3</translation>
    </message>
</context>
<context>
    <name>MessageEditor</name>
    <message>
        <source></source>
        <comment>This is the right panel of the main window.</comment>
        <translation></translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="vanished">Ruso</translation>
    </message>
    <message>
        <source>German</source>
        <translation type="vanished">Alemán</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation type="vanished">Japonés</translation>
    </message>
    <message>
        <source>French</source>
        <translation type="vanished">Francés</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation type="vanished">Polaco</translation>
    </message>
    <message>
        <source>Chinese</source>
        <translation type="vanished">Chino</translation>
    </message>
    <message>
        <source>This whole panel allows you to view and edit the translation of some source text.</source>
        <translation>Este panel completo le permite ver y editar la traducción de algún texto fuente.</translation>
    </message>
    <message>
        <source>Source text</source>
        <translation>Texto fuente</translation>
    </message>
    <message>
        <source>This area shows the source text.</source>
        <translation>Esta área muestra el texto fuente.</translation>
    </message>
    <message>
        <source>Source text (Plural)</source>
        <translation>Texto fuente (Plural)</translation>
    </message>
    <message>
        <source>This area shows the plural form of the source text.</source>
        <translation>Esta área muestra la forma plural del texto fuente.</translation>
    </message>
    <message>
        <source>Developer comments</source>
        <translation>Comentarios del desarrollador</translation>
    </message>
    <message>
        <source>This area shows a comment that may guide you, and the context in which the text occurs.</source>
        <translation>Esta área muestra un comentario que puede guiarlo y el contexto en el que ocurre el texto.</translation>
    </message>
    <message>
        <source>Here you can enter comments for your own use. They have no effect on the translated applications.</source>
        <translation>Aquí puede ingresar comentarios para su propio uso. No tienen efecto en las aplicaciones traducidas.</translation>
    </message>
    <message>
        <source>Translation to %1 (%2)</source>
        <translation>Traducción a %1 (%2)</translation>
    </message>
    <message>
        <source>Translation to %1</source>
        <translation>Traducción a %1</translation>
    </message>
    <message>
        <source>Translator comments for %1</source>
        <translation>Comentarios del traductor para %1</translation>
    </message>
    <message>
        <source>%1 translation (%2)</source>
        <translation type="vanished">%1 traducción (%2)</translation>
    </message>
    <message>
        <source>This is where you can enter or modify the translation of the above source text.</source>
        <translation>Aquí puede ingresar o modificar la traducción del texto fuente anterior.</translation>
    </message>
    <message>
        <source>%1 translation</source>
        <translation type="vanished">%1 traducción</translation>
    </message>
    <message>
        <source>%1 translator comments</source>
        <translation type="vanished">%1 comentarios del traductor</translation>
    </message>
    <message>
        <source>&apos;%1&apos;
Line: %2</source>
        <translation>&apos;%1&apos;
Línea: %2</translation>
    </message>
</context>
<context>
    <name>MessageModel</name>
    <message>
        <source>Completion status for %1</source>
        <translation>Estado de finalización para %1</translation>
    </message>
    <message>
        <source>&lt;file header&gt;</source>
        <translation>&lt;encabezado de archivo&gt;</translation>
    </message>
    <message>
        <source>&lt;context comment&gt;</source>
        <translation>&lt;comentario de contexto&gt;</translation>
    </message>
    <message>
        <source>&lt;unnamed context&gt;</source>
        <translation>&lt;contexto sin nombre&gt;</translation>
    </message>
    <message numerus="yes">
        <source>%n unfinished message(s) left.</source>
        <translation>
            <numerusform>%n befejezetlen üzenet van hátra.</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>PhraseBook</name>
    <message>
        <source>Parse error at line %1, column %2 (%3).</source>
        <translation>Error de análisis en la línea %1, col %2 (%3).</translation>
    </message>
</context>
<context>
    <name>PhraseBookBox</name>
    <message>
        <source>Edit Phrase Book</source>
        <translation>Editar Libro de Frases</translation>
    </message>
    <message>
        <source>This window allows you to add, modify, or delete entries in a phrase book.</source>
        <translation>Esta ventana le permite agregar, modificar o eliminar entradas en un libro de frases.</translation>
    </message>
    <message>
        <source>&amp;Translation:</source>
        <translation>&amp;Traducción:</translation>
    </message>
    <message>
        <source>This is the phrase in the target language corresponding to the source phrase.</source>
        <translation>Esta es la frase en el idioma de destino correspondiente a la frase de origen.</translation>
    </message>
    <message>
        <source>S&amp;ource phrase:</source>
        <translation>Frase de origen:</translation>
    </message>
    <message>
        <source>This is a definition for the source phrase.</source>
        <translation>Esta es una definición para la frase fuente.</translation>
    </message>
    <message>
        <source>This is the phrase in the source language.</source>
        <translation>Esta es la frase en el idioma de origen.</translation>
    </message>
    <message>
        <source>&amp;Definition:</source>
        <translation>&amp;Definición:</translation>
    </message>
    <message>
        <source>Click here to add the phrase to the phrase book.</source>
        <translation>Haga clic aquí para agregar la frase al libro de frases.</translation>
    </message>
    <message>
        <source>&amp;New Entry</source>
        <translation>&amp;Nueva Entrada</translation>
    </message>
    <message>
        <source>Click here to remove the entry from the phrase book.</source>
        <translation>Haga clic aquí para eliminar la entrada del libro de frases.</translation>
    </message>
    <message>
        <source>&amp;Remove Entry</source>
        <translation>&amp;Eliminar Entrada</translation>
    </message>
    <message>
        <source>Settin&amp;gs...</source>
        <translation>Confi&amp;guración...</translation>
    </message>
    <message>
        <source>Click here to save the changes made.</source>
        <translation>Haga clic aquí para guardar los cambios realizados.</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Guardar</translation>
    </message>
    <message>
        <source>Click here to close this window.</source>
        <translation>Haga clic aquí para cerrar esta ventana.</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source></source>
        <comment>Go to Phrase &gt; Edit Phrase Book... The dialog that pops up is a PhraseBookBox.</comment>
        <translation></translation>
    </message>
    <message>
        <source>(New Entry)</source>
        <translation>(Nueva Entrada)</translation>
    </message>
    <message>
        <source>%1[*] - Qt Linguist</source>
        <translation>%1[*] - Qt Lingüista</translation>
    </message>
    <message>
        <source>Qt Linguist</source>
        <translation>Qt Lingüista</translation>
    </message>
    <message>
        <source>Cannot save phrase book &apos;%1&apos;.</source>
        <translation>No se puede guardar el libro de frases &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>PhraseModel</name>
    <message>
        <source>Source phrase</source>
        <translation>Frase de origen</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Traducción</translation>
    </message>
    <message>
        <source>Definition</source>
        <translation>Definición</translation>
    </message>
</context>
<context>
    <name>PhraseView</name>
    <message>
        <source>Insert</source>
        <translation>Insertar</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Go to</source>
        <translation>Ir a</translation>
    </message>
    <message>
        <source>Guess from &apos;%1&apos; (%2)</source>
        <translation>Adivinar desde &apos;%1&apos; (%2)</translation>
    </message>
    <message>
        <source>Guess from &apos;%1&apos;</source>
        <translation>Adivinar desde &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Guess (%1)</source>
        <translation type="vanished">Adivinar (%1)</translation>
    </message>
    <message>
        <source>Guess</source>
        <translation type="vanished">Adivinar</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Translation files (%1);;</source>
        <translation>Archivos de traducción (%1);;</translation>
    </message>
    <message>
        <source>All files (*)</source>
        <translation>Todos los archivos (*)</translation>
    </message>
    <message>
        <source>Qt Linguist</source>
        <translation>Qt Lingüista</translation>
    </message>
</context>
<context>
    <name>SourceCodeView</name>
    <message>
        <source>&lt;i&gt;Source code not available&lt;/i&gt;</source>
        <translation>&lt;i&gt;Código fuente no disponible&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;i&gt;File %1 not available&lt;/i&gt;</source>
        <translation>&lt;i&gt;Archivo %1 no disponible&lt;/i&gt;</translation>
    </message>
    <message>
        <source>&lt;i&gt;File %1 not readable&lt;/i&gt;</source>
        <translation>&lt;i&gt;Archivo %1 no legible&lt;/i&gt;</translation>
    </message>
</context>
<context>
    <name>Statistics</name>
    <message>
        <source>Statistics</source>
        <translation>Estadísticas</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Translation</source>
        <translation>Traducción</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Words:</source>
        <translation>Textos:</translation>
    </message>
    <message>
        <source>Characters:</source>
        <translation>Caracteres:</translation>
    </message>
    <message>
        <source>Characters (with spaces):</source>
        <translation>Caracteres (con espacios):</translation>
    </message>
    <message>
        <source>Unfinished</source>
        <translation>Incompleto</translation>
    </message>
    <message>
        <source>Total translatable messages:</source>
        <translation>Total de mensajes traducibles:</translation>
    </message>
    <message>
        <source>Total finished:</source>
        <translation>Total completados:</translation>
    </message>
    <message>
        <source>Without warnings:</source>
        <translation>Sin advertencias:</translation>
    </message>
    <message>
        <source>With warnings:</source>
        <translation>Con advertencias:</translation>
    </message>
    <message>
        <source>Unfinished:</source>
        <translation>Incompleto:</translation>
    </message>
    <message>
        <source>Total messages including obsolete:</source>
        <translation>Total de mensajes incluyendo obsoletos:</translation>
    </message>
</context>
<context>
    <name>TranslateDialog</name>
    <message>
        <source>This window allows you to search for some text in the translation source file.</source>
        <translation>Esta ventana le permite buscar texto en el archivo fuente de traducción.</translation>
    </message>
    <message>
        <source>Type in the text to search for.</source>
        <translation>Escriba el texto a buscar.</translation>
    </message>
    <message>
        <source>Find &amp;source text:</source>
        <translation>Buscar &amp;texto fuente:</translation>
    </message>
    <message>
        <source>&amp;Translate to:</source>
        <translation>&amp;Traducir a:</translation>
    </message>
    <message>
        <source>Search options</source>
        <translation>Opciones de búsqueda</translation>
    </message>
    <message>
        <source>Texts such as &apos;TeX&apos; and &apos;tex&apos; are considered as different when checked.</source>
        <translation>Textos como &apos;TeX&apos; y &apos;tex&apos; se consideran diferentes al verificarlos.</translation>
    </message>
    <message>
        <source>Match &amp;case</source>
        <translation>Coincidir &amp;mayúsculas y minúsculas</translation>
    </message>
    <message>
        <source>Mark new translation as &amp;finished</source>
        <translation>Marcar nueva traducción como &amp;completada</translation>
    </message>
    <message>
        <source>Click here to find the next occurrence of the text you typed in.</source>
        <translation>Haga clic aquí para encontrar la siguiente ocurrencia del texto que escribió.</translation>
    </message>
    <message>
        <source>Find Next</source>
        <translation>Buscar siguiente</translation>
    </message>
    <message>
        <source>Translate</source>
        <translation>Traducir</translation>
    </message>
    <message>
        <source>Translate All</source>
        <translation>Traducir todo</translation>
    </message>
    <message>
        <source>Click here to close this window.</source>
        <translation>Haga clic aquí para cerrar esta ventana.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>TranslationSettingsDialog</name>
    <message>
        <source>Source language</source>
        <translation>Idioma de origen</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <source>Country/Region</source>
        <translation>País/Región</translation>
    </message>
    <message>
        <source>Target language</source>
        <translation>Idioma de destino</translation>
    </message>
    <message>
        <source>%1 (%2)</source>
        <extracomment>&lt;english&gt; (&lt;endonym&gt;) (language names)</extracomment>
        <translation>%1 (%2)</translation>
    </message>
    <message>
        <source>Settings for &apos;%1&apos; - Qt Linguist</source>
        <translation>Configuración para &apos;%1&apos; - Qt Lingüista</translation>
    </message>
    <message>
        <source>Any Territory</source>
        <translation>Cualquier territorio</translation>
    </message>
    <message>
        <source>Any Country</source>
        <translation type="vanished">Cualquier país</translation>
    </message>
</context>
</TS>
