<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QWidget</name>
    <message>
        <source>*</source>
        <translation>*</translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>CD</source>
        <translation>CD</translation>
    </message>
    <message>
        <source>Go</source>
        <translation>Ir</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Arriba</translation>
    </message>
    <message>
        <source>Alt</source>
        <translation>Alt</translation>
    </message>
    <message>
        <source>F%1</source>
        <translation>F%1</translation>
    </message>
    <message>
        <source>DOS</source>
        <translation>DOS</translation>
    </message>
    <message>
        <source>Del</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <source>End</source>
        <translation>Fin</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Ins</source>
        <translation>Ins</translation>
    </message>
    <message>
        <source>Tab</source>
        <translation>Pestaña</translation>
    </message>
    <message>
        <source>WWW</source>
        <translation>WWW</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Atrás</translation>
    </message>
    <message>
        <source>Away</source>
        <translation>Ausente</translation>
    </message>
    <message>
        <source>Book</source>
        <translation>Libro</translation>
    </message>
    <message>
        <source>Call</source>
        <translation>Llamada</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Ctrl</source>
        <translation>Ctrl</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Abajo</translation>
    </message>
    <message>
        <source>Flip</source>
        <translation>Voltear</translation>
    </message>
    <message>
        <source>Game</source>
        <translation>Juego</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Inicio</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Izquierda</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>Menú</translation>
    </message>
    <message>
        <source>Meta</source>
        <translation>Meta</translation>
    </message>
    <message>
        <source>News</source>
        <translation>Noticias</translation>
    </message>
    <message>
        <source>PgUp</source>
        <translation>RePág</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Enviar</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Tienda</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Detener</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Hora</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Ver</translation>
    </message>
    <message>
        <source>Split Screen</source>
        <translation>Pantalla Dividida</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Limpiar</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Eject</source>
        <translation>Expulsar</translation>
    </message>
    <message>
        <source>Enter</source>
        <translation>Entrar</translation>
    </message>
    <message>
        <source>Kanji</source>
        <translation>Kanji</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Pegar</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pausa</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>Teléfono</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>Reply</source>
        <translation>Responder</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Derecha</translation>
    </message>
    <message>
        <source>Shift</source>
        <translation>Mayús</translation>
    </message>
    <message>
        <source>Sleep</source>
        <translation>Dormir</translation>
    </message>
    <message>
        <source>Space</source>
        <translation>Espacio</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Herramientas</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Hiragana</source>
        <translation>Hiragana</translation>
    </message>
    <message>
        <source>Wireless</source>
        <translation>Inalámbrico</translation>
    </message>
    <message>
        <source>Media Record</source>
        <translation>Grabar Medios</translation>
    </message>
    <message>
        <source>Print Screen</source>
        <translation>Imprimir pantalla</translation>
    </message>
    <message>
        <source>Audio Rewind</source>
        <translation>Rebobinar Audio</translation>
    </message>
    <message>
        <source>Audio Repeat</source>
        <translation>Repetir audio</translation>
    </message>
    <message>
        <source>Toggle Call/Hangup</source>
        <translation>Alternar llamada/colgar</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>Acercar</translation>
    </message>
    <message>
        <source>Treble Down</source>
        <translation>Bajos</translation>
    </message>
    <message>
        <source>Scroll Lock</source>
        <translation>Bloqueo de desplazamiento</translation>
    </message>
    <message>
        <source>Media Pause</source>
        <translation>Pausa de medios</translation>
    </message>
    <message>
        <source>Word Processor</source>
        <translation>Procesador de Texto</translation>
    </message>
    <message>
        <source>Volume Down</source>
        <translation>Bajar volumen</translation>
    </message>
    <message>
        <source>Volume Mute</source>
        <translation>Silenciar volumen</translation>
    </message>
    <message>
        <source>Media Previous</source>
        <translation>Medios Anterior</translation>
    </message>
    <message>
        <source>Home Page</source>
        <translation>Página de Inicio</translation>
    </message>
    <message>
        <source>Meeting</source>
        <translation>Reunión</translation>
    </message>
    <message>
        <source>Volume Up</source>
        <translation>Subir volumen</translation>
    </message>
    <message>
        <source>Keyboard Brightness Up</source>
        <translation>Aumentar Brillo del Teclado</translation>
    </message>
    <message>
        <source>Community</source>
        <translation>Comunidad</translation>
    </message>
    <message>
        <source>Launch (6)</source>
        <translation>Lanzar (6)</translation>
    </message>
    <message>
        <source>Launch (7)</source>
        <translation>Lanzar (7)</translation>
    </message>
    <message>
        <source>Launch (8)</source>
        <translation>Lanzar (8)</translation>
    </message>
    <message>
        <source>Launch (9)</source>
        <translation>Lanzar (9)</translation>
    </message>
    <message>
        <source>Launch (2)</source>
        <translation>Lanzar (2)</translation>
    </message>
    <message>
        <source>Launch (3)</source>
        <translation>Lanzar (3)</translation>
    </message>
    <message>
        <source>Launch (4)</source>
        <translation>Lanzar (4)</translation>
    </message>
    <message>
        <source>Launch (5)</source>
        <translation>Lanzar (5)</translation>
    </message>
    <message>
        <source>Launch (0)</source>
        <translation>Lanzar (0)</translation>
    </message>
    <message>
        <source>Launch (1)</source>
        <translation>Lanzar (1)</translation>
    </message>
    <message>
        <source>Launch (F)</source>
        <translation>Lanzar (F)</translation>
    </message>
    <message>
        <source>Launch (B)</source>
        <translation>Lanzar (B)</translation>
    </message>
    <message>
        <source>Launch (C)</source>
        <translation>Lanzar (C)</translation>
    </message>
    <message>
        <source>Launch (D)</source>
        <translation>Lanzar (D)</translation>
    </message>
    <message>
        <source>Launch (E)</source>
        <translation>Lanzar (E)</translation>
    </message>
    <message>
        <source>Launch (A)</source>
        <translation>Lanzar (A)</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Escape</source>
        <translation>Escape</translation>
    </message>
    <message>
        <source>Audio Random Play</source>
        <translation>Reproducción Aleatoria de Audio</translation>
    </message>
    <message>
        <source>Hangup</source>
        <translation>Colgar</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Insertar</translation>
    </message>
    <message>
        <source>Home Office</source>
        <translation>Oficina en casa</translation>
    </message>
    <message>
        <source>Last Number Redial</source>
        <translation>Remarcado del último número</translation>
    </message>
    <message>
        <source>Logoff</source>
        <translation>Cerrar Sesión</translation>
    </message>
    <message>
        <source>Market</source>
        <translation>Mercado</translation>
    </message>
    <message>
        <source>Bass Boost</source>
        <translation>Refuerzo de bajos</translation>
    </message>
    <message>
        <source>Option</source>
        <translation>Opción</translation>
    </message>
    <message>
        <source>PgDown</source>
        <translation>AvPág</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Recargar</translation>
    </message>
    <message>
        <source>Return</source>
        <translation>Regresar</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Seleccionar</translation>
    </message>
    <message>
        <source>SysReq</source>
        <translation>PetSis</translation>
    </message>
    <message>
        <source>Travel</source>
        <translation>Viajar</translation>
    </message>
    <message>
        <source>NumLock</source>
        <translation>Bloq Num</translation>
    </message>
    <message>
        <source>Audio Forward</source>
        <translation>Avance de audio</translation>
    </message>
    <message>
        <source>WebCam</source>
        <translation>Cámara web</translation>
    </message>
    <message>
        <source>Top Menu</source>
        <translation>Menú principal</translation>
    </message>
    <message>
        <source>ScrollLock</source>
        <translation>Bloqueo de Desplazamiento</translation>
    </message>
    <message>
        <source>Hot Links</source>
        <translation>Enlaces Rápidos</translation>
    </message>
    <message>
        <source>Context1</source>
        <translation>Contexto1</translation>
    </message>
    <message>
        <source>Context2</source>
        <translation>Contexto2</translation>
    </message>
    <message>
        <source>Context3</source>
        <translation>Contexto3</translation>
    </message>
    <message>
        <source>Context4</source>
        <translation>Contexto4</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>Alejar</translation>
    </message>
    <message>
        <source>Page Up</source>
        <translation>Página arriba</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation>Abrir URL</translation>
    </message>
    <message>
        <source>iTouch</source>
        <translation>iTouch</translation>
    </message>
    <message>
        <source>Toggle Media Play/Pause</source>
        <translation>Alternar reproducción/pausa de medios</translation>
    </message>
    <message>
        <source>Caps Lock</source>
        <translation>Bloq Mayús</translation>
    </message>
    <message>
        <source>Code input</source>
        <translation>Entrada de código</translation>
    </message>
    <message>
        <source>Camera Focus</source>
        <translation>Enfoque de la cámara</translation>
    </message>
    <message>
        <source>Adjust Brightness</source>
        <translation>Ajustar Brillo</translation>
    </message>
    <message>
        <source>Spreadsheet</source>
        <translation>Hoja de cálculo</translation>
    </message>
    <message>
        <source>Keyboard Brightness Down</source>
        <translation>Bajar brillo del teclado</translation>
    </message>
    <message>
        <source>Monitor Brightness Up</source>
        <translation>Subir brillo del monitor</translation>
    </message>
    <message>
        <source>System Request</source>
        <translation>Solicitud del sistema</translation>
    </message>
    <message>
        <source>CapsLock</source>
        <translation>BloqMayús</translation>
    </message>
    <message>
        <source>Backtab</source>
        <translation>Retroceso</translation>
    </message>
    <message>
        <source>Bass Up</source>
        <translation>Aumentar Bajos</translation>
    </message>
    <message>
        <source>Battery</source>
        <translation>Batería</translation>
    </message>
    <message>
        <source>Katakana</source>
        <translation>Katakana</translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <source>Hibernate</source>
        <translation>Hibernar</translation>
    </message>
    <message>
        <source>Application Left</source>
        <translation>Aplicación izquierda</translation>
    </message>
    <message>
        <source>Voice Dial</source>
        <translation>Marcación por voz</translation>
    </message>
    <message>
        <source>Browser</source>
        <translation>Navegador</translation>
    </message>
    <message>
        <source>Keyboard Menu</source>
        <translation>Menú del teclado</translation>
    </message>
    <message>
        <source>Back Forward</source>
        <translation>Atrás Adelante</translation>
    </message>
    <message>
        <source>Launch Mail</source>
        <translation>Abrir correo</translation>
    </message>
    <message>
        <source>Keyboard Light On/Off</source>
        <translation>Luz del teclado encendida/apagada</translation>
    </message>
    <message>
        <source>Backspace</source>
        <translation>Retroceso</translation>
    </message>
    <message>
        <source>Bass Down</source>
        <translation>Bajar bajos</translation>
    </message>
    <message>
        <source>Mail Forward</source>
        <translation>Reenviar Correo</translation>
    </message>
    <message>
        <source>Messenger</source>
        <translation>Mensajero</translation>
    </message>
    <message>
        <source>Standby</source>
        <translation>En espera</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>Documentos</translation>
    </message>
    <message>
        <source>Calculator</source>
        <translation>Calculadora</translation>
    </message>
    <message>
        <source>Support</source>
        <translation>Soporte</translation>
    </message>
    <message>
        <source>Suspend</source>
        <translation>Suspender</translation>
    </message>
    <message>
        <source>Display</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <source>My Sites</source>
        <translation>Mis Sitios</translation>
    </message>
    <message>
        <source>Rotate Windows</source>
        <translation>Rotar ventanas</translation>
    </message>
    <message>
        <source>Treble Up</source>
        <translation>Subir agudos</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Subtítulo</translation>
    </message>
    <message>
        <source>Hangul Jamo</source>
        <translation>Hangul Jamo</translation>
    </message>
    <message>
        <source>Bluetooth</source>
        <translation>Bluetooth</translation>
    </message>
    <message>
        <source>Num Lock</source>
        <translation>Bloq Num</translation>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Protector de Pantalla</translation>
    </message>
    <message>
        <source>Spellchecker</source>
        <translation>Corrector ortográfico</translation>
    </message>
    <message>
        <source>Terminal</source>
        <translation>Terminal</translation>
    </message>
    <message>
        <source>Add Favorite</source>
        <translation>Agregar a Favoritos</translation>
    </message>
    <message>
        <source>Finance</source>
        <translation>Finanzas</translation>
    </message>
    <message>
        <source>Task Panel</source>
        <translation>Panel de Tareas</translation>
    </message>
    <message>
        <source>Favorites</source>
        <translation>Favoritos</translation>
    </message>
    <message>
        <source>Forward</source>
        <translation>Adelante</translation>
    </message>
    <message>
        <source>Page Down</source>
        <translation>Página abajo</translation>
    </message>
    <message>
        <source>Wake Up</source>
        <translation>Despertar</translation>
    </message>
    <message>
        <source>Power Off</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <source>LightBulb</source>
        <translation>Bombilla</translation>
    </message>
    <message>
        <source>Monitor Brightness Down</source>
        <translation>Bajar brillo del monitor</translation>
    </message>
    <message>
        <source>History</source>
        <translation>Historial</translation>
    </message>
    <message>
        <source>Media Play</source>
        <translation>Reproducir medios</translation>
    </message>
    <message>
        <source>Media Stop</source>
        <translation>Detener medios</translation>
    </message>
    <message>
        <source>Media Next</source>
        <translation>Siguiente en medios</translation>
    </message>
    <message>
        <source>Launch Media</source>
        <translation>Lanzar Medios</translation>
    </message>
    <message>
        <source>Application Right</source>
        <translation>Aplicación derecha</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Imágenes</translation>
    </message>
</context>
<context>
    <name>QPrintDialog</name>
    <message>
        <source>A0</source>
        <translation>A0</translation>
    </message>
    <message>
        <source>A1</source>
        <translation>A1</translation>
    </message>
    <message>
        <source>A2</source>
        <translation>A2</translation>
    </message>
    <message>
        <source>A3</source>
        <translation>A3</translation>
    </message>
    <message>
        <source>A4</source>
        <translation>A4</translation>
    </message>
    <message>
        <source>A5</source>
        <translation>A5</translation>
    </message>
    <message>
        <source>A6</source>
        <translation>A6</translation>
    </message>
    <message>
        <source>A7</source>
        <translation>A7</translation>
    </message>
    <message>
        <source>A8</source>
        <translation>A8</translation>
    </message>
    <message>
        <source>A9</source>
        <translation>A9</translation>
    </message>
    <message>
        <source>B0</source>
        <translation>B0</translation>
    </message>
    <message>
        <source>B1</source>
        <translation>B1</translation>
    </message>
    <message>
        <source>B2</source>
        <translation>B2</translation>
    </message>
    <message>
        <source>B3</source>
        <translation>B3</translation>
    </message>
    <message>
        <source>B4</source>
        <translation>B4</translation>
    </message>
    <message>
        <source>B5</source>
        <translation>B5</translation>
    </message>
    <message>
        <source>B6</source>
        <translation>B6</translation>
    </message>
    <message>
        <source>B7</source>
        <translation>B7</translation>
    </message>
    <message>
        <source>B8</source>
        <translation>B8</translation>
    </message>
    <message>
        <source>B9</source>
        <translation>B9</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <source>B10</source>
        <translation>B10</translation>
    </message>
    <message>
        <source>C5E</source>
        <translation>C5E</translation>
    </message>
    <message>
        <source>DLE</source>
        <translation>DLE</translation>
    </message>
    <message>
        <source>A6 (105 x 148 mm)</source>
        <translation>A6 (105 x 148 mm)</translation>
    </message>
    <message>
        <source>Legal (8.5 x 14 inches, 216 x 356 mm)</source>
        <translation>Legal (8,5 x 14 pulgadas, 216 x 356 mm)</translation>
    </message>
    <message>
        <source>Folio</source>
        <translation>Folio</translation>
    </message>
    <message>
        <source>Legal</source>
        <translation>Legal</translation>
    </message>
    <message>
        <source>Print all</source>
        <translation>Imprimir todo</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>&amp;Options &lt;&lt;</source>
        <translation>&amp;Opciones &lt;&lt;</translation>
    </message>
    <message>
        <source>&amp;Options &gt;&gt;</source>
        <translation>&amp;Opciones &gt;&gt;</translation>
    </message>
    <message>
        <source>B6 (125 x 176 mm)</source>
        <translation>B6 (125 x 176 mm)</translation>
    </message>
    <message>
        <source>B8 (62 x 88 mm)</source>
        <translation>B8 (62 x 88 mm)</translation>
    </message>
    <message>
        <source>A8 (52 x 74 mm)</source>
        <translation>A8 (52 x 74 mm)</translation>
    </message>
    <message>
        <source>B9 (44 x 62 mm)</source>
        <translation>B9 (44 x 62 mm)</translation>
    </message>
    <message>
        <source>A9 (37 x 52 mm)</source>
        <translation>A9 (37 x 52 mm)</translation>
    </message>
    <message>
        <source>B0 (1000 x 1414 mm)</source>
        <translation>B0 (1000 x 1414 mm)</translation>
    </message>
    <message>
        <source>A5 (148 x 210 mm)</source>
        <translation>A5 (148 x 210 mm)</translation>
    </message>
    <message>
        <source>Tabloid (279 x 432 mm)</source>
        <translation>Tabloide (279 x 432 mm)</translation>
    </message>
    <message>
        <source>B10 (31 x 44 mm)</source>
        <translation>B10 (31 x 44 mm)</translation>
    </message>
    <message>
        <source>B2 (500 x 707 mm)</source>
        <translation>B2 (500 x 707 mm)</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation>&amp;Imprimir</translation>
    </message>
    <message>
        <source>A3 (297 x 420 mm)</source>
        <translation>A3 (297 x 420 mm)</translation>
    </message>
    <message>
        <source>Print selection</source>
        <translation>Imprimir selección</translation>
    </message>
    <message>
        <source>Print to File (Postscript)</source>
        <translation>Imprimir a archivo (Postscript)</translation>
    </message>
    <message>
        <source>B4 (250 x 353 mm)</source>
        <translation>B4 (250 x 353 mm)</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to overwrite it?</source>
        <translation>%1 ya existe.
¿Desea sobrescribirlo?</translation>
    </message>
    <message>
        <source>A1 (594 x 841 mm)</source>
        <translation>A1 (594 x 841 mm)</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Personalizado</translation>
    </message>
    <message>
        <source>B1 (707 x 1000 mm)</source>
        <translation>B1 (707 x 1000 mm)</translation>
    </message>
    <message>
        <source>Folio (210 x 330 mm)</source>
        <translation>Folio (210 x 330 mm)</translation>
    </message>
    <message>
        <source>Ledger</source>
        <translation>Libro mayor</translation>
    </message>
    <message>
        <source>Letter</source>
        <translation>Carta</translation>
    </message>
    <message>
        <source>DLE (110 x 220 mm)</source>
        <translation>DLE (110 x 220 mm)</translation>
    </message>
    <message>
        <source>C5E (163 x 229 mm)</source>
        <translation>C5E (163 x 229 mm)</translation>
    </message>
    <message>
        <source>B5 (176 x 250 mm, 6.93 x 9.84 inches)</source>
        <translation>B5 (176 x 250 mm, 6,93 x 9,84 pulgadas)</translation>
    </message>
    <message>
        <source>Print range</source>
        <translation>Rango de impresión</translation>
    </message>
    <message>
        <source>File exists</source>
        <translation>El archivo existe</translation>
    </message>
    <message>
        <source>Write %1 file</source>
        <translation>Escribir archivo %1</translation>
    </message>
    <message>
        <source>Print current page</source>
        <translation>Imprimir página actual</translation>
    </message>
    <message>
        <source>A0 (841 x 1189 mm)</source>
        <translation>A0 (841 x 1189 mm)</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>Archivo local</translation>
    </message>
    <message>
        <source>locally connected</source>
        <translation>conectado localmente</translation>
    </message>
    <message>
        <source>Ledger (432 x 279 mm)</source>
        <translation>Libro mayor (432 x 279 mm)</translation>
    </message>
    <message>
        <source>Aliases: %1</source>
        <translation>Alias: %1</translation>
    </message>
    <message>
        <source>Print to File (PDF)</source>
        <translation>Imprimir a archivo (PDF)</translation>
    </message>
    <message>
        <source>Print To File ...</source>
        <translation>Imprimir a archivo ...</translation>
    </message>
    <message>
        <source>US Common #10 Envelope (105 x 241 mm)</source>
        <translation>Sobre común de EE. UU. #10 (105 x 241 mm)</translation>
    </message>
    <message>
        <source>Tabloid</source>
        <translation>Tabloide</translation>
    </message>
    <message>
        <source>A4 (210 x 297 mm, 8.26 x 11.7 inches)</source>
        <translation>A4 (210 x 297 mm, 8,26 x 11,7 pulgadas)</translation>
    </message>
    <message>
        <source>Executive</source>
        <translation>Ejecutivo</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>desconocido</translation>
    </message>
    <message>
        <source>&lt;qt&gt;Do you want to overwrite it?&lt;/qt&gt;</source>
        <translation>&lt;qt&gt;¿Desea sobrescribirlo?&lt;/qt&gt;</translation>
    </message>
    <message>
        <source>Executive (7.5 x 10 inches, 191 x 254 mm)</source>
        <translation>Ejecutivo (7,5 x 10 pulgadas, 191 x 254 mm)</translation>
    </message>
    <message>
        <source>Letter (8.5 x 11 inches, 216 x 279 mm)</source>
        <translation>Carta (8,5 x 11 pulgadas, 216 x 279 mm)</translation>
    </message>
    <message>
        <source>The &apos;From&apos; value cannot be greater than the &apos;To&apos; value.</source>
        <translation>El valor &apos;Desde&apos; no puede ser mayor que el valor &apos;Hasta&apos;.</translation>
    </message>
    <message>
        <source>US Common #10 Envelope</source>
        <translation>Sobre común de EE. UU. #10</translation>
    </message>
    <message>
        <source>%1 is a directory.
Please choose a different file name.</source>
        <translation>%1 es un directorio.
Por favor elija un nombre de archivo diferente.</translation>
    </message>
    <message>
        <source>File %1 is not writable.
Please choose a different file name.</source>
        <translation>El archivo %1 no se puede escribir.
Por favor elija un nombre de archivo diferente.</translation>
    </message>
    <message>
        <source>B3 (353 x 500 mm)</source>
        <translation>B3 (353 x 500 mm)</translation>
    </message>
    <message>
        <source>A7 (74 x 105 mm)</source>
        <translation>A7 (74 x 105 mm)</translation>
    </message>
    <message>
        <source>A2 (420 x 594 mm)</source>
        <translation>A2 (420 x 594 mm)</translation>
    </message>
    <message>
        <source>B7 (88 x 125 mm)</source>
        <translation>B7 (88 x 125 mm)</translation>
    </message>
</context>
<context>
    <name>QDateTimeEdit</name>
    <message>
        <source>AM</source>
        <translation>AM</translation>
    </message>
    <message>
        <source>PM</source>
        <translation>PM</translation>
    </message>
    <message>
        <source>am</source>
        <translation>am</translation>
    </message>
    <message>
        <source>pm</source>
        <translation>pm</translation>
    </message>
</context>
<context>
    <name>QScriptDebugger</name>
    <message>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <source>F5</source>
        <translation>F5</translation>
    </message>
    <message>
        <source>F9</source>
        <translation>F9</translation>
    </message>
    <message>
        <source>F10</source>
        <translation>F10</translation>
    </message>
    <message>
        <source>F11</source>
        <translation>F11</translation>
    </message>
    <message>
        <source>Debug</source>
        <translation>Depuración</translation>
    </message>
    <message>
        <source>Line:</source>
        <translation>Línea:</translation>
    </message>
    <message>
        <source>Clear Console</source>
        <translation>Limpiar consola</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <source>Clear Error Log</source>
        <translation>Limpiar registro de errores</translation>
    </message>
    <message>
        <source>Clear Debug Output</source>
        <translation>Limpiar salida de depuración</translation>
    </message>
    <message>
        <source>Toggle Breakpoint</source>
        <translation>Alternar punto de interrupción</translation>
    </message>
    <message>
        <source>Find &amp;Next</source>
        <translation>Buscar &amp;Siguiente</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Continuar</translation>
    </message>
    <message>
        <source>Find &amp;Previous</source>
        <translation>Buscar &amp;Anterior</translation>
    </message>
    <message>
        <source>Step Out</source>
        <translation>Salir</translation>
    </message>
    <message>
        <source>Interrupt</source>
        <translation>Interrumpir</translation>
    </message>
    <message>
        <source>Go to Line</source>
        <translation>Ir a la línea</translation>
    </message>
    <message>
        <source>Ctrl+F10</source>
        <translation>Ctrl+F10</translation>
    </message>
    <message>
        <source>Step Into</source>
        <translation>Entrar</translation>
    </message>
    <message>
        <source>Step Over</source>
        <translation>Saltar</translation>
    </message>
    <message>
        <source>&amp;Find in Script...</source>
        <translation>&amp;Buscar en el script...</translation>
    </message>
    <message>
        <source>Run to Cursor</source>
        <translation>Ejecutar hasta el cursor</translation>
    </message>
    <message>
        <source>Run to New Script</source>
        <translation>Ejecutar hasta nuevo script</translation>
    </message>
    <message>
        <source>Shift+F3</source>
        <translation>Shift+F3</translation>
    </message>
    <message>
        <source>Shift+F5</source>
        <translation>Shift+F5</translation>
    </message>
    <message>
        <source>Shift+F11</source>
        <translation>Shift+F11</translation>
    </message>
</context>
<context>
    <name>QScriptBreakpointsModel</name>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Single-shot</source>
        <translation>Disparo único</translation>
    </message>
    <message>
        <source>Condition</source>
        <translation>Condición</translation>
    </message>
    <message>
        <source>Ignore-count</source>
        <translation>Ignorar-conteo</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Ubicación</translation>
    </message>
    <message>
        <source>Hit-count</source>
        <translation>Conteo de aciertos</translation>
    </message>
</context>
<context>
    <name>Q3TabDialog</name>
    <message>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Defaults</source>
        <translation>Predeterminados</translation>
    </message>
</context>
<context>
    <name>QAxSelect</name>
    <message>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <source>COM &amp;Object:</source>
        <translation>Objeto &amp; COM:</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>Select ActiveX Control</source>
        <translation>Seleccionar Control ActiveX</translation>
    </message>
</context>
<context>
    <name>QDialogButtonBox</name>
    <message>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Guardar</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Abortar</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Restablecer</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Reintentar</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation>Restaurar Predeterminados</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Ignorar</translation>
    </message>
    <message>
        <source>Close without Saving</source>
        <translation>Cerrar sin Guardar</translation>
    </message>
    <message>
        <source>N&amp;o to All</source>
        <translation>N&amp;o a Todo</translation>
    </message>
    <message>
        <source>Save All</source>
        <translation>Guardar Todo</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
    <message>
        <source>Yes to &amp;All</source>
        <translation>Sí a &amp;Todo</translation>
    </message>
    <message>
        <source>Don&apos;t Save</source>
        <translation>No Guardar</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>Show Details...</source>
        <translation>Mostrar detalles...</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Acerca de Qt</translation>
    </message>
    <message>
        <source>&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across MS&amp;nbsp;Windows, Mac&amp;nbsp;OS&amp;nbsp;X, Linux, and all major commercial Unix variants. Qt is also available for embedded devices as Qt for Embedded Linux and Qt for Windows CE.&lt;/p&gt;&lt;p&gt;Qt is available under three different licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of the GNU LGPL version 2.1 or GNU GPL version 3.0.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU LGPL version 2.1 is appropriate for the development of Qt applications (proprietary or open source) provided you can comply with the terms and conditions of the GNU LGPL version 2.1.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU General Public License version 3.0 is appropriate for the development of Qt applications where you wish to use such applications in combination with software subject to the terms of the GNU GPL version 3.0 or where you are otherwise willing to comply with the terms of the GNU GPL version 3.0.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;http://qt.nokia.com/products/licensing&quot;&gt;qt.nokia.com/products/licensing&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) 2012 Nokia Corporation and/or its subsidiary(-ies).&lt;/p&gt;&lt;p&gt;Qt is a Nokia product. See &lt;a href=&quot;http://qt.nokia.com/&quot;&gt;qt.nokia.com&lt;/a&gt; for more information.&lt;/p&gt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Hide Details...</source>
        <translation>Ocultar detalles...</translation>
    </message>
    <message>
        <source>&lt;h3&gt;About Qt&lt;/h3&gt;&lt;p&gt;This program uses Qt version %1.&lt;/p&gt;</source>
        <translation>&lt;h3&gt;Acerca de Qt&lt;/h3&gt;&lt;p&gt;Este programa usa Qt versión %1.&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>QSql</name>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Insertar</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <source>Delete this record?</source>
        <translation>¿Eliminar este registro?</translation>
    </message>
    <message>
        <source>Save edits?</source>
        <translation>¿Guardar ediciones?</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
    <message>
        <source>Cancel your edits?</source>
        <translation>¿Cancelar sus ediciones?</translation>
    </message>
</context>
<context>
    <name>QSoftKeyManager</name>
    <message>
        <source>Ok</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Hecho</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Seleccionar</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
</context>
<context>
    <name>QPrintSettingsOutput</name>
    <message>
        <source>to</source>
        <translation>a</translation>
    </message>
    <message>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <source>Print all</source>
        <translation>Imprimir todo</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Página actual</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Selección</translation>
    </message>
    <message>
        <source>Long side</source>
        <translation>Lado largo</translation>
    </message>
    <message>
        <source>Copies</source>
        <translation>Copias</translation>
    </message>
    <message>
        <source>Print range</source>
        <translation>Rango de impresión</translation>
    </message>
    <message>
        <source>Color Mode</source>
        <translation>Modo de color</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <source>Output Settings</source>
        <translation>Configuración de salida</translation>
    </message>
    <message>
        <source>Reverse</source>
        <translation>Invertir</translation>
    </message>
    <message>
        <source>Grayscale</source>
        <translation>Escala de grises</translation>
    </message>
    <message>
        <source>Short side</source>
        <translation>Lado corto</translation>
    </message>
    <message>
        <source>Collate</source>
        <translation>Intercalar</translation>
    </message>
    <message>
        <source>Copies:</source>
        <translation>Copias:</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Páginas desde</translation>
    </message>
    <message>
        <source>Duplex Printing</source>
        <translation>Impresión a doble cara</translation>
    </message>
</context>
<context>
    <name>QPrintPreviewDialog</name>
    <message>
        <source>%1%</source>
        <translation>%1%</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation>Vista previa de impresión</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>Fit page</source>
        <translation>Ajustar página</translation>
    </message>
    <message>
        <source>Zoom in</source>
        <translation>Acercar</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Paisaje</translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation>Alejar</translation>
    </message>
    <message>
        <source>Fit width</source>
        <translation>Ajustar ancho</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Retrato</translation>
    </message>
    <message>
        <source>Page Setup</source>
        <translation>Configuración de página</translation>
    </message>
    <message>
        <source>Page setup</source>
        <translation>Configuración de página</translation>
    </message>
    <message>
        <source>Show overview of all pages</source>
        <translation>Mostrar vista general de todas las páginas</translation>
    </message>
    <message>
        <source>First page</source>
        <translation>Primera página</translation>
    </message>
    <message>
        <source>Last page</source>
        <translation>Última página</translation>
    </message>
    <message>
        <source>Show single page</source>
        <translation>Mostrar página única</translation>
    </message>
    <message>
        <source>Export to PDF</source>
        <translation>Exportar a PDF</translation>
    </message>
    <message>
        <source>Previous page</source>
        <translation>Página anterior</translation>
    </message>
    <message>
        <source>Next page</source>
        <translation>Página siguiente</translation>
    </message>
    <message>
        <source>Show facing pages</source>
        <translation>Mostrar páginas enfrentadas</translation>
    </message>
    <message>
        <source>Export to PostScript</source>
        <translation>Exportar a PostScript</translation>
    </message>
</context>
<context>
    <name>Q3FileDialog</name>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <source>Dir</source>
        <translation>Dir</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Atrás</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Fecha</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <source>Sort</source>
        <translation>Ordenar</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Abrir</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Guardar</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>Open </source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>Write: %1</source>
        <translation>Escribir: %1</translation>
    </message>
    <message>
        <source>Sort by &amp;Size</source>
        <translation>Ordenar por &amp;tamaño</translation>
    </message>
    <message>
        <source>Sort by &amp;Date</source>
        <translation>Ordenar por &amp;fecha</translation>
    </message>
    <message>
        <source>Sort by &amp;Name</source>
        <translation>Ordenar por &amp;Nombre</translation>
    </message>
    <message>
        <source>New Folder 1</source>
        <translation>Nueva Carpeta 1</translation>
    </message>
    <message>
        <source>the directory</source>
        <translation>el directorio</translation>
    </message>
    <message>
        <source>File &amp;type:</source>
        <translation>Tipo de &amp;archivo:</translation>
    </message>
    <message>
        <source>File &amp;name:</source>
        <translation>Nombre del &amp;archivo:</translation>
    </message>
    <message>
        <source>Delete %1</source>
        <translation>Eliminar %1</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>R&amp;eload</source>
        <translation>R&amp;ecargar</translation>
    </message>
    <message>
        <source>New Folder</source>
        <translation>Nueva carpeta</translation>
    </message>
    <message>
        <source>&amp;Unsorted</source>
        <translation>&amp;Sin ordenar</translation>
    </message>
    <message>
        <source>Look &amp;in:</source>
        <translation>Buscar &amp;en:</translation>
    </message>
    <message>
        <source>Preview File Contents</source>
        <translation>Vista previa del contenido del archivo</translation>
    </message>
    <message>
        <source>New Folder %1</source>
        <translation>Nueva carpeta %1</translation>
    </message>
    <message>
        <source>Read-write</source>
        <translation>Lectura-escritura</translation>
    </message>
    <message>
        <source>Read-only</source>
        <translation>Solo lectura</translation>
    </message>
    <message>
        <source>Copy or Move a File</source>
        <translation>Copiar o Mover un Archivo</translation>
    </message>
    <message>
        <source>&lt;qt&gt;Are you sure you wish to delete %1 &quot;%2&quot;?&lt;/qt&gt;</source>
        <translation>&lt;qt&gt;¿Está seguro de que desea eliminar %1 &quot;%2&quot;?&lt;/qt&gt;</translation>
    </message>
    <message>
        <source>Find Directory</source>
        <translation>Buscar directorio</translation>
    </message>
    <message>
        <source>Attributes</source>
        <translation>Atributos</translation>
    </message>
    <message>
        <source>Show &amp;hidden files</source>
        <translation>Mostrar archivos &amp;ocultos</translation>
    </message>
    <message>
        <source>Save As</source>
        <translation>Guardar como</translation>
    </message>
    <message>
        <source>Inaccessible</source>
        <translation>Inaccesible</translation>
    </message>
    <message>
        <source>%1
File not found.
Check path and filename.</source>
        <translation>%1
Archivo no encontrado.
Verifique la ruta y el nombre del archivo.</translation>
    </message>
    <message>
        <source>List View</source>
        <translation>Vista de lista</translation>
    </message>
    <message>
        <source>Special</source>
        <translation>Especial</translation>
    </message>
    <message>
        <source>Write-only</source>
        <translation>Solo escritura</translation>
    </message>
    <message>
        <source>the symlink</source>
        <translation>el enlace simbólico</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Eliminar</translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation>Todos los archivos (*)</translation>
    </message>
    <message>
        <source>Directories</source>
        <translation>Directorios</translation>
    </message>
    <message>
        <source>Symlink to Special</source>
        <translation>Enlace simbólico a especial</translation>
    </message>
    <message>
        <source>Select a Directory</source>
        <translation>Seleccionar un directorio</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation>Todos los archivos (*.*)</translation>
    </message>
    <message>
        <source>Read: %1</source>
        <translation>Leer: %1</translation>
    </message>
    <message>
        <source>&amp;Rename</source>
        <translation>&amp;Renombrar</translation>
    </message>
    <message>
        <source>Directory:</source>
        <translation>Directorio:</translation>
    </message>
    <message>
        <source>One directory up</source>
        <translation>Un directorio arriba</translation>
    </message>
    <message>
        <source>Preview File Info</source>
        <translation>Vista previa de la info del archivo</translation>
    </message>
    <message>
        <source>the file</source>
        <translation>el archivo</translation>
    </message>
    <message>
        <source>Create New Folder</source>
        <translation>Crear nueva carpeta</translation>
    </message>
    <message>
        <source>Symlink to File</source>
        <translation>Enlace simbólico al archivo</translation>
    </message>
    <message>
        <source>Symlink to Directory</source>
        <translation>Enlace simbólico al directorio</translation>
    </message>
    <message>
        <source>Detail View</source>
        <translation>Vista detallada</translation>
    </message>
</context>
<context>
    <name>QErrorMessage</name>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Fatal Error:</source>
        <translation>Error fatal:</translation>
    </message>
    <message>
        <source>&amp;Show this message again</source>
        <translation>&amp;Mostrar este mensaje de nuevo</translation>
    </message>
    <message>
        <source>Debug Message:</source>
        <translation>Mensaje de depuración:</translation>
    </message>
    <message>
        <source>Warning:</source>
        <translation>Advertencia:</translation>
    </message>
</context>
<context>
    <name>QPrintWidget</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <source>&amp;Name:</source>
        <translation>&amp;Nombre:</translation>
    </message>
    <message>
        <source>Output &amp;file:</source>
        <translation>Archivo de salida:</translation>
    </message>
    <message>
        <source>P&amp;roperties</source>
        <translation>Propiedades</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Vista previa</translation>
    </message>
    <message>
        <source>Printer</source>
        <translation>Impresora</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Ubicación:</translation>
    </message>
</context>
<context>
    <name>QFontDatabase</name>
    <message>
        <source>Any</source>
        <translation>Cualquiera</translation>
    </message>
    <message>
        <source>Lao</source>
        <translation>Lao</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation>Negrita</translation>
    </message>
    <message>
        <source>N&apos;Ko</source>
        <translation>N&apos;Ko</translation>
    </message>
    <message>
        <source>Thai</source>
        <translation>Tailandés</translation>
    </message>
    <message>
        <source>Black</source>
        <translation>Negro</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Griego</translation>
    </message>
    <message>
        <source>Khmer</source>
        <translation>Khmer</translation>
    </message>
    <message>
        <source>Latin</source>
        <translation>Latín</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Ligero</translation>
    </message>
    <message>
        <source>Ogham</source>
        <translation>Ogham</translation>
    </message>
    <message>
        <source>Oriya</source>
        <translation>Oriya</translation>
    </message>
    <message>
        <source>Runic</source>
        <translation>Rúnico</translation>
    </message>
    <message>
        <source>Tamil</source>
        <translation>Tamil</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Cirílico</translation>
    </message>
    <message>
        <source>Kannada</source>
        <translation>Canarés</translation>
    </message>
    <message>
        <source>Malayalam</source>
        <translation>Malayalam</translation>
    </message>
    <message>
        <source>Simplified Chinese</source>
        <translation>Chino simplificado</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Árabe</translation>
    </message>
    <message>
        <source>Hebrew</source>
        <translation>Hebreo</translation>
    </message>
    <message>
        <source>Myanmar</source>
        <translation>Myanmar</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation>Cursiva</translation>
    </message>
    <message>
        <source>Korean</source>
        <translation>Coreano</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>Oblicuo</translation>
    </message>
    <message>
        <source>Telugu</source>
        <translation>Télugu</translation>
    </message>
    <message>
        <source>Thaana</source>
        <translation>Thaana</translation>
    </message>
    <message>
        <source>Symbol</source>
        <translation>Símbolo</translation>
    </message>
    <message>
        <source>Syriac</source>
        <translation>Siríaco</translation>
    </message>
    <message>
        <source>Devanagari</source>
        <translation>Devanagari</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonés</translation>
    </message>
    <message>
        <source>Bengali</source>
        <translation>Bengalí</translation>
    </message>
    <message>
        <source>Armenian</source>
        <translation>Armenio</translation>
    </message>
    <message>
        <source>Sinhala</source>
        <translation>Cingalés</translation>
    </message>
    <message>
        <source>Tibetan</source>
        <translation>Tibetano</translation>
    </message>
    <message>
        <source>Vietnamese</source>
        <translation>Vietnamita</translation>
    </message>
    <message>
        <source>Gujarati</source>
        <translation>Gujarati</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Chino tradicional</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgiano</translation>
    </message>
    <message>
        <source>Gurmukhi</source>
        <translation>Gurmukhi</translation>
    </message>
</context>
<context>
    <name>QInputContext</name>
    <message>
        <source>FEP</source>
        <translation>FEP</translation>
    </message>
    <message>
        <source>XIM</source>
        <translation>XIM</translation>
    </message>
    <message>
        <source>Windows input method</source>
        <translation>Método de entrada de Windows</translation>
    </message>
    <message>
        <source>XIM input method</source>
        <translation>Método de entrada XIM</translation>
    </message>
    <message>
        <source>Mac OS X input method</source>
        <translation>Método de entrada de Mac OS X</translation>
    </message>
    <message>
        <source>S60 FEP input method</source>
        <translation>Método de entrada FEP S60</translation>
    </message>
</context>
<context>
    <name>QWebPage</name>
    <message>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Superior</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation>Negrita</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Detener</translation>
    </message>
    <message>
        <source>Align Right</source>
        <translation>Alinear a la derecha</translation>
    </message>
    <message>
        <source>Insert a new paragraph</source>
        <translation>Insertar un nuevo párrafo</translation>
    </message>
    <message>
        <source>Strikethrough</source>
        <translation>Tachado</translation>
    </message>
    <message>
        <source>Open Frame</source>
        <translation>Abrir marco</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Abrir Imagen</translation>
    </message>
    <message>
        <source>Fonts</source>
        <translation>Fuentes</translation>
    </message>
    <message>
        <source>Movie time scrubber thumb</source>
        <translation>Control deslizante de tiempo de película</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Pegar</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Restablecer</translation>
    </message>
    <message>
        <source>Inspect</source>
        <translation>Inspeccionar</translation>
    </message>
    <message>
        <source>Select to the start of the block</source>
        <translation>Seleccionar hasta el inicio del bloque</translation>
    </message>
    <message>
        <source>Indefinite time</source>
        <translation>Tiempo indefinido</translation>
    </message>
    <message>
        <source>Move the cursor to the end of the block</source>
        <translation>Mover el cursor al final del bloque</translation>
    </message>
    <message>
        <source>Select to the start of the line</source>
        <translation>Seleccionar hasta el inicio de la línea</translation>
    </message>
    <message>
        <source>Look Up In Dictionary</source>
        <translation>Buscar en el diccionario</translation>
    </message>
    <message>
        <source>Mute audio tracks</source>
        <translation>Silenciar pistas de audio</translation>
    </message>
    <message>
        <source>Search The Web</source>
        <translation>Buscar en la web</translation>
    </message>
    <message>
        <source>Status Display</source>
        <translation>Visualización del estado</translation>
    </message>
    <message>
        <source>Check Spelling While Typing</source>
        <translation>Verificar Ortografía Mientras Escribes</translation>
    </message>
    <message>
        <source>Add To Dictionary</source>
        <translation>Agregar al diccionario</translation>
    </message>
    <message>
        <source>Justify</source>
        <translation>Justificar</translation>
    </message>
    <message>
        <source>Pause Button</source>
        <translation>Botón de Pausa</translation>
    </message>
    <message>
        <source>Slider Thumb</source>
        <translation>Control deslizante</translation>
    </message>
    <message>
        <source>Delete to the start of the word</source>
        <translation>Eliminar hasta el inicio de la palabra</translation>
    </message>
    <message>
        <source>Recent searches</source>
        <translation>Búsquedas recientes</translation>
    </message>
    <message>
        <source>Move the cursor to the next word</source>
        <translation>Mover el cursor a la siguiente palabra</translation>
    </message>
    <message>
        <source>Move the cursor to the next line</source>
        <translation>Mover el cursor a la siguiente línea</translation>
    </message>
    <message>
        <source>JavaScript Alert - %1</source>
        <translation>Alerta de JavaScript - %1</translation>
    </message>
    <message>
        <source>%1 minutes %2 seconds</source>
        <translation>%1 minutos %2 segundos</translation>
    </message>
    <message>
        <source>Scroll down</source>
        <translation>Desplazar hacia abajo</translation>
    </message>
    <message>
        <source>Scroll here</source>
        <translation>Desplazar aquí</translation>
    </message>
    <message>
        <source>Scroll left</source>
        <translation>Desplazar a la izquierda</translation>
    </message>
    <message>
        <source>Left to Right</source>
        <translation>De Izquierda a Derecha</translation>
    </message>
    <message>
        <source>Move the cursor to the start of the block</source>
        <translation>Mover el cursor al inicio del bloque</translation>
    </message>
    <message>
        <source>Right to Left</source>
        <translation>De derecha a izquierda</translation>
    </message>
    <message>
        <source>Rewind movie</source>
        <translation>Rebobinar película</translation>
    </message>
    <message>
        <source>Movie time scrubber</source>
        <translation>Barra de desplazamiento de tiempo de película</translation>
    </message>
    <message>
        <source>Text Direction</source>
        <translation>Dirección del texto</translation>
    </message>
    <message>
        <source>Play movie in full-screen mode</source>
        <translation>Reproducir película en modo de pantalla completa</translation>
    </message>
    <message>
        <source>Seek quickly back</source>
        <translation>Retroceder rápidamente</translation>
    </message>
    <message>
        <source>Audio Element</source>
        <translation>Elemento de audio</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Fondo</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Centrar</translation>
    </message>
    <message>
        <source>Mute Button</source>
        <translation>Botón de Silencio</translation>
    </message>
    <message>
        <source>Play Button</source>
        <translation>Botón de reproducción</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Ignorar</translation>
    </message>
    <message>
        <source>Indent</source>
        <translation>Aumentar sangría</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation>Cursiva</translation>
    </message>
    <message>
        <source>Move the cursor to the end of the line</source>
        <translation>Mover el cursor al final de la línea</translation>
    </message>
    <message>
        <source>Move the cursor to the start of the line</source>
        <translation>Mover el cursor al inicio de la línea</translation>
    </message>
    <message>
        <source>Return streaming movie to real-time</source>
        <translation>Devolver la película en streaming al tiempo real</translation>
    </message>
    <message>
        <source>The script on this page appears to have a problem. Do you want to stop the script?</source>
        <translation>El script en esta página parece tener un problema. ¿Desea detener el script?</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Recargar</translation>
    </message>
    <message>
        <source>JavaScript Confirm - %1</source>
        <translation>Confirmación de JavaScript - %1</translation>
    </message>
    <message>
        <source>Insert a new line</source>
        <translation>Insertar una nueva línea</translation>
    </message>
    <message>
        <source>Slider</source>
        <translation>Deslizador</translation>
    </message>
    <message>
        <source>Submit</source>
        <translation>Enviar</translation>
    </message>
    <message>
        <source>Live Broadcast</source>
        <translation>Transmisión en Vivo</translation>
    </message>
    <message>
        <source>Web Inspector - %2</source>
        <translation>Inspector Web - %2</translation>
    </message>
    <message>
        <source>Page up</source>
        <translation>Página arriba</translation>
    </message>
    <message>
        <source>Paste and Match Style</source>
        <translation>Pegar y Coincidir Estilo</translation>
    </message>
    <message>
        <source>Spelling</source>
        <translation>Ortografía</translation>
    </message>
    <message>
        <source>Outdent</source>
        <translation>Disminuir sangría</translation>
    </message>
    <message>
        <source>Outline</source>
        <translation>Contorno</translation>
    </message>
    <message>
        <source>Check Grammar With Spelling</source>
        <translation>Revisar gramática con ortografía</translation>
    </message>
    <message>
        <source>No file selected</source>
        <translation>No se ha seleccionado archivo</translation>
    </message>
    <message>
        <source>Ignore</source>
        <comment>Ignore Grammar context menu item</comment>
        <translation>Ignorar</translation>
    </message>
    <message>
        <source>Save Image</source>
        <translation>Guardar Imagen</translation>
    </message>
    <message>
        <source>Insert Bulleted List</source>
        <translation>Insertar lista con viñetas</translation>
    </message>
    <message>
        <source>JavaScript Problem - %1</source>
        <translation>Problema de JavaScript - %1</translation>
    </message>
    <message>
        <source>Save Link...</source>
        <translation>Guardar enlace...</translation>
    </message>
    <message>
        <source>No recent searches</source>
        <translation>No hay búsquedas recientes</translation>
    </message>
    <message>
        <source>Page right</source>
        <translation>Página derecha</translation>
    </message>
    <message>
        <source>Move the cursor to the start of the document</source>
        <translation>Mover el cursor al inicio del documento</translation>
    </message>
    <message>
        <source>Move the cursor to the next character</source>
        <translation>Mover el cursor al siguiente carácter</translation>
    </message>
    <message>
        <source>JavaScript Prompt - %1</source>
        <translation>Solicitud de JavaScript - %1</translation>
    </message>
    <message>
        <source>Copy Link</source>
        <translation>Copiar enlace</translation>
    </message>
    <message>
        <source>Remaining movie time</source>
        <translation>Tiempo restante de la película</translation>
    </message>
    <message>
        <source>Select to the previous line</source>
        <translation>Seleccionar hasta la línea anterior</translation>
    </message>
    <message>
        <source>Select to the previous word</source>
        <translation>Seleccionar hasta la palabra anterior</translation>
    </message>
    <message>
        <source>Check Spelling</source>
        <translation>Revisar ortografía</translation>
    </message>
    <message>
        <source>Redirection limit reached</source>
        <translation>Límite de redirección alcanzado</translation>
    </message>
    <message>
        <source>Select to the next character</source>
        <translation>Seleccionar hasta el siguiente carácter</translation>
    </message>
    <message>
        <source>Remaining Time</source>
        <translation>Tiempo restante</translation>
    </message>
    <message>
        <source>Show Spelling and Grammar</source>
        <translation>Mostrar ortografía y gramática</translation>
    </message>
    <message>
        <source>Delete to the end of the word</source>
        <translation>Eliminar hasta el final de la palabra</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>Dirección</translation>
    </message>
    <message>
        <source>Select to the end of the line</source>
        <translation>Seleccionar hasta el final de la línea</translation>
    </message>
    <message>
        <source>Submit</source>
        <comment>Submit (input element) alt text for &lt;input&gt; elements with no alt, title, or value</comment>
        <translation>Enviar</translation>
    </message>
    <message>
        <source>Unmute Button</source>
        <translation>Botón de Activar Sonido</translation>
    </message>
    <message>
        <source>Video Element</source>
        <translation>Elemento de video</translation>
    </message>
    <message>
        <source>Choose File</source>
        <translation>Elegir Archivo</translation>
    </message>
    <message>
        <source>Seek quickly forward</source>
        <translation>Avanzar rápidamente</translation>
    </message>
    <message>
        <source>Scroll up</source>
        <translation>Desplazar hacia arriba</translation>
    </message>
    <message>
        <source>Begin playback</source>
        <translation>Iniciar reproducción</translation>
    </message>
    <message>
        <source>Subscript</source>
        <translation>Subíndice</translation>
    </message>
    <message>
        <source>%1 days %2 hours %3 minutes %4 seconds</source>
        <translation>%1 días %2 horas %3 minutos %4 segundos</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <translation>%1 segundos</translation>
    </message>
    <message>
        <source>Superscript</source>
        <translation>Superíndice</translation>
    </message>
    <message>
        <source>Clear recent searches</source>
        <translation>Borrar búsquedas recientes</translation>
    </message>
    <message>
        <source>Seek Back Button</source>
        <translation>Botón de retroceso</translation>
    </message>
    <message>
        <source>Pause playback</source>
        <translation>Pausar reproducción</translation>
    </message>
    <message>
        <source>Select to the start of the document</source>
        <translation>Seleccionar hasta el inicio del documento</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Predeterminado</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation>Subrayar</translation>
    </message>
    <message>
        <source>Loading...</source>
        <translation>Cargando...</translation>
    </message>
    <message>
        <source>Move the cursor to the previous character</source>
        <translation>Mover el cursor al carácter anterior</translation>
    </message>
    <message>
        <source>Copy Image</source>
        <translation>Copiar imagen</translation>
    </message>
    <message>
        <source>Insert Numbered List</source>
        <translation>Insertar lista numerada</translation>
    </message>
    <message>
        <source>Audio element playback controls and status display</source>
        <translation>Controles de reproducción del elemento de audio y visualización del estado</translation>
    </message>
    <message>
        <source>Select to the end of the document</source>
        <translation>Seleccionar hasta el final del documento</translation>
    </message>
    <message>
        <source>Select to the end of the block</source>
        <translation>Seleccionar hasta el final del bloque</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Seleccionar todo</translation>
    </message>
    <message>
        <source>Seek Forward Button</source>
        <translation>Botón de avance rápido</translation>
    </message>
    <message>
        <source>Scroll right</source>
        <translation>Desplazar a la derecha</translation>
    </message>
    <message>
        <source>No Guesses Found</source>
        <translation>No se encontraron conjeturas</translation>
    </message>
    <message>
        <source>Open Link</source>
        <translation>Abrir Enlace</translation>
    </message>
    <message>
        <source>Current movie status</source>
        <translation>Estado actual de la película</translation>
    </message>
    <message>
        <source>Bad HTTP request</source>
        <translation>Solicitud HTTP incorrecta</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <source>Rewind Button</source>
        <translation>Botón de rebobinado</translation>
    </message>
    <message>
        <source>%1 hours %2 minutes %3 seconds</source>
        <translation>%1 horas %2 minutos %3 segundos</translation>
    </message>
    <message>
        <source>Move the cursor to the previous word</source>
        <translation>Mover el cursor a la palabra anterior</translation>
    </message>
    <message>
        <source>Move the cursor to the previous line</source>
        <translation>Mover el cursor a la línea anterior</translation>
    </message>
    <message numerus="yes">
        <source>%n file(s)</source>
        <translation>
            <numerusform>%n datoteka</numerusform>
        </translation>
    </message>
    <message>
        <source>Left edge</source>
        <translation>Borde izquierdo</translation>
    </message>
    <message>
        <source>Unmute audio tracks</source>
        <translation>Activar sonido de las pistas de audio</translation>
    </message>
    <message>
        <source>Go Forward</source>
        <translation>Ir adelante</translation>
    </message>
    <message>
        <source>Page down</source>
        <translation>Página abajo</translation>
    </message>
    <message>
        <source>Page left</source>
        <translation>Página izquierda</translation>
    </message>
    <message>
        <source>Fullscreen Button</source>
        <translation>Botón de Pantalla Completa</translation>
    </message>
    <message>
        <source>Missing Plug-in</source>
        <translation>Complemento Faltante</translation>
    </message>
    <message>
        <source>This is a searchable index. Enter search keywords: </source>
        <translation>Este es un índice buscable. Ingrese palabras clave de búsqueda: </translation>
    </message>
    <message>
        <source>Align Left</source>
        <translation>Alinear a la izquierda</translation>
    </message>
    <message>
        <source>Select to the previous character</source>
        <translation>Seleccionar hasta el carácter anterior</translation>
    </message>
    <message>
        <source>Go Back</source>
        <translation>Regresar</translation>
    </message>
    <message>
        <source>Return to Real-time Button</source>
        <translation>Botón de retorno al tiempo real</translation>
    </message>
    <message>
        <source>Current movie time</source>
        <translation>Tiempo actual de la película</translation>
    </message>
    <message>
        <source>Open in New Window</source>
        <translation>Abrir en Nueva Ventana</translation>
    </message>
    <message>
        <source>Right edge</source>
        <translation>Borde derecho</translation>
    </message>
    <message>
        <source>Move the cursor to the end of the document</source>
        <translation>Mover el cursor al final del documento</translation>
    </message>
    <message>
        <source>Video element playback controls and status display</source>
        <translation>Controles de reproducción del elemento de video y visualización del estado</translation>
    </message>
    <message>
        <source>Remove formatting</source>
        <translation>Eliminar formato</translation>
    </message>
    <message>
        <source>Elapsed Time</source>
        <translation>Tiempo transcurrido</translation>
    </message>
    <message>
        <source>Hide Spelling and Grammar</source>
        <translation>Ocultar Ortografía y Gramática</translation>
    </message>
    <message>
        <source>%1 (%2x%3 pixels)</source>
        <translation>%1 (%2x%3 píxeles)</translation>
    </message>
    <message>
        <source>Select to the next word</source>
        <translation>Seleccionar hasta la siguiente palabra</translation>
    </message>
    <message>
        <source>Select to the next line</source>
        <translation>Seleccionar hasta la siguiente línea</translation>
    </message>
</context>
<context>
    <name>QScriptBreakpointsWidget</name>
    <message>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
</context>
<context>
    <name>QScrollBar</name>
    <message>
        <source>Top</source>
        <translation>Superior</translation>
    </message>
    <message>
        <source>Scroll down</source>
        <translation>Desplazar hacia abajo</translation>
    </message>
    <message>
        <source>Scroll here</source>
        <translation>Desplazar aquí</translation>
    </message>
    <message>
        <source>Scroll left</source>
        <translation>Desplazar a la izquierda</translation>
    </message>
    <message>
        <source>Line up</source>
        <translation>Línea arriba</translation>
    </message>
    <message>
        <source>Line down</source>
        <translation>Línea abajo</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Fondo</translation>
    </message>
    <message>
        <source>Page up</source>
        <translation>Página arriba</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <source>Page right</source>
        <translation>Página derecha</translation>
    </message>
    <message>
        <source>Scroll up</source>
        <translation>Desplazar hacia arriba</translation>
    </message>
    <message>
        <source>Scroll right</source>
        <translation>Desplazar a la derecha</translation>
    </message>
    <message>
        <source>Left edge</source>
        <translation>Borde izquierdo</translation>
    </message>
    <message>
        <source>Page down</source>
        <translation>Página abajo</translation>
    </message>
    <message>
        <source>Page left</source>
        <translation>Página izquierda</translation>
    </message>
    <message>
        <source>Right edge</source>
        <translation>Borde derecho</translation>
    </message>
</context>
<context>
    <name>QFile</name>
    <message>
        <source>Cannot remove source file</source>
        <translation>No se puede eliminar el archivo fuente</translation>
    </message>
    <message>
        <source>Cannot create %1 for output</source>
        <translation>No se puede crear %1 para salida</translation>
    </message>
    <message>
        <source>Failure to write block</source>
        <translation>Fallo al escribir bloque</translation>
    </message>
    <message>
        <source>Cannot open %1 for input</source>
        <translation>No se puede abrir %1 para entrada</translation>
    </message>
    <message>
        <source>Destination file exists</source>
        <translation>El archivo de destino ya existe</translation>
    </message>
    <message>
        <source>Cannot open for output</source>
        <translation>No se puede abrir para salida</translation>
    </message>
    <message>
        <source>Will not rename sequential file using block copy</source>
        <translation>No se renombrará el archivo secuencial usando copia de bloque</translation>
    </message>
</context>
<context>
    <name>QFileDialog</name>
    <message>
        <source>Back</source>
        <translation>Atrás</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Abrir</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Guardar</translation>
    </message>
    <message>
        <source>Alias</source>
        <translation>Alias</translation>
    </message>
    <message>
        <source>Drive</source>
        <translation>Unidad</translation>
    </message>
    <message>
        <source>Show </source>
        <translation>Mostrar </translation>
    </message>
    <message>
        <source>&apos;%1&apos; is write protected.
Do you want to delete it anyway?</source>
        <translation>&apos;%1&apos; está protegido contra escritura.
¿Desea eliminarlo de todos modos?</translation>
    </message>
    <message>
        <source>File &amp;name:</source>
        <translation>Nombre del &amp;archivo:</translation>
    </message>
    <message>
        <source>File Folder</source>
        <translation>Carpeta de archivos</translation>
    </message>
    <message>
        <source>New Folder</source>
        <translation>Nueva carpeta</translation>
    </message>
    <message>
        <source>Folder</source>
        <translation>Carpeta</translation>
    </message>
    <message>
        <source>Parent Directory</source>
        <translation>Directorio principal</translation>
    </message>
    <message>
        <source>&amp;New Folder</source>
        <translation>&amp;Nueva carpeta</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>My Computer</source>
        <translation>Mi PC</translation>
    </message>
    <message>
        <source>Look in:</source>
        <translation>Buscar en:</translation>
    </message>
    <message>
        <source>Create a New Folder</source>
        <translation>Crear una nueva carpeta</translation>
    </message>
    <message>
        <source>Files of type:</source>
        <translation>Archivos de tipo:</translation>
    </message>
    <message>
        <source>Find Directory</source>
        <translation>Buscar directorio</translation>
    </message>
    <message>
        <source>Show &amp;hidden files</source>
        <translation>Mostrar archivos &amp;ocultos</translation>
    </message>
    <message>
        <source>Are sure you want to delete &apos;%1&apos;?</source>
        <translation>¿Está seguro de que desea eliminar &apos;%1&apos;?</translation>
    </message>
    <message>
        <source>Save As</source>
        <translation>Guardar como</translation>
    </message>
    <message>
        <source>%1
Directory not found.
Please verify the correct directory name was given.</source>
        <translation>%1
Directorio no encontrado.
Por favor verifique que se haya proporcionado el nombre correcto del directorio.</translation>
    </message>
    <message>
        <source>List View</source>
        <translation>Vista de lista</translation>
    </message>
    <message>
        <source>&amp;Choose</source>
        <translation>&amp;Seleccionar</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Eliminar</translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation>Todos los archivos (*)</translation>
    </message>
    <message>
        <source>Directories</source>
        <translation>Directorios</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation>Todos los archivos (*.*)</translation>
    </message>
    <message>
        <source>&amp;Rename</source>
        <translation>&amp;Renombrar</translation>
    </message>
    <message>
        <source>Could not delete directory.</source>
        <translation>No se pudo eliminar el directorio.</translation>
    </message>
    <message>
        <source>Directory:</source>
        <translation>Directorio:</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>%1 ya existe.
¿Desea reemplazarlo?</translation>
    </message>
    <message>
        <source>Forward</source>
        <translation>Adelante</translation>
    </message>
    <message>
        <source>Go forward</source>
        <translation>Ir adelante</translation>
    </message>
    <message>
        <source>Go to the parent directory</source>
        <translation>Ir al directorio padre</translation>
    </message>
    <message>
        <source>Recent Places</source>
        <translation>Lugares recientes</translation>
    </message>
    <message>
        <source>Go back</source>
        <translation>Regresar</translation>
    </message>
    <message>
        <source>Change to detail view mode</source>
        <translation>Cambiar a modo de vista detallada</translation>
    </message>
    <message>
        <source>Create New Folder</source>
        <translation>Crear nueva carpeta</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Acceso directo</translation>
    </message>
    <message>
        <source>Detail View</source>
        <translation>Vista detallada</translation>
    </message>
    <message>
        <source>%1
File not found.
Please verify the correct file name was given.</source>
        <translation>%1
Archivo no encontrado.
Por favor verifique que se proporcionó el nombre de archivo correcto.</translation>
    </message>
    <message>
        <source>Change to list view mode</source>
        <translation>Cambiar a modo de vista de lista</translation>
    </message>
</context>
<context>
    <name>Q3TextEdit</name>
    <message>
        <source>Cu&amp;t</source>
        <translation>Cor&amp;tar</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Rehacer</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Deshacer</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Limpiar</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Pegar</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Seleccionar todo</translation>
    </message>
</context>
<context>
    <name>QLineEdit</name>
    <message>
        <source>Cu&amp;t</source>
        <translation>Cor&amp;tar</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Rehacer</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Deshacer</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Pegar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Seleccionar todo</translation>
    </message>
</context>
<context>
    <name>QTextControl</name>
    <message>
        <source>Cu&amp;t</source>
        <translation>Cor&amp;tar</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Rehacer</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Deshacer</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Pegar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Seleccionar todo</translation>
    </message>
    <message>
        <source>Copy &amp;Link Location</source>
        <translation>Copiar ubicación del &amp;enlace</translation>
    </message>
</context>
<context>
    <name>QDockWidget</name>
    <message>
        <source>Dock</source>
        <translation>Acoplar</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Float</source>
        <translation>Flotar</translation>
    </message>
</context>
<context>
    <name>QDialog</name>
    <message>
        <source>Done</source>
        <translation>Hecho</translation>
    </message>
    <message>
        <source>What&apos;s This?</source>
        <translation>¿Qué es esto?</translation>
    </message>
</context>
<context>
    <name>QWizard</name>
    <message>
        <source>Done</source>
        <translation>Hecho</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ayuda</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Siguiente</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Commit</source>
        <translation>Confirmar</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Continuar</translation>
    </message>
    <message>
        <source>&amp;Finish</source>
        <translation>&amp;Finalizar</translation>
    </message>
    <message>
        <source>&amp;Next &gt;</source>
        <translation>&amp;Siguiente &gt;</translation>
    </message>
    <message>
        <source>Go Back</source>
        <translation>Regresar</translation>
    </message>
    <message>
        <source>&lt; &amp;Back</source>
        <translation>&lt; &amp;Atrás</translation>
    </message>
</context>
<context>
    <name>QPageSetupWidget</name>
    <message>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <source>bottom margin</source>
        <translation>margen inferior</translation>
    </message>
    <message>
        <source>Paper</source>
        <translation>Papel</translation>
    </message>
    <message>
        <source>Paper source:</source>
        <translation>Fuente de papel:</translation>
    </message>
    <message>
        <source>Centimeters (cm)</source>
        <translation>Centímetros (cm)</translation>
    </message>
    <message>
        <source>right margin</source>
        <translation>margen derecho</translation>
    </message>
    <message>
        <source>Margins</source>
        <translation>Márgenes</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Paisaje</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Ancho:</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation>Orientación</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Retrato</translation>
    </message>
    <message>
        <source>top margin</source>
        <translation>margen superior</translation>
    </message>
    <message>
        <source>left margin</source>
        <translation>margen izquierdo</translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation>Tamaño de página:</translation>
    </message>
    <message>
        <source>Reverse portrait</source>
        <translation>Retrato inverso</translation>
    </message>
    <message>
        <source>Millimeters (mm)</source>
        <translation>Milímetros (mm)</translation>
    </message>
    <message>
        <source>Points (pt)</source>
        <translation>Puntos (pt)</translation>
    </message>
    <message>
        <source>Inches (in)</source>
        <translation>Pulgadas (in)</translation>
    </message>
    <message>
        <source>Reverse landscape</source>
        <translation>Paisaje inverso</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Altura:</translation>
    </message>
</context>
<context>
    <name>QPrintPropertiesWidget</name>
    <message>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
</context>
<context>
    <name>QMdiSubWindow</name>
    <message>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>Menú</translation>
    </message>
    <message>
        <source>&amp;Move</source>
        <translation>&amp;Mover</translation>
    </message>
    <message>
        <source>&amp;Size</source>
        <translation>&amp;Size</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Minimizar</translation>
    </message>
    <message>
        <source>Shade</source>
        <translation>Sombrear</translation>
    </message>
    <message>
        <source>Stay on &amp;Top</source>
        <translation>Mantener en &amp;Superior</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <source>- [%1]</source>
        <translation>- [%1]</translation>
    </message>
    <message>
        <source>%1 - [%2]</source>
        <translation>%1 - [%2]</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Restaurar</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Restaurar</translation>
    </message>
    <message>
        <source>Maximize</source>
        <translation>Maximizar</translation>
    </message>
    <message>
        <source>Unshade</source>
        <translation>Desombrecer</translation>
    </message>
    <message>
        <source>Mi&amp;nimize</source>
        <translation>Mi&amp;nimizar</translation>
    </message>
    <message>
        <source>Ma&amp;ximize</source>
        <translation>Ma&amp;ximizar</translation>
    </message>
    <message>
        <source>Restore Down</source>
        <translation>Restaurar abajo</translation>
    </message>
</context>
<context>
    <name>QDirModel</name>
    <message>
        <source>Kind</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Date Modified</source>
        <translation>Fecha de Modificación</translation>
    </message>
</context>
<context>
    <name>QFileSystemModel</name>
    <message>
        <source>Kind</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 TB</source>
        <translation>%1 TB</translation>
    </message>
    <message>
        <source>&lt;b&gt;The name &quot;%1&quot; can not be used.&lt;/b&gt;&lt;p&gt;Try using another name, with fewer characters or no punctuations marks.</source>
        <translation>&lt;b&gt;Intente usar otro nombre, con menos caracteres o sin signos de puntuación.</translation>
    </message>
    <message>
        <source>%1 bytes</source>
        <translation>%1 bytes</translation>
    </message>
    <message>
        <source>My Computer</source>
        <translation>Mi PC</translation>
    </message>
    <message>
        <source>Computer</source>
        <translation>Computadora</translation>
    </message>
    <message>
        <source>Invalid filename</source>
        <translation>Nombre de archivo no válido</translation>
    </message>
    <message>
        <source>%1 byte(s)</source>
        <translation>%1 byte(s)</translation>
    </message>
    <message>
        <source>Date Modified</source>
        <translation>Fecha de Modificación</translation>
    </message>
</context>
<context>
    <name>QDoubleSpinBox</name>
    <message>
        <source>Less</source>
        <translation>Menos</translation>
    </message>
    <message>
        <source>More</source>
        <translation>Más</translation>
    </message>
</context>
<context>
    <name>QSpinBox</name>
    <message>
        <source>Less</source>
        <translation>Menos</translation>
    </message>
    <message>
        <source>More</source>
        <translation>Más</translation>
    </message>
</context>
<context>
    <name>QPPDOptionsModel</name>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
</context>
<context>
    <name>QScriptDebuggerLocalsModel</name>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
</context>
<context>
    <name>QScriptDebuggerStackModel</name>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Level</source>
        <translation>Nivel</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Ubicación</translation>
    </message>
</context>
<context>
    <name>QScriptDebuggerCodeFinderWidget</name>
    <message>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Whole words</source>
        <translation>Palabras completas</translation>
    </message>
    <message>
        <source>Previous</source>
        <translation>Anterior</translation>
    </message>
    <message>
        <source>&lt;img src=&quot;:/qt/scripttools/debugging/images/wrap.png&quot;&gt;&amp;nbsp;Search wrapped</source>
        <translation>&lt;img src=&quot;:/qt/scripttools/debugging/images/wrap.png&quot;&gt;&amp;nbsp;Búsqueda reiniciada</translation>
    </message>
    <message>
        <source>Case Sensitive</source>
        <translation>Distingue mayúsculas y minúsculas</translation>
    </message>
</context>
<context>
    <name>QComboBox</name>
    <message>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Verdadero</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Falso</translation>
    </message>
</context>
<context>
    <name>QMenu</name>
    <message>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Execute</source>
        <translation>Ejecutar</translation>
    </message>
</context>
<context>
    <name>QPushButton</name>
    <message>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
</context>
<context>
    <name>QToolButton</name>
    <message>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>Press</source>
        <translation>Presionar</translation>
    </message>
</context>
<context>
    <name>QUndoGroup</name>
    <message>
        <source>Redo</source>
        <translation>Rehacer</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Deshacer</translation>
    </message>
</context>
<context>
    <name>QUndoStack</name>
    <message>
        <source>Redo</source>
        <translation>Rehacer</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Deshacer</translation>
    </message>
</context>
<context>
    <name>Q3DataTable</name>
    <message>
        <source>True</source>
        <translation>Verdadero</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Falso</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Insertar</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
</context>
<context>
    <name>QScriptEngineDebugger</name>
    <message>
        <source>View</source>
        <translation>Ver</translation>
    </message>
    <message>
        <source>Stack</source>
        <translation>Pila</translation>
    </message>
    <message>
        <source>Debug Output</source>
        <translation>Salida de depuración</translation>
    </message>
    <message>
        <source>Breakpoints</source>
        <translation>Puntos de interrupción</translation>
    </message>
    <message>
        <source>Qt Script Debugger</source>
        <translation>Depurador de scripts de Qt</translation>
    </message>
    <message>
        <source>Locals</source>
        <translation>Locales</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Error Log</source>
        <translation>Registro de errores</translation>
    </message>
    <message>
        <source>Console</source>
        <translation>Consola</translation>
    </message>
    <message>
        <source>Loaded Scripts</source>
        <translation>Scripts cargados</translation>
    </message>
</context>
<context>
    <name>QDeclarativeCompiler</name>
    <message>
        <source>Attached properties cannot be used here</source>
        <translation>Las propiedades adjuntas no se pueden usar aquí</translation>
    </message>
    <message>
        <source>Invalid property assignment: rect expected</source>
        <translation>Asignación de propiedad no válida: se esperaba rect</translation>
    </message>
    <message>
        <source>Invalid attached object assignment</source>
        <translation>Asignación de objeto adjunto inválida</translation>
    </message>
    <message>
        <source>Component elements may not contain properties other than id</source>
        <translation>Los elementos del componente no pueden contener propiedades distintas de id</translation>
    </message>
    <message>
        <source>Invalid grouped property access</source>
        <translation>Acceso a propiedad agrupada no válido</translation>
    </message>
    <message>
        <source>Invalid property type</source>
        <translation>Tipo de propiedad no válido</translation>
    </message>
    <message>
        <source>Cannot override FINAL property</source>
        <translation>No se puede sobrescribir la propiedad FINAL</translation>
    </message>
    <message>
        <source>Invalid property assignment: size expected</source>
        <translation>Asignación de propiedad inválida: se esperaba tamaño</translation>
    </message>
    <message>
        <source>Cannot assign object to list</source>
        <translation>No se puede asignar un objeto a la lista</translation>
    </message>
    <message>
        <source>Invalid property assignment: string expected</source>
        <translation>Asignación de propiedad no válida: se esperaba cadena</translation>
    </message>
    <message>
        <source>Cannot assign a value to a signal (expecting a script to be run)</source>
        <translation>No se puede asignar un valor a una señal (se espera que se ejecute un script)</translation>
    </message>
    <message>
        <source>Invalid property assignment: unknown enumeration</source>
        <translation>Asignación de propiedad no válida: enumeración desconocida</translation>
    </message>
    <message>
        <source>Invalid property assignment: unsupported type &quot;%1&quot;</source>
        <translation>Asignación de propiedad no válida: tipo no soportado &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Invalid property assignment: datetime expected</source>
        <translation>Asignación de propiedad inválida: se esperaba fecha y hora</translation>
    </message>
    <message>
        <source>Invalid property assignment: 3D vector expected</source>
        <translation>Asignación de propiedad no válida: Se esperaba vector 3D</translation>
    </message>
    <message>
        <source>Cannot assign multiple values to a script property</source>
        <translation>No se pueden asignar múltiples valores a una propiedad de script</translation>
    </message>
    <message>
        <source>Invalid property assignment: date expected</source>
        <translation>Asignación de propiedad no válida: se esperaba una fecha</translation>
    </message>
    <message>
        <source>Invalid property assignment: time expected</source>
        <translation>Asignación de propiedad inválida: se esperaba tiempo</translation>
    </message>
    <message>
        <source>Property assignment expected</source>
        <translation>Se esperaba asignación de propiedad</translation>
    </message>
    <message>
        <source>Cannot create empty component specification</source>
        <translation>No se puede crear una especificación de componente vacía</translation>
    </message>
    <message>
        <source>&quot;%1&quot; cannot operate on &quot;%2&quot;</source>
        <translation>&quot;%1&quot; no puede operar en &quot;%2&quot;</translation>
    </message>
    <message>
        <source>Invalid use of id property</source>
        <translation>Uso no válido de la propiedad id</translation>
    </message>
    <message>
        <source>Method names cannot begin with an upper case letter</source>
        <translation>Los nombres de los métodos no pueden comenzar con una letra mayúscula</translation>
    </message>
    <message>
        <source>Empty signal assignment</source>
        <translation>Asignación de señal vacía</translation>
    </message>
    <message>
        <source>Duplicate property name</source>
        <translation>Nombre de propiedad duplicado</translation>
    </message>
    <message>
        <source>Not an attached property name</source>
        <translation>No es un nombre de propiedad adjunto</translation>
    </message>
    <message>
        <source>Component objects cannot declare new functions.</source>
        <translation>Los objetos del componente no pueden declarar nuevas funciones.</translation>
    </message>
    <message>
        <source>Incorrectly specified signal assignment</source>
        <translation>Asignación de señal especificada incorrectamente</translation>
    </message>
    <message>
        <source>Element is not creatable.</source>
        <translation>El elemento no se puede crear.</translation>
    </message>
    <message>
        <source>Component objects cannot declare new properties.</source>
        <translation>Los objetos del componente no pueden declarar nuevas propiedades.</translation>
    </message>
    <message>
        <source>Invalid property assignment: color expected</source>
        <translation>Asignación de propiedad no válida: se esperaba color</translation>
    </message>
    <message>
        <source>Duplicate method name</source>
        <translation>Nombre de método duplicado</translation>
    </message>
    <message>
        <source>Invalid property assignment: boolean expected</source>
        <translation>Asignación de propiedad no válida: se esperaba booleano</translation>
    </message>
    <message>
        <source>Cannot assign to non-existent default property</source>
        <translation>No se puede asignar a una propiedad predeterminada inexistente</translation>
    </message>
    <message>
        <source>Invalid alias reference. An alias reference must be specified as &lt;id&gt; or &lt;id&gt;.&lt;property&gt;</source>
        <translation>Referencia de alias no válida. Una referencia debe ser &lt;id&gt; o &lt;id&gt;.&lt;propiedad&gt;</translation>
    </message>
    <message>
        <source>Non-existent attached object</source>
        <translation>Objeto adjunto inexistente</translation>
    </message>
    <message>
        <source>IDs cannot start with an uppercase letter</source>
        <translation>Los IDs no pueden comenzar con una letra mayúscula</translation>
    </message>
    <message>
        <source>Invalid property assignment: point expected</source>
        <translation>Asignación de propiedad no válida: se esperaba punto</translation>
    </message>
    <message>
        <source>Can only assign one binding to lists</source>
        <translation>Solo se puede asignar un enlace a las listas</translation>
    </message>
    <message>
        <source>Duplicate default property</source>
        <translation>Propiedad predeterminada duplicada</translation>
    </message>
    <message>
        <source>Duplicate signal name</source>
        <translation>Nombre de señal duplicado</translation>
    </message>
    <message>
        <source>Invalid property assignment: unsigned int expected</source>
        <translation>Asignación de propiedad inválida: se esperaba entero sin signo</translation>
    </message>
    <message>
        <source>id is not unique</source>
        <translation>id no es único</translation>
    </message>
    <message>
        <source>Invalid property nesting</source>
        <translation>Anidamiento de propiedad no válido</translation>
    </message>
    <message>
        <source>Property names cannot begin with an upper case letter</source>
        <translation>Los nombres de las propiedades no pueden comenzar con una letra mayúscula</translation>
    </message>
    <message>
        <source>Invalid alias reference. Unable to find id &quot;%1&quot;</source>
        <translation>Referencia de alias no válida. No se puede encontrar el id &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Invalid property assignment: &quot;%1&quot; is a read-only property</source>
        <translation>Asignación de propiedad no válida: &quot;%1&quot; es una propiedad de solo lectura</translation>
    </message>
    <message>
        <source>Property value set multiple times</source>
        <translation>Valor de propiedad establecido varias veces</translation>
    </message>
    <message>
        <source>Illegal signal name</source>
        <translation>Nombre de señal ilegal</translation>
    </message>
    <message>
        <source>Cannot assign primitives to lists</source>
        <translation>No se pueden asignar primitivos a listas</translation>
    </message>
    <message>
        <source>Cannot assign object to property</source>
        <translation>No se puede asignar objeto a la propiedad</translation>
    </message>
    <message>
        <source>No property alias location</source>
        <translation>No hay ubicación de alias de propiedad</translation>
    </message>
    <message>
        <source>Property has already been assigned a value</source>
        <translation>La propiedad ya ha sido asignada un valor</translation>
    </message>
    <message>
        <source>Illegal method name</source>
        <translation>Nombre de método ilegal</translation>
    </message>
    <message>
        <source>Invalid property use</source>
        <translation>Uso de propiedad no válido</translation>
    </message>
    <message>
        <source>Invalid property assignment: number expected</source>
        <translation>Asignación de propiedad no válida: se esperaba número</translation>
    </message>
    <message>
        <source>Cannot assign a value directly to a grouped property</source>
        <translation>No se puede asignar un valor directamente a una propiedad agrupada</translation>
    </message>
    <message>
        <source>IDs must start with a letter or underscore</source>
        <translation>Los IDs deben comenzar con una letra o guion bajo</translation>
    </message>
    <message>
        <source>Invalid empty ID</source>
        <translation>ID vacío no válido</translation>
    </message>
    <message>
        <source>Unexpected object assignment</source>
        <translation>Asignación de objeto inesperada</translation>
    </message>
    <message>
        <source>Cannot assign to non-existent property &quot;%1&quot;</source>
        <translation>No se puede asignar a la propiedad inexistente &quot;%1&quot;</translation>
    </message>
    <message>
        <source>ID illegally masks global JavaScript property</source>
        <translation>ID enmascara ilegalmente la propiedad global de JavaScript</translation>
    </message>
    <message>
        <source>Invalid component body specification</source>
        <translation>Especificación del cuerpo del componente no válida</translation>
    </message>
    <message>
        <source>Component objects cannot declare new signals.</source>
        <translation>Los objetos del componente no pueden declarar nuevas señales.</translation>
    </message>
    <message>
        <source>IDs must contain only letters, numbers, and underscores</source>
        <translation>Los IDs deben contener solo letras, números y guiones bajos</translation>
    </message>
    <message>
        <source>Invalid use of namespace</source>
        <translation>Uso no válido del espacio de nombres</translation>
    </message>
    <message>
        <source>Invalid property assignment: int expected</source>
        <translation>Asignación de propiedad no válida: se esperaba int</translation>
    </message>
    <message>
        <source>Invalid component id specification</source>
        <translation>Especificación de id de componente no válida</translation>
    </message>
    <message>
        <source>Illegal property name</source>
        <translation>Nombre de propiedad ilegal</translation>
    </message>
    <message>
        <source>Invalid alias location</source>
        <translation>Ubicación de alias no válida</translation>
    </message>
    <message>
        <source>Single property assignment expected</source>
        <translation>Se esperaba asignación de propiedad única</translation>
    </message>
    <message>
        <source>Empty property assignment</source>
        <translation>Asignación de propiedad vacía</translation>
    </message>
    <message>
        <source>Signal names cannot begin with an upper case letter</source>
        <translation>Los nombres de las señales no pueden comenzar con una letra mayúscula</translation>
    </message>
    <message>
        <source>Invalid property assignment: url expected</source>
        <translation>Asignación de propiedad inválida: se esperaba URL</translation>
    </message>
    <message>
        <source>Invalid property assignment: script expected</source>
        <translation>Asignación de propiedad no válida: se esperaba script</translation>
    </message>
</context>
<context>
    <name>QSslSocket</name>
    <message>
        <source>Error creating SSL session: %1</source>
        <translation>Error al crear la sesión SSL: %1</translation>
    </message>
    <message>
        <source>Error creating SSL session, %1</source>
        <translation>Error al crear la sesión SSL, %1</translation>
    </message>
    <message>
        <source>The certificate&apos;s notAfter field contains an invalid time</source>
        <translation>El campo notAfter del certificado contiene un tiempo inválido</translation>
    </message>
    <message>
        <source>No error</source>
        <translation>Sin error</translation>
    </message>
    <message>
        <source>Cannot provide a certificate with no key, %1</source>
        <translation>No se puede proporcionar un certificado sin clave, %1</translation>
    </message>
    <message>
        <source>Unable to write data: %1</source>
        <translation>No se pueden escribir datos: %1</translation>
    </message>
    <message>
        <source>The certificate has expired</source>
        <translation>El certificado ha expirado</translation>
    </message>
    <message>
        <source>Error during SSL handshake: %1</source>
        <translation>Error durante el apretón de manos SSL: %1</translation>
    </message>
    <message>
        <source>Error loading local certificate, %1</source>
        <translation>Error al cargar el certificado local, %1</translation>
    </message>
    <message>
        <source>The certificate is self-signed, and untrusted</source>
        <translation>El certificado es autofirmado y no confiable</translation>
    </message>
    <message>
        <source>The peer did not present any certificate</source>
        <translation>El par no presentó ningún certificado</translation>
    </message>
    <message>
        <source>The root CA certificate is marked to reject the specified purpose</source>
        <translation>El certificado de la CA raíz está marcado para rechazar el propósito especificado</translation>
    </message>
    <message>
        <source>Invalid or empty cipher list (%1)</source>
        <translation>Lista de cifrado inválida o vacía (%1)</translation>
    </message>
    <message>
        <source>No certificates could be verified</source>
        <translation>No se pudieron verificar los certificados</translation>
    </message>
    <message>
        <source>The root CA certificate is not trusted for this purpose</source>
        <translation>El certificado CA raíz no es confiable para este propósito</translation>
    </message>
    <message>
        <source>The host name did not match any of the valid hosts for this certificate</source>
        <translation>El nombre del host no coincidió con ninguno de los hosts válidos para este certificado</translation>
    </message>
    <message>
        <source>The root certificate of the certificate chain is self-signed, and untrusted</source>
        <translation>El certificado raíz de la cadena de certificados está autofirmado y no es confiable</translation>
    </message>
    <message>
        <source>The certificate signature could not be decrypted</source>
        <translation>No se pudo descifrar la firma del certificado</translation>
    </message>
    <message>
        <source>The supplied certificate is unsuitable for this purpose</source>
        <translation>El certificado proporcionado no es adecuado para este propósito</translation>
    </message>
    <message>
        <source>Private key does not certify public key, %1</source>
        <translation>La clave privada no certifica la clave pública, %1</translation>
    </message>
    <message>
        <source>Error creating SSL context (%1)</source>
        <translation>Error al crear el contexto SSL (%1)</translation>
    </message>
    <message>
        <source>The issuer certificate could not be found</source>
        <translation>No se pudo encontrar el certificado del emisor</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
    <message>
        <source>Error while reading: %1</source>
        <translation>Error al leer: %1</translation>
    </message>
    <message>
        <source>The certificate&apos;s notBefore field contains an invalid time</source>
        <translation>El campo notBefore del certificado contiene un tiempo inválido</translation>
    </message>
    <message>
        <source>Error loading private key, %1</source>
        <translation>Error al cargar la clave privada, %1</translation>
    </message>
    <message>
        <source>The certificate is not yet valid</source>
        <translation>El certificado aún no es válido</translation>
    </message>
    <message>
        <source>The public key in the certificate could not be read</source>
        <translation>No se pudo leer la clave pública en el certificado</translation>
    </message>
    <message>
        <source>One of the CA certificates is invalid</source>
        <translation>Uno de los certificados CA es inválido</translation>
    </message>
    <message>
        <source>The signature of the certificate is invalid</source>
        <translation>La firma del certificado es inválida</translation>
    </message>
    <message>
        <source>The issuer certificate of a locally looked up certificate could not be found</source>
        <translation>No se pudo encontrar el certificado emisor de un certificado buscado localmente</translation>
    </message>
    <message>
        <source>Unable to decrypt data: %1</source>
        <translation>No se puede descifrar los datos: %1</translation>
    </message>
</context>
<context>
    <name>QLocalSocket</name>
    <message>
        <source>%1: Connection error</source>
        <translation>%1: Error de conexión</translation>
    </message>
    <message>
        <source>%1: Connection refused</source>
        <translation>%1: Conexión rechazada</translation>
    </message>
    <message>
        <source>%1: Unknown error %2</source>
        <translation>%1: Error desconocido %2</translation>
    </message>
    <message>
        <source>%1: Socket access error</source>
        <translation>%1: Error de acceso al socket</translation>
    </message>
    <message>
        <source>%1: Socket resource error</source>
        <translation>%1: Error de recurso de socket</translation>
    </message>
    <message>
        <source>%1: The socket operation is not supported</source>
        <translation>%1: La operación de socket no es compatible</translation>
    </message>
    <message>
        <source>%1: Invalid name</source>
        <translation>%1: Nombre inválido</translation>
    </message>
    <message>
        <source>%1: Unknown error</source>
        <translation>%1: Error desconocido</translation>
    </message>
    <message>
        <source>%1: Socket operation timed out</source>
        <translation>%1: La operación de socket excedió el tiempo de espera</translation>
    </message>
    <message>
        <source>%1: Datagram too large</source>
        <translation>%1: Datagrama demasiado grande</translation>
    </message>
    <message>
        <source>%1: Remote closed</source>
        <translation>%1: Cerrado por remoto</translation>
    </message>
</context>
<context>
    <name>QOCIResult</name>
    <message>
        <source>Unable to get statement type</source>
        <translation>No se puede obtener el tipo de declaración</translation>
    </message>
    <message>
        <source>Unable to alloc statement</source>
        <translation>No se puede asignar la declaración</translation>
    </message>
    <message>
        <source>Unable to goto next</source>
        <translation>No se puede ir al siguiente</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>No se puede ejecutar la declaración</translation>
    </message>
    <message>
        <source>Unable to bind column for batch execute</source>
        <translation>No se puede vincular la col para la ejecución por lotes</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>No se puede preparar la declaración</translation>
    </message>
    <message>
        <source>Unable to execute batch statement</source>
        <translation>No se puede ejecutar la declaración por lotes</translation>
    </message>
    <message>
        <source>Unable to bind value</source>
        <translation>No se puede enlazar el valor</translation>
    </message>
</context>
<context>
    <name>QtXmlPatterns</name>
    <message>
        <source>A comment cannot contain %1</source>
        <translation>Un comentario no puede contener %1</translation>
    </message>
    <message>
        <source>Version %1 is not supported. The supported XQuery version is 1.0.</source>
        <translation>La versión %1 no es compatible. La versión de XQuery compatible es 1.0.</translation>
    </message>
    <message>
        <source>&apos;%1&apos; attribute contains invalid QName content: %2.</source>
        <translation>El atributo &apos;%1&apos; contiene contenido QName inválido: %2.</translation>
    </message>
    <message>
        <source>Notation %1 already defined.</source>
        <translation>Notación %1 ya definida.</translation>
    </message>
    <message>
        <source>Declaration for element %1 does not exist.</source>
        <translation>La declaración para el elemento %1 no existe.</translation>
    </message>
    <message>
        <source>The parameter %1 is required, but no corresponding %2 is supplied.</source>
        <translation>El parámetro %1 es requerido, pero no se ha proporcionado el correspondiente %2.</translation>
    </message>
    <message>
        <source>Namespace declarations must occur before function, variable, and option declarations.</source>
        <translation>Las declaraciones de espacio de nombres deben ocurrir antes de las declaraciones de funciones, variables y opciones.</translation>
    </message>
    <message>
        <source>empty</source>
        <translation>vacío</translation>
    </message>
    <message>
        <source>Specifying use=&apos;prohibited&apos; inside an attribute group has no effect.</source>
        <translation>Especificar use=&apos;prohibited&apos; dentro de un grupo de atributos no tiene efecto.</translation>
    </message>
    <message>
        <source>Attribute group %1 contains attribute %2 twice.</source>
        <translation>El grupo de atributos %1 contiene el atributo %2 dos veces.</translation>
    </message>
    <message>
        <source>A comment cannot end with a %1.</source>
        <translation>Un comentario no puede terminar con un %1.</translation>
    </message>
    <message>
        <source>Derived particle allows content that is not allowed in the base particle.</source>
        <translation>La partícula derivada permite contenido que no está permitido en la partícula base.</translation>
    </message>
    <message>
        <source>%1 element is not allowed in this scope</source>
        <translation>El elemento %1 no está permitido en este ámbito.</translation>
    </message>
    <message>
        <source>Element %1 exists twice with different types.</source>
        <translation>El elemento %1 existe dos veces con diferentes tipos.</translation>
    </message>
    <message>
        <source>Integer division (%1) by zero (%2) is undefined.</source>
        <translation>La división entera (%1) por cero (%2) no está definida.</translation>
    </message>
    <message>
        <source>A library module cannot be evaluated directly. It must be imported from a main module.</source>
        <translation>Un módulo de biblioteca no puede evaluarse directamente. Debe importarse desde un módulo principal.</translation>
    </message>
    <message>
        <source>Time %1:%2:%3.%4 is invalid.</source>
        <translation>La hora %1:%2:%3.%4 es inválida.</translation>
    </message>
    <message>
        <source>A value of type %1 must contain an even number of digits. The value %2 does not.</source>
        <translation>Un valor de tipo %1 debe contener un número par de dígitos. El valor %2 no lo hace.</translation>
    </message>
    <message>
        <source>Child element is missing in that scope, possible child elements are: %1.</source>
        <translation>Falta un elemento hijo en ese ámbito, los posibles elementos hijos son: %1.</translation>
    </message>
    <message>
        <source>Modulus division (%1) by zero (%2) is undefined.</source>
        <translation>La división de módulo (%1) por cero (%2) no está definida.</translation>
    </message>
    <message>
        <source>Data of type %1 are not allowed to be empty.</source>
        <translation>Los datos del tipo %1 no pueden estar vacíos.</translation>
    </message>
    <message>
        <source>No function with signature %1 is available</source>
        <translation>No hay función disponible con la firma %1</translation>
    </message>
    <message>
        <source>Network timeout.</source>
        <translation>Tiempo de espera de red.</translation>
    </message>
    <message>
        <source>%1 element must not have %2 and %3 attribute together.</source>
        <translation>El elemento %1 no debe tener los atributos %2 y %3 juntos.</translation>
    </message>
    <message>
        <source>%1 element requires either %2 or %3 attribute.</source>
        <translation>El elemento %1 requiere el atributo %2 o %3.</translation>
    </message>
    <message>
        <source>Content of attribute %1 does not match its type definition: %2.</source>
        <translation>El contenido del atributo %1 no coincide con su definición de tipo: %2.</translation>
    </message>
    <message>
        <source>Attribute %1 and %2 are mutually exclusive.</source>
        <translation>Los atributos %1 y %2 son mutuamente excluyentes.</translation>
    </message>
    <message>
        <source>Loaded schema file is invalid.</source>
        <translation>El archivo de esquema cargado es inválido.</translation>
    </message>
    <message>
        <source>Parse error: %1</source>
        <translation>Error de análisis: %1</translation>
    </message>
    <message>
        <source>If the first argument is the empty sequence or a zero-length string (no namespace), a prefix cannot be specified. Prefix %1 was specified.</source>
        <translation>Si el primer argumento es la seq vacía o una cadena de longitud cero (sin espacio de nombres), no se puede especificar un prefijo. Se especificó el prefijo %1.</translation>
    </message>
    <message>
        <source>At least one component must be present.</source>
        <translation>Debe estar presente al menos un componente.</translation>
    </message>
    <message>
        <source>An attribute by name %1 has already been created.</source>
        <translation>Ya se ha creado un atributo con el nombre %1.</translation>
    </message>
    <message>
        <source>%1 element must have either %2 or %3 attribute.</source>
        <translation>El elemento %1 debe tener el atributo %2 o %3.</translation>
    </message>
    <message>
        <source>Invalid QName content: %1.</source>
        <translation>Contenido de QName inválido: %1.</translation>
    </message>
    <message>
        <source>Matches are case insensitive</source>
        <translation>Las coincidencias no distinguen entre mayúsculas y minúsculas</translation>
    </message>
    <message>
        <source>The name of an extension expression must be in a namespace.</source>
        <translation>El nombre de una expresión de extensión debe estar en un espacio de nombres.</translation>
    </message>
    <message>
        <source>%1 matches newline characters</source>
        <translation>%1 coincide con caracteres de nueva línea</translation>
    </message>
    <message>
        <source>Year %1 is invalid because it begins with %2.</source>
        <translation>El año %1 es inválido porque comienza con %2.</translation>
    </message>
    <message>
        <source>Content of attribute %1 does not match defined value constraint.</source>
        <translation>El contenido del atributo %1 no coincide con la restricción de valor definida.</translation>
    </message>
    <message>
        <source>Attribute %1 does not match the attribute wildcard.</source>
        <translation>El atributo %1 no coincide con el comodín de atributo.</translation>
    </message>
    <message>
        <source>Complex type %1 contains attribute %2 twice.</source>
        <translation>El tipo complejo %1 contiene el atributo %2 dos veces.</translation>
    </message>
    <message>
        <source>The second argument to %1 cannot be of type %2. It must be of type %3, %4, or %5.</source>
        <translation>El segundo argumento de %1 no puede ser de tipo %2. Debe ser de tipo %3, %4 o %5.</translation>
    </message>
    <message>
        <source>Element %1 cannot have children.</source>
        <translation>El elemento %1 no puede tener hijos.</translation>
    </message>
    <message>
        <source>The name for a computed attribute cannot have the namespace URI %1 with the local name %2.</source>
        <translation>El nombre de un atributo calculado no puede tener el URI del espacio de nombres %1 con el nombre local %2.</translation>
    </message>
    <message>
        <source>Element %1 is missing child element.</source>
        <translation>El elemento %1 carece de un elemento hijo.</translation>
    </message>
    <message>
        <source>Element %1 can&apos;t be serialized because it appears outside the document element.</source>
        <translation>El elemento %1 no puede ser serializado porque aparece fuera del elemento del documento.</translation>
    </message>
    <message>
        <source>Attribute %1 contains invalid data: %2</source>
        <translation>El atributo %1 contiene datos inválidos: %2</translation>
    </message>
    <message>
        <source>%1 and %2 match the start and end of a line.</source>
        <translation>%1 y %2 coinciden con el inicio y el fin de una línea.</translation>
    </message>
    <message>
        <source>%1 cannot be retrieved</source>
        <translation>%1 no se puede recuperar</translation>
    </message>
    <message>
        <source>The value of the XSL-T version attribute must be a value of type %1, which %2 isn&apos;t.</source>
        <translation>El valor del atributo de versión XSL-T debe ser un valor del tipo %1, lo cual %2 no es.</translation>
    </message>
    <message>
        <source>Element %1 already defined.</source>
        <translation>El elemento %1 ya está definido.</translation>
    </message>
    <message>
        <source>The prefix %1 cannot be bound.</source>
        <translation>El prefijo %1 no se puede enlazar.</translation>
    </message>
    <message numerus="yes">
        <source>%1 takes at most %n argument(s). %2 is therefore invalid.</source>
        <translation>
            <numerusform>%1 potrebuje največ %n argument. %2 zato ni veljavno.</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 attribute of %2 element must contain %3, %4 or a list of URIs.</source>
        <translation>El atributo %1 del elemento %2 debe contener %3, %4 o una lista de URIs.</translation>
    </message>
    <message>
        <source>If element %1 has no attribute %2, it cannot have attribute %3 or %4.</source>
        <translation>Si el elemento %1 no tiene el atributo %2, no puede tener los atributos %3 o %4.</translation>
    </message>
    <message>
        <source>A function already exists with the signature %1.</source>
        <translation>Ya existe una función con la firma %1.</translation>
    </message>
    <message>
        <source>Complex type %1 is not allowed to be abstract.</source>
        <translation>No se permite que el tipo complejo %1 sea abstracto.</translation>
    </message>
    <message>
        <source>Content of element %1 does not match defined value constraint.</source>
        <translation>El contenido del elemento %1 no coincide con la restricción de valor definida.</translation>
    </message>
    <message>
        <source>The item %1 did not match the required type %2.</source>
        <translation>El elemento %1 no coincidió con el tipo requerido %2.</translation>
    </message>
    <message>
        <source>Non-unique value found for constraint %1.</source>
        <translation>Se encontró un valor no único para la restricción %1.</translation>
    </message>
    <message>
        <source>one or more</source>
        <translation>uno o más</translation>
    </message>
    <message>
        <source>%1 element has neither %2 attribute nor %3 child element.</source>
        <translation>El elemento %1 no tiene ni el atributo %2 ni el elemento hijo %3.</translation>
    </message>
    <message>
        <source>Duplicated element names %1 in %2 element.</source>
        <translation>Nombres de elementos duplicados %1 en el elemento %2.</translation>
    </message>
    <message>
        <source>The encoding %1 is invalid. It must contain Latin characters only, must not contain whitespace, and must match the regular expression %2.</source>
        <translation>La codificación %1 es inválida. Debe contener solo caracteres latinos, no debe contener espacios en blanco y debe coincidir con la expresión regular %2.</translation>
    </message>
    <message>
        <source>%1 attribute of %2 element contains invalid content: {%3}.</source>
        <translation>El atributo %1 del elemento %2 contiene contenido no válido: {%3}.</translation>
    </message>
    <message numerus="yes">
        <source>%1 requires at least %n argument(s). %2 is therefore invalid.</source>
        <translation>
            <numerusform>%1 potrebuje najmanj %n argument. %2 zato ni veljavno.</numerusform>
        </translation>
    </message>
    <message>
        <source>Component with ID %1 has been defined previously.</source>
        <translation>El componente con ID %1 ha sido definido previamente.</translation>
    </message>
    <message>
        <source>Element %1 contains two attributes of type %2.</source>
        <translation>El elemento %1 contiene dos atributos de tipo %2.</translation>
    </message>
    <message>
        <source>The focus is undefined.</source>
        <translation>El enfoque no está definido.</translation>
    </message>
    <message>
        <source>%1 attribute of %2 element must be %3 or %4.</source>
        <translation>El atributo %1 del elemento %2 debe ser %3 o %4.</translation>
    </message>
    <message>
        <source>%1 is an unknown schema type.</source>
        <translation>%1 es un tipo de esquema desconocido.</translation>
    </message>
    <message>
        <source>The value for attribute %1 on element %2 must either be %3 or %4, not %5.</source>
        <translation>El valor para el atributo %1 en el elemento %2 debe ser %3 o %4, no %5.</translation>
    </message>
    <message>
        <source>Element %1 contains not allowed text content.</source>
        <translation>El elemento %1 contiene contenido de texto no permitido.</translation>
    </message>
    <message>
        <source>The namespace for a user defined function cannot be empty (try the predefined prefix %1 which exists for cases like this)</source>
        <translation>El espacio de nombres para una función definida por el usuario no puede estar vacío (intente el prefijo predefinido %1 que existe para casos como este)</translation>
    </message>
    <message>
        <source>%1 is not a valid value of type %2.</source>
        <translation>%1 no es un valor válido del tipo %2.</translation>
    </message>
    <message>
        <source>Multiplication of a value of type %1 by %2 or %3 (plus or minus infinity) is not allowed.</source>
        <translation>No se permite la multiplicación de un valor de tipo %1 por %2 o %3 (más o menos infinito).</translation>
    </message>
    <message>
        <source>The variable %1 is unused</source>
        <translation>La variable %1 no se utiliza</translation>
    </message>
    <message>
        <source>The %1-axis is unsupported in XQuery</source>
        <translation>El eje %1 no es compatible en XQuery</translation>
    </message>
    <message>
        <source>No definition for element %1 available.</source>
        <translation>No hay definición disponible para el elemento %1.</translation>
    </message>
    <message>
        <source>Dividing a value of type %1 by %2 or %3 (plus or minus zero) is not allowed.</source>
        <translation>No se permite dividir un valor de tipo %1 por %2 o %3 (más o menos cero).</translation>
    </message>
    <message>
        <source>Attribute %1 already defined.</source>
        <translation>El atributo %1 ya está definido.</translation>
    </message>
    <message>
        <source>%1 attribute of %2 element must have the value %3 because the %4 attribute is set.</source>
        <translation>El atributo %1 del elemento %2 debe tener el valor %3 porque el atributo %4 está establecido.</translation>
    </message>
    <message>
        <source>Attribute %1 cannot have the value %2.</source>
        <translation>El atributo %1 no puede tener el valor %2.</translation>
    </message>
    <message>
        <source>Element %1 is not allowed in this scope, possible elements are: %2.</source>
        <translation>El elemento %1 no está permitido en este ámbito, los elementos posibles son: %2.</translation>
    </message>
    <message>
        <source>%1 attribute of %2 element has larger value than %3 attribute.</source>
        <translation>El atributo %1 del elemento %2 tiene un valor mayor que el atributo %3.</translation>
    </message>
    <message>
        <source>It will not be possible to retrieve %1.</source>
        <translation>No será posible recuperar %1.</translation>
    </message>
    <message>
        <source>In an XSL-T pattern, function %1 cannot have a third argument.</source>
        <translation>En un patrón XSL-T, la función %1 no puede tener un tercer argumento.</translation>
    </message>
    <message>
        <source>The namespace URI in the name for a computed attribute cannot be %1.</source>
        <translation>El URI del espacio de nombres en el nombre de un atributo calculado no puede ser %1.</translation>
    </message>
    <message>
        <source>Specified type %1 is not known to the schema.</source>
        <translation>El tipo especificado %1 no es conocido por el esquema.</translation>
    </message>
    <message>
        <source>Declaration for attribute %1 does not exist.</source>
        <translation>La declaración para el atributo %1 no existe.</translation>
    </message>
    <message>
        <source>zero or one</source>
        <translation>cero o uno</translation>
    </message>
    <message>
        <source>Two namespace declaration attributes have the same name: %1.</source>
        <translation>Dos atributos de declaración de espacio de nombres tienen el mismo nombre: %1.</translation>
    </message>
    <message>
        <source>Effective Boolean Value cannot be calculated for a sequence containing two or more atomic values.</source>
        <translation>No se puede calcular el Valor Booleano Efectivo para una seq que contiene dos o más valores atómicos.</translation>
    </message>
    <message>
        <source>%1 is an invalid %2</source>
        <translation>%1 es un %2 inválido</translation>
    </message>
    <message>
        <source>The first argument to %1 cannot be of type %2. It must be a numeric type, xs:yearMonthDuration or xs:dayTimeDuration.</source>
        <translation>El primer argumento para %1 no puede ser del tipo %2. Debe ser un tipo numérico, xs:yearMonthDuration o xs:dayTimeDuration.</translation>
    </message>
    <message>
        <source>Division (%1) by zero (%2) is undefined.</source>
        <translation>La división (%1) por cero (%2) no está definida.</translation>
    </message>
    <message>
        <source>No template by name %1 exists.</source>
        <translation>No existe ninguna plantilla con el nombre %1.</translation>
    </message>
    <message>
        <source>%1 contains invalid data.</source>
        <translation>%1 contiene datos inválidos.</translation>
    </message>
    <message>
        <source>The default collection is undefined</source>
        <translation>La colección predeterminada no está definida</translation>
    </message>
    <message>
        <source>Only the prefix %1 can be bound to %2 and vice versa.</source>
        <translation>Solo el prefijo %1 puede estar vinculado a %2 y viceversa.</translation>
    </message>
    <message>
        <source>Value %1 of type %2 exceeds maximum (%3).</source>
        <translation>El valor %1 de tipo %2 excede el máximo (%3).</translation>
    </message>
    <message>
        <source>Whitespace characters are removed, except when they appear in character classes</source>
        <translation>Los caracteres de espacio en blanco se eliminan, excepto cuando aparecen en clases de caracteres</translation>
    </message>
    <message>
        <source>Operator %1 cannot be used on type %2.</source>
        <translation>El operador %1 no se puede usar en el tipo %2.</translation>
    </message>
    <message>
        <source>The namespace %1 is reserved; therefore user defined functions may not use it. Try the predefined prefix %2, which exists for these cases.</source>
        <translation>El espacio de nombres %1 está reservado; por lo tanto, las funciones definidas por el usuario no pueden usarlo. Intente el prefijo predefinido %2, que existe para estos casos.</translation>
    </message>
    <message>
        <source>The target namespace of a %1 cannot be empty.</source>
        <translation>El espacio de nombres de destino de un %1 no puede estar vacío.</translation>
    </message>
    <message>
        <source>Can not process unknown element %1, expected elements are: %2.</source>
        <translation>No se puede procesar el elemento desconocido %1, los elementos esperados son: %2.</translation>
    </message>
    <message>
        <source>%1 is an invalid namespace URI.</source>
        <translation>%1 es un URI de espacio de nombres no válido.</translation>
    </message>
    <message>
        <source>The attribute %1 can only appear on the first %2 element.</source>
        <translation>El atributo %1 solo puede aparecer en el primer elemento %2.</translation>
    </message>
    <message>
        <source>%1 element is not allowed in this context.</source>
        <translation>El elemento %1 no está permitido en este contexto.</translation>
    </message>
    <message>
        <source>Wildcard in derived particle is not a valid subset of wildcard in base particle.</source>
        <translation>El comodín en la partícula derivada no es un subconjunto válido del comodín en la partícula base.</translation>
    </message>
    <message>
        <source>%1 attribute of %2 element contains invalid content: {%3} is not a value of type %4.</source>
        <translation>El atributo %1 del elemento %2 contiene contenido inválido: {%3} no es un valor de tipo %4.</translation>
    </message>
    <message>
        <source>Module imports must occur before function, variable, and option declarations.</source>
        <translation>Las importaciones de módulos deben ocurrir antes de las declaraciones de funciones, variables y opciones.</translation>
    </message>
    <message>
        <source>Complex type of derived element %1 cannot be validly derived from base element.</source>
        <translation>El tipo complejo del elemento derivado %1 no puede derivarse válidamente del elemento base.</translation>
    </message>
    <message>
        <source>Day %1 is outside the range %2..%3.</source>
        <translation>El día %1 está fuera del rango %2..%3.</translation>
    </message>
    <message>
        <source>Text nodes are not allowed at this location.</source>
        <translation>Los nodos de texto no están permitidos en esta ubicación.</translation>
    </message>
    <message>
        <source>%1 element must have either %2 attribute or %3 or %4 as child element.</source>
        <translation>El elemento %1 debe tener ya sea el atributo %2 o %3 o %4 como elemento hijo.</translation>
    </message>
    <message>
        <source>Attribute group %1 already defined.</source>
        <translation>El grupo de atributos %1 ya está definido.</translation>
    </message>
    <message>
        <source>%1 was called.</source>
        <translation>%1 fue llamado.</translation>
    </message>
    <message>
        <source>Identity constraint %1 already defined.</source>
        <translation>La restricción de identidad %1 ya está definida.</translation>
    </message>
    <message>
        <source>%1 attribute of %2 element must either contain %3 or the other values.</source>
        <translation>El atributo %1 del elemento %2 debe contener %3 o los otros valores.</translation>
    </message>
    <message>
        <source>Element group %1 already defined.</source>
        <translation>El grupo de elementos %1 ya está definido.</translation>
    </message>
    <message>
        <source>Attribute %1 contains invalid content.</source>
        <translation>El atributo %1 contiene contenido inválido.</translation>
    </message>
    <message>
        <source>Element %1 contains not allowed attributes.</source>
        <translation>El elemento %1 contiene atributos no permitidos.</translation>
    </message>
    <message>
        <source>processContent of wildcard in derived particle is weaker than wildcard in base particle.</source>
        <translation>processContent del comodín en la partícula derivada es más débil que el comodín en la partícula base.</translation>
    </message>
    <message>
        <source>The namespace of a user defined function in a library module must be equivalent to the module namespace. In other words, it should be %1 instead of %2</source>
        <translation>El espacio de nombres de una función definida por el usuario en un módulo de biblioteca debe ser equivalente al espacio de nombres del módulo. En otras palabras, debería ser %1 en lugar de %2</translation>
    </message>
    <message>
        <source>Day %1 is invalid for month %2.</source>
        <translation>El día %1 no es válido para el mes %2.</translation>
    </message>
    <message>
        <source>Overflow: Can&apos;t represent date %1.</source>
        <translation>Desbordamiento: No se puede representar la fecha %1.</translation>
    </message>
    <message>
        <source>Unknown XSL-T attribute %1.</source>
        <translation>Atributo XSL-T desconocido %1.</translation>
    </message>
    <message>
        <source>It is not possible to redeclare prefix %1.</source>
        <translation>No es posible volver a declarar el prefijo %1.</translation>
    </message>
    <message>
        <source>exactly one</source>
        <translation>exactamente uno</translation>
    </message>
    <message>
        <source>%1 is not valid according to %2.</source>
        <translation>%1 no es válido según %2.</translation>
    </message>
    <message>
        <source>%1 is an invalid regular expression pattern: %2</source>
        <translation>%1 es un patrón de expresión regular inválido: %2</translation>
    </message>
    <message>
        <source>%1 element with %2 child element must not have a %3 attribute.</source>
        <translation>El elemento %1 con el elemento hijo %2 no debe tener un atributo %3.</translation>
    </message>
    <message>
        <source>Element %1 is not allowed at this location.</source>
        <translation>El elemento %1 no está permitido en esta ubicación.</translation>
    </message>
    <message>
        <source>Element %1 contains not allowed child element.</source>
        <translation>El elemento %1 contiene un elemento hijo no permitido.</translation>
    </message>
    <message>
        <source>Document is not a XML schema.</source>
        <translation>El documento no es un esquema XML.</translation>
    </message>
    <message>
        <source>%1 attribute of %2 element must have a value of %3 or %4.</source>
        <translation>El atributo %1 del elemento %2 debe tener un valor de %3 o %4.</translation>
    </message>
    <message>
        <source>Dividing a value of type %1 by %2 (not-a-number) is not allowed.</source>
        <translation>No se permite dividir un valor de tipo %1 por %2 (no es un número).</translation>
    </message>
    <message>
        <source>There is one IDREF value with no corresponding ID: %1.</source>
        <translation>Hay un valor IDREF sin un ID correspondiente: %1.</translation>
    </message>
    <message>
        <source>Field %1 has no simple type.</source>
        <translation>El campo %1 no tiene un tipo simple.</translation>
    </message>
    <message>
        <source>Key constraint %1 contains absent fields.</source>
        <translation>La restricción de clave %1 contiene campos ausentes.</translation>
    </message>
    <message>
        <source>ID value &apos;%1&apos; is not unique.</source>
        <translation>El valor de ID &apos;%1&apos; no es único.</translation>
    </message>
    <message>
        <source>Type of %1 element must be a simple type, %2 is not.</source>
        <translation>El tipo del elemento %1 debe ser un tipo simple, %2 no lo es.</translation>
    </message>
    <message>
        <source>%1 attribute of %2 element must have a value of %3.</source>
        <translation>El atributo %1 del elemento %2 debe tener un valor de %3.</translation>
    </message>
    <message>
        <source>Ambiguous rule match.</source>
        <translation>Coincidencia de regla ambigua.</translation>
    </message>
    <message>
        <source>Content of element %1 does not match its type definition: %2.</source>
        <translation>El contenido del elemento %1 no coincide con su definición de tipo: %2.</translation>
    </message>
    <message>
        <source>Promoting %1 to %2 may cause loss of precision.</source>
        <translation>Promover %1 a %2 puede causar pérdida de precisión.</translation>
    </message>
    <message>
        <source>Element %1 contains unknown attribute %2.</source>
        <translation>El elemento %1 contiene un atributo desconocido %2.</translation>
    </message>
    <message>
        <source>A default namespace declaration must occur before function, variable, and option declarations.</source>
        <translation>Una declaración de espacio de nombres predeterminado debe ocurrir antes de las declaraciones de funciones, variables y opciones.</translation>
    </message>
    <message>
        <source>Operator %1 cannot be used on atomic values of type %2 and %3.</source>
        <translation>El operador %1 no se puede usar en valores atómicos de tipo %2 y %3.</translation>
    </message>
    <message>
        <source>The module import feature is not supported</source>
        <translation>La función de importación de módulos no es compatible.</translation>
    </message>
    <message>
        <source>The parameter %1 is passed, but no corresponding %2 exists.</source>
        <translation>El parámetro %1 se pasa, pero no existe un %2 correspondiente.</translation>
    </message>
    <message>
        <source>A value of type %1 cannot have an Effective Boolean Value.</source>
        <translation>Un valor de tipo %1 no puede tener un Valor Booleano Efectivo.</translation>
    </message>
    <message>
        <source>Element %1 is missing required attribute %2.</source>
        <translation>Al elemento %1 le falta el atributo requerido %2.</translation>
    </message>
    <message>
        <source>The data of a processing instruction cannot contain the string %1</source>
        <translation>Los datos de una instrucción de procesamiento no pueden contener la cadena %1</translation>
    </message>
    <message>
        <source>Time 24:%1:%2.%3 is invalid. Hour is 24, but minutes, seconds, and milliseconds are not all 0; </source>
        <translation>La hora 24:%1:%2.%3 es inválida. La hora es 24, pero los minutos, segundos y milisegundos no son todos 0; </translation>
    </message>
    <message>
        <source>Text or entity references not allowed inside %1 element</source>
        <translation>No se permiten referencias de texto o entidades dentro del elemento %1.</translation>
    </message>
    <message>
        <source>Value %1 of type %2 is below minimum (%3).</source>
        <translation>El valor %1 del tipo %2 está por debajo del mínimo (%3).</translation>
    </message>
    <message>
        <source>Required type is %1, but %2 was found.</source>
        <translation>El tipo requerido es %1, pero se encontró %2.</translation>
    </message>
    <message>
        <source>Element %1 contains invalid content.</source>
        <translation>El elemento %1 contiene contenido inválido.</translation>
    </message>
    <message>
        <source>%1 is an unsupported encoding.</source>
        <translation>%1 es una codificación no compatible.</translation>
    </message>
    <message>
        <source>The name of an option must have a prefix. There is no default namespace for options.</source>
        <translation>El nombre de una opción debe tener un prefijo. No hay un espacio de nombres predeterminado para las opciones.</translation>
    </message>
    <message>
        <source>Type %1 already defined.</source>
        <translation>El tipo %1 ya está definido.</translation>
    </message>
    <message>
        <source>Element %1 must come last.</source>
        <translation>El elemento %1 debe ser el último.</translation>
    </message>
    <message>
        <source>Element %1 is missing in derived particle.</source>
        <translation>Falta el elemento %1 en la partícula derivada.</translation>
    </message>
    <message>
        <source>Element %1 contains not allowed child content.</source>
        <translation>El elemento %1 contiene contenido hijo no permitido.</translation>
    </message>
    <message>
        <source>The name %1 does not refer to any schema type.</source>
        <translation>El nombre %1 no se refiere a ningún tipo de esquema.</translation>
    </message>
    <message>
        <source>Prefix %1 can only be bound to %2 (and it is, in either case, pre-declared).</source>
        <translation>El prefijo %1 solo puede estar vinculado a %2 (y está, en cualquier caso, predeclarado).</translation>
    </message>
    <message>
        <source>Element %1 is not defined in this scope.</source>
        <translation>El elemento %1 no está definido en este ámbito.</translation>
    </message>
    <message>
        <source>The initialization of variable %1 depends on itself</source>
        <translation>La inicialización de la variable %1 depende de sí misma</translation>
    </message>
    <message>
        <source>Content of %1 attribute of %2 element must not be from namespace %3.</source>
        <translation>El contenido del atributo %1 del elemento %2 no debe ser del espacio de nombres %3.</translation>
    </message>
    <message>
        <source>Month %1 is outside the range %2..%3.</source>
        <translation>El mes %1 está fuera del rango %2..%3.</translation>
    </message>
    <message>
        <source>The name of a variable bound in a for-expression must be different from the positional variable. Hence, the two variables named %1 collide.</source>
        <translation>El nombre de una variable vinculada en una expresión for debe ser diferente de la variable posicional. Por lo tanto, las dos variables llamadas %1 colisionan.</translation>
    </message>
    <message>
        <source>%1 is not valid as a value of type %2.</source>
        <translation>%1 no es válido como un valor del tipo %2.</translation>
    </message>
    <message>
        <source>zero or more</source>
        <translation>cero o más</translation>
    </message>
    <message>
        <source>More than one value found for field %1.</source>
        <translation>Se encontró más de un valor para el campo %1.</translation>
    </message>
    <message>
        <source>At least one time component must appear after the %1-delimiter.</source>
        <translation>Al menos un componente de tiempo debe aparecer después del delimitador %1.</translation>
    </message>
    <message>
        <source>Overflow: Date can&apos;t be represented.</source>
        <translation>Desbordamiento: La fecha no se puede representar.</translation>
    </message>
    <message>
        <source>%1 attribute of %2 element must not be %3.</source>
        <translation>El atributo %1 del elemento %2 no debe ser %3.</translation>
    </message>
    <message>
        <source>Prefix of qualified name %1 is not defined.</source>
        <translation>El prefijo del nombre calificado %1 no está definido.</translation>
    </message>
    <message>
        <source>No schema defined for validation.</source>
        <translation>No se ha definido un esquema para la validación.</translation>
    </message>
    <message>
        <source>%1 is not a valid XML 1.0 character.</source>
        <translation>%1 no es un carácter válido de XML 1.0.</translation>
    </message>
    <message>
        <source>The first argument to %1 cannot be of type %2. It must be of type %3, %4, or %5.</source>
        <translation>El primer argumento para %1 no puede ser del tipo %2. Debe ser de tipo %3, %4 o %5.</translation>
    </message>
    <message>
        <source>Element %1 is declared as abstract.</source>
        <translation>El elemento %1 está declarado como abstracto.</translation>
    </message>
    <message>
        <source>%1 is not a whole number of minutes.</source>
        <translation>%1 no es un número entero de minutos.</translation>
    </message>
    <message>
        <source>%1 element is not allowed inside %2 element if %3 attribute is present.</source>
        <translation>El elemento %1 no está permitido dentro del elemento %2 si el atributo %3 está presente.</translation>
    </message>
    <message>
        <source>Namespace %1 can only be bound to %2 (and it is, in either case, pre-declared).</source>
        <translation>El espacio de nombres %1 solo puede estar vinculado a %2 (y en cualquier caso, está predeclarado).</translation>
    </message>
    <message>
        <source>Simple type of derived element %1 cannot be validly derived from base element.</source>
        <translation>El tipo simple del elemento derivado %1 no puede derivarse válidamente del elemento base.</translation>
    </message>
    <message>
        <source>Element %1 must have at least one of the attributes %2 or %3.</source>
        <translation>El elemento %1 debe tener al menos uno de los atributos %2 o %3.</translation>
    </message>
    <message>
        <source>No external functions are supported. All supported functions can be used directly, without first declaring them as external</source>
        <translation>No se admiten funciones externas. Todas las funciones admitidas se pueden usar directamente, sin necesidad de declararlas primero como externas.</translation>
    </message>
</context>
<context>
    <name>QDeclarativeAnchors</name>
    <message>
        <source>Cannot anchor item to self.</source>
        <translation>No se puede anclar un elemento a sí mismo.</translation>
    </message>
    <message>
        <source>Possible anchor loop detected on horizontal anchor.</source>
        <translation>Se detectó un posible bucle de anclaje en el anclaje horizontal.</translation>
    </message>
    <message>
        <source>Cannot anchor to a null item.</source>
        <translation>No se puede anclar a un elemento nulo.</translation>
    </message>
    <message>
        <source>Cannot specify top, bottom, and vcenter anchors.</source>
        <translation>No se pueden especificar anclajes superior, inferior y vcenter.</translation>
    </message>
    <message>
        <source>Possible anchor loop detected on centerIn.</source>
        <translation>Se detectó un posible bucle de anclaje en centerIn.</translation>
    </message>
    <message>
        <source>Baseline anchor cannot be used in conjunction with top, bottom, or vcenter anchors.</source>
        <translation>El anclaje de línea base no se puede usar junto con anclajes superior, inferior o vcenter.</translation>
    </message>
    <message>
        <source>Cannot specify left, right, and hcenter anchors.</source>
        <translation>No se pueden especificar anclajes izquierdo, derecho y hcenter.</translation>
    </message>
    <message>
        <source>Possible anchor loop detected on vertical anchor.</source>
        <translation>Se detectó un posible bucle de anclaje en el anclaje vertical.</translation>
    </message>
    <message>
        <source>Cannot anchor a horizontal edge to a vertical edge.</source>
        <translation>No se puede anclar un borde horizontal a un borde vertical.</translation>
    </message>
    <message>
        <source>Cannot anchor a vertical edge to a horizontal edge.</source>
        <translation>No se puede anclar un borde vertical a un borde horizontal.</translation>
    </message>
    <message>
        <source>Cannot anchor to an item that isn&apos;t a parent or sibling.</source>
        <translation>No se puede anclar a un elemento que no sea padre o hermano.</translation>
    </message>
    <message>
        <source>Possible anchor loop detected on fill.</source>
        <translation>Se detectó un posible bucle de anclaje en el relleno.</translation>
    </message>
</context>
<context>
    <name>QDeclarativeTypeData</name>
    <message>
        <source>%1 %2</source>
        <translation>%1 %2</translation>
    </message>
    <message>
        <source>Type %1 unavailable</source>
        <translation>Tipo %1 no disponible</translation>
    </message>
    <message>
        <source>Namespace %1 cannot be used as a type</source>
        <translation>El espacio de nombres %1 no puede usarse como un tipo</translation>
    </message>
    <message>
        <source>Script %1 unavailable</source>
        <translation>Script %1 no disponible</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::AudioEqualizer</name>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
</context>
<context>
    <name>QFontDialog</name>
    <message>
        <source>&amp;Font</source>
        <translation>&amp;Fuente</translation>
    </message>
    <message>
        <source>&amp;Size</source>
        <translation>&amp;Size</translation>
    </message>
    <message>
        <source>Sample</source>
        <translation>Muestra</translation>
    </message>
    <message>
        <source>Font st&amp;yle</source>
        <translation>Estilo de fuent&amp;a</translation>
    </message>
    <message>
        <source>Wr&amp;iting System</source>
        <translation>Sistema de escritu&amp;ra</translation>
    </message>
    <message>
        <source>Select Font</source>
        <translation>Seleccionar fuente</translation>
    </message>
    <message>
        <source>&amp;Underline</source>
        <translation>&amp;Subrayado</translation>
    </message>
    <message>
        <source>Effects</source>
        <translation>Efectos</translation>
    </message>
    <message>
        <source>Stri&amp;keout</source>
        <translation>Tach&amp;ado</translation>
    </message>
</context>
<context>
    <name>Q3Wizard</name>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ayuda</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>&amp;Finish</source>
        <translation>&amp;Finalizar</translation>
    </message>
    <message>
        <source>&amp;Next &gt;</source>
        <translation>&amp;Siguiente &gt;</translation>
    </message>
    <message>
        <source>&lt; &amp;Back</source>
        <translation>&lt; &amp;Atrás</translation>
    </message>
</context>
<context>
    <name>QWorkspace</name>
    <message>
        <source>&amp;Move</source>
        <translation>&amp;Mover</translation>
    </message>
    <message>
        <source>&amp;Size</source>
        <translation>&amp;Size</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Minimizar</translation>
    </message>
    <message>
        <source>Stay on &amp;Top</source>
        <translation>Mantener en &amp;Superior</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <source>%1 - [%2]</source>
        <translation>%1 - [%2]</translation>
    </message>
    <message>
        <source>Sh&amp;ade</source>
        <translation>&amp;Ocultar</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Restaurar</translation>
    </message>
    <message>
        <source>&amp;Unshade</source>
        <translation>&amp;Desombrear</translation>
    </message>
    <message>
        <source>Mi&amp;nimize</source>
        <translation>Mi&amp;nimizar</translation>
    </message>
    <message>
        <source>Ma&amp;ximize</source>
        <translation>Ma&amp;ximizar</translation>
    </message>
    <message>
        <source>Restore Down</source>
        <translation>Restaurar abajo</translation>
    </message>
</context>
<context>
    <name>QColorDialog</name>
    <message>
        <source>&amp;Red:</source>
        <translation>&amp;Rojizo:</translation>
    </message>
    <message>
        <source>&amp;Sat:</source>
        <translation>&amp;Sat:</translation>
    </message>
    <message>
        <source>&amp;Val:</source>
        <translation>&amp;Val:</translation>
    </message>
    <message>
        <source>Hu&amp;e:</source>
        <translation>Ton&amp;alidad:</translation>
    </message>
    <message>
        <source>Select Color</source>
        <translation>Seleccionar color</translation>
    </message>
    <message>
        <source>&amp;Add to Custom Colors</source>
        <translation>&amp;Agregar a colores personalizados</translation>
    </message>
    <message>
        <source>Bl&amp;ue:</source>
        <translation>Az&amp;ul:</translation>
    </message>
    <message>
        <source>&amp;Green:</source>
        <translation>&amp;Verde:</translation>
    </message>
    <message>
        <source>&amp;Basic colors</source>
        <translation>&amp;Colores básicos</translation>
    </message>
    <message>
        <source>&amp;Custom colors</source>
        <translation>&amp;Colores personalizados</translation>
    </message>
    <message>
        <source>A&amp;lpha channel:</source>
        <translation>Canal &amp;alfa:</translation>
    </message>
</context>
<context>
    <name>QNetworkSessionPrivateImpl</name>
    <message>
        <source>Roaming error</source>
        <translation>Error de itinerancia</translation>
    </message>
    <message>
        <source>The session was aborted by the user or system.</source>
        <translation>La sesión fue abortada por el usuario o el sistema.</translation>
    </message>
    <message>
        <source>The requested operation is not supported by the system.</source>
        <translation>La operación solicitada no es compatible con el sistema.</translation>
    </message>
    <message>
        <source>Session aborted by user or system</source>
        <translation>Sesión abortada por el usuario o el sistema</translation>
    </message>
    <message>
        <source>Unidentified Error</source>
        <translation>Error no identificado</translation>
    </message>
    <message>
        <source>Roaming was aborted or is not possible.</source>
        <translation>La itinerancia fue abortada o no es posible.</translation>
    </message>
    <message>
        <source>The specified configuration cannot be used.</source>
        <translation>La configuración especificada no se puede usar.</translation>
    </message>
    <message>
        <source>Unknown session error.</source>
        <translation>Error de sesión desconocido.</translation>
    </message>
</context>
<context>
    <name>QSharedMemory</name>
    <message>
        <source>%1: system-imposed size restrictions</source>
        <translation>%1: restricciones de tamaño impuestas por el sistema</translation>
    </message>
    <message>
        <source>%1: doesn&apos;t exists</source>
        <translation>%1: no existe</translation>
    </message>
    <message>
        <source>%1: key is empty</source>
        <translation>%1: la clave está vacía</translation>
    </message>
    <message>
        <source>%1: key error</source>
        <translation>%1: error de clave</translation>
    </message>
    <message>
        <source>%1: create size is less then 0</source>
        <translation>%1: el tamaño de creación es menor que 0</translation>
    </message>
    <message>
        <source>%1: already exists</source>
        <translation>%1: ya existe</translation>
    </message>
    <message>
        <source>%1: unknown error %2</source>
        <translation>%1: error desconocido %2</translation>
    </message>
    <message>
        <source>%1: invalid size</source>
        <translation>%1: tamaño inválido</translation>
    </message>
    <message>
        <source>%1: unable to make key</source>
        <translation>%1: no se puede crear la clave</translation>
    </message>
    <message>
        <source>%1: unable to set key on lock</source>
        <translation>%1: no se puede establecer la clave en el bloqueo</translation>
    </message>
    <message>
        <source>%1: unable to unlock</source>
        <translation>%1: no se puede desbloquear</translation>
    </message>
    <message>
        <source>%1: permission denied</source>
        <translation>%1: permiso denegado</translation>
    </message>
    <message>
        <source>%1: ftok failed</source>
        <translation>%1: ftok falló</translation>
    </message>
    <message>
        <source>%1: out of resources</source>
        <translation>%1: sin recursos</translation>
    </message>
    <message>
        <source>%1: not attached</source>
        <translation>%1: no está adjunto</translation>
    </message>
    <message>
        <source>%1: UNIX key file doesn&apos;t exist</source>
        <translation>%1: El archivo de clave UNIX no existe</translation>
    </message>
    <message>
        <source>%1: doesn&apos;t exist</source>
        <translation>%1: no existe</translation>
    </message>
    <message>
        <source>%1: size query failed</source>
        <translation>%1: fallo en la consulta de tamaño</translation>
    </message>
    <message>
        <source>%1: unable to lock</source>
        <translation>%1: no se puede bloquear</translation>
    </message>
</context>
<context>
    <name>QXmlStream</name>
    <message>
        <source>Reference to unparsed entity &apos;%1&apos;.</source>
        <translation>Referencia a entidad no analizada &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>Unexpected character &apos;%1&apos; in public id literal.</source>
        <translation>Carácter inesperado &apos;%1&apos; en el literal de id público.</translation>
    </message>
    <message>
        <source>Illegal namespace declaration.</source>
        <translation>Declaración de espacio de nombres ilegal.</translation>
    </message>
    <message>
        <source>Invalid XML character.</source>
        <translation>Carácter XML inválido.</translation>
    </message>
    <message>
        <source>Expected character data.</source>
        <translation>Se esperaban datos de carácter.</translation>
    </message>
    <message>
        <source>Standalone accepts only yes or no.</source>
        <translation>Standalone solo acepta sí o no.</translation>
    </message>
    <message>
        <source>Invalid XML version string.</source>
        <translation>Cadena de versión XML inválida.</translation>
    </message>
    <message>
        <source>Invalid processing instruction name.</source>
        <translation>Nombre de instrucción de procesamiento inválido.</translation>
    </message>
    <message>
        <source>Namespace prefix &apos;%1&apos; not declared</source>
        <translation>Prefijo de espacio de nombres &apos;%1&apos; no declarado</translation>
    </message>
    <message>
        <source>Entity &apos;%1&apos; not declared.</source>
        <translation>Entidad &apos;%1&apos; no declarada.</translation>
    </message>
    <message>
        <source>%1 is an invalid processing instruction name.</source>
        <translation>%1 es un nombre de instrucción de procesamiento inválido.</translation>
    </message>
    <message>
        <source>The standalone pseudo attribute must appear after the encoding.</source>
        <translation>El pseudoatributo standalone debe aparecer después de la codificación.</translation>
    </message>
    <message>
        <source>Sequence &apos;]]&gt;&apos; not allowed in content.</source>
        <translation>Seq &apos;]]&gt;&apos; no permitida en el contenido.</translation>
    </message>
    <message>
        <source>%1 is an invalid encoding name.</source>
        <translation>%1 es un nombre de codificación inválido.</translation>
    </message>
    <message>
        <source>, but got &apos;</source>
        <translation>, pero se obtuvo &apos;</translation>
    </message>
    <message>
        <source>Start tag expected.</source>
        <translation>Se esperaba una etiqueta de inicio.</translation>
    </message>
    <message>
        <source>Invalid character reference.</source>
        <translation>Referencia de carácter inválida.</translation>
    </message>
    <message>
        <source>Reference to external entity &apos;%1&apos; in attribute value.</source>
        <translation>Referencia a entidad externa &apos;%1&apos; en el valor del atributo.</translation>
    </message>
    <message>
        <source>Expected </source>
        <translation>Esperado </translation>
    </message>
    <message>
        <source>Invalid document.</source>
        <translation>Documento inválido.</translation>
    </message>
    <message>
        <source>Opening and ending tag mismatch.</source>
        <translation>Desajuste entre etiqueta de apertura y cierre.</translation>
    </message>
    <message>
        <source>Encountered incorrectly encoded content.</source>
        <translation>Contenido codificado incorrectamente encontrado.</translation>
    </message>
    <message>
        <source>Invalid attribute in XML declaration.</source>
        <translation>Atributo inválido en la declaración XML.</translation>
    </message>
    <message>
        <source>Attribute redefined.</source>
        <translation>Atributo redefinido.</translation>
    </message>
    <message>
        <source>%1 is an invalid PUBLIC identifier.</source>
        <translation>%1 es un identificador PUBLIC inválido.</translation>
    </message>
    <message>
        <source>Extra content at end of document.</source>
        <translation>Contenido extra al final del documento.</translation>
    </message>
    <message>
        <source>Invalid XML name.</source>
        <translation>Nombre XML inválido.</translation>
    </message>
    <message>
        <source>Premature end of document.</source>
        <translation>Fin prematuro del documento.</translation>
    </message>
    <message>
        <source>XML declaration not at start of document.</source>
        <translation>Declaración XML no al inicio del documento.</translation>
    </message>
    <message>
        <source>Recursive entity detected.</source>
        <translation>Entidad recursiva detectada.</translation>
    </message>
    <message>
        <source>Unsupported XML version.</source>
        <translation>Versión XML no soportada.</translation>
    </message>
    <message>
        <source>Unexpected &apos;</source>
        <translation>Inesperado &apos;</translation>
    </message>
    <message>
        <source>Invalid entity value.</source>
        <translation>Valor de entidad inválido.</translation>
    </message>
    <message>
        <source>Encoding %1 is unsupported</source>
        <translation>Codificación %1 no soportada</translation>
    </message>
    <message>
        <source>NDATA in parameter entity declaration.</source>
        <translation>NDATA en la declaración de entidad de parámetro.</translation>
    </message>
</context>
<context>
    <name>QProcess</name>
    <message>
        <source>Error writing to process</source>
        <translation>Error al escribir en el proceso</translation>
    </message>
    <message>
        <source>Resource error (fork failure): %1</source>
        <translation>Error de recurso (fallo de fork): %1</translation>
    </message>
    <message>
        <source>Error reading from process</source>
        <translation>Error al leer del proceso</translation>
    </message>
    <message>
        <source>Process failed to start: %1</source>
        <translation>El proceso no pudo iniciar: %1</translation>
    </message>
    <message>
        <source>Could not open input redirection for reading</source>
        <translation>No se pudo abrir la redirección de entrada para lectura</translation>
    </message>
    <message>
        <source>No program defined</source>
        <translation>No se definió ningún programa</translation>
    </message>
    <message>
        <source>Could not open output redirection for writing</source>
        <translation>No se pudo abrir la redirección de salida para escritura</translation>
    </message>
    <message>
        <source>Process operation timed out</source>
        <translation>La operación del proceso agotó el tiempo</translation>
    </message>
    <message>
        <source>Process crashed</source>
        <translation>El proceso se estrelló</translation>
    </message>
</context>
<context>
    <name>QNativeSocketEngine</name>
    <message>
        <source>The proxy type is invalid for this operation</source>
        <translation>El tipo de proxy es inválido para esta operación</translation>
    </message>
    <message>
        <source>Network operation timed out</source>
        <translation>Operación de red agotó el tiempo de espera</translation>
    </message>
    <message>
        <source>The remote host closed the connection</source>
        <translation>El host remoto cerró la conexión</translation>
    </message>
    <message>
        <source>Invalid socket descriptor</source>
        <translation>Descriptor de socket inválido</translation>
    </message>
    <message>
        <source>Host unreachable</source>
        <translation>Host inalcanzable</translation>
    </message>
    <message>
        <source>Protocol type not supported</source>
        <translation>Tipo de protocolo no soportado</translation>
    </message>
    <message>
        <source>Datagram was too large to send</source>
        <translation>El datagrama era demasiado grande para enviar</translation>
    </message>
    <message>
        <source>Attempt to use IPv6 socket on a platform with no IPv6 support</source>
        <translation>Intento de usar un socket IPv6 en una plataforma sin soporte para IPv6</translation>
    </message>
    <message>
        <source>Unable to receive a message</source>
        <translation>No se puede recibir un mensaje</translation>
    </message>
    <message>
        <source>Permission denied</source>
        <translation>Permiso denegado</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>Conexión rechazada</translation>
    </message>
    <message>
        <source>Unable to write</source>
        <translation>No se puede escribir</translation>
    </message>
    <message>
        <source>Another socket is already listening on the same port</source>
        <translation>Otro socket ya está escuchando en el mismo puerto</translation>
    </message>
    <message>
        <source>Unable to send a message</source>
        <translation>No se puede enviar un mensaje</translation>
    </message>
    <message>
        <source>The bound address is already in use</source>
        <translation>La dirección vinculada ya está en uso</translation>
    </message>
    <message>
        <source>Connection timed out</source>
        <translation>Conexión agotada</translation>
    </message>
    <message>
        <source>Network error</source>
        <translation>Error de red</translation>
    </message>
    <message>
        <source>Unsupported socket operation</source>
        <translation>Operación de socket no soportada</translation>
    </message>
    <message>
        <source>Operation on non-socket</source>
        <translation>Operación en un no-socket</translation>
    </message>
    <message>
        <source>Unable to initialize broadcast socket</source>
        <translation>No se puede inicializar el socket de difusión</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
    <message>
        <source>Unable to initialize non-blocking socket</source>
        <translation>No se puede inicializar el socket no bloqueante</translation>
    </message>
    <message>
        <source>The address is protected</source>
        <translation>La dirección está protegida</translation>
    </message>
    <message>
        <source>Network unreachable</source>
        <translation>Red inalcanzable</translation>
    </message>
    <message>
        <source>The address is not available</source>
        <translation>La dirección no está disponible</translation>
    </message>
    <message>
        <source>Out of resources</source>
        <translation>Sin recursos</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessFtpBackend</name>
    <message>
        <source>No suitable proxy found</source>
        <translation>No se encontró un proxy adecuado</translation>
    </message>
    <message>
        <source>Error while downloading %1: %2</source>
        <translation>Error al descargar %1: %2</translation>
    </message>
    <message>
        <source>Error while uploading %1: %2</source>
        <translation>Error al subir %1: %2</translation>
    </message>
    <message>
        <source>Cannot open %1: is a directory</source>
        <translation>No se puede abrir %1: es un directorio</translation>
    </message>
    <message>
        <source>Logging in to %1 failed: authentication required</source>
        <translation>Error al iniciar sesión en %1: se requiere autenticación</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessHttpBackend</name>
    <message>
        <source>No suitable proxy found</source>
        <translation>No se encontró un proxy adecuado</translation>
    </message>
</context>
<context>
    <name>QCheckBox</name>
    <message>
        <source>Check</source>
        <translation>Verificar</translation>
    </message>
    <message>
        <source>Toggle</source>
        <translation>Alternar</translation>
    </message>
    <message>
        <source>Uncheck</source>
        <translation>Desmarcar</translation>
    </message>
</context>
<context>
    <name>QRadioButton</name>
    <message>
        <source>Check</source>
        <translation>Verificar</translation>
    </message>
</context>
<context>
    <name>Q3TitleBar</name>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Minimizar</translation>
    </message>
    <message>
        <source>Displays the name of the window and contains controls to manipulate it</source>
        <translation>Muestra el nombre de la ventana y contiene controles para manipularla</translation>
    </message>
    <message>
        <source>Makes the window full screen</source>
        <translation>Hace que la ventana sea de pantalla completa</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <source>Maximize</source>
        <translation>Maximizar</translation>
    </message>
    <message>
        <source>Contains commands to manipulate the window</source>
        <translation>Contiene comandos para manipular la ventana</translation>
    </message>
    <message>
        <source>Restore up</source>
        <translation>Restaurar arriba</translation>
    </message>
    <message>
        <source>Puts a minimized window back to normal</source>
        <translation>Restaura una ventana minimizada a su tamaño normal</translation>
    </message>
    <message>
        <source>Closes the window</source>
        <translation>Cierra la ventana</translation>
    </message>
    <message>
        <source>Puts a maximized window back to normal</source>
        <translation>Devuelve una ventana maximizada a su tamaño normal</translation>
    </message>
    <message>
        <source>Moves the window out of the way</source>
        <translation>Mueve la ventana fuera del camino</translation>
    </message>
    <message>
        <source>Restore down</source>
        <translation>Restaurar abajo</translation>
    </message>
</context>
<context>
    <name>QScriptNewBreakpointWidget</name>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
</context>
<context>
    <name>Phonon::</name>
    <message>
        <source>Games</source>
        <translation>Juegos</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Communication</source>
        <translation>Comunicación</translation>
    </message>
    <message>
        <source>Accessibility</source>
        <translation>Accesibilidad</translation>
    </message>
    <message>
        <source>Notifications</source>
        <translation>Notificaciones</translation>
    </message>
</context>
<context>
    <name>Phonon::VolumeSlider</name>
    <message>
        <source>Muted</source>
        <translation>Silenciado</translation>
    </message>
    <message>
        <source>Volume: %1%</source>
        <translation>Volumen: %1%</translation>
    </message>
    <message>
        <source>Use this slider to adjust the volume. The leftmost position is 0%, the rightmost is %1%</source>
        <translation>Use este control deslizante para ajustar el volumen. La posición más a la izquierda es 0%, la más a la derecha es %1%</translation>
    </message>
</context>
<context>
    <name>Q3LocalFs</name>
    <message>
        <source>Could not open
%1</source>
        <translation>No se pudo abrir
%1</translation>
    </message>
    <message>
        <source>Could not remove file or directory
%1</source>
        <translation>No se pudo eliminar el archivo o directorio
%1</translation>
    </message>
    <message>
        <source>Could not create directory
%1</source>
        <translation>No se pudo crear el directorio
%1</translation>
    </message>
    <message>
        <source>Could not read directory
%1</source>
        <translation>No se pudo leer el directorio
%1</translation>
    </message>
    <message>
        <source>Could not rename
%1
to
%2</source>
        <translation>No se pudo renombrar
%1
a
%2</translation>
    </message>
    <message>
        <source>Could not write
%1</source>
        <translation>No se pudo escribir
%1</translation>
    </message>
</context>
<context>
    <name>QDial</name>
    <message>
        <source>QDial</source>
        <translation>QDial</translation>
    </message>
    <message>
        <source>SliderHandle</source>
        <translation>ControlDeslizante</translation>
    </message>
    <message>
        <source>SpeedoMeter</source>
        <translation>Velocímetro</translation>
    </message>
</context>
<context>
    <name>QAccessibleButton</name>
    <message>
        <source>Press</source>
        <translation>Presionar</translation>
    </message>
</context>
<context>
    <name>QSocks5SocketEngine</name>
    <message>
        <source>Network operation timed out</source>
        <translation>Operación de red agotó el tiempo de espera</translation>
    </message>
    <message>
        <source>Connection to proxy closed prematurely</source>
        <translation>Conexión con el proxy cerrada prematuramente</translation>
    </message>
    <message>
        <source>Proxy authentication failed: %1</source>
        <translation>Fallo en la autenticación del proxy: %1</translation>
    </message>
    <message>
        <source>Proxy authentication failed</source>
        <translation>Fallo en la autenticación del proxy</translation>
    </message>
    <message>
        <source>General SOCKSv5 server failure</source>
        <translation>Fallo general del servidor SOCKSv5</translation>
    </message>
    <message>
        <source>Unknown SOCKSv5 proxy error code 0x%1</source>
        <translation>Código de error desconocido del proxy SOCKSv5 0x%1</translation>
    </message>
    <message>
        <source>Connection not allowed by SOCKSv5 server</source>
        <translation>Conexión no permitida por el servidor SOCKSv5</translation>
    </message>
    <message>
        <source>SOCKSv5 command not supported</source>
        <translation>Comando SOCKSv5 no soportado</translation>
    </message>
    <message>
        <source>Connection to proxy timed out</source>
        <translation>Conexión con el proxy agotó el tiempo de espera</translation>
    </message>
    <message>
        <source>Proxy host not found</source>
        <translation>Host del proxy no encontrado</translation>
    </message>
    <message>
        <source>TTL expired</source>
        <translation>TTL expirado</translation>
    </message>
    <message>
        <source>Address type not supported</source>
        <translation>Tipo de dirección no soportado</translation>
    </message>
    <message>
        <source>Connection to proxy refused</source>
        <translation>Conexión con el proxy rechazada</translation>
    </message>
    <message>
        <source>SOCKS version 5 protocol error</source>
        <translation>Error de protocolo de la versión 5 de SOCKS</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF</name>
    <message>
        <source>Could not connect</source>
        <translation>No se pudo conectar</translation>
    </message>
    <message>
        <source>Access denied</source>
        <translation>Acceso denegado</translation>
    </message>
    <message>
        <source>Invalid protocol</source>
        <translation>Protocolo inválido</translation>
    </message>
    <message>
        <source>No error</source>
        <translation>Sin error</translation>
    </message>
    <message>
        <source>Audio Output</source>
        <translation>Salida de Audio</translation>
    </message>
    <message>
        <source>Disconnected</source>
        <translation>Desconectado</translation>
    </message>
    <message>
        <source>Server alert</source>
        <translation>Alerta del servidor</translation>
    </message>
    <message>
        <source>Out of memory</source>
        <translation>Sin memoria</translation>
    </message>
    <message>
        <source>Not supported</source>
        <translation>No soportado</translation>
    </message>
    <message>
        <source>Invalid URL</source>
        <translation>URL inválida</translation>
    </message>
    <message>
        <source>Video output error</source>
        <translation>Error de salida de video</translation>
    </message>
    <message>
        <source>In use</source>
        <translation>En uso</translation>
    </message>
    <message>
        <source>Insufficient bandwidth</source>
        <translation>Ancho de banda insuficiente</translation>
    </message>
    <message>
        <source>Already exists</source>
        <translation>Ya existe</translation>
    </message>
    <message>
        <source>Audio output error</source>
        <translation>Error de salida de audio</translation>
    </message>
    <message>
        <source>Multicast error</source>
        <translation>Error de multidifusión</translation>
    </message>
    <message>
        <source>Proxy server not supported</source>
        <translation>Servidor proxy no soportado</translation>
    </message>
    <message>
        <source>Permission denied</source>
        <translation>Permiso denegado</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>No encontrado</translation>
    </message>
    <message>
        <source>Not ready</source>
        <translation>No está listo</translation>
    </message>
    <message>
        <source>Proxy server error</source>
        <translation>Error del servidor proxy</translation>
    </message>
    <message>
        <source>The audio output device</source>
        <translation>El dispositivo de salida de audio</translation>
    </message>
    <message>
        <source>Streaming not supported</source>
        <translation>Transmisión no soportada</translation>
    </message>
    <message>
        <source>Audio or video components could not be played</source>
        <translation>No se pudieron reproducir los componentes de audio o video</translation>
    </message>
    <message>
        <source>Underflow</source>
        <translation>Subdesbordamiento</translation>
    </message>
    <message>
        <source>Network communication error</source>
        <translation>Error de comunicación de red</translation>
    </message>
    <message>
        <source>Overflow</source>
        <translation>Desbordamiento</translation>
    </message>
    <message>
        <source>Network unavailable</source>
        <translation>Red no disponible</translation>
    </message>
    <message>
        <source>Path not found</source>
        <translation>Ruta no encontrada</translation>
    </message>
    <message>
        <source>Decoder error</source>
        <translation>Error de decodificación</translation>
    </message>
    <message>
        <source>DRM error</source>
        <translation>Error de DRM</translation>
    </message>
    <message>
        <source>Unknown error (%1)</source>
        <translation>Error desconocido (%1)</translation>
    </message>
</context>
<context>
    <name>QRegExp</name>
    <message>
        <source>invalid category</source>
        <translation>categoría inválida</translation>
    </message>
    <message>
        <source>bad lookahead syntax</source>
        <translation>sintaxis de lookahead incorrecta</translation>
    </message>
    <message>
        <source>no error occurred</source>
        <translation>no ocurrió ningún error</translation>
    </message>
    <message>
        <source>missing left delim</source>
        <translation>falta el delimitador izquierdo</translation>
    </message>
    <message>
        <source>bad char class syntax</source>
        <translation>sintaxis de clase de carácter incorrecta</translation>
    </message>
    <message>
        <source>disabled feature used</source>
        <translation>se usó una función deshabilitada</translation>
    </message>
    <message>
        <source>invalid octal value</source>
        <translation>valor octal inválido</translation>
    </message>
    <message>
        <source>bad repetition syntax</source>
        <translation>sintaxis de repetición incorrecta</translation>
    </message>
    <message>
        <source>met internal limit</source>
        <translation>se alcanzó el límite interno</translation>
    </message>
    <message>
        <source>invalid interval</source>
        <translation>intervalo inválido</translation>
    </message>
    <message>
        <source>unexpected end</source>
        <translation>fin inesperado</translation>
    </message>
</context>
<context>
    <name>QWhatsThisAction</name>
    <message>
        <source>What&apos;s This?</source>
        <translation>¿Qué es esto?</translation>
    </message>
</context>
<context>
    <name>QDeclarativeTextInput</name>
    <message>
        <source>Could not instantiate cursor delegate</source>
        <translation>No se pudo instanciar el delegado del cursor</translation>
    </message>
    <message>
        <source>Could not load cursor delegate</source>
        <translation>No se pudo cargar el delegado del cursor</translation>
    </message>
</context>
<context>
    <name>Q3UrlOperator</name>
    <message>
        <source>The protocol `%1&apos; does not support getting files</source>
        <translation>El protocolo `%1&apos; no admite obtener archivos</translation>
    </message>
    <message>
        <source>The protocol `%1&apos; does not support renaming files or directories</source>
        <translation>El protocolo `%1&apos; no admite renombrar archivos o directorios</translation>
    </message>
    <message>
        <source>The protocol `%1&apos; does not support listing directories</source>
        <translation>El protocolo `%1&apos; no admite listar directorios</translation>
    </message>
    <message>
        <source>(unknown)</source>
        <translation>(desconocido)</translation>
    </message>
    <message>
        <source>The protocol `%1&apos; does not support removing files or directories</source>
        <translation>El protocolo `%1&apos; no admite eliminar archivos o directorios</translation>
    </message>
    <message>
        <source>The protocol `%1&apos; does not support putting files</source>
        <translation>El protocolo `%1&apos; no admite poner archivos</translation>
    </message>
    <message>
        <source>The protocol `%1&apos; is not supported</source>
        <translation>El protocolo `%1&apos; no es compatible</translation>
    </message>
    <message>
        <source>The protocol `%1&apos; does not support copying or moving files or directories</source>
        <translation>El protocolo `%1&apos; no admite copiar o mover archivos o directorios</translation>
    </message>
    <message>
        <source>The protocol `%1&apos; does not support creating new directories</source>
        <translation>El protocolo `%1&apos; no admite crear nuevos directorios</translation>
    </message>
</context>
<context>
    <name>QFtp</name>
    <message>
        <source>Listing directory failed:
%1</source>
        <translation>Error al listar el directorio:
%1</translation>
    </message>
    <message>
        <source>Creating directory failed:
%1</source>
        <translation>Error al crear el directorio:
%1</translation>
    </message>
    <message>
        <source>Not connected</source>
        <translation>No conectado</translation>
    </message>
    <message>
        <source>Connection refused for data connection</source>
        <translation>Conexión rechazada para la conexión de datos</translation>
    </message>
    <message>
        <source>Login failed:
%1</source>
        <translation>Error de inicio de sesión:
%1</translation>
    </message>
    <message>
        <source>Downloading file failed:
%1</source>
        <translation>Error al descargar el archivo:
%1</translation>
    </message>
    <message>
        <source>Connected to host</source>
        <translation>Conectado al host</translation>
    </message>
    <message>
        <source>Connection timed out to host %1</source>
        <translation>Tiempo de conexión agotado para el host %1</translation>
    </message>
    <message>
        <source>Connected to host %1</source>
        <translation>Conectado al host %1</translation>
    </message>
    <message>
        <source>Connecting to host failed:
%1</source>
        <translation>Error al conectar al host:
%1</translation>
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation>Host %1 no encontrado</translation>
    </message>
    <message>
        <source>Uploading file failed:
%1</source>
        <translation>Error al subir el archivo:
%1</translation>
    </message>
    <message>
        <source>Changing directory failed:
%1</source>
        <translation>Error al cambiar de directorio:
%1</translation>
    </message>
    <message>
        <source>Host found</source>
        <translation>Host encontrado</translation>
    </message>
    <message>
        <source>Removing directory failed:
%1</source>
        <translation>Error al eliminar el directorio:
%1</translation>
    </message>
    <message>
        <source>Connection refused to host %1</source>
        <translation>Conexión rechazada al host %1</translation>
    </message>
    <message>
        <source>Connection to %1 closed</source>
        <translation>Conexión a %1 cerrada</translation>
    </message>
    <message>
        <source>Removing file failed:
%1</source>
        <translation>Error al eliminar el archivo:
%1</translation>
    </message>
    <message>
        <source>Host %1 found</source>
        <translation>Host %1 encontrado</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
    <message>
        <source>Connection closed</source>
        <translation>Conexión cerrada</translation>
    </message>
</context>
<context>
    <name>QDeclarativeListModel</name>
    <message>
        <source>set: value is not an object</source>
        <translation>establecer: el valor no es un objeto</translation>
    </message>
    <message>
        <source>ListElement: cannot use script for property value</source>
        <translation>ListElement: no se puede usar un script para el valor de la propiedad</translation>
    </message>
    <message>
        <source>ListModel: undefined property &apos;%1&apos;</source>
        <translation>ListModel: propiedad &apos;%1&apos; indefinida</translation>
    </message>
    <message>
        <source>ListElement: cannot contain nested elements</source>
        <translation>ListElement: no puede contener elementos anidados</translation>
    </message>
    <message>
        <source>insert: value is not an object</source>
        <translation>insertar: el valor no es un objeto</translation>
    </message>
    <message>
        <source>remove: index %1 out of range</source>
        <translation>eliminar: índice %1 fuera de rango</translation>
    </message>
    <message>
        <source>set: index %1 out of range</source>
        <translation>establecer: índice %1 fuera de rango</translation>
    </message>
    <message>
        <source>append: value is not an object</source>
        <translation>añadir: el valor no es un objeto</translation>
    </message>
    <message>
        <source>move: out of range</source>
        <translation>mover: fuera de rango</translation>
    </message>
    <message>
        <source>insert: index %1 out of range</source>
        <translation>insertar: índice %1 fuera de rango</translation>
    </message>
    <message>
        <source>ListElement: cannot use reserved &quot;id&quot; property</source>
        <translation>ListElement: no se puede usar la propiedad reservada &quot;id&quot;</translation>
    </message>
</context>
<context>
    <name>QDeclarativeEngine</name>
    <message>
        <source>Version mismatch: expected %1, found %2</source>
        <translation>Incompatibilidad de versión: se esperaba %1, se encontró %2</translation>
    </message>
    <message>
        <source>executeSql called outside transaction()</source>
        <translation>executeSql llamado fuera de transacción()</translation>
    </message>
    <message>
        <source>Read-only Transaction</source>
        <translation>Transacción de solo lectura</translation>
    </message>
    <message>
        <source>SQL transaction failed</source>
        <translation>Transacción SQL fallida</translation>
    </message>
    <message>
        <source>transaction: missing callback</source>
        <translation>transacción: falta callback</translation>
    </message>
    <message>
        <source>SQL: database version mismatch</source>
        <translation>SQL: incompatibilidad de versión de la base de datos</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::EnvironmentalReverb</name>
    <message>
        <source>Reverb delay (ms)</source>
        <translation>Retraso de reverberación (ms)</translation>
    </message>
    <message>
        <source>Density (%)</source>
        <translation>Densidad (%)</translation>
    </message>
    <message>
        <source>Room HF level</source>
        <translation>Nivel HF de la sala</translation>
    </message>
    <message>
        <source>Reverb level (mB)</source>
        <translation>Nivel de reverberación (mB)</translation>
    </message>
    <message>
        <source>Diffusion (%)</source>
        <translation>Difusión (%)</translation>
    </message>
    <message>
        <source>Decay HF ratio (%)</source>
        <translation>Relación de decaimiento HF (%)</translation>
    </message>
    <message>
        <source>Decay time (ms)</source>
        <translation>Tiempo de decaimiento (ms)</translation>
    </message>
    <message>
        <source>Reflections level (mB)</source>
        <translation>Nivel de reflexiones (mB)</translation>
    </message>
    <message>
        <source>Room level (mB)</source>
        <translation>Nivel de la sala (mB)</translation>
    </message>
    <message>
        <source>Reflections delay (ms)</source>
        <translation>Retraso de reflexiones (ms)</translation>
    </message>
</context>
<context>
    <name>QDeclarativeVME</name>
    <message>
        <source>Cannot assign object to list</source>
        <translation>No se puede asignar un objeto a la lista</translation>
    </message>
    <message>
        <source>Cannot assign object type %1 with no default method</source>
        <translation>No se puede asignar un tipo de objeto %1 sin un método predeterminado</translation>
    </message>
    <message>
        <source>Cannot connect mismatched signal/slot %1 %vs. %2</source>
        <translation>No se puede conectar señal/ranura %1 %vs. %2 no coincidentes</translation>
    </message>
    <message>
        <source>Cannot assign value %1 to property %2</source>
        <translation>No se puede asignar el valor %1 a la propiedad %2</translation>
    </message>
    <message>
        <source>Cannot set properties on %1 as it is null</source>
        <translation>No se pueden establecer propiedades en %1 ya que es nulo</translation>
    </message>
    <message>
        <source>Cannot assign an object to signal property %1</source>
        <translation>No se puede asignar un objeto a la propiedad de señal %1</translation>
    </message>
    <message>
        <source>Unable to create object of type %1</source>
        <translation>No se puede crear un objeto del tipo %1</translation>
    </message>
    <message>
        <source>Cannot assign object to interface property</source>
        <translation>No se puede asignar un objeto a la propiedad de la interfaz</translation>
    </message>
    <message>
        <source>Unable to create attached object</source>
        <translation>No se puede crear un objeto adjunto</translation>
    </message>
</context>
<context>
    <name>QDB2Driver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No se puede confirmar la transacción</translation>
    </message>
    <message>
        <source>Unable to set autocommit</source>
        <translation>No se puede establecer autocommit</translation>
    </message>
    <message>
        <source>Unable to connect</source>
        <translation>No se puede conectar</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No se puede revertir la transacción</translation>
    </message>
</context>
<context>
    <name>QIBaseDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No se puede confirmar la transacción</translation>
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation>No se pudo iniciar la transacción</translation>
    </message>
    <message>
        <source>Error opening database</source>
        <translation>Error al abrir la base de datos</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No se puede revertir la transacción</translation>
    </message>
</context>
<context>
    <name>QIBaseResult</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No se puede confirmar la transacción</translation>
    </message>
    <message>
        <source>Unable to open BLOB</source>
        <translation>No se puede abrir el BLOB</translation>
    </message>
    <message>
        <source>Could not describe statement</source>
        <translation>No se pudo describir la declaración</translation>
    </message>
    <message>
        <source>Could not describe input statement</source>
        <translation>No se pudo describir la declaración de entrada</translation>
    </message>
    <message>
        <source>Could not allocate statement</source>
        <translation>No se pudo asignar la declaración</translation>
    </message>
    <message>
        <source>Unable to write BLOB</source>
        <translation>No se puede escribir BLOB</translation>
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation>No se pudo iniciar la transacción</translation>
    </message>
    <message>
        <source>Unable to close statement</source>
        <translation>No se puede cerrar la declaración</translation>
    </message>
    <message>
        <source>Could not get query info</source>
        <translation>No se pudo obtener la info de la consulta</translation>
    </message>
    <message>
        <source>Could not find array</source>
        <translation>No se pudo encontrar la matriz</translation>
    </message>
    <message>
        <source>Could not get array data</source>
        <translation>No se pudo obtener datos de matriz</translation>
    </message>
    <message>
        <source>Unable to execute query</source>
        <translation>No se puede ejecutar la consulta</translation>
    </message>
    <message>
        <source>Could not prepare statement</source>
        <translation>No se pudo preparar la declaración</translation>
    </message>
    <message>
        <source>Could not fetch next item</source>
        <translation>No se pudo obtener el siguiente elemento</translation>
    </message>
    <message>
        <source>Could not get statement info</source>
        <translation>No se pudo obtener la info de la declaración</translation>
    </message>
    <message>
        <source>Unable to create BLOB</source>
        <translation>No se puede crear el BLOB</translation>
    </message>
    <message>
        <source>Unable to read BLOB</source>
        <translation>No se puede leer el BLOB</translation>
    </message>
</context>
<context>
    <name>QMYSQLDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No se puede confirmar la transacción</translation>
    </message>
    <message>
        <source>Unable to open database &apos;</source>
        <translation>No se puede abrir la base de datos &apos;</translation>
    </message>
    <message>
        <source>Unable to connect</source>
        <translation>No se puede conectar</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No se puede revertir la transacción</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>No se puede iniciar la transacción</translation>
    </message>
</context>
<context>
    <name>QOCIDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No se puede confirmar la transacción</translation>
    </message>
    <message>
        <source>Unable to initialize</source>
        <translation>No se puede inicializar</translation>
    </message>
    <message>
        <source>Unable to logon</source>
        <translation>No se puede iniciar sesión</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No se puede revertir la transacción</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>No se puede iniciar la transacción</translation>
    </message>
</context>
<context>
    <name>QODBCDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No se puede confirmar la transacción</translation>
    </message>
    <message>
        <source>Unable to enable autocommit</source>
        <translation>No se puede habilitar el autocommit</translation>
    </message>
    <message>
        <source>Unable to disable autocommit</source>
        <translation>No se puede deshabilitar el autocommit</translation>
    </message>
    <message>
        <source>Unable to connect - Driver doesn&apos;t support all functionality required</source>
        <translation>No se puede conectar - El controlador no admite toda la funcionalidad requerida</translation>
    </message>
    <message>
        <source>Unable to connect</source>
        <translation>No se puede conectar</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No se puede revertir la transacción</translation>
    </message>
</context>
<context>
    <name>QSQLite2Driver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No se puede confirmar la transacción</translation>
    </message>
    <message>
        <source>Error opening database</source>
        <translation>Error al abrir la base de datos</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No se puede revertir la transacción</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>No se puede iniciar la transacción</translation>
    </message>
</context>
<context>
    <name>QSQLiteDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No se puede confirmar la transacción</translation>
    </message>
    <message>
        <source>Error closing database</source>
        <translation>Error al cerrar la base de datos</translation>
    </message>
    <message>
        <source>Error opening database</source>
        <translation>Error al abrir la base de datos</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No se puede revertir la transacción</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>No se puede iniciar la transacción</translation>
    </message>
</context>
<context>
    <name>QAbstractSocket</name>
    <message>
        <source>Host not found</source>
        <translation>Host no encontrado</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>Conexión rechazada</translation>
    </message>
    <message>
        <source>Connection timed out</source>
        <translation>Conexión agotada</translation>
    </message>
    <message>
        <source>Socket is not connected</source>
        <translation>El socket no está conectado</translation>
    </message>
    <message>
        <source>Socket operation timed out</source>
        <translation>La operación de socket excedió el tiempo de espera</translation>
    </message>
    <message>
        <source>Network unreachable</source>
        <translation>Red inalcanzable</translation>
    </message>
    <message>
        <source>Operation on socket is not supported</source>
        <translation>La operación en el socket no es compatible</translation>
    </message>
</context>
<context>
    <name>QHostInfoAgent</name>
    <message>
        <source>Host not found</source>
        <translation>Host no encontrado</translation>
    </message>
    <message>
        <source>No host name given</source>
        <translation>No se proporcionó un nombre de host</translation>
    </message>
    <message>
        <source>Unknown address type</source>
        <translation>Tipo de dirección desconocido</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
    <message>
        <source>Invalid hostname</source>
        <translation>Nombre de host inválido</translation>
    </message>
</context>
<context>
    <name>Phonon::Gstreamer::MediaObject</name>
    <message>
        <source>Could not open media source.</source>
        <translation>No se pudo abrir la fuente de medios.</translation>
    </message>
    <message>
        <source>Missing codec helper script assistant.</source>
        <translation>Falta el asistente del script de ayuda de códecs.</translation>
    </message>
    <message>
        <source>Could not decode media source.</source>
        <translation>No se pudo decodificar la fuente de medios.</translation>
    </message>
    <message>
        <source>Invalid source type.</source>
        <translation>Tipo de fuente inválido.</translation>
    </message>
    <message>
        <source>Cannot start playback. 

Check your GStreamer installation and make sure you 
have libgstreamer-plugins-base installed.</source>
        <translation>No se puede iniciar la reproducción. 

Verifica tu instalación de GStreamer y asegúrate de que 
tienes instalado libgstreamer-plugins-base.</translation>
    </message>
    <message>
        <source>Plugin codec installation failed for codec: %0</source>
        <translation>La instalación del códec del plugin falló para el códec: %0</translation>
    </message>
    <message>
        <source>Could not open audio device. The device is already in use.</source>
        <translation>No se pudo abrir el dispositivo de audio. El dispositivo ya está en uso.</translation>
    </message>
    <message>
        <source>A required codec is missing. You need to install the following codec(s) to play this content: %0</source>
        <translation>Falta un códec requerido. Necesitas instalar el(los) siguiente(s) códec(s) para reproducir este contenido: %0</translation>
    </message>
    <message>
        <source>Could not locate media source.</source>
        <translation>No se pudo localizar la fuente de medios.</translation>
    </message>
</context>
<context>
    <name>QXmlPatternistCLI</name>
    <message>
        <source>Unknown location</source>
        <translation>Ubicación desconocida</translation>
    </message>
    <message>
        <source>Error %1 in %2, at line %3, column %4: %5</source>
        <translation>Error %1 en %2, en la línea %3, col %4: %5</translation>
    </message>
    <message>
        <source>Warning in %1: %2</source>
        <translation>Advertencia en %1: %2</translation>
    </message>
    <message>
        <source>Error %1 in %2: %3</source>
        <translation>Error %1 en %2: %3</translation>
    </message>
    <message>
        <source>Warning in %1, at line %2, column %3: %4</source>
        <translation>Advertencia en %1, en la línea %2, col %3: %4</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <source>Connection refused (or timed out)</source>
        <translation>Conexión rechazada (o agotada)</translation>
    </message>
    <message>
        <source>Data corrupted</source>
        <translation>Datos corruptos</translation>
    </message>
    <message>
        <source>Connected to host</source>
        <translation>Conectado al host</translation>
    </message>
    <message>
        <source>Connected to host %1</source>
        <translation>Conectado al host %1</translation>
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation>Host %1 no encontrado</translation>
    </message>
    <message>
        <source>Unknown authentication method</source>
        <translation>Método de autenticación desconocido</translation>
    </message>
    <message>
        <source>Host requires authentication</source>
        <translation>El host requiere autenticación</translation>
    </message>
    <message>
        <source>Error writing response to device</source>
        <translation>Error al escribir la respuesta en el dispositivo</translation>
    </message>
    <message>
        <source>HTTPS connection requested but SSL support not compiled in</source>
        <translation>Se solicitó conexión HTTPS pero el soporte SSL no está compilado</translation>
    </message>
    <message>
        <source>Host found</source>
        <translation>Host encontrado</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>Conexión rechazada</translation>
    </message>
    <message>
        <source>Proxy authentication required</source>
        <translation>Se requiere autenticación del proxy</translation>
    </message>
    <message>
        <source>Unknown protocol specified</source>
        <translation>Protocolo desconocido especificado</translation>
    </message>
    <message>
        <source>HTTP request failed</source>
        <translation>Solicitud HTTP fallida</translation>
    </message>
    <message>
        <source>Proxy requires authentication</source>
        <translation>El proxy requiere autenticación</translation>
    </message>
    <message>
        <source>Authentication required</source>
        <translation>Se requiere autenticación</translation>
    </message>
    <message>
        <source>SSL handshake failed</source>
        <translation>Fallo en el handshake SSL</translation>
    </message>
    <message>
        <source>Connection to %1 closed</source>
        <translation>Conexión a %1 cerrada</translation>
    </message>
    <message>
        <source>Invalid HTTP chunked body</source>
        <translation>Cuerpo HTTP con chunked inválido</translation>
    </message>
    <message>
        <source>Host %1 found</source>
        <translation>Host %1 encontrado</translation>
    </message>
    <message>
        <source>Wrong content length</source>
        <translation>Longitud de contenido incorrecta</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
    <message>
        <source>Invalid HTTP response header</source>
        <translation>Encabezado de respuesta HTTP inválido</translation>
    </message>
    <message>
        <source>Connection closed</source>
        <translation>Conexión cerrada</translation>
    </message>
    <message>
        <source>No server set to connect to</source>
        <translation>No se ha configurado un servidor para conectar</translation>
    </message>
    <message>
        <source>Server closed connection unexpectedly</source>
        <translation>El servidor cerró la conexión inesperadamente</translation>
    </message>
    <message>
        <source>Request aborted</source>
        <translation>Solicitud abortada</translation>
    </message>
</context>
<context>
    <name>QDeclarativeImportDatabase</name>
    <message>
        <source>is ambiguous. Found in %1 and in %2</source>
        <translation>es ambiguo. Encontrado en %1 y en %2</translation>
    </message>
    <message>
        <source>local directory</source>
        <translation>directorio local</translation>
    </message>
    <message>
        <source>import &quot;%1&quot; has no qmldir and no namespace</source>
        <translation>la importación &quot;%1&quot; no tiene qmldir ni espacio de nombres</translation>
    </message>
    <message>
        <source>- %1 is not a namespace</source>
        <translation>- %1 no es un espacio de nombres</translation>
    </message>
    <message>
        <source>module &quot;%1&quot; definition &quot;%2&quot; not readable</source>
        <translation>el módulo &quot;%1&quot; definición &quot;%2&quot; no es legible</translation>
    </message>
    <message>
        <source>module &quot;%1&quot; plugin &quot;%2&quot; not found</source>
        <translation>módulo &quot;%1&quot; complemento &quot;%2&quot; no encontrado</translation>
    </message>
    <message>
        <source>is not a type</source>
        <translation>no es un tipo</translation>
    </message>
    <message>
        <source>module &quot;%1&quot; is not installed</source>
        <translation>el módulo &quot;%1&quot; no está instalado</translation>
    </message>
    <message>
        <source>module &quot;%1&quot; version %2.%3 is not installed</source>
        <translation>el módulo &quot;%1&quot; versión %2.%3 no está instalado</translation>
    </message>
    <message>
        <source>- nested namespaces not allowed</source>
        <translation>- no se permiten espacios de nombres anidados</translation>
    </message>
    <message>
        <source>plugin cannot be loaded for module &quot;%1&quot;: %2</source>
        <translation>el complemento no se puede cargar para el módulo &quot;%1&quot;: %2</translation>
    </message>
    <message>
        <source>is instantiated recursively</source>
        <translation>se instancia recursivamente</translation>
    </message>
    <message>
        <source>is ambiguous. Found in %1 in version %2.%3 and %4.%5</source>
        <translation>es ambiguo. Encontrado en %1 en versión %2.%3 y %4.%5</translation>
    </message>
    <message>
        <source>&quot;%1&quot;: no such directory</source>
        <translation>&quot;%1&quot;: no existe tal directorio</translation>
    </message>
</context>
<context>
    <name>QXml</name>
    <message>
        <source>unparsed entity reference in wrong context</source>
        <translation>referencia a entidad no analizada en contexto incorrecto</translation>
    </message>
    <message>
        <source>external parsed general entity reference not allowed in DTD</source>
        <translation>referencia a entidad general externa analizada no permitida en DTD</translation>
    </message>
    <message>
        <source>wrong value for standalone declaration</source>
        <translation>valor incorrecto para la declaración independiente</translation>
    </message>
    <message>
        <source>encoding declaration or standalone declaration expected while reading the XML declaration</source>
        <translation>se esperaba una declaración de codificación o declaración independiente al leer la declaración XML</translation>
    </message>
    <message>
        <source>no error occurred</source>
        <translation>no ocurrió ningún error</translation>
    </message>
    <message>
        <source>error occurred while parsing reference</source>
        <translation>ocurrió un error al analizar la referencia</translation>
    </message>
    <message>
        <source>standalone declaration expected while reading the XML declaration</source>
        <translation>se esperaba una declaración independiente al leer la declaración XML</translation>
    </message>
    <message>
        <source>invalid name for processing instruction</source>
        <translation>nombre no válido para la instrucción de procesamiento</translation>
    </message>
    <message>
        <source>error triggered by consumer</source>
        <translation>error provocado por el consumidor</translation>
    </message>
    <message>
        <source>error occurred while parsing element</source>
        <translation>se produjo un error al analizar el elemento</translation>
    </message>
    <message>
        <source>unexpected character</source>
        <translation>carácter inesperado</translation>
    </message>
    <message>
        <source>tag mismatch</source>
        <translation>desajuste de etiqueta</translation>
    </message>
    <message>
        <source>error occurred while parsing content</source>
        <translation>se produjo un error al analizar el contenido</translation>
    </message>
    <message>
        <source>error occurred while parsing comment</source>
        <translation>ocurrió un error al analizar el comentario</translation>
    </message>
    <message>
        <source>internal general entity reference not allowed in DTD</source>
        <translation>no se permite la referencia a entidad general interna en el DTD</translation>
    </message>
    <message>
        <source>recursive entities</source>
        <translation>entidades recursivas</translation>
    </message>
    <message>
        <source>more than one document type definition</source>
        <translation>más de una definición de tipo de documento</translation>
    </message>
    <message>
        <source>version expected while reading the XML declaration</source>
        <translation>se esperaba la versión al leer la declaración XML</translation>
    </message>
    <message>
        <source>letter is expected</source>
        <translation>se espera una letra</translation>
    </message>
    <message>
        <source>unexpected end of file</source>
        <translation>fin de archivo inesperado</translation>
    </message>
    <message>
        <source>external parsed general entity reference not allowed in attribute value</source>
        <translation>no se permite la referencia a entidad general externa analizada en el valor del atributo</translation>
    </message>
    <message>
        <source>error in the text declaration of an external entity</source>
        <translation>error en la declaración de texto de una entidad externa</translation>
    </message>
    <message>
        <source>error occurred while parsing document type definition</source>
        <translation>se produjo un error al analizar la definición del tipo de documento</translation>
    </message>
</context>
<context>
    <name>QCoreApplication</name>
    <message>
        <source>%1: does not exist</source>
        <translation>%1: no existe</translation>
    </message>
    <message>
        <source>%1: key is empty</source>
        <translation>%1: la clave está vacía</translation>
    </message>
    <message>
        <source>%1: already exists</source>
        <translation>%1: ya existe</translation>
    </message>
    <message>
        <source>%1: unknown error %2</source>
        <translation>%1: error desconocido %2</translation>
    </message>
    <message>
        <source>%1: unable to make key</source>
        <translation>%1: no se puede crear la clave</translation>
    </message>
    <message>
        <source>%1: ftok failed</source>
        <translation>%1: ftok falló</translation>
    </message>
    <message>
        <source>%1: out of resources</source>
        <translation>%1: sin recursos</translation>
    </message>
</context>
<context>
    <name>QSystemSemaphore</name>
    <message>
        <source>%1: does not exist</source>
        <translation>%1: no existe</translation>
    </message>
    <message>
        <source>%1: already exists</source>
        <translation>%1: ya existe</translation>
    </message>
    <message>
        <source>%1: unknown error %2</source>
        <translation>%1: error desconocido %2</translation>
    </message>
    <message>
        <source>%1: permission denied</source>
        <translation>%1: permiso denegado</translation>
    </message>
    <message>
        <source>%1: out of resources</source>
        <translation>%1: sin recursos</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::MediaObject</name>
    <message>
        <source>Error opening source: resource is compressed</source>
        <translation>Error al abrir la fuente: recurso comprimido</translation>
    </message>
    <message>
        <source>Error opening source: media type could not be determined</source>
        <translation>Error al abrir la fuente: no se pudo determinar el tipo de medio</translation>
    </message>
    <message>
        <source>Error opening source: resource not valid</source>
        <translation>Error al abrir la fuente: recurso no válido</translation>
    </message>
    <message>
        <source>Error opening source: type not supported</source>
        <translation>Error al abrir la fuente: tipo no compatible</translation>
    </message>
</context>
<context>
    <name>QDeclarativePixmap</name>
    <message>
        <source>Error decoding: %1: %2</source>
        <translation>Error al decodificar: %1: %2</translation>
    </message>
    <message>
        <source>Cannot open: %1</source>
        <translation>No se puede abrir: %1</translation>
    </message>
    <message>
        <source>Failed to get image from provider: %1</source>
        <translation>No se pudo obtener la imagen del proveedor: %1</translation>
    </message>
</context>
<context>
    <name>QSQLiteResult</name>
    <message>
        <source>Unable to fetch row</source>
        <translation>No se puede obtener la fila</translation>
    </message>
    <message>
        <source>No query</source>
        <translation>No hay consulta</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>No se puede ejecutar la declaración</translation>
    </message>
    <message>
        <source>Unable to bind parameters</source>
        <translation>No se pueden vincular los parámetros</translation>
    </message>
    <message>
        <source>Unable to reset statement</source>
        <translation>No se puede restablecer la declaración</translation>
    </message>
    <message>
        <source>Parameter count mismatch</source>
        <translation>Desajuste en el número de parámetros</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <source>Activates the program&apos;s main window</source>
        <translation>Activa la ventana principal del programa</translation>
    </message>
    <message>
        <source>Activate</source>
        <translation>Activar</translation>
    </message>
    <message>
        <source>Executable &apos;%1&apos; requires Qt %2, found Qt %3.</source>
        <translation>El ejecutable &apos;%1&apos; requiere Qt %2, se encontró Qt %3.</translation>
    </message>
    <message>
        <source>Incompatible Qt Library Error</source>
        <translation>Error de biblioteca Qt incompatible</translation>
    </message>
</context>
<context>
    <name>QDeclarativeBinding</name>
    <message>
        <source>Binding loop detected for property &quot;%1&quot;</source>
        <translation>Se detectó un bucle de enlace para la propiedad &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>QDeclarativeCompiledBindings</name>
    <message>
        <source>Binding loop detected for property &quot;%1&quot;</source>
        <translation>Se detectó un bucle de enlace para la propiedad &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>QUnicodeControlCharacterMenu</name>
    <message>
        <source>RLE Start of right-to-left embedding</source>
        <translation>RLE Inicio de la incrustación de derecha a izquierda</translation>
    </message>
    <message>
        <source>ZWSP Zero width space</source>
        <translation>ZWSP Espacio de ancho cero</translation>
    </message>
    <message>
        <source>Insert Unicode control character</source>
        <translation>Insertar carácter de control Unicode</translation>
    </message>
    <message>
        <source>LRO Start of left-to-right override</source>
        <translation>LRO Inicio de la anulación de izquierda a derecha</translation>
    </message>
    <message>
        <source>LRE Start of left-to-right embedding</source>
        <translation>LRE Inicio de la incrustación de izquierda a derecha</translation>
    </message>
    <message>
        <source>RLM Right-to-left mark</source>
        <translation>RLM Marca de derecha a izquierda</translation>
    </message>
    <message>
        <source>PDF Pop directional formatting</source>
        <translation>PDF Finalizar formato direccional</translation>
    </message>
    <message>
        <source>ZWNJ Zero width non-joiner</source>
        <translation>ZWNJ Espacio sin ancho no unidor</translation>
    </message>
    <message>
        <source>RLO Start of right-to-left override</source>
        <translation>RLO Inicio de la anulación de derecha a izquierda</translation>
    </message>
    <message>
        <source>ZWJ Zero width joiner</source>
        <translation>ZWJ Espacio sin ancho unidor</translation>
    </message>
    <message>
        <source>LRM Left-to-right mark</source>
        <translation>LRM Marca de izquierda a derecha</translation>
    </message>
</context>
<context>
    <name>QWebFrame</name>
    <message>
        <source>Request blocked</source>
        <translation>Solicitud bloqueada</translation>
    </message>
    <message>
        <source>Frame load interrupted by policy change</source>
        <translation>Carga de marco interrumpida por cambio de política</translation>
    </message>
    <message>
        <source>Request cancelled</source>
        <translation>Solicitud cancelada</translation>
    </message>
    <message>
        <source>Cannot show URL</source>
        <translation>No se puede mostrar la URL</translation>
    </message>
    <message>
        <source>File does not exist</source>
        <translation>El archivo no existe</translation>
    </message>
    <message>
        <source>Cannot show mimetype</source>
        <translation>No se puede mostrar el tipo MIME</translation>
    </message>
</context>
<context>
    <name>QHttpSocketEngine</name>
    <message>
        <source>Proxy connection refused</source>
        <translation>Conexión al proxy rechazada</translation>
    </message>
    <message>
        <source>Proxy denied connection</source>
        <translation>Conexión denegada por el proxy</translation>
    </message>
    <message>
        <source>Proxy server not found</source>
        <translation>Servidor proxy no encontrado</translation>
    </message>
    <message>
        <source>Proxy server connection timed out</source>
        <translation>Tiempo de espera agotado para la conexión al servidor proxy</translation>
    </message>
    <message>
        <source>Did not receive HTTP response from proxy</source>
        <translation>No se recibió respuesta HTTP del proxy</translation>
    </message>
    <message>
        <source>Proxy connection closed prematurely</source>
        <translation>Conexión al proxy cerrada prematuramente</translation>
    </message>
    <message>
        <source>Error communicating with HTTP proxy</source>
        <translation>Error al comunicar con el proxy HTTP</translation>
    </message>
    <message>
        <source>Authentication required</source>
        <translation>Se requiere autenticación</translation>
    </message>
    <message>
        <source>Error parsing authentication request from proxy</source>
        <translation>Error al analizar la solicitud de autenticación del proxy</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessManager</name>
    <message>
        <source>Network access is disabled.</source>
        <translation>El acceso a la red está deshabilitado.</translation>
    </message>
</context>
<context>
    <name>QNetworkReply</name>
    <message>
        <source>Error downloading %1 - server replied: %2</source>
        <translation>Error al descargar %1 - el servidor respondió: %2</translation>
    </message>
    <message>
        <source>Network session error.</source>
        <translation>Error de sesión de red.</translation>
    </message>
    <message>
        <source>Protocol &quot;%1&quot; is unknown</source>
        <translation>Protocolo &quot;%1&quot; desconocido</translation>
    </message>
    <message>
        <source>Temporary network failure.</source>
        <translation>Fallo temporal de red.</translation>
    </message>
</context>
<context>
    <name>QAbstractSpinBox</name>
    <message>
        <source>Step &amp;down</source>
        <translation>Bajar un &amp;nivel</translation>
    </message>
    <message>
        <source>&amp;Step up</source>
        <translation>&amp;Subir un nivel</translation>
    </message>
    <message>
        <source>&amp;Select All</source>
        <translation>&amp;Seleccionar Todo</translation>
    </message>
</context>
<context>
    <name>QDeclarativeXmlRoleList</name>
    <message>
        <source>An XmlListModel query must start with &apos;/&apos; or &quot;//&quot;</source>
        <translation>Una consulta XmlListModel debe comenzar con &apos;/&apos; o &quot;//&quot;</translation>
    </message>
</context>
<context>
    <name>QDB2Result</name>
    <message>
        <source>Unable to bind variable</source>
        <translation>No se puede enlazar la variable</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>No se puede ejecutar la declaración</translation>
    </message>
    <message>
        <source>Unable to fetch next</source>
        <translation>No se puede obtener el siguiente</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>No se puede preparar la declaración</translation>
    </message>
    <message>
        <source>Unable to fetch record %1</source>
        <translation>No se puede obtener el registro %1</translation>
    </message>
    <message>
        <source>Unable to fetch first</source>
        <translation>No se puede obtener el primero</translation>
    </message>
</context>
<context>
    <name>QODBCResult</name>
    <message>
        <source>Unable to bind variable</source>
        <translation>No se puede enlazar la variable</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>No se puede ejecutar la declaración</translation>
    </message>
    <message>
        <source>Unable to fetch next</source>
        <translation>No se puede obtener el siguiente</translation>
    </message>
    <message>
        <source>Unable to fetch last</source>
        <translation>No se puede obtener el último</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>No se puede preparar la declaración</translation>
    </message>
    <message>
        <source>Unable to fetch previous</source>
        <translation>No se puede obtener el anterior</translation>
    </message>
    <message>
        <source>Unable to fetch</source>
        <translation>No se puede obtener</translation>
    </message>
    <message>
        <source>QODBCResult::reset: Unable to set &apos;SQL_CURSOR_STATIC&apos; as statement attribute. Please check your ODBC driver configuration</source>
        <translation>QODBCResult::reset: No se puede establecer &apos;SQL_CURSOR_STATIC&apos; como atributo de la declaración. Por favor, verifique la configuración de su controlador ODBC</translation>
    </message>
    <message>
        <source>Unable to fetch first</source>
        <translation>No se puede obtener el primero</translation>
    </message>
</context>
<context>
    <name>QPSQLDriver</name>
    <message>
        <source>Unable to subscribe</source>
        <translation>No se puede suscribir</translation>
    </message>
    <message>
        <source>Could not begin transaction</source>
        <translation>No se pudo iniciar la transacción</translation>
    </message>
    <message>
        <source>Could not rollback transaction</source>
        <translation>No se pudo revertir la transacción</translation>
    </message>
    <message>
        <source>Could not commit transaction</source>
        <translation>No se pudo confirmar la transacción</translation>
    </message>
    <message>
        <source>Unable to connect</source>
        <translation>No se puede conectar</translation>
    </message>
    <message>
        <source>Unable to unsubscribe</source>
        <translation>No se puede cancelar la suscripción</translation>
    </message>
</context>
<context>
    <name>QInputDialog</name>
    <message>
        <source>Enter a value:</source>
        <translation>Ingrese un valor:</translation>
    </message>
</context>
<context>
    <name>QIODevice</name>
    <message>
        <source>No such file or directory</source>
        <translation>No existe tal archivo o directorio</translation>
    </message>
    <message>
        <source>Permission denied</source>
        <translation>Permiso denegado</translation>
    </message>
    <message>
        <source>No space left on device</source>
        <translation>No hay espacio disponible en el dispositivo</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
    <message>
        <source>Too many open files</source>
        <translation>Demasiados archivos abiertos</translation>
    </message>
</context>
<context>
    <name>FakeReply</name>
    <message>
        <source>Invalid URL</source>
        <translation>URL inválida</translation>
    </message>
    <message>
        <source>Fake error !</source>
        <translation>¡Error falso!</translation>
    </message>
</context>
<context>
    <name>QMultiInputContext</name>
    <message>
        <source>Select IM</source>
        <translation>Seleccionar IM</translation>
    </message>
</context>
<context>
    <name>QTabBar</name>
    <message>
        <source>Scroll Left</source>
        <translation>Desplazar a la izquierda</translation>
    </message>
    <message>
        <source>Scroll Right</source>
        <translation>Desplazar a la derecha</translation>
    </message>
</context>
<context>
    <name>QUndoModel</name>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;vacío&gt;</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessCacheBackend</name>
    <message>
        <source>Error opening %1</source>
        <translation>Error al abrir %1</translation>
    </message>
</context>
<context>
    <name>QDeclarativeParser</name>
    <message>
        <source>Script import qualifiers must be unique.</source>
        <translation>Los calificadores de importación de scripts deben ser únicos.</translation>
    </message>
    <message>
        <source>Unterminated regular expression class</source>
        <translation>Clase de expresión regular sin terminar</translation>
    </message>
    <message>
        <source>Library import requires a version</source>
        <translation>La importación de la biblioteca requiere una versión</translation>
    </message>
    <message>
        <source>Invalid regular expression flag &apos;%0&apos;</source>
        <translation>Bandera de expresión regular no válida &apos;%0&apos;</translation>
    </message>
    <message>
        <source>JavaScript declaration outside Script element</source>
        <translation>Declaración de JavaScript fuera del elemento Script</translation>
    </message>
    <message>
        <source>Illegal character</source>
        <translation>Carácter ilegal</translation>
    </message>
    <message>
        <source>Unclosed comment at end of file</source>
        <translation>Comentario sin cerrar al final del archivo</translation>
    </message>
    <message>
        <source>Unclosed string at end of line</source>
        <translation>Cadena sin cerrar al final de la línea</translation>
    </message>
    <message>
        <source>Expected property type</source>
        <translation>Tipo de propiedad esperado</translation>
    </message>
    <message>
        <source>Expected type name</source>
        <translation>Nombre de tipo esperado</translation>
    </message>
    <message>
        <source>Illegal escape sequence</source>
        <translation>Seq de escape ilegal</translation>
    </message>
    <message>
        <source>Readonly not yet supported</source>
        <translation>Readonly aún no es compatible</translation>
    </message>
    <message>
        <source>Unterminated regular expression literal</source>
        <translation>Literal de expresión regular sin terminar</translation>
    </message>
    <message>
        <source>Property value set multiple times</source>
        <translation>Valor de propiedad establecido varias veces</translation>
    </message>
    <message>
        <source>Unterminated regular expression backslash sequence</source>
        <translation>Seq de barra invertida de expresión regular sin terminar</translation>
    </message>
    <message>
        <source>Identifier cannot start with numeric literal</source>
        <translation>El identificador no puede comenzar con un literal numérico</translation>
    </message>
    <message>
        <source>Script import requires a qualifier</source>
        <translation>La importación de script requiere un calificador</translation>
    </message>
    <message>
        <source>Illegal syntax for exponential number</source>
        <translation>Sintaxis ilegal para número exponencial</translation>
    </message>
    <message>
        <source>Invalid property type modifier</source>
        <translation>Modificador de tipo de propiedad no válido</translation>
    </message>
    <message>
        <source>Reserved name &quot;Qt&quot; cannot be used as an qualifier</source>
        <translation>El nombre reservado &quot;Qt&quot; no puede usarse como calificador</translation>
    </message>
    <message>
        <source>Expected token `%1&apos;</source>
        <translation>Token esperado `%1&apos;</translation>
    </message>
    <message>
        <source>Unexpected token `%1&apos;</source>
        <translation>Token inesperado `%1&apos;</translation>
    </message>
    <message>
        <source>Expected parameter type</source>
        <translation>Tipo de parámetro esperado</translation>
    </message>
    <message>
        <source>Illegal unicode escape sequence</source>
        <translation>Seq de escape unicode ilegal</translation>
    </message>
    <message>
        <source>Unexpected property type modifier</source>
        <translation>Modificador de tipo de propiedad inesperado</translation>
    </message>
    <message>
        <source>Invalid import qualifier ID</source>
        <translation>ID de calificador de importación no válido</translation>
    </message>
    <message>
        <source>Syntax error</source>
        <translation>Error de sintaxis</translation>
    </message>
</context>
<context>
    <name>QScriptEdit</name>
    <message>
        <source>Disable Breakpoint</source>
        <translation>Deshabilitar punto de interrupción</translation>
    </message>
    <message>
        <source>Breakpoint Condition:</source>
        <translation>Condición del punto de interrupción:</translation>
    </message>
    <message>
        <source>Toggle Breakpoint</source>
        <translation>Alternar punto de interrupción</translation>
    </message>
    <message>
        <source>Enable Breakpoint</source>
        <translation>Habilitar punto de interrupción</translation>
    </message>
</context>
<context>
    <name>QMYSQLResult</name>
    <message>
        <source>Unable to execute statement</source>
        <translation>No se puede ejecutar la declaración</translation>
    </message>
    <message>
        <source>Unable to store statement results</source>
        <translation>No se pueden almacenar los resultados de la declaración</translation>
    </message>
    <message>
        <source>Unable to execute next query</source>
        <translation>No se puede ejecutar la siguiente consulta</translation>
    </message>
    <message>
        <source>Unable to bind outvalues</source>
        <translation>No se pueden enlazar los valores de salida</translation>
    </message>
    <message>
        <source>Unable to store next result</source>
        <translation>No se puede almacenar el siguiente resultado</translation>
    </message>
    <message>
        <source>Unable to fetch data</source>
        <translation>No se pueden obtener datos</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>No se puede preparar la declaración</translation>
    </message>
    <message>
        <source>Unable to store result</source>
        <translation>No se puede almacenar el resultado</translation>
    </message>
    <message>
        <source>Unable to bind value</source>
        <translation>No se puede enlazar el valor</translation>
    </message>
    <message>
        <source>Unable to execute query</source>
        <translation>No se puede ejecutar la consulta</translation>
    </message>
    <message>
        <source>Unable to reset statement</source>
        <translation>No se puede restablecer la declaración</translation>
    </message>
</context>
<context>
    <name>QSQLite2Result</name>
    <message>
        <source>Unable to execute statement</source>
        <translation>No se puede ejecutar la declaración</translation>
    </message>
    <message>
        <source>Unable to fetch results</source>
        <translation>No se pueden obtener los resultados</translation>
    </message>
</context>
<context>
    <name>Phonon::AudioOutput</name>
    <message>
        <source>&lt;html&gt;Switching to the audio playback device &lt;b&gt;%1&lt;/b&gt;&lt;br/&gt;which has higher preference or is specifically configured for this stream.&lt;/html&gt;</source>
        <translation>&lt;html&gt;Cambiando al dispositivo de reproducción de audio &lt;b&gt;%1&lt;/b&gt;que tiene mayor preferencia o está configurado específicamente para esta transmisión.&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;The audio playback device &lt;b&gt;%1&lt;/b&gt; does not work.&lt;br/&gt;Falling back to &lt;b&gt;%2&lt;/b&gt;.&lt;/html&gt;</source>
        <translation>&lt;html&gt;El dispositivo de reproducción de audio &lt;b&gt;%1&lt;/b&gt; no funciona.Volviendo a &lt;b&gt;%2&lt;/b&gt;.&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Revert back to device &apos;%1&apos;</source>
        <translation>Revertir al dispositivo &apos;%1&apos;</translation>
    </message>
    <message>
        <source>&lt;html&gt;Switching to the audio playback device &lt;b&gt;%1&lt;/b&gt;&lt;br/&gt;which just became available and has higher preference.&lt;/html&gt;</source>
        <translation>&lt;html&gt;Cambiando al dispositivo de reproducción de audio &lt;b&gt;%1&lt;/b&gt;que acaba de estar disponible y tiene mayor preferencia.&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>Q3MainWindow</name>
    <message>
        <source>Line up</source>
        <translation>Línea arriba</translation>
    </message>
    <message>
        <source>Customize...</source>
        <translation>Personalizar...</translation>
    </message>
</context>
<context>
    <name>QUdpSocket</name>
    <message>
        <source>This platform does not support IPv6</source>
        <translation>Esta plataforma no soporta IPv6</translation>
    </message>
</context>
<context>
    <name>Phonon::Gstreamer::Backend</name>
    <message>
        <source>Warning: You do not seem to have the base GStreamer plugins installed.
          All audio and video support has been disabled</source>
        <translation>Advertencia: Parece que no tienes instalados los plugins base de GStreamer.
          Todo el soporte de audio y video ha sido deshabilitado</translation>
    </message>
    <message>
        <source>Warning: You do not seem to have the package gstreamer0.10-plugins-good installed.
          Some video features have been disabled.</source>
        <translation>Advertencia: Parece que no tienes instalado el paquete gstreamer0.10-plugins-good.
          Algunas funciones de video han sido deshabilitadas.</translation>
    </message>
</context>
<context>
    <name>QDeclarativePropertyChanges</name>
    <message>
        <source>Cannot assign to read-only property &quot;%1&quot;</source>
        <translation>No se puede asignar a una propiedad de solo lectura &quot;%1&quot;</translation>
    </message>
    <message>
        <source>PropertyChanges does not support creating state-specific objects.</source>
        <translation>PropertyChanges no admite la creación de objetos específicos de estado.</translation>
    </message>
    <message>
        <source>Cannot assign to non-existent property &quot;%1&quot;</source>
        <translation>No se puede asignar a la propiedad inexistente &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>QLocalServer</name>
    <message>
        <source>%1: Name error</source>
        <translation>%1: Error de nombre</translation>
    </message>
    <message>
        <source>%1: Unknown error %2</source>
        <translation>%1: Error desconocido %2</translation>
    </message>
    <message>
        <source>%1: Permission denied</source>
        <translation>%1: Permiso denegado</translation>
    </message>
    <message>
        <source>%1: Address in use</source>
        <translation>%1: Dirección en uso</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::AbstractVideoPlayer</name>
    <message>
        <source>Pause failed</source>
        <translation>Error al pausar</translation>
    </message>
    <message>
        <source>Seek failed</source>
        <translation>Error al buscar</translation>
    </message>
    <message>
        <source>Opening clip failed</source>
        <translation>Error al abrir el clip</translation>
    </message>
    <message>
        <source>Getting position failed</source>
        <translation>Error al obtener la posición</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::AbstractMediaPlayer</name>
    <message>
        <source>Not ready to play</source>
        <translation>No listo para reproducir</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>Error al abrir el archivo</translation>
    </message>
    <message>
        <source>Error opening source: resource not opened</source>
        <translation>Error al abrir la fuente: recurso no abierto</translation>
    </message>
    <message>
        <source>Error opening URL</source>
        <translation>Error al abrir URL</translation>
    </message>
    <message>
        <source>Loading clip failed</source>
        <translation>Error al cargar el clip</translation>
    </message>
    <message>
        <source>Setting volume failed</source>
        <translation>Error al ajustar el volumen</translation>
    </message>
    <message>
        <source>Error opening resource</source>
        <translation>Error al abrir el recurso</translation>
    </message>
    <message>
        <source>Playback complete</source>
        <translation>Reproducción completa</translation>
    </message>
</context>
<context>
    <name>QDeclarativeAbstractAnimation</name>
    <message>
        <source>Animation is an abstract class</source>
        <translation>La animación es una clase abstracta</translation>
    </message>
    <message>
        <source>Cannot animate non-existent property &quot;%1&quot;</source>
        <translation>No se puede animar la propiedad inexistente &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Cannot animate read-only property &quot;%1&quot;</source>
        <translation>No se puede animar la propiedad de solo lectura &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>QDeclarativeFlipable</name>
    <message>
        <source>front is a write-once property</source>
        <translation>front es una propiedad de solo escritura</translation>
    </message>
    <message>
        <source>back is a write-once property</source>
        <translation>back es una propiedad de solo escritura</translation>
    </message>
</context>
<context>
    <name>Q3ToolBar</name>
    <message>
        <source>More...</source>
        <translation>Más...</translation>
    </message>
</context>
<context>
    <name>QDeclarativeParentAnimation</name>
    <message>
        <source>Unable to preserve appearance under non-uniform scale</source>
        <translation>No se puede preservar la apariencia bajo una escala no uniforme</translation>
    </message>
    <message>
        <source>Unable to preserve appearance under complex transform</source>
        <translation>No se puede preservar la apariencia bajo una transformación compleja</translation>
    </message>
    <message>
        <source>Unable to preserve appearance under scale of 0</source>
        <translation>No se puede preservar la apariencia bajo una escala de 0</translation>
    </message>
</context>
<context>
    <name>QDeclarativeParentChange</name>
    <message>
        <source>Unable to preserve appearance under non-uniform scale</source>
        <translation>No se puede preservar la apariencia bajo una escala no uniforme</translation>
    </message>
    <message>
        <source>Unable to preserve appearance under complex transform</source>
        <translation>No se puede preservar la apariencia bajo una transformación compleja</translation>
    </message>
    <message>
        <source>Unable to preserve appearance under scale of 0</source>
        <translation>No se puede preservar la apariencia bajo una escala de 0</translation>
    </message>
</context>
<context>
    <name>QMultiInputContextPlugin</name>
    <message>
        <source>Multiple input method switcher that uses the context menu of the text widgets</source>
        <translation>Conmutador de métodos de entrada múltiple que utiliza el menú contextual de los widgets de texto</translation>
    </message>
    <message>
        <source>Multiple input method switcher</source>
        <translation>Conmutador de métodos de entrada múltiple</translation>
    </message>
</context>
<context>
    <name>QGuiApplication</name>
    <message>
        <source>QT_LAYOUT_DIRECTION</source>
        <translation>QT_LAYOUT_DIRECTION</translation>
    </message>
</context>
<context>
    <name>Q3ProgressDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>QProgressDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>QDeclarativeComponent</name>
    <message>
        <source>Invalid empty URL</source>
        <translation>URL vacía inválida</translation>
    </message>
</context>
<context>
    <name>MAC_APPLICATION_MENU</name>
    <message>
        <source>Hide Others</source>
        <translation>Ocultar otros</translation>
    </message>
    <message>
        <source>Quit %1</source>
        <translation>Salir de %1</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation>Acerca de %1</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>Preferencias...</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Servicios</translation>
    </message>
    <message>
        <source>Hide %1</source>
        <translation>Ocultar %1</translation>
    </message>
    <message>
        <source>Show All</source>
        <translation>Mostrar todo</translation>
    </message>
</context>
<context>
    <name>QLibrary</name>
    <message>
        <source>Cannot unload library %1: %2</source>
        <translation>No se puede descargar la biblioteca %1: %2</translation>
    </message>
    <message>
        <source>Cannot load library %1: %2</source>
        <translation>No se puede cargar la biblioteca %1: %2</translation>
    </message>
    <message>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. (%2.%3.%4) [%5]</source>
        <translation>El complemento &apos;%1&apos; utiliza una biblioteca Qt incompatible. (%2.%3.%4) [%5]</translation>
    </message>
    <message>
        <source>Cannot resolve symbol &quot;%1&quot; in %2: %3</source>
        <translation>No se puede resolver el símbolo &quot;%1&quot; en %2: %3</translation>
    </message>
    <message>
        <source>Plugin verification data mismatch in &apos;%1&apos;</source>
        <translation>Desajuste de datos de verificación del complemento en &apos;%1&apos;</translation>
    </message>
    <message>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. (Cannot mix debug and release libraries.)</source>
        <translation>El complemento &apos;%1&apos; utiliza una biblioteca Qt incompatible. (No se pueden mezclar bibliotecas de depuración y liberación.)</translation>
    </message>
    <message>
        <source>The file &apos;%1&apos; is not a valid Qt plugin.</source>
        <translation>El archivo &apos;%1&apos; no es un complemento Qt válido.</translation>
    </message>
    <message>
        <source>The shared library was not found.</source>
        <translation>No se encontró la biblioteca compartida.</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
    <message>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. Expected build key &quot;%2&quot;, got &quot;%3&quot;</source>
        <translation>El complemento &apos;%1&apos; utiliza una biblioteca Qt incompatible. Se esperaba la clave de compilación &quot;%2&quot;, se obtuvo &quot;%3&quot;</translation>
    </message>
</context>
<context>
    <name>QTDSDriver</name>
    <message>
        <source>Unable to open connection</source>
        <translation>No se puede abrir la conexión</translation>
    </message>
    <message>
        <source>Unable to use database</source>
        <translation>No se puede usar la base de datos</translation>
    </message>
</context>
<context>
    <name>QDeclarativeVisualDataModel</name>
    <message>
        <source>Delegate component must be Item type.</source>
        <translation>El componente delegado debe ser del tipo Item.</translation>
    </message>
</context>
<context>
    <name>QDeclarativeConnections</name>
    <message>
        <source>Connections: script expected</source>
        <translation>Conexiones: se esperaba script</translation>
    </message>
    <message>
        <source>Connections: nested objects not allowed</source>
        <translation>Conexiones: objetos anidados no permitidos</translation>
    </message>
    <message>
        <source>Cannot assign to non-existent property &quot;%1&quot;</source>
        <translation>No se puede asignar a la propiedad inexistente &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Connections: syntax error</source>
        <translation>Conexiones: error de sintaxis</translation>
    </message>
</context>
<context>
    <name>QPluginLoader</name>
    <message>
        <source>The plugin was not loaded.</source>
        <translation>El complemento no se cargó.</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
</context>
<context>
    <name>QSlider</name>
    <message>
        <source>Page up</source>
        <translation>Página arriba</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <source>Page right</source>
        <translation>Página derecha</translation>
    </message>
    <message>
        <source>Page down</source>
        <translation>Página abajo</translation>
    </message>
    <message>
        <source>Page left</source>
        <translation>Página izquierda</translation>
    </message>
</context>
<context>
    <name>CloseButton</name>
    <message>
        <source>Close Tab</source>
        <translation>Cerrar pestaña</translation>
    </message>
</context>
<context>
    <name>QPSQLResult</name>
    <message>
        <source>Unable to prepare statement</source>
        <translation>No se puede preparar la declaración</translation>
    </message>
    <message>
        <source>Unable to create query</source>
        <translation>No se puede crear la consulta</translation>
    </message>
</context>
<context>
    <name>QNetworkSession</name>
    <message>
        <source>Invalid configuration.</source>
        <translation>Configuración inválida.</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessDataBackend</name>
    <message>
        <source>Invalid URI: %1</source>
        <translation>URI inválido: %1</translation>
    </message>
    <message>
        <source>Operation not supported on %1</source>
        <translation>Operación no soportada en %1</translation>
    </message>
</context>
<context>
    <name>QDeclarativeAnimatedImage</name>
    <message>
        <source>Qt was built without support for QMovie</source>
        <translation>Qt fue compilado sin soporte para QMovie</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>&quot;%1&quot; duplicates a previous role name and will be disabled.</source>
        <translation>&quot;%1&quot; duplica un nombre de rol anterior y será deshabilitado.</translation>
    </message>
    <message>
        <source>PulseAudio Sound Server</source>
        <translation>Servidor de Sonido PulseAudio</translation>
    </message>
    <message>
        <source>invalid query: &quot;%1&quot;</source>
        <translation>consulta inválida: &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>QDeclarativeKeysAttached</name>
    <message>
        <source>Keys is only available via attached properties</source>
        <translation>Keys solo está disponible a través de propiedades adjuntas</translation>
    </message>
</context>
<context>
    <name>QMenuBar</name>
    <message>
        <source>Actions</source>
        <translation>Acciones</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessDebugPipeBackend</name>
    <message>
        <source>Socket error on %1: %2</source>
        <translation>Error de socket en %1: %2</translation>
    </message>
    <message>
        <source>Remote host closed the connection prematurely on %1</source>
        <translation>El host remoto cerró la conexión prematuramente en %1</translation>
    </message>
    <message>
        <source>Write error writing to %1: %2</source>
        <translation>Error de escritura al escribir en %1: %2</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessFileBackend</name>
    <message>
        <source>Request for opening non-local file %1</source>
        <translation>Solicitud para abrir archivo no local %1</translation>
    </message>
    <message>
        <source>Read error reading from %1: %2</source>
        <translation>Error de lectura al leer desde %1: %2</translation>
    </message>
    <message>
        <source>Cannot open %1: Path is a directory</source>
        <translation>No se puede abrir %1: La ruta es un directorio</translation>
    </message>
    <message>
        <source>Error opening %1: %2</source>
        <translation>Error al abrir %1: %2</translation>
    </message>
    <message>
        <source>Write error writing to %1: %2</source>
        <translation>Error de escritura al escribir en %1: %2</translation>
    </message>
</context>
<context>
    <name>QHostInfo</name>
    <message>
        <source>No host name given</source>
        <translation>No se proporcionó un nombre de host</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
</context>
<context>
    <name>QDeclarativeLoader</name>
    <message>
        <source>Loader does not support loading non-visual elements.</source>
        <translation>Loader no soporta la carga de elementos no visuales.</translation>
    </message>
</context>
<context>
    <name>QNetworkReplyImpl</name>
    <message>
        <source>Operation canceled</source>
        <translation>Operación cancelada</translation>
    </message>
</context>
<context>
    <name>Q3NetworkProtocol</name>
    <message>
        <source>Operation stopped by the user</source>
        <translation>Operación detenida por el usuario</translation>
    </message>
</context>
<context>
    <name>QStateMachine</name>
    <message>
        <source>Missing default state in history state &apos;%1&apos;</source>
        <translation>Falta el estado predeterminado en el estado de historial &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
    <message>
        <source>Missing initial state in compound state &apos;%1&apos;</source>
        <translation>Falta el estado inicial en el estado compuesto &apos;%1&apos;</translation>
    </message>
    <message>
        <source>No common ancestor for targets and source of transition from state &apos;%1&apos;</source>
        <translation>No hay un ancestro común para los objetivos y la fuente de la transición desde el estado &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>QMdiArea</name>
    <message>
        <source>(Untitled)</source>
        <translation>(Sin título)</translation>
    </message>
</context>
<context>
    <name>QDeclarativeXmlListModelRole</name>
    <message>
        <source>An XmlRole query must not start with &apos;/&apos;</source>
        <translation>Una consulta XmlRole no debe comenzar con &apos;/&apos;</translation>
    </message>
</context>
<context>
    <name>QDeclarativeBehavior</name>
    <message>
        <source>Cannot change the animation assigned to a Behavior.</source>
        <translation>No se puede cambiar la animación asignada a un Comportamiento.</translation>
    </message>
</context>
<context>
    <name>Q3Accel</name>
    <message>
        <source>%1, %2 not defined</source>
        <translation>%1, %2 no definidos</translation>
    </message>
    <message>
        <source>Ambiguous %1 not handled</source>
        <translation>%1 ambiguo no manejado</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::EffectFactory</name>
    <message>
        <source>Enabled</source>
        <translation>Habilitado</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::DsaVideoPlayer</name>
    <message>
        <source>Video display error</source>
        <translation>Error de visualización de video</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::SurfaceVideoPlayer</name>
    <message>
        <source>Video display error</source>
        <translation>Error de visualización de video</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::StereoWidening</name>
    <message>
        <source>Level (%)</source>
        <translation>Nivel (%)</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::AudioPlayer</name>
    <message>
        <source>Getting position failed</source>
        <translation>Error al obtener la posición</translation>
    </message>
</context>
<context>
    <name>QDeclarativeKeyNavigationAttached</name>
    <message>
        <source>KeyNavigation is only available via attached properties</source>
        <translation>KeyNavigation solo está disponible a través de propiedades adjuntas</translation>
    </message>
</context>
<context>
    <name>QDeclarativeAnchorAnimation</name>
    <message>
        <source>Cannot set a duration of &lt; 0</source>
        <translation>No se puede establecer una duración de &lt; 0</translation>
    </message>
</context>
<context>
    <name>QDeclarativePauseAnimation</name>
    <message>
        <source>Cannot set a duration of &lt; 0</source>
        <translation>No se puede establecer una duración de &lt; 0</translation>
    </message>
</context>
<context>
    <name>QDeclarativePropertyAnimation</name>
    <message>
        <source>Cannot set a duration of &lt; 0</source>
        <translation>No se puede establecer una duración de &lt; 0</translation>
    </message>
</context>
<context>
    <name>QTcpServer</name>
    <message>
        <source>Operation on socket is not supported</source>
        <translation>La operación en el socket no es compatible</translation>
    </message>
</context>
<context>
    <name>QDeclarativeXmlListModel</name>
    <message>
        <source>Qt was built without support for xmlpatterns</source>
        <translation>Qt fue construido sin soporte para xmlpatterns</translation>
    </message>
</context>
</TS>
