<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>ComTableFilter</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table_filter.ui" line="37"/>
        <source>内容筛选</source>
        <translation type="unfinished">Filter content</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table_filter.ui" line="57"/>
        <source>清空条件</source>
        <translation type="unfinished">Clear conditions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table_filter.ui" line="87"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table_filter.ui" line="94"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
</context>
<context>
    <name>DateTimeWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.ui" line="109"/>
        <source>yyyy/MM/dd</source>
        <translation type="unfinished">yyyy/MM/dd</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.ui" line="202"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="18"/>
        <source>6月</source>
        <translation type="unfinished">Jun</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.ui" line="238"/>
        <source>2022年</source>
        <translation type="unfinished">2022</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.ui" line="359"/>
        <source>日</source>
        <translation type="unfinished">Day</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.ui" line="384"/>
        <source>一</source>
        <translation type="unfinished">Mon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.ui" line="409"/>
        <source>二</source>
        <translation type="unfinished">Tue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.ui" line="434"/>
        <source>三</source>
        <translation type="unfinished">Wed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.ui" line="459"/>
        <source>四</source>
        <translation type="unfinished">Thu</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.ui" line="484"/>
        <source>五</source>
        <translation type="unfinished">Fri</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.ui" line="509"/>
        <source>六</source>
        <translation type="unfinished">Sat</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.ui" line="641"/>
        <source>HH:mm:ss</source>
        <translation type="unfinished">HH:mm:ss</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.ui" line="779"/>
        <source>今日</source>
        <translation type="unfinished">Today</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.ui" line="795"/>
        <source>现在</source>
        <translation type="unfinished">Now</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.ui" line="831"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.ui" line="847"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="13"/>
        <source>1月</source>
        <translation type="unfinished">Jan</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="14"/>
        <source>2月</source>
        <translation type="unfinished">Feb</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="15"/>
        <source>3月</source>
        <translation type="unfinished">Mar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="16"/>
        <source>4月</source>
        <translation type="unfinished">Apr</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="17"/>
        <source>5月</source>
        <translation type="unfinished">May</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="19"/>
        <source>7月</source>
        <translation type="unfinished">Jul</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="20"/>
        <source>8月</source>
        <translation type="unfinished">Aug</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="21"/>
        <source>9月</source>
        <translation type="unfinished">Sept</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="22"/>
        <source>10月</source>
        <translation type="unfinished">Oct</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="23"/>
        <source>11月</source>
        <translation type="unfinished">Nov</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="24"/>
        <source>12月</source>
        <translation type="unfinished">Dec</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="70"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="354"/>
        <source>%1</source>
        <comment>buttonName</comment>
        <translation type="unfinished"> %1 </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="149"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="278"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="293"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="326"/>
        <source>%1年</source>
        <comment>buttonName</comment>
        <translation type="unfinished">%1 Year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="371"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="403"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_combobox/date_time_widget.cpp" line="420"/>
        <source>%1年</source>
        <translation type="unfinished">%1 year(s)</translation>
    </message>
</context>
<context>
    <name>FindReplaceBaseDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.ui" line="14"/>
        <source>查找和替换</source>
        <translation type="unfinished">Find and replace</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.ui" line="35"/>
        <source>查找内容:</source>
        <translation type="unfinished">Search content:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.ui" line="82"/>
        <source>替换下一个(ALT+F)</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Replace next(ALT+F)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.ui" line="89"/>
        <source>替换上一个(ALT+V)</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Replace previous(ALT+V)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.ui" line="109"/>
        <source>替换全部(ALT+I)</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Replace all(ALT+I)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.ui" line="116"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.ui" line="175"/>
        <source>关闭</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.ui" line="154"/>
        <source>查找全部(ALT+I)</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Find all(ALT+I)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.ui" line="161"/>
        <source>查找上一个(ALT+V)</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Find previous (ALT+V)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.ui" line="168"/>
        <source>查找下一个(ALT+F)</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Find next (ALT+F)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.ui" line="200"/>
        <source>查找</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Find</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.ui" line="280"/>
        <source>替换</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Replace</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.ui" line="254"/>
        <source>区分大小写</source>
        <translation type="unfinished">Case sensitive</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.ui" line="261"/>
        <source>替换为:</source>
        <translation type="unfinished">Replaced to:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.ui" line="293"/>
        <source>全字匹配</source>
        <translation type="unfinished">Match whole word</translation>
    </message>
</context>
<context>
    <name>RollingCalendar</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_calendar.ui" line="168"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
</context>
<context>
    <name>RollingSection</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="12"/>
        <source>1月</source>
        <translation type="unfinished">Jan</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="13"/>
        <source>2月</source>
        <translation type="unfinished">Feb</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="14"/>
        <source>3月</source>
        <translation type="unfinished">Mar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="15"/>
        <source>4月</source>
        <translation type="unfinished">Apr</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="16"/>
        <source>5月</source>
        <translation type="unfinished">May</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="17"/>
        <source>6月</source>
        <translation type="unfinished">Jun</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="18"/>
        <source>7月</source>
        <translation type="unfinished">Jul</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="19"/>
        <source>8月</source>
        <translation type="unfinished">Aug</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="20"/>
        <source>9月</source>
        <translation type="unfinished">Sept</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="21"/>
        <source>10月</source>
        <translation type="unfinished">Oct</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="22"/>
        <source>11月</source>
        <translation type="unfinished">Nov</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="23"/>
        <source>12月</source>
        <translation type="unfinished">Dec</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="226"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="282"/>
        <source>月</source>
        <translation type="unfinished">month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="278"/>
        <source>年</source>
        <translation type="unfinished">year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="286"/>
        <source>日</source>
        <translation type="unfinished">day</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="290"/>
        <source>时</source>
        <translation type="unfinished">h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="294"/>
        <source>分</source>
        <comment>Time</comment>
        <translation type="unfinished">min</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/datetime_edit/rolling_section.cpp" line="298"/>
        <source>秒</source>
        <translation type="unfinished">sec</translation>
    </message>
</context>
<context>
    <name>iasp::gui::ApiSysTemTray</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/system_tray/api_system_tray.cpp" line="82"/>
        <source>主界面</source>
        <comment>menuName</comment>
        <translation type="unfinished">Main interface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/system_tray/api_system_tray.cpp" line="86"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/system_tray/api_system_tray.cpp" line="90"/>
        <source>退出</source>
        <comment>menuName</comment>
        <translation type="unfinished">Exit</translation>
    </message>
</context>
<context>
    <name>iasp::gui::ColorBase</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/color_select/color_base.cpp" line="43"/>
        <source>其他颜色</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Other colors</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/color_select/color_base.cpp" line="46"/>
        <source>其他颜色</source>
        <translation type="unfinished">Other colors</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/color_select/color_base.cpp" line="109"/>
        <source>选择颜色</source>
        <translation type="unfinished">Choose color</translation>
    </message>
</context>
<context>
    <name>iasp::gui::ComDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_dialog/com_dialog.cpp" line="59"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_dialog/com_dialog.cpp" line="60"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_dialog/com_dialog.cpp" line="61"/>
        <source>其他</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Other</translation>
    </message>
</context>
<context>
    <name>iasp::gui::ComFileDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_file_dialog/com_file_dialog.cpp" line="309"/>
        <source>禁止输入包含路径导航字符</source>
        <translation type="unfinished">Prohibit input including path navigation characters</translation>
    </message>
</context>
<context>
    <name>iasp::gui::ComLineEdit</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_lineEdit.cpp" line="64"/>
        <source>请输入数字</source>
        <translation type="unfinished">Please enter the number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_lineEdit.cpp" line="83"/>
        <source>请输入数字，精确到小数点后%1位</source>
        <translation type="unfinished">Please enter a number accurate to %1 decimal place</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_lineEdit.cpp" line="95"/>
        <source>仅支持输入数字、字母、下划线</source>
        <translation type="unfinished">Only digits, letters, and base lines are supported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_lineEdit.cpp" line="102"/>
        <source>仅支持输入字母</source>
        <translation type="unfinished">Only letters are supported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_lineEdit.cpp" line="109"/>
        <source>仅支持输入数字、字母、汉字</source>
        <translation type="unfinished">Only digits, letters, and Chinese characters are supported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_lineEdit.cpp" line="116"/>
        <source>请输入邮箱</source>
        <translation type="unfinished">Please enter email</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_lineEdit.cpp" line="124"/>
        <source>请输入ip</source>
        <translation type="unfinished">Please enter IP</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_lineEdit.cpp" line="132"/>
        <source>请输入名称</source>
        <translation type="unfinished">Please enter name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_lineEdit.cpp" line="146"/>
        <source>请输入内容，禁止输入SQL关键字</source>
        <translation type="unfinished">Please enter content, prohibit entering SQL keywords</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_lineEdit.cpp" line="45"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_lineEdit.cpp" line="205"/>
        <source>请输入内容</source>
        <translation type="unfinished">Please enter content</translation>
    </message>
</context>
<context>
    <name>iasp::gui::ComMsgBox</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_msgbox/com_msgbox.cpp" line="180"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_msgbox/com_msgbox.cpp" line="185"/>
        <source>信息</source>
        <translation type="unfinished">Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_msgbox/com_msgbox.cpp" line="251"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_msgbox/com_msgbox.cpp" line="256"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_msgbox/com_msgbox.cpp" line="331"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_msgbox/com_msgbox.cpp" line="336"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_msgbox/com_msgbox.cpp" line="407"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_msgbox/com_msgbox.cpp" line="412"/>
        <source>严重告警</source>
        <translation type="unfinished">Critical alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_msgbox/com_msgbox.cpp" line="623"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_msgbox/com_msgbox.cpp" line="624"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_msgbox/com_msgbox.cpp" line="625"/>
        <source>丢弃</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Drop</translation>
    </message>
</context>
<context>
    <name>iasp::gui::ComSearchLineEdit</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_searchlineedit.cpp" line="67"/>
        <source>请输入内容</source>
        <translation type="unfinished">Please enter content</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_searchlineedit.cpp" line="131"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_searchlineedit.cpp" line="328"/>
        <source>搜索</source>
        <translation type="unfinished">search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_searchlineedit.cpp" line="132"/>
        <source>过滤</source>
        <translation type="unfinished">filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_searchlineedit.cpp" line="148"/>
        <source>区分大小写</source>
        <translation type="unfinished">Case sensitive</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_searchlineedit.cpp" line="152"/>
        <source>全词匹配</source>
        <translation type="unfinished">Full word match</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_searchlineedit.cpp" line="156"/>
        <source>全部信息显示</source>
        <translation type="unfinished">Display all info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_searchlineedit.cpp" line="160"/>
        <source>打开文件夹</source>
        <translation type="unfinished">Open the folder</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_lineEdit/com_searchlineedit.cpp" line="323"/>
        <source>查找</source>
        <translation type="unfinished">Find</translation>
    </message>
</context>
<context>
    <name>iasp::gui::ComTable</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="341"/>
        <source>升序</source>
        <translation type="unfinished">Ascending order</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="342"/>
        <source>降序</source>
        <translation type="unfinished">Descending order</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="343"/>
        <source>自动调整列宽</source>
        <translation type="unfinished">Auto adjust column width</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="344"/>
        <source>自动调整所有列宽</source>
        <translation type="unfinished">Auto adjust all column widths</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="362"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="432"/>
        <source>筛选</source>
        <translation type="unfinished">Filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="364"/>
        <source>打印</source>
        <translation type="unfinished">Print</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="365"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="367"/>
        <source>保存为</source>
        <translation type="unfinished">Save as</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="368"/>
        <source>保存为CSV</source>
        <translation type="unfinished">Save as CSV</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="369"/>
        <source>保存为Excel</source>
        <translation type="unfinished">Save as Excel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="370"/>
        <source>保存为Excel XML</source>
        <translation type="unfinished">Save as Excel XML</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="371"/>
        <source>保存为Word XML</source>
        <translation type="unfinished">Save as Word XML</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="372"/>
        <source>保存为XML</source>
        <translation type="unfinished">Save as XML</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="373"/>
        <source>保存为PDF</source>
        <translation type="unfinished">Save as PDF</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="374"/>
        <source>保存为HTML</source>
        <translation type="unfinished">Save as HTML</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="427"/>
        <source>取消筛选</source>
        <translation type="unfinished">Unfilter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table.cpp" line="579"/>
        <source>保存文件</source>
        <translation type="unfinished">Save file</translation>
    </message>
</context>
<context>
    <name>iasp::gui::ComTableFilterLine</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table_filter_line.cpp" line="20"/>
        <source>Filter</source>
        <translation type="unfinished">Filter</translation>
    </message>
</context>
<context>
    <name>iasp::gui::ComTableHeader</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_table/com_table_header.cpp" line="129"/>
        <source>Filter</source>
        <translation type="unfinished">Filter</translation>
    </message>
</context>
<context>
    <name>iasp::gui::ComTitleBar</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_dialog/com_titlebar.cpp" line="230"/>
        <source>最小化</source>
        <translation type="unfinished">Minimize</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_dialog/com_titlebar.cpp" line="236"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_dialog/com_titlebar.cpp" line="272"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_dialog/com_titlebar.cpp" line="304"/>
        <source>还原</source>
        <translation type="unfinished">Restore</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_dialog/com_titlebar.cpp" line="241"/>
        <source>关闭</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_dialog/com_titlebar.cpp" line="280"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/com_dialog/com_titlebar.cpp" line="313"/>
        <source>最大化</source>
        <translation type="unfinished">Maximize</translation>
    </message>
</context>
<context>
    <name>iasp::gui::CustomTitleBar</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/custom_frameless/custom_titlebar.cpp" line="263"/>
        <source>最小化</source>
        <translation type="unfinished">Minimize</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/custom_frameless/custom_titlebar.cpp" line="271"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/custom_frameless/custom_titlebar.cpp" line="309"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/custom_frameless/custom_titlebar.cpp" line="341"/>
        <source>还原</source>
        <translation type="unfinished">Restore</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/custom_frameless/custom_titlebar.cpp" line="278"/>
        <source>关闭</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/custom_frameless/custom_titlebar.cpp" line="317"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/custom_frameless/custom_titlebar.cpp" line="350"/>
        <source>最大化</source>
        <translation type="unfinished">Maximize</translation>
    </message>
</context>
<context>
    <name>iasp::gui::FindReplaceBaseDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.cpp" line="240"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.cpp" line="257"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.cpp" line="274"/>
        <source>确认替换</source>
        <translation type="unfinished">Confirm to replace</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.cpp" line="241"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.cpp" line="258"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_comp/find_replace_dlg/find_replace_base_dlg.cpp" line="275"/>
        <source>替换字符串为空，将会删除匹配的内容，是否继续？</source>
        <translation type="unfinished">The replacement string is empty and the matched content will be deleted. Whether to continue?</translation>
    </message>
</context>
</TS>
