<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CWarnItemModel</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="482"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="484"/>
        <source>时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Hora</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="486"/>
        <source>告警节点</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nodo de alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="488"/>
        <source>告警项</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Elementos de alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="490"/>
        <source>告警对象</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Objeto de alarma </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="492"/>
        <source>告警等级</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nivel de alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="494"/>
        <source>告警内容</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Contenido de la alarma</translation>
    </message>
</context>
<context>
    <name>CommonWidget</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_widget.cpp" line="38"/>
        <source>参数配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Config de Parámetros</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_widget.cpp" line="37"/>
        <source>资源监视</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Monitor</translation>
    </message>
</context>
<context>
    <name>choos_tool_time</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.ui" line="20"/>
        <source>工具进程选取时间范围：</source>
        <translation type="unfinished">Rango de tiempo del proceso de la herramienta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.ui" line="30"/>
        <source>开始时间：</source>
        <translation type="unfinished">Hora de inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.ui" line="40"/>
        <source>结束时间：</source>
        <translation type="unfinished">Hora de Finalización:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.ui" line="69"/>
        <source>设置全部节点</source>
        <translation type="unfinished">Establecer todos los nodos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.ui" line="76"/>
        <source>设置当前节点</source>
        <translation type="unfinished">Establecer el nodo actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.ui" line="83"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.cpp" line="23"/>
        <source>时间设置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Reloj</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.cpp" line="39"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.cpp" line="39"/>
        <source>请检查检索起止时间设置</source>
        <translation type="unfinished">Verifique la configuración de inicio y fin de tiempo de búsqueda</translation>
    </message>
</context>
<context>
    <name>common_curve</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="11"/>
        <source>曲线图</source>
        <translation type="unfinished">Gráfica de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="12"/>
        <source>柱状图</source>
        <translation type="unfinished">Gráfico de barras</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="19"/>
        <source>导出CSV</source>
        <comment>menuName</comment>
        <translation type="unfinished">Exp CSV</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="22"/>
        <source>数据详情</source>
        <comment>menuName</comment>
        <translation type="unfinished">Det datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="322"/>
        <source>查询时间间隔过短，不能小于60秒</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="680"/>
        <source>采样数据</source>
        <comment>toolName</comment>
        <translation type="unfinished">Datos Muestreados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="689"/>
        <source>无数据</source>
        <comment>toolName</comment>
        <translation type="unfinished">Sin Datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="738"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="796"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="738"/>
        <source>采集值</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Valor de colección</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="738"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="796"/>
        <source>单位</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Unidad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="738"/>
        <source>采集值占比(%)</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Porcentaje de valores recolectados (%)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="738"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="796"/>
        <source>采集时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tiempo de colección</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="796"/>
        <source>采样值</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Valor de muestra</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="315"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="322"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="315"/>
        <source>日期选择错误</source>
        <translation type="unfinished">Error de selección de fecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.ui" line="85"/>
        <source>开始：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.ui" line="95"/>
        <source>结束：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Fin:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.ui" line="118"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Consulta</translation>
    </message>
</context>
<context>
    <name>common_proc_para</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.ui" line="32"/>
        <source>参数：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Parámetros:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.ui" line="39"/>
        <source>采样</source>
        <translation type="unfinished">Muestreo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.ui" line="46"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.ui" line="59"/>
        <source>预警</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.ui" line="72"/>
        <source>配额</source>
        <translation type="unfinished">Cuota</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.ui" line="98"/>
        <source>重置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Restablecer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.ui" line="105"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.cpp" line="203"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.cpp" line="372"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.cpp" line="203"/>
        <source>参数保存失败</source>
        <translation type="unfinished">Fallo al guardar el parámetro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.cpp" line="372"/>
        <source>参数修改成功</source>
        <translation type="unfinished">Modificación de parámetros exitosa</translation>
    </message>
</context>
<context>
    <name>config_para</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="145"/>
        <source>转发流量</source>
        <translation type="unfinished">Reenvío de tráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="66"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="243"/>
        <source>采样周期</source>
        <translation type="unfinished">Ciclo de muestra</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1497"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1736"/>
        <source>  数据采样</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Muestra de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1545"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1777"/>
        <source>  告警阈值</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Umbral de alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="204"/>
        <source>转发流量：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Reenvío de tráfico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="235"/>
        <source>转发数据包：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Paquetes de reenvío:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="324"/>
        <source>采样周期：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Ciclo de muestreo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="355"/>
        <source>存历史周期(倍率)：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Ciclo de almacenamiento histórico (multiplicador):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="386"/>
        <source>告警间隔：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Intervalo de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="417"/>
        <source>资源检查周期：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Ciclo de inspección de recursos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="448"/>
        <source>预警计算周期：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Ciclo de cálculo de alerta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="541"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1031"/>
        <source>内存</source>
        <translation type="unfinished">Memoria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="548"/>
        <source>网络流量</source>
        <translation type="unfinished">Tráfico de red</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="562"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1526"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1758"/>
        <source>磁盘值</source>
        <translation type="unfinished">Valor del disco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="555"/>
        <source>节点句柄</source>
        <translation type="unfinished">Manejo del nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="687"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1126"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1349"/>
        <source>内存：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Memoria:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="718"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1157"/>
        <source>网络：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Red:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="749"/>
        <source>磁盘：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Disco:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="780"/>
        <source>句柄：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Manejar:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1848"/>
        <source>  预警</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="848"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1417"/>
        <source>内存预警：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Advertencia de memoria:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="879"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1684"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1888"/>
        <source>容量预警：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Advertencia de capacidad:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="910"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1448"/>
        <source>句柄预警：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Manejar alerta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1188"/>
        <source>数据包：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Paquete de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1219"/>
        <source>磁盘速率：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Velocidad del disco:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1250"/>
        <source>进程句柄：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Manejo del proceso:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1585"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1817"/>
        <source>磁盘值：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Valor del disco:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1616"/>
        <source>连接数：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Número de conexiones:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1644"/>
        <source>  预警</source>
        <translation type="unfinished">Alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1940"/>
        <source>  默认监视文件</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Archivo de monitoreo predeterminado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="2037"/>
        <source>重置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Restablecer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="2044"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1024"/>
        <source>网络</source>
        <translation type="unfinished">Red</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="101"/>
        <source>现场</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Sitio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="123"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="975"/>
        <source>数据采样</source>
        <comment>subTitle</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="164"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="616"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1064"/>
        <source>告警阈值</source>
        <comment>subTitle</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="284"/>
        <source>资源监视服务</source>
        <comment>subTitle</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="503"/>
        <source>节点</source>
        <comment>subTitle</comment>
        <translation type="unfinished">nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="519"/>
        <source>数据采样</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="591"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1007"/>
        <source>CPU采样方式：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="808"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1377"/>
        <source>预警</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="959"/>
        <source>进程</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1038"/>
        <source>磁盘速率</source>
        <translation type="unfinished">Velocidad del disco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1045"/>
        <source>进程句柄</source>
        <translation type="unfinished">Manejo del proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1278"/>
        <source>配额</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Cuota</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1519"/>
        <source>连接数</source>
        <translation type="unfinished">Conteo de conexiones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1959"/>
        <source>新增</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1966"/>
        <source>编辑</source>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1973"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="89"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="89"/>
        <source>目录名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre del directorio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="89"/>
        <source>描述</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="89"/>
        <source>相对路径</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Ruta relativa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="348"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="352"/>
        <source>平均值</source>
        <translation type="unfinished">Valor promedio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="348"/>
        <source>瞬时值</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="592"/>
        <source>参数保存失败</source>
        <translation type="unfinished">Fallo al guardar el parámetro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="596"/>
        <source>参数保存成功</source>
        <translation type="unfinished">Parámetro guardado exitosamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="626"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="668"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="661"/>
        <source>参数加载失败</source>
        <translation type="unfinished">Fallo en la carga de parámetros</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="665"/>
        <source>参数加载成功</source>
        <translation type="unfinished">Carga de parámetros exitosa</translation>
    </message>
</context>
<context>
    <name>tips_curve_wg</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="131"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="147"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="180"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="199"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="218"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="330"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="336"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="671"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="702"/>
        <source>发:</source>
        <translation type="unfinished">Enviar:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="133"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="149"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="182"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="201"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="220"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="331"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="337"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="672"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="703"/>
        <source>收:</source>
        <translation type="unfinished">Recibir:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="163"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="348"/>
        <source>读:</source>
        <translation type="unfinished">Leer:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="165"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="349"/>
        <source>写:</source>
        <translation type="unfinished">Escribir:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="317"/>
        <source>异常告警</source>
        <translation type="unfinished">Alarma Anormal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="322"/>
        <source>CPU/内存</source>
        <translation type="unfinished">CPU/Memoria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="328"/>
        <source>网络</source>
        <translation type="unfinished">Red</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="334"/>
        <source>包吞吐量</source>
        <translation type="unfinished">Rendimiento de Paquetes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="340"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="370"/>
        <source>句柄</source>
        <translation type="unfinished">Manejar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="346"/>
        <source>磁盘速率</source>
        <translation type="unfinished">Velocidad del disco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="352"/>
        <source>连接数</source>
        <translation type="unfinished">Conteo de conexiones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="358"/>
        <source>已用容量</source>
        <translation type="unfinished">Capacidad utilizada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="364"/>
        <source>内存</source>
        <translation type="unfinished">Memoria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="657"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="666"/>
        <source>跨现场流量：%1</source>
        <translation type="unfinished">Tráfico entre sitios: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="688"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="697"/>
        <source>跨现场包率：%1</source>
        <translation type="unfinished">Tasa de paquetes entre sitios: %1</translation>
    </message>
</context>
<context>
    <name>warn_query_wg</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="60"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="65"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="125"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="157"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="328"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="355"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="363"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="60"/>
        <source>日期选择错误</source>
        <translation type="unfinished">Error de selección de fecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="65"/>
        <source>告警类型为空</source>
        <translation type="unfinished">El tipo de alarma está vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="125"/>
        <source>查询失败，请检查历史数据服务是否正常</source>
        <translation type="unfinished">Consulta fallida. Verifique si el servicio de datos históricos es normal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="157"/>
        <source>查询完成</source>
        <translation type="unfinished">Consulta completada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="221"/>
        <source>所有类型</source>
        <translation type="unfinished">Todos los tipos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="271"/>
        <source>本现场所有节点</source>
        <translation type="unfinished">Todos los nodos en el sitio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="328"/>
        <source>复归失败，请检查数据服务</source>
        <translation type="unfinished">Error al reiniciar, por favor verifique el servicio de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="355"/>
        <source>告警重置失败</source>
        <translation type="unfinished">Error al reiniciar la alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="363"/>
        <source>告警重置成功</source>
        <translation type="unfinished">Reinicio de alarma exitoso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.ui" line="23"/>
        <source>开始：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.ui" line="33"/>
        <source>结束：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Fin:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.ui" line="56"/>
        <source>查询</source>
        <comment>toolName</comment>
        <translation type="unfinished">Consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.ui" line="63"/>
        <source>告警重置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Reinicio de Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.ui" line="76"/>
        <source>告警项：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Elementos de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.ui" line="86"/>
        <source>告警节点：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nodo de alarma:</translation>
    </message>
</context>
</TS>
