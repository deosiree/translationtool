<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/api/window_manager_api/utils.cpp" line="85"/>
        <source>未知应用</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
