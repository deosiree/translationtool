<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="en_US">
<context>
    <name>MFPlayerSession</name>
    <message>
        <source>Invalid stream source.</source>
        <translation />
    </message>
    <message>
        <source>Attempting to play invalid Qt resource.</source>
        <translation />
    </message>
    <message>
        <source>The system cannot find the file specified.</source>
        <translation />
    </message>
    <message>
        <source>The specified server could not be found.</source>
        <translation />
    </message>
    <message>
        <source>Unsupported media type.</source>
        <translation />
    </message>
    <message>
        <source>Unsupported URL scheme.</source>
        <translation />
    </message>
    <message>
        <source>Connection to server could not be established.</source>
        <translation />
    </message>
    <message>
        <source>Failed to load source.</source>
        <translation />
    </message>
    <message>
        <source>Cannot create presentation descriptor.</source>
        <translation />
    </message>
    <message>
        <source>Failed to get stream count.</source>
        <translation />
    </message>
    <message>
        <source>Failed to create topology.</source>
        <translation />
    </message>
    <message>
        <source>Unable to play any stream.</source>
        <translation />
    </message>
    <message>
        <source>Unable to play.</source>
        <translation />
    </message>
    <message>
        <source>Failed to set topology.</source>
        <translation />
    </message>
    <message>
        <source>Unknown stream type.</source>
        <translation />
    </message>
    <message>
        <source>Failed to stop.</source>
        <translation />
    </message>
    <message>
        <source>failed to start playback</source>
        <translation />
    </message>
    <message>
        <source>Failed to pause.</source>
        <translation />
    </message>
    <message>
        <source>Unable to create mediasession.</source>
        <translation />
    </message>
    <message>
        <source>Unable to pull session events.</source>
        <translation />
    </message>
    <message>
        <source>Failed to seek.</source>
        <translation />
    </message>
    <message>
        <source>Media session non-fatal error.</source>
        <translation />
    </message>
    <message>
        <source>Error reading from the network.</source>
        <translation />
    </message>
    <message>
        <source>Error writing to the network.</source>
        <translation />
    </message>
    <message>
        <source>Network packets might be blocked by a firewall.</source>
        <translation />
    </message>
    <message>
        <source>Media session state error.</source>
        <translation />
    </message>
    <message>
        <source>Invalid stream data.</source>
        <translation />
    </message>
    <message>
        <source>Media session serious error.</source>
        <translation />
    </message>
    <message>
        <source>Unsupported media, a codec is missing.</source>
        <translation />
    </message>
</context>
<context>
    <name>QAndroidCameraSession</name>
    <message>
        <source>Failed to capture image</source>
        <translation />
    </message>
    <message>
        <source>Camera preview failed to start.</source>
        <translation />
    </message>
    <message>
        <source>File is not available: %1</source>
        <translation />
    </message>
    <message>
        <source>Could not save to file: %1</source>
        <translation />
    </message>
</context>
<context>
    <name>QAudioDecoder</name>
    <message>
        <source>QAudioDecoder not supported.</source>
        <translation />
    </message>
</context>
<context>
    <name>QMediaPlayer</name>
    <message>
        <source>Attempting to play invalid Qt resource</source>
        <translation />
    </message>
    <message>
        <source>Could not open file</source>
        <translation />
    </message>
    <message>
        <source>Could not find stream information for media file</source>
        <translation />
    </message>
</context>
<context>
    <name>QImageCapture</name>
    <message>
        <source>Could not capture in stopped state</source>
        <translation />
    </message>
    <message>
        <source>Camera is not ready.</source>
        <translation />
    </message>
    <message>
        <source>No instance of QImageCapture set on QMediaCaptureSession.</source>
        <translation />
    </message>
</context>
<context>
    <name>QMediaRecorder</name>
    <message>
        <source>Pause not supported</source>
        <translation />
    </message>
    <message>
        <source>Resume not supported</source>
        <translation />
    </message>
    <message>
        <source>Failed to start recording</source>
        <translation />
    </message>
    <message>
        <source>Output location not writable</source>
        <translation />
    </message>
    <message>
        <source>No video or audio input</source>
        <translation />
    </message>
    <message>
        <source>Cannot open the output location for writing</source>
        <translation />
    </message>
    <message>
        <source>No camera or audio input</source>
        <translation />
    </message>
</context>
<context>
    <name>QMediaMetaData</name>
    <message>
        <source>Title</source>
        <translation />
    </message>
    <message>
        <source>Author</source>
        <translation />
    </message>
    <message>
        <source>Comment</source>
        <translation />
    </message>
    <message>
        <source>Description</source>
        <translation />
    </message>
    <message>
        <source>Genre</source>
        <translation />
    </message>
    <message>
        <source>Date</source>
        <translation />
    </message>
    <message>
        <source>Language</source>
        <translation />
    </message>
    <message>
        <source>Publisher</source>
        <translation />
    </message>
    <message>
        <source>Copyright</source>
        <translation />
    </message>
    <message>
        <source>Url</source>
        <translation />
    </message>
    <message>
        <source>Duration</source>
        <translation />
    </message>
    <message>
        <source>Media type</source>
        <translation />
    </message>
    <message>
        <source>Container Format</source>
        <translation />
    </message>
    <message>
        <source>Audio bit rate</source>
        <translation />
    </message>
    <message>
        <source>Audio codec</source>
        <translation />
    </message>
    <message>
        <source>Video bit rate</source>
        <translation />
    </message>
    <message>
        <source>Video codec</source>
        <translation />
    </message>
    <message>
        <source>Video frame rate</source>
        <translation />
    </message>
    <message>
        <source>Album title</source>
        <translation />
    </message>
    <message>
        <source>Album artist</source>
        <translation />
    </message>
    <message>
        <source>Contributing artist</source>
        <translation />
    </message>
    <message>
        <source>Track number</source>
        <translation />
    </message>
    <message>
        <source>Composer</source>
        <translation />
    </message>
    <message>
        <source>Thumbnail image</source>
        <translation />
    </message>
    <message>
        <source>Cover art image</source>
        <translation />
    </message>
    <message>
        <source>Orientation</source>
        <translation />
    </message>
    <message>
        <source>Resolution</source>
        <translation />
    </message>
    <message>
        <source>Lead performer</source>
        <translation />
    </message>
    <message>
        <source>Has HDR content</source>
        <translation />
    </message>
</context>
<context>
    <name>Decoder</name>
    <message>
        <source>Cannot set source, invalid mime type for the source provided.</source>
        <translation />
    </message>
    <message>
        <source>Cannot open the file</source>
        <translation />
    </message>
    <message>
        <source>Invalid fileDescriptor for source.</source>
        <translation />
    </message>
    <message>
        <source>Setting source for Audio Decoder failed.</source>
        <translation />
    </message>
    <message>
        <source>Format not supported by Audio Decoder.</source>
        <translation />
    </message>
    <message>
        <source>Cannot decode, source not set.</source>
        <translation />
    </message>
    <message>
        <source>Audio Decoder could not be created.</source>
        <translation />
    </message>
    <message>
        <source>Audio Decoder failed configuration.</source>
        <translation />
    </message>
    <message>
        <source>Audio Decoder failed to start.</source>
        <translation />
    </message>
</context>
<context>
    <name>QAndroidAudioDecoder</name>
    <message>
        <source>Error opening temporary file: %1</source>
        <translation />
    </message>
    <message>
        <source>Error while writing data to temporary file</source>
        <translation />
    </message>
</context>
<context>
    <name>AVFAudioDecoder</name>
    <message>
        <source>Unable to read from specified device</source>
        <translation />
    </message>
    <message>
        <source>Could not load media source's tracks</source>
        <translation />
    </message>
    <message>
        <source>No audio tracks found</source>
        <translation />
    </message>
    <message>
        <source>Unsupported source format</source>
        <translation />
    </message>
    <message>
        <source>Failed to add asset reader output</source>
        <translation />
    </message>
    <message>
        <source>Could not start reading</source>
        <translation />
    </message>
</context>
<context>
    <name>AVFCameraSession</name>
    <message>
        <source>Runtime camera error</source>
        <translation />
    </message>
</context>
<context>
    <name>AVFImageCapture</name>
    <message>
        <source>Could not open destination file:
%1</source>
        <translation />
    </message>
</context>
<context>
    <name>AVFMediaEncoder</name>
    <message>
        <source>No inputs specified</source>
        <translation />
    </message>
    <message>
        <source>Invalid output file URL</source>
        <translation />
    </message>
    <message>
        <source>Non-writeable file location</source>
        <translation />
    </message>
    <message>
        <source>File already exists</source>
        <translation />
    </message>
</context>
<context>
    <name>AVFMediaPlayer</name>
    <message>
        <source>Failed to load media</source>
        <translation />
    </message>
</context>
<context>
    <name>QFFmpegImageCapture</name>
    <message>
        <source>No camera available.</source>
        <translation />
    </message>
</context>
<context>
    <name>QGstreamerAudioDecoder</name>
    <message>
        <source>Cannot play stream of type: &lt;unknown&gt;</source>
        <translation />
    </message>
</context>
<context>
    <name>QGstreamerMediaPlayer</name>
    <message>
        <source>Cannot play stream of type: &lt;unknown&gt;</source>
        <translation />
    </message>
</context>
<context>
    <name>QGstreamerImageCapture</name>
    <message>
        <source>No camera available.</source>
        <translation />
    </message>
</context>
<context>
    <name>MFAudioDecoderControl</name>
    <message>
        <source>Unsupported media type</source>
        <translation />
    </message>
    <message>
        <source>Media not found</source>
        <translation />
    </message>
    <message>
        <source>Unable to load specified URL</source>
        <translation />
    </message>
    <message>
        <source>Could not instantiate MFDecoderSourceReader</source>
        <translation />
    </message>
    <message>
        <source>Invalid media format</source>
        <translation />
    </message>
    <message>
        <source>Unable to read from specified device</source>
        <translation />
    </message>
    <message>
        <source>No media source specified</source>
        <translation />
    </message>
    <message>
        <source>Failed processing a sample</source>
        <translation />
    </message>
</context>
<context>
    <name>QWindowsMediaEncoder</name>
    <message>
        <source>Failed to pause recording</source>
        <translation />
    </message>
    <message>
        <source>Failed to resume recording</source>
        <translation />
    </message>
    <message>
        <source>Camera is no longer present</source>
        <translation />
    </message>
    <message>
        <source>Audio input is no longer present</source>
        <translation />
    </message>
    <message>
        <source>Streaming error</source>
        <translation />
    </message>
    <message>
        <source>Recording error</source>
        <translation />
    </message>
</context>
<context>
    <name>QV4L2Camera</name>
    <message>
        <source>Camera is in use.</source>
        <translation type="vanished" />
    </message>
</context>
</TS>