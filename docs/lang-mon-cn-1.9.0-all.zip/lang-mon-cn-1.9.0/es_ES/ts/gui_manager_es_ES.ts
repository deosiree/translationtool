<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>ArrowWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/taskbarwidget/arrow_widget.cpp" line="26"/>
        <source>悬浮菜单</source>
        <translation type="unfinished">Menú flotante</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/taskbarwidget/arrow_widget.cpp" line="176"/>
        <source>全部关闭</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cerrar todo</translation>
    </message>
</context>
<context>
    <name>CardFrameControl</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/cardframe/card_frame_control.cpp" line="159"/>
        <source>启动命令：</source>
        <translation type="unfinished">Comando de inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/cardframe/card_frame_control.cpp" line="159"/>
        <source>描述：</source>
        <translation type="unfinished">Descripción:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/cardframe/card_frame_control.cpp" line="182"/>
        <source>启动失败</source>
        <translation type="unfinished">Inicio falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/cardframe/card_frame_control.cpp" line="183"/>
        <source>工具启动数量已达最大限制</source>
        <translation type="unfinished">Núm. de inicios de herramienta al límite</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/cardframe/card_frame_control.cpp" line="212"/>
        <source>关闭%1</source>
        <translation type="unfinished">Cerrar %1</translation>
    </message>
</context>
<context>
    <name>CommandManager</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="174"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="373"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="415"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="450"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="470"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="594"/>
        <source>启动失败</source>
        <translation type="unfinished">Fallo al iniciar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="175"/>
        <source>配置了单启动，进程已存在，不可重复启动</source>
        <translation type="unfinished">Config. de inicio único, proceso existe, no repetir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="374"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="416"/>
        <source>无法找到当前工具权限配置</source>
        <translation type="unfinished">No se encontró config. de permiso de herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="430"/>
        <source>已启动</source>
        <translation type="unfinished">Iniciado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="430"/>
        <source>工具已启动，请检查</source>
        <translation type="unfinished">Herramienta iniciada, verifique</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="451"/>
        <source>当前节点支持最大启动进程数为%1，启动失败</source>
        <translation type="unfinished">El número máximo de procesos de inicio soportados por el nodo actual es %1. Error al iniciar </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="470"/>
        <source>用户未登录，请登录</source>
        <translation type="unfinished">Usuario no conectado, inicie sesión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="559"/>
        <source>(自动)</source>
        <translation type="unfinished">(Automático)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="594"/>
        <source>工具打开失败</source>
        <translation type="unfinished">Fallo al abrir herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="682"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="696"/>
        <source>(推画面)</source>
        <translation type="unfinished">(Grafico de empuje)</translation>
    </message>
</context>
<context>
    <name>GuiManagerMainWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="207"/>
        <source>界面管理器</source>
        <translation type="unfinished">Interfaz</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="540"/>
        <source>切换用户</source>
        <translation type="unfinished">Cambiar usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="540"/>
        <source>是否切换用户?</source>
        <translation type="unfinished">¿Desea cambiar de usuario?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="541"/>
        <source>是</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="542"/>
        <source>否</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="638"/>
        <source>关闭</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="638"/>
        <source>是否确认关闭</source>
        <translation type="unfinished">Está seguro de cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="655"/>
        <source>全屏</source>
        <translation type="unfinished">Pantalla completa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="661"/>
        <source>退出全屏</source>
        <translation type="unfinished">Salir pantalla completa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="797"/>
        <source>版本信息</source>
        <translation type="unfinished">Info. de versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1337"/>
        <source>应用错误</source>
        <translation type="unfinished">Error de app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1338"/>
        <source>界面处于最大化，无法记录当前界面尺寸</source>
        <translation type="unfinished">Interfaz maximizada, no guarda tamaño</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1349"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1349"/>
        <source>重启生效</source>
        <translation type="unfinished">Reinicio para aplicar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1374"/>
        <source>停用系统</source>
        <translation type="unfinished">Desactivar sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1374"/>
        <source>是否停用</source>
        <translation type="unfinished">¿Desactivar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1399"/>
        <source>重启设备</source>
        <translation type="unfinished">Reiniciar equipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1399"/>
        <source>是否重启</source>
        <translation type="unfinished">¿Reiniciar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1424"/>
        <source>关闭电源</source>
        <translation type="unfinished">Apagar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1424"/>
        <source>是否关闭</source>
        <translation type="unfinished">¿Cerrar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1627"/>
        <source>：未配置权限</source>
        <translation type="unfinished">: Sin permisos configurados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1635"/>
        <source>跟随启动失败</source>
        <translation type="unfinished">Fallo al iniciar acompañado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1636"/>
        <source>失败原因:</source>
        <translation type="unfinished">Razón de fallo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1884"/>
        <source>退出当前会话</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1885"/>
        <source>长时间内未做任何操作，退出当前会话</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LinuxMsgBox</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/popupdialog/linux_msgbox.cpp" line="47"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/popupdialog/linux_msgbox.cpp" line="51"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/popupdialog/linux_msgbox.cpp" line="95"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/popupdialog/linux_msgbox.cpp" line="52"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/popupdialog/linux_msgbox.cpp" line="96"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>MainMenu</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="34"/>
        <source>帮助中心</source>
        <translation type="unfinished">Centro de ayuda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="39"/>
        <source>关于界面</source>
        <translation type="unfinished">Acerca de interfaz</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="43"/>
        <source>停止系统</source>
        <translation type="unfinished">Detener sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="47"/>
        <source>重启系统</source>
        <translation type="unfinished">Reiniciar sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="51"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="75"/>
        <source>关闭电源</source>
        <translation type="unfinished">Apagar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="55"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="76"/>
        <source>全屏</source>
        <translation type="unfinished">Pantalla completa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="71"/>
        <source>帮助</source>
        <translation type="unfinished">Ayuda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="72"/>
        <source>关于</source>
        <translation type="unfinished">Acerca de</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="73"/>
        <source>停用系统</source>
        <translation type="unfinished">Desactivar sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="74"/>
        <source>重启设备</source>
        <translation type="unfinished">Reiniciar equipo</translation>
    </message>
</context>
<context>
    <name>MsgLovelyBox</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/popupdialog/msg_lovelybox.cpp" line="23"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/popupdialog/msg_lovelybox.cpp" line="24"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="211"/>
        <source>系统已启动</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Sistema iniciado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="212"/>
        <source>当前不允许无系统登录，请使用其他方式登录</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">No permitido sin inicio sist., use otro método</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="289"/>
        <source>参数解析失败</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Fallo al analizar parámetros</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="289"/>
        <source>请检查</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Revise</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="336"/>
        <source>磁盘告警</source>
        <comment>gui_manager::main</comment>
        <translation type="unfinished">Alarma de disco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="337"/>
        <source>磁盘已使用%1%,请注意!</source>
        <comment>gui_manager::main</comment>
        <translation type="unfinished">El disco ha sido utilizado %1%, ¡por favor tenga en cuenta!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="376"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="406"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="469"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="477"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="516"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="542"/>
        <source>提示</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="377"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="407"/>
        <source>初始化失败，程序退出</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Fallo al inicializar, programa termina</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="470"/>
        <source>已配置单启动，程序退出</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Inicio único configurado, programa termina</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="478"/>
        <source>不是自启动模式，程序退出</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">No es modo autoarranque, programa termina</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="517"/>
        <source>统一初始化失败，程序退出</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Fallo al inicializar, programa termina</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="543"/>
        <source>获取用户支持的工具列表错误，程序退出</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Fallo al obtener lista herramientas, termina</translation>
    </message>
</context>
<context>
    <name>ShowIconDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/popupdialog/show_icon_dialog.cpp" line="45"/>
        <source>展示图标</source>
        <translation type="unfinished">Mostrar ícono</translation>
    </message>
</context>
<context>
    <name>TitleWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="73"/>
        <source>登录时限：</source>
        <translation type="unfinished">Límite de tiempo de inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="80"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="229"/>
        <source>换肤</source>
        <translation type="unfinished">Cambio de piel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="230"/>
        <source>主菜单</source>
        <translation type="unfinished">Menú principal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="231"/>
        <source>最小化</source>
        <translation type="unfinished">Minimizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="232"/>
        <source>最大化</source>
        <translation type="unfinished">Maximizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="233"/>
        <source>关闭</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="537"/>
        <source>柔性异构一体化平台</source>
        <comment>toolName</comment>
        <translation type="unfinished">Plataforma Flex-Hetero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="573"/>
        <source>授权到期时间：</source>
        <translation type="unfinished">Tiempo de expiración de la autorización:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="568"/>
        <source>(节点名：</source>
        <translation type="unfinished">(Nombre de nodo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="89"/>
        <source>临时许可</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="562"/>
        <source>(系统名：</source>
        <translation type="unfinished">(Nombre de sistema:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="562"/>
        <source>现场名：</source>
        <translation type="unfinished">Nombre de sitio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="563"/>
        <source>节点名：</source>
        <translation type="unfinished">Nombre de nodo:</translation>
    </message>
</context>
<context>
    <name>WaveBallWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/wave_ball_widget.cpp" line="203"/>
        <source>显示主界面</source>
        <translation type="unfinished">Mostrar interfaz principal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/wave_ball_widget.cpp" line="204"/>
        <source>退出</source>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/wave_ball_widget.cpp" line="205"/>
        <source>隐藏</source>
        <translation type="unfinished">Ocultar</translation>
    </message>
</context>
</TS>
