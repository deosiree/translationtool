<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="en_US">
<context>
    <name>QQmlWebSocket</name>
    <message>
        <source>Messages can only be sent when the socket is open.</source>
        <translation />
    </message>
    <message>
        <source>QQmlWebSocket is not ready.</source>
        <translation />
    </message>
</context>
<context>
    <name>QQmlWebSocketServer</name>
    <message>
        <source>QQmlWebSocketServer is not ready.</source>
        <translation />
    </message>
</context>
<context>
    <name>QWebSocket</name>
    <message>
        <source>Connection closed</source>
        <translation />
    </message>
    <message>
        <source>Invalid URL.</source>
        <translation />
    </message>
    <message>
        <source>Invalid resource name.</source>
        <translation />
    </message>
    <message>
        <source>SSL Sockets are not supported on this platform.</source>
        <translation />
    </message>
    <message>
        <source>Out of memory.</source>
        <translation />
    </message>
    <message>
        <source>Unsupported WebSocket scheme: %1</source>
        <translation />
    </message>
    <message>
        <source>Error writing bytes to socket: %1.</source>
        <translation />
    </message>
    <message>
        <source>Bytes written %1 != %2.</source>
        <translation />
    </message>
    <message>
        <source>QWebSocketPrivate::processHandshake: Unsupported WWW-Authenticate challenge encountered.</source>
        <extracomment>'WWW-Authenticate' is the HTTP header.</extracomment>
        <translation />
    </message>
    <message>
        <source>QWebSocketPrivate::processHandshake: Unsupported WWW-Authenticate challenges encountered.</source>
        <translation />
    </message>
    <message>
        <source>Header is too large</source>
        <translation />
    </message>
    <message>
        <source>Read handshake request header failed</source>
        <translation />
    </message>
    <message>
        <source>Read handshake request status failed</source>
        <translation />
    </message>
    <message>
        <source>Parsing handshake request header failed</source>
        <translation />
    </message>
    <message>
        <source>WebSocket server has chosen protocol %1 which has not been requested</source>
        <translation />
    </message>
    <message>
        <source>Invalid parameter encountered during protocol upgrade: %1</source>
        <translation />
    </message>
    <message>
        <source>Invalid parameter(s) presented during protocol upgrade: %1</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Invalid statusline in response: %1.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>QWebSocketPrivate::processHandshake: Connection closed while reading header.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Accept-Key received from server %1 does not match the client key %2.</source>
        <translation />
    </message>
    <message>
        <source>QWebSocketPrivate::processHandshake: Invalid statusline in response: %1.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Handshake: Server requests a version that we don't support: %1.</source>
        <translation />
    </message>
    <message>
        <source>QWebSocketPrivate::processHandshake: Unknown error condition encountered. Aborting connection.</source>
        <translation />
    </message>
    <message>
        <source>QWebSocket::processHandshake: Host requires authentication</source>
        <translation />
    </message>
    <message>
        <source>QWebSocketPrivate::processHandshake: Unhandled http status code: %1 (%2).</source>
        <translation />
    </message>
    <message>
        <source>The resource name contains newlines. Possible attack detected.</source>
        <translation />
    </message>
    <message>
        <source>The hostname contains newlines. Possible attack detected.</source>
        <translation />
    </message>
    <message>
        <source>The origin contains newlines. Possible attack detected.</source>
        <translation />
    </message>
    <message>
        <source>The extensions attribute contains newlines. Possible attack detected.</source>
        <translation />
    </message>
    <message>
        <source>The protocols attribute contains newlines. Possible attack detected.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Connection refused</source>
        <translation />
    </message>
</context>
<context>
    <name>QWebSocketDataProcessor</name>
    <message>
        <source>Received Continuation frame, while there is nothing to continue.</source>
        <translation />
    </message>
    <message>
        <source>All data frames after the initial data frame must have opcode 0 (continuation).</source>
        <translation />
    </message>
    <message>
        <source>Received message is too big.</source>
        <translation />
    </message>
    <message>
        <source>Invalid UTF-8 code encountered.</source>
        <translation />
    </message>
    <message>
        <source>Payload of close frame is too small.</source>
        <translation />
    </message>
    <message>
        <source>Invalid close code %1 detected.</source>
        <translation />
    </message>
    <message>
        <source>Invalid opcode detected: %1</source>
        <translation />
    </message>
    <message>
        <source>Timeout when reading data from socket.</source>
        <translation />
    </message>
</context>
<context>
    <name>QWebSocketFrame</name>
    <message>
        <source>Timeout when reading data from socket.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Waiting for more data from socket.</source>
        <translation />
    </message>
    <message>
        <source>Error occurred while reading header from the network: %1</source>
        <translation />
    </message>
    <message>
        <source>Error occurred while reading from the network: %1</source>
        <translation />
    </message>
    <message>
        <source>Lengths smaller than 126 must be expressed as one byte.</source>
        <translation />
    </message>
    <message>
        <source>Something went wrong during reading from the network.</source>
        <translation />
    </message>
    <message>
        <source>Highest bit of payload length is not 0.</source>
        <translation />
    </message>
    <message>
        <source>Lengths smaller than 65536 (2^16) must be expressed as 2 bytes.</source>
        <translation />
    </message>
    <message>
        <source>Error while reading from the network: %1.</source>
        <translation />
    </message>
    <message>
        <source>Maximum framesize exceeded.</source>
        <translation />
    </message>
    <message>
        <source>Some serious error occurred while reading from the network.</source>
        <translation />
    </message>
    <message>
        <source>Rsv field is non-zero</source>
        <translation />
    </message>
    <message>
        <source>Used reserved opcode</source>
        <translation />
    </message>
    <message>
        <source>Control frame is larger than 125 bytes</source>
        <translation />
    </message>
    <message>
        <source>Control frames cannot be fragmented</source>
        <translation />
    </message>
</context>
<context>
    <name>QWebSocketHandshakeResponse</name>
    <message>
        <source>Access forbidden.</source>
        <translation />
    </message>
    <message>
        <source>Unsupported version requested.</source>
        <translation />
    </message>
    <message>
        <source>One of the headers contains a newline. Possible attack detected.</source>
        <translation />
    </message>
    <message>
        <source>Bad handshake request received.</source>
        <translation />
    </message>
</context>
<context>
    <name>QWebSocketServer</name>
    <message>
        <source>Server closed.</source>
        <translation />
    </message>
    <message>
        <source>Header is too large.</source>
        <translation />
    </message>
    <message>
        <source>Too many pending connections.</source>
        <translation />
    </message>
    <message>
        <source>Read handshake request header failed.</source>
        <translation />
    </message>
    <message>
        <source>Upgrade to WebSocket failed.</source>
        <translation />
    </message>
    <message>
        <source>Invalid response received.</source>
        <translation />
    </message>
</context>
</TS>