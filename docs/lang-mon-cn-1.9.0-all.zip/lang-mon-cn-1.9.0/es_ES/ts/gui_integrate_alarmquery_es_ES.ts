<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>AlarmInfoTableModel</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="243"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="258"/>
        <source>告警项描述</source>
        <translation type="unfinished">Descripción de ítem de alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="264"/>
        <source>告警等级</source>
        <translation type="unfinished">Nivel de alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="270"/>
        <source>操作</source>
        <translation type="unfinished">Operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="190"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="319"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="326"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="338"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="346"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="358"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="389"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="396"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="408"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="500"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="190"/>
        <source>历史库链接失败!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="319"/>
        <source>获取告警表信息失败</source>
        <translation type="unfinished">Fallo al obtener info. de tabla alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="326"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="346"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="396"/>
        <source>获取告警表字段信息失败</source>
        <translation type="unfinished">Fallo al obtener campos de tabla alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="338"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="389"/>
        <source>查询历史表信息失败</source>
        <translation type="unfinished">Error al consultar la información de la tabla histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="358"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="408"/>
        <source>获取历史告警总数失败</source>
        <translation type="unfinished">Fallo al obtener total de alertas hist.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="500"/>
        <source>%1调用查询失败</source>
        <translation type="unfinished">Fallo al consultar %1</translation>
    </message>
</context>
<context>
    <name>AlarmInfoTableView</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="27"/>
        <source>详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Detalles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="69"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="73"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="83"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="86"/>
        <source>查询告警</source>
        <translation type="unfinished">Consulta de alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="69"/>
        <source>查询完成</source>
        <translation type="unfinished">Consulta completada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="73"/>
        <source>查询为空</source>
        <translation type="unfinished">La consulta está vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="83"/>
        <source>未注册网络</source>
        <translation type="unfinished">Red no registrada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="86"/>
        <source>查询失败</source>
        <translation type="unfinished">Consulta fallida</translation>
    </message>
</context>
<context>
    <name>AlarmQueryCriteria</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="63"/>
        <source>本地</source>
        <translation type="unfinished">Local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="64"/>
        <source>历史</source>
        <translation type="unfinished">Historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="71"/>
        <source>按编辑条件，查询平台告警</source>
        <translation type="unfinished">Consulta de alarmas de plataforma según condiciones de edición</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="117"/>
        <source>重置查询条件，默认查询最近一个小时</source>
        <translation type="unfinished">Restablecer las condiciones de consulta y consultar la última hora por defecto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="122"/>
        <source>打开告警配置工具</source>
        <translation type="unfinished">Herramienta de configuración de alarmas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="69"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="114"/>
        <source>重置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Restablecer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="129"/>
        <source>编辑条件</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Editar condiciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="134"/>
        <source>编辑查询条件</source>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="139"/>
        <source>当前节点的本地缓存,删除后不可恢复</source>
        <translation type="unfinished">Caché local del nodo, irreparable tras eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="283"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="481"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="284"/>
        <source>是否确认重置告警查询条件</source>
        <translation type="unfinished">¿Restablecer condiciones de consulta alerta?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="357"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="393"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="357"/>
        <source>已启动,打开失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="393"/>
        <source>打开失败</source>
        <translation type="unfinished">Fallo al abrir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="400"/>
        <source>询问</source>
        <translation type="unfinished">Solicitar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="400"/>
        <source>是否确定删除当前节点本地缓存</source>
        <translation type="unfinished">¿Está seguro de eliminar la caché local del nodo actual?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="423"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="423"/>
        <source>清空缓存失败</source>
        <translation type="unfinished">Fallo al borrar la caché</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="428"/>
        <source>清空缓存</source>
        <translation type="unfinished">Borrar caché </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="428"/>
        <source>清空缓存成功</source>
        <translation type="unfinished">Caché eliminada con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="481"/>
        <source>是否查询</source>
        <translation type="unfinished">¿Consultar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="501"/>
        <source>查询历史告警</source>
        <translation type="unfinished">Consultar alarmas históricas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="512"/>
        <source>去这该节点查告警</source>
        <translation type="unfinished">Ir a este nodo para verificar la alarma.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="542"/>
        <source>告警级别：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="548"/>
        <source>时间范围：</source>
        <translation type="unfinished">Rango de tiempo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="559"/>
        <source>告警项：</source>
        <translation type="unfinished">Elementos de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="566"/>
        <source>告警项描述：</source>
        <translation type="unfinished">Descripción del ítem de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="573"/>
        <source>发送方：</source>
        <translation type="unfinished">Emisor:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="580"/>
        <source>告警对象：</source>
        <translation type="unfinished">Objeto de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="587"/>
        <source>告警内容：</source>
        <translation type="unfinished">Contenido de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="594"/>
        <source>告警对象</source>
        <translation type="unfinished">Objeto de alarma </translation>
    </message>
</context>
<context>
    <name>DlgAlarmItemInfo</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="26"/>
        <source>告警项详情</source>
        <comment>toolName</comment>
        <translation type="unfinished">Detalles del Elemento de Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="51"/>
        <source>告警项名称：</source>
        <translation type="unfinished">Nombre del ítem de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="52"/>
        <source>告警项描述：</source>
        <translation type="unfinished">Descripción del ítem de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="53"/>
        <source>推送画面：</source>
        <translation type="unfinished">Empujar gráfica:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="53"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="54"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="55"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="56"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="57"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="53"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="54"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="55"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="56"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="57"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="54"/>
        <source>语音播放：</source>
        <translation type="unfinished">Reproducción de voz:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="55"/>
        <source>音响播放：</source>
        <translation type="unfinished">Reproducción de audio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="56"/>
        <source>发送短信：</source>
        <translation type="unfinished">Enviar mensaje:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="57"/>
        <source>发送邮件：</source>
        <translation type="unfinished">Enviar correo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="79"/>
        <source>告警项：</source>
        <translation type="unfinished">Ítems de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="80"/>
        <source>发送方：</source>
        <translation type="unfinished">Emisor:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="85"/>
        <source>告警时间：</source>
        <translation type="unfinished">Hora de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="88"/>
        <source>告警对象oid：</source>
        <translation type="unfinished">Oid del objeto de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="91"/>
        <source>告警对象：</source>
        <translation type="unfinished">Objeto de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="94"/>
        <source>告警内容：</source>
        <translation type="unfinished">Contenido de alarma:</translation>
    </message>
</context>
<context>
    <name>DlgEditCondition</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="95"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="95"/>
        <source>oid不符合规范，无法作为查询条件</source>
        <translation type="unfinished">OID no cumple norma, no usable en consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="211"/>
        <source>平台告警过滤条件选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar Filtros de Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="277"/>
        <source>请输入告警等级以应用筛选</source>
        <translation type="unfinished">Ingrese nivel alerta para filtrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="278"/>
        <source>请输入告警项描述以应用筛选</source>
        <translation type="unfinished">Ingrese desc. ítem alerta para filtrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="279"/>
        <source>请输入告警项以应用筛选</source>
        <translation type="unfinished">Ingrese ítem alerta para filtrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="281"/>
        <source>请输入对象oid</source>
        <translation type="unfinished">Por favor, ingrese el oid del objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="282"/>
        <source>请输入对象描述</source>
        <translation type="unfinished">Por favor, ingrese una descripción del objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="283"/>
        <source>请输入发送方</source>
        <translation type="unfinished">Por favor, ingrese el emisor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="284"/>
        <source>请输入告警内容</source>
        <translation type="unfinished">Por favor, ingrese el contenido de la alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="384"/>
        <source>时间范围</source>
        <translation type="unfinished">Rango de tiempo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="491"/>
        <source>时间范围：</source>
        <translation type="unfinished">Rango de tiempo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="527"/>
        <source>告警等级：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="543"/>
        <source>告警项：</source>
        <translation type="unfinished">Elementos de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="564"/>
        <source>告警项描述：</source>
        <translation type="unfinished">Descripción del ítem de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="579"/>
        <source>发送方：</source>
        <translation type="unfinished">Emisor:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="594"/>
        <source>告警对象：</source>
        <translation type="unfinished">Objeto de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="609"/>
        <source>告警内容：</source>
        <translation type="unfinished">Contenido de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="478"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="478"/>
        <source>开始时间不能晚于结束时间</source>
        <translation type="unfinished">Inicio no posterior a fin</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="624"/>
        <source>告警对象</source>
        <translation type="unfinished">Objeto de alarma </translation>
    </message>
</context>
<context>
    <name>PaginationWidget</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="25"/>
        <source>首页</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="26"/>
        <source>上一页</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Anterior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="27"/>
        <source>下一页</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Siguiente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="28"/>
        <source>尾页</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Último</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="77"/>
        <source>共有%1数据</source>
        <translation type="unfinished">Total %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="85"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="92"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="105"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="113"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="124"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="143"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="158"/>
        <source>/ %1</source>
        <translation type="unfinished">/ %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="130"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="148"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="163"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="130"/>
        <source>页数不合法</source>
        <translation type="unfinished">Número de páginas no válido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="148"/>
        <source>已经是第一页</source>
        <translation type="unfinished">Ya está en la primera página</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="163"/>
        <source>已经是最后一页</source>
        <translation type="unfinished">Ya está en la última página</translation>
    </message>
</context>
<context>
    <name>dlg_edit_condition</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="23"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="44"/>
        <source>可选字段：</source>
        <translation type="unfinished">Campos opcionales:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="52"/>
        <source>告警时间</source>
        <translation type="unfinished">Hora de la alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="57"/>
        <source>告警等级</source>
        <translation type="unfinished">Nivel de alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="62"/>
        <source>发送方</source>
        <translation type="unfinished">Emisor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="67"/>
        <source>告警项</source>
        <translation type="unfinished">Ítems de alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="72"/>
        <source>告警项描述</source>
        <translation type="unfinished">Descripción del ítem de alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="77"/>
        <source>告警对象oid</source>
        <translation type="unfinished">OID del objeto de alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="82"/>
        <source>告警对象</source>
        <translation type="unfinished">Objeto de alarma </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="87"/>
        <source>告警内容</source>
        <translation type="unfinished">Contenido de la alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="101"/>
        <source>可选值：</source>
        <translation type="unfinished">Valores opcionales:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="119"/>
        <source>一小时</source>
        <translation type="unfinished">Una hora</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="126"/>
        <source>三小时</source>
        <translation type="unfinished">Tres horas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="133"/>
        <source>八小时</source>
        <translation type="unfinished">Ocho horas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="144"/>
        <source>一天</source>
        <translation type="unfinished">Un día</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="151"/>
        <source>三天</source>
        <translation type="unfinished">Tres días</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="158"/>
        <source>一周</source>
        <translation type="unfinished">Una semana</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="169"/>
        <source>一月</source>
        <translation type="unfinished">Un mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="176"/>
        <source>一年</source>
        <translation type="unfinished">Un año</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="183"/>
        <source>任意时间</source>
        <translation type="unfinished">Cualquier momento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="207"/>
        <source>开始时间</source>
        <translation type="unfinished">Anteayer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="217"/>
        <source>结束时间</source>
        <translation type="unfinished">Hora de finalización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="400"/>
        <source>条件选择结果：</source>
        <translation type="unfinished">Condición:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="420"/>
        <source>清空</source>
        <translation type="unfinished">Borrar</translation>
    </message>
</context>
</TS>
