<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.h" line="96"/>
        <source>下标:  </source>
        <translation type="unfinished">Subíndice:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.h" line="96"/>
        <source>名称:</source>
        <translation type="unfinished">Nombre:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.h" line="96"/>
        <source>描述:  </source>
        <translation type="unfinished">Descripción:</translation>
    </message>
</context>
<context>
    <name>batchSpinBox</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/batchSpinBox.h" line="16"/>
        <source>请输入10以下的整数</source>
        <translation type="unfinished">Por favor, ingrese un número entero inferior a 10</translation>
    </message>
</context>
<context>
    <name>eventCfg</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.ui" line="14"/>
        <source>eventCfg</source>
        <translation type="unfinished">eventCfg</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="56"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="65"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="146"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="168"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="215"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="277"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="298"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="343"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="403"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="426"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="473"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="564"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1370"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1591"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1651"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1857"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1917"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2127"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="56"/>
        <source>网络注册失败，程序退出</source>
        <translation type="unfinished">Registro de red fallido y el programa salió</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="65"/>
        <source>打开数据库失败，程序退出</source>
        <translation type="unfinished">No se pudo abrir la base de datos y el programa salió</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="146"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="277"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="403"/>
        <source>是否保存子系统？</source>
        <translation type="unfinished">¿Desea guardar el subsistema?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="168"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="298"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="426"/>
        <source>是否保存功能项？</source>
        <translation type="unfinished">¿Desea guardar los ítems de función?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="215"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="343"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="473"/>
        <source>是否保存操作项？</source>
        <translation type="unfinished">¿Desea guardar los elementos de acción?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="564"/>
        <source>删除成功</source>
        <translation type="unfinished">Eliminado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="688"/>
        <source>事件总览表</source>
        <translation type="unfinished">Tabla de descripción de eventos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="699"/>
        <source>子系统信息</source>
        <translation type="unfinished">Información del subsistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="700"/>
        <source>功能项信息</source>
        <translation type="unfinished">Información del elemento de función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="701"/>
        <source>操作项信息</source>
        <translation type="unfinished">Información del ítem de operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="702"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1054"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1129"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1210"/>
        <source>事件号</source>
        <translation type="unfinished">ID de evento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="703"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1055"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1130"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1211"/>
        <source>固定事件号</source>
        <translation type="unfinished">ID de evento fijo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="989"/>
        <source>事件</source>
        <translation type="unfinished">Evento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="997"/>
        <source>子系统</source>
        <translation type="unfinished">Subsistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1050"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1125"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1207"/>
        <source>oid</source>
        <translation type="unfinished">Oid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1051"/>
        <source>子系统名称</source>
        <translation type="unfinished">Nombre del subsistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1052"/>
        <source>子系统描述</source>
        <translation type="unfinished">Descripción del subsistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1053"/>
        <source>包含功能项数目</source>
        <translation type="unfinished">Cantidad de elementos de función incluidos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1126"/>
        <source>功能项名称</source>
        <translation type="unfinished">Nombre del ítem de función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1127"/>
        <source>功能项描述</source>
        <translation type="unfinished">Descripción del ítem de función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1128"/>
        <source>包含操作项数目</source>
        <translation type="unfinished">Cantidad de elementos de operación incluidos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1208"/>
        <source>操作项名称</source>
        <translation type="unfinished">Nombre del ítem de operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1209"/>
        <source>操作项描述</source>
        <translation type="unfinished">Descripción del artículo de operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1368"/>
        <source>子系统已存在，是否仅修改描述和固定事件号？</source>
        <translation type="unfinished">Si el subsistema ya existe, ¿desea modificar solo la descripción y el ID de evento fijo?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1378"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1393"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1414"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1421"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1432"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1466"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1480"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1508"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1516"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1547"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1560"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1567"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1578"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1586"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1606"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1659"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1674"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1695"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1706"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1740"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1753"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1774"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1782"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1811"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1822"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1829"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1844"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1852"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1925"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1940"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1961"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1972"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2006"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2019"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2041"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2049"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2079"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2093"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2100"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2114"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2122"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2143"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2148"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1378"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1516"/>
        <source>子系统描述不能为空</source>
        <translation type="unfinished">La descripción del subsistema no puede estar vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1393"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1466"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1674"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1740"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1940"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2006"/>
        <source>固定事件号已存在</source>
        <translation type="unfinished">El ID de evento fijo ya existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1414"/>
        <source>oid无效</source>
        <translation type="unfinished">OID inválido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1421"/>
        <source>子系统描述更新失败</source>
        <translation type="unfinished">La actualización de la descripción del subsistema falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1431"/>
        <source>子系统已存在，不可修改</source>
        <translation type="unfinished">El subsistema ya existe y no se puede modificar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1480"/>
        <source>子系统更新失败</source>
        <translation type="unfinished">Fallo en la actualización del subsistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1508"/>
        <source>子系统名称不能为空</source>
        <translation type="unfinished">El nombre del subsistema no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1546"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1559"/>
        <source>子系统已存在，不可重复添加</source>
        <translation type="unfinished">El subsistema ya existe y no se puede agregar de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1567"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1829"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2100"/>
        <source>固定事件号重复</source>
        <translation type="unfinished">ID de evento fijo duplicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1578"/>
        <source>子系统插入失败</source>
        <translation type="unfinished">Fallo en la inserción del subsistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1586"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1852"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2122"/>
        <source>没有修改任何内容</source>
        <translation type="unfinished">No se ha cambiado nada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1591"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1857"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2127"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1606"/>
        <source>请选中子系统</source>
        <translation type="unfinished">Por favor, seleccione el subsistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1649"/>
        <source>功能项已存在，是否仅修改描述和固定事件号？</source>
        <translation type="unfinished">El elemento de función ya existe, ¿desea modificar solo la descripción y el ID de evento fijo?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1659"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1782"/>
        <source>功能项描述不能为空</source>
        <translation type="unfinished">La descripción del elemento de función no puede estar vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1695"/>
        <source>功能项描述更新失败</source>
        <translation type="unfinished">Falló la actualización de la descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1705"/>
        <source>功能项已存在，不可修改</source>
        <translation type="unfinished">Los ítems de función ya existen y no pueden ser modificados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1753"/>
        <source>功能项更新失败</source>
        <translation type="unfinished">Fallo al actualizar un elemento de función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1774"/>
        <source>功能项名称不能为空</source>
        <translation type="unfinished">El nombre del ítem de función no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1810"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1821"/>
        <source>功能项已存在，不可重复添加</source>
        <translation type="unfinished">Los elementos de función ya existen y no se pueden agregar repetidamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1844"/>
        <source>功能项插入失败</source>
        <translation type="unfinished">Descripción Falló al insertar un ítem de función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1915"/>
        <source>操作项已存在，是否仅修改描述和固定事件号？</source>
        <translation type="unfinished">Si el artículo de operación ya existe, ¿desea modificar solo la descripción y el ID de evento fijo?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1925"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2049"/>
        <source>操作项描述不能为空</source>
        <translation type="unfinished">La descripción del artículo de operación no puede estar vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1961"/>
        <source>操作项描述更新失败</source>
        <translation type="unfinished">Fallo en la actualización de la descripción de la operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="1971"/>
        <source>操作项已存在，不可修改</source>
        <translation type="unfinished">El artículo de operación ya existe y no se puede modificar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2019"/>
        <source>操作项更新失败</source>
        <translation type="unfinished">Falló la actualización del artículo de operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2041"/>
        <source>操作项名称不能为空</source>
        <translation type="unfinished">El nombre del artículo de operación no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2078"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2092"/>
        <source>操作项已存在，不可重复添加</source>
        <translation type="unfinished">El ítem de operación ya existe y no puede ser agregado nuevamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2114"/>
        <source>操作项插入失败</source>
        <translation type="unfinished">Falló la inserción del artículo de operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2143"/>
        <source>未选中任何行</source>
        <translation type="unfinished">No se seleccionaron filas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2148"/>
        <source>删除后无法恢复，是否继续？</source>
        <translation type="unfinished">La eliminación no puede restaurarse. ¿Desea continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2194"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2194"/>
        <source>删除失败</source>
        <translation type="unfinished">Fallo al eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2381"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2391"/>
        <source>无效输入</source>
        <translation type="unfinished">Entrada inválida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2381"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventcfg.cpp" line="2391"/>
        <source>请输入一个十六进制数</source>
        <translation type="unfinished">Por favor, ingrese un número hexadecimal</translation>
    </message>
</context>
<context>
    <name>eventMenu</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventMenu.cpp" line="11"/>
        <source>新增</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventMenu.cpp" line="17"/>
        <source>请输入10以下的整数</source>
        <translation type="unfinished">Por favor, ingrese un número entero inferior a 10</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventMenu.cpp" line="31"/>
        <source>批量新增</source>
        <translation type="unfinished">Alta masiva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventMenu.cpp" line="40"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventMenu.cpp" line="41"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventcfg/eventMenu.cpp" line="42"/>
        <source>事件总览</source>
        <translation type="unfinished">Resumen del evento</translation>
    </message>
</context>
</TS>
