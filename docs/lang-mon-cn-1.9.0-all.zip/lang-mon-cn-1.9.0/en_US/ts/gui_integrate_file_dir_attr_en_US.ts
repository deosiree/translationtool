<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>BorderDelegate</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="68"/>
        <source>文件名不能包含以下字符:</source>
        <translation type="unfinished">The file name cannot contain the following characters:</translation>
    </message>
</context>
<context>
    <name>DirAtrrWidget</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="953"/>
        <source>改名</source>
        <translation type="unfinished">Rename</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="956"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="489"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1350"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1393"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1427"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1642"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="2830"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="2987"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="2993"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3022"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3189"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="489"/>
        <source>无系统模式</source>
        <translation type="unfinished">No system mode</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="495"/>
        <source>重启中……请等待</source>
        <translation type="unfinished">Restarting... Please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="518"/>
        <source>file_dir_config</source>
        <translation type="unfinished">file_dir_config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="556"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1782"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1807"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3100"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3104"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3136"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3156"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3177"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3308"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3312"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3333"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3365"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3382"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="556"/>
        <source>目前无值班节点</source>
        <translation type="unfinished">No node is currently on duty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="959"/>
        <source>版本清理数量限制(个)</source>
        <translation type="unfinished">Version cleanup limit (pcs)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="962"/>
        <source>超期清理时间限制(天)</source>
        <translation type="unfinished">Overdue cleaning time limit (days)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="642"/>
        <source>对象OID</source>
        <translation type="unfinished">Object Oid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1758"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1876"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="2050"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="2198"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="2200"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="2376"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3709"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1762"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1881"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="2205"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="2381"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1062"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1073"/>
        <source>请输入非负整数</source>
        <translation type="unfinished">Please enter a non-negative integer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1318"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1324"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1438"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1448"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1638"/>
        <source>信息</source>
        <translation type="unfinished">Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1138"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1302"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1331"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1318"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1324"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1302"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1331"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1350"/>
        <source>配置改变，是否重启服务</source>
        <translation type="unfinished">Config has changed, whether to restart the service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1427"/>
        <source>是否重置</source>
        <translation type="unfinished">Whether to reset it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1642"/>
        <source>是否删除</source>
        <translation type="unfinished">Whether to delete it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="577"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3438"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3518"/>
        <source>无版本托管配置文件</source>
        <translation type="unfinished">Config file without version control</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="578"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3453"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3533"/>
        <source>无版本托管运行文件</source>
        <translation type="unfinished">Running file without version control</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1438"/>
        <source>重置成功</source>
        <translation type="unfinished">Reset successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="576"/>
        <source>全部同步</source>
        <translation type="unfinished">Sync all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="576"/>
        <source>部分同步</source>
        <translation type="unfinished">Partial sync</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="576"/>
        <source>部分不同步</source>
        <translation type="unfinished">Partially asynchronous</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="576"/>
        <source>全部不同步</source>
        <translation type="unfinished">All out of sync</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="965"/>
        <source>同步节点</source>
        <translation type="unfinished">Sync nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1032"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1062"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1073"/>
        <source>警告</source>
        <comment>toolName</comment>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1032"/>
        <source>请输入正确格式</source>
        <translation type="unfinished">Please enter the correct format</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1448"/>
        <source>取消成功</source>
        <translation type="unfinished">Cancel successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1638"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Please select the data to be operated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1138"/>
        <source>提示</source>
        <comment>toolName</comment>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1807"/>
        <source>名称重复，请重新输入。</source>
        <translation type="unfinished">The name is duplicated, please re-enter.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="577"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3429"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3509"/>
        <source>显式版本托管配置文件</source>
        <translation type="unfinished">Explicit version hosting configuration file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="577"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3434"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3514"/>
        <source>隐式版本托管配置文件</source>
        <translation type="unfinished">Implicit version hosting configuration file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="578"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3443"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3523"/>
        <source>显式版本托管运行文件</source>
        <translation type="unfinished">Explicit version hosting running files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="578"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3448"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3528"/>
        <source>隐式版本托管运行文件</source>
        <translation type="unfinished">Implicit version hosting running file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="591"/>
        <source>新建根目录(显式配置文件)</source>
        <comment>menuName</comment>
        <translation type="unfinished">New root dir (Explicit config file)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="592"/>
        <source>新建根目录(隐式配置文件)</source>
        <comment>menuName</comment>
        <translation type="unfinished">New root dir (Implicit config file)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="593"/>
        <source>新建根目录(无版本配置文件)</source>
        <comment>menuName</comment>
        <translation type="unfinished">New root dir (Config file without version control)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="594"/>
        <source>新建根目录(显式运行文件)</source>
        <comment>menuName</comment>
        <translation type="unfinished">New root dir (Explicit running files)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="595"/>
        <source>新增根目录</source>
        <comment>menuName</comment>
        <translation type="unfinished">Add root dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="596"/>
        <source>新建根目录(无版本运行文件)</source>
        <comment>menuName</comment>
        <translation type="unfinished">New root dir (Running file without version control)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="598"/>
        <source>新增(显式配置文件)</source>
        <comment>menuName</comment>
        <translation type="unfinished">Add (Explicit config file)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="599"/>
        <source>新增(隐式配置文件)</source>
        <comment>menuName</comment>
        <translation type="unfinished">Add (Implicit config file)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="600"/>
        <source>新增(无版本配置文件)</source>
        <comment>menuName</comment>
        <translation type="unfinished">Add (Config file without version control)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="601"/>
        <source>新增(显式运行文件)</source>
        <comment>menuName</comment>
        <translation type="unfinished">Add (Explicit running file)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="602"/>
        <source>新增</source>
        <comment>menuName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="603"/>
        <source>新增(无版本运行文件)</source>
        <comment>menuName</comment>
        <translation type="unfinished">Add (Running file without version control)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="605"/>
        <source>删除</source>
        <comment>menuName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="606"/>
        <source>导出配置</source>
        <comment>menuName</comment>
        <translation type="unfinished">Export config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="640"/>
        <source>目录</source>
        <comment>subTitle</comment>
        <translation type="unfinished">DIR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="640"/>
        <source>改名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Rename</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="640"/>
        <source>移动</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Move</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="640"/>
        <source>删除</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="640"/>
        <source>版本托管%1(不可编辑)</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Version hosting%1(non editable)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="640"/>
        <source>目录大小限制%1(M)</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Dir size limit %1(M)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="641"/>
        <source>是否递归%1(目录大小)</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Recursived%1(dir size)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="641"/>
        <source>文件总数量%1(个)</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Total files: %1(pcs)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="641"/>
        <source>是否递归%1(文件个数)</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Recursived%1(pcs)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="641"/>
        <source>版本清理数量限制%1(个)</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Version cleanup limit%1(pcs)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="642"/>
        <source>超期清理时间限制(天)</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Overdue cleaning time limit (days)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="642"/>
        <source>同步类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Sync type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="642"/>
        <source>节点范围</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="662"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="663"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="664"/>
        <source>输入范围：0~999999</source>
        <translation type="unfinished">Input range:0–999999</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1387"/>
        <source>重启失败</source>
        <translation type="unfinished">Restart failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="1782"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3156"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3365"/>
        <source>存在同名的顶层名</source>
        <translation type="unfinished">A top-level name with the same name exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="2024"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="2176"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="2514"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3841"/>
        <source>节点1,节点2</source>
        <translation type="unfinished">Node 1, Node 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="2830"/>
        <source>发生变化，请保存</source>
        <translation type="unfinished">Changes made, please save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="2987"/>
        <source>文件打开失败</source>
        <translation type="unfinished">File open failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="2992"/>
        <source>成功导出文件</source>
        <translation type="unfinished">Exported the file successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3022"/>
        <source>导入成功，需保存生效</source>
        <translation type="unfinished">Import successful, save to take effect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3100"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3308"/>
        <source>目录名不能为空</source>
        <translation type="unfinished">The dir name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3104"/>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3312"/>
        <source>目录名长度过长</source>
        <translation type="unfinished">The dir name is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3177"/>
        <source>存在重复的名称</source>
        <translation type="unfinished">Duplicate name exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3189"/>
        <source>改名成功</source>
        <translation type="unfinished">Name changed successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3333"/>
        <source>异常输入，请重新输入</source>
        <translation type="unfinished">Abnormal input, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.cpp" line="3382"/>
        <source>存在重复的名称！</source>
        <translation type="unfinished">Duplicate name exists!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.ui" line="55"/>
        <source>文件目录</source>
        <translation type="unfinished">file dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.ui" line="75"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.ui" line="82"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.ui" line="125"/>
        <source>导入</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.ui" line="132"/>
        <source>导出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.ui" line="161"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/diratrrwidget.ui" line="177"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
</context>
<context>
    <name>Worker</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/Worker.cpp" line="74"/>
        <source>节点%1文件管理应用非值班或备用状态</source>
        <translation type="unfinished">Node %1 file management application is not in duty or standby status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/Worker.cpp" line="79"/>
        <source>节点%1查询应用状态失败</source>
        <translation type="unfinished">Node %1 failed to query the application status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/Worker.cpp" line="84"/>
        <source>节点%1数据库非正常状态</source>
        <translation type="unfinished">Node %1 database is in an abnormal status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/Worker.cpp" line="89"/>
        <source>节点%1查询数据库状态失败</source>
        <translation type="unfinished">Node %1 failed to query the database status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/Worker.cpp" line="95"/>
        <source>节点%1文件服务非正常状态</source>
        <translation type="unfinished">Node %1 file service is in an abnormal status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/Worker.cpp" line="101"/>
        <source>节点%1查询服务状态失败</source>
        <translation type="unfinished">Node %1 failed to query the service status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/Worker.cpp" line="108"/>
        <source>无正常状态文件服务节点，取消重启</source>
        <translation type="unfinished">No normal status file service node, canceling restart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/Worker.cpp" line="116"/>
        <source>节点%1文件服务停止失败</source>
        <translation type="unfinished">Node %1 file service failed to stop</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/Worker.cpp" line="142"/>
        <source>节点%1文件服务启动失败</source>
        <translation type="unfinished">Node %1 file service failed to start</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_dir_attr_config/Worker.cpp" line="149"/>
        <source>节点%1文件服务重启成功</source>
        <translation type="unfinished">Node %1 file service restarted successfully</translation>
    </message>
</context>
</TS>
