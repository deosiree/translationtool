<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="104"/>
        <source>源库：</source>
        <translation type="unfinished">Biblioteca de origen:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="106"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="114"/>
        <source>请选择比对对象</source>
        <translation type="unfinished">Seleccione el objeto de comparación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="111"/>
        <source>目标库：</source>
        <translation type="unfinished">Biblioteca de destino:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="195"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="230"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="235"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="250"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="358"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="399"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="405"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="465"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="860"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="864"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1153"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1174"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1306"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1314"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1321"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1332"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1518"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1523"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="195"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="358"/>
        <source>差异页会全部关闭，是否继续</source>
        <translation type="unfinished">Todas las páginas de diferencias se cerrarán. Desea continuar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="230"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="399"/>
        <source>相同路径下库不参与比对</source>
        <translation type="unfinished">Las bibliotecas bajo la misma ruta no participan en la comparación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="235"/>
        <source>与目标库名不同，是否继续</source>
        <translation type="unfinished">Diferente del nombre de la biblioteca de destino, ¿desea continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="250"/>
        <source>需清空目标库，是否继续</source>
        <translation type="unfinished">Necesita limpiar la biblioteca de destino, ¿desea continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="405"/>
        <source>与源库名不同，重新选择</source>
        <translation type="unfinished">Diferente del nombre de la biblioteca de origen, seleccione de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="465"/>
        <source>差异页会全部清除，是否继续</source>
        <translation type="unfinished">Las páginas de diferencia se borrarán completamente. Desea continuar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="828"/>
        <source>重新比对</source>
        <translation type="unfinished">Recomparar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="120"/>
        <source>选择源库</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Seleccionar biblioteca de origen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="126"/>
        <source>选择目标库</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Seleccionar biblioteca de destino</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="820"/>
        <source>配置列</source>
        <comment>toolName</comment>
        <translation type="unfinished">Cols de Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="831"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="912"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="951"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="832"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="913"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="952"/>
        <source>退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="851"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1289"/>
        <source>比对中....请等待</source>
        <translation type="unfinished">Comparando... por favor espere</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="860"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1306"/>
        <source>无差异</source>
        <translation type="unfinished">Sin diferencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="864"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1314"/>
        <source>有差异</source>
        <translation type="unfinished">Hay diferencias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="904"/>
        <source>可展示字段</source>
        <comment>toolName</comment>
        <translation type="unfinished">Campos Mostrables</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1153"/>
        <source>元数据有差异</source>
        <translation type="unfinished">Hay diferencias en los metadatos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1174"/>
        <source>元数据无差异</source>
        <translation type="unfinished">No hay diferencias en los metadatos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1518"/>
        <source>各自一个对象</source>
        <translation type="unfinished">Cada uno con su propio objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1523"/>
        <source>最大支持10个详情页，请先关闭部分</source>
        <translation type="unfinished">Se admiten hasta 10 páginas de detalle, por favor cierre algunas primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1545"/>
        <source>比对详情</source>
        <translation type="unfinished">Comparar detalles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1551"/>
        <source>表%1元数据详情</source>
        <translation type="unfinished">Detalles de metadatos de la tabla %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2017"/>
        <source>比对</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Comparar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2026"/>
        <source>全部数据</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Todos los datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2036"/>
        <source>维护数据</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Datos de maint.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2045"/>
        <source>重新加载</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Recargar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2047"/>
        <source>重新加载源/目标库内容</source>
        <translation type="unfinished">Recargar contenido de la biblioteca de origen/destino</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2054"/>
        <source>差异详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Detalles de la diferencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2056"/>
        <source>也可以选中差异节点，鼠标右键查看差异详情</source>
        <translation type="unfinished">También puede seleccionar el nodo de diferencia y hacer clic derecho para ver los detalles de la diferencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2062"/>
        <source>更多设置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Más configuraciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2063"/>
        <source>设置比对关键字段，以及展示数据类型</source>
        <translation type="unfinished">Establecer campos clave de comparación y mostrar tipos de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2103"/>
        <source>可展示字段</source>
        <translation type="unfinished">Campos mostrables</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2323"/>
        <source>表名：</source>
        <translation type="unfinished">Nombre de la tabla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2324"/>
        <source>表大小：</source>
        <translation type="unfinished">Tamaño de la tabla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2333"/>
        <source>检索路径：</source>
        <translation type="unfinished">Ruta de búsqueda:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2334"/>
        <source>存历史：</source>
        <translation type="unfinished">Guardar historial:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2335"/>
        <source>维护模式：</source>
        <translation type="unfinished">Modo de maint.:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1644"/>
        <source>加载中....请等待</source>
        <translation type="unfinished">Cargando.... Espere</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1322"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1333"/>
        <source>差异条数:</source>
        <translation type="unfinished">Elementos de diferencias:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1811"/>
        <source>表元数据</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Metadatos de la Tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1812"/>
        <source>字段元数据</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Metadatos del Campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1999"/>
        <source>比对类型：</source>
        <translation type="unfinished">Tipo de comparación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2005"/>
        <source>数据库</source>
        <translation type="unfinished">Base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2006"/>
        <source>配置文件</source>
        <translation type="unfinished">Archivos de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2088"/>
        <source>刷新</source>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2096"/>
        <source>配置列</source>
        <translation type="unfinished">Cols de config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2110"/>
        <source>导出</source>
        <translation type="unfinished">Exportar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2279"/>
        <source>表别名</source>
        <translation type="unfinished">Alias de tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2279"/>
        <source>表大小</source>
        <translation type="unfinished">Tamaño de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2279"/>
        <source>数据区大小</source>
        <translation type="unfinished">Tamaño del área de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="471"/>
        <source>不存历史</source>
        <translation type="unfinished">Sin historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="473"/>
        <source>采样存历史</source>
        <translation type="unfinished">Muestreo y almacenamiento de historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="475"/>
        <source>事件存历史</source>
        <translation type="unfinished">Los eventos se almacenan en el historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="477"/>
        <source>统计存历史</source>
        <translation type="unfinished">Almacenamiento de Historial de Estadísticas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="479"/>
        <source>采样加事件</source>
        <translation type="unfinished">Eventos de muestreo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="481"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="495"/>
        <source>未知类型</source>
        <translation type="unfinished">Tipo desconocido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="489"/>
        <source>默认</source>
        <translation type="unfinished">Predeterminado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="491"/>
        <source>同步增删改</source>
        <translation type="unfinished">Sinc CRUD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="493"/>
        <source>同步修改</source>
        <translation type="unfinished">Actualización de sinc</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.ui" line="24"/>
        <source>首页</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Primero</translation>
    </message>
</context>
<context>
    <name>ObjColCfgDlg</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="644"/>
        <source>字段别名</source>
        <translation type="unfinished">Alias del campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="644"/>
        <source>字段ID</source>
        <translation type="unfinished">ID del campo</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="3006"/>
        <source>数据库比对工具</source>
        <comment>toolName</comment>
        <translation type="unfinished">Herramienta de Comparación de Bases de Datos</translation>
    </message>
</context>
<context>
    <name>appAccess</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="562"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
</context>
<context>
    <name>choseRowWidget</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="804"/>
        <source>字段别名</source>
        <translation type="unfinished">Alias del campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="804"/>
        <source>字段ID</source>
        <translation type="unfinished">ID del campo</translation>
    </message>
</context>
<context>
    <name>dbConfUserDlg</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="12"/>
        <source>更多设置</source>
        <translation type="unfinished">Más Configuraciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="29"/>
        <source>标识模式:</source>
        <translation type="unfinished">Modo de identificación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="35"/>
        <source>关键字</source>
        <translation type="unfinished">Palabra clave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="36"/>
        <source>OID</source>
        <translation type="unfinished">OID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="40"/>
        <source>数据模式:</source>
        <translation type="unfinished">Modo de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="45"/>
        <source>全部数据</source>
        <translation type="unfinished">Todos los datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="46"/>
        <source>模型数据</source>
        <translation type="unfinished">Datos del modelo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="47"/>
        <source>运行数据</source>
        <translation type="unfinished">Datos de Operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="56"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="62"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>dbDataAccessBase</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="672"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="781"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="515"/>
        <source>离散</source>
        <translation type="unfinished">Dispersión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="675"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="784"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="518"/>
        <source>连续</source>
        <translation type="unfinished">Continuo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="678"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="787"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="521"/>
        <source>循环</source>
        <translation type="unfinished">Bucle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="681"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="790"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="524"/>
        <source>循环子表</source>
        <translation type="unfinished">Subtabla de bucle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="684"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="793"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="527"/>
        <source>历史</source>
        <translation type="unfinished">Historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="1456"/>
        <source>信息提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="1456"/>
        <source>循环子表不支持查询</source>
        <translation type="unfinished">Las subtablas circulares no admiten consultas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="1460"/>
        <source>错误信息</source>
        <translation type="unfinished">Mensaje de error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="245"/>
        <source>对象数据</source>
        <translation type="unfinished">Datos del objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="258"/>
        <source>元数据</source>
        <translation type="unfinished">Metadatos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="421"/>
        <source>维护包</source>
        <translation type="unfinished">Paquete de maint.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="424"/>
        <source>同步包</source>
        <translation type="unfinished">Paquete de sinc</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="427"/>
        <source>本地包</source>
        <translation type="unfinished">Paquete local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="430"/>
        <source>历史包</source>
        <translation type="unfinished">Paquete de historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="763"/>
        <source>Y</source>
        <translation type="unfinished">Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="765"/>
        <source>N</source>
        <translation type="unfinished">N</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="1065"/>
        <source>StructInfo</source>
        <translation type="unfinished">StructInfo</translation>
    </message>
</context>
<context>
    <name>dbLeftWidget</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="45"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="45"/>
        <source>别名</source>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="45"/>
        <source>类型</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="45"/>
        <source>对象数</source>
        <translation type="unfinished">Número de objetos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="45"/>
        <source>差异数</source>
        <translation type="unfinished">Número de diferencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="477"/>
        <source>包ID:【%1】</source>
        <translation type="unfinished">ID de paquete: [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="482"/>
        <source>表ID:【%1】</source>
        <translation type="unfinished">ID de tabla: [%1]</translation>
    </message>
</context>
<context>
    <name>dbNormalTableView</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1477"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1577"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1594"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1613"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1477"/>
        <source>上限为10个关联窗口</source>
        <translation type="unfinished">El número máximo de ventanas vinculadas es 10</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1576"/>
        <source>跨库关系:未配置元数据信息
 检索信息失败</source>
        <translation type="unfinished">Relación entre bases de datos: La información de metadatos no está configurada
Fallo al recuperar información</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1592"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1611"/>
        <source>打开失败:应用</source>
        <translation type="unfinished">Fallo al abrir: Aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1592"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1611"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2110"/>
        <source>属性</source>
        <translation type="unfinished">Atributos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2116"/>
        <source>索引数据区</source>
        <translation type="unfinished">Datos de índice</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2117"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2123"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2131"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2144"/>
        <source>装库</source>
        <translation type="unfinished">Instalar BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2122"/>
        <source>维护数据区</source>
        <translation type="unfinished">Mantener datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2128"/>
        <source>同步数据区</source>
        <translation type="unfinished">Sinc Datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2135"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2148"/>
        <source>非装库</source>
        <translation type="unfinished">Base de datos no instalada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2141"/>
        <source>本地数据区</source>
        <translation type="unfinished">Datos Locales</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2153"/>
        <source>未设置区</source>
        <translation type="unfinished">Área no configurada</translation>
    </message>
</context>
<context>
    <name>dbio_dbShowDialog</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="254"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="254"/>
        <source>当前为镜像库</source>
        <translation type="unfinished">Biblioteca de imágenes actualmente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="264"/>
        <source>请输入必要参数</source>
        <translation type="unfinished">Ingrese los Parámetros Requeridos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="271"/>
        <source>库类型：</source>
        <translation type="unfinished">Tipo de BD:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="275"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="276"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="277"/>
        <source>本地路径</source>
        <translation type="unfinished">ruta local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="285"/>
        <source>应用名：</source>
        <translation type="unfinished">Nombre de la aplicación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="297"/>
        <source>库名称：</source>
        <translation type="unfinished">Nombre de la BD:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="309"/>
        <source>选择</source>
        <translation type="unfinished">Seleccionar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="318"/>
        <source>选择文件</source>
        <translation type="unfinished">Seleccionar Archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="332"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
</context>
<context>
    <name>metaDiffWidget</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="28"/>
        <source>字段名称</source>
        <translation type="unfinished">Nombre del campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="29"/>
        <source>字段别名</source>
        <translation type="unfinished">Alias del campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="30"/>
        <source>字段ID</source>
        <translation type="unfinished">ID del campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="31"/>
        <source>关键字字段</source>
        <translation type="unfinished">Campo de palabra clave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="33"/>
        <source>标识字段</source>
        <translation type="unfinished">Campo de ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="34"/>
        <source>检索器中不可见</source>
        <translation type="unfinished">Invisible en el recuperador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="35"/>
        <source>是否存历史</source>
        <translation type="unfinished">Guardar historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="36"/>
        <source>是否装库</source>
        <translation type="unfinished">Recarga de BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="37"/>
        <source>维护和运行库%1同步更新</source>
        <translation type="unfinished">MTDB y RTDB %1 se están sincronizando y actualizando</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="38"/>
        <source>维护库中%1显示顺序</source>
        <translation type="unfinished">Orden de visualización de %1 en MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="39"/>
        <source>运行库中%1显示顺序</source>
        <translation type="unfinished">Orden de visualización de %1 en RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="40"/>
        <source>循环子对象个数</source>
        <translation type="unfinished">Contador de sub-objetos en bucle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="41"/>
        <source>单向关联</source>
        <translation type="unfinished">Enlace unidireccional</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="42"/>
        <source>跨库关联</source>
        <translation type="unfinished">Enlace entre bases de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="43"/>
        <source>是否翻译</source>
        <translation type="unfinished">Traducido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="44"/>
        <source>是否索引</source>
        <translation type="unfinished">Indexado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="85"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="93"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="103"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="115"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="129"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="138"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="146"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="243"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="87"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="96"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="106"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="119"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="133"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="149"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="246"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
</context>
<context>
    <name>tableMetaDiff</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="320"/>
        <source>类别</source>
        <translation type="unfinished">Categoría</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="321"/>
        <source>源表值</source>
        <translation type="unfinished">Valor de la tabla fuente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="323"/>
        <source>目标表值</source>
        <translation type="unfinished">Valor de la tabla objetivo</translation>
    </message>
</context>
<context>
    <name>tableMetaModel</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="440"/>
        <source>类别</source>
        <translation type="unfinished">Categoría</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="440"/>
        <source>源表值</source>
        <translation type="unfinished">Valor de la tabla fuente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="440"/>
        <source>目标表值</source>
        <translation type="unfinished">Valor de la tabla objetivo</translation>
    </message>
</context>
</TS>
