<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>ChooseReportDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_plugin/dlg_choose_report.cpp" line="18"/>
        <source>报表选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">Report Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_plugin/dlg_choose_report.cpp" line="28"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_plugin/dlg_choose_report.cpp" line="34"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_plugin/dlg_choose_report.cpp" line="50"/>
        <source>选择的报表：</source>
        <translation type="unfinished">Selected report:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_plugin/dlg_choose_report.cpp" line="69"/>
        <source>开始时间:</source>
        <translation type="unfinished">Start time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_plugin/dlg_choose_report.cpp" line="81"/>
        <source>结束时间:</source>
        <translation type="unfinished">End time:</translation>
    </message>
</context>
<context>
    <name>ReportPlugin</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_plugin/report_plugin.cpp" line="19"/>
        <source>报表插件</source>
        <translation type="unfinished">Report plugin</translation>
    </message>
</context>
<context>
    <name>ReportPluginWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_plugin/report_plugin_widget.cpp" line="35"/>
        <source>请等待……</source>
        <comment>toolName</comment>
        <translation type="unfinished">Waiting...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_plugin/report_plugin_widget.cpp" line="102"/>
        <source>报表刷新</source>
        <translation type="unfinished">Report refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_plugin/report_plugin_widget.cpp" line="104"/>
        <source>重置查询时间</source>
        <translation type="unfinished">Reset time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_plugin/report_plugin_widget.cpp" line="106"/>
        <source>报表导出</source>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_plugin/report_plugin_widget.cpp" line="108"/>
        <source>报表打印</source>
        <translation type="unfinished">Print</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_plugin/report_plugin_widget.cpp" line="110"/>
        <source>打印预览</source>
        <translation type="unfinished">Print preview</translation>
    </message>
</context>
</TS>
