<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>EventModelMain</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.ui" line="35"/>
        <source>当前应用</source>
        <translation type="unfinished">Aplicación actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.ui" line="48"/>
        <source>事件存储表</source>
        <translation type="unfinished">Tabla de almacenamiento de eventos</translation>
    </message>
</context>
<context>
    <name>HisEventTableEditor</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_editor.ui" line="26"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_editor.ui" line="40"/>
        <source>别名</source>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_editor.ui" line="54"/>
        <source>是否起效</source>
        <translation type="unfinished">Eficaz</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_editor.ui" line="62"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_editor.ui" line="67"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_editor.ui" line="79"/>
        <source>时间单位</source>
        <translation type="unfinished">Unidad de tiempo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_editor.ui" line="121"/>
        <source>重置</source>
        <translation type="unfinished">Restablecer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_editor.ui" line="128"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="554"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="584"/>
        <source>打开 %1 库失败</source>
        <translation type="unfinished">No se pudo abrir la biblioteca %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="555"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="585"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_coloumn_model.cpp" line="122"/>
        <source>获取枚举失败</source>
        <translation type="unfinished">Fallo al obtener enumeración</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::EventModelMain</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="130"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="548"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="578"/>
        <source>事件存储表</source>
        <translation type="unfinished">Tabla de almacenamiento de eventos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="155"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="190"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="249"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="253"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="418"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="529"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="155"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="190"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="418"/>
        <source>查询的应用不符合格式要求</source>
        <translation type="unfinished">La aplicación que está buscando no cumple con el formato requerido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="249"/>
        <source>更新记录成功</source>
        <translation type="unfinished">Registro actualizado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="253"/>
        <source>更新记录失败</source>
        <translation type="unfinished">Fallo al actualizar el registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="529"/>
        <source>切换的应用名称不符合规则</source>
        <translation type="unfinished">El nombre de la aplicación cambiada no cumple con las reglas</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::HisEventColoumnModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_coloumn_model.cpp" line="133"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_coloumn_model.cpp" line="151"/>
        <source>未配置</source>
        <translation type="unfinished">No configurado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_coloumn_model.cpp" line="140"/>
        <source>获取枚举失败</source>
        <translation type="unfinished">Fallo al obtener enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_coloumn_model.cpp" line="351"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_coloumn_model.cpp" line="383"/>
        <source>唯一标识</source>
        <translation type="unfinished">ID único</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::HisEventTableModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="130"/>
        <source>不清理</source>
        <translation type="unfinished">No limpiar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="134"/>
        <source>历史库磁盘清理</source>
        <translation type="unfinished">Limpieza de disco de la BD histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="150"/>
        <source>年</source>
        <translation type="unfinished">año</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="156"/>
        <source>月</source>
        <translation type="unfinished">mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="162"/>
        <source>天</source>
        <translation type="unfinished">Día</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="168"/>
        <source>小时</source>
        <translation type="unfinished">Hora</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="173"/>
        <source>秒</source>
        <translation type="unfinished">seg</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="421"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="454"/>
        <source>唯一标识</source>
        <translation type="unfinished">ID único</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::TableColoumnModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="47"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="49"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="51"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="53"/>
        <source>主键列</source>
        <translation type="unfinished">Columna clave primaria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="55"/>
        <source>是否存历史</source>
        <translation type="unfinished">Guardar historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="87"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="95"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="89"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="99"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
</context>
</TS>
