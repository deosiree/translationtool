<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>HisdataQueryTool</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="77"/>
        <source>查询条件</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Condición de consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="124"/>
        <source>当前应用：</source>
        <translation type="unfinished">App actual:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="150"/>
        <source>历史存储表：</source>
        <translation type="unfinished">Tabla de almacenamiento histórico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="176"/>
        <source>查询时段：</source>
        <translation type="unfinished">Período de consulta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="286"/>
        <source>条件字符：</source>
        <translation type="unfinished">Caracteres de condición:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="310"/>
        <source>请输入查询条件...</source>
        <translation type="unfinished">Ingrese la condición de consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="323"/>
        <source>查询对象：</source>
        <translation type="unfinished">Objeto de consulta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="399"/>
        <source>选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Seleccionar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="426"/>
        <source>清除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Limpiar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="460"/>
        <source>查看SQL</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Ver SQL</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="488"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="516"/>
        <source>查询结果</source>
        <translation type="unfinished">Resultados de la consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="672"/>
        <source>/1</source>
        <translation type="unfinished">/1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/include/copy_sql_dlg.h" line="18"/>
        <source>sql语句</source>
        <translation type="unfinished">Sentencia SQL</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/include/copy_sql_dlg.h" line="25"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/include/copy_sql_dlg.h" line="29"/>
        <source>复制</source>
        <translation type="unfinished">Duplicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="131"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="160"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="164"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="170"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="179"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="193"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="201"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="228"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="234"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="250"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="307"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="322"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="353"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="356"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="400"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="404"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="436"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="502"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="605"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="620"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="699"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="717"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="729"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="745"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="764"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="768"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="786"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="813"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="950"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="131"/>
        <source>历史数据访问对象创建失败</source>
        <translation type="unfinished">Fallo al crear el objeto de acceso a datos históricos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="160"/>
        <source>请选择应用</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="164"/>
        <source>请选择表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="170"/>
        <source>开始时间不能晚于结束时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="179"/>
        <source>采样表查询时间范围不能超过1年</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="193"/>
        <source>查询结果模型创建失败</source>
        <translation type="unfinished">Fallo al crear el modelo de resultado de la consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="200"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="785"/>
        <source>正在查询，请稍候...</source>
        <translation type="unfinished">Consultando, por favor espere...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="200"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="785"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="228"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="813"/>
        <source>查询失败</source>
        <translation type="unfinished">Consulta fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="234"/>
        <source>查询结果为空</source>
        <translation type="unfinished">El resultado de la consulta está vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="250"/>
        <source>查询成功，共%1条数据</source>
        <translation type="unfinished">Consulta exitosa, total %1 elementos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="307"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="404"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="717"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="768"/>
        <source>请选择历史存储表</source>
        <translation type="unfinished">Por favor, seleccione la tabla de almacenamiento histórico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="322"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="502"/>
        <source>切换的应用名称不符合规则</source>
        <translation type="unfinished">El nombre de la aplicación cambiada no cumple con las reglas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="353"/>
        <source>未选择查询对象</source>
        <translation type="unfinished">No se seleccionó ningún objeto de consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="356"/>
        <source>只能选择最多10个查询对象</source>
        <translation type="unfinished">Solo puede seleccionar hasta 10 objetos de consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="400"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="764"/>
        <source>开始时间不能大于结束时间</source>
        <translation type="unfinished">La hora de inicio no puede ser mayor que la hora de finalización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="436"/>
        <source>sql语句生成失败</source>
        <translation type="unfinished">Fallo al generar la declaración SQL</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="605"/>
        <source>获取历史数据库连接失败</source>
        <translation type="unfinished">No se pudo obtener la conexión de la base de datos histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="620"/>
        <source>获取历史数据库表信息失败</source>
        <translation type="unfinished">No se pudo recuperar la información de la tabla de la base de datos histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="699"/>
        <source>已经是第一页</source>
        <translation type="unfinished">Ya está en la primera página</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="729"/>
        <source>已经是最后一页</source>
        <translation type="unfinished">Ya está en la última página</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="745"/>
        <source>页数不合法</source>
        <translation type="unfinished">Número de páginas no válido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="934"/>
        <source>实例%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="949"/>
        <source>检测到装库事件(%1)，稍后手动刷新</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/query_result_model.cpp" line="104"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
</context>
</TS>
