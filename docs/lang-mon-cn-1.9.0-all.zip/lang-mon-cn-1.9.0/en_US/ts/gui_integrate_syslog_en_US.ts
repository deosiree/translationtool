<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>iasp::smg::SysLogViewer</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_syslog/src/syslog_widget.cpp" line="54"/>
        <source>操作系统日志信息：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_syslog/src/syslog_widget.cpp" line="55"/>
        <source>一键查验</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_syslog/src/syslog_widget.cpp" line="110"/>
        <source>节点:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_syslog/src/syslog_widget.cpp" line="112"/>
        <source>全部节点</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_syslog/src/syslog_widget.cpp" line="114"/>
        <source>时间:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_syslog/src/syslog_widget.cpp" line="120"/>
        <source>查询</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_syslog/src/syslog_widget.cpp" line="121"/>
        <source>重置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_syslog/src/syslog_widget.cpp" line="136"/>
        <source>停止</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_syslog/src/syslog_widget.cpp" line="203"/>
        <source>scada01</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_syslog/src/syslog_widget.cpp" line="211"/>
        <source>opt01</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
