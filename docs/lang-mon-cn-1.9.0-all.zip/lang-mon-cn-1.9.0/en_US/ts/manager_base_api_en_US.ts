<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/base/dlg_about.cpp" line="28"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/base/dlg_about.cpp" line="29"/>
        <source>版本描述</source>
        <translation type="unfinished">Version description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/base/dlg_about.cpp" line="190"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/base/dlg_about.cpp" line="215"/>
        <source>产品型号: %1</source>
        <translation type="unfinished">Product type: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/base/dlg_about.cpp" line="191"/>
        <source>应用版本: %1</source>
        <translation type="unfinished">Application version: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/base/dlg_about.cpp" line="192"/>
        <source>版权所有(C)2024-%1 上海思源弘瑞自动化有限公司</source>
        <translation type="unfinished">Copyright (C) 2024-%1 Shanghai Sieyuan Hongrui Automation Co., Ltd</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/base/dlg_about.cpp" line="226"/>
        <source>版本信息: %1</source>
        <translation type="unfinished">Version info: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/base/dlg_about.cpp" line="227"/>
        <source>版权所有(C) %1, 思源</source>
        <translation type="unfinished">Copyright (C) %1, Sieyuan</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/base/dlg_about.cpp" line="218"/>
        <source>平台版本: %1</source>
        <translation type="unfinished">Platform version: %1</translation>
    </message>
</context>
<context>
    <name>ConsoleTreeXml</name>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/console_tree_xml.cpp" line="153"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/console_tree_xml.cpp" line="523"/>
        <source>自启动守护</source>
        <translation type="unfinished">Self starting guard</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/console_tree_xml.cpp" line="157"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/console_tree_xml.cpp" line="519"/>
        <source>自启动</source>
        <translation type="unfinished">Self starting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/console_tree_xml.cpp" line="169"/>
        <source>推画面最大进程数量不合法（范围1-20）</source>
        <translation type="unfinished">Maximum of pushing graph processes is invalid (range 1-20)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/console_tree_xml.cpp" line="177"/>
        <source>手动启动进程最大数量设置不合法（范围1-20）</source>
        <translation type="unfinished">Illegal setting of maximum number of manual start processes (range 1-20)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/console_tree_xml.cpp" line="285"/>
        <source>系统工具</source>
        <comment>gui_console</comment>
        <translation type="unfinished">System tools</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/console_tree_xml.cpp" line="401"/>
        <source>是</source>
        <comment>Boolean</comment>
        <translation type="unfinished">True</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/console_tree_xml.cpp" line="515"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/console_tree_xml.cpp" line="527"/>
        <source>不跟随启动</source>
        <translation type="unfinished">No follow start</translation>
    </message>
</context>
<context>
    <name>DlgSplash</name>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/dlg_splash.cpp" line="9"/>
        <source>正在启动...</source>
        <translation type="unfinished">Starting...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/dlg_splash.cpp" line="61"/>
        <source>启动界面</source>
        <comment>toolName</comment>
        <translation type="unfinished">Startup Interface</translation>
    </message>
</context>
<context>
    <name>ManageTreeXml</name>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/manage_tree_xml.cpp" line="177"/>
        <source>推画面最大进程数量不合法（范围1-20）</source>
        <translation type="unfinished">Maximum of pushing graph processes is invalid (range 1-20)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/manage_tree_xml.cpp" line="187"/>
        <source>手动启动进程最大数量设置不合法（范围1-20）</source>
        <translation type="unfinished">Illegal setting of maximum number of manual start processes (range 1-20)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/manage_tree_xml.cpp" line="413"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/manage_tree_xml.cpp" line="418"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/manage_tree_xml.cpp" line="424"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/manage_tree_xml.cpp" line="468"/>
        <source>是</source>
        <comment>Boolean</comment>
        <translation type="unfinished">True</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="431"/>
        <source>退出系统</source>
        <translation type="unfinished">Exit system</translation>
    </message>
</context>
<context>
    <name>StaticGlobalMethod</name>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/static_global_method.cpp" line="243"/>
        <source>正常显示</source>
        <translation type="unfinished">Normal display</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/static_global_method.cpp" line="243"/>
        <source>无系统</source>
        <translation type="unfinished">No system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/static_global_method.cpp" line="243"/>
        <source>远程登陆</source>
        <translation type="unfinished">Remote login</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/static_global_method.cpp" line="243"/>
        <source>远程登陆及无系统登陆</source>
        <translation type="unfinished">Remote login and no system login</translation>
    </message>
</context>
<context>
    <name>UpgradeHistoryDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/upgrade_history_dialog.cpp" line="12"/>
        <source>关闭</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/upgrade_history_dialog.cpp" line="14"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/upgrade_history_dialog.cpp" line="15"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/upgrade_history_dialog.cpp" line="20"/>
        <source>升级历史记录</source>
        <translation type="unfinished">Upgrade history</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/upgrade_history_dialog.cpp" line="31"/>
        <source>时间</source>
        <translation type="unfinished">Time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/upgrade_history_dialog.cpp" line="31"/>
        <source>升级包</source>
        <translation type="unfinished">Upgrade package</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/upgrade_history_dialog.cpp" line="31"/>
        <source>旧版本</source>
        <translation type="unfinished">Old version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/upgrade_history_dialog.cpp" line="31"/>
        <source>新版本</source>
        <translation type="unfinished">New version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/upgrade_history_dialog.cpp" line="31"/>
        <source>结果</source>
        <translation type="unfinished">Result</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/upgrade_history_dialog.cpp" line="31"/>
        <source>备注</source>
        <translation type="unfinished">Remark</translation>
    </message>
</context>
<context>
    <name>Widget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.ui" line="84"/>
        <source>监控系统</source>
        <translation type="unfinished">Monitor system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.ui" line="347"/>
        <source>失败</source>
        <translation type="unfinished">Failed</translation>
    </message>
</context>
<context>
    <name>iasp::gui::Widget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="209"/>
        <source>系统退出界面</source>
        <comment>toolName</comment>
        <translation type="unfinished">System Exit Interface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="215"/>
        <source>系统启动界面</source>
        <comment>toolName</comment>
        <translation type="unfinished">System Startup Interface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="255"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="563"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="609"/>
        <source>系统退出</source>
        <translation type="unfinished">System exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="273"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="522"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="550"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="588"/>
        <source>系统等待启动中</source>
        <translation type="unfinished">The system is waiting to start</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="280"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="618"/>
        <source>系统等待恢复中</source>
        <translation type="unfinished">System is waiting for recovery</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="298"/>
        <source>注册码待验证</source>
        <translation type="unfinished">Reg code to be verified</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="306"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="407"/>
        <source>系统启动</source>
        <translation type="unfinished">System boot</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="365"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="374"/>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="379"/>
        <source>详情</source>
        <translation type="unfinished">Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="389"/>
        <source>启动系统</source>
        <translation type="unfinished">Start system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="442"/>
        <source>验证注册码</source>
        <translation type="unfinished">Verify</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="452"/>
        <source>登录系统</source>
        <translation type="unfinished">Login</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="479"/>
        <source>退出系统</source>
        <translation type="unfinished">Exit system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="536"/>
        <source>系统正在启动</source>
        <translation type="unfinished"> System is starting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/manager_base_api/src/startupscreen/widget.cpp" line="695"/>
        <source>异常信息</source>
        <translation type="unfinished">Exception info</translation>
    </message>
</context>
</TS>
