<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CommonFormula</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_data_api/common_formula.cpp" line="315"/>
        <location filename="../../../../src/plat/gui/api/report_data_api/common_formula.cpp" line="321"/>
        <source>报表文件格式无效</source>
        <translation type="unfinished">Invalid report file format</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_data_api/common_formula.cpp" line="416"/>
        <source>绝对值</source>
        <translation type="unfinished">ABS</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_data_api/common_formula.cpp" line="427"/>
        <source>平方根</source>
        <translation type="unfinished">Sqrt</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_data_api/common_formula.cpp" line="431"/>
        <source>立方根</source>
        <translation type="unfinished">Cbrt</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_data_api/common_formula.cpp" line="436"/>
        <source>正弦</source>
        <translation type="unfinished">Sine</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_data_api/common_formula.cpp" line="441"/>
        <source>余弦</source>
        <translation type="unfinished">Cosine</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_data_api/common_formula.cpp" line="445"/>
        <source>正切</source>
        <translation type="unfinished">Tangent</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_data_api/common_formula.cpp" line="460"/>
        <source>幂</source>
        <translation type="unfinished">Power</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_data_api/common_formula.cpp" line="474"/>
        <source>最小值</source>
        <translation type="unfinished">Mininum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_data_api/common_formula.cpp" line="480"/>
        <source>最大值</source>
        <translation type="unfinished">Maximum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_data_api/common_formula.cpp" line="486"/>
        <source>求和</source>
        <translation type="unfinished">Sum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_data_api/common_formula.cpp" line="492"/>
        <source>平均值</source>
        <translation type="unfinished">Avg</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_data_api/common_formula.cpp" line="503"/>
        <source>时间差Ms</source>
        <translation type="unfinished">DeltaMs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_data_api/common_formula.cpp" line="512"/>
        <source>时间差s</source>
        <translation type="unfinished">DeltaS</translation>
    </message>
</context>
<context>
    <name>FormulaCalculator</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_data_api/formula_calculator.cpp" line="446"/>
        <source>%1存在公式自关联</source>
        <translation type="unfinished">%1 has self-linked in the formula</translation>
    </message>
</context>
</TS>
