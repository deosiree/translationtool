<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="en_US">
<context>
    <name>QBluetoothDeviceDiscoveryAgent</name>
    <message>
        <source>Device is powered off</source>
        <translation />
    </message>
    <message>
        <source>Cannot find valid Bluetooth adapter.</source>
        <translation />
    </message>
    <message>
        <source>Input Output Error</source>
        <translation />
    </message>
    <message>
        <source>Bluetooth LE is not supported</source>
        <translation />
    </message>
    <message>
        <source>Unknown error</source>
        <translation />
    </message>
    <message>
        <source>Missing permission</source>
        <translation />
    </message>
    <message>
        <source>Cannot start device inquiry</source>
        <translation />
    </message>
    <message>
        <source>Cannot start low energy device inquiry</source>
        <translation />
    </message>
    <message>
        <source>Discovery cannot be stopped</source>
        <translation />
    </message>
    <message>
        <source>Invalid Bluetooth adapter address</source>
        <translation />
    </message>
    <message>
        <source>One or more device discovery methods are not supported on this platform</source>
        <translation />
    </message>
    <message>
        <source>Device does not support Bluetooth</source>
        <translation />
    </message>
    <message>
        <source>Passed address is not a local device.</source>
        <translation />
    </message>
    <message>
        <source>Missing Location permission. Search is not possible.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Location service turned off. Search is not possible.</source>
        <translation />
    </message>
    <message>
        <source>Failed to start device discovery due to missing permissions.</source>
        <translation />
    </message>
    <message>
        <source>Classic Discovery cannot be started</source>
        <translation />
    </message>
    <message>
        <source>Low Energy Discovery not supported</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Discovery cannot be started</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Bluetooth adapter error</source>
        <translation />
    </message>
    <message>
        <source>Device discovery not supported on this platform</source>
        <translation />
    </message>
    <message>
        <source>Cannot access adapter during service discovery</source>
        <translation />
    </message>
    <message>
        <source>Bluetooth adapter powered off.</source>
        <translation />
    </message>
</context>
<context>
    <name>QBluetoothServiceDiscoveryAgent</name>
    <message>
        <source>Local device is powered off</source>
        <translation />
    </message>
    <message>
        <source>Minimal service discovery failed</source>
        <translation />
    </message>
    <message>
        <source>Invalid Bluetooth adapter address</source>
        <translation />
    </message>
    <message>
        <source>Platform does not support Bluetooth</source>
        <translation />
    </message>
    <message>
        <source>Android API below v15 does not support SDP discovery</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Failed to start service discovery due to missing permissions.</source>
        <translation />
    </message>
    <message>
        <source>Cannot create Android BluetoothDevice</source>
        <translation />
    </message>
    <message>
        <source>Cannot obtain service uuids</source>
        <translation />
    </message>
    <message>
        <source>Serial Port Profile</source>
        <translation />
    </message>
    <message>
        <source>Device is powered off</source>
        <translation />
    </message>
    <message>
        <source>Unable to find appointed local adapter</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Cannot find local Bluetooth adapter</source>
        <translation />
    </message>
    <message>
        <source>Unable to find sdpscanner</source>
        <translation />
    </message>
    <message>
        <source>Unable to perform SDP scan</source>
        <translation />
    </message>
    <message>
        <source>Unable to access device</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Custom Service</source>
        <translation />
    </message>
    <message>
        <source>Service Discovery</source>
        <translation />
    </message>
    <message>
        <source>Browse Group Descriptor</source>
        <translation />
    </message>
    <message>
        <source>Public Browse Group</source>
        <translation />
    </message>
    <message>
        <source>LAN Access Profile</source>
        <translation />
    </message>
    <message>
        <source>Dial-Up Networking</source>
        <translation />
    </message>
    <message>
        <source>Synchronization</source>
        <translation />
    </message>
    <message>
        <source>Object Push</source>
        <translation />
    </message>
    <message>
        <source>File Transfer</source>
        <translation />
    </message>
    <message>
        <source>Synchronization Command</source>
        <translation />
    </message>
    <message>
        <source>Headset</source>
        <translation />
    </message>
    <message>
        <source>Audio Source</source>
        <translation />
    </message>
    <message>
        <source>Audio Sink</source>
        <translation />
    </message>
    <message>
        <source>Audio/Video Remote Control Target</source>
        <translation />
    </message>
    <message>
        <source>Advanced Audio Distribution</source>
        <translation />
    </message>
    <message>
        <source>Audio/Video Remote Control</source>
        <translation />
    </message>
    <message>
        <source>Audio/Video Remote Control Controller</source>
        <translation />
    </message>
    <message>
        <source>Headset AG</source>
        <translation />
    </message>
    <message>
        <source>Personal Area Networking (PANU)</source>
        <translation />
    </message>
    <message>
        <source>Personal Area Networking (NAP)</source>
        <translation />
    </message>
    <message>
        <source>Personal Area Networking (GN)</source>
        <translation />
    </message>
    <message>
        <source>Basic Direct Printing (BPP)</source>
        <translation />
    </message>
    <message>
        <source>Basic Reference Printing (BPP)</source>
        <translation />
    </message>
    <message>
        <source>Basic Imaging Profile</source>
        <translation />
    </message>
    <message>
        <source>Basic Imaging Responder</source>
        <translation />
    </message>
    <message>
        <source>Basic Imaging Archive</source>
        <translation />
    </message>
    <message>
        <source>Basic Imaging Ref Objects</source>
        <translation />
    </message>
    <message>
        <source>Hands-Free</source>
        <translation />
    </message>
    <message>
        <source>Hands-Free AG</source>
        <translation />
    </message>
    <message>
        <source>Basic Printing RefObject Service</source>
        <translation />
    </message>
    <message>
        <source>Basic Printing Reflected UI</source>
        <translation />
    </message>
    <message>
        <source>Basic Printing</source>
        <translation />
    </message>
    <message>
        <source>Basic Printing Status</source>
        <translation />
    </message>
    <message>
        <source>Human Interface Device</source>
        <translation />
    </message>
    <message>
        <source>Hardcopy Cable Replacement</source>
        <translation />
    </message>
    <message>
        <source>Hardcopy Cable Replacement Print</source>
        <translation />
    </message>
    <message>
        <source>Hardcopy Cable Replacement Scan</source>
        <translation />
    </message>
    <message>
        <source>SIM Access Server</source>
        <translation />
    </message>
    <message>
        <source>Phonebook Access PCE</source>
        <translation />
    </message>
    <message>
        <source>Phonebook Access PSE</source>
        <translation />
    </message>
    <message>
        <source>Phonebook Access</source>
        <translation />
    </message>
    <message>
        <source>Headset HS</source>
        <translation />
    </message>
    <message>
        <source>Message Access Server</source>
        <translation />
    </message>
    <message>
        <source>Message Notification Server</source>
        <translation />
    </message>
    <message>
        <source>Message Access</source>
        <translation />
    </message>
    <message>
        <source>Global Navigation Satellite System</source>
        <translation />
    </message>
    <message>
        <source>Global Navigation Satellite System Server</source>
        <translation />
    </message>
    <message>
        <source>3D Synchronization Display</source>
        <translation />
    </message>
    <message>
        <source>3D Synchronization Glasses</source>
        <translation />
    </message>
    <message>
        <source>3D Synchronization</source>
        <translation />
    </message>
    <message>
        <source>Multi-Profile Specification (Profile)</source>
        <translation />
    </message>
    <message>
        <source>Multi-Profile Specification</source>
        <translation />
    </message>
    <message>
        <source>Device Identification</source>
        <translation />
    </message>
    <message>
        <source>Generic Networking</source>
        <translation />
    </message>
    <message>
        <source>Generic File Transfer</source>
        <translation />
    </message>
    <message>
        <source>Generic Audio</source>
        <translation />
    </message>
    <message>
        <source>Generic Telephony</source>
        <translation />
    </message>
    <message>
        <source>Video Source</source>
        <translation />
    </message>
    <message>
        <source>Video Sink</source>
        <translation />
    </message>
    <message>
        <source>Video Distribution</source>
        <translation />
    </message>
    <message>
        <source>Health Device</source>
        <translation />
    </message>
    <message>
        <source>Health Device Source</source>
        <translation />
    </message>
    <message>
        <source>Health Device Sink</source>
        <translation />
    </message>
    <message>
        <source>Generic Access</source>
        <translation />
    </message>
    <message>
        <source>Generic Attribute</source>
        <translation />
    </message>
    <message>
        <source>Immediate Alert</source>
        <translation />
    </message>
    <message>
        <source>Link Loss</source>
        <translation />
    </message>
    <message>
        <source>Tx Power</source>
        <translation />
    </message>
    <message>
        <source>Current Time Service</source>
        <translation />
    </message>
    <message>
        <source>Reference Time Update Service</source>
        <translation />
    </message>
    <message>
        <source>Next DST Change Service</source>
        <translation />
    </message>
    <message>
        <source>Glucose</source>
        <translation />
    </message>
    <message>
        <source>Health Thermometer</source>
        <translation />
    </message>
    <message>
        <source>Device Information</source>
        <translation />
    </message>
    <message>
        <source>Heart Rate</source>
        <translation />
    </message>
    <message>
        <source>Phone Alert Status Service</source>
        <translation />
    </message>
    <message>
        <source>Battery Service</source>
        <translation />
    </message>
    <message>
        <source>Blood Pressure</source>
        <translation />
    </message>
    <message>
        <source>Alert Notification Service</source>
        <translation />
    </message>
    <message>
        <source>Scan Parameters</source>
        <translation />
    </message>
    <message>
        <source>Running Speed and Cadence</source>
        <translation />
    </message>
    <message>
        <source>Cycling Speed and Cadence</source>
        <translation />
    </message>
    <message>
        <source>Cycling Power</source>
        <translation />
    </message>
    <message>
        <source>Location and Navigation</source>
        <translation />
    </message>
    <message>
        <source>Environmental Sensing</source>
        <translation />
    </message>
    <message>
        <source>Body Composition</source>
        <translation />
    </message>
    <message>
        <source>User Data</source>
        <translation />
    </message>
    <message>
        <source>Weight Scale</source>
        <translation />
    </message>
    <message>
        <source>Bond Management</source>
        <extracomment>Connection management (Bluetooth)</extracomment>
        <translation />
    </message>
    <message>
        <source>Continuous Glucose Monitoring</source>
        <translation />
    </message>
    <message>
        <source>Service Discovery Protocol</source>
        <translation />
    </message>
    <message>
        <source>User Datagram Protocol</source>
        <translation />
    </message>
    <message>
        <source>Radio Frequency Communication</source>
        <translation />
    </message>
    <message>
        <source>Transmission Control Protocol</source>
        <translation />
    </message>
    <message>
        <source>Telephony Control Specification - Binary</source>
        <translation />
    </message>
    <message>
        <source>Telephony Control Specification - AT</source>
        <translation />
    </message>
    <message>
        <source>Attribute Protocol</source>
        <translation />
    </message>
    <message>
        <source>Object Exchange Protocol</source>
        <translation />
    </message>
    <message>
        <source>Internet Protocol</source>
        <translation />
    </message>
    <message>
        <source>File Transfer Protocol</source>
        <translation />
    </message>
    <message>
        <source>Hypertext Transfer Protocol</source>
        <translation />
    </message>
    <message>
        <source>Wireless Short Packet Protocol</source>
        <translation />
    </message>
    <message>
        <source>Bluetooth Network Encapsulation Protocol</source>
        <translation />
    </message>
    <message>
        <source>Extended Service Discovery Protocol</source>
        <translation />
    </message>
    <message>
        <source>Human Interface Device Protocol</source>
        <translation />
    </message>
    <message>
        <source>Hardcopy Control Channel</source>
        <translation />
    </message>
    <message>
        <source>Hardcopy Data Channel</source>
        <translation />
    </message>
    <message>
        <source>Hardcopy Notification</source>
        <translation />
    </message>
    <message>
        <source>Audio/Video Control Transport Protocol</source>
        <translation />
    </message>
    <message>
        <source>Audio/Video Distribution Transport Protocol</source>
        <translation />
    </message>
    <message>
        <source>Common ISDN Access Protocol</source>
        <translation />
    </message>
    <message>
        <source>UdiCPlain</source>
        <translation />
    </message>
    <message>
        <source>Multi-Channel Adaptation Protocol - Control</source>
        <translation />
    </message>
    <message>
        <source>Multi-Channel Adaptation Protocol - Data</source>
        <translation />
    </message>
    <message>
        <source>Layer 2 Control Protocol</source>
        <translation />
    </message>
    <message>
        <source>GAP Device Name</source>
        <extracomment>GAP: Generic Access Profile (Bluetooth)</extracomment>
        <translation />
    </message>
    <message>
        <source>GAP Appearance</source>
        <extracomment>GAP: Generic Access Profile (Bluetooth)</extracomment>
        <translation />
    </message>
    <message>
        <source>GAP Peripheral Privacy Flag</source>
        <extracomment>GAP: Generic Access Profile (Bluetooth)</extracomment>
        <translation />
    </message>
    <message>
        <source>GAP Reconnection Address</source>
        <extracomment>GAP: Generic Access Profile (Bluetooth)</extracomment>
        <translation />
    </message>
    <message>
        <source>GAP Peripheral Preferred Connection Parameters</source>
        <translation />
    </message>
    <message>
        <source>GATT Service Changed</source>
        <extracomment>GATT: _G_eneric _Att_ribute Profile (Bluetooth)</extracomment>
        <translation />
    </message>
    <message>
        <source>Alert Level</source>
        <translation />
    </message>
    <message>
        <source>TX Power</source>
        <translation />
    </message>
    <message>
        <source>Date Time</source>
        <translation />
    </message>
    <message>
        <source>Day Of Week</source>
        <translation />
    </message>
    <message>
        <source>Day Date Time</source>
        <translation />
    </message>
    <message>
        <source>Exact Time 256</source>
        <translation />
    </message>
    <message>
        <source>DST Offset</source>
        <translation />
    </message>
    <message>
        <source>Time Zone</source>
        <translation />
    </message>
    <message>
        <source>Local Time Information</source>
        <translation />
    </message>
    <message>
        <source>Time With DST</source>
        <translation />
    </message>
    <message>
        <source>Time Accuracy</source>
        <translation />
    </message>
    <message>
        <source>Time Source</source>
        <translation />
    </message>
    <message>
        <source>Reference Time Information</source>
        <translation />
    </message>
    <message>
        <source>Time Update Control Point</source>
        <translation />
    </message>
    <message>
        <source>Time Update State</source>
        <translation />
    </message>
    <message>
        <source>Glucose Measurement</source>
        <translation />
    </message>
    <message>
        <source>Battery Level</source>
        <translation />
    </message>
    <message>
        <source>Temperature Measurement</source>
        <translation />
    </message>
    <message>
        <source>Temperature Type</source>
        <translation />
    </message>
    <message>
        <source>Intermediate Temperature</source>
        <translation />
    </message>
    <message>
        <source>Measurement Interval</source>
        <translation />
    </message>
    <message>
        <source>Boot Keyboard Input Report</source>
        <translation />
    </message>
    <message>
        <source>System ID</source>
        <translation />
    </message>
    <message>
        <source>Model Number String</source>
        <translation />
    </message>
    <message>
        <source>Serial Number String</source>
        <translation />
    </message>
    <message>
        <source>Firmware Revision String</source>
        <translation />
    </message>
    <message>
        <source>Hardware Revision String</source>
        <translation />
    </message>
    <message>
        <source>Software Revision String</source>
        <translation />
    </message>
    <message>
        <source>Manufacturer Name String</source>
        <translation />
    </message>
    <message>
        <source>IEEE 11073 20601 Regulatory Certification Data List</source>
        <translation />
    </message>
    <message>
        <source>Current Time</source>
        <translation />
    </message>
    <message>
        <source>Scan Refresh</source>
        <translation />
    </message>
    <message>
        <source>Boot Keyboard Output Report</source>
        <translation />
    </message>
    <message>
        <source>Boot Mouse Input Report</source>
        <translation />
    </message>
    <message>
        <source>Glucose Measurement Context</source>
        <translation />
    </message>
    <message>
        <source>Blood Pressure Measurement</source>
        <translation />
    </message>
    <message>
        <source>Intermediate Cuff Pressure</source>
        <translation />
    </message>
    <message>
        <source>Heart Rate Measurement</source>
        <translation />
    </message>
    <message>
        <source>Body Sensor Location</source>
        <translation />
    </message>
    <message>
        <source>Heart Rate Control Point</source>
        <translation />
    </message>
    <message>
        <source>Alert Status</source>
        <translation />
    </message>
    <message>
        <source>Ringer Control Point</source>
        <translation />
    </message>
    <message>
        <source>Ringer Setting</source>
        <translation />
    </message>
    <message>
        <source>Alert Category ID Bit Mask</source>
        <translation />
    </message>
    <message>
        <source>Alert Category ID</source>
        <translation />
    </message>
    <message>
        <source>Alert Notification Control Point</source>
        <translation />
    </message>
    <message>
        <source>Unread Alert Status</source>
        <translation />
    </message>
    <message>
        <source>New Alert</source>
        <translation />
    </message>
    <message>
        <source>Supported New Alert Category</source>
        <translation />
    </message>
    <message>
        <source>Supported Unread Alert Category</source>
        <translation />
    </message>
    <message>
        <source>Blood Pressure Feature</source>
        <translation />
    </message>
    <message>
        <source>HID Information</source>
        <extracomment>HID: Human Interface Device Profile (Bluetooth)</extracomment>
        <translation />
    </message>
    <message>
        <source>Report Map</source>
        <translation />
    </message>
    <message>
        <source>HID Control Point</source>
        <extracomment>HID: Human Interface Device Profile (Bluetooth)</extracomment>
        <translation />
    </message>
    <message>
        <source>Report</source>
        <translation />
    </message>
    <message>
        <source>Protocol Mode</source>
        <translation />
    </message>
    <message>
        <source>Scan Interval Window</source>
        <translation />
    </message>
    <message>
        <source>PnP ID</source>
        <translation />
    </message>
    <message>
        <source>Glucose Feature</source>
        <translation />
    </message>
    <message>
        <source>Record Access Control Point</source>
        <extracomment>Glucose Sensor patient record database.</extracomment>
        <translation />
    </message>
    <message>
        <source>RSC Measurement</source>
        <extracomment>RSC: Running Speed and Cadence</extracomment>
        <translation />
    </message>
    <message>
        <source>RSC Feature</source>
        <extracomment>RSC: Running Speed and Cadence</extracomment>
        <translation />
    </message>
    <message>
        <source>SC Control Point</source>
        <translation />
    </message>
    <message>
        <source>CSC Measurement</source>
        <extracomment>CSC: Cycling Speed and Cadence</extracomment>
        <translation />
    </message>
    <message>
        <source>CSC Feature</source>
        <extracomment>CSC: Cycling Speed and Cadence</extracomment>
        <translation />
    </message>
    <message>
        <source>Sensor Location</source>
        <translation />
    </message>
    <message>
        <source>Cycling Power Measurement</source>
        <translation />
    </message>
    <message>
        <source>Cycling Power Vector</source>
        <translation />
    </message>
    <message>
        <source>Cycling Power Feature</source>
        <translation />
    </message>
    <message>
        <source>Cycling Power Control Point</source>
        <translation />
    </message>
    <message>
        <source>Location And Speed</source>
        <translation />
    </message>
    <message>
        <source>Navigation</source>
        <translation />
    </message>
    <message>
        <source>Position Quality</source>
        <translation />
    </message>
    <message>
        <source>LN Feature</source>
        <translation />
    </message>
    <message>
        <source>LN Control Point</source>
        <translation />
    </message>
    <message>
        <source>Magnetic Declination</source>
        <extracomment>Angle between geographic and magnetic north</extracomment>
        <translation />
    </message>
    <message>
        <source>Elevation</source>
        <extracomment>Above/below sea level</extracomment>
        <translation />
    </message>
    <message>
        <source>Pressure</source>
        <translation />
    </message>
    <message>
        <source>Temperature</source>
        <translation />
    </message>
    <message>
        <source>Humidity</source>
        <translation />
    </message>
    <message>
        <source>True Wind Speed</source>
        <extracomment>Wind speed while standing</extracomment>
        <translation />
    </message>
    <message>
        <source>True Wind Direction</source>
        <translation />
    </message>
    <message>
        <source>Apparent Wind Speed</source>
        <extracomment>Wind speed while observer is moving</extracomment>
        <translation />
    </message>
    <message>
        <source>Apparent Wind Direction</source>
        <translation />
    </message>
    <message>
        <source>Gust Factor</source>
        <extracomment>Factor by which wind gust is stronger than average wind</extracomment>
        <translation />
    </message>
    <message>
        <source>Pollen Concentration</source>
        <translation />
    </message>
    <message>
        <source>UV Index</source>
        <translation />
    </message>
    <message>
        <source>Irradiance</source>
        <translation />
    </message>
    <message>
        <source>Rainfall</source>
        <translation />
    </message>
    <message>
        <source>Wind Chill</source>
        <translation />
    </message>
    <message>
        <source>Heat Index</source>
        <translation />
    </message>
    <message>
        <source>Dew Point</source>
        <translation />
    </message>
    <message>
        <source>Descriptor Value Changed</source>
        <extracomment>Environmental sensing related</extracomment>
        <translation />
    </message>
    <message>
        <source>Aerobic Heart Rate Lower Limit</source>
        <translation />
    </message>
    <message>
        <source>Aerobic Heart Rate Upper Limit</source>
        <translation />
    </message>
    <message>
        <source>Aerobic Threshold</source>
        <translation />
    </message>
    <message>
        <source>Age</source>
        <extracomment>Age of person</extracomment>
        <translation />
    </message>
    <message>
        <source>Anaerobic Heart Rate Lower Limit</source>
        <translation />
    </message>
    <message>
        <source>Anaerobic Heart Rate Upper Limit</source>
        <translation />
    </message>
    <message>
        <source>Anaerobic Threshold</source>
        <translation />
    </message>
    <message>
        <source>Date Of Birth</source>
        <translation />
    </message>
    <message>
        <source>Date Of Threshold Assessment</source>
        <translation />
    </message>
    <message>
        <source>Email Address</source>
        <translation />
    </message>
    <message>
        <source>Fat Burn Heart Rate Lower Limit</source>
        <translation />
    </message>
    <message>
        <source>Fat Burn Heart Rate Upper Limit</source>
        <translation />
    </message>
    <message>
        <source>First Name</source>
        <translation />
    </message>
    <message>
        <source>5-Zone Heart Rate Limits</source>
        <translation />
    </message>
    <message>
        <source>Gender</source>
        <translation />
    </message>
    <message>
        <source>Heart Rate Maximum</source>
        <translation />
    </message>
    <message>
        <source>Height</source>
        <extracomment>Height of a person</extracomment>
        <translation />
    </message>
    <message>
        <source>Hip Circumference</source>
        <translation />
    </message>
    <message>
        <source>Last Name</source>
        <translation />
    </message>
    <message>
        <source>Maximum Recommended Heart Rate</source>
        <translation />
    </message>
    <message>
        <source>Resting Heart Rate</source>
        <translation />
    </message>
    <message>
        <source>Sport Type For Aerobic/Anaerobic Thresholds</source>
        <translation />
    </message>
    <message>
        <source>3-Zone Heart Rate Limits</source>
        <translation />
    </message>
    <message>
        <source>2-Zone Heart Rate Limits</source>
        <translation />
    </message>
    <message>
        <source>Oxygen Uptake</source>
        <translation />
    </message>
    <message>
        <source>Waist Circumference</source>
        <translation />
    </message>
    <message>
        <source>Weight</source>
        <translation />
    </message>
    <message>
        <source>Database Change Increment</source>
        <extracomment>Environmental sensing related</extracomment>
        <translation />
    </message>
    <message>
        <source>User Index</source>
        <translation />
    </message>
    <message>
        <source>Body Composition Feature</source>
        <translation />
    </message>
    <message>
        <source>Body Composition Measurement</source>
        <translation />
    </message>
    <message>
        <source>Weight Measurement</source>
        <translation />
    </message>
    <message>
        <source>Weight Scale Feature</source>
        <translation />
    </message>
    <message>
        <source>User Control Point</source>
        <translation />
    </message>
    <message>
        <source>Magnetic Flux Density 2D</source>
        <translation />
    </message>
    <message>
        <source>Magnetic Flux Density 3D</source>
        <translation />
    </message>
    <message>
        <source>Language</source>
        <translation />
    </message>
    <message>
        <source>Barometric Pressure Trend</source>
        <translation />
    </message>
    <message>
        <source>Characteristic Extended Properties</source>
        <translation />
    </message>
    <message>
        <source>Characteristic User Description</source>
        <translation />
    </message>
    <message>
        <source>Client Characteristic Configuration</source>
        <translation />
    </message>
    <message>
        <source>Server Characteristic Configuration</source>
        <translation />
    </message>
    <message>
        <source>Characteristic Presentation Format</source>
        <translation />
    </message>
    <message>
        <source>Characteristic Aggregate Format</source>
        <translation />
    </message>
    <message>
        <source>Valid Range</source>
        <translation />
    </message>
    <message>
        <source>External Report Reference</source>
        <translation />
    </message>
    <message>
        <source>Report Reference</source>
        <translation />
    </message>
    <message>
        <source>Environmental Sensing Configuration</source>
        <translation />
    </message>
    <message>
        <source>Environmental Sensing Measurement</source>
        <translation />
    </message>
    <message>
        <source>Environmental Sensing Trigger Setting</source>
        <translation />
    </message>
    <message>
        <source>Unknown Service</source>
        <translation />
    </message>
</context>
<context>
    <name>QBluetoothSocket</name>
    <message>
        <source>Network Error</source>
        <translation />
    </message>
    <message>
        <source>Cannot write while not connected</source>
        <translation />
    </message>
    <message>
        <source>Trying to connect while connection is in progress</source>
        <translation />
    </message>
    <message>
        <source>Service cannot be found</source>
        <translation />
    </message>
    <message>
        <source>Invalid data/data size</source>
        <translation />
    </message>
    <message>
        <source>Cannot read while not connected</source>
        <translation />
    </message>
    <message>
        <source>Socket type not supported</source>
        <translation />
    </message>
    <message>
        <source>Unknown socket error</source>
        <translation />
    </message>
    <message>
        <source>Network Error: %1</source>
        <translation />
    </message>
    <message>
        <source>Connecting to port is not supported</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Cannot connect to %1</source>
        <comment>%1 = uuid</comment>
        <translation />
    </message>
    <message>
        <source>Bluetooth socket connect failed due to missing permissions.</source>
        <translation />
    </message>
    <message>
        <source>Device does not support Bluetooth</source>
        <translation />
    </message>
    <message>
        <source>Device is powered off</source>
        <translation />
    </message>
    <message>
        <source>Cannot access address %1</source>
        <comment>%1 = Bt address e.g. 11:22:33:44:55:66</comment>
        <translation />
    </message>
    <message>
        <source>Cannot connect to %1 on %2</source>
        <comment>%1 = uuid, %2 = Bt address</comment>
        <translation />
    </message>
    <message>
        <source>Obtaining streams for service failed</source>
        <translation />
    </message>
    <message>
        <source>Input stream thread cannot be started</source>
        <translation />
    </message>
    <message>
        <source>Connection to service failed</source>
        <translation />
    </message>
    <message>
        <source>Error during write on socket.</source>
        <translation />
    </message>
    <message>
        <source>Network error during read</source>
        <translation />
    </message>
    <message>
        <source>Cannot set connection security level</source>
        <translation />
    </message>
    <message>
        <source>Cannot export profile on DBus</source>
        <translation />
    </message>
    <message>
        <source>Cannot register profile on DBus</source>
        <translation />
    </message>
    <message>
        <source>Cannot find remote device</source>
        <translation />
    </message>
    <message>
        <source>Cannot connect to remote profile</source>
        <translation />
    </message>
    <message>
        <source>Missing serviceUuid or Serial Port service class uuid</source>
        <translation />
    </message>
    <message>
        <source>Invalid Bluetooth address passed to connectToService()</source>
        <translation />
    </message>
    <message>
        <source>Unsupported protocol. Win32 only supports RFCOMM sockets</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Failed to create socket</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Socket type not handled: %1</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Logic error: more bytes sent than passed to ::send</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Network error</source>
        <translation />
    </message>
    <message>
        <source>Remote host closed connection</source>
        <translation />
    </message>
    <message>
        <source>Connection timed out</source>
        <translation />
    </message>
    <message>
        <source>Host not reachable</source>
        <translation />
    </message>
    <message>
        <source>Host refused connection</source>
        <translation />
    </message>
</context>
<context>
    <name>QBluetoothSocketPrivateAndroid</name>
    <message>
        <source>Connecting to port is not supported</source>
        <translation />
    </message>
</context>
<context>
    <name>QBluetoothSocketPrivateBluezDBus</name>
    <message>
        <source>Connecting to port is not supported via Bluez DBus</source>
        <translation />
    </message>
</context>
<context>
    <name>QBluetoothTransferReply</name>
    <message>
        <source>Invalid target address</source>
        <translation />
    </message>
    <message>
        <source>Push session cannot be started</source>
        <translation />
    </message>
    <message>
        <source>Push session cannot connect</source>
        <translation />
    </message>
    <message>
        <source>Source file does not exist</source>
        <translation />
    </message>
    <message>
        <source>QIODevice cannot be read. Make sure it is open for reading.</source>
        <translation />
    </message>
    <message>
        <source>Push session failed</source>
        <translation />
    </message>
    <message>
        <source>Invalid input device (null)</source>
        <translation />
    </message>
    <message>
        <source>Operation canceled</source>
        <translation />
    </message>
    <message>
        <source>Transfer already started</source>
        <translation />
    </message>
    <message>
        <source>Push service not found</source>
        <translation />
    </message>
</context>
<context>
    <name>QBluetoothTransferReplyBluez</name>
    <message>
        <source>Unknown Error</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Could not open file for sending</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>The transfer was canceled</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Operation canceled</source>
        <translation type="vanished" />
    </message>
</context>
<context>
    <name>QLowEnergyController</name>
    <message>
        <source>Remote device cannot be found</source>
        <translation />
    </message>
    <message>
        <source>Cannot find local adapter</source>
        <translation />
    </message>
    <message>
        <source>Error occurred during connection I/O</source>
        <translation />
    </message>
    <message>
        <source>Unknown Error</source>
        <translation />
    </message>
    <message>
        <source>Missing permission</source>
        <translation />
    </message>
    <message>
        <source>Error occurred trying to connect to remote device.</source>
        <translation />
    </message>
    <message>
        <source>Remote device closed the connection</source>
        <translation />
    </message>
    <message>
        <source>Failed to authorize on the remote device</source>
        <translation />
    </message>
    <message>
        <source>Missing permissions error</source>
        <translation />
    </message>
    <message>
        <source>Error reading RSSI value</source>
        <translation />
    </message>
    <message>
        <source>Advertisement data is larger than 31 bytes</source>
        <translation />
    </message>
    <message>
        <source>Advertisement feature not supported on the platform</source>
        <translation />
    </message>
    <message>
        <source>Error occurred trying to start advertising</source>
        <translation />
    </message>
    <message>
        <source>Failed due to too many advertisers</source>
        <translation />
    </message>
    <message>
        <source>Unknown advertisement error</source>
        <translation />
    </message>
</context>
</TS>