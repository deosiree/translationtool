<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CrossEventModel</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossEventModel.cpp" line="54"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossEventModel.cpp" line="56"/>
        <source>服务提供者</source>
        <translation type="unfinished">Service provider</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossEventModel.cpp" line="58"/>
        <source>事件功能</source>
        <translation type="unfinished">Event function</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossEventModel.cpp" line="60"/>
        <source>事件功能分组</source>
        <translation type="unfinished">Event function grouping</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossEventModel.cpp" line="62"/>
        <source>固定事件号</source>
        <translation type="unfinished">Fixed event ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossEventModel.cpp" line="64"/>
        <source>事件号</source>
        <translation type="unfinished">Event ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossEventModel.cpp" line="817"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossEventModel.cpp" line="817"/>
        <source>没有复制任何数据</source>
        <translation type="unfinished">No data is copied</translation>
    </message>
</context>
<context>
    <name>CrossSite</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.ui" line="14"/>
        <source>CrossSite</source>
        <translation type="unfinished">Cross-site</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.ui" line="111"/>
        <source>跨现场转发信息</source>
        <translation type="unfinished">Forwarding info across sites</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.ui" line="175"/>
        <source>跨现场事件转发表</source>
        <translation type="unfinished">Cross-site event forwarding table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="126"/>
        <source>本现场 (%1) 跨现场转发信息</source>
        <translation type="unfinished">Local site (%1) forwards info across sites</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="162"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="399"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="599"/>
        <source>新增</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="190"/>
        <source>导入</source>
        <translation type="unfinished">Import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="197"/>
        <source>打开文件</source>
        <translation type="unfinished">Open file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="218"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="282"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="528"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="834"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="218"/>
        <source>导入成功</source>
        <translation type="unfinished">Import successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="175"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="222"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="245"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="287"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="300"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="304"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="333"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="338"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="349"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="440"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="449"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="464"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="472"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="480"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="488"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="496"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="504"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="522"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="541"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="545"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="637"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="654"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="658"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="817"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="830"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="170"/>
        <source>编辑</source>
        <translation type="unfinished">Edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="175"/>
        <source>请选择一行进行编辑</source>
        <translation type="unfinished">Please select a line for editing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="222"/>
        <source>导入失败</source>
        <translation type="unfinished">Import failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="228"/>
        <source>导出</source>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="239"/>
        <source>选择导出文件</source>
        <translation type="unfinished">Select export file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="245"/>
        <source>文件名不能为空！</source>
        <translation type="unfinished">The file name cannot be empty!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="264"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="272"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="264"/>
        <source>命令启动失败</source>
        <translation type="unfinished">Command launch failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="272"/>
        <source>命令执行超时</source>
        <translation type="unfinished">Command execution timeout</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="282"/>
        <source>导出成功</source>
        <translation type="unfinished">Export successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="287"/>
        <source>导出失败</source>
        <translation type="unfinished">Export failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="293"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="534"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="648"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="300"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="333"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="541"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="654"/>
        <source>请至少选择一行</source>
        <translation type="unfinished">Please select at least one line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="305"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="546"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="659"/>
        <source>删除无法恢复，是否删除？</source>
        <translation type="unfinished">The deletion cannot be recovered. Whether to delete it?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="322"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="569"/>
        <source>代理节点IP信息</source>
        <translation type="unfinished">IP address of the proxy node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="323"/>
        <source>跨现场转发事件表</source>
        <translation type="unfinished">Forwarding event tables across sites</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="327"/>
        <source>查看详情</source>
        <translation type="unfinished">View details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="338"/>
        <source>只能选择一行</source>
        <translation type="unfinished">Only one line can be selected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="349"/>
        <source>反向类型没有代理节点信息</source>
        <translation type="unfinished">The reverse type has no proxy node info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="357"/>
        <source>同构类型详情</source>
        <translation type="unfinished">Isomorphic type details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="360"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="383"/>
        <source>目的现场</source>
        <translation type="unfinished">Dest site</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="364"/>
        <source>源现场</source>
        <translation type="unfinished">Source site</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="380"/>
        <source>正向类型详情</source>
        <translation type="unfinished">Forward type details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="412"/>
        <source>批量编辑</source>
        <translation type="unfinished">Bath edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="430"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="440"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="449"/>
        <source>没有修改数据</source>
        <translation type="unfinished">No modified data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="464"/>
        <source>%1 的A网和B网IP地址至少需要填写一个</source>
        <translation type="unfinished">At least one of the IP addresses (Net A or Net B) for %1 must be filled in</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="472"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="496"/>
        <source>%1 的A网IP地址不合法</source>
        <translation type="unfinished">Net A IP address of %1 is illegal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="480"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="488"/>
        <source>%1 的B网IP地址不合法</source>
        <translation type="unfinished">Net B IP address of %1 is illegal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="504"/>
        <source>%1 的A网和B网IP地址都不合法</source>
        <translation type="unfinished">Both the net A and net B IP addresses of %1 are invalid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="522"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="528"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="623"/>
        <source>新增固定事件号</source>
        <translation type="unfinished">Add fixed event ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="631"/>
        <source>复制全部事件</source>
        <translation type="unfinished">Copy all events</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="637"/>
        <source>没有数据可复制</source>
        <translation type="unfinished">No data to copy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="644"/>
        <source>粘贴</source>
        <translation type="unfinished">Paste</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="685"/>
        <source>目的现场 (%1) 代理节点IP信息列表</source>
        <translation type="unfinished">Destination site (%1) proxy node IP info list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="686"/>
        <source>目的现场 (%1) 跨现场转发事件列表</source>
        <translation type="unfinished">Destination site (%1) cross-site forwarding event list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="817"/>
        <source>请输入有效的十六进制数！</source>
        <translation type="unfinished">Please enter a valid hex number!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="830"/>
        <source>保存失败！</source>
        <translation type="unfinished">Save failed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="834"/>
        <source>保存成功！</source>
        <translation type="unfinished">Save successfully!</translation>
    </message>
</context>
<context>
    <name>CrossSiteDetailModel</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossSiteDetailModel.cpp" line="32"/>
        <source>节点</source>
        <translation type="unfinished">Node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossSiteDetailModel.cpp" line="34"/>
        <source>A网IP</source>
        <translation type="unfinished">A-net IP address</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossSiteDetailModel.cpp" line="36"/>
        <source>B网IP</source>
        <translation type="unfinished">B-net IP address</translation>
    </message>
</context>
<context>
    <name>CrosssiteModel</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="34"/>
        <source>目的现场</source>
        <translation type="unfinished">Dest site</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="36"/>
        <source>转发类型</source>
        <translation type="unfinished">Forwarding type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="62"/>
        <source>未配置</source>
        <translation type="unfinished">No Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="63"/>
        <source>跨对等现场</source>
        <translation type="unfinished">Cross-peer site</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="64"/>
        <source>跨正向隔离</source>
        <translation type="unfinished">Cross-forward isolation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="65"/>
        <source>跨反向隔离</source>
        <translation type="unfinished">Cross-reverse isolation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="66"/>
        <source>未知类型</source>
        <translation type="unfinished">Unknown type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="191"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="193"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="225"/>
        <source>代理节点</source>
        <translation type="unfinished">Proxy node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="191"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="193"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="225"/>
        <source>节点ip1</source>
        <translation type="unfinished">Node IP 1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="191"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="193"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="225"/>
        <source>节点ip2</source>
        <translation type="unfinished">Node IP2</translation>
    </message>
</context>
<context>
    <name>MEventGroupModel</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/MEventGroupModel.cpp" line="37"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/MEventGroupModel.cpp" line="39"/>
        <source>分组名</source>
        <translation type="unfinished">Group name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/MEventGroupModel.cpp" line="41"/>
        <source>分组描述</source>
        <translation type="unfinished">Group description</translation>
    </message>
</context>
<context>
    <name>MTdbModel</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/MTdbModel.cpp" line="37"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/MTdbModel.cpp" line="39"/>
        <source>应用名</source>
        <translation type="unfinished">App name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/MTdbModel.cpp" line="41"/>
        <source>库名</source>
        <translation type="unfinished">DB name</translation>
    </message>
</context>
<context>
    <name>NewCrossEvent</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.ui" line="14"/>
        <source>新建跨现场转发事件</source>
        <translation type="unfinished">New cross-site forwarding event</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.ui" line="68"/>
        <source>服务提供者选择：</source>
        <translation type="unfinished">Service Provider Selection:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.ui" line="75"/>
        <source>实时库</source>
        <translation type="unfinished">TDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.ui" line="82"/>
        <source>应用</source>
        <translation type="unfinished">App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.ui" line="182"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="91"/>
        <source>转发事件功能选择</source>
        <translation type="unfinished">Function</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.ui" line="312"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="92"/>
        <source>转发事件功能分组选择</source>
        <translation type="unfinished">Group</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="57"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="58"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="404"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="404"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="415"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="421"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="430"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="437"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="461"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="470"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="479"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="493"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="502"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="511"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="527"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="536"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="545"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="559"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="568"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="577"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="415"/>
        <source>请至少选择一个实时库</source>
        <translation type="unfinished">Please select at least one TDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="421"/>
        <source>请至少选择一个应用</source>
        <translation type="unfinished">Please select at least one application</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="430"/>
        <source>请至少选择一个功能项</source>
        <translation type="unfinished">Please select at least one function</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="437"/>
        <source>请至少选择一个事件组</source>
        <translation type="unfinished">Please select at least one event group</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="460"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="469"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="478"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="492"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="501"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="510"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="526"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="535"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="544"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="558"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="567"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="576"/>
        <source>写入数据库失败，错误码：</source>
        <translation type="unfinished">Failed to write to db, error code:</translation>
    </message>
</context>
<context>
    <name>NewCrossSiteDialog</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.ui" line="14"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="68"/>
        <source>新建跨现场</source>
        <translation type="unfinished">New cross-site</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.ui" line="25"/>
        <source>目的现场名：</source>
        <translation type="unfinished">Dest site name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.ui" line="39"/>
        <source>转发类型：</source>
        <translation type="unfinished">Forwarding type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.ui" line="46"/>
        <source>正向</source>
        <translation type="unfinished">Forward direction</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.ui" line="53"/>
        <source>反向</source>
        <translation type="unfinished">Reverse direction</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.ui" line="60"/>
        <source>同构</source>
        <translation type="unfinished">Isomorphic</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="28"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="29"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="49"/>
        <source>编辑跨现场</source>
        <translation type="unfinished">Edit cross site</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="136"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="148"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="167"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="136"/>
        <source>现场名称不能为空！</source>
        <translation type="unfinished">The site name cannot be empty!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="148"/>
        <source>获取跨现场信息失败！</source>
        <translation type="unfinished">Failed to retrieve cross site info!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="167"/>
        <source>保存失败！</source>
        <translation type="unfinished">Save failed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="171"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="171"/>
        <source>保存成功！</source>
        <translation type="unfinished">Save successfully!</translation>
    </message>
</context>
<context>
    <name>ProxyNodeDialog</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="22"/>
        <source>A网地址</source>
        <translation type="unfinished">A_Net address</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="22"/>
        <source>B网地址</source>
        <translation type="unfinished">B_Net address</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="31"/>
        <source>新增代理节点</source>
        <translation type="unfinished">Add proxy node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="32"/>
        <source>删除代理节点</source>
        <translation type="unfinished">Delete proxy node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="33"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="46"/>
        <source>节点管理</source>
        <translation type="unfinished">Node management</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="55"/>
        <source>编辑节点</source>
        <translation type="unfinished">Edit node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="58"/>
        <source>新增节点</source>
        <translation type="unfinished">Add node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="75"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="93"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="183"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="75"/>
        <source>获取节点IP数据失败</source>
        <translation type="unfinished">Failed to retrieve node IP data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="93"/>
        <source>请选择要删除的节点</source>
        <translation type="unfinished">Please select the node to delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="183"/>
        <source>删除原有节点IP失败</source>
        <translation type="unfinished">Failed to delete the original node IP</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="126"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="197"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="126"/>
        <source>无效的oid！</source>
        <translation type="unfinished">Invalid oid!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="148"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="158"/>
        <source>无效IP地址</source>
        <translation type="unfinished">Invalid IP address</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="149"/>
        <source>第 %1 行的 A 网地址不合法！</source>
        <translation type="unfinished">The A-net address on line %1 is not legal!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="159"/>
        <source>第 %1 行的 B 网地址不合法！</source>
        <translation type="unfinished">The B-net address on line %1 is not legal!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="197"/>
        <source>保存代理节点失败！</source>
        <translation type="unfinished">Failed to save proxy node!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="201"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="201"/>
        <source>所有代理节点已成功保存！</source>
        <translation type="unfinished">All agent nodes saved successfully!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossSiteDetailModel.cpp" line="171"/>
        <source>节点%1</source>
        <translation type="unfinished">Node %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/HexSaveDialog.cpp" line="5"/>
        <source>固定事件号</source>
        <translation type="unfinished">Fixed event ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/HexSaveDialog.cpp" line="9"/>
        <source>请输入8字节的16进制数：</source>
        <translation type="unfinished">Please enter an 8-byte hexadecimal number:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/HexSaveDialog.cpp" line="19"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/HexSaveDialog.cpp" line="30"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/HexSaveDialog.cpp" line="40"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/HexSaveDialog.cpp" line="30"/>
        <source>输入有效的8字节16进制数</source>
        <translation type="unfinished">Enter a valid 8-byte hexadecimal number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/HexSaveDialog.cpp" line="40"/>
        <source>16进制数长度不足8字节</source>
        <translation type="unfinished">Hexadecimal number length is less than 8 bytes</translation>
    </message>
</context>
<context>
    <name>eventMenu</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/eventMenu.cpp" line="11"/>
        <source>新增</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/eventMenu.cpp" line="40"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/eventMenu.cpp" line="41"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
</context>
</TS>
