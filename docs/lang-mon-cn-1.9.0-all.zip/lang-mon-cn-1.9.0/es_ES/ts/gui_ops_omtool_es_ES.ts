<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CSecOmTool</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/omtool.cpp" line="334"/>
        <source>系统运维分析(节点名:%1)</source>
        <comment>toolName</comment>
        <translation type="unfinished">Análisis de Sysops (Nodo:%1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/omtool.cpp" line="387"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/omtool.cpp" line="387"/>
        <source>%1无权限打开此工具</source>
        <translation type="unfinished">%1 sin permiso para abrir esta herramienta</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/main.cpp" line="102"/>
        <source>节点：%1 工具：%2 %3</source>
        <translation type="unfinished">Nodo: %1 Herramienta: %2 %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/main.cpp" line="130"/>
        <source>登录模式不支持，请检查系统</source>
        <translation type="unfinished">Modo de login no soportado, revise sist.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/main.cpp" line="131"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/main.cpp" line="424"/>
        <source>登录时限：</source>
        <translation type="unfinished">Límite de tiempo de inicio de sesión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1625"/>
        <source>进程未存活，设置日志等级失败</source>
        <translation type="unfinished">Proceso no activo, fallo al setear nivel log</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/omtool.cpp" line="326"/>
        <source>系统运维分析</source>
        <comment>toolName</comment>
        <translation type="unfinished">Análisis de Operaciones del Sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/rec_his_log_worker.cpp" line="57"/>
        <source>历史日志接收超时</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>app_debug</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.ui" line="84"/>
        <source>图标</source>
        <translation type="unfinished">ícono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.ui" line="91"/>
        <source>方法描述：</source>
        <translation type="unfinished">Descripción del método:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.ui" line="139"/>
        <source>调用记录：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Registro de llamadas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.ui" line="159"/>
        <source>调用</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Llamada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.ui" line="194"/>
        <source>调用返回结果：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Resultado de la devolución de llamada:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.cpp" line="36"/>
        <source>功能名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de la función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.cpp" line="37"/>
        <source>时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Hora</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.cpp" line="38"/>
        <source>执行结果</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Ejecutar resultados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.cpp" line="74"/>
        <source>获取数据交换调试方法失败</source>
        <translation type="unfinished">Fallo al obtener método de depuración intercambio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.cpp" line="80"/>
        <source>数据交换调试方法为空</source>
        <translation type="unfinished">Método de depuración intercambio vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.cpp" line="113"/>
        <source>参数：</source>
        <translation type="unfinished">Parámetros:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.cpp" line="162"/>
        <source>失败</source>
        <translation type="unfinished">Fallido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.cpp" line="164"/>
        <source>成功</source>
        <translation type="unfinished">Éxito</translation>
    </message>
</context>
<context>
    <name>app_debug_tab</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.cpp" line="237"/>
        <source>回到首页</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.cpp" line="238"/>
        <source>返回主界面</source>
        <translation type="unfinished">Volver a la interfaz principal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.cpp" line="243"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/app_debug.cpp" line="254"/>
        <source>数据交互</source>
        <translation type="unfinished">Interacción de datos</translation>
    </message>
</context>
<context>
    <name>back_model_info</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2202"/>
        <source>保存为模板</source>
        <translation type="unfinished">Guardar como</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2216"/>
        <source> 记录名称：</source>
        <translation type="unfinished">Nombre del registro:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2218"/>
        <source>请输入记录名称</source>
        <translation type="unfinished">Por favor, ingrese un nombre de registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2221"/>
        <source>备注信息：</source>
        <translation type="unfinished">Observaciones:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2223"/>
        <source>请输入备注信息</source>
        <translation type="unfinished">Por favor, ingrese las observaciones</translation>
    </message>
</context>
<context>
    <name>choose_func</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="161"/>
        <source>临时日志</source>
        <translation type="unfinished">Registro temporal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="162"/>
        <source>永久日志</source>
        <translation type="unfinished">Registro permanente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="113"/>
        <source>进程选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar Progreso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="138"/>
        <source>时间范围：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Rango de tiempo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="157"/>
        <source>类型：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tipo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="166"/>
        <source>等级：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nivel:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="192"/>
        <source>已选进程：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Proceso seleccionado:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="213"/>
        <source>节点维度</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Dimensión del Nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="219"/>
        <source>应用维度</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Dimensión de la Aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="230"/>
        <source>名称</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="230"/>
        <source>时间</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Hora</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="233"/>
        <source>工具日志</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Registro de la Herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="306"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="481"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="867"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="904"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1155"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1169"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1294"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="306"/>
        <source>获取系统信息库节点信息失败</source>
        <translation type="unfinished">Fallo al obtener info. nodos BD sist.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="481"/>
        <source>系统信息库节点信息为空，无法选取进程</source>
        <translation type="unfinished">Info. nodos BD sistema vacía, no procesos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="867"/>
        <source>实时日志模块目前最多支持同时订阅%1个进程</source>
        <translation type="unfinished">Máx. %1 procesos logs real simultáneos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="904"/>
        <source>历史日志模块目前最多支持同时调阅%1个进程</source>
        <translation type="unfinished">Máx. %1 procesos hist. logs simultáneos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1156"/>
        <source>变更日志的永久或非永久属性，将重新加载列表</source>
        <translation type="unfinished">Cambiar atributo perm. recarga lista</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1169"/>
        <source>日期选择错误</source>
        <translation type="unfinished">Error en selección de fecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1295"/>
        <source>获取节点日志列表失败，retCode：%1 %2</source>
        <translation type="unfinished">Falló al obtener la lista de registros del nodo, retCode: %1 %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1314"/>
        <source>空</source>
        <translation type="unfinished">Nulo</translation>
    </message>
</context>
<context>
    <name>choose_func_wg</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="39"/>
        <source>请输入关键字查询</source>
        <translation type="unfinished">Por favor, ingrese la búsqueda por palabra clave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="47"/>
        <source>名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="47"/>
        <source>网络注册名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">RegName de red</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="47"/>
        <source>状态</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Estado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.ui" line="44"/>
        <source>选择历史</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Seleccionar historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.ui" line="75"/>
        <source>搜索</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Buscar</translation>
    </message>
</context>
<context>
    <name>chose_column</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/chose_column.cpp" line="7"/>
        <source>行号</source>
        <translation type="unfinished">ID de línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/chose_column.cpp" line="8"/>
        <source>节点</source>
        <translation type="unfinished">Nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/chose_column.cpp" line="9"/>
        <source>日志内容</source>
        <translation type="unfinished">Contenido del registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/chose_column.cpp" line="10"/>
        <source>文件名称</source>
        <translation type="unfinished">Nombre del archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/chose_column.cpp" line="11"/>
        <source>函数名称</source>
        <translation type="unfinished">Nombre de la función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/chose_column.cpp" line="12"/>
        <source>日志等级</source>
        <translation type="unfinished">Nivel de registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/chose_column.cpp" line="13"/>
        <source>进程号</source>
        <translation type="unfinished">Número de proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/chose_column.cpp" line="14"/>
        <source>进程名</source>
        <translation type="unfinished">Nombre del proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/chose_column.cpp" line="15"/>
        <source>时间</source>
        <translation type="unfinished">Tiempo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/chose_column.cpp" line="16"/>
        <source>线程号</source>
        <translation type="unfinished">ID de hilo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/chose_column.cpp" line="18"/>
        <source>自定义列表显示字段</source>
        <comment>toolName</comment>
        <translation type="unfinished">Personalizar Campos de Visualización de Lista</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/chose_column.cpp" line="28"/>
        <source>请选择表格日志需要展示的字段内容：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Seleccione los campos que se mostrarán en el registro de la tabla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/chose_column.cpp" line="29"/>
        <source>列表字段可拖拽排序</source>
        <translation type="unfinished">Los campos de la lista pueden ser arrastrados y ordenados</translation>
    </message>
</context>
<context>
    <name>editFileStatus</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="1168"/>
        <source>未处理</source>
        <translation type="unfinished">No procesado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="1168"/>
        <source>已分析</source>
        <translation type="unfinished">Analizado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="1168"/>
        <source>已消缺</source>
        <translation type="unfinished">Eliminado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="1172"/>
        <source>故障状态记录</source>
        <comment>toolName</comment>
        <translation type="unfinished">Registro de Estado de Falla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="1180"/>
        <source>处理记录:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Procesando registros:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="1182"/>
        <source>故障状态:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Estado de falla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="1191"/>
        <source>请输入处理备注</source>
        <translation type="unfinished">Ingrese comentario de procesamiento</translation>
    </message>
</context>
<context>
    <name>edit_condition</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.ui" line="44"/>
        <source>可选字段：</source>
        <translation type="unfinished">Campos opcionales:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.ui" line="52"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.cpp" line="145"/>
        <source>日志等级</source>
        <translation type="unfinished">Nivel de registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.ui" line="57"/>
        <source>时间</source>
        <translation type="unfinished">Tiempo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.ui" line="62"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.cpp" line="197"/>
        <source>进程号</source>
        <translation type="unfinished">Número de proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.ui" line="67"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.cpp" line="209"/>
        <source>线程号</source>
        <translation type="unfinished">ID de hilo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.ui" line="72"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.cpp" line="221"/>
        <source>进程名</source>
        <translation type="unfinished">Nombre del proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.ui" line="77"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.cpp" line="233"/>
        <source>文件名称</source>
        <translation type="unfinished">Nombre del archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.ui" line="82"/>
        <source>函数名</source>
        <translation type="unfinished">Nombre de la función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.ui" line="87"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.cpp" line="257"/>
        <source>日志内容</source>
        <translation type="unfinished">Contenido del registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.ui" line="101"/>
        <source>可选值：</source>
        <translation type="unfinished">Valores opcionales:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.ui" line="170"/>
        <source>开始时间</source>
        <translation type="unfinished">Anteayer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.ui" line="187"/>
        <source>结束时间</source>
        <translation type="unfinished">Hora de finalización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.ui" line="358"/>
        <source>条件选择结果：</source>
        <translation type="unfinished">Condición:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.ui" line="378"/>
        <source>清空</source>
        <translation type="unfinished">Borrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.cpp" line="107"/>
        <source>日志过滤条件选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar Condición de Filtro de Registro </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.cpp" line="155"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.cpp" line="155"/>
        <source>日期选择错误，请重新选择</source>
        <translation type="unfinished">Error en selección de fecha, reintente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.cpp" line="163"/>
        <source>时间范围</source>
        <translation type="unfinished">Rango de tiempo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/edit_condition.cpp" line="245"/>
        <source>函数名称</source>
        <translation type="unfinished">Nombre de la función</translation>
    </message>
</context>
<context>
    <name>fault_report</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.ui" line="140"/>
        <source>自选日期</source>
        <translation type="unfinished">Seleccionar fecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="91"/>
        <source>报告未处理</source>
        <translation type="unfinished">Reporte no procesado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="92"/>
        <source>报告已分析</source>
        <translation type="unfinished">Reporte analizado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="93"/>
        <source>报告已消缺</source>
        <translation type="unfinished">Reporte ha sido borrado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="125"/>
        <source>故障报告</source>
        <translation type="unfinished">Reporte de fallos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="128"/>
        <source>刷新目录</source>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="133"/>
        <source>返回主界面</source>
        <translation type="unfinished">Volver a la interfaz principal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="149"/>
        <source>全部</source>
        <translation type="unfinished">Todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="149"/>
        <source>当日</source>
        <translation type="unfinished">En el día</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="149"/>
        <source>近两天</source>
        <translation type="unfinished">Últimos dos días</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="149"/>
        <source>近三天</source>
        <translation type="unfinished">Últimos tres días</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="149"/>
        <source>近一周</source>
        <translation type="unfinished">Última semana</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="149"/>
        <source>近一个月</source>
        <translation type="unfinished">El mes pasado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="232"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="370"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="400"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="409"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="578"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="587"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="599"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="786"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="1027"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="232"/>
        <source>获取状态失败，请刷新目录重新获取</source>
        <translation type="unfinished">Fallo al obtener estado, actualice dir.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="352"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="361"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="380"/>
        <source>获取文件失败</source>
        <translation type="unfinished">Fallo al obtener archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="400"/>
        <source>读取文件失败，请检查文件是否存在</source>
        <translation type="unfinished">Fallo al leer archivo, verifique existencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="566"/>
        <source>节点 %1 svc_net_ftp 登录失败</source>
        <translation type="unfinished">Nodo %1 svc_net_ftp login falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="577"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="587"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="599"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="786"/>
        <source>当前目录下无文件</source>
        <translation type="unfinished">No hay archivos en dir. actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="610"/>
        <source>节点 %1 获取状态目录失败</source>
        <translation type="unfinished">Nodo %1 falló al obtener dir. de estado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="1027"/>
        <source>日期选择错误，请重新选择</source>
        <translation type="unfinished">Error en selec. de fecha, reelija</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="352"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="361"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="380"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="127"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="132"/>
        <source>回到首页</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="146"/>
        <source>设置处理状态</source>
        <comment>menuName</comment>
        <translation type="unfinished">Estar estad proc</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="368"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="407"/>
        <source>文件大小为 %1 MB, 文件过大, 是否继续?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="371"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="410"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="371"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="410"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="441"/>
        <source>节点</source>
        <translation type="unfinished">Nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="474"/>
        <source>crash</source>
        <translation type="unfinished">crash</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="478"/>
        <source>asan</source>
        <translation type="unfinished">asan</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="567"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="611"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
</context>
<context>
    <name>find_text_browser</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="548"/>
        <source>关闭</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="549"/>
        <source>查找</source>
        <translation type="unfinished">Buscar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="550"/>
        <source>上一个</source>
        <translation type="unfinished">Anterior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="551"/>
        <source>下一个</source>
        <translation type="unfinished">Siguiente</translation>
    </message>
</context>
<context>
    <name>log_model</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="12"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="47"/>
        <source>日志等级</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nivel de registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="13"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="49"/>
        <source>时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Hora</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="14"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="51"/>
        <source>进程号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">PID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="15"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="53"/>
        <source>线程号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">ID del hilo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="16"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="55"/>
        <source>进程名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre del proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="17"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="57"/>
        <source>文件名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre del archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="18"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="59"/>
        <source>函数名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de la función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="19"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="61"/>
        <source>行号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">ID de línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="20"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="63"/>
        <source>日志内容</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Contenido del registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_model.cpp" line="65"/>
        <source>应用信息</source>
        <comment>subTitle</comment>
        <translation type="unfinished">App Info</translation>
    </message>
</context>
<context>
    <name>log_view</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="38"/>
        <source>日志信息展示</source>
        <translation type="unfinished">Información de registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="43"/>
        <source>保存为模板</source>
        <translation type="unfinished">Guardar como</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="47"/>
        <source>自定义列表显示字段</source>
        <translation type="unfinished">Personalizar los campos de visualización de la lista</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="51"/>
        <source>返回主界面</source>
        <translation type="unfinished">Volver a la interfaz principal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="42"/>
        <source>保存为模板记录</source>
        <comment>toolName</comment>
        <translation type="unfinished">Guardar como Modelo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="52"/>
        <source>回到首页</source>
        <comment>toolName</comment>
        <translation type="unfinished">Inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="66"/>
        <source>日志等级设置</source>
        <translation type="unfinished">Configuración del nivel de registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="70"/>
        <source>数据交互</source>
        <translation type="unfinished">Interacción de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="177"/>
        <source>查找</source>
        <translation type="unfinished">Buscar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="181"/>
        <source>上一个</source>
        <translation type="unfinished">Anterior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="185"/>
        <source>下一个</source>
        <translation type="unfinished">Siguiente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="189"/>
        <source>关闭</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="431"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="437"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="452"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="562"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="567"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1138"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1576"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1588"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1631"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1635"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1655"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1742"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1780"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1788"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1828"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1836"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1890"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2026"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2187"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="431"/>
        <source>记录名称不允许为空</source>
        <translation type="unfinished">Nombre de registro no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="453"/>
        <source>配置文件解析错误，模板保存失败，请检查配置文件</source>
        <translation type="unfinished">Error al analizar config., guardado falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="562"/>
        <source>模板保存失败，请检查配置文件</source>
        <translation type="unfinished">Fallo al guardar plantilla, revise config.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="567"/>
        <source>模板保存成功</source>
        <translation type="unfinished">Plantilla guardada con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="613"/>
        <source>日志等级</source>
        <translation type="unfinished">Nivel de registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="620"/>
        <source>进程号</source>
        <translation type="unfinished">Número de proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="627"/>
        <source>线程号</source>
        <translation type="unfinished">ID de hilo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="634"/>
        <source>进程名</source>
        <translation type="unfinished">Nombre del proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="641"/>
        <source>文件名称</source>
        <translation type="unfinished">Nombre del archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="648"/>
        <source>函数名称</source>
        <translation type="unfinished">Nombre de la función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="655"/>
        <source>日志内容</source>
        <translation type="unfinished">Contenido del registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="898"/>
        <source>应用信息</source>
        <comment>subTitle</comment>
        <translation type="unfinished">App Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="898"/>
        <source>时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Hora</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="898"/>
        <source>日志等级</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nivel de registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="898"/>
        <source>进程号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">PID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="898"/>
        <source>线程号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">ID del hilo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="898"/>
        <source>进程名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre del proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="898"/>
        <source>文件名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre del archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="899"/>
        <source>行号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">ID de línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="899"/>
        <source>函数名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de la función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="899"/>
        <source>日志内容</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Contenido del registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1166"/>
        <source>关闭窗口</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1168"/>
        <source>全选</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1170"/>
        <source>一键删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar con un clic</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1588"/>
        <source>日志句柄获取失败，日志等级获取失败</source>
        <translation type="unfinished">Fallo al obtener manejador de log</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1630"/>
        <source>设置结果：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1635"/>
        <source>日志等级设置成功</source>
        <translation type="unfinished">Ajuste de nivel de log exitoso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1660"/>
        <source>数据交互</source>
        <comment>toolName</comment>
        <translation type="unfinished">Interacción de Datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1742"/>
        <source>订阅失败，请检查系统是否正常</source>
        <translation type="unfinished">Suscripción falló, revise sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1788"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1836"/>
        <source>取消订阅失败，请检查系统是否正常</source>
        <translation type="unfinished">Cancelar de suscripción falló, revise sist.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1964"/>
        <source>长时间无操作，实时日志监视已于[%1]自动停止</source>
        <translation type="unfinished">Sin operación por mucho tiempo, logs parados [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2026"/>
        <source>请输入至少3个字符</source>
        <translation type="unfinished">Ingrese al menos 3 caracteres</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="437"/>
        <source>名称重复</source>
        <translation type="unfinished">Nombre duplicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="662"/>
        <source>时间范围</source>
        <translation type="unfinished">Rango de tiempo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1139"/>
        <source>是否清空当前日志</source>
        <translation type="unfinished">¿Limpiar log actual?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1517"/>
        <source>实时日志信息展示</source>
        <translation type="unfinished">Información de registro en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1525"/>
        <source>历史日志信息展示</source>
        <translation type="unfinished">Información del historial de registros</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1526"/>
        <source>日志文件</source>
        <translation type="unfinished">Archivos de registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1576"/>
        <source>未订阅程序，无法进行日志等级设置</source>
        <translation type="unfinished">No suscrito, no se puede ajustar nivel log</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1655"/>
        <source>未订阅程序，无法进行程序调试</source>
        <translation type="unfinished">Programa no suscrito, no depurable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1763"/>
        <source> 订阅失败，错误码：</source>
        <translation type="unfinished">Fallo en la suscripción, código de error:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1817"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="1859"/>
        <source> 取消订阅失败，错误码：</source>
        <translation type="unfinished">Fallo en la cancelación de la suscripción, código de error:</translation>
    </message>
</context>
<context>
    <name>logtool_view</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.ui" line="58"/>
        <source>编辑表头</source>
        <translation type="unfinished">Editar encabezado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.ui" line="75"/>
        <source>保存为历史记录</source>
        <translation type="unfinished">Guardar como historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.ui" line="92"/>
        <source>回到首页</source>
        <translation type="unfinished">Inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.ui" line="138"/>
        <source>监视进程：</source>
        <translation type="unfinished">Proceso de monitoreo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.ui" line="184"/>
        <source>添加进程</source>
        <translation type="unfinished">Agregar proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.ui" line="191"/>
        <source>开始接收</source>
        <translation type="unfinished">Comenzar a recibir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.ui" line="214"/>
        <source>日志等级设置</source>
        <translation type="unfinished">Configuración del nivel de registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.ui" line="221"/>
        <source>数据交互</source>
        <translation type="unfinished">Interacción de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.ui" line="249"/>
        <source>编辑条件</source>
        <translation type="unfinished">Editar condiciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.ui" line="266"/>
        <source>切换模式</source>
        <translation type="unfinished">Cambiar modo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.ui" line="273"/>
        <source>清除日志</source>
        <translation type="unfinished">Borrado de registros</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.ui" line="337"/>
        <source>查找</source>
        <translation type="unfinished">Buscar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.ui" line="344"/>
        <source>上一个</source>
        <translation type="unfinished">Anterior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.ui" line="351"/>
        <source>下一个</source>
        <translation type="unfinished">Siguiente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.ui" line="358"/>
        <source>关闭</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
</context>
<context>
    <name>manager_app</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.ui" line="35"/>
        <source>实时日志监视</source>
        <translation type="unfinished">Registro en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.ui" line="42"/>
        <source>历史日志查询</source>
        <translation type="unfinished">Registro histórico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.ui" line="49"/>
        <source>数据交互</source>
        <translation type="unfinished">Interacción de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.ui" line="56"/>
        <source>故障报告</source>
        <translation type="unfinished">Reporte de fallos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.ui" line="146"/>
        <source>请输入关键字查询</source>
        <translation type="unfinished">Por favor, ingrese la búsqueda por palabra clave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.ui" line="153"/>
        <source>查询</source>
        <translation type="unfinished">Consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.ui" line="200"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="16"/>
        <source>历史记录</source>
        <translation type="unfinished">Historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="20"/>
        <source>名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="21"/>
        <source>备注信息</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Observaciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="22"/>
        <source>记录类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tipo de registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="23"/>
        <source>操作</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="75"/>
        <source>实时日志</source>
        <translation type="unfinished">Registro en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="77"/>
        <source>历史日志</source>
        <translation type="unfinished">Registro histórico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="245"/>
        <source>重命名</source>
        <translation type="unfinished">Renombrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="252"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="259"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="267"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="295"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="316"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="324"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="354"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="252"/>
        <source>记录名称不允许为空</source>
        <translation type="unfinished">Nombre de registro no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="259"/>
        <source>名称重复</source>
        <translation type="unfinished">Nombre duplicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="267"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="324"/>
        <source>记录修改失败，请检查记录文件，重新启动程序</source>
        <translation type="unfinished">Fallo al modificar registro, revise archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="290"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="320"/>
        <source>是否删除</source>
        <translation type="unfinished">¿Eliminar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="295"/>
        <source>删除失败</source>
        <translation type="unfinished">Fallo al eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="316"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Seleccione datos para operar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="354"/>
        <source>配置文件解析错误，请检查配置文件</source>
        <translation type="unfinished">Error al analizar config., verifique archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="290"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="320"/>
        <source>删除确认</source>
        <translation type="unfinished">Confirmación de eliminación</translation>
    </message>
</context>
<context>
    <name>omtool</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/omtool.cpp" line="147"/>
        <source>实时报文监视将于 %1 后停止</source>
        <translation type="unfinished">Monitoreo de mensajes finaliza en %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/omtool.cpp" line="153"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/omtool.cpp" line="153"/>
        <source>闲置超时，实时日志监视已退出</source>
        <translation type="unfinished">Timeout ocioso, monitoreo logs detenido</translation>
    </message>
</context>
<context>
    <name>opt_button_widget</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="361"/>
        <source>重命名</source>
        <translation type="unfinished">Renombrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/manager_app.cpp" line="365"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
</context>
<context>
    <name>progressDlg</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="849"/>
        <source>查询状态：</source>
        <translation type="unfinished">Estado de consulta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="862"/>
        <source>日志查询请求中</source>
        <translation type="unfinished">Solicitud de consulta de logs en curso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="890"/>
        <source>取消查询</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="891"/>
        <source>关闭</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="904"/>
        <source>历史日志查询状态</source>
        <translation type="unfinished">Estado de la consulta de registro histórico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="925"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="993"/>
        <source>%1 接收异常， 错误码： %2  %3 </source>
        <translation type="unfinished">Excepción de recepción %1, código de error: %2 %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="935"/>
        <source>历史日志接收中</source>
        <translation type="unfinished">Recibiendo logs históricos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="941"/>
        <source>历史日志查询完成</source>
        <translation type="unfinished">Consulta de logs históricos completada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="961"/>
        <source>历史日志查询已取消</source>
        <translation type="unfinished">Consulta de logs históricos cancelada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="946"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="952"/>
        <source>历史日志合并中</source>
        <translation type="unfinished">Combinando logs históricos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/com_widget.cpp" line="975"/>
        <source>已接收条数：%1</source>
        <translation type="unfinished">Conteo de mensajes recibidos: %1</translation>
    </message>
</context>
<context>
    <name>rec_his_log_worker</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/rec_his_log_worker.cpp" line="249"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/rec_his_log_worker.cpp" line="283"/>
        <source> 查询失败，错误码：</source>
        <translation type="unfinished">Consulta fallida, código de error:</translation>
    </message>
</context>
<context>
    <name>setFileTimeDlg</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="1229"/>
        <source>开始时间:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Hora de inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="1230"/>
        <source>结束时间:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Hora de finalización:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="1249"/>
        <source>设置文件日期</source>
        <comment>toolName</comment>
        <translation type="unfinished">Establecer Fecha del Archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="1270"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/fault_report.cpp" line="1270"/>
        <source>日期选择错误，请重新选择</source>
        <translation type="unfinished">Error en selección de fecha, reintente</translation>
    </message>
</context>
<context>
    <name>set_log_level</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2240"/>
        <source>日志等级设置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Configuración del Nivel de Registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2256"/>
        <source>日志等级：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nivel de registro:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2274"/>
        <source>有效期：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Periodo de validez:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2279"/>
        <source>30分钟</source>
        <translation type="unfinished">30min</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2282"/>
        <source>60分钟</source>
        <translation type="unfinished">60min</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2285"/>
        <source>3小时</source>
        <translation type="unfinished">3h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2288"/>
        <source>6小时</source>
        <translation type="unfinished">6h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2291"/>
        <source>12小时</source>
        <translation type="unfinished">12h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2294"/>
        <source>24小时</source>
        <translation type="unfinished">24 h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2305"/>
        <source>小时</source>
        <translation type="unfinished">h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2305"/>
        <source>分钟</source>
        <translation type="unfinished">min</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/logtool_view.cpp" line="2305"/>
        <source>秒</source>
        <translation type="unfinished">seg</translation>
    </message>
</context>
<context>
    <name>viewHisFileInfo</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1351"/>
        <source>时间范围：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Rango de tiempo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1370"/>
        <source>日志类型：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tipo de registro:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1373"/>
        <source>永久日志</source>
        <translation type="unfinished">Registro permanente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1374"/>
        <source>临时日志</source>
        <translation type="unfinished">Registro temporal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1383"/>
        <source>日志等级：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nivel de registro:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1401"/>
        <source>节点：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nodo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1402"/>
        <source>应用：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Aplicación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1403"/>
        <source>程序：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Programa:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1448"/>
        <source>历史日志信息</source>
        <comment>toolName</comment>
        <translation type="unfinished">Info del Registro Histórico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1416"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1417"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1474"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_omtool/choose_func_wg.cpp" line="1474"/>
        <source>日期选择错误</source>
        <translation type="unfinished">Error en selec. de fecha</translation>
    </message>
</context>
</TS>
