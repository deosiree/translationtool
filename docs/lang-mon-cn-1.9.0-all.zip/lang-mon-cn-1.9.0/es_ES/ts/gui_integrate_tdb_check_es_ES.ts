<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.ui" line="84"/>
        <source>校验数据选择：</source>
        <translation type="unfinished">Seleccione los datos de verificación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.ui" line="117"/>
        <source>本地运行库</source>
        <translation type="unfinished">RTDB local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.ui" line="137"/>
        <source>本地维护库</source>
        <translation type="unfinished">MTDB local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.ui" line="165"/>
        <source>本地文件</source>
        <translation type="unfinished">Archivo local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="185"/>
        <source>文件选择</source>
        <translation type="unfinished">Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.ui" line="251"/>
        <source>应用名：</source>
        <translation type="unfinished">Nombre de la aplicación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.ui" line="279"/>
        <source>库名：</source>
        <translation type="unfinished">Nombre de la base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.ui" line="358"/>
        <source>日志消息：</source>
        <translation type="unfinished">Mensaje de registro:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="186"/>
        <source>开始校验</source>
        <translation type="unfinished">Verificar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="35"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="86"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="205"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="259"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="278"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="287"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="306"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="350"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="412"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="35"/>
        <source>注册失败</source>
        <translation type="unfinished">Fallo al registrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="86"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="205"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="412"/>
        <source>系统管理库映射为空</source>
        <translation type="unfinished">La asignación de base de datos de Sysmgr está vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="191"/>
        <source>文件选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="193"/>
        <source>开始校验</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Verificar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="240"/>
        <source>选择文件夹</source>
        <translation type="unfinished">Seleccionar carpeta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="259"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="287"/>
        <source>库名不能为空</source>
        <translation type="unfinished">El nombre de la base de datos no puede estar vacío.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="278"/>
        <source>数据连接失败</source>
        <translation type="unfinished">Conexión de datos fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="306"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="350"/>
        <source>数据连接映射失败</source>
        <translation type="unfinished">Conexión de datos fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="315"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="327"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="340"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="315"/>
        <source>库路径不能为空！</source>
        <translation type="unfinished">¡La ruta de la base de datos no puede estar vacía!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="327"/>
        <source>路径下无相关库文件</source>
        <translation type="unfinished">No hay archivo de base de datos relacionado en la ruta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="340"/>
        <source>库名不能为空！</source>
        <translation type="unfinished">¡El nombre de la base de datos no puede estar vacío!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="378"/>
        <source>校验成功!</source>
        <translation type="unfinished">¡Validación exitosa!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="390"/>
        <source>检测失败!</source>
        <translation type="unfinished">¡Detección fallida!</translation>
    </message>
</context>
<context>
    <name>NoticeWidget</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/noticewidget.cpp" line="58"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/noticewidget.h" line="65"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/noticewidget.ui" line="207"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
</context>
</TS>
