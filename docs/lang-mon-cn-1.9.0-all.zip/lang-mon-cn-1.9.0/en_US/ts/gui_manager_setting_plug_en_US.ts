<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AppSettingModuleConfigWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="74"/>
        <source>一级标题栏，%1重复</source>
        <translation type="unfinished">Main title bar, %1 is duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="78"/>
        <source>二级导航栏，%1重复</source>
        <translation type="unfinished">Secondary navigation bar, %1 is duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="86"/>
        <source>三级工具栏，%1重复</source>
        <translation type="unfinished">Tertiary toolbar, %1 is duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="108"/>
        <source>重置文件</source>
        <translation type="unfinished">Reset file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="108"/>
        <source>是否重置文件</source>
        <translation type="unfinished">Whether to reset file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="108"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="142"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="234"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="242"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="108"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="142"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="142"/>
        <source>应用发布</source>
        <translation type="unfinished">Application Publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="142"/>
        <source>是否发布</source>
        <translation type="unfinished">Published</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="166"/>
        <source>应用发布</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="170"/>
        <source>取消修改</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel changes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="172"/>
        <source>取消工具配置</source>
        <translation type="unfinished">Cancel Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="174"/>
        <source>上传</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Upload</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="234"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="242"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="242"/>
        <source>发布成功，重启界面管理器生效</source>
        <translation type="unfinished">Successfully published, restart the interface manager to take effect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="74"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="78"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="82"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="86"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="90"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="82"/>
        <source>%1</source>
        <translation type="unfinished">%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="90"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="168"/>
        <source>发布配置</source>
        <translation type="unfinished">Publish Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="176"/>
        <source>将本地文件上传到文件服务</source>
        <translation type="unfinished">Upload local files to file service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="234"/>
        <source>发布失败</source>
        <translation type="unfinished">Publish failed</translation>
    </message>
</context>
<context>
    <name>FCustomTreeWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="57"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="67"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="77"/>
        <source>请输入名称</source>
        <translation type="unfinished">Please enter name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="58"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="68"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="78"/>
        <source>请选择图标</source>
        <translation type="unfinished">Please select the icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="79"/>
        <source>请添加描述</source>
        <translation type="unfinished">Please add a description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="80"/>
        <source>请输入启动命令</source>
        <translation type="unfinished">Please enter the start command</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="114"/>
        <source>删除节点</source>
        <translation type="unfinished">Delete node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="114"/>
        <source>是否确定</source>
        <translation type="unfinished">Whether to confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="114"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="114"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="369"/>
        <source>新建</source>
        <translation type="unfinished">New</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="371"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="374"/>
        <source>上移</source>
        <translation type="unfinished">Move up</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="376"/>
        <source>下移</source>
        <translation type="unfinished">Move down</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="379"/>
        <source>验证</source>
        <translation type="unfinished">Verify</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="392"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="392"/>
        <source>图标</source>
        <translation type="unfinished">Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="392"/>
        <source>权限</source>
        <translation type="unfinished">Permission</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="392"/>
        <source>参数</source>
        <translation type="unfinished">Param</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="392"/>
        <source>描述</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="393"/>
        <source>跟随启动</source>
        <translation type="unfinished">Follow start</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="393"/>
        <source>跟随关闭</source>
        <translation type="unfinished">Follow close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="393"/>
        <source>推画面最大进程数量</source>
        <translation type="unfinished">Maximum Proc. for pushing graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="394"/>
        <source>手动启动最大进程数量</source>
        <translation type="unfinished">Manual Maximum Proc.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="394"/>
        <source>ID</source>
        <translation type="unfinished">ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="394"/>
        <source>B端URL</source>
        <translation type="unfinished">URL of browser</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="394"/>
        <source>B端参数</source>
        <translation type="unfinished">Params of browser</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="395"/>
        <source>登录类型</source>
        <translation type="unfinished">Login Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="395"/>
        <source>启动弹窗</source>
        <translation type="unfinished">Startup Dialog</translation>
    </message>
</context>
<context>
    <name>MyDelegate</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="94"/>
        <source>选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="122"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="179"/>
        <source>选择图标文件</source>
        <translation type="unfinished">Select icon file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="124"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="181"/>
        <source>PNG 文件</source>
        <translation type="unfinished">PNG file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="124"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="181"/>
        <source>SVG 文件</source>
        <translation type="unfinished">SVG file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="124"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="181"/>
        <source>JPG 文件</source>
        <translation type="unfinished">JPG file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="125"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="182"/>
        <source>图标文件</source>
        <translation type="unfinished">Icon file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="125"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="182"/>
        <source>所有文件</source>
        <translation type="unfinished">All files</translation>
    </message>
</context>
<context>
    <name>SettinWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="109"/>
        <source>基础配置</source>
        <translation type="unfinished">Basic Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="44"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="44"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="44"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="44"/>
        <source>存在未保存修改，是否保存发布？</source>
        <translation type="unfinished">Unsaved modifications. Save &amp; publish?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="108"/>
        <source>基础配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Basic Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="111"/>
        <source>平台工具配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Platform Tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="112"/>
        <source>平台工具配置</source>
        <translation type="unfinished">Platform Tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="119"/>
        <source>应用工具配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">App Tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="120"/>
        <source>应用工具配置</source>
        <translation type="unfinished">Application Tool Config</translation>
    </message>
</context>
<context>
    <name>SettingBaseConfigWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="66"/>
        <source>启动画面显示屏设置：</source>
        <translation type="unfinished">Startup graph display screen setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="68"/>
        <source>主屏</source>
        <translation type="unfinished">Main screen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="69"/>
        <source>副屏</source>
        <translation type="unfinished">Secondary screen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="76"/>
        <source>界面缩放：</source>
        <translation type="unfinished">Interface zooming:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="77"/>
        <source>允许缩放</source>
        <translation type="unfinished">Enable scaling</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="81"/>
        <source>工具窗口设置：</source>
        <translation type="unfinished">Tool window setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="82"/>
        <source>最小化到托盘</source>
        <translation type="unfinished">Minimize to tray </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="85"/>
        <source>最小化到悬浮球</source>
        <translation type="unfinished">Minimize to floater</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="86"/>
        <source>隐藏最大化按钮</source>
        <translation type="unfinished">Hide maximize button</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="88"/>
        <source>提示音设置：</source>
        <translation type="unfinished">Prompt tone setting: 	</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="89"/>
        <source>告警声音</source>
        <translation type="unfinished">Alarm voice</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="91"/>
        <source>音量：</source>
        <translation type="unfinished">Volume:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="97"/>
        <source>系统行为设置：</source>
        <translation type="unfinished">System behavior setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="98"/>
        <source>解列退出</source>
        <translation type="unfinished">Split exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="99"/>
        <source>跟随启动守护</source>
        <translation type="unfinished">Follow the startup guardian</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="163"/>
        <source>取消修改</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel changes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="166"/>
        <source>应用发布</source>
        <comment>buttonName</comment>
        <translation type="unfinished">App publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="507"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="516"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="507"/>
        <source>发布失败</source>
        <translation type="unfinished">Publish failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="507"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="516"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="522"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="531"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="516"/>
        <source>发布成功，重启界面管理器生效</source>
        <translation type="unfinished">Successfully published, restart the interface manager to take effect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="522"/>
        <source>应用发布</source>
        <translation type="unfinished">Application Publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="522"/>
        <source>是否发布</source>
        <translation type="unfinished">Published</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="522"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="531"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="531"/>
        <source>取消修改</source>
        <translation type="unfinished">Cancel changes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="531"/>
        <source>是否取消修改</source>
        <translation type="unfinished">Whether to cancel the modification</translation>
    </message>
</context>
<context>
    <name>SettingModuleConfigWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="74"/>
        <source>一级标题栏，%1重复</source>
        <translation type="unfinished">Main title bar, %1 is duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="78"/>
        <source>二级导航栏，%1重复</source>
        <translation type="unfinished">Secondary navigation bar, %1 is duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="86"/>
        <source>三级工具栏，%1重复</source>
        <translation type="unfinished">Tertiary toolbar, %1 is duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="107"/>
        <source>重置文件</source>
        <translation type="unfinished">Reset file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="107"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="141"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="233"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="242"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="107"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="141"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="107"/>
        <source>是否重置文件</source>
        <translation type="unfinished">Whether to reset file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="74"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="78"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="82"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="86"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="90"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="82"/>
        <source>%1</source>
        <translation type="unfinished">%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="90"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="141"/>
        <source>应用发布</source>
        <translation type="unfinished">Application Publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="141"/>
        <source>是否发布</source>
        <translation type="unfinished">Published</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="165"/>
        <source>发布应用</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Publish app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="169"/>
        <source>取消修改</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel changes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="171"/>
        <source>取消工具配置</source>
        <translation type="unfinished">Cancel Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="173"/>
        <source>上传</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Upload</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="175"/>
        <source>将本地文件上传到文件服务</source>
        <translation type="unfinished">Upload local files to file service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="233"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="242"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="242"/>
        <source>发布成功，重启界面管理器生效</source>
        <translation type="unfinished">Successfully published, restart the interface manager to take effect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="167"/>
        <source>发布配置</source>
        <translation type="unfinished">Publish Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="233"/>
        <source>发布失败</source>
        <translation type="unfinished">Publish failed</translation>
    </message>
</context>
</TS>
