<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CalcEditorCalcMdl</name>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.ui" line="38"/>
        <source>验证</source>
        <translation type="unfinished">Verify</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="57"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="155"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="461"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="471"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="480"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="498"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="504"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="510"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="516"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="522"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="283"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="360"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="58"/>
        <source>打开%1计算库失败,请检查应用是否配置</source>
        <translation type="unfinished">Failed to open %1 compute db, please check whether the application is configured</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="149"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="237"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="287"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="487"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="295"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="149"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="487"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="295"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="155"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="224"/>
        <source>添加计算目标组</source>
        <translation type="unfinished">New calculation destination group</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="234"/>
        <source>删除计算目标组</source>
        <translation type="unfinished">Delete calculation destination group</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="237"/>
        <source>是否删除该计算目标组?</source>
        <translation type="unfinished">Whether to delete the calculation target group?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="275"/>
        <source>添加计算目标</source>
        <translation type="unfinished">Add calculation destination</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="284"/>
        <source>删除计算目标</source>
        <translation type="unfinished">Delete calculation destination</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="287"/>
        <source>是否删除该计算目标?</source>
        <translation type="unfinished">Whether to delete this calculation target?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="295"/>
        <source>修改计算目标</source>
        <translation type="unfinished">Modify calculation objectives</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="309"/>
        <source>全部</source>
        <translation type="unfinished">All</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_delegate.cpp" line="182"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="119"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_delegate.cpp" line="183"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="123"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="55"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="54"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="57"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="59"/>
        <source>应用</source>
        <translation type="unfinished">App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="61"/>
        <source>数据库</source>
        <translation type="unfinished">DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="63"/>
        <source>链接类型</source>
        <translation type="unfinished">Link type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="65"/>
        <source>表名</source>
        <translation type="unfinished">Table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="67"/>
        <source>值字段</source>
        <translation type="unfinished">Value field</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="69"/>
        <source>时间字段</source>
        <translation type="unfinished">Time field</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="71"/>
        <source>标志字段</source>
        <translation type="unfinished">Flag field</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="73"/>
        <source>计算方式</source>
        <translation type="unfinished">Calculation method</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="75"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="70"/>
        <source>计算周期</source>
        <translation type="unfinished">Calculation cycle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="127"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="165"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="125"/>
        <source>未知类型</source>
        <translation type="unfinished">Unknown type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="196"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="154"/>
        <source>未知周期</source>
        <translation type="unfinished">Unknown cycle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="415"/>
        <source>重复警告</source>
        <translation type="unfinished">Duplicated warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="415"/>
        <source>计算表格信息重复，请重新选择</source>
        <translation type="unfinished">Calculation table info is duplicated, please select again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="430"/>
        <source>修改警告</source>
        <translation type="unfinished">Modify Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="431"/>
        <source>修改计算结果配置信息会导致计算结果丢失，是否继续？</source>
        <translation type="unfinished">Modifying the config info of the calculation result will result in the loss of the calculation result. Whether to continue?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="461"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="283"/>
        <source>名称包含非法字符，请重新输入</source>
        <translation type="unfinished">The name contains invalid characters; please re-enter.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="471"/>
        <source>添加数据失败</source>
        <translation type="unfinished">Failed to add data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="480"/>
        <source>更新数据失败</source>
        <translation type="unfinished">Failed to update data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="498"/>
        <source>第%1行名称为空，请重新输入</source>
        <translation type="unfinished">The name in line %1 is empty, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="504"/>
        <source>第%1行应用为空，请重新输入</source>
        <translation type="unfinished">The application in line %1 is empty, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="510"/>
        <source>第%1行数据库为空，请重新输入</source>
        <translation type="unfinished">The db in line %1 is empty, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="516"/>
        <source>第%1行表名为空，请重新输入</source>
        <translation type="unfinished">The table name in row %1 is empty; please re-enter it.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="522"/>
        <source>第%1行值字段为空，请重新输入</source>
        <translation type="unfinished">The value field in line %1 is empty, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="58"/>
        <source>任务名称</source>
        <translation type="unfinished">Task name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="62"/>
        <source>目标路径</source>
        <translation type="unfinished">Dest path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="66"/>
        <source>计算类型</source>
        <translation type="unfinished">Calculation type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="360"/>
        <source>计算目标[%1]已存在</source>
        <translation type="unfinished">The calculation destination [%1] already exists</translation>
    </message>
</context>
</TS>
