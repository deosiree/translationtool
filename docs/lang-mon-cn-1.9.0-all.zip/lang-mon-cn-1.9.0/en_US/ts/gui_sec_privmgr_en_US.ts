<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CSecPri</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="297"/>
        <source>用户登录超时</source>
        <translation type="unfinished">User login timeout</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="300"/>
        <source>长时间未操作，请重新登录</source>
        <translation type="unfinished">Long time no operation, please login again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="302"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
</context>
<context>
    <name>QMyFrameEditStatus</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="111"/>
        <source>编辑</source>
        <translation type="unfinished">Edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="112"/>
        <source>浏览</source>
        <translation type="unfinished">Browse</translation>
    </message>
</context>
<context>
    <name>QMyFrameRadio</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="167"/>
        <source>待输入</source>
        <translation type="unfinished">Waiting for input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="169"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="170"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
</context>
<context>
    <name>QMyFrameSearch</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="143"/>
        <source>请输入关键字</source>
        <translation type="unfinished">Please enter keywords</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="145"/>
        <source>搜索</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="150"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="151"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="152"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/main.cpp" line="196"/>
        <source>网络注册失败</source>
        <translation type="unfinished">Net reg failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/main.cpp" line="197"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/main.cpp" line="247"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/main.cpp" line="208"/>
        <source>本地系统已启动</source>
        <translation type="unfinished">Local system started</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/main.cpp" line="246"/>
        <source>远程网络注册失败</source>
        <translation type="unfinished">Remote net reg failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/main.cpp" line="209"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/main.cpp" line="381"/>
        <source>登录时限：</source>
        <translation type="unfinished">Login time limit:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="228"/>
        <source>权限管理工具</source>
        <comment>toolName</comment>
        <translation type="unfinished">Permission Manager</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="228"/>
        <source>节点名</source>
        <comment>toolName</comment>
        <translation type="unfinished">Node Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="875"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1026"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1125"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1444"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1544"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1923"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2042"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="389"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="923"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1055"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1001"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1265"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3003"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="212"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="428"/>
        <source>%1输入异常字符，可能存在篡改、恶意攻击行为</source>
        <translation type="unfinished">%1 contains abnormal characters; possible tampering/malicious attack detected</translation>
    </message>
</context>
<context>
    <name>addMgr</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2922"/>
        <source>上级组织：</source>
        <translation type="unfinished">Parent organization:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2923"/>
        <source>组织名称：</source>
        <translation type="unfinished">Organization name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2953"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2962"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2978"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2985"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2992"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3020"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3032"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3041"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3052"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2953"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2962"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2978"/>
        <source>读取失败，请检查数据库服务</source>
        <translation type="unfinished">Failed to read, please check the db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3032"/>
        <source>组织名称已存在</source>
        <translation type="unfinished">Organization name already exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3020"/>
        <source>保存失败，请检查数据库服务</source>
        <translation type="unfinished">Failed to save, please check the db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2911"/>
        <source>新增组织</source>
        <comment>toolName</comment>
        <translation type="unfinished">Add Organization</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2947"/>
        <source>用户列表</source>
        <comment>menuName</comment>
        <translation type="unfinished">User list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2965"/>
        <source>编辑组织名称</source>
        <comment>toolName</comment>
        <translation type="unfinished">Edit Organization Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2985"/>
        <source>组织名称不可为空</source>
        <translation type="unfinished">Organization name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2992"/>
        <source>组织名称超长</source>
        <translation type="unfinished">Organization name too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2999"/>
        <source>异常输入</source>
        <translation type="unfinished">Abnormal input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2999"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished">Abnormal query data, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3004"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3009"/>
        <source>权限管理工具</source>
        <translation type="unfinished">Permission Manager</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3041"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3052"/>
        <source>更新失败，请检查数据库服务</source>
        <translation type="unfinished">Update failed, please check the db service</translation>
    </message>
</context>
<context>
    <name>chooseRoleDlg</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2597"/>
        <source>关联角色</source>
        <translation type="unfinished">Linked roles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2613"/>
        <source>角色选择</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Role Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2615"/>
        <source>功能信息</source>
        <translation type="unfinished">Functional info</translation>
    </message>
</context>
<context>
    <name>confTabWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="154"/>
        <source>用户</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">User</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="155"/>
        <source>角色</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Role</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="156"/>
        <source>功能</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Function</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="160"/>
        <source>节点</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="161"/>
        <source>责任区</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">AOR </translation>
    </message>
</context>
<context>
    <name>fingerInfoDlg</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.ui" line="36"/>
        <source>用户名：</source>
        <translation type="unfinished">Username:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.ui" line="65"/>
        <source>录入</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Entry</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.ui" line="72"/>
        <source>清除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.ui" line="79"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.ui" line="92"/>
        <source>指纹1： </source>
        <translation type="unfinished">Fingerprint 1:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.ui" line="115"/>
        <source>指纹2： </source>
        <translation type="unfinished">Fingerprint 2:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.ui" line="158"/>
        <source>提示：  </source>
        <translation type="unfinished">Tips:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.ui" line="138"/>
        <source>超时剩余时长：</source>
        <translation type="unfinished">Timeout remaining time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="21"/>
        <source>关闭</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="54"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="112"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="118"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="123"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="128"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="138"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="145"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="239"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="252"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="284"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="289"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="111"/>
        <source>指纹清除成功</source>
        <translation type="unfinished">Fingerprint cleared successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="118"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Please select the data to be operated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="123"/>
        <source>请选择一条数据</source>
        <translation type="unfinished">Please select a piece of data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="145"/>
        <source>指纹仪连接失败</source>
        <translation type="unfinished">Fail to connect fingerprint device</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="238"/>
        <source>指纹仪录入出错</source>
        <translation type="unfinished">Fingerprint device input error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="251"/>
        <source>指纹仪录入超时</source>
        <translation type="unfinished">Fingerprint device input timeout</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="128"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="138"/>
        <source>指纹仪未连接</source>
        <translation type="unfinished">Fingerprint not connected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="33"/>
        <source>指纹信息</source>
        <comment>toolName</comment>
        <translation type="unfinished">Fingerprint Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="149"/>
        <source>指纹仪连接成功</source>
        <translation type="unfinished">Fingerprint meter connected successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="152"/>
        <source>请录入三次指纹，请第[ 1 ]次录入指纹</source>
        <translation type="unfinished">Please enter the fingerprint for three times, please enter the fingerprint for the [first] time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="270"/>
        <source>请录入三次指纹，请第[ %1 ]次录入指纹</source>
        <translation type="unfinished">Please enter the fingerprint for three times, please enter the fingerprint for the [%1] time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="283"/>
        <source>指纹录入成功</source>
        <translation type="unfinished">Fingerprint input succeeded</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="288"/>
        <source>指纹录入失败，请检查数据库服务</source>
        <translation type="unfinished">Fingerprint entry failed, please check the db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="60"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="61"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="97"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="106"/>
        <source>未录入</source>
        <translation type="unfinished">Not entered</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="54"/>
        <source>初始化失败，请检查数据库</source>
        <translation type="unfinished">Initialization failed, please check the db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="73"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="79"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="222"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="227"/>
        <source>已录入</source>
        <translation type="unfinished">Already entered</translation>
    </message>
</context>
<context>
    <name>funcConfWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="47"/>
        <source>新增工具类型</source>
        <translation type="unfinished">Add Tool Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="49"/>
        <source>编辑工具类型</source>
        <translation type="unfinished">Type of editing tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="51"/>
        <source>删除工具类型</source>
        <translation type="unfinished">Delete tool type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="53"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="74"/>
        <source>新增工具</source>
        <translation type="unfinished">Add Tools</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="76"/>
        <source>新增功能项</source>
        <translation type="unfinished">Add Functions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="78"/>
        <source>新增子功能项</source>
        <translation type="unfinished">Add sub-functions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="80"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="82"/>
        <source>全局查找</source>
        <translation type="unfinished">Global search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="84"/>
        <source>列查找</source>
        <translation type="unfinished">Column search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="86"/>
        <source>调整工具类型</source>
        <translation type="unfinished">Adjust tool type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="100"/>
        <source>  配置信息</source>
        <translation type="unfinished"> Config Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="112"/>
        <source>功能项名称：</source>
        <translation type="unfinished">Function item name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="114"/>
        <source>功能项别名：</source>
        <translation type="unfinished">Functional item aliases:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="117"/>
        <source>二次验证：</source>
        <translation type="unfinished">Secondary validation:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="119"/>
        <source>多分配：</source>
        <translation type="unfinished">Multi-distribution:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="128"/>
        <source>责任区：</source>
        <translation type="unfinished">AOR:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="184"/>
        <source>工具名称：</source>
        <translation type="unfinished">Tool name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="186"/>
        <source>工具别名：</source>
        <translation type="unfinished">Tool alias:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="189"/>
        <source>多登录：</source>
        <translation type="unfinished">Multiple logins:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="193"/>
        <source>多启动：</source>
        <translation type="unfinished">Multi-start:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="195"/>
        <source>文件视图：</source>
        <translation type="unfinished">File View:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="137"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="199"/>
        <source>认证方式：</source>
        <translation type="unfinished">Auth method:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="202"/>
        <source>工具类型：</source>
        <translation type="unfinished">Tool type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="267"/>
        <source>工具列表</source>
        <translation type="unfinished">Tool List</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="302"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="303"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1227"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1228"/>
        <source>未分类工具</source>
        <translation type="unfinished">Uncategorised Tools</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="323"/>
        <source>待关联列表</source>
        <translation type="unfinished">To-be-linked List</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="342"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="348"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="523"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="527"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="588"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="592"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1956"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1959"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2083"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2088"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="344"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="350"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="521"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="525"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="529"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="590"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="594"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1954"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1957"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2085"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2090"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="473"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="485"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="847"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="857"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="863"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="890"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="900"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="949"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1008"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1014"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1041"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1049"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1083"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1089"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1095"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1107"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1113"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1140"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1148"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1169"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1175"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1193"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1296"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1427"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1432"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1462"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1467"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1490"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1493"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1500"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1512"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1521"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1526"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1531"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1563"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1568"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1598"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1626"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1631"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1647"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1676"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1682"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1806"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1827"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1949"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2070"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2098"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2110"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2124"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2131"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2140"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2148"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2160"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2177"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2186"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2195"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2202"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="473"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="485"/>
        <source>获取App信息失败，请检查数据库</source>
        <translation type="unfinished">Failed to retrieve app info, please check the db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="847"/>
        <source>请在工具表中右键添加工具项</source>
        <translation type="unfinished">Please right-click to add a tool item in the tool table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1107"/>
        <source>子功能项名称不可为空</source>
        <translation type="unfinished">Sub function item name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1467"/>
        <source>新增失败，请检查数据库连接</source>
        <translation type="unfinished">Failed to add, please check the db connection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2140"/>
        <source>工具别名不可为空</source>
        <translation type="unfinished">Tool alias cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2160"/>
        <source>功能项名称不可为空</source>
        <translation type="unfinished">Function item name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2195"/>
        <source>功能项别名不可为空</source>
        <translation type="unfinished">Function item alias cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="863"/>
        <source>工具已存在</source>
        <translation type="unfinished">Tool already exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1490"/>
        <source>请在工具类型上右键删除</source>
        <translation type="unfinished">Please right-click on tool type to delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1626"/>
        <source>未选择工具</source>
        <translation type="unfinished">No tool selected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1647"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1676"/>
        <source>未选择功能项</source>
        <translation type="unfinished">No function item selected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1827"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2124"/>
        <source>工具名称已存在</source>
        <translation type="unfinished">Tool name already exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2148"/>
        <source>工具别名超长</source>
        <translation type="unfinished">Tool alias is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2202"/>
        <source>功能项别名超长</source>
        <translation type="unfinished">Function item alias is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="950"/>
        <source>在导航树中选中工具，在表格中右键添加功能项</source>
        <translation type="unfinished">Select a tool in the navigation tree and right-click to add a function item in the table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="141"/>
        <source>系统默认</source>
        <translation type="unfinished">System default</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="145"/>
        <source>密码</source>
        <translation type="unfinished">Password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="147"/>
        <source>密码+UKey</source>
        <translation type="unfinished">Password+UKey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="149"/>
        <source>密码+指纹</source>
        <translation type="unfinished">Password + Fingerprint</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="223"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="381"/>
        <source>功能名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Function name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="381"/>
        <source>功能别名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Functional alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="381"/>
        <source>二次验证</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Secondary verification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="381"/>
        <source>多分配</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Multiple allocation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="381"/>
        <source>引用责任区</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Reference aor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="452"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="544"/>
        <source>工具名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tool name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="452"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="544"/>
        <source>工具别名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tool aliases</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="452"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="544"/>
        <source>多启动</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Multiboot</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="452"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="544"/>
        <source>多登录</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Multiple logins</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="452"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="544"/>
        <source>文件视图</source>
        <comment>subTitle</comment>
        <translation type="unfinished">File view</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="452"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="544"/>
        <source>工具类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tool type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="851"/>
        <source>添加工具</source>
        <comment>toolName</comment>
        <translation type="unfinished">Add Tools</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="871"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1022"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1121"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1440"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1540"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1919"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2038"/>
        <source>异常输入</source>
        <translation type="unfinished">Abnormal input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="871"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1022"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1121"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1919"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2038"/>
        <source>输入数据异常，请重新输入</source>
        <translation type="unfinished">Abnormal input data, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="876"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="881"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1027"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1032"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1126"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1131"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1445"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1450"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1545"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1550"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1924"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1929"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2043"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2048"/>
        <source>权限管理工具</source>
        <translation type="unfinished">Permission Manager</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1008"/>
        <source>功能项不可为空</source>
        <translation type="unfinished">Function item cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1014"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1806"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2177"/>
        <source>功能项名称已存在</source>
        <translation type="unfinished">Function item name already exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1113"/>
        <source>子功能项名称已存在</source>
        <translation type="unfinished">Sub function item name already exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1198"/>
        <source>工具类型调整</source>
        <comment>toolName</comment>
        <translation type="unfinished">Tool Type Adjust</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1209"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1210"/>
        <source>工具列表</source>
        <comment>menuName</comment>
        <translation type="unfinished">Tool list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1421"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1515"/>
        <source>请输入工具类型名称</source>
        <translation type="unfinished">Please enter the tool type name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1421"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1515"/>
        <source>工具类型名称</source>
        <comment>toolName</comment>
        <translation type="unfinished">Tool Type Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1427"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1521"/>
        <source>工具类型名称超长</source>
        <translation type="unfinished">Tool type name is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1432"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1526"/>
        <source>工具类型名称不可为空</source>
        <translation type="unfinished">Tool type name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1440"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1540"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished">Abnormal query data, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1462"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1563"/>
        <source>工具类型已存在</source>
        <translation type="unfinished">Tool type already exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1493"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1598"/>
        <source>是否删除</source>
        <translation type="unfinished">Whether to delete it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1500"/>
        <source>删除失败，请检查数据库服务</source>
        <translation type="unfinished">Deletion failed, please check the db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1512"/>
        <source>请在工具类型上右键编辑名称</source>
        <translation type="unfinished">Please right-click the tool type to edit the name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1531"/>
        <source>工具类型名称未发生变化</source>
        <translation type="unfinished">Tool type name has not changed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1568"/>
        <source>保存失败，请检查数据库服务</source>
        <translation type="unfinished">Failed to save, please check the db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1631"/>
        <source>更新失败，请检查数据库</source>
        <translation type="unfinished">Update failed, please check the db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1637"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2009"/>
        <source>工具</source>
        <translation type="unfinished">tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1682"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1949"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2070"/>
        <source>更新失败，请检查数据库服务</source>
        <translation type="unfinished">Update failed, please check the db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1688"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2091"/>
        <source>功能项</source>
        <translation type="unfinished">function item</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2098"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="532"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="598"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1979"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2236"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2237"/>
        <source>未分类</source>
        <translation type="unfinished">Uncategorised</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="129"/>
        <source>关联</source>
        <translation type="unfinished">Link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="851"/>
        <source>请输入工具名称</source>
        <translation type="unfinished">Please enter the name of the tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="857"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2110"/>
        <source>工具名称不可为空</source>
        <translation type="unfinished">Tool name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="890"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2131"/>
        <source>工具名称超长</source>
        <translation type="unfinished">Tool name is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="900"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1049"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1148"/>
        <source>新增失败，请检查数据库服务</source>
        <translation type="unfinished">Failed to add. Please check the db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1002"/>
        <source>添加功能项</source>
        <translation type="unfinished">Add functional items</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1002"/>
        <source>请输入功能项名称</source>
        <translation type="unfinished">Please enter a function name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1041"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1140"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2186"/>
        <source>功能项名称超长</source>
        <translation type="unfinished">Function item name is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1083"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1089"/>
        <source>请选中功能项后添加子功能项</source>
        <translation type="unfinished">Please select the function item and add sub function items</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1095"/>
        <source>存在待关联项的功能项不可添加子功能项</source>
        <translation type="unfinished">Sub function items cannot be added for function items with items to be linked</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1101"/>
        <source>添加子功能项</source>
        <translation type="unfinished">Add sub-functions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1101"/>
        <source>请输入子功能项名称</source>
        <translation type="unfinished">Please enter the name of the sub-function item</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1169"/>
        <source>未添加工具类型</source>
        <translation type="unfinished">Tool type not added</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1175"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1193"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1296"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Please select the data to be operated</translation>
    </message>
</context>
<context>
    <name>genUkey</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="124"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="153"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="160"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="168"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="175"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="182"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="213"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="249"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="124"/>
        <source>证书生成失败</source>
        <translation type="unfinished">Certificate generation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="153"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="160"/>
        <source>证书信息损坏</source>
        <translation type="unfinished">Certificate info corrupted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="168"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="175"/>
        <source>UKey加载出错</source>
        <translation type="unfinished">Failed to load the UKey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="182"/>
        <source>UKey第一次绑定出错</source>
        <translation type="unfinished">Ukey binding error for the first time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="204"/>
        <source>UKey制作失败</source>
        <translation type="unfinished">Ukey creation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="210"/>
        <source>UKey制作成功。</source>
        <translation type="unfinished">UKey was created successfully.</translation>
    </message>
</context>
<context>
    <name>nodeChooseDialog</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="290"/>
        <source>关联节点</source>
        <comment>toolName</comment>
        <translation type="unfinished">Link Node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="308"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="309"/>
        <source>节点名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="310"/>
        <source>节点别名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="311"/>
        <source>系统信息库节点ID</source>
        <comment>subTitle</comment>
        <translation type="unfinished">System info node id</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="312"/>
        <source>节点类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="355"/>
        <source>系统节点</source>
        <translation type="unfinished">System Node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="359"/>
        <source>系统外节点</source>
        <translation type="unfinished">Node outside the system</translation>
    </message>
</context>
<context>
    <name>nodeConfWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="68"/>
        <source>同步节点</source>
        <translation type="unfinished">Sync nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="70"/>
        <source>全局查找</source>
        <translation type="unfinished">Global search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="72"/>
        <source>列查找</source>
        <translation type="unfinished">Column search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="89"/>
        <source>节点名称：</source>
        <translation type="unfinished">Node name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="92"/>
        <source>节点别名：</source>
        <translation type="unfinished">Node aliases:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="95"/>
        <source>责任区：</source>
        <translation type="unfinished">AOR:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="100"/>
        <source>角色：</source>
        <translation type="unfinished">Characters:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="49"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="49"/>
        <source>节点名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="49"/>
        <source>节点别名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="49"/>
        <source>引用责任区</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Reference aor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="49"/>
        <source>关联角色</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Link roles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="82"/>
        <source>  配置信息</source>
        <comment>subTitle</comment>
        <translation type="unfinished"> Config Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="96"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="101"/>
        <source>关联</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="103"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="385"/>
        <source>异常输入</source>
        <translation type="unfinished">Abnormal input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="385"/>
        <source>输入数据异常，请重新输入</source>
        <translation type="unfinished">Abnormal input data, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="390"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="395"/>
        <source>权限管理工具</source>
        <translation type="unfinished">Permission Manager</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="405"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="421"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="716"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="798"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="405"/>
        <source>更新失败，请检查数据库</source>
        <translation type="unfinished">Update failed, please check the db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="421"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="717"/>
        <source>是否同步系统信息库节点</source>
        <translation type="unfinished">Synchronize system info base node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="798"/>
        <source>节点别名超长</source>
        <translation type="unfinished">Node alias is too long</translation>
    </message>
</context>
<context>
    <name>roleChooseDialog</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="161"/>
        <source>关联角色</source>
        <comment>toolName</comment>
        <translation type="unfinished">Link Roles</translation>
    </message>
</context>
<context>
    <name>roleConfWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="181"/>
        <source>批量新增</source>
        <translation type="unfinished">Batch Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="186"/>
        <source>新增操作员角色</source>
        <translation type="unfinished">Add operator role</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="190"/>
        <source>新增角色</source>
        <translation type="unfinished">Add Role</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="194"/>
        <source>从现有角色复制</source>
        <translation type="unfinished">Copy from existing roles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="197"/>
        <source>删除角色</source>
        <translation type="unfinished">Delete Role</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="199"/>
        <source>全局查找</source>
        <translation type="unfinished">Global search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="201"/>
        <source>列查找</source>
        <translation type="unfinished">Column search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="203"/>
        <source>刷新工具类型</source>
        <translation type="unfinished">Refresh tool type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="223"/>
        <source>数据级别</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Data level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="255"/>
        <source>画面功能配置：</source>
        <translation type="unfinished">Graph Function Config:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="264"/>
        <source>角色名称：</source>
        <translation type="unfinished">Role name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="272"/>
        <source>启动画面：</source>
        <translation type="unfinished">Startup graph:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="281"/>
        <source>文件视图：</source>
        <translation type="unfinished">File View:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="290"/>
        <source>数据库视图：</source>
        <translation type="unfinished">DB view:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="299"/>
        <source>多分配：</source>
        <translation type="unfinished">Multi-distribution:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="300"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="485"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="301"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="487"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="316"/>
        <source>责任区选择：</source>
        <translation type="unfinished">Select AOR:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="326"/>
        <source>节点选择：</source>
        <translation type="unfinished">Node Selection:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="353"/>
        <source>基本信息</source>
        <translation type="unfinished">Basic Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="391"/>
        <source>角色列表</source>
        <translation type="unfinished">Role List</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="561"/>
        <source>未定义类型</source>
        <translation type="unfinished">Undefined</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="570"/>
        <source>通用级别</source>
        <translation type="unfinished">General level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="919"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="937"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="993"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1005"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1011"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1030"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1042"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1075"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1141"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1161"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1261"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1272"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1284"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1336"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1363"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1371"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1376"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1419"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1428"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1434"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1467"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1476"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1482"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1490"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1498"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1506"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1514"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1533"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="919"/>
        <source>输入包含非法字符，请检查</source>
        <translation type="unfinished">The input contains illegal characters; please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="924"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="929"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1056"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1061"/>
        <source>权限管理工具</source>
        <translation type="unfinished">Permission Manager</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="937"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1075"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1161"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1376"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1434"/>
        <source>更新失败，请检查数据库</source>
        <translation type="unfinished">Update failed, please check the db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="993"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1005"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1030"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1419"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1467"/>
        <source>角色名称不可为空</source>
        <translation type="unfinished">Role name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1051"/>
        <source>异常输入</source>
        <translation type="unfinished">Abnormal input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1051"/>
        <source>输入数据异常，请重新输入</source>
        <translation type="unfinished">Abnormal input data, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1141"/>
        <source>获取失败，请检查数据库</source>
        <translation type="unfinished">Failed to retrieved, please check the db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1261"/>
        <source>只能选择一个角色进行复制</source>
        <translation type="unfinished">Only one role can be selected  to be copied</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1273"/>
        <source>以下角色禁止复制：</source>
        <translation type="unfinished">The following roles are prohibited from copying:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1284"/>
        <source>请选择需要复制的角色</source>
        <translation type="unfinished">Please select the role to be copied</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1304"/>
        <source>批量新增</source>
        <comment>toolName</comment>
        <translation type="unfinished">Batch Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1364"/>
        <source>以下角色禁止删除：</source>
        <translation type="unfinished">Roles that cannot be deleted:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1371"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Please select the data to be operated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1490"/>
        <source>启动画面内容超长</source>
        <translation type="unfinished">Content of the startup graph is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1498"/>
        <source>画面功能内容超长</source>
        <translation type="unfinished">Function content of graph is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1506"/>
        <source>文件视图内容超长</source>
        <translation type="unfinished">File view content is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1514"/>
        <source>数据库视图内容超长</source>
        <translation type="unfinished">DB view content is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1533"/>
        <source>角色功能互斥检测失败</source>
        <translation type="unfinished">Role function mutual exclusion detection failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1042"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1428"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1476"/>
        <source>角色已存在</source>
        <translation type="unfinished">Role already exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1336"/>
        <source>是否删除</source>
        <translation type="unfinished">Whether to delete it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="999"/>
        <source>添加角色</source>
        <translation type="unfinished">Add Role</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="144"/>
        <source>操作员</source>
        <translation type="unfinished">Operator</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="145"/>
        <source>管理员</source>
        <translation type="unfinished">Admin</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="146"/>
        <source>审计员</source>
        <translation type="unfinished">Auditor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="147"/>
        <source>未登录角色</source>
        <translation type="unfinished">Unlogged Role</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="222"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="222"/>
        <source>角色名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Role name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="222"/>
        <source>多分配</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Multiple allocation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="222"/>
        <source>启动画面</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Startup graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="222"/>
        <source>画面功能配置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Graph function config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="222"/>
        <source>文件视图</source>
        <comment>subTitle</comment>
        <translation type="unfinished">File view</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="223"/>
        <source>数据库权限</source>
        <comment>subTitle</comment>
        <translation type="unfinished">DB permissions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="223"/>
        <source>责任区</source>
        <comment>subTitle</comment>
        <translation type="unfinished">AOR </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="223"/>
        <source>节点</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="223"/>
        <source>角色类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Role Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="243"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="701"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="710"/>
        <source>节点白名单：</source>
        <translation type="unfinished">Node whitelist:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="714"/>
        <source>节点黑名单：</source>
        <translation type="unfinished">Node blacklist:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="999"/>
        <source>请输入角色名称</source>
        <translation type="unfinished">Please enter a role name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1011"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1482"/>
        <source>角色名称超长</source>
        <translation type="unfinished">Role name is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1304"/>
        <source>输入数量：</source>
        <translation type="unfinished">Input quantity:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1574"/>
        <source>未分类</source>
        <translation type="unfinished">Uncategorised</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1582"/>
        <source>功能选择</source>
        <translation type="unfinished">Function Selection</translation>
    </message>
</context>
<context>
    <name>roleFuncChoose</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1748"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1761"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1748"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1761"/>
        <source>角色功能信息获取失败，请检查数据库服务</source>
        <translation type="unfinished">Failed to get the role function information, please check the database service</translation>
    </message>
</context>
<context>
    <name>sysConfWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="47"/>
        <source>当前配置</source>
        <translation type="unfinished">Current config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="48"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="49"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="50"/>
        <source>保存到模板</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save to template</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="51"/>
        <source>设置为系统配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Set as system config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="68"/>
        <source>密码有效天数：</source>
        <translation type="unfinished">Password expiration:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="79"/>
        <source>密码最大错误次数：</source>
        <translation type="unfinished">Maximum password attempts:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="90"/>
        <source>登录失败用户锁定时长：</source>
        <translation type="unfinished">Login failure lockout duration:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="101"/>
        <source>机器闲置工具锁定时长：</source>
        <translation type="unfinished">Machine idle tool lockout duration:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="112"/>
        <source>默认用户登录有效期：</source>
        <translation type="unfinished">Default user login validity period:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="123"/>
        <source>历史密码个数：</source>
        <translation type="unfinished">History passwords count:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="134"/>
        <source>密码最小长度：</source>
        <translation type="unfinished">Minimum password length:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="145"/>
        <source>密码最大长度：</source>
        <translation type="unfinished">Maximum password length:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="157"/>
        <source>密码复杂度：</source>
        <translation type="unfinished">Password complexity:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="158"/>
        <source>数字</source>
        <translation type="unfinished">Number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="159"/>
        <source>小写字母</source>
        <translation type="unfinished">Lowercase letters</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="160"/>
        <source>大写字母</source>
        <translation type="unfinished">Capital letters</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="161"/>
        <source>特殊字符</source>
        <translation type="unfinished">Special Characters</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="162"/>
        <source>禁止包含用户名</source>
        <translation type="unfinished">Usernames are not allowed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="174"/>
        <source>强制修改初始密码：</source>
        <translation type="unfinished">Force change the initial password:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="176"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="190"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="204"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="177"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="191"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="205"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="188"/>
        <source>强制修改过期密码：</source>
        <translation type="unfinished">Force change of expired password:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="202"/>
        <source>登录框隐藏用户名：</source>
        <translation type="unfinished">Hide username in login box:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="245"/>
        <source>系统配置</source>
        <translation type="unfinished">System Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="246"/>
        <source>配置模板</source>
        <translation type="unfinished">Config templates</translation>
    </message>
</context>
<context>
    <name>ukeyInfoDlg</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="20"/>
        <source>证书</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Certificate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="35"/>
        <source>状态：</source>
        <translation type="unfinished">Status:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="57"/>
        <source>加密方式：</source>
        <translation type="unfinished">Encryption method:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="79"/>
        <source>有效期：  </source>
        <translation type="unfinished">Validity period:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="121"/>
        <source>生成</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Gen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="128"/>
        <source>校验</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Verify</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="135"/>
        <source>查看</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="142"/>
        <source>清除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="155"/>
        <source>Ukey</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Ukey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="173"/>
        <source>Ukeys设备：      </source>
        <translation type="unfinished">Ukeys device:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="189"/>
        <source>加载</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Load</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="272"/>
        <source>重置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Reset</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="279"/>
        <source>制作</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Make</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="286"/>
        <source>关闭</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="208"/>
        <source>所属用户：    </source>
        <translation type="unfinished">Assigned user:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="230"/>
        <source>设备状态：    </source>
        <translation type="unfinished">Device status:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="286"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="292"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="298"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="311"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="348"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="354"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="360"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="377"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="391"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="398"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="405"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="412"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="422"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="429"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="437"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="449"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="495"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="502"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="505"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="510"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="516"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="524"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="543"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="568"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="593"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="597"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="621"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="634"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="650"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="657"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="774"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="286"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="292"/>
        <source>获取用户信息失败</source>
        <translation type="unfinished">Failed to retrieve user info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="298"/>
        <source>获取用户信息失败，请检查数据库服务</source>
        <translation type="unfinished">Failed to retrieve user info, please check the db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="311"/>
        <source>获取证书信息失败</source>
        <translation type="unfinished">Failed to get certificate info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="348"/>
        <source>UKey已使用，请重置</source>
        <translation type="unfinished">Ukey has been used, please reset</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="354"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="391"/>
        <source>请加载设备</source>
        <translation type="unfinished">Please load the device</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="370"/>
        <source>UKey制作失败</source>
        <translation type="unfinished">Ukey creation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="375"/>
        <source>UKey制作成功</source>
        <translation type="unfinished">Ukey created successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="422"/>
        <source>用户证书已存在</source>
        <translation type="unfinished">User certificate already exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="429"/>
        <source>用户信息证书读取失败，请检查数据库服务</source>
        <translation type="unfinished">Failed to read user info certificate, please check db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="437"/>
        <source>保存失败，请检查数据库服务</source>
        <translation type="unfinished">Failed to save, please check the db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="449"/>
        <source>创建证书失败</source>
        <translation type="unfinished">Failed to create certificate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="495"/>
        <source>生成证书成功</source>
        <translation type="unfinished">Certificate gened successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="502"/>
        <source>用户证书不存在</source>
        <translation type="unfinished">User certificate does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="510"/>
        <source>删除证书成功</source>
        <translation type="unfinished">Certificate deleted successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="516"/>
        <source>删除证书失败</source>
        <translation type="unfinished">Failed to delete certificate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="524"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="568"/>
        <source>请生成用户证书</source>
        <translation type="unfinished">Please gen user certificate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="543"/>
        <source>证书加载失败</source>
        <translation type="unfinished">Certificate loading failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="597"/>
        <source>校验成功</source>
        <translation type="unfinished">Verification succeeded</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="774"/>
        <source>读取证书失败，请检查数据库服务</source>
        <translation type="unfinished">Failed to read the certificate, please check the db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="303"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="323"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="512"/>
        <source>未生成证书</source>
        <translation type="unfinished">No certificate gened</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="257"/>
        <source>UKey配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">UKey Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="319"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="496"/>
        <source>已生成证书</source>
        <translation type="unfinished">Gened certificate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="360"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="398"/>
        <source>UKey绑定出错</source>
        <translation type="unfinished">Ukey binding error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="392"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="400"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="407"/>
        <source>UKey重置失败</source>
        <translation type="unfinished">UKey reset failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="405"/>
        <source>UKey重置出错</source>
        <translation type="unfinished">Ukey reset error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="412"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="415"/>
        <source>UKey重置成功</source>
        <translation type="unfinished">The UKey is successfully reset.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="505"/>
        <source>是否删除</source>
        <translation type="unfinished">Whether to delete it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="549"/>
        <source>证书信息</source>
        <translation type="unfinished">Certificate Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="558"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="593"/>
        <source>证书校验失败</source>
        <translation type="unfinished">Certificate verification failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="621"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="623"/>
        <source>UKey加载出错</source>
        <translation type="unfinished">Failed to load the UKey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="627"/>
        <source>UKey加载成功</source>
        <translation type="unfinished">UKey loaded successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="634"/>
        <source>用户证书信息未生成</source>
        <translation type="unfinished">User certificate info not gened</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="650"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="657"/>
        <source>用户证书信息损坏</source>
        <translation type="unfinished">User certificate info is corrupted</translation>
    </message>
</context>
<context>
    <name>userConfWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="105"/>
        <source>增加平级组织</source>
        <translation type="unfinished">Add horizontal organizations</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="107"/>
        <source>增加下级组织</source>
        <translation type="unfinished">Add subordinate organizations</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="109"/>
        <source>编辑组织</source>
        <translation type="unfinished">Edit Organization</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="111"/>
        <source>删除组织</source>
        <translation type="unfinished">Delete organisation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="113"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="130"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1327"/>
        <source>批量新增</source>
        <translation type="unfinished">Batch add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="132"/>
        <source>新增用户</source>
        <translation type="unfinished">Add user</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="134"/>
        <source>删除用户</source>
        <translation type="unfinished">Delete user</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="136"/>
        <source>全局查找</source>
        <translation type="unfinished">Global search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="138"/>
        <source>列查找</source>
        <translation type="unfinished">Column search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="140"/>
        <source>组织调整</source>
        <translation type="unfinished">Adjust organisation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="180"/>
        <source>  配置信息</source>
        <translation type="unfinished"> Config Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="195"/>
        <source>用户名称：</source>
        <translation type="unfinished">Username:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="197"/>
        <source>密码：</source>
        <translation type="unfinished">Password:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="202"/>
        <source>电话：</source>
        <translation type="unfinished">Phone:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="208"/>
        <source>邮箱：</source>
        <translation type="unfinished">Email:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="213"/>
        <source>启动画面：</source>
        <translation type="unfinished">Startup graph:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="216"/>
        <source>证书及UKey：</source>
        <translation type="unfinished">Certificate and UKey:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="220"/>
        <source>指纹：</source>
        <translation type="unfinished">Fingerprint:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="225"/>
        <source>锁定状态：</source>
        <translation type="unfinished">Locked status:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="230"/>
        <source>角色：</source>
        <translation type="unfinished">Characters:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="337"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="338"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2085"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2086"/>
        <source>未分组</source>
        <translation type="unfinished">Ungrouped</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="417"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="675"/>
        <source>已激活</source>
        <translation type="unfinished">Activated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="421"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="673"/>
        <source>未激活</source>
        <translation type="unfinished">Inactive</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="445"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="715"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="808"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1082"/>
        <source>已生成</source>
        <translation type="unfinished">Gened</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="449"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="719"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="809"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1083"/>
        <source>未生成</source>
        <translation type="unfinished">Not gened</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="472"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="742"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="812"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1232"/>
        <source>已录入</source>
        <translation type="unfinished">Already entered</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="476"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="746"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="813"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1233"/>
        <source>未录入</source>
        <translation type="unfinished">Not entered</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="486"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="755"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="818"/>
        <source>已锁定</source>
        <translation type="unfinished">Locked</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="490"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="759"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="822"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1747"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1748"/>
        <source>未锁定</source>
        <translation type="unfinished">Unlocked</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="906"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="914"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="969"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1040"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1247"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1253"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1280"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1295"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1349"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1408"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1429"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1499"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1504"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1514"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1552"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1557"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1566"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1587"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1649"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1657"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1663"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1672"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1751"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1851"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1859"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1896"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1907"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1924"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1941"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1950"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1967"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1975"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1987"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1996"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2046"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2154"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2216"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2227"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2244"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2253"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2357"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2366"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2375"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2382"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2393"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2401"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2410"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="906"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1247"/>
        <source>用户名不可为空</source>
        <translation type="unfinished">User name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="969"/>
        <source>更新失败，请检查数据库服务</source>
        <translation type="unfinished">Update failed, please check the db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1429"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1587"/>
        <source>是否删除</source>
        <translation type="unfinished">Whether to delete it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1552"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1657"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2046"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2154"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2216"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2357"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Please select the data to be operated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2382"/>
        <source>用户名称超长</source>
        <translation type="unfinished">User name is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2410"/>
        <source>启动画面设置超长</source>
        <translation type="unfinished">Content of the startup graph is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1040"/>
        <source>数据保存成功</source>
        <translation type="unfinished">Data saved successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="142"/>
        <source>修改密码</source>
        <translation type="unfinished">Change password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="159"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="159"/>
        <source>用户名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Username</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="159"/>
        <source>电话</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Telephone</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="159"/>
        <source>邮箱</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Email</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="159"/>
        <source>激活状态</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Activation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="159"/>
        <source>启动画面</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Startup graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="159"/>
        <source>角色</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Role</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="160"/>
        <source>证书</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Certificate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="160"/>
        <source>UKey</source>
        <comment>subTitle</comment>
        <translation type="unfinished">UKey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="160"/>
        <source>指纹</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Fingerprint</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="160"/>
        <source>锁定状态</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Locked</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="160"/>
        <source>修改密码时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Password change time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="160"/>
        <source>密码有效期</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Password expiration</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="198"/>
        <source>重置密码</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Reset password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="217"/>
        <source>管理</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Manage</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="221"/>
        <source>录入</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Entry</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="226"/>
        <source>解锁</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Unlock</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="231"/>
        <source>关联</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="235"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="308"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="309"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2062"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2063"/>
        <source>用户列表</source>
        <comment>menuName</comment>
        <translation type="unfinished">User list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="914"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1253"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2375"/>
        <source>用户名已存在</source>
        <translation type="unfinished">Username already exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="997"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1261"/>
        <source>异常输入</source>
        <translation type="unfinished">Abnormal input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="997"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1261"/>
        <source>输入数据异常，请重新输入</source>
        <translation type="unfinished">Abnormal input data, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1002"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1007"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1266"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1271"/>
        <source>权限管理工具</source>
        <translation type="unfinished">Permission Manager</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1241"/>
        <source>添加用户</source>
        <comment>toolName</comment>
        <translation type="unfinished">Add User</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1295"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1349"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1557"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1566"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1663"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1672"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1851"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1996"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2244"/>
        <source>更新错误，请检查数据库服务</source>
        <translation type="unfinished">Update error, please check the db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1409"/>
        <source>更新用户:{}操作员角色错误，请检查数据库服务</source>
        <translation type="unfinished">Update user: {} Operator role error, please check db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1499"/>
        <source>删除失败，每个角色（审计员、管理员）都需至少有一名用户</source>
        <translation type="unfinished">Deletion failed, each role (auditor, administrator) must have at least one user</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1514"/>
        <source>禁止删除登录用户</source>
        <translation type="unfinished">Deleting logged-in users is not allowed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1650"/>
        <source>以下用户禁止删除：</source>
        <translation type="unfinished">The following users are prohibited from deletion:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1744"/>
        <source>用户解锁失败，请检查数据库服务</source>
        <translation type="unfinished">User unlocking failed, please check the db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1749"/>
        <source>用户解锁成功</source>
        <translation type="unfinished">User unlocked successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1859"/>
        <source>重置密码成功</source>
        <translation type="unfinished">Password reset succeeded</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1897"/>
        <source>增加平级组织时不能选择用户列表或未分组</source>
        <translation type="unfinished">User list or ungrouped cannot be selected when adding a peer organization</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1907"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1950"/>
        <source>未获取到该组织的上级组织</source>
        <translation type="unfinished">The parent organization of the organization was not retrieved</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1924"/>
        <source>增加下级组织时不能选择未分组</source>
        <translation type="unfinished">Ungrouped cannot be selected when adding subordinate organizations</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1942"/>
        <source>修改组织名称时不能选择用户列表或未分组</source>
        <translation type="unfinished">User list or ungrouped cannot be selected when modifying the organization name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1957"/>
        <source>编辑组织名称</source>
        <comment>toolName</comment>
        <translation type="unfinished">Edit Organization Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1968"/>
        <source>删除平级组织时不能选择用户列表或未分组</source>
        <translation type="unfinished">You cannot select a user list or ungroup when deleting a peer organization</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1974"/>
        <source>请确认是否删除组织[%1]</source>
        <translation type="unfinished">Please confirm whether to delete organization [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1988"/>
        <source>该组织存在下级组织，点击确定将级联删除所有组织</source>
        <translation type="unfinished">Organization has subordinate organizations. Click Confirm to cascade delete all.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2051"/>
        <source>组织关系调整</source>
        <comment>toolName</comment>
        <translation type="unfinished">Organization Adjustment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2188"/>
        <source>修改密码</source>
        <comment>toolName</comment>
        <translation type="unfinished">Change Password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2188"/>
        <source>请输入密码</source>
        <translation type="unfinished">Please enter your password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1504"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2227"/>
        <source>读取失败，请检查数据库服务</source>
        <translation type="unfinished">Read failed, please check the db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2253"/>
        <source>修改密码成功</source>
        <translation type="unfinished">Password changed successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2366"/>
        <source>请检查用户名是否设置正确</source>
        <translation type="unfinished">Please check whether the username is set correctly.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2393"/>
        <source>请检查电话是否设置正确</source>
        <translation type="unfinished">Please check if the phone is set up correctly</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2401"/>
        <source>请检查邮箱是否设置正确</source>
        <translation type="unfinished">Please check whether the mailbox is set correctly</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1241"/>
        <source>请输入用户名</source>
        <translation type="unfinished">Please enter username</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1280"/>
        <source>用户名超长</source>
        <translation type="unfinished">User name is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1327"/>
        <source>输入数量:</source>
        <translation type="unfinished">Enter quantity:</translation>
    </message>
</context>
<context>
    <name>workChooseDialog</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="16"/>
        <source>关联责任区</source>
        <comment>toolName</comment>
        <translation type="unfinished">Link AOR </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="58"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="59"/>
        <source>名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="60"/>
        <source>应用组号</source>
        <comment>subTitle</comment>
        <translation type="unfinished"> App group No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="61"/>
        <source>库内组号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Group number in the db</translation>
    </message>
</context>
<context>
    <name>workConfWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="67"/>
        <source>批量新增</source>
        <translation type="unfinished">Batch Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="69"/>
        <source>新增责任区</source>
        <translation type="unfinished">Add AOR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="71"/>
        <source>全局查找</source>
        <translation type="unfinished">Global search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="73"/>
        <source>列查找</source>
        <translation type="unfinished">Column search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="75"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="86"/>
        <source>  配置信息</source>
        <translation type="unfinished"> Config Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="94"/>
        <source>责任区：</source>
        <translation type="unfinished">AOR:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="96"/>
        <source>应用组号：</source>
        <translation type="unfinished"> App group No.:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="98"/>
        <source>库内组号：</source>
        <translation type="unfinished">DB group number:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="100"/>
        <source>备注：</source>
        <translation type="unfinished">Remarks:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="159"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="182"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="208"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="225"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="238"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="405"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="411"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="418"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="442"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="454"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="473"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="478"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="509"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="526"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="535"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="542"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="550"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="558"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="566"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="159"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="535"/>
        <source>责任区名称已存在</source>
        <translation type="unfinished">AOR name already exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="208"/>
        <source>输入包含非法字符，请检查</source>
        <translation type="unfinished">The input contains illegal characters; please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="213"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="218"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="429"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="434"/>
        <source>权限管理工具</source>
        <translation type="unfinished">Permission Manager</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="418"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="542"/>
        <source>责任区名称超长</source>
        <translation type="unfinished">Name of AOR is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="182"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="405"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="526"/>
        <source>责任区名称不可为空</source>
        <translation type="unfinished">The name of AOR cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="46"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="46"/>
        <source>责任区</source>
        <comment>subTitle</comment>
        <translation type="unfinished">AOR </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="46"/>
        <source>应用组号</source>
        <comment>subTitle</comment>
        <translation type="unfinished"> App group No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="46"/>
        <source>库内组号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Group number in the db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="46"/>
        <source>备注</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Remark</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="101"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="399"/>
        <source>添加责任区</source>
        <comment>toolName</comment>
        <translation type="unfinished">Add AOR </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="424"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="424"/>
        <source>责任区名称包含非法字符</source>
        <translation type="unfinished">The AOR name contains invalid characters.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="442"/>
        <source>新增失败，请检查数据库链接</source>
        <translation type="unfinished">Failed to add, please check the db link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="495"/>
        <source>批量新增</source>
        <comment>toolName</comment>
        <translation type="unfinished">Batch Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="550"/>
        <source>应用组号内容超长</source>
        <translation type="unfinished">Application group number is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="558"/>
        <source>库内组号内容超长</source>
        <translation type="unfinished">The content of group number in the DB is too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="566"/>
        <source>备注内容超长</source>
        <translation type="unfinished">Remarks are too long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="225"/>
        <source>数据更新错误，请检查数据库服务</source>
        <translation type="unfinished">Data update error, please check the db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="238"/>
        <source>数据保存成功</source>
        <translation type="unfinished">Data saved successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="411"/>
        <source>责任区已存在</source>
        <translation type="unfinished">AOR already exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="454"/>
        <source>是否删除</source>
        <translation type="unfinished">Whether to delete it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="399"/>
        <source>请输入责任区名称</source>
        <translation type="unfinished">Please enter the name of the AOR </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="473"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Please select the data to be operated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="478"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="509"/>
        <source>更新失败，请检查数据库服务</source>
        <translation type="unfinished">Update failed, please check the db service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="495"/>
        <source>输入数量：</source>
        <translation type="unfinished">Input quantity:</translation>
    </message>
</context>
</TS>
