<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CellFormatDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="14"/>
        <source>单元格格式</source>
        <translation type="unfinished">Cell format</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="101"/>
        <source>常规</source>
        <translation type="unfinished">Conventional</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="106"/>
        <source>日期时间</source>
        <translation type="unfinished">Datetime</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="111"/>
        <source>日期</source>
        <translation type="unfinished">Date</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="116"/>
        <source>时间</source>
        <translation type="unfinished">Time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="121"/>
        <source>数值</source>
        <translation type="unfinished">Number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="126"/>
        <source>百分比</source>
        <translation type="unfinished">Percent</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="160"/>
        <source>常规单元格格式不包含任何特定的数字格式</source>
        <translation type="unfinished">General cell formats do not include any specific number formats</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="174"/>
        <source>日期：</source>
        <translation type="unfinished">Date:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="181"/>
        <source>时间：</source>
        <translation type="unfinished">Time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="209"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="256"/>
        <source>小数位数：</source>
        <translation type="unfinished">Decimal places:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="315"/>
        <source>示例文字</source>
        <translation type="unfinished">Example Text</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="344"/>
        <source>水平对齐：</source>
        <translation type="unfinished">Horizontal:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="352"/>
        <source>靠左</source>
        <translation type="unfinished">Left align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="357"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="389"/>
        <source>居中</source>
        <translation type="unfinished">Align center</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="362"/>
        <source>靠右</source>
        <translation type="unfinished">Keep right</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="376"/>
        <source>垂直对齐：</source>
        <translation type="unfinished">Vertical:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="384"/>
        <source>靠上</source>
        <translation type="unfinished">Top align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="394"/>
        <source>靠下</source>
        <translation type="unfinished">Lean down</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="477"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="507"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="482"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="512"/>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="487"/>
        <source>3</source>
        <translation type="unfinished">3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="492"/>
        <source>4</source>
        <translation type="unfinished">4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="497"/>
        <source>5</source>
        <translation type="unfinished">5</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="502"/>
        <source>6</source>
        <translation type="unfinished">6</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="763"/>
        <source>边框</source>
        <translation type="unfinished">Border</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="436"/>
        <source>线条</source>
        <translation type="unfinished">line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="50"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="57"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="70"/>
        <source>数字</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="88"/>
        <source>分类:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Category:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="309"/>
        <source>示例</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Example</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="326"/>
        <source>对齐</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="332"/>
        <source>文本对齐方式</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Text alignment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="419"/>
        <source>字体</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Font</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="424"/>
        <source>边框</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Border</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="584"/>
        <source>颜色：</source>
        <translation type="unfinished">Color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="607"/>
        <source>预置</source>
        <translation type="unfinished">Preset</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="634"/>
        <source>外边框</source>
        <translation type="unfinished">Border</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="711"/>
        <source> 内部</source>
        <translation type="unfinished">Interior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.ui" line="756"/>
        <source>  无</source>
        <translation type="unfinished">None</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.cpp" line="74"/>
        <source>yyyy&apos;年&apos;M&apos;月&apos;d&apos;日&apos;</source>
        <translation type="unfinished">yyyy&apos;Year&apos;M&apos;Month&apos;d&apos;Day&apos;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.cpp" line="77"/>
        <source>HH&apos;时&apos;mm&apos;分&apos;ss&apos;秒&apos;</source>
        <translation type="unfinished">HH&apos;Hour&apos;mm&apos;Minute&apos;ss&apos;Second&apos;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.cpp" line="688"/>
        <source>月底</source>
        <translation type="unfinished">Month-End</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.cpp" line="689"/>
        <source>年</source>
        <translation type="unfinished">Year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.cpp" line="690"/>
        <source>月</source>
        <translation type="unfinished">Month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.cpp" line="691"/>
        <source>周</source>
        <translation type="unfinished">Week</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.cpp" line="692"/>
        <source>日</source>
        <translation type="unfinished">Day</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.cpp" line="693"/>
        <source>时</source>
        <translation type="unfinished">Hour</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.cpp" line="694"/>
        <source>分</source>
        <translation type="unfinished">Minute</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.cpp" line="695"/>
        <source>本</source>
        <translation type="unfinished">Current</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.cpp" line="696"/>
        <source>前</source>
        <translation type="unfinished">Previous</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.cpp" line="697"/>
        <source>后</source>
        <translation type="unfinished">Next</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.cpp" line="698"/>
        <source>求和</source>
        <translation type="unfinished">Sum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.cpp" line="699"/>
        <source>首部减去尾部</source>
        <translation type="unfinished">Head minus Tail</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_cell_format.cpp" line="700"/>
        <source>尾部减去首部</source>
        <translation type="unfinished">Tail minus Head</translation>
    </message>
</context>
<context>
    <name>ChooseDirDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="28"/>
        <source>报表分类选择</source>
        <translation type="unfinished">Select report category</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="32"/>
        <source>报表选择</source>
        <translation type="unfinished">Report Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="37"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="41"/>
        <source>报表分类:</source>
        <translation type="unfinished">Report category:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="45"/>
        <source>报表:</source>
        <translation type="unfinished">Report:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="60"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="63"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="152"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="156"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="165"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="169"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="179"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="152"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="165"/>
        <source>报表分类无效，请重新选择</source>
        <translation type="unfinished">Invalid report classification, please select again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="156"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="169"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_choose_dir.cpp" line="179"/>
        <source>报表无效，请重新选择</source>
        <translation type="unfinished">The report is invalid; please select again</translation>
    </message>
</context>
<context>
    <name>CommonLinkWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.ui" line="32"/>
        <source>数据库设置</source>
        <translation type="unfinished">DB settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.ui" line="50"/>
        <source>纵向</source>
        <translation type="unfinished">Vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.ui" line="76"/>
        <source>数据库表：</source>
        <translation type="unfinished">Table:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.ui" line="90"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="61"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="74"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="849"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="861"/>
        <source>自定义表</source>
        <translation type="unfinished">Custom</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.ui" line="114"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.ui" line="128"/>
        <source>上移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Move up</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.ui" line="142"/>
        <source>下移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Move down</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.ui" line="156"/>
        <source>前缀</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Prefix</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.ui" line="161"/>
        <source>对象</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.ui" line="166"/>
        <source>后缀</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Suffix</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.ui" line="40"/>
        <source>横向</source>
        <translation type="unfinished">Horizontal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.ui" line="104"/>
        <source>对象检索</source>
        <translation type="unfinished">Retrieval Obj</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="86"/>
        <source>复制当前列值到所有</source>
        <translation type="unfinished">Copy the current column value to all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="87"/>
        <source>清除当前列值</source>
        <translation type="unfinished">Clear the current column value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="129"/>
        <source>询问</source>
        <translation type="unfinished">Ask</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="130"/>
        <source>该操作将清除所有列值，是否继续</source>
        <translation type="unfinished">This operation will clear all column values. Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="446"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="450"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="454"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="641"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="645"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="649"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="739"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="743"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="747"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="446"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="641"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="739"/>
        <source>当前行列数均超过表格总行列数，将按表格总行列数做截取处理</source>
        <translation type="unfinished">The current number of rows and columns exceeds the total number of rows and columns in the table, and will be truncated according to the total number of rows and columns in the table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="450"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="645"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="743"/>
        <source>当前行数超过表格总行数，将按表格总行数做截取处理</source>
        <translation type="unfinished">If the current number of rows exceeds the total number of rows in the table, it will be truncated according to the total number of rows in the table.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="454"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="649"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_link_widget.cpp" line="747"/>
        <source>当前列数超过表格总列数，将按表格总列数做截取处理</source>
        <translation type="unfinished">The current number of columns exceeds the total number of columns in the table, and will be truncated according to the total number of columns in the table</translation>
    </message>
</context>
<context>
    <name>CommonSequenceWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="407"/>
        <source>取数时间：</source>
        <translation type="unfinished">Access time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="484"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="629"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="36"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="42"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="51"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="183"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="190"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="208"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="215"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="221"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="314"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="376"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="691"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="699"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="717"/>
        <source>本</source>
        <translation type="unfinished">Current</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="427"/>
        <source>年</source>
        <translation type="unfinished">Year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="20"/>
        <source>序列时间单位</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Seq time unit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="51"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="226"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="447"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="40"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="304"/>
        <source>月</source>
        <translation type="unfinished">Month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="54"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="211"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="317"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="379"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="720"/>
        <source>月底</source>
        <translation type="unfinished">Month-End</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="61"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="467"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="289"/>
        <source>日</source>
        <translation type="unfinished">Day</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="66"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="612"/>
        <source>时</source>
        <translation type="unfinished">Hour</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="71"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="937"/>
        <source>分</source>
        <translation type="unfinished">Minute</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="111"/>
        <source>附加信息</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Additional info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="123"/>
        <source>取数延展</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Access extension</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="141"/>
        <source>后向</source>
        <translation type="unfinished">Backward​</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="151"/>
        <source>前向</source>
        <translation type="unfinished">Forward​</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="167"/>
        <source>序列时间设置</source>
        <translation type="unfinished">Seq time settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="193"/>
        <source>序列时间步长：</source>
        <translation type="unfinished">Seq time steps:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="257"/>
        <source>序列时间个数：</source>
        <translation type="unfinished">Seq times count:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="297"/>
        <source>序列时间长度：</source>
        <translation type="unfinished">Seq time length:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="329"/>
        <source>关联设置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Link settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="370"/>
        <source>公式信息</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Formula info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="389"/>
        <source>时间设置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Clock</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="56"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="294"/>
        <source>周</source>
        <translation type="unfinished">Week</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="85"/>
        <source>序列时间单位：</source>
        <translation type="unfinished">Seq time unit:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="347"/>
        <source>单个关联</source>
        <translation type="unfinished">Single link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.ui" line="357"/>
        <source>序列关联</source>
        <translation type="unfinished">Seq link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="37"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="43"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="52"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="184"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="191"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="209"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="216"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="222"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="315"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="377"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="692"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="700"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="718"/>
        <source>前</source>
        <translation type="unfinished">Previous</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="38"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="44"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="53"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="185"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="192"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="210"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="217"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="223"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="316"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="378"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="693"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="701"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="719"/>
        <source>后</source>
        <translation type="unfinished">Next</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="83"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="125"/>
        <source>全选</source>
        <translation type="unfinished">Select all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="84"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="126"/>
        <source>反选</source>
        <translation type="unfinished">Invert</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="85"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="127"/>
        <source>取消选择</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="1189"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="1190"/>
        <source>求和</source>
        <translation type="unfinished">Sum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="1197"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="1198"/>
        <source>首部减去尾部</source>
        <translation type="unfinished">Head minus Tail</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="1205"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/common_sequence_widget.cpp" line="1206"/>
        <source>尾部减去首部</source>
        <translation type="unfinished">Tail minus Head</translation>
    </message>
</context>
<context>
    <name>DataBlockEditDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_data_block_edit.ui" line="14"/>
        <source>数据块定义</source>
        <translation type="unfinished">Data block definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_data_block_edit.ui" line="26"/>
        <source>数据块名称：</source>
        <translation type="unfinished">Data block name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_data_block_edit.ui" line="42"/>
        <source>方法名称：</source>
        <translation type="unfinished">Method name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_data_block_edit.ui" line="68"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_data_block_edit.ui" line="81"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_data_block_edit.ui" line="88"/>
        <source>数据块默认参数配置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Data block default params config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_data_block_edit.cpp" line="116"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_data_block_edit.cpp" line="121"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_data_block_edit.cpp" line="116"/>
        <source>数据块插件不能为空</source>
        <translation type="unfinished">Data block plug-in cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_data_block_edit.cpp" line="121"/>
        <source>数据块方法名不能为空</source>
        <translation type="unfinished">Data block method name cannot be empty</translation>
    </message>
</context>
<context>
    <name>DataTableConfigDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.ui" line="20"/>
        <source>数据表类型配置</source>
        <translation type="unfinished">Config Table Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.ui" line="41"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.ui" line="48"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.ui" line="57"/>
        <source>添加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.ui" line="64"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.ui" line="85"/>
        <source>数据库表名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.ui" line="90"/>
        <source>别名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.ui" line="95"/>
        <source>应用名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">App name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.ui" line="100"/>
        <source>数据库名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">DB name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.ui" line="105"/>
        <source>数据表名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.cpp" line="248"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.cpp" line="253"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.cpp" line="279"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.cpp" line="285"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.cpp" line="260"/>
        <source>异常输入</source>
        <translation type="unfinished">Abnormal input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.cpp" line="260"/>
        <source>名称数据异常，请重新输入</source>
        <translation type="unfinished">Invalid name data; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.cpp" line="285"/>
        <source>清空数据表配置失败</source>
        <translation type="unfinished">Failed to clear data table config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.cpp" line="248"/>
        <source>数据库表名称不可空</source>
        <translation type="unfinished">DB table name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.cpp" line="253"/>
        <source>数据库表名称不可与内置类型(自定义表)重名</source>
        <translation type="unfinished">The db table name cannot be duplicated as the built-in type (custom table)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.cpp" line="251"/>
        <source>自定义表</source>
        <translation type="unfinished">Custom</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_datatable_config.cpp" line="279"/>
        <source>数据库表名称不允许重名！</source>
        <translation type="unfinished">DB table names cannot be duplicated!</translation>
    </message>
</context>
<context>
    <name>ExampleBorderWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/example_border_widget.cpp" line="34"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/example_border_widget.cpp" line="39"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/example_border_widget.cpp" line="41"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/example_border_widget.cpp" line="46"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/example_border_widget.cpp" line="48"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/example_border_widget.cpp" line="53"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/example_border_widget.cpp" line="55"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/example_border_widget.cpp" line="57"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/example_border_widget.cpp" line="59"/>
        <source>文本</source>
        <translation type="unfinished">Text</translation>
    </message>
</context>
<context>
    <name>HisDataLinkDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_hisdata_link.ui" line="20"/>
        <source>历史数据关联定义</source>
        <translation type="unfinished">Historical data link definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_hisdata_link.ui" line="70"/>
        <source>添加对象标题</source>
        <translation type="unfinished">Add object title</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_hisdata_link.ui" line="60"/>
        <source>添加时标</source>
        <translation type="unfinished">Add timestamp</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_hisdata_link.ui" line="36"/>
        <source>附加统计信息</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Additional statistics</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_hisdata_link.ui" line="80"/>
        <source>标题类型：</source>
        <translation type="unfinished">Title type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_hisdata_link.ui" line="120"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_hisdata_link.ui" line="127"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_hisdata_link.cpp" line="30"/>
        <source>对象名称</source>
        <translation type="unfinished">Object name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_hisdata_link.cpp" line="31"/>
        <source>对象路径</source>
        <translation type="unfinished">Object path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_hisdata_link.cpp" line="58"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_hisdata_link.cpp" line="68"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_hisdata_link.cpp" line="58"/>
        <source>请选择对象</source>
        <translation type="unfinished">Please select object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_hisdata_link.cpp" line="68"/>
        <source>请选择时间</source>
        <translation type="unfinished">Please select time</translation>
    </message>
</context>
<context>
    <name>InsertRowColWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/insert_rowcol_widget.cpp" line="113"/>
        <source>在下方插入行</source>
        <translation type="unfinished">↓ Insert Row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/insert_rowcol_widget.cpp" line="119"/>
        <source>在上方插入行</source>
        <translation type="unfinished">↑ Insert Row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/insert_rowcol_widget.cpp" line="125"/>
        <source>在右侧插入列</source>
        <translation type="unfinished">→ Insert Col</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/insert_rowcol_widget.cpp" line="131"/>
        <source>在左侧插入列</source>
        <translation type="unfinished">← Insert Col</translation>
    </message>
</context>
<context>
    <name>PluginPathDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_plugin_path.ui" line="14"/>
        <source>应用插件路径配置</source>
        <translation type="unfinished">Config app plugin path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_plugin_path.ui" line="35"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_plugin_path.ui" line="42"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_plugin_path.ui" line="51"/>
        <source>应用数据块插件路径</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Application data block plug-in path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_plugin_path.ui" line="76"/>
        <source>路径</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_plugin_path.ui" line="84"/>
        <source>添加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_plugin_path.ui" line="91"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_plugin_path.cpp" line="42"/>
        <source>选择应用数据块路径</source>
        <translation type="unfinished">Select the path of the application data block</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_plugin_path.cpp" line="75"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_plugin_path.cpp" line="75"/>
        <source>路径存入数据库失败</source>
        <translation type="unfinished">Failed to save path to db</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/main.cpp" line="207"/>
        <source>%1没有此工具的打开权限</source>
        <comment>gui_reporteditor::main</comment>
        <translation type="unfinished">%1 does not have open permission for this tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/main.cpp" line="208"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/main.cpp" line="454"/>
        <source>提示</source>
        <comment>gui_reporteditor::main</comment>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/main.cpp" line="453"/>
        <source>%1没有此工具的打开权限!</source>
        <comment>gui_reporteditor::main</comment>
        <translation type="unfinished">%1 has no permission to open this tool</translation>
    </message>
</context>
<context>
    <name>RealDataLinkDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link.ui" line="14"/>
        <source>实时数据关联定义</source>
        <translation type="unfinished">Real-time data link definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link.ui" line="32"/>
        <source>添加对象标题</source>
        <translation type="unfinished">Add object title</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link.ui" line="42"/>
        <source>标题类型：</source>
        <translation type="unfinished">Title type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link.ui" line="82"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link.ui" line="89"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link.cpp" line="27"/>
        <source>对象名称</source>
        <translation type="unfinished">Object name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link.cpp" line="28"/>
        <source>对象路径</source>
        <translation type="unfinished">Object path</translation>
    </message>
</context>
<context>
    <name>RealDataLinkModifyDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.ui" line="14"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.cpp" line="60"/>
        <source>实时数据关联修改</source>
        <translation type="unfinished">Real-time data link modification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.ui" line="28"/>
        <source>修改对象</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Modify obj</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.ui" line="61"/>
        <source>单元格序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Cell No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.ui" line="66"/>
        <source>前缀</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Prefix</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.ui" line="71"/>
        <source>对象</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.ui" line="76"/>
        <source>后缀</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Suffix</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.ui" line="99"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.ui" line="106"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.cpp" line="31"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.cpp" line="651"/>
        <source>展开合并项</source>
        <translation type="unfinished">Expand merged items</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.cpp" line="35"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.cpp" line="647"/>
        <source>合并相同项</source>
        <translation type="unfinished">Merge identical items</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.cpp" line="64"/>
        <source>历史数据关联修改</source>
        <translation type="unfinished">Modify historical data link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.cpp" line="78"/>
        <source>复制当前列值到所有</source>
        <translation type="unfinished">Copy the current column value to all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.cpp" line="79"/>
        <source>清除当前列值</source>
        <translation type="unfinished">Clear the current column value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.cpp" line="121"/>
        <source>询问</source>
        <translation type="unfinished">Ask</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.cpp" line="122"/>
        <source>该操作将清除所有列值，是否继续</source>
        <translation type="unfinished">This operation will clear all column values. Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.cpp" line="616"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.cpp" line="616"/>
        <source>是否保存</source>
        <translation type="unfinished">Whether to save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.cpp" line="617"/>
        <source>是</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.cpp" line="618"/>
        <source>否</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.ui" line="35"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_realdata_link_modify.cpp" line="634"/>
        <source>展开合并项</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Expand merged items</translation>
    </message>
</context>
<context>
    <name>ReportCreateDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="14"/>
        <source>新建报表</source>
        <translation type="unfinished">New report</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="28"/>
        <source>报表分类：</source>
        <translation type="unfinished">Report category:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="35"/>
        <source>行数(1-2000)：</source>
        <translation type="unfinished">Lines count (1-2000) :</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="68"/>
        <source>责任区：</source>
        <translation type="unfinished">AOR:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="97"/>
        <source>模板名称：</source>
        <translation type="unfinished">Template Name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="104"/>
        <source>列数(1-1000)：</source>
        <translation type="unfinished">Cols count(1-1000) :</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="143"/>
        <source>实时报表</source>
        <translation type="unfinished">Real-time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="148"/>
        <source>历史报表</source>
        <translation type="unfinished">History</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="153"/>
        <source>其他报表</source>
        <translation type="unfinished">Other</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="161"/>
        <source>报表名称：</source>
        <translation type="unfinished">Report name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="181"/>
        <source>报表类型：</source>
        <translation type="unfinished">Report type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="188"/>
        <source>web发布</source>
        <translation type="unfinished">Web publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="198"/>
        <source>报表范围自适应</source>
        <translation type="unfinished">Rpt Scope Auto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="212"/>
        <source>清除</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="221"/>
        <source>定时生成excel</source>
        <translation type="unfinished">Gen excel regularly</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="237"/>
        <source>每月</source>
        <translation type="unfinished">Every month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="242"/>
        <source>每周</source>
        <translation type="unfinished">Weekly</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="247"/>
        <source>每日</source>
        <translation type="unfinished">Everyday</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="287"/>
        <source>日</source>
        <translation type="unfinished">Day</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="307"/>
        <source>时</source>
        <translation type="unfinished">Hour</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="327"/>
        <source>分</source>
        <translation type="unfinished">Minute</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="352"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.ui" line="359"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="87"/>
        <source>模板</source>
        <translation type="unfinished">Template</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="91"/>
        <source>动态模板</source>
        <translation type="unfinished">Dynamic template</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="95"/>
        <source>报表</source>
        <translation type="unfinished">Report</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="99"/>
        <source>修改%1</source>
        <translation type="unfinished">Modified %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="114"/>
        <source>新增%2</source>
        <translation type="unfinished">Add %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="124"/>
        <source>模板名称:</source>
        <translation type="unfinished">Template name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="263"/>
        <source>行数（%1-%2):</source>
        <translation type="unfinished">Rows count (%1-%2):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="270"/>
        <source>列数（%1-%2):</source>
        <translation type="unfinished">Cols count (%1-%2):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="396"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="401"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="480"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="485"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="396"/>
        <source>名称不可为空</source>
        <translation type="unfinished">Name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="401"/>
        <source>分类不可为空</source>
        <translation type="unfinished">Classification cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="408"/>
        <source>异常输入</source>
        <translation type="unfinished">Abnormal input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="408"/>
        <source>名称数据异常，请重新输入</source>
        <translation type="unfinished">Invalid name data; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="480"/>
        <source>%1已存在</source>
        <translation type="unfinished">%1 already exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create.cpp" line="485"/>
        <source>更新数据库信息失败，报表创建失败</source>
        <translation type="unfinished">Failed to update DB Info, report creation failed</translation>
    </message>
</context>
<context>
    <name>ReportCreateGuideDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.ui" line="20"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="47"/>
        <source>新建报表向导</source>
        <translation type="unfinished">New report wizard</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.ui" line="55"/>
        <source>报表标题：</source>
        <translation type="unfinished">Report title:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.ui" line="38"/>
        <source>报表分类：</source>
        <translation type="unfinished">Report category:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.ui" line="62"/>
        <source>报表名称：</source>
        <translation type="unfinished">Report name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.ui" line="45"/>
        <source>web发布</source>
        <translation type="unfinished">Web publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.ui" line="79"/>
        <source>报表范围自适应</source>
        <translation type="unfinished">Rpt Scope Auto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.ui" line="189"/>
        <source>对象标题类型：</source>
        <translation type="unfinished">Object title type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.ui" line="229"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.ui" line="236"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.ui" line="125"/>
        <source>报表类型：</source>
        <translation type="unfinished">Report type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.ui" line="139"/>
        <source>实时报表</source>
        <translation type="unfinished">Real-time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.ui" line="144"/>
        <source>历史报表</source>
        <translation type="unfinished">History</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="51"/>
        <source>修改报表向导</source>
        <translation type="unfinished">Modify Report Wizard</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="92"/>
        <source>对象名称</source>
        <translation type="unfinished">Object name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="93"/>
        <source>对象路径</source>
        <translation type="unfinished">Object path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="197"/>
        <source>报表日期:</source>
        <translation type="unfinished">Report date:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="200"/>
        <source>报表浏览时间</source>
        <translation type="unfinished">Report browsing time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="260"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="265"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="270"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="332"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="260"/>
        <source>名称不可为空</source>
        <translation type="unfinished">Name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="265"/>
        <source>分类不可为空</source>
        <translation type="unfinished">Classification cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="270"/>
        <source>标题不可为空</source>
        <translation type="unfinished">Title cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="277"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="284"/>
        <source>异常输入</source>
        <translation type="unfinished">Abnormal input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="277"/>
        <source>名称数据异常，请重新输入</source>
        <translation type="unfinished">Invalid name data; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="284"/>
        <source>标题数据异常，请重新输入</source>
        <translation type="unfinished">Title data exception; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="338"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="338"/>
        <source>修改向导将重建报表且不可恢复，是否继续</source>
        <translation type="unfinished">The modification wizard will rebuild the report and it cannot be recovered. Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="339"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="340"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_create_guide.cpp" line="332"/>
        <source>更新数据库信息失败，记录创建失败</source>
        <translation type="unfinished">Failed to update DB Info, record creation failed</translation>
    </message>
</context>
<context>
    <name>ReportEditor</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="510"/>
        <source>询问</source>
        <translation type="unfinished">Ask</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="676"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1031"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1035"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1194"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1198"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1208"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1295"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1325"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1421"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1457"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1561"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1609"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2087"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2101"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2397"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2427"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2678"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2923"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1478"/>
        <source>导入报表文件</source>
        <translation type="unfinished">Import file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="723"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1486"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1499"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2352"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2361"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2869"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2890"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2950"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="3146"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="549"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="644"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="873"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1145"/>
        <source>模板：</source>
        <translation type="unfinished">Template:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="511"/>
        <source>是否保存 %1 为草稿</source>
        <translation type="unfinished">Whether to save %1 as a draft</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="550"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="645"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="874"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1146"/>
        <source>草稿版本</source>
        <translation type="unfinished">Draft version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="676"/>
        <source>全部保存成功</source>
        <translation type="unfinished">All saved successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="705"/>
        <source>发布中止</source>
        <translation type="unfinished">Publish abort</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="723"/>
        <source>草稿版本不存在，发布失败</source>
        <translation type="unfinished">Draft version does not exist, publishing failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="765"/>
        <source>发布成功</source>
        <translation type="unfinished">Published successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="780"/>
        <source>发布失败</source>
        <translation type="unfinished">Publish failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="808"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1080"/>
        <source>警告</source>
        <comment>toolName</comment>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="809"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1081"/>
        <source>&apos;%1&apos; 已经被修改,是否保存</source>
        <translation type="unfinished">‘%1&apos; has been modified, whether to save it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="812"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1084"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="813"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1085"/>
        <source>放弃</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Abandon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="814"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1086"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="922"/>
        <source>进行所有报表发布请先关闭所有已打开的报表</source>
        <translation type="unfinished">Please close all reports</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1031"/>
        <source>暂无需要发布的报表</source>
        <translation type="unfinished">No reports to publish.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1035"/>
        <source>所有报表发布成功</source>
        <translation type="unfinished">All reports have been successfully published</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1040"/>
        <source>共有 %1 个报表发布失败:</source>
        <translation type="unfinished">A total of %1 reports failed to publish:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1051"/>
        <source>全部发布结果</source>
        <translation type="unfinished">Publish all results</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1054"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1313"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1343"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1194"/>
        <source>进行所有报表清除历史版本请先关闭所有已打开的报表</source>
        <translation type="unfinished">Please close all reports</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1198"/>
        <source>此操作将删除所有报表的历史版本，是否继续</source>
        <translation type="unfinished">This operation will delete the historical versions of all reports; whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1199"/>
        <source>是</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1200"/>
        <source>否</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1208"/>
        <source>是否版本归零</source>
        <translation type="unfinished">Whether to reset the version to zero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1209"/>
        <source>归零</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Reset to zero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1210"/>
        <source>不归零</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Skip reset to zero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1211"/>
        <source>取消操作</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1295"/>
        <source>全部版本归零成功</source>
        <translation type="unfinished">All versions reset to zero successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1299"/>
        <source>共有 %1 个报表归零失败:</source>
        <translation type="unfinished">A total of %1 reports failed to reset to zero:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1310"/>
        <source>全部归零结果</source>
        <translation type="unfinished">All results after resetting to zero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1325"/>
        <source>全部历史版本清除成功</source>
        <translation type="unfinished">All historical versions cleared successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1329"/>
        <source>共有 %1 个报表历史版本清除失败:</source>
        <translation type="unfinished">%1 report historical versions clear failed:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1340"/>
        <source>全部历史版本清除结果</source>
        <translation type="unfinished">Result of clearing all historical versions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1421"/>
        <source>预览前，是否保存对%1的更改</source>
        <translation type="unfinished">Save changes to %1 before previewing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1457"/>
        <source>版本已更新，将重新加载最新版本</source>
        <translation type="unfinished">Version updated, the latest version will be reloaded</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1478"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1530"/>
        <source>报表文件</source>
        <translation type="unfinished">Report files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1486"/>
        <source>报表文件格式无效</source>
        <translation type="unfinished">Invalid report file format</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1499"/>
        <source>复制到%1路径失败</source>
        <translation type="unfinished">Copy to %1 path failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1530"/>
        <source>导出报表文件</source>
        <translation type="unfinished">Export file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1561"/>
        <source>报表 : %1 已打开 %2</source>
        <translation type="unfinished">Report: %1 has opened %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1609"/>
        <source>报表已在节点：%1,进程号：%2,注册名：%3 中打开</source>
        <translation type="unfinished">The report has been opened in node: %1, PID: %2, registered name: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="1669"/>
        <source>导入Xlsx文件</source>
        <translation type="unfinished">Import xlsx file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2087"/>
        <source>插入%1行后将超过表格最大行数%2，将按最大行数做截取处理</source>
        <translation type="unfinished">After %1 column is inserted, the maximum number %2 of columns in the table will be exceeded and interception will be conducted according to the maximum number of columns</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2101"/>
        <source>插入%1列后将超过表格最大列数%2，将按最大列数做截取处理</source>
        <translation type="unfinished">After %1 column is inserted, the maximum number %2 of columns in the table will be exceeded and interception will be conducted according to the maximum number of columns.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2119"/>
        <source>打开</source>
        <translation type="unfinished">Open</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2126"/>
        <source>打开失败</source>
        <translation type="unfinished">Open failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2126"/>
        <source>未知的文件格式</source>
        <translation type="unfinished">Unknown file format</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2352"/>
        <source>多重选定区域，不可进行合并/拆分单元格操作</source>
        <translation type="unfinished">Multiple selected areas, cannot merge/split cells</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2361"/>
        <source>区域内有数据块插件，不可合并/拆分单元格</source>
        <translation type="unfinished">Range has data block plugin. No merge/split cells.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2397"/>
        <source>暂无选中的行</source>
        <translation type="unfinished">No selected row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2427"/>
        <source>暂无选中的列</source>
        <translation type="unfinished">No selected columns</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2569"/>
        <source>月底</source>
        <translation type="unfinished">Month-End</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2570"/>
        <source>年</source>
        <translation type="unfinished">Year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2571"/>
        <source>月</source>
        <translation type="unfinished">Month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2572"/>
        <source>周</source>
        <translation type="unfinished">Week</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2573"/>
        <source>日</source>
        <translation type="unfinished">Day</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2574"/>
        <source>时</source>
        <translation type="unfinished">Hour</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2575"/>
        <source>分</source>
        <translation type="unfinished">Minute</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2576"/>
        <source>本</source>
        <translation type="unfinished">Current</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2577"/>
        <source>前</source>
        <translation type="unfinished">Previous</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2578"/>
        <source>后</source>
        <translation type="unfinished">Next</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2579"/>
        <source>求和</source>
        <translation type="unfinished">Sum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2580"/>
        <source>首部减去尾部</source>
        <translation type="unfinished">Head minus Tail</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2581"/>
        <source>尾部减去首部</source>
        <translation type="unfinished">Tail minus Head</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2708"/>
        <source>选择区域内无实时关联定义</source>
        <translation type="unfinished">No real-time link definition in the selected area</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2736"/>
        <source>选择区域内无历史关联定义</source>
        <translation type="unfinished">No historical link definition in the selected area</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2862"/>
        <source>数据块插件路径下文件较多，正在扫描数据块插件，请稍后再试</source>
        <translation type="unfinished">Data block plugin path: many files. Scanning. Try later.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2869"/>
        <source>多重选定区域，不支持进行数据块定义操作</source>
        <translation type="unfinished">Multiple selected areas, data block definition operation is not supported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2890"/>
        <source>此区域已包含数据块数据，请删除后再进行定义</source>
        <translation type="unfinished">This area already includes data block data, please delete it before defining</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2950"/>
        <source>多重选定区域，不支持设置打印范围</source>
        <translation type="unfinished">Multiple selected areas, setting the print range is not supported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2955"/>
        <source>设置打印范围成功</source>
        <translation type="unfinished">Set print range successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2976"/>
        <source>未设置打印范围</source>
        <translation type="unfinished">Print range not set</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="3146"/>
        <source>报表已打开，请先关闭再删除</source>
        <translation type="unfinished">The report has been opened. Please close it before deleting it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2622"/>
        <source>关于 %1</source>
        <translation type="unfinished">About %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2119"/>
        <source>所有文件</source>
        <translation type="unfinished">All files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2624"/>
        <source>版本  %2</source>
        <translation type="unfinished">Version %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2678"/>
        <source>当前区域存在关联定义，是否覆盖</source>
        <translation type="unfinished">Existing Link found; whether to overwrite it?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="705"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="765"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="780"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2708"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2736"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2862"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2955"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2976"/>
        <source>通知</source>
        <translation type="unfinished">Notification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2822"/>
        <source>报表浏览时间</source>
        <translation type="unfinished">Report browsing time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2845"/>
        <source>数据生成时间</source>
        <translation type="unfinished">Data gened time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2923"/>
        <source>当前区域存在关联定义，是否删除</source>
        <translation type="unfinished">Existing Link found; whether to delete it?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_editor.cpp" line="2992"/>
        <source>属性...</source>
        <translation type="unfinished">Attrs...</translation>
    </message>
</context>
<context>
    <name>ReportFormulaWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_formula_widget.cpp" line="41"/>
        <source>宋体</source>
        <translation type="unfinished">Song typeface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_formula_widget.cpp" line="56"/>
        <source>取消公式定义</source>
        <translation type="unfinished">Cancel formula definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_formula_widget.cpp" line="58"/>
        <source>确认公式定义</source>
        <translation type="unfinished">Confirm formula definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_formula_widget.cpp" line="60"/>
        <source>公式定义</source>
        <translation type="unfinished">Formula definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_formula_widget.cpp" line="113"/>
        <source>添加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
</context>
<context>
    <name>ReportImportDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_import.cpp" line="32"/>
        <source>行数（%1-%2):</source>
        <translation type="unfinished">Rows count (%1-%2):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_import.cpp" line="33"/>
        <source>列数（%1-%2):</source>
        <translation type="unfinished">Cols count (%1-%2):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_report_import.cpp" line="34"/>
        <source>导入文件</source>
        <translation type="unfinished">Import file</translation>
    </message>
</context>
<context>
    <name>ReportMainwindow</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="169"/>
        <source>登录时限：</source>
        <translation type="unfinished">Login time limit:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="200"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="486"/>
        <source>%1 暂无此工具的权限</source>
        <translation type="unfinished">%1 no permission for this tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="201"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="487"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="243"/>
        <source>报表编辑工具(节点名:%1)</source>
        <comment>toolName</comment>
        <translation type="unfinished">Report Editor (Node: %1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="255"/>
        <source>报表列表</source>
        <comment>toolName</comment>
        <translation type="unfinished">Report List</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="290"/>
        <source>异常输入</source>
        <translation type="unfinished">Abnormal input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="290"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished">Abnormal query data, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="517"/>
        <source>文件</source>
        <comment>subTitle</comment>
        <translation type="unfinished">File</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="520"/>
        <source>新建</source>
        <translation type="unfinished">New</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="521"/>
        <source>向导新建</source>
        <translation type="unfinished">New wizard</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="522"/>
        <source>新建模板</source>
        <translation type="unfinished">New template</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="523"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="524"/>
        <source>全部保存</source>
        <translation type="unfinished">Save all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="525"/>
        <source>发布</source>
        <translation type="unfinished">Publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="526"/>
        <source>全部发布</source>
        <translation type="unfinished">Publish all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="527"/>
        <source>清除历史</source>
        <translation type="unfinished">Clear history</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="528"/>
        <source>另存为</source>
        <translation type="unfinished">Save as</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="529"/>
        <source>另存为模板</source>
        <translation type="unfinished">Save as template</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="532"/>
        <source>导入</source>
        <comment>menuName</comment>
        <translation type="unfinished">Import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="535"/>
        <source>导入报表文件</source>
        <comment>menuName</comment>
        <translation type="unfinished">Import file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="536"/>
        <source>导入xlsx文件(只包含样式和文本)</source>
        <comment>menuName</comment>
        <translation type="unfinished">Import xlsx file (styles and text only)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="543"/>
        <source>导出</source>
        <comment>menuName</comment>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="546"/>
        <source>导出报表文件</source>
        <comment>menuName</comment>
        <translation type="unfinished">Export file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="548"/>
        <source>导出xlsx文件</source>
        <comment>menuName</comment>
        <translation type="unfinished">Export xlsx file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="553"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="555"/>
        <source>打印</source>
        <comment>menuName</comment>
        <translation type="unfinished">Print</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="557"/>
        <source>打印预览</source>
        <comment>menuName</comment>
        <translation type="unfinished">Print preview</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="563"/>
        <source>退出</source>
        <comment>menuName</comment>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="568"/>
        <source>编辑</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="579"/>
        <source>恢复</source>
        <comment>menuName</comment>
        <translation type="unfinished">Redo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="588"/>
        <source>剪切</source>
        <comment>menuName</comment>
        <translation type="unfinished">Cut</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="589"/>
        <source>复制</source>
        <comment>menuName</comment>
        <translation type="unfinished">Copy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="590"/>
        <source>粘贴</source>
        <comment>menuName</comment>
        <translation type="unfinished">Paste</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="593"/>
        <source>清除内容</source>
        <comment>menuName</comment>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="594"/>
        <source>删除行</source>
        <comment>menuName</comment>
        <translation type="unfinished">Delete row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="595"/>
        <source>删除列</source>
        <comment>menuName</comment>
        <translation type="unfinished">Delete col</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="596"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="1071"/>
        <source>删除关联</source>
        <comment>menuName</comment>
        <translation type="unfinished">Delete link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="597"/>
        <source>查找</source>
        <comment>menuName</comment>
        <translation type="unfinished">Find</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="598"/>
        <source>替换</source>
        <comment>menuName</comment>
        <translation type="unfinished">Replace</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="600"/>
        <source>数据表定义</source>
        <comment>menuName</comment>
        <translation type="unfinished">Definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="605"/>
        <source>插入</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Insert</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="608"/>
        <source>插入行</source>
        <comment>menuName</comment>
        <translation type="unfinished">Insert row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="615"/>
        <source>插入列</source>
        <comment>menuName</comment>
        <translation type="unfinished">Insert col</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="679"/>
        <source>格式</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Format</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="682"/>
        <source>格式刷</source>
        <comment>menuName</comment>
        <translation type="unfinished">Format</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="717"/>
        <source>合并/拆分</source>
        <comment>menuName</comment>
        <translation type="unfinished">Merge/split</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="719"/>
        <source>单元格格式</source>
        <comment>menuName</comment>
        <translation type="unfinished">Cell format</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="720"/>
        <source>行高</source>
        <comment>menuName</comment>
        <translation type="unfinished">Height</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="721"/>
        <source>列宽</source>
        <comment>menuName</comment>
        <translation type="unfinished">Col width</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="768"/>
        <source>加粗</source>
        <comment>menuName</comment>
        <translation type="unfinished">Bold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="772"/>
        <source>斜体</source>
        <comment>menuName</comment>
        <translation type="unfinished">Italic</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="776"/>
        <source>下划线</source>
        <comment>menuName</comment>
        <translation type="unfinished">Base Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="780"/>
        <source>删除线</source>
        <comment>menuName</comment>
        <translation type="unfinished">Strikeout line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="797"/>
        <source>边框选择</source>
        <comment>menuName</comment>
        <translation type="unfinished">Border selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="808"/>
        <source>顶端对齐</source>
        <comment>menuName</comment>
        <translation type="unfinished">Top align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="813"/>
        <source>垂直居中</source>
        <comment>menuName</comment>
        <translation type="unfinished">Vertical center</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="817"/>
        <source>底端对齐</source>
        <comment>menuName</comment>
        <translation type="unfinished">Bottom align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="828"/>
        <source>左对齐</source>
        <comment>menuName</comment>
        <translation type="unfinished">Left align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="833"/>
        <source>水平居中</source>
        <comment>menuName</comment>
        <translation type="unfinished">Horizontal center</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="837"/>
        <source>右对齐</source>
        <comment>menuName</comment>
        <translation type="unfinished">Right align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="856"/>
        <source>无框线</source>
        <comment>menuName</comment>
        <translation type="unfinished">Borderless lines</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="858"/>
        <source>所有框线</source>
        <comment>menuName</comment>
        <translation type="unfinished">All border lines</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="860"/>
        <source>外侧框线</source>
        <comment>menuName</comment>
        <translation type="unfinished">Outside border line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="862"/>
        <source>粗匣框线</source>
        <comment>menuName</comment>
        <translation type="unfinished">Thick box border line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="865"/>
        <source>下框线</source>
        <comment>menuName</comment>
        <translation type="unfinished">Bottom border line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="867"/>
        <source>上框线</source>
        <comment>menuName</comment>
        <translation type="unfinished">Top border line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="869"/>
        <source>左框线</source>
        <comment>menuName</comment>
        <translation type="unfinished">Left border line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="871"/>
        <source>右框线</source>
        <comment>menuName</comment>
        <translation type="unfinished">Right border line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="873"/>
        <source>上下框线</source>
        <comment>menuName</comment>
        <translation type="unfinished">Top-bottom border line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="880"/>
        <source>边框颜色</source>
        <comment>menuName</comment>
        <translation type="unfinished">Border color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="890"/>
        <source>窗口</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Window</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="893"/>
        <source>报表字典</source>
        <comment>menuName</comment>
        <translation type="unfinished">Dictionary</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="896"/>
        <source>层叠排列</source>
        <comment>menuName</comment>
        <translation type="unfinished">Cascade</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="897"/>
        <source>平铺排列</source>
        <comment>menuName</comment>
        <translation type="unfinished">Tiled</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="900"/>
        <source>换肤</source>
        <comment>menuName</comment>
        <translation type="unfinished">Skin change</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="902"/>
        <source>平台灰</source>
        <comment>menuName</comment>
        <translation type="unfinished">Platform grey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="909"/>
        <source>平台蓝</source>
        <comment>menuName</comment>
        <translation type="unfinished">Platform blue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="916"/>
        <source>灰色</source>
        <comment>menuName</comment>
        <translation type="unfinished">grey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="923"/>
        <source>白色</source>
        <comment>menuName</comment>
        <translation type="unfinished">white</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="930"/>
        <source>蓝色</source>
        <comment>menuName</comment>
        <translation type="unfinished">blue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="943"/>
        <source>帮助</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Help</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="945"/>
        <source>关于</source>
        <comment>menuName</comment>
        <translation type="unfinished">About</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="970"/>
        <source>定义实时关联</source>
        <comment>menuName</comment>
        <translation type="unfinished">Define real-time link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="972"/>
        <source>修改实时关联</source>
        <comment>menuName</comment>
        <translation type="unfinished">Modified real-time link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="977"/>
        <source>定义历史关联</source>
        <comment>menuName</comment>
        <translation type="unfinished">Define history link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="980"/>
        <source>修改历史关联</source>
        <comment>menuName</comment>
        <translation type="unfinished">Modify history link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="985"/>
        <source>修改向导信息</source>
        <comment>menuName</comment>
        <translation type="unfinished">Modify wizard info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="990"/>
        <source>定义时间关联</source>
        <comment>menuName</comment>
        <translation type="unfinished">Define date link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="993"/>
        <source>报表浏览日期</source>
        <comment>menuName</comment>
        <translation type="unfinished">Report viewing date</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="995"/>
        <source>数据生成日期</source>
        <comment>menuName</comment>
        <translation type="unfinished">Data generation date</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="1067"/>
        <source>动态属性编辑</source>
        <comment>menuName</comment>
        <translation type="unfinished">Dynamic attrs edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="1075"/>
        <source>插入</source>
        <comment>menuName</comment>
        <translation type="unfinished">Insert</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="1077"/>
        <source>插入单元格，活动单元格右移</source>
        <comment>menuName</comment>
        <translation type="unfinished">Insert cell, move active cell right</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="1081"/>
        <source>插入单元格，活动单元格下移</source>
        <comment>menuName</comment>
        <translation type="unfinished">Insert cell, move active cell down</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="1154"/>
        <source>删除</source>
        <comment>menuName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="1156"/>
        <source>右侧单元格左移</source>
        <comment>menuName</comment>
        <translation type="unfinished">Move the right cell left</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="1160"/>
        <source>下方单元格上移</source>
        <comment>menuName</comment>
        <translation type="unfinished">Move the lower cell up</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="1166"/>
        <source>整行</source>
        <comment>menuName</comment>
        <translation type="unfinished">Whole row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="1167"/>
        <source>整列</source>
        <comment>menuName</comment>
        <translation type="unfinished">Whole column</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="1241"/>
        <source>设置为打印范围</source>
        <comment>menuName</comment>
        <translation type="unfinished">Set print range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="1245"/>
        <source>清空打印范围</source>
        <comment>menuName</comment>
        <translation type="unfinished">Clear print range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="1246"/>
        <source>查看打印范围</source>
        <comment>menuName</comment>
        <translation type="unfinished">View print range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="570"/>
        <source>撤销</source>
        <translation type="unfinished">Undo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="689"/>
        <source>增大字号</source>
        <translation type="unfinished">Increase the size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="703"/>
        <source>缩小字号</source>
        <translation type="unfinished">Reduce font size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="786"/>
        <source>文字颜色</source>
        <translation type="unfinished">Text color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="791"/>
        <source>填充颜色</source>
        <translation type="unfinished">Fill color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/report_mainwindow.cpp" line="876"/>
        <source>其他边框</source>
        <translation type="unfinished">Other border</translation>
    </message>
</context>
<context>
    <name>RowColHeightDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_rowcol_height.cpp" line="26"/>
        <source>行高</source>
        <translation type="unfinished">Height</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_rowcol_height.cpp" line="27"/>
        <source>行高（R)(5-2000):</source>
        <translation type="unfinished">Row height (R)(5-2000):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_rowcol_height.cpp" line="31"/>
        <source>列宽</source>
        <translation type="unfinished">Col width</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_rowcol_height.cpp" line="32"/>
        <source>列宽（C)(5-2000):</source>
        <translation type="unfinished">Col width (C) (5-2000):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_rowcol_height.cpp" line="42"/>
        <source>像素</source>
        <translation type="unfinished">pixel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_rowcol_height.cpp" line="45"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_rowcol_height.cpp" line="48"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>SaveAsDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_save_as.ui" line="14"/>
        <source>另存为</source>
        <translation type="unfinished">Save as</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_save_as.ui" line="41"/>
        <source>报表名称：</source>
        <translation type="unfinished">Report name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_save_as.ui" line="61"/>
        <source>报表分类：</source>
        <translation type="unfinished">Report category:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_save_as.ui" line="85"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_save_as.ui" line="92"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_save_as.cpp" line="42"/>
        <source>另存为模板</source>
        <comment>toolName</comment>
        <translation type="unfinished">Save As Template</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_save_as.cpp" line="45"/>
        <source>模板名称：</source>
        <translation type="unfinished">Template name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_save_as.cpp" line="46"/>
        <source>模板分类：</source>
        <translation type="unfinished">Template type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_save_as.cpp" line="91"/>
        <source>分类不可为空</source>
        <translation type="unfinished">Classification cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_save_as.cpp" line="98"/>
        <source>异常输入</source>
        <translation type="unfinished">Abnormal input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_save_as.cpp" line="98"/>
        <source>名称数据异常，请重新输入</source>
        <translation type="unfinished">Invalid name data; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_save_as.cpp" line="121"/>
        <source>复制到%1路径失败</source>
        <translation type="unfinished">Copy to %1 path failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_save_as.cpp" line="91"/>
        <location filename="../../../../src/plat/gui/tool/gui_reporteditor/dialogs/dlg_save_as.cpp" line="121"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
</context>
</TS>
