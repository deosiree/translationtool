<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CMyBasicPlot</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_plot.cpp" line="289"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_plot.cpp" line="300"/>
        <source>年</source>
        <translation type="unfinished">Año</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_plot.cpp" line="300"/>
        <source>周</source>
        <translation type="unfinished">Semana</translation>
    </message>
</context>
<context>
    <name>CMyCanvasArea</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2308"/>
        <source>保存曲线数据</source>
        <translation type="unfinished">Guardar datos de la curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2329"/>
        <source>%1-x轴(时间), </source>
        <translation type="unfinished">%1-Eje x (Tiempo),</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2329"/>
        <source>%1-y轴(值)</source>
        <translation type="unfinished">%1-Eje y (valor)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2368"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2424"/>
        <source>成功</source>
        <translation type="unfinished">Éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2368"/>
        <source>曲线数据已成功导出!</source>
        <translation type="unfinished">¡Los datos de la curva se han exportado con éxito!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2373"/>
        <source>导入曲线数据</source>
        <translation type="unfinished">Importar datos de la curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2380"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2380"/>
        <source>无法打开文件 %1</source>
        <translation type="unfinished">No se puede abrir el archivo %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2424"/>
        <source>数据导入成功</source>
        <translation type="unfinished">Importación de datos exitosa</translation>
    </message>
</context>
<context>
    <name>CMyCurveDefinition</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="142"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="143"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="169"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="173"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="815"/>
        <source>当前区间</source>
        <translation type="unfinished">Rango actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="147"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="148"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="807"/>
        <source>本月</source>
        <translation type="unfinished">Este mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="152"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="153"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="811"/>
        <source>本年</source>
        <translation type="unfinished">Este año</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="157"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="158"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="803"/>
        <source>本日</source>
        <translation type="unfinished">Hoy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="188"/>
        <source>基本属性</source>
        <translation type="unfinished">Atributos Básicos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1292"/>
        <source>曲线名称：</source>
        <translation type="unfinished">Nombre de la curva:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1295"/>
        <source>请输入曲线名称</source>
        <translation type="unfinished">Ingrese un nombre de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1314"/>
        <source>线色：</source>
        <translation type="unfinished">Color de línea:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1298"/>
        <source>小数点精度：</source>
        <translation type="unfinished">Precisión del punto decimal:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1309"/>
        <source>线宽：</source>
        <translation type="unfinished">Ancho de línea:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1324"/>
        <source>对象检索：</source>
        <translation type="unfinished">Recuperación de objeto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1328"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1441"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1446"/>
        <source>检索</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Buscar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1347"/>
        <source>设置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Configuraciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1427"/>
        <source>配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Configuraciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1249"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1251"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1253"/>
        <source>上移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Mover arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1255"/>
        <source>下移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Mover hacia abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1257"/>
        <source>复制</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Duplicar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="528"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="294"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="752"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Verdadero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="294"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="752"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">Falso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="529"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="841"/>
        <source>请选择需要操作的曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1330"/>
        <source>计划值曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1343"/>
        <source>起始时间：</source>
        <translation type="unfinished">Hora de inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1365"/>
        <source>数据点形状：</source>
        <translation type="unfinished">Forma del punto de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1369"/>
        <source>空心圆</source>
        <translation type="unfinished">Círculo hueco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1369"/>
        <source>实心圆</source>
        <translation type="unfinished">Círculo sólido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1369"/>
        <source>正方形</source>
        <translation type="unfinished">Cuadrado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1369"/>
        <source>三角形</source>
        <translation type="unfinished">Triángulo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="243"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1380"/>
        <source>显示数据点</source>
        <translation type="unfinished">Mostrar puntos de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1419"/>
        <source>计算曲线</source>
        <translation type="unfinished">Curva de cálculo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1438"/>
        <source>X轴数据源:</source>
        <translation type="unfinished">Fuente de datos del eje X:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1443"/>
        <source>Y轴数据源:</source>
        <translation type="unfinished">Fuente de datos del eje Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1387"/>
        <source>单位:</source>
        <translation type="unfinished">Unidad:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1389"/>
        <source>请输入单位</source>
        <translation type="unfinished">Ingrese la unidad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1393"/>
        <source>Y轴配置:</source>
        <translation type="unfinished">Config del eje Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="243"/>
        <source>曲线名称</source>
        <translation type="unfinished">Nombre de la curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="243"/>
        <source>线色</source>
        <translation type="unfinished">Color de línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="243"/>
        <source>线宽</source>
        <translation type="unfinished">Ancho de línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="243"/>
        <source>基本点形状</source>
        <translation type="unfinished">Forma básica del punto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="243"/>
        <source>对象检索</source>
        <translation type="unfinished">Obj de recuperación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="493"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="595"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="841"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="493"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="595"/>
        <source>曲线数量超过限制</source>
        <translation type="unfinished">El número de curvas excede el límite</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="498"/>
        <source>线</source>
        <translation type="unfinished">Línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="523"/>
        <source>删除</source>
        <comment>toolName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="525"/>
        <source>删除不可恢复，是否继续</source>
        <translation type="unfinished">La eliminación es irrecuperable. Desea continuar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="617"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="628"/>
        <source>-副本(%1)</source>
        <translation type="unfinished">-Copiar(%1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="621"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="623"/>
        <source>-副本</source>
        <translation type="unfinished">-Copiar</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupAttribute</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="105"/>
        <source>曲线组名称：</source>
        <translation type="unfinished">Nombre del grupo de curvas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="107"/>
        <source>请输入</source>
        <translation type="unfinished">Ingrese</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="117"/>
        <source>曲线组类型:</source>
        <translation type="unfinished">Tipo de grupo de curvas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="121"/>
        <source>日曲线</source>
        <translation type="unfinished">Curva diaria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="121"/>
        <source>月曲线</source>
        <translation type="unfinished">Curva mensual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="121"/>
        <source>年曲线</source>
        <translation type="unfinished">Curva anual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="121"/>
        <source>实时曲线</source>
        <translation type="unfinished">Curva en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="150"/>
        <source>展示形式:</source>
        <translation type="unfinished">Formato de visualización:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="154"/>
        <source>点</source>
        <translation type="unfinished">Punto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="154"/>
        <source>线</source>
        <translation type="unfinished">Línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="154"/>
        <source>向下填充</source>
        <translation type="unfinished">Rellenar hacia abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="177"/>
        <source>左边距:</source>
        <translation type="unfinished">Margen izquierdo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="180"/>
        <source>下边距:</source>
        <translation type="unfinished">Margen inferior:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="195"/>
        <source>背景颜色:</source>
        <translation type="unfinished">BG color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="202"/>
        <source>阈值颜色:</source>
        <translation type="unfinished">Color del umbral:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="216"/>
        <source>阈值上限:</source>
        <translation type="unfinished">Umbral superior:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="227"/>
        <source>阈值下限:</source>
        <translation type="unfinished">Umbral inferior:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="247"/>
        <source>刷新周期%1</source>
        <translation type="unfinished">Ciclo de actualización %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="265"/>
        <source>区间配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Rango</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="330"/>
        <source>标题栏</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Barra de Título</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="331"/>
        <source>网格</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Cuadrícula</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="332"/>
        <source>图例</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Leyenda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="333"/>
        <source>游标</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Cursor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="334"/>
        <source>坐标轴</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Eje de Coordenadas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="339"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="467"/>
        <source>多Y轴</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Múltiples Ejes Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="279"/>
        <source>背景透明</source>
        <translation type="unfinished">Fondo transparente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="282"/>
        <source>平滑曲线</source>
        <translation type="unfinished">Curva suave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="285"/>
        <source>曲线详情</source>
        <translation type="unfinished">Detalles de la curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="288"/>
        <source>显示阈值</source>
        <translation type="unfinished">Umbral de visualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="291"/>
        <source>漏点断开</source>
        <translation type="unfinished">Ruptura de fuga</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="295"/>
        <source>绝对值曲线</source>
        <translation type="unfinished">Curva de valor absoluto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="450"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="455"/>
        <source>至</source>
        <translation type="unfinished">a</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="493"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="549"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="494"/>
        <source>切换曲线类型,需要清空曲线，是否确定?</source>
        <translation type="unfinished">Cambiar el tipo de curva. Necesita borrar la curva. ¿Está seguro?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="549"/>
        <source>暂不支持该类型曲线</source>
        <translation type="unfinished">Este tipo de curva no es compatible actualmente</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupAxis</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="99"/>
        <source>坐标轴自适应</source>
        <translation type="unfinished">Eje adaptativo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="103"/>
        <source>多Y轴</source>
        <translation type="unfinished">Múltiples ejes Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="115"/>
        <source>是否固定轴</source>
        <translation type="unfinished">Fijar eje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="144"/>
        <source>X轴主刻度:</source>
        <translation type="unfinished">Escala mayor del eje X:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="149"/>
        <source>Y轴主刻度:</source>
        <translation type="unfinished">Escala mayor del eje Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="168"/>
        <source>X轴字体:</source>
        <translation type="unfinished">Fuente del eje X:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="171"/>
        <source>Y轴字体:</source>
        <translation type="unfinished">Fuente del eje Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="185"/>
        <source>坐标轴线宽:</source>
        <translation type="unfinished">Ancho del eje de coordenadas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="191"/>
        <source>坐标轴颜色:</source>
        <translation type="unfinished">Color del eje:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="206"/>
        <source>y轴最小值:</source>
        <translation type="unfinished">Mínimo del eje Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="212"/>
        <source>y轴最大值:</source>
        <translation type="unfinished">Máximo del eje y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="231"/>
        <source>曲线轴区间:</source>
        <translation type="unfinished">Rango del eje de la curva:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="235"/>
        <source>设置实时曲线的轴范围</source>
        <translation type="unfinished">Establecer el rango del eje de la curva en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="237"/>
        <source>显示历史</source>
        <translation type="unfinished">Mostrar historial</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupCursor</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="38"/>
        <source>显示游标</source>
        <translation type="unfinished">Mostrar cursor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="41"/>
        <source>显示日期</source>
        <translation type="unfinished">Mostrar fecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="44"/>
        <source>背景透明</source>
        <translation type="unfinished">Fondo transparente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="63"/>
        <source>背景颜色：</source>
        <translation type="unfinished">BG color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="64"/>
        <source>字体大小：</source>
        <translation type="unfinished">Tamaño de fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="82"/>
        <source>游标线宽：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="83"/>
        <source>游标颜色：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="96"/>
        <source>实线</source>
        <translation type="unfinished">Línea sólida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="96"/>
        <source>虚线</source>
        <translation type="unfinished">Línea discontinua</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="96"/>
        <source>点线</source>
        <translation type="unfinished">Línea punteada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="96"/>
        <source>点划线</source>
        <translation type="unfinished">Línea de puntos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="99"/>
        <source>游标线型：</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupGrid</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_grid.cpp" line="56"/>
        <source>不显示</source>
        <translation type="unfinished">Ocultar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_grid.cpp" line="57"/>
        <source>多列</source>
        <translation type="unfinished">Múltiples cols</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_grid.cpp" line="58"/>
        <source>少列</source>
        <translation type="unfinished">Menos cols</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_grid.cpp" line="69"/>
        <source>网格线颜色:</source>
        <translation type="unfinished">Color de la línea de cuadrícula:</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupLegend</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="70"/>
        <source>隐藏图例</source>
        <translation type="unfinished">Ocultar leyenda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="74"/>
        <source>图例间距：</source>
        <translation type="unfinished">Espaciado de leyenda:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="78"/>
        <source>图例方向：</source>
        <translation type="unfinished">Dirección de la leyenda:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>上左</source>
        <translation type="unfinished">Superior izquierdo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>上中</source>
        <translation type="unfinished">Parte superior media</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>上右</source>
        <translation type="unfinished">Superior derecho</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>中左</source>
        <translation type="unfinished">Centro izquierdo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>正中</source>
        <translation type="unfinished">Medio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>中右</source>
        <translation type="unfinished">Centro derecho</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>下左</source>
        <translation type="unfinished">Inferior izquierdo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>下中</source>
        <translation type="unfinished">Inferior medio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="82"/>
        <source>下右</source>
        <translation type="unfinished">Inferior derecho</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="95"/>
        <source>排列方式:</source>
        <translation type="unfinished">Arreglo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="98"/>
        <source>水平</source>
        <translation type="unfinished">Horizontal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="98"/>
        <source>垂直</source>
        <translation type="unfinished">Vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="102"/>
        <source>换行:</source>
        <translation type="unfinished">Salto de línea:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="106"/>
        <source>设置图例自动换行，0表示不换行</source>
        <translation type="unfinished">Establecer la leyenda para ajustar automáticamente, 0 significa sin ajuste</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="120"/>
        <source>图例字体:</source>
        <translation type="unfinished">Fuente de la leyenda:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="124"/>
        <source>图例颜色:</source>
        <translation type="unfinished">Color de la leyenda:</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupTitleBar</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="39"/>
        <source>显示标题栏</source>
        <translation type="unfinished">Mostrar barra de título</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="42"/>
        <source>背景透明</source>
        <translation type="unfinished">Fondo transparente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="46"/>
        <source>显示按钮</source>
        <translation type="unfinished">Mostrar botón</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="56"/>
        <source>背景颜色:</source>
        <translation type="unfinished">BG color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="57"/>
        <source>字体颜色:</source>
        <translation type="unfinished">Color de fuente:</translation>
    </message>
</context>
<context>
    <name>CMyCurveNewCreate</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="56"/>
        <source>曲线组属性</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Atributos del Grupo de Curvas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="57"/>
        <source>曲线定义</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Definición de Curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="60"/>
        <source>设置曲线属性</source>
        <translation type="unfinished">Establecer atributos de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="152"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="160"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="165"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="171"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="177"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="182"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="198"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="152"/>
        <source>对象检索为空,请关联曲线数据</source>
        <translation type="unfinished">La recuperación del objeto está vacía, por favor vincule los datos de la curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="160"/>
        <source>曲线名称不可为空</source>
        <translation type="unfinished">El nombre de la curva no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="165"/>
        <source>曲线重复</source>
        <translation type="unfinished">La curva se repite</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="171"/>
        <source>曲线名称不可重复</source>
        <translation type="unfinished">Los nombres de las curvas no pueden repetirse</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="177"/>
        <source>y轴最小值大于y轴最大值</source>
        <translation type="unfinished">El mínimo del eje Y es mayor que el máximo del eje Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="182"/>
        <source>阈值下限大于阈值上限</source>
        <translation type="unfinished">El umbral inferior es mayor que el umbral superior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="198"/>
        <source>y轴最大值需大于y轴最小值</source>
        <translation type="unfinished">El valor máximo en el eje y debe ser mayor que el valor mínimo en el eje y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="205"/>
        <source>曲线组名称不能为空!</source>
        <translation type="unfinished">¡El nombre del grupo de curvas no puede estar vacío!</translation>
    </message>
</context>
<context>
    <name>CMyMultipleYAxis</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="40"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="42"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>编号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>Y轴名称</source>
        <translation type="unfinished">Nombre del eje Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>Y轴颜色</source>
        <translation type="unfinished">Color del eje Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>最大值</source>
        <translation type="unfinished">Máximo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>最小值</source>
        <translation type="unfinished">Mínimo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>是否显示</source>
        <translation type="unfinished">Mostrar</translation>
    </message>
</context>
<context>
    <name>CmyStatisticalTable</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>最小值</source>
        <translation type="unfinished">Mínimo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>最大值</source>
        <translation type="unfinished">Máximo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>曲线名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>模拟量</source>
        <translation type="unfinished">Valor analógico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>平均值</source>
        <translation type="unfinished">Valor promedio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>最大值时刻</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>最小值时刻</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>起始时间</source>
        <translation type="unfinished">Hora de inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>终止时间</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ContextMenu</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="28"/>
        <source>编辑画面</source>
        <translation type="unfinished">Editar gráfica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="32"/>
        <source>另存为</source>
        <translation type="unfinished">Guardar como</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="33"/>
        <source>打开</source>
        <translation type="unfinished">Abrir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="38"/>
        <source>曲线详情</source>
        <translation type="unfinished">Detalles de la curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="47"/>
        <source>平滑曲线</source>
        <translation type="unfinished">Curva suave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="56"/>
        <source>绝对值曲线</source>
        <translation type="unfinished">Curva de valor absoluto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="66"/>
        <source>开启实时刷新</source>
        <translation type="unfinished">Habilitar actualización en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="74"/>
        <source>导出数据</source>
        <translation type="unfinished">Exportar datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="75"/>
        <source>刷新</source>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="76"/>
        <source>重置</source>
        <translation type="unfinished">Restablecer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="78"/>
        <source>查询</source>
        <translation type="unfinished">Consulta</translation>
    </message>
</context>
<context>
    <name>DlgIntervalTime</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="37"/>
        <source>设置日期</source>
        <comment>toolName</comment>
        <translation type="unfinished">Establecer Fecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="65"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="78"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="65"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="78"/>
        <source>日期选择错误，请重新选择</source>
        <translation type="unfinished">Error de selección de fecha, por favor seleccione de nuevo</translation>
    </message>
</context>
<context>
    <name>DlgQuery</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_query.cpp" line="23"/>
        <source>查询</source>
        <comment>toolName</comment>
        <translation type="unfinished">Consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_query.cpp" line="47"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_query.cpp" line="48"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Consulta</translation>
    </message>
</context>
<context>
    <name>DlgRelativeTime</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="69"/>
        <source>本日</source>
        <translation type="unfinished">Hoy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="70"/>
        <source>昨日</source>
        <translation type="unfinished">Ayer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="71"/>
        <source>明日</source>
        <translation type="unfinished">Mañana</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="72"/>
        <source>上周今日</source>
        <translation type="unfinished">Hoy de la semana pasada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="73"/>
        <source>上月今日</source>
        <translation type="unfinished">Este día del mes pasado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="74"/>
        <source>去年今日</source>
        <translation type="unfinished">Este día del año pasado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="80"/>
        <source>本月</source>
        <translation type="unfinished">Este mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="81"/>
        <source>上月</source>
        <translation type="unfinished">El mes pasado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="82"/>
        <source>下月</source>
        <translation type="unfinished">El próximo mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="83"/>
        <source>去年该月</source>
        <translation type="unfinished">Este mes del año pasado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="86"/>
        <source>月前</source>
        <translation type="unfinished">hace meses</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="91"/>
        <source>本年</source>
        <translation type="unfinished">Este año</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="92"/>
        <source>去年</source>
        <translation type="unfinished">El año pasado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="93"/>
        <source>下年</source>
        <translation type="unfinished">El próximo año</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="94"/>
        <source>去年该年</source>
        <translation type="unfinished">El año pasado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="98"/>
        <source>年前</source>
        <translation type="unfinished">hace años</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="68"/>
        <source>日曲线时间配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Config de Tiempo de Curva Diaria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="79"/>
        <source>月曲线时间配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Config de Tiempo de Curva Mensual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="90"/>
        <source>年曲线时间配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Config de Tiempo de Curva Anual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="102"/>
        <source>区间曲线时间配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Configuración de Tiempo de Curva de Intervalo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="103"/>
        <source>当前区间</source>
        <translation type="unfinished">Rango actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="104"/>
        <source>昨天该区间</source>
        <translation type="unfinished">Ayer, este rango</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="105"/>
        <source>明天该区间</source>
        <translation type="unfinished">Intervalo de mañana</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="106"/>
        <source>上周该区间</source>
        <translation type="unfinished">La semana pasada, este rango</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="107"/>
        <source>上月该区间</source>
        <translation type="unfinished">El mes pasado, este rango</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="108"/>
        <source>去年该区间</source>
        <translation type="unfinished">El año pasado, este rango</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="128"/>
        <source>请输入数字（范围1～365）</source>
        <translation type="unfinished">Ingrese un número (rango 1~365)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="149"/>
        <source>请输入数字（范围1～99）</source>
        <translation type="unfinished">Ingrese un número (rango 1~99)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="170"/>
        <source>请输入数字（范围1～9）</source>
        <translation type="unfinished">Por favor ingrese un número (rango 1~9)</translation>
    </message>
</context>
<context>
    <name>PrinterHandle</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/printer_handle.cpp" line="73"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/printer_handle.cpp" line="77"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/printer_handle.cpp" line="73"/>
        <source>曲线打印失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/printer_handle.cpp" line="77"/>
        <source>曲线打印成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/printer_handle.cpp" line="83"/>
        <source>打印错误</source>
        <translation type="unfinished">Error de impresión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/printer_handle.cpp" line="83"/>
        <source>无法找到打印机</source>
        <translation type="unfinished">No se puede encontrar la impresora</translation>
    </message>
</context>
<context>
    <name>XMLFileHandle</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="22"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="22"/>
        <source>文件打开或创建失败</source>
        <translation type="unfinished">Falló la apertura o creación del archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="25"/>
        <source>文件保存中</source>
        <translation type="unfinished">Guardando archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="96"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="96"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado exitosamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="665"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="670"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="676"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="684"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="708"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="665"/>
        <source>文件不存在</source>
        <translation type="unfinished">Archivo no encontrado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="670"/>
        <source>文件打开失败</source>
        <translation type="unfinished">Falló la apertura del archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="676"/>
        <source>操作的文件不是XML格式</source>
        <translation type="unfinished">El archivo para la operación no está en formato XML</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="684"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="708"/>
        <source>曲线文件格式无效</source>
        <translation type="unfinished">Formato de archivo de curva inválido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="713"/>
        <source>曲线文件读取中</source>
        <translation type="unfinished">Lectura de archivo de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="713"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>dlg_interval_time</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.ui" line="22"/>
        <source>开始时间：</source>
        <translation type="unfinished">Hora de inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.ui" line="36"/>
        <source>结束时间：</source>
        <translation type="unfinished">Hora de Finalización:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.ui" line="63"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.ui" line="70"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>dlg_relative_time</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="22"/>
        <source>今天</source>
        <translation type="unfinished">Hoy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="29"/>
        <source>昨天</source>
        <translation type="unfinished">Ayer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="36"/>
        <source>明天</source>
        <translation type="unfinished">mañana</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="47"/>
        <source>上周今天</source>
        <translation type="unfinished">Hoy de la semana pasada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="54"/>
        <source>上月今天</source>
        <translation type="unfinished">Hoy del mes pasado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="61"/>
        <source>去年今天</source>
        <translation type="unfinished">Hoy del año pasado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="72"/>
        <source>自定义</source>
        <translation type="unfinished">Personalizado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="82"/>
        <source>天前</source>
        <translation type="unfinished">hace días</translation>
    </message>
</context>
</TS>
