<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>GraphicAppImp</name>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="69"/>
        <source>接地</source>
        <translation type="unfinished">Grounding</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="70"/>
        <source>无效</source>
        <translation type="unfinished">Invalid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="849"/>
        <source>传入画面信息为空</source>
        <translation type="unfinished">Importing graph info is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="870"/>
        <source>传入的所有画面光字信息均为空</source>
        <translation type="unfinished">All imported graph annunciator info is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="878"/>
        <source>传入的画面[%1]光字信息为空</source>
        <translation type="unfinished">Importing graph [%1] annunciator info is empty</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="41"/>
        <source>测试应用通用接口插件集合</source>
        <translation type="unfinished">Test application common interface plug-in collection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="232"/>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="239"/>
        <source>牌的相对坐标 x=%1,y=%2,width=%3,height=%4</source>
        <translation type="unfinished">Relative coordinates of cards x=%1,y=%2,width=%3,height=%4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="238"/>
        <source>牌信息</source>
        <translation type="unfinished">Card info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="250"/>
        <source>类型</source>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="251"/>
        <source>厂站名</source>
        <translation type="unfinished">Station name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="322"/>
        <source>测试设备对象</source>
        <translation type="unfinished">Test equipment object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="326"/>
        <source>测试数值前景对象</source>
        <translation type="unfinished">Testing value foreground object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="330"/>
        <source>测试状态前景对象</source>
        <translation type="unfinished">Test state foreground object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="334"/>
        <source>测试字符前景对象</source>
        <translation type="unfinished">Test character foreground object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="338"/>
        <source>测试光敏点前景对象</source>
        <translation type="unfinished">Test photosensitive point foreground object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="342"/>
        <source>测试未定义类型对象</source>
        <translation type="unfinished">Testing for undefined type objects</translation>
    </message>
</context>
</TS>
