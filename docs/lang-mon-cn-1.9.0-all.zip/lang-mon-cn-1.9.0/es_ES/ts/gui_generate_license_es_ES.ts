<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>DlgGenerateLicense</name>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="27"/>
        <source>请输入产品名称</source>
        <translation type="unfinished">Por favor, ingrese el nombre del producto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="31"/>
        <source>请输入客户名称</source>
        <translation type="unfinished">Por favor, ingrese el nombre del cliente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="35"/>
        <source>请输入版本号</source>
        <translation type="unfinished">Por favor ingrese el número de versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="69"/>
        <source>必填信息为空!</source>
        <translation type="unfinished">¡La información requerida está vacía!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="84"/>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="101"/>
        <source>内容为空!</source>
        <translation type="unfinished">¡El contenido está vacío!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="92"/>
        <source>已将 license 复制到剪贴板!</source>
        <translation type="unfinished">¡Licencia copiada al portapapeles!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="108"/>
        <source>Save File</source>
        <translation type="unfinished">Guardar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="108"/>
        <source>Text Files (*.txt)</source>
        <translation type="unfinished">Archivos de texto (*.txt)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="115"/>
        <source>打开文件失败!</source>
        <translation type="unfinished">¡Fallo al abrir archivo!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="122"/>
        <source>已将 license 导出到 %1</source>
        <translation type="unfinished">Licencia exportada a %1</translation>
    </message>
</context>
<context>
    <name>dlg_generate_license</name>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="43"/>
        <source>信息配置区</source>
        <translation type="unfinished">Área de configuración de información</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="81"/>
        <source>有效期(天)：</source>
        <translation type="unfinished">Validez (días):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="67"/>
        <source>产品名称：</source>
        <translation type="unfinished">Nombre del producto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="51"/>
        <source>版本号：</source>
        <translation type="unfinished">Número de versión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="74"/>
        <source>客户名称：</source>
        <translation type="unfinished">Nombre del cliente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="114"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="127"/>
        <source>生成</source>
        <translation type="unfinished">Generar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="139"/>
        <source>生成结果</source>
        <translation type="unfinished">Generar resultados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="169"/>
        <source>复制注册码</source>
        <translation type="unfinished">Copiar el código de registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="182"/>
        <source>导出注册码</source>
        <translation type="unfinished">Exportar código de registro</translation>
    </message>
</context>
</TS>
