<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>ConfigParam</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="55"/>
        <source>密码复杂度：</source>
        <translation type="unfinished">Complejidad de la contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="70"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="1055"/>
        <source>低（无特殊限制）</source>
        <translation type="unfinished">Baja (sin restricciones especiales)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="75"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="1056"/>
        <source>中（6位以上，必须包含数字、大小写字母）</source>
        <translation type="unfinished">Media (más de 6 caracteres, debe contener números, letras mayúsculas y minúsculas)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="80"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="1058"/>
        <source>高（8位以上，必须包含数字、大小写字母、特殊字符，且不包含用户名）</source>
        <translation type="unfinished">Alta (más de 8 caracteres, debe contener números, letras mayúsculas y minúsculas, caracteres especiales y no incluir el nombre de usuario)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="114"/>
        <source>密码有效期（天）：</source>
        <translation type="unfinished">	Durac. Contrs.:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="128"/>
        <source>历史密码个数：</source>
        <translation type="unfinished">Cantidad de contraseñas históricas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="142"/>
        <source>错误密码重试次数：</source>
        <translation type="unfinished">Reintentos incorrectos de contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="156"/>
        <source>用户锁定时长（秒）：</source>
        <translation type="unfinished">Duración del bloqueo del usuario (s):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="279"/>
        <source>密码加密存储</source>
        <translation type="unfinished">Almacenamiento criptográfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="293"/>
        <source>隐藏登录用户名</source>
        <translation type="unfinished">Ocultar el nombre de usuario de inicio de sesión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="307"/>
        <source>强制修改初始密码</source>
        <translation type="unfinished">Cambiar la contraseña inicial forzosamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="321"/>
        <source>强制修改过期密码</source>
        <translation type="unfinished">Cambio forzado de contraseña expirada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="40"/>
        <source>密码配置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Contraseña de config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="168"/>
        <source>闲置锁定时长（秒）：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="351"/>
        <source>认证配置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Configuración de autenticación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="366"/>
        <source>节点认证方式：</source>
        <translation type="unfinished">Modo de autenticación de nodo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="378"/>
        <source>登录认证方式：</source>
        <translation type="unfinished">Modo de autenticación de inicio de sesión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="395"/>
        <source>白名单</source>
        <translation type="unfinished">Lista blanca</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="400"/>
        <source>黑名单</source>
        <translation type="unfinished">Listas negras</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="414"/>
        <source>用户名+密码</source>
        <translation type="unfinished">Nombre de usuario + Contraseña</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="419"/>
        <source>用户名+密码+UKEY</source>
        <translation type="unfinished">Nombre de Usuario + Contraseña + UKEY</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="424"/>
        <source>用户名+密码+指纹</source>
        <translation type="unfinished">Nombre de Usuario + Contraseña + Huella digital</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="456"/>
        <source>启用安全身份认证</source>
        <translation type="unfinished">Habilitar autenticación segura</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="468"/>
        <source>启用认证白名单</source>
        <translation type="unfinished">Habilitar lista blanca de autenticación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="489"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="511"/>
        <source>调试配置</source>
        <translation type="unfinished">Configuración de depuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="503"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="525"/>
        <source>工程配置</source>
        <translation type="unfinished">Configuración del proyecto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="518"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="539"/>
        <source>安全配置</source>
        <translation type="unfinished">Configuración de seguridad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="534"/>
        <source>版本</source>
        <translation type="unfinished">Versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="561"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="575"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="587"/>
        <source>启用内部安全通讯</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="386"/>
        <source>本模式节点认证方式需设置为：白名单</source>
        <translation type="unfinished">En este modo, el modo de autenticación de nodo debe ser lista blanca</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="391"/>
        <source>本模式节点认证方式需设置为：黑名单</source>
        <translation type="unfinished">El método de autenticación de nodo en este modo debe configurarse como: lista negra</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="432"/>
        <source>本模式登录认证需设置为：仅密码</source>
        <translation type="unfinished">La autenticación de inicio de sesión para este modo necesita configurarse en: Solo contraseña</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="437"/>
        <source>本模式登录认证需设置为：Ukey或指纹认证</source>
        <translation type="unfinished">La autenticación de inicio de sesión para este modo necesita configurarse en: Autenticación Ukey o huella dactilar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="401"/>
        <source>本模式密码复杂度需设置为：低</source>
        <translation type="unfinished">La complejidad de la contraseña en este modo necesita configurarse en: bajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="406"/>
        <source>本模式密码复杂度需设置为：中</source>
        <translation type="unfinished">La complejidad de la contraseña en este modo necesita configurarse en: Media</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="411"/>
        <source>本模式密码复杂度需设置为：高</source>
        <translation type="unfinished">La complejidad de la contraseña en este modo necesita configurarse en: Alto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="416"/>
        <source>本模式密码复杂度需设置为：低或中</source>
        <translation type="unfinished">La complejidad de la contraseña en este modo necesita configurarse en: baja o media</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="421"/>
        <source>本模式密码复杂度需设置为：低或高</source>
        <translation type="unfinished">La complejidad de la contraseña en este modo necesita configurarse en: baja o alta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="426"/>
        <source>本模式密码复杂度需设置为：中或高</source>
        <translation type="unfinished">La complejidad de la contraseña en este modo necesita configurarse en: Media o Alta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="445"/>
        <source>本模式密码有效天数范围: </source>
        <translation type="unfinished">El período de validez de la contraseña para este modo es:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="454"/>
        <source>本模式设置历史密码保存数量: </source>
        <translation type="unfinished">Modo establece núm. de contraseñas guardadas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="463"/>
        <source>本模式错误密码重试次数范围: </source>
        <translation type="unfinished">El rango de reintentos incorrectos de contraseña en este modo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="472"/>
        <source>本模式用户锁定时长范围: </source>
        <translation type="unfinished">El rango de tiempo de bloqueo del usuario para este modo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="478"/>
        <source>本模式需: 启用密码加密功能</source>
        <translation type="unfinished">Este modo requiere: Habilitar cifrado de contraseña</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="482"/>
        <source>本模式需: 启用隐藏登录用户名功能</source>
        <translation type="unfinished">Este modo requiere: Habilitar la función de ocultar el nombre de usuario de inicio de sesión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="486"/>
        <source>本模式需: 启用强制修改初始密码功能</source>
        <translation type="unfinished">Este modo requiere: Habilitar la función de modificación forzada de la contraseña inicial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="490"/>
        <source>本模式需: 启用强制修改过期密码功能</source>
        <translation type="unfinished">Este modo requiere: Habilitar modificación forzada de contraseñas vencidas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="494"/>
        <source>本模式需: 启用认证白名单功能功能</source>
        <translation type="unfinished">En este modo, la función de lista blanca de autenticación debe estar habilitada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="498"/>
        <source>本模式需: 启用安全身份认证功能</source>
        <translation type="unfinished">Este modo requiere: Habilitar función de autenticación de identidad segura</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="582"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="617"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="652"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="674"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="692"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="713"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="583"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="693"/>
        <source>数据库模板名称与配置文件名称不一致或找不到配置名称为：调试配置、工程配置、安全配置的参数</source>
        <translation type="unfinished">El nombre de la plantilla de base de datos no coincide con el nombre del archivo de configuración o no se puede encontrar el nombre de la configuración: Configuración de depuración, Configuración de ingeniería, Configuración de seguridad de parámetros</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="609"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="614"/>
        <source>检测到当前设置为：</source>
        <translation type="unfinished">Se detectó la configuración actual como:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="610"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="615"/>
        <source> 存在以下设置不符合要求：</source>
        <translation type="unfinished">La siguiente configuración no cumple con los requisitos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="652"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="675"/>
        <source>安全身份认证已启用，请确保系统管理中已配置了认证服务， 并且用户已设置了认证信息</source>
        <translation type="unfinished">La autenticación segura está habilitada. Asegúrese de que el servicio de autenticación esté configurado en administración del sistema y que el usuario haya configurado la información de autenticación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="713"/>
        <source>刷新成功</source>
        <translation type="unfinished">Actualización exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="822"/>
        <source>调试配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Config de depuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="823"/>
        <source>工程配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Config del proyecto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="824"/>
        <source>安全配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Config de seguridad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="920"/>
        <source>切换当前安全配置模式为：</source>
        <translation type="unfinished">Cambiar modo de seguridad:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="920"/>
        <source>保存后将重置相关配置，请确认后继续。</source>
        <translation type="unfinished">Después de guardar, la configuración relevante se restablecerá. Por favor confirme y continúe.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="1049"/>
        <source>8位以上，必须包含数字、大小写字母、特殊字符，且不包含用户名</source>
        <translation type="unfinished">Más de 8 caracteres, debe contener números, letras mayúsculas y minúsculas, caracteres especiales y no debe contener el nombre de usuario</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/plugin_sec_usermgr.cpp" line="45"/>
        <source>用户管理参数配置</source>
        <translation type="unfinished">Configuración de parámetros de gestión de usuarios</translation>
    </message>
</context>
</TS>
