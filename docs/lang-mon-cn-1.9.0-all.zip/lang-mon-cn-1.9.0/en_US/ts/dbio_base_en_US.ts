<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>dbChildObjectDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1476"/>
        <source>关联信息</source>
        <comment>toolName</comment>
        <translation type="unfinished">Related Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1488"/>
        <source>父对象信息</source>
        <translation type="unfinished">Parent object info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1496"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1497"/>
        <source>子对象ID</source>
        <translation type="unfinished">Child object ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1498"/>
        <source>子对象名称</source>
        <translation type="unfinished">Subobject name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1506"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1509"/>
        <source>添加关联</source>
        <translation type="unfinished">Add link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1510"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1513"/>
        <source>删除关联</source>
        <translation type="unfinished">Delete link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1514"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1516"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1517"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1519"/>
        <source>退出</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1544"/>
        <source>父对象:</source>
        <translation type="unfinished">Parent object:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1635"/>
        <source>重复项</source>
        <translation type="unfinished">Duplicates</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1635"/>
        <source>已存在相同的对象，%1无需重复添加。</source>
        <translation type="unfinished">The same object already exists.%1No need to add it again.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1653"/>
        <source>删除失败</source>
        <translation type="unfinished">Deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1653"/>
        <source>请先选择一行进行删除！</source>
        <translation type="unfinished">Please select a row to delete first!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1681"/>
        <source>错误信息</source>
        <translation type="unfinished">Error message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1682"/>
        <source>建立关联关系失败</source>
        <translation type="unfinished">Failed to establish link relationship</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1687"/>
        <source>信息</source>
        <translation type="unfinished">Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1687"/>
        <source>关联成功！</source>
        <translation type="unfinished">Linked successfully!</translation>
    </message>
</context>
<context>
    <name>dbDataAccessBase</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="924"/>
        <source>信息提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="924"/>
        <source>循环子表不支持查询</source>
        <translation type="unfinished">Circular subtables do not support queries</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="928"/>
        <source>错误信息</source>
        <translation type="unfinished">Error message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="929"/>
        <source>获取对象失败</source>
        <translation type="unfinished">Failed to retrieve object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="1567"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="1807"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="2116"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="2289"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="1570"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="1810"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="2119"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="2292"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="1596"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_virtual.cpp" line="2976"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="1681"/>
        <source>用户{%1} 删除应用【{%2}.{%3}.{%4}】{%5}【{%6}】对象【{%7}】失败,原因：{%8}</source>
        <translation type="unfinished">User {%1} failed to delete application {%2}.{%3}.{%4}} {%5} {%6}} object {%7}, reason: {%8}</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="1705"/>
        <source>用户{%1} 删除应用【{%2}.{%3}.{%4}】{%5}【{%6}】对象【{%7}】</source>
        <translation type="unfinished">User {%1} deleted the application {%2}.{%3}.{%4}} {%5} {%6}} object {%7}</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="1905"/>
        <source>用户{%1} 应用【{%2}.{%3}.{%4}】{%5}【{%6}】insertSymbChildObjects，父表OID【{%7}】子表ID【{%8}】插入{%9}个子对象</source>
        <translation type="unfinished">User {%1} App {%2}.{%3}.{%4}} {%5} {%6} insertSymbChildObjects, parent table OID {%7} child table ID {%8}} inserted {%9} child objects</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="1923"/>
        <source>用户{%1} 应用【{%2}.{%3}.{%4}】{%5}【{%6}】insertObjects，表ID【{%7}】插入{%8}个子对象</source>
        <translation type="unfinished">User {%1} App {%2}.{%3}.{%4}} {%5} {%6} insertObjects, table ID {%7} inserted {%8} child objects</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="1943"/>
        <source>用户{%1} 应用【{%2}.{%3}.{%4}】{%5}【{%6}】表【{%7}】插入{%8}个子对象失败,原因:{%9}</source>
        <translation type="unfinished">User {%1} App {%2}.{%3}.{%4}} {%5} {%6}] table {%7} failed to insert {%8} child objects, reason: {%9}</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="1961"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="2066"/>
        <source>用户{%1} 应用【{%2}.{%3}.{%4}】{%5}【{%6}】根据父{%7}插入{%8}个子对象</source>
        <translation type="unfinished">User {%1} App {%2}.{%3}.{%4}} {%5} {%6}} , based on parent {%7} ,inserted {%8} child objects </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="2264"/>
        <source>用户{%1} 应用【{%2}.{%3}.{%4}】{%5}【{%6}】更新{%7}个对象成功</source>
        <translation type="unfinished">User {%1} App {%2}.{%3}.{%4}} {%5} {%6}] updated {%7} objects successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_func.cpp" line="2559"/>
        <source>用户{%1} 应用【{%2}.{%3}.{%4}】{%5}【{%6}】更新{%7}对象成功</source>
        <translation type="unfinished">User {%1} App {%2}.{%3}.{%4}} {%5} {%6}] updated {%7} object successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_virtual.cpp" line="259"/>
        <source>复原</source>
        <translation type="unfinished">Recover</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_virtual.cpp" line="436"/>
        <source>单表</source>
        <translation type="unfinished">Single table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_virtual.cpp" line="440"/>
        <source>层次表</source>
        <translation type="unfinished">Hierarchy table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_virtual.cpp" line="444"/>
        <source>所有表</source>
        <translation type="unfinished">All</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_virtual.cpp" line="594"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_virtual.cpp" line="594"/>
        <source>连接有误，查询元数据失败%1，需退出工具，重新打开</source>
        <translation type="unfinished">Connection error, query metadata failed %1, Need to exit the tool and reopen it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_virtual.cpp" line="1745"/>
        <source>错误提示信息</source>
        <translation type="unfinished">Error message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_virtual.cpp" line="1746"/>
        <source>获取关联OID失败</source>
        <translation type="unfinished">Failed to retrieve linked OID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_virtual.cpp" line="2099"/>
        <source>未定义</source>
        <translation type="unfinished">Undefined</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_data_base_virtual.cpp" line="2976"/>
        <source>超出字符长度</source>
        <translation type="unfinished">Exceeded character length</translation>
    </message>
</context>
<context>
    <name>dbDeleteDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="465"/>
        <source>清除关系</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Clear link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="467"/>
        <source>清除关系</source>
        <translation type="unfinished">Clear Link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="472"/>
        <source>删除对象</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete obj</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="474"/>
        <source>删除对象</source>
        <translation type="unfinished">Delete Object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="483"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="486"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="491"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="494"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="521"/>
        <source>删除所选对象?</source>
        <translation type="unfinished">Delete the selected object?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="523"/>
        <source>删除所有当前对象?</source>
        <translation type="unfinished">Delete all current objects?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="532"/>
        <source>删除对象/清除对象关系?</source>
        <translation type="unfinished">Delete objects/Clear object relationships?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="534"/>
        <source>确认针对当前所有对象?删除对象/清除对象关系?</source>
        <translation type="unfinished">Confirm for all current objects? Delete object/clear object link?</translation>
    </message>
</context>
<context>
    <name>dbInsertDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="169"/>
        <source>上层</source>
        <translation type="unfinished">Upper layer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="178"/>
        <source>参照</source>
        <translation type="unfinished">Refer to</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="187"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="202"/>
        <source>数目</source>
        <translation type="unfinished">Number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="219"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="222"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="226"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="229"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="261"/>
        <source>请输入插入参数 [</source>
        <translation type="unfinished">Please enter insert params [</translation>
    </message>
</context>
<context>
    <name>dbLoginDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1124"/>
        <source>用户名称</source>
        <translation type="unfinished">Username</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1130"/>
        <source>用户密码</source>
        <translation type="unfinished">User Password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1137"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1146"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1138"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1150"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>dbMultAppDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="60"/>
        <source>选择</source>
        <translation type="unfinished">Select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="74"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="77"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="82"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="85"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>dbNormalTableView</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="133"/>
        <source>路径</source>
        <translation type="unfinished">Path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="167"/>
        <source>清除本行本列关联</source>
        <translation type="unfinished">Clear the link of this row and column</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="173"/>
        <source>清除整列关联</source>
        <translation type="unfinished">Clear entire column link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="177"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="239"/>
        <source>恢复</source>
        <translation type="unfinished">Recover</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="181"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="244"/>
        <source>隐藏</source>
        <translation type="unfinished">Hide</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="185"/>
        <source>查找</source>
        <translation type="unfinished">Find</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="189"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="246"/>
        <source>升序</source>
        <translation type="unfinished">Ascending</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="193"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="251"/>
        <source>降序</source>
        <translation type="unfinished">Descending order</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="199"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="258"/>
        <source>设置值</source>
        <translation type="unfinished">Set value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="203"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="259"/>
        <source>设置空值</source>
        <translation type="unfinished">Set null</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="207"/>
        <source>部分替换</source>
        <translation type="unfinished">Partial replacement</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="211"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="265"/>
        <source>展开-收缩</source>
        <translation type="unfinished">Expand-Collapse</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="215"/>
        <source>导入</source>
        <translation type="unfinished">Import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="218"/>
        <source>导出</source>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="222"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="272"/>
        <source>输出Excel</source>
        <translation type="unfinished">Export Excel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="225"/>
        <source>上移</source>
        <translation type="unfinished">Move up</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="228"/>
        <source>下移</source>
        <translation type="unfinished">Move down</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="231"/>
        <source>移动至</source>
        <translation type="unfinished">Move to</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="234"/>
        <source>更新父对象</source>
        <translation type="unfinished">Update parent object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="245"/>
        <source>过滤</source>
        <translation type="unfinished">Filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="260"/>
        <source>局部替换</source>
        <translation type="unfinished">Partial Replacement</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="1464"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="1469"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="1500"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="1600"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="1617"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="1636"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1147"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1757"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="1464"/>
        <source>关联前，先保存对象</source>
        <translation type="unfinished">Save the object before linking</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="1469"/>
        <source>当前OID有误</source>
        <translation type="unfinished">The current OID is incorrect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="1500"/>
        <source>上限为10个关联窗口</source>
        <translation type="unfinished">The maximum number of linked Windows is 10</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="1615"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="1634"/>
        <source>打开失败:应用</source>
        <translation type="unfinished">Open failed: App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="1615"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="1634"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2137"/>
        <source>属性</source>
        <translation type="unfinished">Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2143"/>
        <source>索引数据区</source>
        <translation type="unfinished">Index Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2156"/>
        <source>维护数据区</source>
        <translation type="unfinished">Maintain Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2169"/>
        <source>同步数据区</source>
        <translation type="unfinished">Sync Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2189"/>
        <source>本地数据区</source>
        <translation type="unfinished">Local Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2146"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2159"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2174"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2194"/>
        <source>装库</source>
        <translation type="unfinished">Load DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="1599"/>
        <source>跨库关系:未配置元数据信息</source>
        <translation type="unfinished">Cross-db relationship: Metadata info is not configured</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="1599"/>
        <source>检索信息失败</source>
        <translation type="unfinished">Failed to retrieve info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2150"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2163"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2178"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2183"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2198"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2203"/>
        <source>非装库</source>
        <translation type="unfinished">Non-Load DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2208"/>
        <source>未设置区</source>
        <translation type="unfinished">Non-setted area</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_func.cpp" line="543"/>
        <source>[非单表]:[%1]</source>
        <translation type="unfinished">[Non-single table]:[%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_func.cpp" line="549"/>
        <source>离散</source>
        <translation type="unfinished">Scatter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_func.cpp" line="550"/>
        <source>连续</source>
        <translation type="unfinished">Continuous</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_func.cpp" line="551"/>
        <source>循环</source>
        <translation type="unfinished">Loop</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_func.cpp" line="552"/>
        <source>循环子表</source>
        <translation type="unfinished">Loop subtable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_func.cpp" line="553"/>
        <source>历史</source>
        <translation type="unfinished">History</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1116"/>
        <source>选择文件</source>
        <translation type="unfinished">Select file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1116"/>
        <source>导入配置文件%1</source>
        <translation type="unfinished">Import config file %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1127"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1161"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1209"/>
        <source>错误信息</source>
        <translation type="unfinished">Error message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1128"/>
        <source>导入数据失败！</source>
        <translation type="unfinished">Failed to import data!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1162"/>
        <source>导出表数据失败！无任何表信息</source>
        <translation type="unfinished">Exporting table data failed! No table information available</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1184"/>
        <source>导出中......请等待</source>
        <translation type="unfinished">Exporting... Please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1207"/>
        <source>子表不允许单独导出</source>
        <translation type="unfinished">Sub-tables cannot be exported separately</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1550"/>
        <source>移动至</source>
        <comment>toolName</comment>
        <translation type="unfinished">Move To</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1550"/>
        <source>目标行:</source>
        <translation type="unfinished">Target line:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1757"/>
        <source>无可移动的父对象</source>
        <translation type="unfinished">No movable parent object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1134"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1214"/>
        <source>通知</source>
        <translation type="unfinished">Notification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1134"/>
        <source>导入成功！</source>
        <translation type="unfinished">Import successful!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1147"/>
        <source>请先保存数据！</source>
        <translation type="unfinished">Please save the data first!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1153"/>
        <source>保存文件</source>
        <translation type="unfinished">Save file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view_slot.cpp" line="1214"/>
        <source>导出成功！</source>
        <translation type="unfinished">Export successful!</translation>
    </message>
</context>
<context>
    <name>dbOutputFileDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="716"/>
        <source>导出文件名称</source>
        <translation type="unfinished">Export file name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="730"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="733"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="738"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="741"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>dbPartReplaceDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="919"/>
        <source>原始值</source>
        <translation type="unfinished">Original value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="925"/>
        <source>替换值</source>
        <translation type="unfinished">Replace value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="931"/>
        <source>仅设置选择对象</source>
        <translation type="unfinished">Set only selected objects</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="941"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="944"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="949"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="952"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>dbProgressDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1047"/>
        <source>执行进度</source>
        <translation type="unfinished">Execution schedule</translation>
    </message>
</context>
<context>
    <name>dbQueryRelateObjDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="2054"/>
        <source>对象信息</source>
        <translation type="unfinished">Object info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="2060"/>
        <source>查询对象</source>
        <comment>toolName</comment>
        <translation type="unfinished">Query Object</translation>
    </message>
</context>
<context>
    <name>dbSFilterDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="576"/>
        <source>信息检索</source>
        <comment>toolName</comment>
        <translation type="unfinished">Info Retrieval</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="601"/>
        <source>选择检索列</source>
        <translation type="unfinished">Select search column</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="608"/>
        <source>匹配字符串</source>
        <translation type="unfinished">Match string</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="622"/>
        <source>检索</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Retrieve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="624"/>
        <source>检索</source>
        <translation type="unfinished">Retrieve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="627"/>
        <source>下一个</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Next</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="633"/>
        <source>退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="635"/>
        <source>退出</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="652"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="652"/>
        <source>异常输入，请重新输入</source>
        <translation type="unfinished">Invalid input; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="629"/>
        <source>下一个</source>
        <translation type="unfinished">Next</translation>
    </message>
</context>
<context>
    <name>dbSaveToDBDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1002"/>
        <source>进度</source>
        <translation type="unfinished">Progress</translation>
    </message>
</context>
<context>
    <name>dbSearcherDialog</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_dialog.cpp" line="60"/>
        <source>数据库检索器</source>
        <translation type="unfinished">DB retriever</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_dialog.cpp" line="80"/>
        <source>清除</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_dialog.cpp" line="90"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_dialog.cpp" line="93"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_dialog_slot.cpp" line="44"/>
        <source>检索器信息不完整</source>
        <translation type="unfinished">Retriever info is incomplete</translation>
    </message>
</context>
<context>
    <name>dbSearcherWidget</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_base.cpp" line="203"/>
        <source>未选择对象</source>
        <translation type="unfinished">Unselected object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_base.cpp" line="215"/>
        <source>未选择属性</source>
        <translation type="unfinished">No attrs have been selected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_base_func.cpp" line="74"/>
        <source>检索对象</source>
        <translation type="unfinished">Retrieval object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_base_func.cpp" line="75"/>
        <source>检索实时列</source>
        <translation type="unfinished">Search real-time column</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_base_func.cpp" line="76"/>
        <source>检索历史列</source>
        <translation type="unfinished">Search history column</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_base_func.cpp" line="242"/>
        <source>清空</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_base_func.cpp" line="102"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_base_func.cpp" line="262"/>
        <source>上层对象</source>
        <translation type="unfinished">Upper object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_base_func.cpp" line="85"/>
        <source>清空</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_base_func.cpp" line="114"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_base_func.cpp" line="275"/>
        <source>选择对象</source>
        <translation type="unfinished">Select object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_base_func.cpp" line="125"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_base_func.cpp" line="286"/>
        <source>选择属性</source>
        <translation type="unfinished">Select attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_base_func.cpp" line="832"/>
        <source>数据库检索器</source>
        <translation type="unfinished">DB retriever</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/db_search_widget_base_func.cpp" line="838"/>
        <source>运行库--</source>
        <translation type="unfinished">RTDB --</translation>
    </message>
</context>
<context>
    <name>dbSelectFileDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1243"/>
        <source>默认文件</source>
        <translation type="unfinished">Default file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1247"/>
        <source>指定文件</source>
        <translation type="unfinished">Specifying files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1252"/>
        <source>导入厂站模型</source>
        <translation type="unfinished">Import plant model</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1287"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1296"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1288"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1299"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1320"/>
        <source>默认文件:</source>
        <translation type="unfinished">Default file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="1399"/>
        <source>选择文件</source>
        <translation type="unfinished">Select file</translation>
    </message>
</context>
<context>
    <name>dbSetValueDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="796"/>
        <source>本列设置值</source>
        <translation type="unfinished">This column sets the value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="800"/>
        <source>设置递增值</source>
        <translation type="unfinished">Set increasing value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="806"/>
        <source>仅设置选择对象</source>
        <translation type="unfinished">Set only selected objects</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="816"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="819"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="824"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="827"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>dbTreeObjItemMoveDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="2127"/>
        <source>父对象：</source>
        <translation type="unfinished">Parent object:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="2128"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="2128"/>
        <source>退出</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_com_dlg.cpp" line="2130"/>
        <source>更新父对象</source>
        <comment>toolName</comment>
        <translation type="unfinished">Update Parent Object</translation>
    </message>
</context>
<context>
    <name>dbWidgetSpecialBase</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_widget_base_virtual.cpp" line="114"/>
        <source>信息</source>
        <translation type="unfinished">Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_widget_base_virtual.cpp" line="114"/>
        <source>表对象不存在,请先选中任意表</source>
        <translation type="unfinished">The table object does not exist. Please select any table first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_widget_base_virtual.cpp" line="139"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_widget_base_virtual.cpp" line="481"/>
        <source>错误信息</source>
        <translation type="unfinished">Error message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_widget_base_virtual.cpp" line="139"/>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_widget_base_virtual.cpp" line="481"/>
        <source>未发现父对象,请先定义父对象!</source>
        <translation type="unfinished">The parent object was not found, please define the parent object first!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_widget_base_virtual.cpp" line="339"/>
        <source>删除警告</source>
        <translation type="unfinished">Delete warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_widget_base_virtual.cpp" line="341"/>
        <source>删除选择对象?</source>
        <translation type="unfinished">Delete selection?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_widget_base_virtual.cpp" line="343"/>
        <source>删除所有当前对象?</source>
        <translation type="unfinished">Delete all current objects?</translation>
    </message>
</context>
<context>
    <name>mtObjListView</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_base_def.cpp" line="603"/>
        <source>移动</source>
        <translation type="unfinished">move</translation>
    </message>
</context>
<context>
    <name>singleTableWorker</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/dbio_base/source/dbio_table_view.cpp" line="2429"/>
        <source>导出失败</source>
        <translation type="unfinished">Export failed</translation>
    </message>
</context>
</TS>
