<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CSecPri</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="297"/>
        <source>用户登录超时</source>
        <translation type="unfinished">Tiempo de sesión de usuario agotado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="300"/>
        <source>长时间未操作，请重新登录</source>
        <translation type="unfinished">Sin operación por mucho tiempo, reingrese</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="302"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
</context>
<context>
    <name>QMyFrameEditStatus</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="111"/>
        <source>编辑</source>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="112"/>
        <source>浏览</source>
        <translation type="unfinished">Examinar</translation>
    </message>
</context>
<context>
    <name>QMyFrameRadio</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="167"/>
        <source>待输入</source>
        <translation type="unfinished">Esperando entrada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="169"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="170"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
</context>
<context>
    <name>QMyFrameSearch</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="143"/>
        <source>请输入关键字</source>
        <translation type="unfinished">Ingrese palabras clave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="145"/>
        <source>搜索</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Buscar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="150"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="151"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/base_item.cpp" line="152"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/main.cpp" line="196"/>
        <source>网络注册失败</source>
        <translation type="unfinished">Fallo al registrar en red</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/main.cpp" line="208"/>
        <source>本地系统已启动</source>
        <translation type="unfinished">Sistema local iniciado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/main.cpp" line="246"/>
        <source>远程网络注册失败</source>
        <translation type="unfinished">Registro de red remota falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/main.cpp" line="197"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/main.cpp" line="247"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/main.cpp" line="209"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/main.cpp" line="381"/>
        <source>登录时限：</source>
        <translation type="unfinished">Límite de tiempo de inicio de sesión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="228"/>
        <source>权限管理工具</source>
        <comment>toolName</comment>
        <translation type="unfinished">Administrador de Permisos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="228"/>
        <source>节点名</source>
        <comment>toolName</comment>
        <translation type="unfinished">Nombre del Nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="875"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1026"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1125"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1444"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1544"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1923"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2042"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="389"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="923"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1055"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1001"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1265"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3003"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="212"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="428"/>
        <source>%1输入异常字符，可能存在篡改、恶意攻击行为</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>addMgr</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2922"/>
        <source>上级组织：</source>
        <translation type="unfinished">Organización principal:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2923"/>
        <source>组织名称：</source>
        <translation type="unfinished">Nombre de la organización:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2953"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2962"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2978"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2985"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2992"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3020"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3032"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3041"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3052"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2953"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2962"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2978"/>
        <source>读取失败，请检查数据库服务</source>
        <translation type="unfinished">Fallo al leer, verifique servicio BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3032"/>
        <source>组织名称已存在</source>
        <translation type="unfinished">Nombre de organización ya existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3020"/>
        <source>保存失败，请检查数据库服务</source>
        <translation type="unfinished">Fallo al guardar, verifique BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2911"/>
        <source>新增组织</source>
        <comment>toolName</comment>
        <translation type="unfinished">Agregar Organizaciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2947"/>
        <source>用户列表</source>
        <comment>menuName</comment>
        <translation type="unfinished">List users</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2965"/>
        <source>编辑组织名称</source>
        <comment>toolName</comment>
        <translation type="unfinished">Editar Nombre de la Organización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2985"/>
        <source>组织名称不可为空</source>
        <translation type="unfinished">Nombre de organización no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2992"/>
        <source>组织名称超长</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2999"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2999"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3004"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3009"/>
        <source>权限管理工具</source>
        <translation type="unfinished">Administrador de Permisos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3041"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="3052"/>
        <source>更新失败，请检查数据库服务</source>
        <translation type="unfinished">Fallo al actualizar, verifique BD</translation>
    </message>
</context>
<context>
    <name>chooseRoleDlg</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2597"/>
        <source>关联角色</source>
        <translation type="unfinished">Roles vinculados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2613"/>
        <source>角色选择</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Seleccionar rol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2615"/>
        <source>功能信息</source>
        <translation type="unfinished">Información funcional</translation>
    </message>
</context>
<context>
    <name>confTabWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="154"/>
        <source>用户</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="155"/>
        <source>角色</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Rol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="156"/>
        <source>功能</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="160"/>
        <source>节点</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_tab.cpp" line="161"/>
        <source>责任区</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">AOR </translation>
    </message>
</context>
<context>
    <name>fingerInfoDlg</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.ui" line="36"/>
        <source>用户名：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.ui" line="65"/>
        <source>录入</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Entrada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.ui" line="72"/>
        <source>清除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Limpiar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.ui" line="79"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.ui" line="92"/>
        <source>指纹1： </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.ui" line="115"/>
        <source>指纹2： </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.ui" line="158"/>
        <source>提示：  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.ui" line="138"/>
        <source>超时剩余时长：</source>
        <translation type="unfinished">Tiempo restante para el tiempo de espera:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="21"/>
        <source>关闭</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="54"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="112"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="118"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="123"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="128"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="138"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="145"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="239"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="252"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="284"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="289"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="54"/>
        <source>初始化失败，请检查数据库</source>
        <translation type="unfinished">Inicialización falló, revise BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="60"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="61"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="97"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="106"/>
        <source>未录入</source>
        <translation type="unfinished">No ingresado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="73"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="79"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="222"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="227"/>
        <source>已录入</source>
        <translation type="unfinished">Ya ingresado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="111"/>
        <source>指纹清除成功</source>
        <translation type="unfinished">Huella limpiada con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="118"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Seleccione datos a operar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="123"/>
        <source>请选择一条数据</source>
        <translation type="unfinished">Seleccione un dato</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="145"/>
        <source>指纹仪连接失败</source>
        <translation type="unfinished">Fallo al conectar huella</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="238"/>
        <source>指纹仪录入出错</source>
        <translation type="unfinished">Error de entrada de huella</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="251"/>
        <source>指纹仪录入超时</source>
        <translation type="unfinished">Tiempo de entrada de huella agotado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="128"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="138"/>
        <source>指纹仪未连接</source>
        <translation type="unfinished">Huella no conectada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="33"/>
        <source>指纹信息</source>
        <comment>toolName</comment>
        <translation type="unfinished">Info de Huella Digital</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="149"/>
        <source>指纹仪连接成功</source>
        <translation type="unfinished">Conexión de huella exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="152"/>
        <source>请录入三次指纹，请第[ 1 ]次录入指纹</source>
        <translation type="unfinished">Ingrese huella 3 veces, [1ra] vez</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="270"/>
        <source>请录入三次指纹，请第[ %1 ]次录入指纹</source>
        <translation type="unfinished">Ingrese huella 3 veces, [%1] vez</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="283"/>
        <source>指纹录入成功</source>
        <translation type="unfinished">Entrada de huella exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/finger_dlg.cpp" line="288"/>
        <source>指纹录入失败，请检查数据库服务</source>
        <translation type="unfinished">Fallo entrada huella, revise BD</translation>
    </message>
</context>
<context>
    <name>funcConfWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="47"/>
        <source>新增工具类型</source>
        <translation type="unfinished">Nuevo tipo de herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="49"/>
        <source>编辑工具类型</source>
        <translation type="unfinished">Tipo de herramienta de edición</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="51"/>
        <source>删除工具类型</source>
        <translation type="unfinished">Eliminar tipo de herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="53"/>
        <source>刷新</source>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="74"/>
        <source>新增工具</source>
        <translation type="unfinished">Nuevas herramientas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="76"/>
        <source>新增功能项</source>
        <translation type="unfinished">Nuevas funciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="78"/>
        <source>新增子功能项</source>
        <translation type="unfinished">Nuevas subfunciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="80"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="82"/>
        <source>全局查找</source>
        <translation type="unfinished">Búsqueda global</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="84"/>
        <source>列查找</source>
        <translation type="unfinished">Búsqueda de columna</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="86"/>
        <source>调整工具类型</source>
        <translation type="unfinished">Ajuste de tipo de herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="100"/>
        <source>  配置信息</source>
        <translation type="unfinished"> Información de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="112"/>
        <source>功能项名称：</source>
        <translation type="unfinished">Nombre del ítem de función:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="114"/>
        <source>功能项别名：</source>
        <translation type="unfinished">Alias de ítem funcional:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="117"/>
        <source>二次验证：</source>
        <translation type="unfinished">Validación secundaria:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="119"/>
        <source>多分配：</source>
        <translation type="unfinished">Distribución múltiple:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="128"/>
        <source>责任区：</source>
        <translation type="unfinished">AOR:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="184"/>
        <source>工具名称：</source>
        <translation type="unfinished">Nombre de la herramienta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="186"/>
        <source>工具别名：</source>
        <translation type="unfinished">Alias de herramienta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="189"/>
        <source>多登录：</source>
        <translation type="unfinished">Inicios de sesión múltiples:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="193"/>
        <source>多启动：</source>
        <translation type="unfinished">Arranque múltiple:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="195"/>
        <source>文件视图：</source>
        <translation type="unfinished">Vista de documentos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="137"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="199"/>
        <source>认证方式：</source>
        <translation type="unfinished">Método de autenticación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="202"/>
        <source>工具类型：</source>
        <translation type="unfinished">Tipo de herramienta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="267"/>
        <source>工具列表</source>
        <translation type="unfinished">Lista de herramientas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="302"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="303"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1227"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1228"/>
        <source>未分类工具</source>
        <translation type="unfinished">Herramientas no categorizadas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="323"/>
        <source>待关联列表</source>
        <translation type="unfinished">Lista por vincular</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="342"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="348"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="523"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="527"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="588"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="592"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1956"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1959"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2083"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2088"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="344"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="350"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="521"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="525"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="529"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="590"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="594"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1954"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1957"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2085"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2090"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="473"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="485"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="847"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="857"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="863"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="890"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="900"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="949"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1008"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1014"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1041"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1049"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1083"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1089"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1095"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1107"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1113"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1140"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1148"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1169"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1175"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1193"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1296"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1427"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1432"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1462"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1467"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1490"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1493"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1500"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1512"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1521"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1526"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1531"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1563"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1568"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1598"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1626"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1631"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1647"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1676"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1682"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1806"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1827"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1949"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2070"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2098"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2110"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2124"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2131"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2140"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2148"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2160"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2177"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2186"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2195"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2202"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="473"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="485"/>
        <source>获取App信息失败，请检查数据库</source>
        <translation type="unfinished">Fallo al obtener info. de app, revise BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="532"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="598"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1979"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2236"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2237"/>
        <source>未分类</source>
        <translation type="unfinished">No categorizado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="847"/>
        <source>请在工具表中右键添加工具项</source>
        <translation type="unfinished">Haga clic derecho para añadir ítem en tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="851"/>
        <source>请输入工具名称</source>
        <translation type="unfinished">Por favor, ingrese el nombre de la herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="857"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2110"/>
        <source>工具名称不可为空</source>
        <translation type="unfinished">Nombre de herramienta no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="900"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1049"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1148"/>
        <source>新增失败，请检查数据库服务</source>
        <translation type="unfinished">Fallo al añadir, revise BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1095"/>
        <source>存在待关联项的功能项不可添加子功能项</source>
        <translation type="unfinished">No añadir subítems a ítems con asociación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1467"/>
        <source>新增失败，请检查数据库连接</source>
        <translation type="unfinished">Fallo al añadir, revise conexión BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2140"/>
        <source>工具别名不可为空</source>
        <translation type="unfinished">Alias de herramienta no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2160"/>
        <source>功能项名称不可为空</source>
        <translation type="unfinished">Nombre de ítem de función no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2195"/>
        <source>功能项别名不可为空</source>
        <translation type="unfinished">Alias de ítem de función no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="890"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2131"/>
        <source>工具名称超长</source>
        <translation type="unfinished">Nombre de herramienta largo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1041"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1140"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2186"/>
        <source>功能项名称超长</source>
        <translation type="unfinished">Nombre de ítem de función largo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1169"/>
        <source>未添加工具类型</source>
        <translation type="unfinished">Tipo de herramienta no añadido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1198"/>
        <source>工具类型调整</source>
        <comment>toolName</comment>
        <translation type="unfinished">Ajuste de Tipo de Herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1209"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1210"/>
        <source>工具列表</source>
        <comment>menuName</comment>
        <translation type="unfinished">List herram</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1421"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1515"/>
        <source>工具类型名称</source>
        <comment>toolName</comment>
        <translation type="unfinished">Nombre del Tipo de Herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1490"/>
        <source>请在工具类型上右键删除</source>
        <translation type="unfinished">Haga clic derecho en tipo de herramienta para elim.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1626"/>
        <source>未选择工具</source>
        <translation type="unfinished">Sin herramienta seleccionada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1647"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1676"/>
        <source>未选择功能项</source>
        <translation type="unfinished">Sin ítem de función seleccionado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1827"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2124"/>
        <source>工具名称已存在</source>
        <translation type="unfinished">Nombre de herramienta ya existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2148"/>
        <source>工具别名超长</source>
        <translation type="unfinished">Alias de herramienta demasiado largo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2202"/>
        <source>功能项别名超长</source>
        <translation type="unfinished">Alias de ítem de función largo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="863"/>
        <source>工具已存在</source>
        <translation type="unfinished">Herramienta ya existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="129"/>
        <source>关联</source>
        <translation type="unfinished">Enlace</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="141"/>
        <source>系统默认</source>
        <translation type="unfinished">Predeterminado sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="145"/>
        <source>密码</source>
        <translation type="unfinished">Contraseña</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="147"/>
        <source>密码+UKey</source>
        <translation type="unfinished">Contraseña+UKey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="149"/>
        <source>密码+指纹</source>
        <translation type="unfinished">Contraseña+Huella</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="223"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="381"/>
        <source>功能名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de la función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="381"/>
        <source>功能别名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alias funcional</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="381"/>
        <source>二次验证</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Verificación secundaria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="381"/>
        <source>多分配</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Asignación múltiple</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="381"/>
        <source>引用责任区</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Referencia AOR </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="452"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="544"/>
        <source>工具名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de la herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="452"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="544"/>
        <source>工具别名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alias de herramientas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="452"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="544"/>
        <source>多启动</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Multiboot</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="452"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="544"/>
        <source>多登录</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Múltiples inicios de sesión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="452"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="544"/>
        <source>文件视图</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Vista de archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="452"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="544"/>
        <source>工具类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tipo de herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="851"/>
        <source>添加工具</source>
        <comment>toolName</comment>
        <translation type="unfinished">Agregar Herramientas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="871"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1022"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1121"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1440"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1540"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1919"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2038"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="871"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1022"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1121"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1919"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2038"/>
        <source>输入数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="876"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="881"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1027"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1032"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1126"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1131"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1445"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1450"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1545"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1550"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1924"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1929"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2043"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2048"/>
        <source>权限管理工具</source>
        <translation type="unfinished">Administrador de Permisos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="950"/>
        <source>在导航树中选中工具，在表格中右键添加功能项</source>
        <translation type="unfinished">Seleccione herramienta en árbol y añada ítem</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1002"/>
        <source>添加功能项</source>
        <translation type="unfinished">Agregar ítems funcionales</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1002"/>
        <source>请输入功能项名称</source>
        <translation type="unfinished">Por favor, ingrese un nombre de función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1008"/>
        <source>功能项不可为空</source>
        <translation type="unfinished">Ítem de función no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1014"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1806"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2177"/>
        <source>功能项名称已存在</source>
        <translation type="unfinished">Nombre de ítem de función ya existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1083"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1089"/>
        <source>请选中功能项后添加子功能项</source>
        <translation type="unfinished">Seleccione ítem de función y añada subítems</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1101"/>
        <source>添加子功能项</source>
        <translation type="unfinished">Agregar subfunciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1101"/>
        <source>请输入子功能项名称</source>
        <translation type="unfinished">Por favor, ingrese el nombre del ítem de subfunción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1107"/>
        <source>子功能项名称不可为空</source>
        <translation type="unfinished">Nombre de subítem de función no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1113"/>
        <source>子功能项名称已存在</source>
        <translation type="unfinished">Nombre de subítem de función ya existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1175"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1193"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1296"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Seleccione datos a operar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1421"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1515"/>
        <source>请输入工具类型名称</source>
        <translation type="unfinished">Ingrese nombre de tipo de herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1427"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1521"/>
        <source>工具类型名称超长</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1432"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1526"/>
        <source>工具类型名称不可为空</source>
        <translation type="unfinished">Nombre de tipo de herramienta no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1440"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1540"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1462"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1563"/>
        <source>工具类型已存在</source>
        <translation type="unfinished">Tipo de herramienta ya existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1493"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1598"/>
        <source>是否删除</source>
        <translation type="unfinished">¿Eliminar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1500"/>
        <source>删除失败，请检查数据库服务</source>
        <translation type="unfinished">Eliminación falló, revise BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1512"/>
        <source>请在工具类型上右键编辑名称</source>
        <translation type="unfinished">Haga clic derecho en tipo para editar nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1531"/>
        <source>工具类型名称未发生变化</source>
        <translation type="unfinished">Nombre de tipo de herramienta sin cambios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1568"/>
        <source>保存失败，请检查数据库服务</source>
        <translation type="unfinished">Guardado falló, revise BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1631"/>
        <source>更新失败，请检查数据库</source>
        <translation type="unfinished">Actualización falló, revise BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1637"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2009"/>
        <source>工具</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1682"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1949"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2070"/>
        <source>更新失败，请检查数据库服务</source>
        <translation type="unfinished">Actualización falló, revise BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="1688"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2091"/>
        <source>功能项</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_func.cpp" line="2098"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
</context>
<context>
    <name>genUkey</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="124"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="153"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="160"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="168"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="175"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="182"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="213"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="249"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="124"/>
        <source>证书生成失败</source>
        <translation type="unfinished">Generación de certificado falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="153"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="160"/>
        <source>证书信息损坏</source>
        <translation type="unfinished">Certificado dañado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="168"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="175"/>
        <source>UKey加载出错</source>
        <translation type="unfinished">Fallo al cargar UKey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="182"/>
        <source>UKey第一次绑定出错</source>
        <translation type="unfinished">Error de enlace UKey primera vez</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="204"/>
        <source>UKey制作失败</source>
        <translation type="unfinished">Creación de UKey falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="210"/>
        <source>UKey制作成功。</source>
        <translation type="unfinished">UKey se creó con éxito.</translation>
    </message>
</context>
<context>
    <name>nodeChooseDialog</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="290"/>
        <source>关联节点</source>
        <comment>toolName</comment>
        <translation type="unfinished">Nodo de Enlace</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="308"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="309"/>
        <source>节点名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre del nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="310"/>
        <source>节点别名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alias del nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="311"/>
        <source>系统信息库节点ID</source>
        <comment>subTitle</comment>
        <translation type="unfinished">ID del nodo de info del sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="312"/>
        <source>节点类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tipo de nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="355"/>
        <source>系统节点</source>
        <translation type="unfinished">Nodo del sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="359"/>
        <source>系统外节点</source>
        <translation type="unfinished">Nodo fuera del sistema</translation>
    </message>
</context>
<context>
    <name>nodeConfWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="68"/>
        <source>同步节点</source>
        <translation type="unfinished">Sincronizar nodos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="70"/>
        <source>全局查找</source>
        <translation type="unfinished">Búsqueda global</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="72"/>
        <source>列查找</source>
        <translation type="unfinished">Búsqueda de columna</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="89"/>
        <source>节点名称：</source>
        <translation type="unfinished">Nombre del nodo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="92"/>
        <source>节点别名：</source>
        <translation type="unfinished">Alias del nodo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="95"/>
        <source>责任区：</source>
        <translation type="unfinished">AOR:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="100"/>
        <source>角色：</source>
        <translation type="unfinished">Caracteres:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="49"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="49"/>
        <source>节点名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre del nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="49"/>
        <source>节点别名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alias del nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="49"/>
        <source>引用责任区</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Referencia AOR </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="49"/>
        <source>关联角色</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Roles de enlace</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="82"/>
        <source>  配置信息</source>
        <comment>subTitle</comment>
        <translation type="unfinished"> Info de config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="96"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="101"/>
        <source>关联</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Enlace</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="103"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="385"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="385"/>
        <source>输入数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="390"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="395"/>
        <source>权限管理工具</source>
        <translation type="unfinished">Administrador de Permisos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="405"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="421"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="716"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="798"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="405"/>
        <source>更新失败，请检查数据库</source>
        <translation type="unfinished">Fallo al actualizar, verifique BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="421"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="717"/>
        <source>是否同步系统信息库节点</source>
        <translation type="unfinished">¿Sincronizar nodos de info. del sistema?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_node.cpp" line="798"/>
        <source>节点别名超长</source>
        <translation type="unfinished">Alias de nodo demasiado largo</translation>
    </message>
</context>
<context>
    <name>roleChooseDialog</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="161"/>
        <source>关联角色</source>
        <comment>toolName</comment>
        <translation type="unfinished">Roles de Enlace</translation>
    </message>
</context>
<context>
    <name>roleConfWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="181"/>
        <source>批量新增</source>
        <translation type="unfinished">Alta masiva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="186"/>
        <source>新增操作员角色</source>
        <translation type="unfinished">Añadir rol operador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="190"/>
        <source>新增角色</source>
        <translation type="unfinished">Nuevo rol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="194"/>
        <source>从现有角色复制</source>
        <translation type="unfinished">Copiar desde Roles Existentes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="197"/>
        <source>删除角色</source>
        <translation type="unfinished">Eliminar rol.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="199"/>
        <source>全局查找</source>
        <translation type="unfinished">Búsqueda global</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="201"/>
        <source>列查找</source>
        <translation type="unfinished">Búsqueda de columna</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="203"/>
        <source>刷新工具类型</source>
        <translation type="unfinished">Actualizar tipo de herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="223"/>
        <source>数据级别</source>
        <comment>subTitle</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="255"/>
        <source>画面功能配置：</source>
        <translation type="unfinished">Configuración de pantalla de función:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="264"/>
        <source>角色名称：</source>
        <translation type="unfinished">Nombre del rol:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="272"/>
        <source>启动画面：</source>
        <translation type="unfinished">Pantalla de inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="281"/>
        <source>文件视图：</source>
        <translation type="unfinished">Vista de documentos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="290"/>
        <source>数据库视图：</source>
        <translation type="unfinished">Vista de base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="299"/>
        <source>多分配：</source>
        <translation type="unfinished">Distribución múltiple:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="300"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="485"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="301"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="487"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="316"/>
        <source>责任区选择：</source>
        <translation type="unfinished">Seleccionar AOR:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="326"/>
        <source>节点选择：</source>
        <translation type="unfinished">Seleccione nodo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="353"/>
        <source>基本信息</source>
        <translation type="unfinished">Información básica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="391"/>
        <source>角色列表</source>
        <translation type="unfinished">Lista de roles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="561"/>
        <source>未定义类型</source>
        <translation type="unfinished">Indefinido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="570"/>
        <source>通用级别</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="919"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="937"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="993"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1005"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1011"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1030"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1042"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1075"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1141"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1161"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1261"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1272"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1284"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1336"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1363"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1371"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1376"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1419"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1428"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1434"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1467"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1476"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1482"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1490"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1498"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1506"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1514"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1533"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="919"/>
        <source>输入包含非法字符，请检查</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="924"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="929"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1056"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1061"/>
        <source>权限管理工具</source>
        <translation type="unfinished">Administrador de Permisos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="937"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1075"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1161"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1376"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1434"/>
        <source>更新失败，请检查数据库</source>
        <translation type="unfinished">Fallo al actualizar, verifique BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="993"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="999"/>
        <source>添加角色</source>
        <translation type="unfinished">Agregar rol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="999"/>
        <source>请输入角色名称</source>
        <translation type="unfinished">Por favor, ingrese un nombre de rol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1051"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1051"/>
        <source>输入数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1141"/>
        <source>获取失败，请检查数据库</source>
        <translation type="unfinished">Adquisición Fallida, Verificar Base Datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1261"/>
        <source>只能选择一个角色进行复制</source>
        <translation type="unfinished">Solo un Rol Puede Seleccionarse para Replicar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1273"/>
        <source>以下角色禁止复制：</source>
        <translation type="unfinished">Siguientes Roles Prohibidos para Copiar:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1284"/>
        <source>请选择需要复制的角色</source>
        <translation type="unfinished">Seleccionar Rol a Copiar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1011"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1482"/>
        <source>角色名称超长</source>
        <translation type="unfinished">Nombre de rol demasiado largo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1364"/>
        <source>以下角色禁止删除：</source>
        <translation type="unfinished">Roles que no se pueden eliminar:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1371"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Seleccione datos para operar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1490"/>
        <source>启动画面内容超长</source>
        <translation type="unfinished">El contenido del gráfica de inicio es demasiado largo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1498"/>
        <source>画面功能内容超长</source>
        <translation type="unfinished">El contenido de la función de la gráfica es demasiado largo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1506"/>
        <source>文件视图内容超长</source>
        <translation type="unfinished">Contenido vista archivo excede longitud</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1514"/>
        <source>数据库视图内容超长</source>
        <translation type="unfinished">Contenido vista BD excede longitud</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1533"/>
        <source>角色功能互斥检测失败</source>
        <translation type="unfinished">Fallo al detectar conflicto de funciones rol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1042"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1428"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1476"/>
        <source>角色已存在</source>
        <translation type="unfinished">Rol ya existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="144"/>
        <source>操作员</source>
        <translation type="unfinished">Operador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="145"/>
        <source>管理员</source>
        <translation type="unfinished">Administrador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="146"/>
        <source>审计员</source>
        <translation type="unfinished">Auditor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="147"/>
        <source>未登录角色</source>
        <translation type="unfinished">Rol no registrado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="222"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="222"/>
        <source>角色名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre del rol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="222"/>
        <source>多分配</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Asignación múltiple</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="222"/>
        <source>启动画面</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Gráfica de inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="222"/>
        <source>画面功能配置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Config de función de gráfica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="222"/>
        <source>文件视图</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Vista de archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="223"/>
        <source>数据库权限</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Permisos de BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="223"/>
        <source>责任区</source>
        <comment>subTitle</comment>
        <translation type="unfinished">AOR </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="223"/>
        <source>节点</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="223"/>
        <source>角色类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tipo de Rol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="243"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="701"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="710"/>
        <source>节点白名单：</source>
        <translation type="unfinished">Lista blanca de nodos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="714"/>
        <source>节点黑名单：</source>
        <translation type="unfinished">Lista negra de nodos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1005"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1030"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1419"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1467"/>
        <source>角色名称不可为空</source>
        <translation type="unfinished">Nombre de rol no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1304"/>
        <source>输入数量：</source>
        <translation type="unfinished">Cantidad de entrada:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1304"/>
        <source>批量新增</source>
        <comment>toolName</comment>
        <translation type="unfinished">Agregar en Lote</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1336"/>
        <source>是否删除</source>
        <translation type="unfinished">¿Eliminar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1574"/>
        <source>未分类</source>
        <translation type="unfinished">No categorizado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1582"/>
        <source>功能选择</source>
        <translation type="unfinished">Seleccionar función</translation>
    </message>
</context>
<context>
    <name>roleFuncChoose</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1748"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1761"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1748"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_role.cpp" line="1761"/>
        <source>角色功能信息获取失败，请检查数据库服务</source>
        <translation type="unfinished">Fallo al obtener info. funcs. rol, verifique BD</translation>
    </message>
</context>
<context>
    <name>sysConfWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="47"/>
        <source>当前配置</source>
        <translation type="unfinished">Configuración actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="48"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="49"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="50"/>
        <source>保存到模板</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar en el modelo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="51"/>
        <source>设置为系统配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="68"/>
        <source>密码有效天数：</source>
        <translation type="unfinished">Expiración de la contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="79"/>
        <source>密码最大错误次数：</source>
        <translation type="unfinished">Número máximo de intentos de contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="90"/>
        <source>登录失败用户锁定时长：</source>
        <translation type="unfinished">Duración del bloqueo por fallo en el inicio de sesión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="101"/>
        <source>机器闲置工具锁定时长：</source>
        <translation type="unfinished">Duración del bloqueo por inactividad de la herramienta de la máquina:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="112"/>
        <source>默认用户登录有效期：</source>
        <translation type="unfinished">Período de validez del inicio de sesión del usuario predeterminado:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="123"/>
        <source>历史密码个数：</source>
        <translation type="unfinished">Cantidad de contraseñas históricas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="134"/>
        <source>密码最小长度：</source>
        <translation type="unfinished">Longitud mínima de la contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="145"/>
        <source>密码最大长度：</source>
        <translation type="unfinished">Longitud máxima de la contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="157"/>
        <source>密码复杂度：</source>
        <translation type="unfinished">Complejidad de la contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="158"/>
        <source>数字</source>
        <translation type="unfinished">Número</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="159"/>
        <source>小写字母</source>
        <translation type="unfinished">Letras minúsculas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="160"/>
        <source>大写字母</source>
        <translation type="unfinished">Letras mayúsculas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="161"/>
        <source>特殊字符</source>
        <translation type="unfinished">Caracteres especiales</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="162"/>
        <source>禁止包含用户名</source>
        <translation type="unfinished">No se permiten nombres de usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="174"/>
        <source>强制修改初始密码：</source>
        <translation type="unfinished">Forzar el cambio de la contraseña inicial:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="176"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="190"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="204"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="177"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="191"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="205"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="188"/>
        <source>强制修改过期密码：</source>
        <translation type="unfinished">Forzar el cambio de contraseña vencida:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="202"/>
        <source>登录框隐藏用户名：</source>
        <translation type="unfinished">Ocultar el nombre de usuario en el cuadro de inicio de sesión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="245"/>
        <source>系统配置</source>
        <translation type="unfinished">Configuración del sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_sys.cpp" line="246"/>
        <source>配置模板</source>
        <translation type="unfinished">Plantillas de configuración</translation>
    </message>
</context>
<context>
    <name>ukeyInfoDlg</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="20"/>
        <source>证书</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Certificado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="35"/>
        <source>状态：</source>
        <translation type="unfinished">Estado:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="57"/>
        <source>加密方式：</source>
        <translation type="unfinished">Método de cifrado:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="79"/>
        <source>有效期：  </source>
        <translation type="unfinished">Período de validez:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="121"/>
        <source>生成</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Generar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="128"/>
        <source>校验</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Verificar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="135"/>
        <source>查看</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cargar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="142"/>
        <source>清除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Limpiar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="155"/>
        <source>Ukey</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Ukey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="189"/>
        <source>加载</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cargar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="272"/>
        <source>重置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Restablecer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="279"/>
        <source>制作</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Hacer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="286"/>
        <source>关闭</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="173"/>
        <source>Ukeys设备：      </source>
        <translation type="unfinished">Equipo UKeys:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="208"/>
        <source>所属用户：    </source>
        <translation type="unfinished">Usuario:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.ui" line="230"/>
        <source>设备状态：    </source>
        <translation type="unfinished">Estado del dispositivo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="286"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="292"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="298"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="311"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="348"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="354"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="360"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="377"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="391"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="398"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="405"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="412"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="422"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="429"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="437"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="449"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="495"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="502"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="505"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="510"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="516"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="524"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="543"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="568"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="593"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="597"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="621"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="634"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="650"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="657"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="774"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="286"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="292"/>
        <source>获取用户信息失败</source>
        <translation type="unfinished">Fallo al obtener info. usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="298"/>
        <source>获取用户信息失败，请检查数据库服务</source>
        <translation type="unfinished">Fallo al obtener info. usuario, revise BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="303"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="323"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="512"/>
        <source>未生成证书</source>
        <translation type="unfinished">No se generó certificado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="311"/>
        <source>获取证书信息失败</source>
        <translation type="unfinished">Fallo al obtener info. de certificado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="319"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="496"/>
        <source>已生成证书</source>
        <translation type="unfinished">Certificado generado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="348"/>
        <source>UKey已使用，请重置</source>
        <translation type="unfinished">UKey usado, reinicie</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="354"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="391"/>
        <source>请加载设备</source>
        <translation type="unfinished">Cargue el equipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="370"/>
        <source>UKey制作失败</source>
        <translation type="unfinished">Creación de UKey falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="375"/>
        <source>UKey制作成功</source>
        <translation type="unfinished">UKey creado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="392"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="400"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="407"/>
        <source>UKey重置失败</source>
        <translation type="unfinished">Fallo al restablecer el UKey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="360"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="398"/>
        <source>UKey绑定出错</source>
        <translation type="unfinished">Error de enlace UKey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="257"/>
        <source>UKey配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Config de UKey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="405"/>
        <source>UKey重置出错</source>
        <translation type="unfinished">Error al resetear UKey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="412"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="415"/>
        <source>UKey重置成功</source>
        <translation type="unfinished">El UKey se ha restablecido con éxito.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="422"/>
        <source>用户证书已存在</source>
        <translation type="unfinished">Certificado de usuario ya existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="429"/>
        <source>用户信息证书读取失败，请检查数据库服务</source>
        <translation type="unfinished">Fallo al leer certif. usuario, revise BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="437"/>
        <source>保存失败，请检查数据库服务</source>
        <translation type="unfinished">Guardado falló, revise servicio de BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="449"/>
        <source>创建证书失败</source>
        <translation type="unfinished">Fallo al crear certificado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="495"/>
        <source>生成证书成功</source>
        <translation type="unfinished">Certificado generado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="502"/>
        <source>用户证书不存在</source>
        <translation type="unfinished">Certificado de usuario no existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="505"/>
        <source>是否删除</source>
        <translation type="unfinished">¿Eliminar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="593"/>
        <source>证书校验失败</source>
        <translation type="unfinished">Validación de certificado falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="634"/>
        <source>用户证书信息未生成</source>
        <translation type="unfinished">Certificado usuario no generado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="650"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="657"/>
        <source>用户证书信息损坏</source>
        <translation type="unfinished">Info. de certificado de usuario dañada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="510"/>
        <source>删除证书成功</source>
        <translation type="unfinished">Certificado eliminado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="516"/>
        <source>删除证书失败</source>
        <translation type="unfinished">Fallo al eliminar certificado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="524"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="568"/>
        <source>请生成用户证书</source>
        <translation type="unfinished">Genere certificado usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="543"/>
        <source>证书加载失败</source>
        <translation type="unfinished">Carga de certificado falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="549"/>
        <source>证书信息</source>
        <translation type="unfinished">Información del certificado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="558"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="597"/>
        <source>校验成功</source>
        <translation type="unfinished">Validación exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="621"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="623"/>
        <source>UKey加载出错</source>
        <translation type="unfinished">Fallo al cargar el UKey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="627"/>
        <source>UKey加载成功</source>
        <translation type="unfinished">UKey cargado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/ukey_dlg.cpp" line="774"/>
        <source>读取证书失败，请检查数据库服务</source>
        <translation type="unfinished">Fallo al leer certificado, verifique BD</translation>
    </message>
</context>
<context>
    <name>userConfWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="105"/>
        <source>增加平级组织</source>
        <translation type="unfinished">Agregar organizaciones horizontales</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="107"/>
        <source>增加下级组织</source>
        <translation type="unfinished">Agregar organizaciones subordinadas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="109"/>
        <source>编辑组织</source>
        <translation type="unfinished">Editar organización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="111"/>
        <source>删除组织</source>
        <translation type="unfinished">Eliminar organización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="113"/>
        <source>刷新</source>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="130"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1327"/>
        <source>批量新增</source>
        <translation type="unfinished">Agregar en lote</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="132"/>
        <source>新增用户</source>
        <translation type="unfinished">Nuevo usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="134"/>
        <source>删除用户</source>
        <translation type="unfinished">Eliminar usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="136"/>
        <source>全局查找</source>
        <translation type="unfinished">Búsqueda global</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="138"/>
        <source>列查找</source>
        <translation type="unfinished">Búsqueda de columna</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="140"/>
        <source>组织调整</source>
        <translation type="unfinished">Ajustar organización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="180"/>
        <source>  配置信息</source>
        <translation type="unfinished"> Información de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="195"/>
        <source>用户名称：</source>
        <translation type="unfinished">Usuario:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="197"/>
        <source>密码：</source>
        <translation type="unfinished">Contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="202"/>
        <source>电话：</source>
        <translation type="unfinished">Teléfono:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="208"/>
        <source>邮箱：</source>
        <translation type="unfinished">Correo electrónico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="213"/>
        <source>启动画面：</source>
        <translation type="unfinished">Pantalla de inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="216"/>
        <source>证书及UKey：</source>
        <translation type="unfinished">Certificado y UKey:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="220"/>
        <source>指纹：</source>
        <translation type="unfinished">Huellas dactilares:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="225"/>
        <source>锁定状态：</source>
        <translation type="unfinished">Estado bloqueado:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="230"/>
        <source>角色：</source>
        <translation type="unfinished">Caracteres:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="337"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="338"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2085"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2086"/>
        <source>未分组</source>
        <translation type="unfinished">Sin agrupar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="417"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="675"/>
        <source>已激活</source>
        <translation type="unfinished">Activado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="421"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="673"/>
        <source>未激活</source>
        <translation type="unfinished">Inactivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="445"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="715"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="808"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1082"/>
        <source>已生成</source>
        <translation type="unfinished">Generado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="449"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="719"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="809"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1083"/>
        <source>未生成</source>
        <translation type="unfinished">No generado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="472"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="742"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="812"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1232"/>
        <source>已录入</source>
        <translation type="unfinished">Ya ingresado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="476"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="746"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="813"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1233"/>
        <source>未录入</source>
        <translation type="unfinished">No ingresado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="486"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="755"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="818"/>
        <source>已锁定</source>
        <translation type="unfinished">Bloqueado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="490"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="759"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="822"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1747"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1748"/>
        <source>未锁定</source>
        <translation type="unfinished">Desbloqueado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="906"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="914"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="969"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1040"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1247"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1253"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1280"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1295"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1349"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1408"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1429"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1499"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1504"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1514"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1552"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1557"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1566"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1587"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1649"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1657"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1663"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1672"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1751"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1851"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1859"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1896"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1907"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1924"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1941"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1950"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1967"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1975"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1987"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1996"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2046"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2154"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2216"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2227"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2244"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2253"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2357"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2366"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2375"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2382"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2393"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2401"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2410"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="906"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1247"/>
        <source>用户名不可为空</source>
        <translation type="unfinished">Nombre de usuario no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="969"/>
        <source>更新失败，请检查数据库服务</source>
        <translation type="unfinished">Actualización falló, revise BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="997"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1261"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="997"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1261"/>
        <source>输入数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1002"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1007"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1266"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1271"/>
        <source>权限管理工具</source>
        <translation type="unfinished">Administrador de Permisos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1280"/>
        <source>用户名超长</source>
        <translation type="unfinished">Nombre de usuario largo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1409"/>
        <source>更新用户:{}操作员角色错误，请检查数据库服务</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1429"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1587"/>
        <source>是否删除</source>
        <translation type="unfinished">¿Eliminar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1499"/>
        <source>删除失败，每个角色（审计员、管理员）都需至少有一名用户</source>
        <translation type="unfinished">Error al eliminar, cada rol (auditor, administrador) debe tener al menos un usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1514"/>
        <source>禁止删除登录用户</source>
        <translation type="unfinished">No se permite eliminar usuarios con sesión iniciada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1957"/>
        <source>编辑组织名称</source>
        <comment>toolName</comment>
        <translation type="unfinished">Editar Nombre de la Organización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1974"/>
        <source>请确认是否删除组织[%1]</source>
        <translation type="unfinished">Confirme si desea eliminar la organización [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2051"/>
        <source>组织关系调整</source>
        <comment>toolName</comment>
        <translation type="unfinished"> Ajustar Relación Organizacional</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2188"/>
        <source>修改密码</source>
        <comment>toolName</comment>
        <translation type="unfinished">Cambiar Contraseña</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2188"/>
        <source>请输入密码</source>
        <translation type="unfinished">Ingrese su contraseña</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1504"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2227"/>
        <source>读取失败，请检查数据库服务</source>
        <translation type="unfinished">Error de lectura, por favor verifique el servicio de BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2253"/>
        <source>修改密码成功</source>
        <translation type="unfinished">Contraseña cambiada con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2382"/>
        <source>用户名称超长</source>
        <translation type="unfinished">Nombre de usuario largo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2410"/>
        <source>启动画面设置超长</source>
        <translation type="unfinished">El contenido del gráfica de inicio es demasiado largo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1040"/>
        <source>数据保存成功</source>
        <translation type="unfinished">Datos guardados con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1241"/>
        <source>请输入用户名</source>
        <translation type="unfinished">Por favor ingrese el nombre de usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="914"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1253"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2375"/>
        <source>用户名已存在</source>
        <translation type="unfinished">Nombre de usuario ya existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="142"/>
        <source>修改密码</source>
        <translation type="unfinished">Cambiar contraseña</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="159"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="159"/>
        <source>用户名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="159"/>
        <source>电话</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Teléfono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="159"/>
        <source>邮箱</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Correo electrónico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="159"/>
        <source>激活状态</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Activación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="159"/>
        <source>启动画面</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Gráfica de inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="159"/>
        <source>角色</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Rol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="160"/>
        <source>证书</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Certificado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="160"/>
        <source>UKey</source>
        <comment>subTitle</comment>
        <translation type="unfinished">UKey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="160"/>
        <source>指纹</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Huella digital</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="160"/>
        <source>锁定状态</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Bloqueado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="160"/>
        <source>修改密码时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Hora de cambio de contraseña</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="160"/>
        <source>密码有效期</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Expiración de la contraseña</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="198"/>
        <source>重置密码</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Restablecer contraseña</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="217"/>
        <source>管理</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Gestionar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="221"/>
        <source>录入</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Entrada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="226"/>
        <source>解锁</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Desbloquear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="231"/>
        <source>关联</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Enlace</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="235"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="308"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="309"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2062"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2063"/>
        <source>用户列表</source>
        <comment>menuName</comment>
        <translation type="unfinished">List users</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1241"/>
        <source>添加用户</source>
        <comment>toolName</comment>
        <translation type="unfinished">Agregar Usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1295"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1349"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1557"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1566"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1663"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1672"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1851"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1996"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2244"/>
        <source>更新错误，请检查数据库服务</source>
        <translation type="unfinished">Error de actualización, revise BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1327"/>
        <source>输入数量:</source>
        <translation type="unfinished">Cantidad de entrada:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1552"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1657"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2046"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2154"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2216"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2357"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Seleccione datos a operar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1650"/>
        <source>以下用户禁止删除：</source>
        <translation type="unfinished">Los siguientes usuarios están prohibidos de eliminación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1744"/>
        <source>用户解锁失败，请检查数据库服务</source>
        <translation type="unfinished">Desbloqueo de usuario falló, revise BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1749"/>
        <source>用户解锁成功</source>
        <translation type="unfinished">Usuario desbloqueado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1859"/>
        <source>重置密码成功</source>
        <translation type="unfinished">Reinicio de contraseña exitoso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1897"/>
        <source>增加平级组织时不能选择用户列表或未分组</source>
        <translation type="unfinished">No seleccionar lista al añadir org. par</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1907"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1950"/>
        <source>未获取到该组织的上级组织</source>
        <translation type="unfinished">No se obtuvo org. padre de la org.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1924"/>
        <source>增加下级组织时不能选择未分组</source>
        <translation type="unfinished">No seleccionar sin grupo al añadir suborgs.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1942"/>
        <source>修改组织名称时不能选择用户列表或未分组</source>
        <translation type="unfinished">No seleccionar lista al modificar nombre org.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1968"/>
        <source>删除平级组织时不能选择用户列表或未分组</source>
        <translation type="unfinished">No seleccionar lista al eliminar org. par</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="1988"/>
        <source>该组织存在下级组织，点击确定将级联删除所有组织</source>
        <translation type="unfinished">Hay suborgs., confirme para eliminar en cascada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2366"/>
        <source>请检查用户名是否设置正确</source>
        <translation type="unfinished">Revise si nombre de usuario está correcto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2393"/>
        <source>请检查电话是否设置正确</source>
        <translation type="unfinished">Revise si teléfono está configurado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_user.cpp" line="2401"/>
        <source>请检查邮箱是否设置正确</source>
        <translation type="unfinished">Revise si correo está configurado correcto</translation>
    </message>
</context>
<context>
    <name>workChooseDialog</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="16"/>
        <source>关联责任区</source>
        <comment>toolName</comment>
        <translation type="unfinished">Enlace AOR </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="58"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="59"/>
        <source>名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="60"/>
        <source>应用组号</source>
        <comment>subTitle</comment>
        <translation type="unfinished"> No. de grupo de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/choose_dialog.cpp" line="61"/>
        <source>库内组号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Número de grupo en la BD</translation>
    </message>
</context>
<context>
    <name>workConfWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="67"/>
        <source>批量新增</source>
        <translation type="unfinished">Agregar en Lote</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="69"/>
        <source>新增责任区</source>
        <translation type="unfinished">Nuevo AOR </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="71"/>
        <source>全局查找</source>
        <translation type="unfinished">Búsqueda global</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="73"/>
        <source>列查找</source>
        <translation type="unfinished">Búsqueda de columna</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="75"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="86"/>
        <source>  配置信息</source>
        <translation type="unfinished"> Información de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="94"/>
        <source>责任区：</source>
        <translation type="unfinished">AOR:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="96"/>
        <source>应用组号：</source>
        <translation type="unfinished">  Número de grupo de la aplicación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="98"/>
        <source>库内组号：</source>
        <translation type="unfinished">Número de grupo de la base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="100"/>
        <source>备注：</source>
        <translation type="unfinished">Observaciones:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="159"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="182"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="208"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="225"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="238"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="405"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="411"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="418"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="442"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="454"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="473"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="478"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="509"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="526"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="535"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="542"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="550"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="558"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="566"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="159"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="535"/>
        <source>责任区名称已存在</source>
        <translation type="unfinished">El nombre de AOR ya existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="208"/>
        <source>输入包含非法字符，请检查</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="213"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="218"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="429"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="434"/>
        <source>权限管理工具</source>
        <translation type="unfinished">Administrador de Permisos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="399"/>
        <source>添加责任区</source>
        <comment>toolName</comment>
        <translation type="unfinished">Agregar AOR </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="418"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="542"/>
        <source>责任区名称超长</source>
        <translation type="unfinished">El nombre de AOR es demasiado largo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="424"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="424"/>
        <source>责任区名称包含非法字符</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="442"/>
        <source>新增失败，请检查数据库链接</source>
        <translation type="unfinished">Fallo al añadir, revise enlace BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="473"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Seleccione datos a operar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="495"/>
        <source>批量新增</source>
        <comment>toolName</comment>
        <translation type="unfinished">Agregar en Lote</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="550"/>
        <source>应用组号内容超长</source>
        <translation type="unfinished">Núm. de grupo de app largo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="558"/>
        <source>库内组号内容超长</source>
        <translation type="unfinished">Contenido de núm. de grupo en BD largo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="566"/>
        <source>备注内容超长</source>
        <translation type="unfinished">Notas demasiado largas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="225"/>
        <source>数据更新错误，请检查数据库服务</source>
        <translation type="unfinished">Error de actualización de datos, revise BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="46"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="46"/>
        <source>责任区</source>
        <comment>subTitle</comment>
        <translation type="unfinished">AOR </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="46"/>
        <source>应用组号</source>
        <comment>subTitle</comment>
        <translation type="unfinished"> No. de grupo de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="46"/>
        <source>库内组号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Número de grupo en la BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="46"/>
        <source>备注</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Observación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="101"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="182"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="405"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="526"/>
        <source>责任区名称不可为空</source>
        <translation type="unfinished">El nombre de AOR no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="238"/>
        <source>数据保存成功</source>
        <translation type="unfinished">Datos guardados con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="399"/>
        <source>请输入责任区名称</source>
        <translation type="unfinished">Por favor, ingrese el nombre del AOR </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="411"/>
        <source>责任区已存在</source>
        <translation type="unfinished">AOR ya existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="454"/>
        <source>是否删除</source>
        <translation type="unfinished">¿Eliminar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="478"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="509"/>
        <source>更新失败，请检查数据库服务</source>
        <translation type="unfinished">Actualización falló, revise BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_privmgr/conf_work.cpp" line="495"/>
        <source>输入数量：</source>
        <translation type="unfinished">Cantidad de entrada:</translation>
    </message>
</context>
</TS>
