<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>FileComparatorComponent::ChooseFileWidget</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/filecomparewidget.h" line="34"/>
        <source>选择文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/filecomparewidget.h" line="35"/>
        <source>请选择QM文件</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileComparatorComponent::FileComparsionPage</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/filecomparewidget.h" line="173"/>
        <source>开启词条定位功能</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/filecomparewidget.h" line="176"/>
        <source>QM文件: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/filecomparewidget.h" line="177"/>
        <source>TS文件: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/filecomparewidget.h" line="178"/>
        <source>比对</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/filecomparewidget.h" line="181"/>
        <source>仅展示TS文件不存在的词条</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/filecomparewidget.h" line="182"/>
        <source>仅展示QM件不存在的词条</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="249"/>
        <source>文件列表</source>
        <translation type="unfinished">Lista de Archivos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="257"/>
        <source>DIC文件</source>
        <translation type="unfinished">Archivo DIC</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="261"/>
        <source>TS文件</source>
        <translation type="unfinished">Archivos TS</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="275"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="276"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1586"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2079"/>
        <source>新增词条</source>
        <translation type="unfinished">Agregar nueva entrada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="282"/>
        <source>删除词条</source>
        <translation type="unfinished">Eliminar Entrada </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="298"/>
        <source>注意</source>
        <translation type="unfinished">Aviso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="298"/>
        <source>TS文件禁止清空</source>
        <translation type="unfinished">El archivo TS no puede ser limpiado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="312"/>
        <source>发布新版本翻译</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="329"/>
        <source>过滤出未翻译的词条</source>
        <translation type="unfinished">Filtrar entradas no traducidas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="355"/>
        <source>输入搜索内容...</source>
        <translation type="unfinished">Ingrese el contenido de búsqueda...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="361"/>
        <source>所有列</source>
        <translation type="unfinished">Todas las cols</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="362"/>
        <source>Source</source>
        <translation type="unfinished">Fuente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="363"/>
        <source>Tag</source>
        <translation type="unfinished">Etiqueta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="364"/>
        <source>Comments</source>
        <translation type="unfinished">Comentarios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="365"/>
        <source>Translation</source>
        <translation type="unfinished">Traducción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="640"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="645"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="661"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="672"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="678"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1103"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1112"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1212"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1275"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1279"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1295"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1322"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1713"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1716"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1733"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1743"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1816"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1821"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="641"/>
        <source>处理文件时发生错误: %1</source>
        <translation type="unfinished">Ocurrió un error al procesar el archivo: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="645"/>
        <source>处理文件时发生未知错误</source>
        <translation type="unfinished">Error desconocido al procesar el archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="661"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1103"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1733"/>
        <source>无法打开文件：</source>
        <translation type="unfinished">No se puede abrir el archivo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="672"/>
        <source>JSON解析错误：</source>
        <translation type="unfinished">Error de análisis JSON:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="678"/>
        <source>JSON文件格式错误：需要数组格式</source>
        <translation type="unfinished">Error de formato de archivo JSON: se requiere formato de arreglo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="198"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="227"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="509"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="512"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="818"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1126"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1129"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1147"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1150"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1158"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1173"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1179"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1185"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1192"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1196"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1240"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1286"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1443"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1456"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="818"/>
        <source>当前服务存在异常</source>
        <translation type="unfinished">Hay una excepción en el servicio actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1112"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1743"/>
        <source>无法解析XML文件</source>
        <translation type="unfinished">No se puede analizar el archivo XML</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1167"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1212"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1295"/>
        <source>无法保存文件：</source>
        <translation type="unfinished">No se puede guardar el archivo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1255"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1307"/>
        <source>成功</source>
        <translation type="unfinished">Éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1255"/>
        <source>文件已保存</source>
        <translation type="unfinished">El archivo ha sido guardado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1276"/>
        <source>保存文件时发生错误: %1</source>
        <translation type="unfinished">Ocurrió un error al guardar el archivo: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1279"/>
        <source>保存文件时发生未知错误</source>
        <translation type="unfinished">Ocurrió un error desconocido al guardar el archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1307"/>
        <source>配置文件已保存</source>
        <translation type="unfinished">El archivo de configuración ha sido guardado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1322"/>
        <source>配置文件保存失败</source>
        <translation type="unfinished">No se pudo guardar el archivo de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1368"/>
        <source>文件不存在</source>
        <translation type="unfinished">Archivo no encontrado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1368"/>
        <source>当前需要同步的文件路径不存在,无法同步该文件,路径为: %1</source>
        <translation type="unfinished">La ruta del archivo que necesita ser sincronizada actualmente no existe, por lo que el archivo no puede ser sincronizado. La ruta es:%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1377"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1417"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1473"/>
        <source>文件同步</source>
        <translation type="unfinished">Sinc Archivos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1378"/>
        <source>目前要同步的文件的相对路径为: %1,是否要继续同步文件</source>
        <translation type="unfinished">La ruta relativa del archivo a sincronizar actualmente es: %1. Desea continuar sincronizando el archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1417"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1473"/>
        <source>已取消文件同步</source>
        <translation type="unfinished">La sincronización de archivos ha sido cancelada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1425"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1479"/>
        <source>文件同步服务执行异常</source>
        <translation type="unfinished">Excepción en la ejecución del servicio de sincronización de archivos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1268"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1352"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1425"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1479"/>
        <source>失败</source>
        <translation type="unfinished">Fallido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="140"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="324"/>
        <source>文件比对</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="198"/>
        <source>文件比对页面功能加载失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="227"/>
        <source>初始化语言管理功能失败,错误码%1</source>
        <translation type="unfinished">Fallo al Inicializar Función Gestión Idioma, Código Error %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="241"/>
        <source>搜索文件: </source>
        <translation type="unfinished">Buscar archivos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="143"/>
        <source>导入词条</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2155"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2166"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2180"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2185"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2190"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2192"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2195"/>
        <source>信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="325"/>
        <source>TS与对应的QM二进制文件比对</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="509"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="512"/>
        <source>文件查询失败,服务异常</source>
        <translation type="unfinished">Consulta Archivo Fallida, Excepción Servicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1126"/>
        <source>保存的TS文件的词条的source不能为空字符串, 保存操作终止</source>
        <translation type="unfinished">La fuente de la entrada en el archivo TS guardado no puede ser una cadena vacía, operación de guardado terminada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1129"/>
        <source>当前服务异常,异常状态码为: %1,%2, 保存操作终止</source>
        <translation type="unfinished">El servicio actual es anormal, con códigos de estado de excepción:%1,%2, operación de guardado terminada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1147"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1150"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1192"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1196"/>
        <source>TS文件存在异常,异常状态码为: %1, 保存操作终止</source>
        <translation type="unfinished">Hay una excepción en el archivo TS, con un código de estado de excepción de %1, operación de guardado terminada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1158"/>
        <source>TS文件存在异常,两个&lt;context/&gt;标签检测到相同的&lt;name&gt;%1&lt;name/&gt;,本工具无法执行保存操作,请自行打开TS文件进行修改</source>
        <translation type="unfinished">Hay Excepción en Archivo TS. Dos Etiquetas &lt;context&gt; Detectaron Mismo &lt;name&gt;%1&lt;name&gt;.&lt;/name&gt;&lt;/name&gt;&lt;/context&gt; Esta Herramienta No Puede Realizar Operación Guardar. Abrir Archivo TS Manualmente para Modificar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1167"/>
        <source>没有需要保存的更改, 保存操作终止</source>
        <translation type="unfinished">No hay cambios que necesiten ser guardados, operación de guardado terminada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1173"/>
        <source>删除词条失败,异常状态码为: %1, 保存操作终止</source>
        <translation type="unfinished">Eliminar entrada falló con código de excepción:%1, operación de guardado terminada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1179"/>
        <source>新增加词条失败,异常状态码为: %1, 保存操作终止</source>
        <translation type="unfinished">No se pudo añadir nueva entrada, código de estado de excepción:%1, operación de guardado terminada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1185"/>
        <source>更新词条失败,异常状态码为: %1, 保存操作终止</source>
        <translation type="unfinished">Actualizar entrada falló con código de excepción:%1, operación de guardado terminada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1240"/>
        <source>无法保存QM文件,在获取QM文件路径时出错,请查看日志</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1268"/>
        <source>文件保存失败,%1;%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1286"/>
        <source>DIC文件不允许清空词条, 至少要保留一个词条</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1352"/>
        <source>文件同步异常, 请检查系统是否正常开启, 文件同步服务是否正常开启</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1357"/>
        <source>完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1358"/>
        <source>文件同步已完成, 文件同步成功的节点的翻译需在系统停止条件下发布新版本的翻译文件后方可生效, 各节点的详细信息如下: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1443"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1456"/>
        <source>内部服务异常,无法进行文件同步</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1565"/>
        <source>重复词条</source>
        <translation type="unfinished">Entradas duplicadas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1565"/>
        <source>存在重复的词条, 建议删除或修改重复的词条, 请检查标红的词条</source>
        <translation type="unfinished">Hay entradas duplicadas, se recomienda eliminarlas o modificarlas. Por favor verifique las entradas resaltadas en rojo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1657"/>
        <source>确认删除</source>
        <translation type="unfinished">Confirmar para eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1658"/>
        <source>确定要删除这个词条吗？</source>
        <translation type="unfinished">¿Está seguro de que desea eliminar esta entrada?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1713"/>
        <source>加载文件时发生错误: %1</source>
        <translation type="unfinished">Error al cargar el archivo: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1716"/>
        <source>加载文件时发生未知错误</source>
        <translation type="unfinished">Ocurrió un error desconocido al cargar el archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1817"/>
        <source>解析文件时发生错误: %1</source>
        <translation type="unfinished">Ocurrió un error al analizar el archivo:%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1821"/>
        <source>解析文件时发生未知错误</source>
        <translation type="unfinished">Ocurrió un error desconocido al analizar el archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1928"/>
        <source>当前选中: Source=&apos;%1&apos; | Context=&apos;%2&apos; | Location=&apos;%3&apos;</source>
        <translation type="unfinished">Actualmente seleccionado: Fuente=&apos;%1&apos; | Contexto=&apos;%2&apos; | Ubicación=&apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1952"/>
        <source>处理表格点击时发生错误: %1</source>
        <translation type="unfinished">Ocurrió un error al procesar el clic en la tabla:%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1971"/>
        <source>表格操作</source>
        <translation type="unfinished">Operación de tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1973"/>
        <source>复制</source>
        <translation type="unfinished">Duplicar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1974"/>
        <source>粘贴</source>
        <translation type="unfinished">Pegar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1975"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2042"/>
        <source>找到 %1 个匹配项</source>
        <translation type="unfinished">Se encontraron %1 coincidencias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2156"/>
        <source>注意, 保存成功, 仅代表dic/ts文件保存成功, 程序实际使用的.rd/.qm文件需在系统停止状态下点击%1按钮生效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2167"/>
        <source>当前存在最新版本的(.rd/.qm)文件的路径为: %2, 如需使最新的翻译生效, 请停系统并点击%1按钮生效, 如果想忽略该文件(.rd/.qm), 可自行删除或通过该工具修改(.dic/.ts)文件, 程序会自动覆盖最新版本的(.rd/.qm)文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2180"/>
        <source>请确认是否更新翻译文件(.rd/.qm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2185"/>
        <source>更新翻译文件(.rd/.qm)需保证系统在未启动状态下进行, 请手动停系统</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2190"/>
        <source>翻译文件(.rd/.qm)更新失败, 请稍后重试</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2192"/>
        <source>翻译文件(.rd/.qm)更新完成,请重启相应进程查看翻译结果</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2195"/>
        <source>更新翻译文件(.rd/.qm)流程已终止</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.h" line="176"/>
        <source>文件编辑</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.h" line="177"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
</context>
<context>
    <name>commonwidget::EntrySearchWidget</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="181"/>
        <source>翻译: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="182"/>
        <source>重置条件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="199"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="211"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="199"/>
        <source>系统服务存在异常</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="202"/>
        <source>搜索</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="211"/>
        <source>切换搜索框搜索翻译语种类型时出现异常, 请联系研发</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>commonwidget::FilesSelectedWidget</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="311"/>
        <source>选择文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="312"/>
        <source>添加文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="313"/>
        <source>删除文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="315"/>
        <source>添加文件路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="316"/>
        <source>删除文件路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="327"/>
        <source>信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="327"/>
        <source>请选择要删除的文件路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.h" line="151"/>
        <source>已选文件: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>commonwidget::TranslationFilesDisplayWidget</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="417"/>
        <source>搜索文件: </source>
        <translation type="unfinished">Buscar archivos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="418"/>
        <source>搜索</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>exportwidget::ExportDisplayWidget</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="19"/>
        <source>文件路径: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="20"/>
        <source>选择文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="28"/>
        <source>选择全部</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="30"/>
        <source>取消全选</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="34"/>
        <source>预览词条</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="35"/>
        <source>导出</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="50"/>
        <source>可导出的.dic文件列表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="109"/>
        <source>点击右侧的按钮选择要导出词条的文件存放的位置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="113"/>
        <source>是否导出</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="179"/>
        <source>选择导出文件的位置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="230"/>
        <source>导入出错</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="230"/>
        <source>dic文件解析出错: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="239"/>
        <source>加载成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="239"/>
        <source>加载数据成功, 请查看表格数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="257"/>
        <source>文件已存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="257"/>
        <source>当前文件已存在, 确定是否覆盖原文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="259"/>
        <source>已取消导出</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="259"/>
        <source>已经取消导出操作</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="268"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="268"/>
        <source>文件导出时出现异常,异常信息为: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="270"/>
        <source>导出成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="270"/>
        <source>导出文件成功</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>importwidget::EntryOverrideDialog</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="838"/>
        <source>新添加的词条和已有的词条完全相同, 需要确定导入后每个词条采用的翻译</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="839"/>
        <source>被勾选的翻译代表要保存的,点击%1或关闭该对话框可以终止词条导入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="868"/>
        <source>词条翻译选择</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="890"/>
        <source>信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="890"/>
        <source>获取冲突解决后的词条失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="954"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="961"/>
        <source>原先的翻译结果</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="961"/>
        <source>新导入的翻译</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.h" line="256"/>
        <source>取消导入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.h" line="258"/>
        <source>全部使用新的翻译</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.h" line="260"/>
        <source>全部使用新的翻译(翻译不为空)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.h" line="262"/>
        <source>保留已有的翻译</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.h" line="264"/>
        <source>保留已有的翻译(翻译为空的除外)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>importwidget::ImportDisplayWidget</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="71"/>
        <source>选择全部</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="72"/>
        <source>取消全选</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="73"/>
        <source>预览词条</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="74"/>
        <source>导入到文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="76"/>
        <source>可选导入语言: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="77"/>
        <source>要导入词条的文件为: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="78"/>
        <source>请选择要导入词条的文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="85"/>
        <source>已选要导入的文件: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="87"/>
        <source>已选择的词条: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="88"/>
        <source>重复词条: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="89"/>
        <source>开启自动搜索: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="90"/>
        <source>进度: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="94"/>
        <source>勾选</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="95"/>
        <source>取消勾选</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="196"/>
        <source>是否导入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="226"/>
        <source>词条导入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="248"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="454"/>
        <source>选择文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="260"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="290"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="355"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="443"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="530"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="533"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="565"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="571"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="584"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="592"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="607"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="610"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="617"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="625"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="628"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="636"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="641"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="647"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="650"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="656"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="660"/>
        <source>信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="260"/>
        <source>添加文件失败, 以下添加的文件路径重复: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="290"/>
        <source>请选择要导入的文件的路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="355"/>
        <source>注意: 此时搜索的翻译语种为: %1, 与准备导入的词条的翻译的语种不符</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="443"/>
        <source>请确认要关闭当前页面吗</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="510"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="597"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="510"/>
        <source>当前文件不存在: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="515"/>
        <source>解析文件出错</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="515"/>
        <source>解析文件: %1时出错, 错误原因: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="530"/>
        <source>词条加载成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="533"/>
        <source>词条加载成功, 其中存在重复的词条(source,tag,comments相同),上述词条已经提供背景色, 请查看</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="565"/>
        <source>请选择要导入的词条</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="571"/>
        <source>请选择要导入到的文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="584"/>
        <source>当前选择导入的词条中存在重复的词条(source,tag,comments相同), 请取消选择重复的词条后再导入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="597"/>
        <source>系统服务异常,请查看日志</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="617"/>
        <source>解析dic文件时出现异常, %1 , 无法向该文件导入词条</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="625"/>
        <source>系统服务异常</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="628"/>
        <source>已终止导入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="636"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="660"/>
        <source>系统服务异常,导入失败, 请查看日志联系研发</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="641"/>
        <source>系统服务异常, 请联系研发,mainwindow is null</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="647"/>
        <source>词条成功导入, 已保存到对应文件, 可在文件编辑页面重新打开文件查看</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="651"/>
        <source>注意, 保存成功, 仅代表dic/ts文件保存成功, 程序实际使用的.rd/.qm文件需在系统停止状态下在编辑页面点击%1按钮生效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="656"/>
        <source>文件导入失败, 请稍后重试</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="592"/>
        <source>请选择要导入的词条对应的翻译语种</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="604"/>
        <source>异常</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="604"/>
        <source>系统服务发生异常, 请查看日志</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="607"/>
        <source>请确认, 当前准备将词条导入到%1中, 导入的词条翻译语种为: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="610"/>
        <source>已取消导入</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>model::ChoosedFilesModel</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/model/model.cpp" line="890"/>
        <source>文件名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/model/model.cpp" line="893"/>
        <source>文件绝对路径</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>model::ConflictEntryTableModel</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/model/model.cpp" line="1145"/>
        <source>未知</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/model/model.h" line="478"/>
        <source>翻译结果1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/model/model.h" line="478"/>
        <source>翻译结果2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>model::DefaultEntryEntityModel</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/model/model.cpp" line="502"/>
        <source>词条来源</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>model::TranslationFilesModel</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/model/model.cpp" line="212"/>
        <source>DIC文件</source>
        <translation type="unfinished">Archivo DIC</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/model/model.cpp" line="213"/>
        <source>TS文件</source>
        <translation type="unfinished">Archivos TS</translation>
    </message>
</context>
<context>
    <name>tabledelegate::ItemSelectedDelegate</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/delegate/tabledelegate.cpp" line="139"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/delegate/tabledelegate.cpp" line="139"/>
        <source>修改单元格数据失败</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
