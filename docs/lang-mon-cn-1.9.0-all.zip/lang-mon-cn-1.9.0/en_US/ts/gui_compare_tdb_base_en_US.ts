<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="104"/>
        <source>源库：</source>
        <translation type="unfinished">Source DB:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="106"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="114"/>
        <source>请选择比对对象</source>
        <translation type="unfinished">Please select the comparison object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="111"/>
        <source>目标库：</source>
        <translation type="unfinished">Dest DB:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="195"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="230"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="235"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="250"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="358"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="399"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="405"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="465"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="860"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="864"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1153"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1174"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1306"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1314"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1321"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1332"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1518"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1523"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="195"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="358"/>
        <source>差异页会全部关闭，是否继续</source>
        <translation type="unfinished">The difference pages will all be closed. Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="230"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="399"/>
        <source>相同路径下库不参与比对</source>
        <translation type="unfinished">DB under the same path do not participate in comparison</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="235"/>
        <source>与目标库名不同，是否继续</source>
        <translation type="unfinished">Different from the destination DB name, whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="250"/>
        <source>需清空目标库，是否继续</source>
        <translation type="unfinished">Need to clear the destination DB, whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="405"/>
        <source>与源库名不同，重新选择</source>
        <translation type="unfinished">Different from the source DB name, select again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="465"/>
        <source>差异页会全部清除，是否继续</source>
        <translation type="unfinished">The difference pages will be cleared completely. Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="828"/>
        <source>重新比对</source>
        <translation type="unfinished">Recompare</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="120"/>
        <source>选择源库</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select source db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="126"/>
        <source>选择目标库</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select dest db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="820"/>
        <source>配置列</source>
        <comment>toolName</comment>
        <translation type="unfinished">Config Columns</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="831"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="912"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="951"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="832"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="913"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="952"/>
        <source>退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="851"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1289"/>
        <source>比对中....请等待</source>
        <translation type="unfinished">Comparing...please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="860"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1306"/>
        <source>无差异</source>
        <translation type="unfinished">No difference</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="864"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1314"/>
        <source>有差异</source>
        <translation type="unfinished">Diffs exist.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="904"/>
        <source>可展示字段</source>
        <comment>toolName</comment>
        <translation type="unfinished">Displayable Fields</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1153"/>
        <source>元数据有差异</source>
        <translation type="unfinished">Metadata diffs.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1174"/>
        <source>元数据无差异</source>
        <translation type="unfinished">Metadata has no difference</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1518"/>
        <source>各自一个对象</source>
        <translation type="unfinished">Each with its own object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1523"/>
        <source>最大支持10个详情页，请先关闭部分</source>
        <translation type="unfinished">Supports up to 10 detail pages, please close some of them first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1545"/>
        <source>比对详情</source>
        <translation type="unfinished">Compare details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1551"/>
        <source>表%1元数据详情</source>
        <translation type="unfinished">Table %1 metadata details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2017"/>
        <source>比对</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Compare</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2026"/>
        <source>全部数据</source>
        <comment>buttonName</comment>
        <translation type="unfinished">All data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2036"/>
        <source>维护数据</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Maintenance data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2045"/>
        <source>重新加载</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Reload</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2047"/>
        <source>重新加载源/目标库内容</source>
        <translation type="unfinished">Reload source/destination DB content</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2054"/>
        <source>差异详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Diff details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2056"/>
        <source>也可以选中差异节点，鼠标右键查看差异详情</source>
        <translation type="unfinished">You can also select the difference node and right-click to view the difference details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2062"/>
        <source>更多设置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">More settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2063"/>
        <source>设置比对关键字段，以及展示数据类型</source>
        <translation type="unfinished">Set comparison key fields and display data types</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2103"/>
        <source>可展示字段</source>
        <translation type="unfinished">Displayable fields</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2323"/>
        <source>表名：</source>
        <translation type="unfinished">Table name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2324"/>
        <source>表大小：</source>
        <translation type="unfinished">Table size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2333"/>
        <source>检索路径：</source>
        <translation type="unfinished">Search path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2334"/>
        <source>存历史：</source>
        <translation type="unfinished">Save history:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2335"/>
        <source>维护模式：</source>
        <translation type="unfinished">Maintenance mode:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1644"/>
        <source>加载中....请等待</source>
        <translation type="unfinished">Loading.... Please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1322"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1333"/>
        <source>差异条数:</source>
        <translation type="unfinished">Differences items:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1811"/>
        <source>表元数据</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Table Metadata</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1812"/>
        <source>字段元数据</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Field Metadata</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="1999"/>
        <source>比对类型：</source>
        <translation type="unfinished">Comparison type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2005"/>
        <source>数据库</source>
        <translation type="unfinished">DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2006"/>
        <source>配置文件</source>
        <translation type="unfinished">Config files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2088"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2096"/>
        <source>配置列</source>
        <translation type="unfinished">Config columns</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2110"/>
        <source>导出</source>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2279"/>
        <source>表别名</source>
        <translation type="unfinished">Table alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2279"/>
        <source>表大小</source>
        <translation type="unfinished">Table size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="2279"/>
        <source>数据区大小</source>
        <translation type="unfinished">Data area size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="471"/>
        <source>不存历史</source>
        <translation type="unfinished">No history</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="473"/>
        <source>采样存历史</source>
        <translation type="unfinished">Sampling and storing history</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="475"/>
        <source>事件存历史</source>
        <translation type="unfinished">Events are stored in history</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="477"/>
        <source>统计存历史</source>
        <translation type="unfinished">Statistics History Storage</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="479"/>
        <source>采样加事件</source>
        <translation type="unfinished">Sampling Events</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="481"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="495"/>
        <source>未知类型</source>
        <translation type="unfinished">Unknown type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="489"/>
        <source>默认</source>
        <translation type="unfinished">Default</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="491"/>
        <source>同步增删改</source>
        <translation type="unfinished">Sync CRUD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow_slot_meta.cpp" line="493"/>
        <source>同步修改</source>
        <translation type="unfinished">Synch update</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.ui" line="24"/>
        <source>首页</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">First</translation>
    </message>
</context>
<context>
    <name>ObjColCfgDlg</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="644"/>
        <source>字段别名</source>
        <translation type="unfinished">Field alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="644"/>
        <source>字段ID</source>
        <translation type="unfinished">Field ID</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/mainwindow.cpp" line="3006"/>
        <source>数据库比对工具</source>
        <comment>toolName</comment>
        <translation type="unfinished">DB Comparison</translation>
    </message>
</context>
<context>
    <name>appAccess</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="562"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
</context>
<context>
    <name>choseRowWidget</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="804"/>
        <source>字段别名</source>
        <translation type="unfinished">Field alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="804"/>
        <source>字段ID</source>
        <translation type="unfinished">Field ID</translation>
    </message>
</context>
<context>
    <name>dbConfUserDlg</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="12"/>
        <source>更多设置</source>
        <translation type="unfinished">More settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="29"/>
        <source>标识模式:</source>
        <translation type="unfinished">Identification mode:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="35"/>
        <source>关键字</source>
        <translation type="unfinished">Keyword</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="36"/>
        <source>OID</source>
        <translation type="unfinished">OID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="40"/>
        <source>数据模式:</source>
        <translation type="unfinished">Data mode:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="45"/>
        <source>全部数据</source>
        <translation type="unfinished">All data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="46"/>
        <source>模型数据</source>
        <translation type="unfinished">Model data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="47"/>
        <source>运行数据</source>
        <translation type="unfinished">Operating Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="56"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_com_dlg.cpp" line="62"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>dbDataAccessBase</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="672"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="781"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="515"/>
        <source>离散</source>
        <translation type="unfinished">Scatter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="675"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="784"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="518"/>
        <source>连续</source>
        <translation type="unfinished">Continuous</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="678"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="787"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="521"/>
        <source>循环</source>
        <translation type="unfinished">Loop</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="681"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="790"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="524"/>
        <source>循环子表</source>
        <translation type="unfinished">Loop subtable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="684"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="793"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="527"/>
        <source>历史</source>
        <translation type="unfinished">History</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="1456"/>
        <source>信息提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="1456"/>
        <source>循环子表不支持查询</source>
        <translation type="unfinished">Circular subtables do not support queries</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_func.cpp" line="1460"/>
        <source>错误信息</source>
        <translation type="unfinished">Error message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="245"/>
        <source>对象数据</source>
        <translation type="unfinished">Object data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="258"/>
        <source>元数据</source>
        <translation type="unfinished">Metadata</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="421"/>
        <source>维护包</source>
        <translation type="unfinished">Maintenance package</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="424"/>
        <source>同步包</source>
        <translation type="unfinished">Sync package</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="427"/>
        <source>本地包</source>
        <translation type="unfinished">Local package</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="430"/>
        <source>历史包</source>
        <translation type="unfinished">History package</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="763"/>
        <source>Y</source>
        <translation type="unfinished">Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="765"/>
        <source>N</source>
        <translation type="unfinished">N</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_data_base_virtual.cpp" line="1065"/>
        <source>StructInfo</source>
        <translation type="unfinished">StructInfo</translation>
    </message>
</context>
<context>
    <name>dbLeftWidget</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="45"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="45"/>
        <source>别名</source>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="45"/>
        <source>类型</source>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="45"/>
        <source>对象数</source>
        <translation type="unfinished">Number of objects</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="45"/>
        <source>差异数</source>
        <translation type="unfinished">Difference number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="477"/>
        <source>包ID:【%1】</source>
        <translation type="unfinished">Package ID: [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbLeftWidget.cpp" line="482"/>
        <source>表ID:【%1】</source>
        <translation type="unfinished">Table ID: [%1]</translation>
    </message>
</context>
<context>
    <name>dbNormalTableView</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1477"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1577"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1594"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1613"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1477"/>
        <source>上限为10个关联窗口</source>
        <translation type="unfinished">The maximum number of linked Windows is 10</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1576"/>
        <source>跨库关系:未配置元数据信息
 检索信息失败</source>
        <translation type="unfinished">Cross-database relationship: Metadata information is not configured
Failed to retrieve information</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1592"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1611"/>
        <source>打开失败:应用</source>
        <translation type="unfinished">Open failed: App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1592"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="1611"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2110"/>
        <source>属性</source>
        <translation type="unfinished">Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2116"/>
        <source>索引数据区</source>
        <translation type="unfinished">Index Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2117"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2123"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2131"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2144"/>
        <source>装库</source>
        <translation type="unfinished">Load DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2122"/>
        <source>维护数据区</source>
        <translation type="unfinished">Maintain Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2128"/>
        <source>同步数据区</source>
        <translation type="unfinished">Sync Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2135"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2148"/>
        <source>非装库</source>
        <translation type="unfinished">Non-Load DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2141"/>
        <source>本地数据区</source>
        <translation type="unfinished">Local Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_table_view.cpp" line="2153"/>
        <source>未设置区</source>
        <translation type="unfinished">Non-setted area</translation>
    </message>
</context>
<context>
    <name>dbio_dbShowDialog</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="254"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="254"/>
        <source>当前为镜像库</source>
        <translation type="unfinished">Mirror DB currently</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="264"/>
        <source>请输入必要参数</source>
        <translation type="unfinished">Enter Params</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="271"/>
        <source>库类型：</source>
        <translation type="unfinished">DB type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="275"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="276"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="277"/>
        <source>本地路径</source>
        <translation type="unfinished">local path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="285"/>
        <source>应用名：</source>
        <translation type="unfinished">App name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="297"/>
        <source>库名称：</source>
        <translation type="unfinished">DB name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="309"/>
        <source>选择</source>
        <translation type="unfinished">Select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="318"/>
        <source>选择文件</source>
        <translation type="unfinished">Select File</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/dbcompare_app_access.cpp" line="332"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
</context>
<context>
    <name>metaDiffWidget</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="28"/>
        <source>字段名称</source>
        <translation type="unfinished">Field name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="29"/>
        <source>字段别名</source>
        <translation type="unfinished">Field alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="30"/>
        <source>字段ID</source>
        <translation type="unfinished">Field ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="31"/>
        <source>关键字字段</source>
        <translation type="unfinished">Keyword field</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="33"/>
        <source>标识字段</source>
        <translation type="unfinished">ID field</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="34"/>
        <source>检索器中不可见</source>
        <translation type="unfinished">Invisible in retriever</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="35"/>
        <source>是否存历史</source>
        <translation type="unfinished">Save history</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="36"/>
        <source>是否装库</source>
        <translation type="unfinished">Load DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="37"/>
        <source>维护和运行库%1同步更新</source>
        <translation type="unfinished">MTDB and RTDB %1 is being synchronously updated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="38"/>
        <source>维护库中%1显示顺序</source>
        <translation type="unfinished">Display order of %1 in MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="39"/>
        <source>运行库中%1显示顺序</source>
        <translation type="unfinished">Display order of %1 in RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="40"/>
        <source>循环子对象个数</source>
        <translation type="unfinished">Loop sub-objects count</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="41"/>
        <source>单向关联</source>
        <translation type="unfinished">One-way link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="42"/>
        <source>跨库关联</source>
        <translation type="unfinished">Cross-db link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="43"/>
        <source>是否翻译</source>
        <translation type="unfinished">Translated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="44"/>
        <source>是否索引</source>
        <translation type="unfinished">Indexed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="85"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="93"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="103"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="115"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="129"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="138"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="146"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="243"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="87"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="96"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="106"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="119"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="133"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="149"/>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="246"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
</context>
<context>
    <name>tableMetaDiff</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="320"/>
        <source>类别</source>
        <translation type="unfinished">Category</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="321"/>
        <source>源表值</source>
        <translation type="unfinished">Source table value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="323"/>
        <source>目标表值</source>
        <translation type="unfinished">Dest table value</translation>
    </message>
</context>
<context>
    <name>tableMetaModel</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="440"/>
        <source>类别</source>
        <translation type="unfinished">Category</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="440"/>
        <source>源表值</source>
        <translation type="unfinished">Source table value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_tdbcompare_tool/tdbcompare_base/source/metaDiffWidget.cpp" line="440"/>
        <source>目标表值</source>
        <translation type="unfinished">Dest table value</translation>
    </message>
</context>
</TS>
