<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="309"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="947"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="980"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1068"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1079"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1096"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1305"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1328"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1606"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1612"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1680"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="309"/>
        <source>注册失败</source>
        <translation type="unfinished">Fallo al registrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="348"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="855"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="971"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="348"/>
        <source>目前无值班节点</source>
        <translation type="unfinished">Ningún nodo está actualmente en servicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="437"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="506"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="437"/>
        <source>同步目录</source>
        <translation type="unfinished">Directorio de sincronización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="395"/>
        <source>新增</source>
        <comment>menuName</comment>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="396"/>
        <source>删除</source>
        <comment>menuName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="397"/>
        <source>保存</source>
        <comment>menuName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="506"/>
        <source>属性配置OID</source>
        <translation type="unfinished">OID del atributo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="506"/>
        <source>同步OID</source>
        <translation type="unfinished">Sincronización OID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="506"/>
        <source>源现场</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Sitio de origen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="506"/>
        <source>目标现场</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Sitio de destino</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="506"/>
        <source>同步目录</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Directorio de sincronización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="671"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="688"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1425"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1442"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="671"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1425"/>
        <source>数据库连接异常</source>
        <translation type="unfinished">Error de conexión a BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="688"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1442"/>
        <source>目录数据加载失败</source>
        <translation type="unfinished">Fallo al cargar datos de directorio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="855"/>
        <source>未选中任何行</source>
        <translation type="unfinished">No se seleccionaron filas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="899"/>
        <source>删除选中行</source>
        <translation type="unfinished">Eliminar fila seleccionada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="899"/>
        <source>是否删除</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="971"/>
        <source>同步目录不能为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1135"/>
        <source>刷新完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1333"/>
        <source>源/目标现场重名，请检查</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1606"/>
        <source>文件打开失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1611"/>
        <source>成功导出文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1680"/>
        <source>导入成功，需保存生效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="947"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1328"/>
        <source>源/目标现场不能为空</source>
        <translation type="unfinished">Sitio fuente/destino no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="980"/>
        <source>数据库连接不可用</source>
        <translation type="unfinished">Conexión a BD no disponible</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1090"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1135"/>
        <source>信息</source>
        <translation type="unfinished">Mensaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1068"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="332"/>
        <source>仅更新同步目录列表信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1073"/>
        <source>告警</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1073"/>
        <source>保存失败</source>
        <translation type="unfinished">Fallo al guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1079"/>
        <source>是否重置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1090"/>
        <source>重置成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1096"/>
        <source>是否刷新同步目录列表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1305"/>
        <source>源/目标现场不允许重名</source>
        <translation type="unfinished">El sitio de origen/destino no puede tener el mismo nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1333"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1339"/>
        <source>重复的数据</source>
        <translation type="unfinished">Datos duplicados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1339"/>
        <source>第%1行，与之前的行重复</source>
        <translation type="unfinished">Línea %1, repitiendo la línea anterior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.cpp" line="1395"/>
        <source>选择文件夹</source>
        <translation type="unfinished">Seleccionar carpeta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.ui" line="47"/>
        <source>跨现场文件目录</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.ui" line="67"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.ui" line="74"/>
        <source>删除</source>
        <comment>butttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.ui" line="81"/>
        <source>刷新</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.ui" line="113"/>
        <source>导入</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.ui" line="120"/>
        <source>导出</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.ui" line="140"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_site_config/mainwindow.ui" line="150"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
</context>
</TS>
