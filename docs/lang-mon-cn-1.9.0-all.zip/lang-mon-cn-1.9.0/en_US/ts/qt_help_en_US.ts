<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="en_US">
<context>
    <name>QCLuceneResultWidget</name>
    <message>
        <source>Search Results</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Note:</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>The search results may not be complete since the documentation is still being indexed.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Your search did not match any documents.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>(The reason for this might be that the documentation is still being indexed.)</source>
        <translation type="vanished" />
    </message>
</context>
<context>
    <name>QHelp</name>
    <message>
        <source>Untitled</source>
        <translation />
    </message>
</context>
<context>
    <name>QHelpCollectionHandler</name>
    <message>
        <source>The collection file '%1' is not set up yet.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>The collection file "%1" is not set up yet.</source>
        <translation />
    </message>
    <message>
        <source>Cannot load sqlite database driver.</source>
        <translation />
    </message>
    <message>
        <source>Cannot open collection file: %1</source>
        <translation />
    </message>
    <message>
        <source>Cannot create tables in file %1.</source>
        <translation />
    </message>
    <message>
        <source>Cannot create index tables in file %1.</source>
        <translation />
    </message>
    <message>
        <source>Cannot register index tables in file %1.</source>
        <translation />
    </message>
    <message>
        <source>Cannot unregister index tables in file %1.</source>
        <translation />
    </message>
    <message>
        <source>The collection file "%1" already exists.</source>
        <translation />
    </message>
    <message>
        <source>Unknown filter "%1".</source>
        <translation />
    </message>
    <message>
        <source>Invalid documentation file "%1".</source>
        <translation />
    </message>
    <message>
        <source>Cannot register namespace "%1".</source>
        <translation />
    </message>
    <message>
        <source>Cannot register virtual folder '%1'.</source>
        <translation />
    </message>
    <message>
        <source>Version %1</source>
        <translation />
    </message>
    <message>
        <source>The collection file '%1' already exists.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Cannot create directory: %1</source>
        <translation />
    </message>
    <message>
        <source>Cannot copy collection file: %1</source>
        <translation />
    </message>
    <message>
        <source>Unknown filter '%1'.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Cannot register filter %1.</source>
        <translation />
    </message>
    <message>
        <source>Cannot open documentation file %1.</source>
        <translation />
    </message>
    <message>
        <source>Invalid documentation file '%1'.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>The namespace %1 was not registered.</source>
        <translation />
    </message>
    <message>
        <source>Namespace %1 already exists.</source>
        <translation />
    </message>
    <message>
        <source>Cannot register namespace '%1'.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Cannot open database '%1' to optimize.</source>
        <translation type="vanished" />
    </message>
</context>
<context>
    <name>QHelpDBReader</name>
    <message>
        <source>Cannot open database '%1' '%2': %3</source>
        <extracomment>The placeholders are: %1 - The name of the database which cannot be opened %2 - The unique id for the connection %3 - The actual error string</extracomment>
        <translation type="vanished" />
    </message>
    <message>
        <source>Cannot open database "%1" "%2": %3</source>
        <extracomment>The placeholders are: %1 - The name of the database which cannot be opened %2 - The unique id for the connection %3 - The actual error string</extracomment>
        <translation />
    </message>
</context>
<context>
    <name>QHelpEngineCore</name>
    <message>
        <source>Cannot open documentation file %1: %2.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>The specified namespace does not exist.</source>
        <translation type="vanished" />
    </message>
</context>
<context>
    <name>QHelpGenerator</name>
    <message>
        <source>Invalid help data.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>No output file name specified.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>The file %1 cannot be overwritten.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Building up file structure...</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Cannot open data base file %1.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Cannot register namespace %1.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Insert custom filters...</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Insert help data for filter section (%1 of %2)...</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Documentation successfully generated.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Some tables already exist.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Cannot create tables.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Cannot register virtual folder.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Insert files...</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>The file %1 does not exist! Skipping it.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Cannot open file %1! Skipping it.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>The filter %1 is already registered.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Cannot register filter %1.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Insert indices...</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Insert contents...</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Cannot insert contents.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Cannot register contents.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>File '%1' does not exist.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>File '%1' cannot be opened.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>File '%1' contains an invalid link to file '%2'</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Invalid links in HTML files.</source>
        <translation type="vanished" />
    </message>
</context>
<context>
    <name>QHelpProject</name>
    <message>
        <source>Unknown token in file "%1".</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Unknown token. Expected "QtHelpProject".</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Error in line %1: %2</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Virtual folder has invalid syntax in file: "%1"</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Namespace "%1" has invalid syntax in file: "%2"</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Missing namespace in QtHelpProject file: "%1"</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Missing virtual folder in QtHelpProject file: "%1"</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>The input file %1 could not be opened.</source>
        <translation type="vanished" />
    </message>
</context>
<context>
    <name>QHelpSearchQueryWidget</name>
    <message>
        <source>Search for:</source>
        <translation />
    </message>
    <message>
        <source>Previous search</source>
        <translation />
    </message>
    <message>
        <source>Next search</source>
        <translation />
    </message>
    <message>
        <source>Search</source>
        <translation />
    </message>
    <message>
        <source>Advanced search</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>words &lt;B&gt;similar&lt;/B&gt; to:</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>&lt;B&gt;without&lt;/B&gt; the words:</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>with &lt;B&gt;exact phrase&lt;/B&gt;:</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>with &lt;B&gt;all&lt;/B&gt; of the words:</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>with &lt;B&gt;at least one&lt;/B&gt; of the words:</source>
        <translation type="vanished" />
    </message>
</context>
<context>
    <name>QHelpSearchResultWidget</name>
    <message numerus="yes">
        <source>%1 - %2 of %n Hits</source>
        <translation><numerusform>%1 - %2 / %n találat</numerusform>
        </translation>
    </message>
    <message>
        <source>0 - 0 of 0 Hits</source>
        <translation />
    </message>
</context>
<context>
    <name>FilterNameDialogClass</name>
    <message>
        <source>Add Filter</source>
        <translation />
    </message>
    <message>
        <source>Filter Name:</source>
        <translation />
    </message>
</context>
<context>
    <name>QHelpFilterSettingsWidget</name>
    <message>
        <source>Form</source>
        <translation />
    </message>
    <message>
        <source>Filter</source>
        <translation />
    </message>
    <message>
        <source>Components</source>
        <translation />
    </message>
    <message>
        <source>Versions</source>
        <translation />
    </message>
    <message>
        <source>Add...</source>
        <translation />
    </message>
    <message>
        <source>Rename...</source>
        <translation />
    </message>
    <message>
        <source>Remove</source>
        <translation />
    </message>
    <message>
        <source>Add Filter</source>
        <translation />
    </message>
    <message>
        <source>New Filter</source>
        <translation />
    </message>
    <message>
        <source>Rename Filter</source>
        <translation />
    </message>
    <message>
        <source>Remove Filter</source>
        <translation />
    </message>
    <message>
        <source>Are you sure you want to remove the "%1" filter?</source>
        <translation />
    </message>
    <message>
        <source>Filter Exists</source>
        <translation />
    </message>
    <message>
        <source>The filter "%1" already exists.</source>
        <translation />
    </message>
    <message>
        <source>No Component</source>
        <translation />
    </message>
    <message>
        <source>Invalid Component</source>
        <translation />
    </message>
    <message>
        <source>No Version</source>
        <translation />
    </message>
    <message>
        <source>Invalid Version</source>
        <translation />
    </message>
</context>
<context>
    <name>fulltextsearch::qt::QHelpSearchIndexWriter</name>
    <message>
        <source>Cannot open database "%1" using connection "%2": %3</source>
        <translation type="vanished" />
    </message>
</context>
<context>
    <name>QResultWidget</name>
    <message>
        <source>Search Results</source>
        <translation />
    </message>
    <message>
        <source>Note:</source>
        <translation />
    </message>
    <message>
        <source>The search results may not be complete since the documentation is still being indexed.</source>
        <translation />
    </message>
    <message>
        <source>Your search did not match any documents.</source>
        <translation />
    </message>
    <message>
        <source>(The reason for this might be that the documentation is still being indexed.)</source>
        <translation />
    </message>
</context>
<context>
    <name>QOptionsWidget</name>
    <message>
        <source>No Option</source>
        <translation />
    </message>
    <message>
        <source>Invalid Option</source>
        <translation />
    </message>
</context>
<context>
    <name>fulltextsearch::QHelpSearchIndexWriter</name>
    <message>
        <source>Cannot open database "%1" using connection "%2": %3</source>
        <translation />
    </message>
</context>
</TS>