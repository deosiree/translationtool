<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/include/copy_sql_dlg.h" line="18"/>
        <source>sql语句</source>
        <translation type="unfinished">Sentencia SQL</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/include/copy_sql_dlg.h" line="25"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5323"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/include/copy_sql_dlg.h" line="29"/>
        <source>复制</source>
        <translation type="unfinished">Duplicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/query_result_model.cpp" line="136"/>
        <source>序号</source>
        <translation type="unfinished">Núm.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/query_result_model.cpp" line="557"/>
        <source>不支持的数据类型</source>
        <translation type="unfinished">Tipo de datos no soportado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="247"/>
        <source>数据查询</source>
        <translation type="unfinished">Consulta de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="248"/>
        <source>数据同步</source>
        <translation type="unfinished">Sincronización de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="249"/>
        <source>导入/导出</source>
        <translation type="unfinished">I/E</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="250"/>
        <source>备份/恢复</source>
        <translation type="unfinished">Respaldo/Restauración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="284"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="293"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="299"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="303"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="307"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="320"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="791"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="890"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="924"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="931"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="973"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2930"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3139"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3143"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3366"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3368"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3663"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3777"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3827"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4148"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4188"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4199"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4214"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4537"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4558"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4593"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4612"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4619"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4642"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4662"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4696"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4715"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4722"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4798"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4902"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5177"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5276"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5351"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5548"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5769"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5960"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="284"/>
        <source>获取节点名失败</source>
        <translation type="unfinished">No se pudo obtener el nombre del nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="293"/>
        <source>访问sysmdl失败</source>
        <translation type="unfinished">Fallo al acceder a sysmdl</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="299"/>
        <source>获取历史库应用失败</source>
        <translation type="unfinished">No se pudo obtener la aplicación de DB histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="303"/>
        <source>历史库应用不唯一</source>
        <translation type="unfinished">La aplicación de la base de datos histórica no es única</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="307"/>
        <source>历史库应用为空</source>
        <translation type="unfinished">La aplicación de la DB histórica está vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="320"/>
        <source>查找部署指定服务进程的节点名失败</source>
        <translation type="unfinished">No se encontró el nombre del nodo para desplegar el proceso de servicio especificado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="791"/>
        <source>请先断开当前连接，然后再选择其他节点</source>
        <translation type="unfinished">Desconecte la conexión actual antes de seleccionar otro nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="815"/>
        <source>IP: %1, 端口: %2</source>
        <translation type="unfinished">IP: %1, Puerto: %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="275"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="826"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="966"/>
        <source>连接</source>
        <translation type="unfinished">Conectar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="82"/>
        <source>同步</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Sinc</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="890"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4214"/>
        <source>获取%1节点表信息失败</source>
        <translation type="unfinished">Fallo al obtener la información de la tabla del nodo %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="984"/>
        <source>关系库(RDB)</source>
        <translation type="unfinished">RDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="987"/>
        <source>时序库(SDB)</source>
        <translation type="unfinished">SDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="990"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1023"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1030"/>
        <source>未知</source>
        <translation type="unfinished">Desconocido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="924"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="931"/>
        <source>连接%1节点库成功</source>
        <translation type="unfinished">Conexión exitosa a la base de datos %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="700"/>
        <source>开始下载导出文件...</source>
        <translation type="unfinished">Descargando archivo exportado...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="973"/>
        <source>已断开与%1节点库的连接</source>
        <translation type="unfinished">Desconectado de la biblioteca de nodos %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1178"/>
        <source>字段名</source>
        <translation type="unfinished">Nombre del campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1180"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1232"/>
        <source>字段类型</source>
        <translation type="unfinished">Tipo de campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1230"/>
        <source>字段名称</source>
        <translation type="unfinished">Nombre del campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1234"/>
        <source>对象内偏移</source>
        <translation type="unfinished">Desplazamiento interno del objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1913"/>
        <source>同步中</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Sincronizando</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2033"/>
        <source>%1 表 %2 无法同步 , 目标库不存在该表且无法建表</source>
        <translation type="unfinished">La tabla %1 %2 no se puede sincronizar. La tabla no existe en la base de datos de destino y no se puede crear.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2050"/>
        <source>%1 开始同步表: %2 (%3/%4)</source>
        <translation type="unfinished">%1 Iniciando la sincronización de la tabla: %2 (%3/%4)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2063"/>
        <source>%1 表 %2 无法同步 , 标签和主键不一致</source>
        <translation type="unfinished">La tabla %1 %2 no se puede sincronizar, la etiqueta y la clave primaria son inconsistentes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2113"/>
        <source>%1 表 %2 无法同步</source>
        <translation type="unfinished">La tabla %1 %2 no se pudo sincronizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2145"/>
        <source>%1 表 %2 同步成功</source>
        <translation type="unfinished">La tabla %1 %2 se sincronizó correctamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2158"/>
        <source>%1 表 %2 同步失败</source>
        <translation type="unfinished">Fallo en la sincronización de la tabla %1 %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2192"/>
        <source>表%1的分区策略为按3小时分区，采用15分钟分片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2197"/>
        <source>表%1的分区策略为按6小时分区，采用30分钟分片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2202"/>
        <source>表%1的分区策略为按12小时分区，采用1小时分片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2207"/>
        <source>表%1的分区策略为按天分区，采用2小时分片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2212"/>
        <source>表%1的分区策略为按月分区，采用1天分片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2217"/>
        <source>表%1的分区策略为按年分区，不分片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2221"/>
        <source>表%1的分区策略未知，不分片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2253"/>
        <source>生成 %1 个时间分片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2257"/>
        <source>不分片，整个时间范围作为一个批次</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2930"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3663"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3777"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3827"/>
        <source>获取表信息失败</source>
        <translation type="unfinished">Fallo al obtener la información de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3119"/>
        <source>是否删除表</source>
        <translation type="unfinished">Eliminar tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3120"/>
        <source>是否删除%1表</source>
        <translation type="unfinished">Eliminar tabla %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3127"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3128"/>
        <source>是否同步删除本现场其他节点</source>
        <translation type="unfinished">Desea eliminar sincrónicamente otros nodos en este sitio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3140"/>
        <source>删除%1表失败</source>
        <translation type="unfinished">Fallo al eliminar la tabla %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3144"/>
        <source>删除%1表成功</source>
        <translation type="unfinished">Eliminar tabla %1 con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3354"/>
        <source>是否清除</source>
        <translation type="unfinished">Borrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3355"/>
        <source>是否清除待同步信息</source>
        <translation type="unfinished">Limpiar la información para sincronizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3366"/>
        <source>清除失败</source>
        <translation type="unfinished">Limpiar fallido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3368"/>
        <source>清除成功</source>
        <translation type="unfinished">Borrado exitoso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3589"/>
        <source>待同步信息</source>
        <translation type="unfinished">Información para sincronizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4188"/>
        <source>只有一个历史库节点，无法进行同步</source>
        <translation type="unfinished">Solo un nodo de la BD histórica, no se puede sincronizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4198"/>
        <source>%1节点连接失败</source>
        <translation type="unfinished">Conexión fallida del nodo %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4213"/>
        <source>%1节点获取表信息失败</source>
        <translation type="unfinished">El nodo %1 no pudo recuperar la información de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4379"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4402"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5087"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5119"/>
        <source>数据文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4593"/>
        <source>请选择要导出的表</source>
        <translation type="unfinished">Seleccionar la tabla que desea exportar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4612"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4715"/>
        <source>结束时间必须大于开始时间</source>
        <translation type="unfinished">El tiempo de finalización debe ser mayor que el tiempo de inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4619"/>
        <source>请选择导出路径</source>
        <translation type="unfinished">Seleccione una ruta de exportación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4643"/>
        <source>部分数据已导入，后续数据是否取消导入？</source>
        <translation type="unfinished">Se han importado algunos datos. ¿Cancelar la importación de los datos restantes?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4696"/>
        <source>请选择要导入的表</source>
        <translation type="unfinished">Seleccionar la tabla que desea importar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4722"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6632"/>
        <source>请选择导入文件</source>
        <translation type="unfinished">Seleccione el archivo de importación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4746"/>
        <source>错误：未选择要导出的表</source>
        <translation type="unfinished">Error: No se ha seleccionado ninguna tabla para exportar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4857"/>
        <source>错误：未选择要导入的表</source>
        <translation type="unfinished">Error: No se ha seleccionado la tabla a importar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4989"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6690"/>
        <source>备份将对整个数据库进行全量备份，请选择备份文件保存路径</source>
        <translation type="unfinished">El respaldo realizará una copia de seguridad completa de toda la BD. Seleccione la ruta de guardado del archivo de respaldo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4990"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6694"/>
        <source>恢复将覆盖当前数据库中的数据，请谨慎操作</source>
        <translation type="unfinished">Realice esta operación con precaución porque los datos en la BD actual serán sobrescritos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5067"/>
        <source>选择备份目录</source>
        <translation type="unfinished">Seleccione el directorio de respaldo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5084"/>
        <source>保存备份文件</source>
        <translation type="unfinished">Guardar archivo de copia de seguridad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5107"/>
        <source>选择恢复目录</source>
        <translation type="unfinished">Seleccionar directorio de recuperación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5116"/>
        <source>选择恢复文件</source>
        <translation type="unfinished">Seleccionar archivo de recuperación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5177"/>
        <source>历史数据清理阈值更新成功</source>
        <translation type="unfinished">El umbral de limpieza de datos históricos se ha actualizado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5179"/>
        <source>历史数据清理阈值更新失败</source>
        <translation type="unfinished">Error al actualizar el umbral de limpieza de datos históricos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5179"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5288"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5317"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5364"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5393"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5400"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5864"/>
        <source>待计算</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6215"/>
        <source>选择计算剩余存储时间的时间单位（1小时/1天）</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6221"/>
        <source>1小时</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6222"/>
        <source>1天</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6245"/>
        <source>磁盘空间超过该值时，会自动清理历史库数据</source>
        <translation type="unfinished">Cuando el espacio en disco exceda este valor, los datos de la BD histórica se borrarán automáticamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6244"/>
        <source>数据天数超过该值后，会自动清理历史库数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4632"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4733"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5446"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5829"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4904"/>
        <source>导入已取消</source>
        <translation type="unfinished">Importación cancelada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4653"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4859"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4929"/>
        <source>导入</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Importar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4661"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4662"/>
        <source>导入取消失败</source>
        <translation type="unfinished">Error al cancelar la importación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4795"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4798"/>
        <source>导出失败</source>
        <translation type="unfinished">Exportación fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4805"/>
        <source>导出取消完成，已删除导出文件</source>
        <translation type="unfinished">Exportación cancelada, archivo exportado eliminado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4811"/>
        <source>历史数据导出成功，耗时: %1 秒</source>
        <translation type="unfinished">Exportación de datos históricos exitosa, tiempo transcurrido: %1 segundos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="7032"/>
        <source>历史数据导出中，已耗时: %1 秒</source>
        <translation type="unfinished">Exportación de datos históricos en progreso, tiempo transcurrido: %1 segundos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4899"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4902"/>
        <source>导入失败</source>
        <translation type="unfinished">Importación fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4912"/>
        <source>历史数据导入成功，耗时: %1 秒</source>
        <translation type="unfinished">Importación de datos históricos exitosa, tiempo transcurrido: %1 segundos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="7036"/>
        <source>历史数据导入中，已耗时: %1 秒</source>
        <translation type="unfinished">Importación de datos históricos en progreso, tiempo transcurrido: %1 segundos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5277"/>
        <source>是否取消备份？</source>
        <translation type="unfinished">¿Desea cancelar la copia de seguridad?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5287"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5288"/>
        <source>取消备份失败</source>
        <translation type="unfinished">Error al cancelar la copia de seguridad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5317"/>
        <source>请先选择备份文件保存路径</source>
        <translation type="unfinished">Seleccione una ruta para guardar el archivo de respaldo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5324"/>
        <source>是否开始备份，耗时可能较长，请确认是否继续。</source>
        <translation type="unfinished">¿Desea iniciar la copia de seguridad? Puede tomar mucho tiempo, por favor confirme si desea continuar.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5332"/>
        <source>正在准备备份...</source>
        <translation type="unfinished">Preparando una copia de seguridad...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5361"/>
        <source>恢复任务已取消，等待启动历史应用</source>
        <translation type="unfinished">La tarea de recuperación ha sido cancelada, esperando para iniciar la aplicación histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5363"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5364"/>
        <source>取消恢复失败</source>
        <translation type="unfinished">Cancelar recuperación falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5393"/>
        <source>请先选择恢复文件</source>
        <translation type="unfinished">Seleccione primero el archivo de recuperación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5415"/>
        <source>正在准备恢复...</source>
        <translation type="unfinished">Preparando para reanudar...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5427"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5664"/>
        <source>错误：未连接数据库</source>
        <translation type="unfinished">Error: La BD no está conectada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5429"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5527"/>
        <source>备份</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Respaldo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5434"/>
        <source>开始备份...</source>
        <translation type="unfinished">Iniciando respaldo...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5435"/>
        <source>备份过程中请勿关闭窗口</source>
        <translation type="unfinished">No cierre la ventana durante la copia de seguridad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5546"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5548"/>
        <source>备份失败</source>
        <translation type="unfinished">Error en la copia de seguridad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5558"/>
        <source>备份取消完成，已删除备份文件</source>
        <translation type="unfinished">Cancelación de respaldo completada, los archivos de respaldo han sido eliminados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5563"/>
        <source>历史数据备份成功，耗时: %1 秒</source>
        <translation type="unfinished">La copia de seguridad de los datos históricos fue exitosa. Tiempo de consumo: %1 segundo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="7040"/>
        <source>历史数据备份中，已耗时: %1 秒</source>
        <translation type="unfinished">Copia de seguridad de datos históricos en progreso, tiempo transcurrido: %1 segundos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5666"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5704"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5732"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5786"/>
        <source>恢复</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Recuperar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5671"/>
        <source>开始恢复...</source>
        <translation type="unfinished">Iniciando recuperación...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5672"/>
        <source>恢复过程中请勿关闭窗口</source>
        <translation type="unfinished">No cierre la ventana durante la restauración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5673"/>
        <source>历史库应用正在切离线...</source>
        <translation type="unfinished">La aplicación de la BD histórica se está desconectando...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5699"/>
        <source>历史库应用切离线失败</source>
        <translation type="unfinished">Error al desconectar la aplicación de la BD histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5707"/>
        <source>历史库应用切离线成功</source>
        <translation type="unfinished">La aplicación de la DB histórica se ha desconectado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5729"/>
        <source>错误：恢复文件路径为空</source>
        <translation type="unfinished">Error: La ruta del archivo de recuperación está vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5756"/>
        <source>历史库应用启动成功</source>
        <translation type="unfinished">La aplicación de la BD histórica se inició con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5759"/>
        <source>历史库应用启动失败</source>
        <translation type="unfinished">Error al iniciar la aplicación de la BD histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5771"/>
        <source>恢复已取消</source>
        <translation type="unfinished">Recuperación cancelada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5861"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5882"/>
        <source>剩余空间不足，将自动删除旧数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5929"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6136"/>
        <source>历史库容量估计</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5930"/>
        <source>历史库容量估计（剩余容量不足）</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5960"/>
        <source>请先连接数据库</source>
        <translation type="unfinished">Conéctese a la BD primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5876"/>
        <source>%1 年</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5877"/>
        <source>%1 月</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 M</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5878"/>
        <source>%1 天</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 D</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5879"/>
        <source>%1 小时</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 H</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5352"/>
        <source>取消恢复可能导致历史数据库损坏，是否继续？</source>
        <translation type="unfinished">Cancelar la recuperación puede causar daños a la BD histórica. ¿Desea continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5401"/>
        <source>恢复操作将清空数据库中的现有数据再恢复，且本节点hisdb应用将切离线，是否继续？</source>
        <translation type="unfinished">La operación de recuperación borrará los datos existentes en la BD antes de la recuperación, y la aplicación hisdb en este nodo estará fuera de línea. ¿Desea continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5765"/>
        <source>恢复文件不合法，请检查文件是否正确</source>
        <translation type="unfinished">La restauración de archivos es ilegal. Verifique si los archivos son correctos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5767"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5769"/>
        <source>恢复失败</source>
        <translation type="unfinished">Restauración fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5777"/>
        <source>历史数据恢复成功，耗时: %1 秒</source>
        <translation type="unfinished">Recuperación de datos históricos exitosa, tiempo transcurrido: %1 segundos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="7044"/>
        <source>历史数据恢复中，已耗时: %1 秒</source>
        <translation type="unfinished">Recuperación de datos históricos en progreso, tiempo transcurrido: %1 segundos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6021"/>
        <source>历史库基础信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2177"/>
        <source>%1 表不存在或获取表信息失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2228"/>
        <source>%1 表的时间字段异常</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2239"/>
        <source>时间范围无效: 开始时间 &gt;= 结束时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2270"/>
        <source>开始扫描时间分片数据...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2277"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2351"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2393"/>
        <source>同步已取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2325"/>
        <source>没有需要同步的数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2330"/>
        <source>扫描完成，总计 %1 个时间分片，%2 条数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2378"/>
        <source>同步时间片 %1/%2: %3 (%4条数据)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2414"/>
        <source>查询失败: 时间片 %1, 批次 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2430"/>
        <source>插入失败: 时间片 %1, 批次 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2449"/>
        <source>已处理 %1/%2 条数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2466"/>
        <source>时间片 %1 同步完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2470"/>
        <source>%1 表同步完成，共处理 %2 个时间分片，%3 条数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6119"/>
        <source>数据库节点</source>
        <translation type="unfinished">Nodo de BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6120"/>
        <source>数据库型号</source>
        <translation type="unfinished">Tipo de BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6121"/>
        <source>数据库名称</source>
        <translation type="unfinished">Nombre de la BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6122"/>
        <source>数据库版本</source>
        <translation type="unfinished">Versión de la BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6123"/>
        <source>数据库类型</source>
        <translation type="unfinished">Tipo de BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6124"/>
        <source>当前连接时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6192"/>
        <source>历史库磁盘完整容量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6193"/>
        <source>历史库磁盘当前使用容量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6194"/>
        <source>历史库磁盘剩余容量</source>
        <translation type="unfinished">Capacidad de disco restante de la BD histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6196"/>
        <source>历史库当前容量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6214"/>
        <source>存储计算时间依据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6235"/>
        <source>计算基准容量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6237"/>
        <source>计算基准容量记录时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6242"/>
        <source>历史库数据保留天数</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6242"/>
        <source>历史库磁盘清理阈值</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6292"/>
        <source>历史库理论剩余容量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6296"/>
        <source>历史库理论剩余可存时间</source>
        <translation type="unfinished">Tiempo teórico restante de almacenamiento de la BD histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6628"/>
        <source>请选择要导出的表和导出路径</source>
        <translation type="unfinished">Seleccionar la tabla a exportar y la ruta de exportación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="871"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="949"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3623"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3732"/>
        <source>总共0条数据</source>
        <translation type="unfinished">Total 0 elementos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="896"/>
        <source>断开</source>
        <translation type="unfinished">Desconectar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1131"/>
        <source>查询字段异常</source>
        <translation type="unfinished">Excepción del campo de consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1133"/>
        <source>查询字段：%1</source>
        <translation type="unfinished">Campo de consulta: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1179"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1231"/>
        <source>字段别名</source>
        <translation type="unfinished">Alias del campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1181"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1233"/>
        <source>字段长度</source>
        <translation type="unfinished">Longitud del campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2000"/>
        <source>%1 表 %2 转换为实时库表名失败</source>
        <translation type="unfinished">%1 tabla %2 conversión a nombre de tabla TDB fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3110"/>
        <source>删除表</source>
        <comment>menuName</comment>
        <translation type="unfinished">Eliminar tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3600"/>
        <source>待同步数据</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Datos no Sincronizados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3601"/>
        <source>待同步表结构</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Estructura de Tabla no Sincronizada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4148"/>
        <source>请先连接一个库节点</source>
        <translation type="unfinished">Por favor, conecte primero un nodo de biblioteca</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4199"/>
        <source>打开%1节点失败</source>
        <translation type="unfinished">Fallo al abrir el nodo %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4376"/>
        <source>选择导出路径</source>
        <translation type="unfinished">Seleccionar ruta de exportación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4399"/>
        <source>选择导入文件</source>
        <translation type="unfinished">Seleccionar archivo de importación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4428"/>
        <source>获取文件中的表信息失败，错误码：%1</source>
        <translation type="unfinished">Error al obtener la información de la tabla en el archivo con el código de error %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4443"/>
        <source>获取文件中的时间范围失败，错误码：%1</source>
        <translation type="unfinished">Error al obtener el rango de tiempo en el archivo con el código de error %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4456"/>
        <source>成功加载文件，包含%1张表，时间范围：%2 ~ %3</source>
        <translation type="unfinished">Archivo cargado con éxito incluyendo %1 tablas, rango de tiempo: %2 ~ %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4538"/>
        <source>是否取消导出？</source>
        <translation type="unfinished">¿Desea cancelar la exportación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4548"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4748"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4829"/>
        <source>导出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exportar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4557"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4558"/>
        <source>导出取消失败</source>
        <translation type="unfinished">Error al cancelar la exportación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/main.cpp" line="38"/>
        <source>历史库管理工具</source>
        <translation type="unfinished">Herramienta de Gestión de la BD de Historial</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::ExpireTimeDialog</name>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/expire_time_dialog.cpp" line="20"/>
        <source>修改数据过期时间</source>
        <translation type="unfinished">Modificar el tiempo de expiración de los datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/expire_time_dialog.cpp" line="33"/>
        <source>自定义时间</source>
        <translation type="unfinished">Tiempo personalizado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/expire_time_dialog.cpp" line="34"/>
        <source>磁盘空间不足时清理</source>
        <translation type="unfinished">Limpieza por espacio en disco bajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/expire_time_dialog.cpp" line="34"/>
        <source>按数据保留天数清理</source>
        <translation type="unfinished">Limpiar por días de retención de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/expire_time_dialog.cpp" line="47"/>
        <source>小时</source>
        <translation type="unfinished">Hora</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/expire_time_dialog.cpp" line="47"/>
        <source>天</source>
        <translation type="unfinished">Día</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/expire_time_dialog.cpp" line="47"/>
        <source>月</source>
        <translation type="unfinished">Mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/expire_time_dialog.cpp" line="47"/>
        <source>年</source>
        <translation type="unfinished">Año</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::sdb_mgr_main</name>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="403"/>
        <source>获取数据类型枚举失败</source>
        <translation type="unfinished">Fallo al obtener la enumeración de tipo de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="77"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1801"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1803"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1907"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2774"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2798"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2869"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2873"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2878"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2912"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2918"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2924"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2947"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2989"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2993"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3173"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3260"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3265"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3284"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3289"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3308"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3313"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3332"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3337"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3348"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3414"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3545"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3551"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3555"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3559"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3577"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3581"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3703"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3822"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3869"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5245"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1400"/>
        <source>数据过期时间:</source>
        <translation type="unfinished">Tiempo de expiración de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1402"/>
        <source>修改</source>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1907"/>
        <source>请选择要同步的表</source>
        <translation type="unfinished">Por favor, seleccione la tabla para sincronizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="77"/>
        <source>同步完成</source>
        <translation type="unfinished">Sincronización completada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="107"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1803"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2912"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3551"/>
        <source>请先连接数据库</source>
        <translation type="unfinished">Conéctese a la BD primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1313"/>
        <source>未找到表信息</source>
        <translation type="unfinished">Información de la tabla no encontrada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2824"/>
        <source>表基本信息</source>
        <translation type="unfinished">Información básica de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1357"/>
        <source>表名:</source>
        <translation type="unfinished">Nombre de la tabla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="112"/>
        <source>操作步骤:</source>
        <translation type="unfinished">Pasos de operación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="112"/>
        <source>1. 选择要连接的节点</source>
        <translation type="unfinished">1. Seleccionar el nodo a conectar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="112"/>
        <source>2. 点击&apos;连接&apos;按钮</source>
        <translation type="unfinished">2. Haga clic en el botón &apos;Conectar&apos;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="113"/>
        <source>3. 连接成功后即可进行数据查询和管理</source>
        <translation type="unfinished">3. Después de una conexión exitosa, se puede llevar a cabo la consulta y gestión de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1328"/>
        <source>表基本信息</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Info de la Tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1366"/>
        <source>别名:</source>
        <translation type="unfinished">Alias:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1370"/>
        <source>未设置别名</source>
        <translation type="unfinished">No se ha establecido alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1377"/>
        <source>建表方式:</source>
        <translation type="unfinished">Método de creación de tabla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1380"/>
        <source>对象建表</source>
        <translation type="unfinished">Crear tabla de objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1380"/>
        <source>列建表</source>
        <translation type="unfinished">Crear tabla de columna</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1394"/>
        <source>是</source>
        <translation type="unfinished">Verdadero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1394"/>
        <source>否</source>
        <translation type="unfinished">Falso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5201"/>
        <source>按数据保留天数清理</source>
        <translation type="unfinished">Limpiar por días de retención de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1415"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5204"/>
        <source>磁盘空间不足时清理</source>
        <translation type="unfinished">Limpieza por espacio en disco bajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1389"/>
        <source>oid作时间戳列:</source>
        <translation type="unfinished">OID como col de marca de tiempo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1410"/>
        <source>按保留天数清理</source>
        <translation type="unfinished">Limpiar por días de retención</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1420"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5207"/>
        <source>永不删除</source>
        <translation type="unfinished">Nunca eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1469"/>
        <source>时序库参数</source>
        <translation type="unfinished">Parámetros STDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1520"/>
        <source>标签列表:</source>
        <translation type="unfinished">Lista de etiquetas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1545"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1637"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1687"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1759"/>
        <source>无</source>
        <translation type="unfinished">Ninguno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1560"/>
        <source>关系库参数</source>
        <translation type="unfinished">Parámetros RDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1612"/>
        <source>主键列表:</source>
        <translation type="unfinished">Lista de claves primarias:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1643"/>
        <source>索引列表:</source>
        <translation type="unfinished">Lista de índices:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1713"/>
        <source>分区字段:</source>
        <translation type="unfinished">Campo de partición:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1716"/>
        <source>分区类型:</source>
        <translation type="unfinished">Tipo de partición:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1727"/>
        <source>无分区</source>
        <translation type="unfinished">Sin partición</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1730"/>
        <source>按年分区</source>
        <translation type="unfinished">Zonificación anual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1733"/>
        <source>按月分区</source>
        <translation type="unfinished">Dividir por mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1736"/>
        <source>按天分区</source>
        <translation type="unfinished">Dividir por día</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1748"/>
        <source>未知分区类型</source>
        <translation type="unfinished">Tipo de partición desconocido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2542"/>
        <source>列名: %1 的数据类型不匹配!</source>
        <translation type="unfinished">Nombre de columna: ¡%1 tiene incompatibilidad de tipo de datos!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2543"/>
        <source>源数据类型: %1</source>
        <translation type="unfinished">Tipo de datos de origen: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2544"/>
        <source>目标数据类型: %3</source>
        <translation type="unfinished">Tipo de datos de destino: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2551"/>
        <source>列名: %1 的数据长度不匹配!</source>
        <translation type="unfinished">Nombre de columna: ¡La longitud de los datos %1 no coincide!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2552"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2645"/>
        <source>源数据长度: %1</source>
        <translation type="unfinished">Longitud de los datos de origen: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2553"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2646"/>
        <source>目标数据长度: %3</source>
        <translation type="unfinished">Longitud de datos de destino: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2643"/>
        <source>字符串: %1 的源数据长度小于目的数据长度!</source>
        <translation type="unfinished">Cadena: ¡La longitud de los datos de origen de %1 es menor que la longitud de los datos de destino!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2774"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3265"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3313"/>
        <source>已经是第一页</source>
        <translation type="unfinished">Ya está en la primera página</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2798"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3289"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3337"/>
        <source>已经是最后一页</source>
        <translation type="unfinished">Ya está en la última página</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5245"/>
        <source>数据过期时间设置成功</source>
        <translation type="unfinished">Tiempo de expiración de datos establecido con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5266"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5266"/>
        <source>设置数据过期时间失败</source>
        <translation type="unfinished">Error al establecer el tiempo de expiración de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5853"/>
        <source>%1天</source>
        <translation type="unfinished">%1 días</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6271"/>
        <source>历史库自动清理阈值，范围是20-95%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6295"/>
        <source>历史库理论剩余容量，根据当前磁盘使用情况和清理阈值计算</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6298"/>
        <source>历史库理论剩余可存时间，根据历史库理论剩余容量与近期历史库数据增长计算</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1801"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2918"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3555"/>
        <source>请选择要查询的表</source>
        <translation type="unfinished">Por favor, seleccione la tabla para consultar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1435"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5222"/>
        <source>%1 年</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1437"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5224"/>
        <source>%1 月</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 M</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1439"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5226"/>
        <source>%1 天</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 D</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1441"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5228"/>
        <source>%1 小时</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 H</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1443"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5230"/>
        <source>%1 分钟</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 Min</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1445"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5233"/>
        <source>%1 秒</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 Seg</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1739"/>
        <source>按3小时分区</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1742"/>
        <source>按6小时分区</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1745"/>
        <source>按12小时分区</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2809"/>
        <source>表信息查询</source>
        <translation type="unfinished">Consulta de información de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2869"/>
        <source>查询表结构失败</source>
        <translation type="unfinished">Error al consultar la estructura de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2873"/>
        <source>查询表元数据失败</source>
        <translation type="unfinished">Error al consultar los metadatos de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2878"/>
        <source>查询表基本信息失败</source>
        <translation type="unfinished">Error al consultar la información básica de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2884"/>
        <source>关闭</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2924"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3559"/>
        <source>开始时间不能大于结束时间</source>
        <translation type="unfinished">La hora de inicio no puede ser mayor que la hora de finalización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2944"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3390"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3670"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3784"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3834"/>
        <source>总共%1条数据</source>
        <translation type="unfinished">Total %1 elementos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2946"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2947"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2989"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3260"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3284"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3308"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3332"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3388"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3414"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3672"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3703"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3786"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3822"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3836"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3869"/>
        <source>查询失败</source>
        <translation type="unfinished">Consulta fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2993"/>
        <source>查询成功</source>
        <translation type="unfinished">Consulta exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3173"/>
        <source>获取表信息失败</source>
        <translation type="unfinished">Fallo al obtener la información de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3249"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3273"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3297"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3321"/>
        <source>Page %1 of %2</source>
        <translation type="unfinished">Página %1 de %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3348"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3577"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3582"/>
        <source>没有%1表</source>
        <translation type="unfinished">La tabla %1 no existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3545"/>
        <source>页数不合法</source>
        <translation type="unfinished">Número de páginas no válido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3613"/>
        <source>清除所有数据</source>
        <comment>menuName</comment>
        <translation type="unfinished">Borr todo dat</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3717"/>
        <source>Context Menu</source>
        <translation type="unfinished">Menú Contextual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3678"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3792"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3842"/>
        <source>Page 1 of %1</source>
        <translation type="unfinished">Página 1 de %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2839"/>
        <source>列信息（列建表）</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Info de Col (Crear Tabla de Col)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2853"/>
        <source>列信息（对象建表）</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Info de Col (Crear Tabla de Objeto)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3680"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3795"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3844"/>
        <source>Page 1 of 1</source>
        <translation type="unfinished">Página 1 de 1</translation>
    </message>
</context>
<context>
    <name>sdb_mgr_main</name>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="51"/>
        <source>库节点</source>
        <translation type="unfinished">Nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="147"/>
        <source>连接</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Conectar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="169"/>
        <source>数据查询</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Consultar Datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="180"/>
        <source>表名</source>
        <translation type="unfinished">Nombre de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="207"/>
        <source>查询时段：      </source>
        <translation type="unfinished">Período de consulta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="214"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="228"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="473"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="487"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="725"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="739"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="939"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="953"/>
        <source>yyyy/M/d HH:mm:ss</source>
        <translation type="unfinished">yyyy/M/d HH:mm:ss</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="267"/>
        <source>总共0条数据</source>
        <translation type="unfinished">Total 0 elementos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="304"/>
        <source>条件字符串：    </source>
        <translation type="unfinished">Cadena de condiciones:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="340"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="373"/>
        <source>表信息</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Info de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="406"/>
        <source>SQL</source>
        <comment>buttonName</comment>
        <translation type="unfinished">SQL</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="430"/>
        <source>数据同步</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Sinc de Datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="533"/>
        <source>同步</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Sinc</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="577"/>
        <source>详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Detalles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="610"/>
        <source>待同步信息</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Datos no sincronizados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="666"/>
        <source>导入/导出</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">I/E</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="676"/>
        <source>导出</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Exportar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="786"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="887"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1075"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1186"/>
        <source>选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Seleccionar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="826"/>
        <source>导出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exportar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="843"/>
        <source>导入</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Importar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1000"/>
        <source>导入</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Importar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1021"/>
        <source>备份/恢复</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Respaldo/Restauración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1031"/>
        <source>备份</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Respaldo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1125"/>
        <source>备份</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Respaldo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1142"/>
        <source>恢复</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Recuperar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1239"/>
        <source>恢复</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Recuperar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1260"/>
        <source>历史库信息</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Info de la BD Histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="438"/>
        <source>节点：</source>
        <translation type="unfinished">Nodo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="445"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="459"/>
        <source>未连接库</source>
        <translation type="unfinished">Base de datos no conectada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="466"/>
        <source>时段：</source>
        <translation type="unfinished">Hora:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="246"/>
        <source>查询字段：</source>
        <translation type="unfinished">Campos de consulta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="621"/>
        <source>源表名</source>
        <translation type="unfinished">Nombre de la tabla de origen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="631"/>
        <source>目的表名</source>
        <translation type="unfinished">Nombre de la tabla de destino</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="641"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="704"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="918"/>
        <source>全选</source>
        <translation type="unfinished">Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="684"/>
        <source>选择导出表：</source>
        <translation type="unfinished">Seleccionar la tabla de exportación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="718"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="932"/>
        <source>时间范围：</source>
        <translation type="unfinished">Rango de tiempo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="750"/>
        <source>导出路径：</source>
        <translation type="unfinished">Ruta de exportación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="851"/>
        <source>导入文件：</source>
        <translation type="unfinished">Importar archivo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="898"/>
        <source>选择导入表：</source>
        <translation type="unfinished">Seleccionar la tabla de importación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="964"/>
        <source>覆盖现有数据</source>
        <translation type="unfinished">Sobrescribir datos actuales</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1039"/>
        <source>备份文件路径：</source>
        <translation type="unfinished">Ruta del archivo de respaldo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1084"/>
        <source>备份将对整个数据库进行全量备份，包括所有表和所有时间范围的数据</source>
        <translation type="unfinished">La copia de seguridad realizará un respaldo completo de toda la BD, incluyendo todas las tablas y datos para todos los rangos de tiempo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1150"/>
        <source>恢复文件：</source>
        <translation type="unfinished">Recuperar archivos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1198"/>
        <source>警告：恢复操作将覆盖数据库中的现有数据，请谨慎操作！</source>
        <translation type="unfinished">Advertencia: La operación de recuperación sobrescribirá los datos existentes en la BD, ¡por favor tenga cuidado!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1284"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="76"/>
        <source>库名称</source>
        <translation type="unfinished">Nombre de la base de datos</translation>
    </message>
</context>
</TS>
