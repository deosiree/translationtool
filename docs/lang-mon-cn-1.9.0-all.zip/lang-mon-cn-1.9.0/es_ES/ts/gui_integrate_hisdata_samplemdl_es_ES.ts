<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>HisSampleEditor</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_editor.ui" line="26"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_editor.ui" line="40"/>
        <source>别名</source>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_editor.ui" line="54"/>
        <source>是否起效</source>
        <translation type="unfinished">Eficaz</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_editor.ui" line="62"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_editor.ui" line="67"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_editor.ui" line="79"/>
        <source>时间单位</source>
        <translation type="unfinished">Unidad de tiempo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_editor.ui" line="121"/>
        <source>重置</source>
        <translation type="unfinished">Restablecer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_editor.ui" line="128"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
</context>
<context>
    <name>HisSampleObjectEditor</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_object_editor.ui" line="32"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_object_editor.ui" line="49"/>
        <source>存储周期（分钟）</source>
        <translation type="unfinished">Ciclo de almacenamiento (min)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_object_editor.ui" line="60"/>
        <source>是否起效</source>
        <translation type="unfinished">Eficaz</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_object_editor.ui" line="68"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_object_editor.ui" line="73"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_object_editor.ui" line="113"/>
        <source>重置</source>
        <translation type="unfinished">Restablecer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_object_editor.ui" line="120"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.cpp" line="591"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.cpp" line="619"/>
        <source>打开 %1 库失败</source>
        <translation type="unfinished">No se pudo abrir la biblioteca %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.cpp" line="592"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.cpp" line="620"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
</context>
<context>
    <name>SampleModelMain</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.ui" line="41"/>
        <source>当前应用</source>
        <translation type="unfinished">Aplicación actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.ui" line="60"/>
        <source>采样存储表</source>
        <translation type="unfinished">Tabla de muestreo</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::AddTableColoumnDialog</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_column_dialog.cpp" line="11"/>
        <source>采样存储列选择器</source>
        <translation type="unfinished">Selector de columnas de almacenamiento de muestras</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_column_dialog.cpp" line="35"/>
        <source>表名</source>
        <translation type="unfinished">Nombre de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_column_dialog.cpp" line="43"/>
        <source>同时存事件</source>
        <translation type="unfinished">Almacenamiento de eventos simultáneos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_column_dialog.cpp" line="47"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_column_dialog.cpp" line="48"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_column_dialog.cpp" line="68"/>
        <source>帮助</source>
        <translation type="unfinished">Ayuda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_column_dialog.cpp" line="74"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_column_dialog.cpp" line="80"/>
        <source>退出</source>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_column_dialog.cpp" line="304"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_column_dialog.cpp" line="308"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_column_dialog.cpp" line="304"/>
        <source>保存成功!</source>
        <translation type="unfinished">¡Guardado exitosamente!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_column_dialog.cpp" line="308"/>
        <source>保存失败!</source>
        <translation type="unfinished">¡Fallo al guardar!</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::AddTableDialog</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_dialog.cpp" line="11"/>
        <source>采样存储列选择器</source>
        <translation type="unfinished">Selector de columnas de almacenamiento de muestras</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_dialog.cpp" line="17"/>
        <source>应用名</source>
        <translation type="unfinished">Nombre de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_dialog.cpp" line="21"/>
        <source>库名</source>
        <translation type="unfinished">Nombre de la base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_dialog.cpp" line="35"/>
        <source>表名</source>
        <translation type="unfinished">Nombre de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_dialog.cpp" line="39"/>
        <source>同时存事件</source>
        <translation type="unfinished">Almacenamiento de eventos simultáneos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_dialog.cpp" line="43"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_dialog.cpp" line="44"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_dialog.cpp" line="64"/>
        <source>帮助</source>
        <translation type="unfinished">Ayuda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_dialog.cpp" line="70"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_dialog.cpp" line="76"/>
        <source>退出</source>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_dialog.cpp" line="318"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_dialog.cpp" line="322"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_dialog.cpp" line="318"/>
        <source>保存成功!</source>
        <translation type="unfinished">¡Guardado exitosamente!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/add_table_dialog.cpp" line="322"/>
        <source>保存失败!</source>
        <translation type="unfinished">¡Fallo al guardar!</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::HisAddDialog</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_add_dialog.cpp" line="11"/>
        <source>存储列选择器</source>
        <translation type="unfinished">Selector de columna almacenada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_add_dialog.cpp" line="17"/>
        <source>应用名</source>
        <translation type="unfinished">Nombre de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_add_dialog.cpp" line="21"/>
        <source>库名</source>
        <translation type="unfinished">Nombre de la base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_add_dialog.cpp" line="36"/>
        <source>表名</source>
        <translation type="unfinished">Nombre de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_add_dialog.cpp" line="40"/>
        <source>同时存事件</source>
        <translation type="unfinished">Almacenamiento de eventos simultáneos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_add_dialog.cpp" line="44"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_add_dialog.cpp" line="45"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_add_dialog.cpp" line="65"/>
        <source>帮助</source>
        <translation type="unfinished">Ayuda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_add_dialog.cpp" line="71"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_add_dialog.cpp" line="77"/>
        <source>退出</source>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_add_dialog.cpp" line="355"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_add_dialog.cpp" line="359"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_add_dialog.cpp" line="355"/>
        <source>保存成功!</source>
        <translation type="unfinished">¡Guardado exitosamente!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_add_dialog.cpp" line="359"/>
        <source>保存失败!</source>
        <translation type="unfinished">¡Fallo al guardar!</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::HisSampleColumnModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_column_model.cpp" line="137"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_column_model.cpp" line="155"/>
        <source>获取枚举失败</source>
        <translation type="unfinished">Fallo al obtener enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_column_model.cpp" line="149"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_column_model.cpp" line="163"/>
        <source>未配置</source>
        <translation type="unfinished">No configurado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_column_model.cpp" line="360"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_column_model.cpp" line="392"/>
        <source>唯一标识</source>
        <translation type="unfinished">ID único</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::HisSampleObjectModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_object_model.cpp" line="367"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_object_model.cpp" line="394"/>
        <source>唯一标识</source>
        <translation type="unfinished">ID único</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::HisSampleTableModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_table_model.cpp" line="163"/>
        <source>获取枚举失败</source>
        <translation type="unfinished">Fallo al obtener enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_table_model.cpp" line="175"/>
        <source>未配置</source>
        <translation type="unfinished">No configurado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_table_model.cpp" line="214"/>
        <source>不清理</source>
        <translation type="unfinished">No limpiar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_table_model.cpp" line="218"/>
        <source>历史库磁盘清理</source>
        <translation type="unfinished">Limpieza de disco de la BD histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_table_model.cpp" line="234"/>
        <source>年</source>
        <translation type="unfinished">año</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_table_model.cpp" line="240"/>
        <source>月</source>
        <translation type="unfinished">mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_table_model.cpp" line="246"/>
        <source>天</source>
        <translation type="unfinished">Día</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_table_model.cpp" line="252"/>
        <source>小时</source>
        <translation type="unfinished">Hora</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_table_model.cpp" line="257"/>
        <source>秒</source>
        <translation type="unfinished">seg</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_table_model.cpp" line="556"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/his_sample_table_model.cpp" line="589"/>
        <source>唯一标识</source>
        <translation type="unfinished">ID único</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::SampleModelMain</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.cpp" line="140"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.cpp" line="584"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.cpp" line="612"/>
        <source>采样存储表</source>
        <translation type="unfinished">Tabla de muestreo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.cpp" line="279"/>
        <source>采样存储列</source>
        <translation type="unfinished">Columna de muestreo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.cpp" line="284"/>
        <source>采样存储对象</source>
        <translation type="unfinished">Objeto de muestreo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.cpp" line="485"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.cpp" line="489"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.cpp" line="568"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.cpp" line="485"/>
        <source>更新记录成功</source>
        <translation type="unfinished">Registro actualizado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.cpp" line="489"/>
        <source>更新记录失败</source>
        <translation type="unfinished">Fallo al actualizar el registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/sample_model_main.cpp" line="568"/>
        <source>切换的应用名称不符合规则</source>
        <translation type="unfinished">El nombre de la aplicación cambiada no cumple con las reglas</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::TableColoumnModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/table_coloumn_model.cpp" line="46"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/table_coloumn_model.cpp" line="48"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/table_coloumn_model.cpp" line="50"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/table_coloumn_model.cpp" line="52"/>
        <source>主键列</source>
        <translation type="unfinished">Columna clave primaria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/table_coloumn_model.cpp" line="54"/>
        <source>当前是否存历史</source>
        <translation type="unfinished">Guardar como historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/table_coloumn_model.cpp" line="86"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/table_coloumn_model.cpp" line="94"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/table_coloumn_model.cpp" line="88"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_samplemdlcfg/src/table_coloumn_model.cpp" line="98"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
</context>
</TS>
