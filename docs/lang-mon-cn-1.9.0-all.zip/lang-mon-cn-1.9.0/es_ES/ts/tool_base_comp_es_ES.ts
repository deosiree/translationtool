<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>DlgAgainLogin</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/dlg_again_login.cpp" line="15"/>
        <source>验证</source>
        <comment>toolName</comment>
        <translation type="unfinished">Verificar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/dlg_again_login.cpp" line="24"/>
        <source>用户名:</source>
        <translation type="unfinished">Nombre de usuario:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/dlg_again_login.cpp" line="33"/>
        <source>密码:</source>
        <translation type="unfinished">Contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/dlg_again_login.cpp" line="36"/>
        <source>请输入密码</source>
        <translation type="unfinished">Ingrese su contraseña</translation>
    </message>
</context>
<context>
    <name>iasp::smg::BaseTableWidget</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="206"/>
        <source>新增</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="208"/>
        <source>单行新增，快捷键为Ctrl + N</source>
        <translation type="unfinished">Agregar individualmente, la tecla de acceso rápido es Ctrl+N</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="209"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="211"/>
        <source>删除，快捷键为Ctrl + D</source>
        <translation type="unfinished">Eliminar, la tecla de acceso rápido es Ctrl+D</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="212"/>
        <source>刷新</source>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="214"/>
        <source>执行刷新，快捷键为Ctrl + R</source>
        <translation type="unfinished">Actualizar, la tecla de acceso rápido es Ctrl+R</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="215"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="217"/>
        <source>执行刷新，快捷键为Ctrl + S</source>
        <translation type="unfinished">Actualizar, la tecla de acceso rápido es Ctrl+S</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="221"/>
        <source>批量新增</source>
        <translation type="unfinished">Alta masiva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="223"/>
        <source>批量新增，快捷键为Ctrl + Q</source>
        <translation type="unfinished">Agregar en Lote, la tecla de acceso rápido es Ctrl+Q</translation>
    </message>
</context>
<context>
    <name>iasp::smg::BaseTree</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_tree.cpp" line="67"/>
        <source>全部展开</source>
        <translation type="unfinished">Expansión completa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_tree.cpp" line="69"/>
        <source>全部折叠</source>
        <translation type="unfinished">Colapsar todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_tree.cpp" line="71"/>
        <source>刷新</source>
        <translation type="unfinished">Actualizar</translation>
    </message>
</context>
<context>
    <name>iasp::smg::CommonMethod</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/common_method.cpp" line="113"/>
        <source>选择导出目录</source>
        <translation type="unfinished">Seleccionar dir. de exportación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/common_method.cpp" line="130"/>
        <source>文件已存在</source>
        <translation type="unfinished">Archivo ya existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/common_method.cpp" line="131"/>
        <source>导出目录中已经存在 %1 文件，是否覆盖</source>
        <translation type="unfinished">Archivo %1 ya existe en dir., ¿sobrescribir?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/common_method.cpp" line="162"/>
        <source>选择导入文件</source>
        <translation type="unfinished">Seleccionar archivo a importar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/common_method.cpp" line="164"/>
        <source>JSON 文件</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>iasp::smg::IntegerLineEdit</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/integer_lineedit.cpp" line="18"/>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/integer_lineedit.cpp" line="49"/>
        <source>请输入数字（范围1～10）</source>
        <translation type="unfinished">Ingrese núm. (rango 1-10)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/integer_lineedit.cpp" line="49"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
</context>
</TS>
