<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>AllDirInfo</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/alldirinfo.ui" line="28"/>
        <source>目录名：</source>
        <translation type="unfinished">Nombre de directorio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/alldirinfo.ui" line="51"/>
        <source>文件名：</source>
        <translation type="unfinished">Nombre del archivo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/alldirinfo.ui" line="68"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/alldirinfo.ui" line="83"/>
        <source>查询结果展示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/alldirinfo.ui" line="108"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/alldirinfo.cpp" line="24"/>
        <source>全局目录查询</source>
        <comment>toolName</comment>
        <translation type="unfinished">Consulta de directorio global</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/alldirinfo.cpp" line="26"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/alldirinfo.cpp" line="27"/>
        <source>请输入内容</source>
        <translation type="unfinished">Por favor, ingrese contenido.</translation>
    </message>
</context>
<context>
    <name>ChoseUpDownFile</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/choseUpFile.cpp" line="177"/>
        <source>文件选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar</translation>
    </message>
</context>
<context>
    <name>ChoseUpFile</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/choseUpFile.ui" line="54"/>
        <source>上传文件：</source>
        <translation type="unfinished">Subir archivo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/choseUpFile.cpp" line="86"/>
        <source>选择文件</source>
        <translation type="unfinished">Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/choseUpFile.ui" line="113"/>
        <source>文件描述：</source>
        <translation type="unfinished">Descripción del archivo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/choseUpFile.ui" line="130"/>
        <source>版本备注：</source>
        <translation type="unfinished">Marca de versión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/choseUpFile.ui" line="147"/>
        <source>版本号：</source>
        <translation type="unfinished">Número de versión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/choseUpFile.ui" line="217"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/choseUpFile.ui" line="233"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/choseUpFile.cpp" line="61"/>
        <source>无版本托管：可不填</source>
        <translation type="unfinished">Sin hosting de versión: opcional</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/choseUpFile.cpp" line="64"/>
        <source>下载路径：</source>
        <translation type="unfinished">Ruta de descarga:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/choseUpFile.cpp" line="67"/>
        <source>文件名称：</source>
        <translation type="unfinished">Nombre del archivo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/choseUpFile.cpp" line="86"/>
        <source>All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LocalUpFile</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/localUpFile.ui" line="98"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/localUpFile.cpp" line="62"/>
        <source>本地文件路径：</source>
        <translation type="unfinished">Ruta de archivo local:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/localUpFile.ui" line="115"/>
        <source>上传到服务目录：</source>
        <translation type="unfinished">Cargar al directorio de servicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/localUpFile.ui" line="194"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/localUpFile.ui" line="226"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/localUpFile.cpp" line="48"/>
        <source>文件选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/localUpFile.cpp" line="77"/>
        <source>错误信息</source>
        <translation type="unfinished">Mensaje de error</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="316"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="511"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1057"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1097"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1173"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1285"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1296"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1319"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1351"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1374"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1400"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1495"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2094"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2151"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2323"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2441"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3853"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="316"/>
        <source>无系统模式</source>
        <translation type="unfinished">Sin modo de sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2018"/>
        <source>加载中……请等待</source>
        <translation type="unfinished">Cargando… espere</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="392"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="4438"/>
        <source>请输入关键字查询</source>
        <translation type="unfinished">Por favor, ingrese palabra clave para buscar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="927"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1056"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1857"/>
        <source>锁定</source>
        <translation type="unfinished">Bloquear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="932"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1096"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1861"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="4506"/>
        <source>解锁</source>
        <translation type="unfinished">Desbloquear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2399"/>
        <source>仅删除服务文件</source>
        <translation type="unfinished">Solo eliminar archivos de servicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1430"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="680"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3896"/>
        <source>其他</source>
        <translation type="unfinished">Otro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="688"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3903"/>
        <source>值班</source>
        <translation type="unfinished">De turno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="692"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3907"/>
        <source>备用</source>
        <translation type="unfinished">Respaldo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="696"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="878"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="979"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3911"/>
        <source>故障</source>
        <translation type="unfinished">Fallo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="709"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="877"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="978"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3917"/>
        <source>离线</source>
        <translation type="unfinished">Desconectado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="722"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="879"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="980"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3923"/>
        <source>禁用</source>
        <translation type="unfinished">Deshabilitar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="735"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="880"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="981"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3929"/>
        <source>待启动</source>
        <translation type="unfinished">Por comenzar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="748"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="881"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="982"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3935"/>
        <source>正启动</source>
        <translation type="unfinished">Está iniciando</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="761"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="882"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="983"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3941"/>
        <source>待合并</source>
        <translation type="unfinished">Por fusionar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="785"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1044"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1085"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1229"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1394"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1446"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1587"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1779"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2090"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2147"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2328"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2453"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2537"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2643"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2703"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2788"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3680"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="4388"/>
        <source>错误信息</source>
        <translation type="unfinished">Mensaje de error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="450"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="823"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3976"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="4462"/>
        <source>本地目录</source>
        <translation type="unfinished">Directorio local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2103"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2160"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2568"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2666"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2713"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2797"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3687"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="4397"/>
        <source>信息</source>
        <translation type="unfinished">Mensaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1057"/>
        <source>锁定成功</source>
        <translation type="unfinished">Bloqueo exitoso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1097"/>
        <source>解锁成功</source>
        <translation type="unfinished">Desbloquear con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1319"/>
        <source>修改安装运行目录名称存在风险，是否继续</source>
        <translation type="unfinished">Riesgo al modificar dir. de instalación, ¿seguir?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1173"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1351"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1374"/>
        <source>刷新完成</source>
        <translation type="unfinished">Actualización completa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1400"/>
        <source>打包成功</source>
        <translation type="unfinished">Paquete exitoso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1495"/>
        <source>改名成功</source>
        <translation type="unfinished">Renombrar con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1542"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1792"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1795"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="4519"/>
        <source>%1 空间大小：</source>
        <translation type="unfinished">Tamaño de %1:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="4607"/>
        <source>文件夹</source>
        <translation type="unfinished">Carpetas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="4615"/>
        <source>本地文件</source>
        <translation type="unfinished">Archivo local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1780"/>
        <source>文件夹列表信息获取失败</source>
        <translation type="unfinished">Error al recuperar la información de la lista de carpetas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="325"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1748"/>
        <source>加载中......请等待</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="438"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="4450"/>
        <source>请输入内容</source>
        <translation type="unfinished">Por favor, ingrese contenido.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="439"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="4451"/>
        <source>全部</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="447"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="4459"/>
        <source>服务</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="470"/>
        <source>普通</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="511"/>
        <source>请选择文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="536"/>
        <source>新增</source>
        <comment>menuName</comment>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="537"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="538"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="573"/>
        <source>删除</source>
        <comment>menuName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="539"/>
        <source>重命名</source>
        <comment>menuName</comment>
        <translation type="unfinished">Renombrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="541"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="574"/>
        <source>刷新</source>
        <comment>menuName</comment>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="543"/>
        <source>打包</source>
        <comment>menuName</comment>
        <translation type="unfinished">Paquete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="544"/>
        <source>统计概览</source>
        <comment>menuName</comment>
        <translation type="unfinished">Resumen estadístico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="564"/>
        <source>锁定</source>
        <comment>menuName</comment>
        <translation type="unfinished">Bloquear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="565"/>
        <source>解锁</source>
        <comment>menuName</comment>
        <translation type="unfinished">Desbloquear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="567"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="568"/>
        <source>上传</source>
        <comment>menuName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="570"/>
        <source>下载</source>
        <comment>menuName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="572"/>
        <source>同步删除</source>
        <comment>menuName</comment>
        <translation type="unfinished">Eliminar sincr</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="597"/>
        <source>名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="597"/>
        <source>总大小[B]</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tamaño total [B]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="597"/>
        <source>修改时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tiempo de modificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="597"/>
        <source>文件描述</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Descripción del archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="597"/>
        <source>可删除</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Eliminable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="597"/>
        <source>版本托管类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tipo de hosting de versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1296"/>
        <source>删除当前目录及所含子目录</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1430"/>
        <source>异常输入，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1879"/>
        <source>隐式版本托管配置文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1897"/>
        <source>显式版本托管配置文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1923"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1926"/>
        <source>隐式版本托管运行文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1941"/>
        <source>显式版本托管运行文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2062"/>
        <source>冻结中……请等待</source>
        <translation type="unfinished">Congelando… espere</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2094"/>
        <source>已是冻结状态</source>
        <translation type="unfinished">Ya está congelado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2103"/>
        <source>冻结成功</source>
        <translation type="unfinished">Congelación exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2119"/>
        <source>解冻中……请等待</source>
        <translation type="unfinished">Descongelando… espere</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2151"/>
        <source>已是解冻状态</source>
        <translation type="unfinished">Descongelado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2160"/>
        <source>解冻成功</source>
        <translation type="unfinished">Descongelando con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2249"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2387"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2395"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2399"/>
        <source>删除选中行</source>
        <translation type="unfinished">Eliminar fila seleccionada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="4629"/>
        <source>未知</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1285"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2399"/>
        <source>是否删除</source>
        <translation type="unfinished">¿Eliminar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2323"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2441"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2797"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="4397"/>
        <source>删除成功</source>
        <translation type="unfinished">Eliminado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2426"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3540"/>
        <source>版本总个数：</source>
        <translation type="unfinished">Número total de versiones:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2512"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2612"/>
        <source>上传中……请等待</source>
        <translation type="unfinished">Subiendo... Espere</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="436"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1682"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2001"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2313"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="4448"/>
        <source>版本总个数：%1</source>
        <translation type="unfinished">Número total de versiones: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1447"/>
        <source>禁止重名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1484"/>
        <source>告警</source>
        <translation type="unfinished">Alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1484"/>
        <source>获取目录属性类型失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1867"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1989"/>
        <source>无版本托管配置文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1911"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="1994"/>
        <source>无版本托管运行文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2249"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2387"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2395"/>
        <source>是否仅删除服务文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2249"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2387"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2395"/>
        <source>保留本地文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2249"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2387"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2395"/>
        <source>退出</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2568"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2666"/>
        <source>上传成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2713"/>
        <source>下载成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2759"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="4359"/>
        <source>删除中……请等待</source>
        <translation type="unfinished">Eliminando… espere</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3687"/>
        <source>描述修改成功</source>
        <translation type="unfinished">Descripción modificada con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3839"/>
        <source>查询失败</source>
        <translation type="unfinished">Consulta fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3856"/>
        <source>目录名：</source>
        <translation type="unfinished">Nombre de directorio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2249"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2387"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2395"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3857"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3863"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3869"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2249"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2387"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="2395"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3860"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3866"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3872"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3862"/>
        <source>改名：</source>
        <translation type="unfinished">Renombrar:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3868"/>
        <source>删除：</source>
        <translation type="unfinished">Eliminar:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3874"/>
        <source>版本托管：</source>
        <translation type="unfinished">Hosting de versión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3876"/>
        <source>清除版本数量限制：</source>
        <translation type="unfinished">Eliminar el límite de versión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3877"/>
        <source>超期清理时间限制：</source>
        <translation type="unfinished">Límites de tiempo de limpieza vencidos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3880"/>
        <source>所含文件数：</source>
        <translation type="unfinished">Número de archivos incluidos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3882"/>
        <source>磁盘空间[KB]：</source>
        <translation type="unfinished">Espacio en disco [KB]:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="3883"/>
        <source>磁盘位置：</source>
        <translation type="unfinished">Ubicación del disco:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.ui" line="112"/>
        <source>选择节点：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.ui" line="276"/>
        <source>搜索</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.ui" line="289"/>
        <source>过滤</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.ui" line="302"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.cpp" line="465"/>
        <source>高级</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.ui" line="347"/>
        <source>上传</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.ui" line="360"/>
        <source>下载</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.ui" line="381"/>
        <source>文件列表信息:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/mainwindow.ui" line="501"/>
        <source>文件版本信息:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Worker</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/Worker.cpp" line="86"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/Worker.cpp" line="124"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/Worker.cpp" line="151"/>
        <source>冻结</source>
        <translation type="unfinished">Congelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/Worker.cpp" line="90"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/Worker.cpp" line="161"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/Worker.cpp" line="187"/>
        <source>解冻</source>
        <translation type="unfinished">Descongelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/Worker.cpp" line="287"/>
        <source>错误信息</source>
        <translation type="unfinished">Mensaje de error</translation>
    </message>
</context>
<context>
    <name>fileVerson_table</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="21"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="74"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="74"/>
        <source>版本名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="74"/>
        <source>文件大小[B]</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tamaño del archivo[B]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="74"/>
        <source>发布时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Fecha de publicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="74"/>
        <source>文件描述</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Descripción del archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="74"/>
        <source>冻结状态</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Estado congelado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="75"/>
        <source>操作</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="184"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="197"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="247"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="282"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="288"/>
        <source>冻结</source>
        <translation type="unfinished">Congelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="188"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="198"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="254"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="283"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/fileVerson_table.cpp" line="292"/>
        <source>解冻</source>
        <translation type="unfinished">Descongelar</translation>
    </message>
</context>
<context>
    <name>statsInfos</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/statsInfos.cpp" line="9"/>
        <source>信息</source>
        <comment>toolName</comment>
        <translation type="unfinished">Información</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/statsInfos.cpp" line="12"/>
        <source>目录相关信息如下：</source>
        <translation type="unfinished">La información relacionada con el directorio es la siguiente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_info/statsInfos.cpp" line="33"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
</context>
</TS>
