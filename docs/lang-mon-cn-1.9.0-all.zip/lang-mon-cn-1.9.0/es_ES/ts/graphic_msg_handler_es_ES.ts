<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>ApiSelectHandler</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1824"/>
        <source>状态前景图元：%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1833"/>
        <source>状态前景</source>
        <translation type="unfinished">Estado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1833"/>
        <source>合成光字牌</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1838"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1884"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1933"/>
        <source>属性配置：%1</source>
        <translation type="unfinished">Config. de prop.: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1872"/>
        <source>字符前景图元：%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1880"/>
        <source>字符前景</source>
        <translation type="unfinished">Carácter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1920"/>
        <source>数值前景图元：%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1928"/>
        <source>数值前景</source>
        <translation type="unfinished">Valor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="2550"/>
        <source>图片原始信息:宽 %1，高 %2  (单位:像素)</source>
        <translation type="unfinished">Info. imagen orig.: ancho %1, alto %2 (px)</translation>
    </message>
</context>
<context>
    <name>ApiTermHandler</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_term_handler.cpp" line="55"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_term_handler.cpp" line="55"/>
        <source>非图元默认态不能进行端点的插入!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgAddApp</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.ui" line="14"/>
        <source>添加应用</source>
        <translation type="unfinished">Agregar aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.ui" line="22"/>
        <source>应用名</source>
        <translation type="unfinished">Nombre de app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.ui" line="40"/>
        <source>类型</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.ui" line="54"/>
        <source>是否在监视工具中显示</source>
        <translation type="unfinished">Mostrar en herramientas de monitoreo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.ui" line="94"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.ui" line="101"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.cpp" line="85"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.cpp" line="85"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.cpp" line="91"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.cpp" line="91"/>
        <source>名称不可为空</source>
        <translation type="unfinished">Nombre no puede estar vacío</translation>
    </message>
</context>
<context>
    <name>DlgAddPicType</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.ui" line="14"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.ui" line="43"/>
        <source>画面类型</source>
        <translation type="unfinished">Tipo de pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.ui" line="22"/>
        <source>画面类型名</source>
        <translation type="unfinished">Nombre de tipo de pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.ui" line="67"/>
        <source>画面枚举</source>
        <translation type="unfinished">Enumeración de pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.ui" line="98"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.ui" line="105"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.cpp" line="52"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.cpp" line="52"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.cpp" line="58"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.cpp" line="58"/>
        <source>画面类型名称不可为空</source>
        <translation type="unfinished">El nombre del tipo de gráfica no puede estar vacío</translation>
    </message>
</context>
<context>
    <name>DlgChangeIcon</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_change_icon.ui" line="22"/>
        <source>图元名称:</source>
        <translation type="unfinished">Nombre del icono:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_change_icon.ui" line="59"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_change_icon.ui" line="66"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_change_icon.cpp" line="32"/>
        <source>图元选择</source>
        <translation type="unfinished">Seleccionar icono</translation>
    </message>
</context>
<context>
    <name>DlgDecisionInfo</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.ui" line="40"/>
        <source>表达式详情：</source>
        <translation type="unfinished">Detalles de expresión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="42"/>
        <source>决策信息</source>
        <translation type="unfinished">Info. de decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="73"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="138"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="79"/>
        <source>决策类型</source>
        <translation type="unfinished">Tipo de decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="85"/>
        <source>决策集合</source>
        <translation type="unfinished">Conjunto de decisiones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="91"/>
        <source>决策应用</source>
        <translation type="unfinished">Aplicación de Decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="97"/>
        <source>决策模式库</source>
        <translation type="unfinished">Base de datos del modo de decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="104"/>
        <source>决策值</source>
        <translation type="unfinished">Valor de decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="110"/>
        <source>决策表达式</source>
        <translation type="unfinished">Expresión de decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="116"/>
        <source>决策值2</source>
        <translation type="unfinished">Valor de decisión 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="122"/>
        <source>决策值3</source>
        <translation type="unfinished">Valor de decisión 3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="144"/>
        <source>因子值</source>
        <translation type="unfinished">Valor de factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="150"/>
        <source>因子名称</source>
        <translation type="unfinished">Nombre del factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="156"/>
        <source>因子路径</source>
        <translation type="unfinished">Ruta del factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="162"/>
        <source>因子类别</source>
        <translation type="unfinished">Tipo de factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="174"/>
        <source>实时表域</source>
        <translation type="unfinished">Campo de tabla en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="186"/>
        <source>历史表域</source>
        <translation type="unfinished">Campo de tabla histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="192"/>
        <source>扩展数据源类名</source>
        <translation type="unfinished">Extender el nombre de clase de la fuente de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="198"/>
        <source>扩展数据源动态库路径</source>
        <translation type="unfinished">Extender la ruta de la base de datos dinámica de la fuente de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="204"/>
        <source>备用扩展数据源参数</source>
        <translation type="unfinished">Parámetros de fuente de datos extendida alternativos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="210"/>
        <source>备用扩展数据源参数2</source>
        <translation type="unfinished">Parámetro de fuente de datos extendida alternativo 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="435"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="454"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="471"/>
        <source>闪烁</source>
        <translation type="unfinished">Parpadeo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="439"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="458"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="475"/>
        <source>不闪烁</source>
        <translation type="unfinished">Sin parpadeo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="520"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="539"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="556"/>
        <source>使能</source>
        <translation type="unfinished">Habilitar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="524"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="543"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="560"/>
        <source>不使能</source>
        <translation type="unfinished">Deshabilitar</translation>
    </message>
</context>
<context>
    <name>DlgDynRectTable</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="565"/>
        <source>纵向表头</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Encabezado Vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="771"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="634"/>
        <source>奇数行：</source>
        <translation type="unfinished">Filas impares:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="785"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="635"/>
        <source>偶数行：</source>
        <translation type="unfinished">Filas pares:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1384"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1391"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="30"/>
        <source>基本选项</source>
        <translation type="unfinished">Opciones básicas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="38"/>
        <source>框架:</source>
        <translation type="unfinished">Marco:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="89"/>
        <source>效果：</source>
        <translation type="unfinished">Efecto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="237"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="517"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="604"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="746"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1238"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1331"/>
        <source>背景色：</source>
        <translation type="unfinished">Color de fondo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="478"/>
        <source>横向表头</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Encabezado Horizontal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="486"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="573"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1198"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1291"/>
        <source>文字字体：</source>
        <translation type="unfinished">Fuente de texto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="263"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="548"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="635"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1211"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1304"/>
        <source>字体设置</source>
        <translation type="unfinished">Config. de fuente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="202"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="531"/>
        <source>高度：</source>
        <translation type="unfinished">Alto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="216"/>
        <source>分页按钮：</source>
        <translation type="unfinished">Botón de paginación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="75"/>
        <source>垂直网格线：</source>
        <translation type="unfinished">Líneas de cuadrícula vertical:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="310"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="507"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="594"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1218"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1311"/>
        <source>文字颜色：</source>
        <translation type="unfinished">Color de texto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="195"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="618"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1096"/>
        <source>宽度：</source>
        <translation type="unfinished">Ancho:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="120"/>
        <source>水平网格线：</source>
        <translation type="unfinished">Líneas de cuadrícula horizontal:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="399"/>
        <source>间隔：</source>
        <translation type="unfinished">Espacio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="303"/>
        <source>边框色：</source>
        <translation type="unfinished">Color de borde:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="96"/>
        <source>单页行数：</source>
        <translation type="unfinished">Líneas por página:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="366"/>
        <source>分栏：</source>
        <translation type="unfinished">Sección:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="113"/>
        <source>分页</source>
        <translation type="unfinished">Paginación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="134"/>
        <source>外框：</source>
        <translation type="unfinished">Marco exterior:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="230"/>
        <source>首/尾页</source>
        <translation type="unfinished">Primera/última página</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="209"/>
        <source>支持跳转</source>
        <translation type="unfinished">Soporte de salto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="223"/>
        <source>显示翻页</source>
        <translation type="unfinished">Mostrar Paginación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="440"/>
        <source>表头：</source>
        <translation type="unfinished">Encabezado:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="524"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="611"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1258"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1351"/>
        <source>边框：</source>
        <translation type="unfinished">Borde:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="721"/>
        <source>单元格：</source>
        <translation type="unfinished">Celda:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="755"/>
        <source>单色</source>
        <translation type="unfinished">Monocromo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="762"/>
        <source>间隔色</source>
        <translation type="unfinished">Color de separación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="808"/>
        <source>颜色效果预览：</source>
        <translation type="unfinished">Vista previa efecto color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="850"/>
        <source>&lt;&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="863"/>
        <source>&lt;</source>
        <translation type="unfinished">&lt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="870"/>
        <source>1/1</source>
        <translation type="unfinished">1/1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="903"/>
        <source>跳转</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Saltar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="883"/>
        <source>&gt;</source>
        <translation type="unfinished">&gt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="175"/>
        <source>文字字体</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="296"/>
        <source>按钮凹凸</source>
        <translation type="unfinished">Alternar estilo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="375"/>
        <source>栏数：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="896"/>
        <source>&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="920"/>
        <source>数据关联</source>
        <translation type="unfinished">Asociación de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="940"/>
        <source>条件列表：</source>
        <translation type="unfinished">Lista de condiciones:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="957"/>
        <source>清空</source>
        <translation type="unfinished">Borrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="950"/>
        <source>检索</source>
        <translation type="unfinished">Búsqueda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="14"/>
        <source>动态表格配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="684"/>
        <source>显示标题</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="691"/>
        <source>标题属性</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="708"/>
        <source>标题间距：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="930"/>
        <source>表类型：</source>
        <translation type="unfinished">Tipo de tabla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="964"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="975"/>
        <source>域列表：</source>
        <translation type="unfinished">Lista de dominios:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="982"/>
        <source>列显示</source>
        <translation type="unfinished">Visualización de columnas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="989"/>
        <source>行显示</source>
        <translation type="unfinished">Visualización de filas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1009"/>
        <source>上移</source>
        <translation type="unfinished">Mover arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1016"/>
        <source>下移</source>
        <translation type="unfinished">Mover abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1023"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1037"/>
        <source>显示方式：</source>
        <translation type="unfinished">Modo de visualización:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1044"/>
        <source>平铺</source>
        <translation type="unfinished">Mosaico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1051"/>
        <source>树结构</source>
        <translation type="unfinished">Estructura de árbol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1122"/>
        <source>初始顺序：</source>
        <translation type="unfinished">Orden inicial:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="658"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1145"/>
        <source>标题栏：</source>
        <translation type="unfinished">Barra de título:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1152"/>
        <source>标题名称：</source>
        <translation type="unfinished">Nombre de título:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="698"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1172"/>
        <source>标题高度：</source>
        <translation type="unfinished">Altura de título:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1284"/>
        <source>树状图：</source>
        <translation type="unfinished">Gráfico de árbol:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="1243"/>
        <source>条件检索</source>
        <translation type="unfinished">Condiciones de búsqueda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="1865"/>
        <source>是否清空所有对象</source>
        <translation type="unfinished">¿Borrar todos los objetos?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2005"/>
        <source>配置新名称</source>
        <translation type="unfinished">Nombre de configuración:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="623"/>
        <source>奇数列：</source>
        <translation type="unfinished">Cols impares:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="244"/>
        <source>列名1</source>
        <comment>subTitle</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="244"/>
        <source>列名2</source>
        <comment>subTitle</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="244"/>
        <source>列名3</source>
        <comment>subTitle</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="254"/>
        <source>行 %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="624"/>
        <source>偶数列：</source>
        <translation type="unfinished">Cols pares:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="890"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2218"/>
        <source>&lt;双击编辑&gt;</source>
        <translation type="unfinished">&lt; doble clic para editar &gt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="1866"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="1965"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="1965"/>
        <source>检索路径不为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2015"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2016"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2026"/>
        <source>配置模板名称选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar Nombre del Modelo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2046"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2062"/>
        <source>信息</source>
        <translation type="unfinished">Mensaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2046"/>
        <source>名称不能为空</source>
        <translation type="unfinished">El nombre no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2062"/>
        <source>保存至%1</source>
        <translation type="unfinished">Guardar en %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2075"/>
        <source>表名</source>
        <translation type="unfinished">Nombre de tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2075"/>
        <source>域名</source>
        <translation type="unfinished">Dominio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2075"/>
        <source>表ID</source>
        <translation type="unfinished">ID de tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2075"/>
        <source>域ID</source>
        <translation type="unfinished">ID de dominio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2075"/>
        <source>列名</source>
        <translation type="unfinished">Nombre de columna</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2075"/>
        <source>前景类型</source>
        <translation type="unfinished">Tipo de primer plano</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2075"/>
        <source>操作</source>
        <translation type="unfinished">Operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2075"/>
        <source>域类型</source>
        <translation type="unfinished">Tipo de campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2076"/>
        <source>高度</source>
        <translation type="unfinished">Alto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2076"/>
        <source>宽度</source>
        <translation type="unfinished">Ancho</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2076"/>
        <source>隐藏</source>
        <translation type="unfinished">Ocultar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2076"/>
        <source>合并到上一层</source>
        <translation type="unfinished">Combinar con capa superior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2076"/>
        <source>隐藏表</source>
        <translation type="unfinished">Ocultar tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2077"/>
        <source>合并表</source>
        <translation type="unfinished">Tabla combinada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="3247"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="3247"/>
        <source>表格对象或标题属性为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="3255"/>
        <source>标题设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2076"/>
        <source>行间距</source>
        <translation type="unfinished">Espaciado línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2076"/>
        <source>列间距</source>
        <translation type="unfinished">Espaciado col</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2683"/>
        <source>名称重复，是否替换</source>
        <translation type="unfinished">Nombre repetido, ¿reemplazar?</translation>
    </message>
</context>
<context>
    <name>DlgEquipmentTempalte</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="24"/>
        <source>数据配置</source>
        <translation type="unfinished">Config. de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="54"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="284"/>
        <source>数据路径：</source>
        <translation type="unfinished">Ruta de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="64"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="270"/>
        <source>清除</source>
        <translation type="unfinished">Limpiar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="74"/>
        <source>属性定义</source>
        <translation type="unfinished">Definir atributos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="80"/>
        <source>基本属性：</source>
        <translation type="unfinished">Atributos básicos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="101"/>
        <source>宽度：</source>
        <translation type="unfinished">Ancho:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="114"/>
        <source>X坐标：</source>
        <translation type="unfinished">Coordenada X:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="121"/>
        <source>高度：</source>
        <translation type="unfinished">Alto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="128"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Coordenada Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="147"/>
        <source>线宽</source>
        <translation type="unfinished">Ancho de línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="158"/>
        <source>X坐标</source>
        <translation type="unfinished">Coordenada X</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="163"/>
        <source>Y坐标</source>
        <translation type="unfinished">Coordenada Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="177"/>
        <source>设备属性：</source>
        <translation type="unfinished">Atributos de equipo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="185"/>
        <source>图元类型：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="199"/>
        <source>图元决策：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="305"/>
        <source>条件：    </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="333"/>
        <source>电压等级：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="357"/>
        <source>数据标识 ：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="371"/>
        <source>标签</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="216"/>
        <source>是否直接使用数据库关联</source>
        <translation type="unfinished">¿Usar asociación a BD directamente?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="219"/>
        <source>是否取库</source>
        <translation type="unfinished">¿Tomar de BD?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="251"/>
        <source>数据库链接</source>
        <translation type="unfinished">Enlace a BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="254"/>
        <source>数据库连接</source>
        <translation type="unfinished">Conexión a BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="267"/>
        <source>清除链接</source>
        <translation type="unfinished">Borrar enlaces</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="324"/>
        <source>无电压等级</source>
        <translation type="unfinished">Sin nivel de voltaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="354"/>
        <source>数据库OID</source>
        <translation type="unfinished">OID de BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="401"/>
        <source>更换图元</source>
        <translation type="unfinished">Reemplazar icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="419"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="439"/>
        <source>确定并退出</source>
        <translation type="unfinished">Confirmar y salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="446"/>
        <source>添加</source>
        <translation type="unfinished">Agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="178"/>
        <source>退出</source>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="187"/>
        <source>确认并退出</source>
        <translation type="unfinished">Confirmar y salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="335"/>
        <source>请链接数据库</source>
        <translation type="unfinished">Por favor, enlace a la BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="335"/>
        <source>数据库未连接</source>
        <translation type="unfinished">BD no conectada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="590"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="727"/>
        <source>字符串</source>
        <translation type="unfinished">Cadena</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="604"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="741"/>
        <source>电压等级</source>
        <translation type="unfinished">Nivel de voltaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2061"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2232"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2505"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2650"/>
        <source>函数决策：</source>
        <translation type="unfinished">Decisión de función:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2066"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2237"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2509"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2655"/>
        <source>颜色决策：</source>
        <translation type="unfinished">Decisión de color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2071"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2242"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2513"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2660"/>
        <source>使能决策：</source>
        <translation type="unfinished">Decisión de habilitación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2076"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2247"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2517"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2665"/>
        <source>闪烁决策：</source>
        <translation type="unfinished">Decisión de parpadeo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2081"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2252"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2521"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2670"/>
        <source>符号决策：</source>
        <translation type="unfinished">Decisión simbólica:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2086"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2257"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2525"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2675"/>
        <source>字符决策：</source>
        <translation type="unfinished">Decisión de carácter:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2587"/>
        <source>选择图元</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar Icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2601"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2606"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2601"/>
        <source>重新选择相同类型的图元</source>
        <translation type="unfinished">Volver a seleccionar icono con el mismo tipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2606"/>
        <source>重新选择相同区域的图元</source>
        <translation type="unfinished">Volver a seleccionar icono con la misma área</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2617"/>
        <source>属性配置：%1 %2</source>
        <translation type="unfinished">Configuración de propiedad: %1 %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2622"/>
        <source>属性配置：%1</source>
        <translation type="unfinished">Configuración de propiedad: %1</translation>
    </message>
</context>
<context>
    <name>DlgModifyPicAttr</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="14"/>
        <source>画面属性</source>
        <translation type="unfinished">Atributos de pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="29"/>
        <source>应用使用扩展属性</source>
        <translation type="unfinished">App usa atributos extendidos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="36"/>
        <source>基本属性</source>
        <translation type="unfinished">Atributos básicos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="47"/>
        <source>责任区名：</source>
        <translation type="unfinished">Nombre AOR:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="54"/>
        <source>4444</source>
        <translation type="unfinished">4444</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="65"/>
        <source>画面名称：</source>
        <translation type="unfinished">Nombre de pantalla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="97"/>
        <source>刷新周期:</source>
        <translation type="unfinished">Ciclo de actualización:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="104"/>
        <source>画面类型</source>
        <translation type="unfinished">Tipo de pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="138"/>
        <source>其他功能：</source>
        <translation type="unfinished">Otras funciones:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="147"/>
        <source>G文件导出</source>
        <translation type="unfinished">Exportación de archivo G</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="157"/>
        <source>隐藏替换失败元素</source>
        <translation type="unfinished">Ocultar el elemento de reemplazo fallido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="177"/>
        <source>画面填库</source>
        <translation type="unfinished">Rellenar BD pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="192"/>
        <source>背景属性</source>
        <translation type="unfinished">Atributos de fondo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="206"/>
        <source>画面高度:</source>
        <translation type="unfinished">Altura de pantalla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="218"/>
        <source>画面宽度：</source>
        <translation type="unfinished">Ancho de pantalla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="228"/>
        <source>保持比例</source>
        <translation type="unfinished">Mantener proporción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="235"/>
        <source>特殊宽高</source>
        <translation type="unfinished">Ancho/alto especial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="270"/>
        <source>颜色</source>
        <translation type="unfinished">Color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="283"/>
        <source>背景颜色</source>
        <translation type="unfinished">Color de fondo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="290"/>
        <source>背景色是否延展</source>
        <translation type="unfinished">Color fondo extendido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="83"/>
        <source>厂站名称：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="124"/>
        <source>应用图类型：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="167"/>
        <source>画面映射</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="258"/>
        <source>背景设置:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="303"/>
        <source>使用模板</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="313"/>
        <source>更新模板</source>
        <translation type="unfinished">Actualizar plantilla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="332"/>
        <source>图片</source>
        <translation type="unfinished">Imagen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="349"/>
        <source>选择图片</source>
        <translation type="unfinished">Seleccionar imagen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="364"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="437"/>
        <source>应用属性</source>
        <translation type="unfinished">Atributos de app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="370"/>
        <source>应用属性定义</source>
        <translation type="unfinished">Definición atributos app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="377"/>
        <source>是否启用</source>
        <translation type="unfinished">¿Habilitar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="382"/>
        <source>模板应用</source>
        <translation type="unfinished">App de plantilla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="387"/>
        <source>模板库名</source>
        <translation type="unfinished">Nombre BD plantilla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="399"/>
        <source>应用扩展属性</source>
        <translation type="unfinished">Atributos extendidos app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="420"/>
        <source>增加</source>
        <translation type="unfinished">Aumentar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="427"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="442"/>
        <source>属性值</source>
        <translation type="unfinished">Valor de atributo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="472"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="479"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="121"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="939"/>
        <source>静态模板路径选择</source>
        <translation type="unfinished">Selección de ruta de plantilla estática</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="577"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="590"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="597"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="612"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="577"/>
        <source>当前应用扩展属性行不匹配</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="590"/>
        <source>当前应用属性有空值项</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="597"/>
        <source>当前应用属性[%1]重复</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="612"/>
        <source>当前属性值有空值项</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="626"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="626"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="636"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="641"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="647"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="662"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="636"/>
        <source>画面名称不可使用内部路径名</source>
        <translation type="unfinished">Nombre gráfico no usa ruta interna</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="641"/>
        <source>画面名称不可为空</source>
        <translation type="unfinished">Nombre de pantalla no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="647"/>
        <source>层或应用不可为空</source>
        <translation type="unfinished">Capa o app no vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="662"/>
        <source>画面名称已存在，请重新输入</source>
        <translation type="unfinished">El nombre de la gráfica ya existe, por favor ingrese de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="925"/>
        <source>选择模板</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar Modelo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="1036"/>
        <source>打开图片</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgPokeSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="14"/>
        <source>光敏点</source>
        <translation type="unfinished">Punto sensible</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="22"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="29"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="55"/>
        <source>基本选项</source>
        <translation type="unfinished">Opciones básicas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="61"/>
        <source>基础设置:</source>
        <translation type="unfinished">Configuración básica:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="81"/>
        <source>边框</source>
        <translation type="unfinished">Borde</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="89"/>
        <source>是否凹凸</source>
        <translation type="unfinished">¿Cóncavo/convexo?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="99"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1281"/>
        <source>是否边框</source>
        <translation type="unfinished">¿Con borde?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="113"/>
        <source>线型：</source>
        <translation type="unfinished">Tipo de línea:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="123"/>
        <source>线宽：</source>
        <translation type="unfinished">Ancho de línea:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="147"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="265"/>
        <source>颜色：</source>
        <translation type="unfinished">Color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="154"/>
        <source>效果：</source>
        <translation type="unfinished">Efecto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="164"/>
        <source>填充</source>
        <translation type="unfinished">Relleno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="173"/>
        <source>是否填充</source>
        <translation type="unfinished">¿Rellenar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="183"/>
        <source>渐变</source>
        <translation type="unfinished">Gradiente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="196"/>
        <source>纯色</source>
        <translation type="unfinished">Color sólido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="209"/>
        <source>图片</source>
        <translation type="unfinished">Imagen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="256"/>
        <source>%</source>
        <translation type="unfinished">%</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="237"/>
        <source>透明度：</source>
        <translation type="unfinished">Transparencia:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="276"/>
        <source>渐变：</source>
        <translation type="unfinished">Gradiente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="297"/>
        <source>方向：</source>
        <translation type="unfinished">Dirección:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="311"/>
        <source>路径：</source>
        <translation type="unfinished">Ruta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="325"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1389"/>
        <source>选择文件</source>
        <translation type="unfinished">Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="332"/>
        <source>保持比例</source>
        <translation type="unfinished">Mantener proporción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="345"/>
        <source>特性</source>
        <translation type="unfinished">Características</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="351"/>
        <source>角型：</source>
        <translation type="unfinished">Tipo de ángulo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="358"/>
        <source>直角</source>
        <translation type="unfinished">Ángulo recto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="371"/>
        <source>弧角</source>
        <translation type="unfinished">Ángulo curvo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="381"/>
        <source>圆角</source>
        <translation type="unfinished">Redondeado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="397"/>
        <source>X坐标：</source>
        <translation type="unfinished">Coordenada X:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="407"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Coordenada Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="446"/>
        <source>相关状态：</source>
        <translation type="unfinished">Estado relacionado:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="474"/>
        <source>状态前景</source>
        <translation type="unfinished">Primer plano estado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="464"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="484"/>
        <source>配置</source>
        <translation type="unfinished">Configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="421"/>
        <source>宽度：</source>
        <translation type="unfinished">Ancho:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="431"/>
        <source>高度：</source>
        <translation type="unfinished">Alto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="491"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="784"/>
        <source>数据关联</source>
        <translation type="unfinished">Enlace datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="503"/>
        <source>显示：</source>
        <translation type="unfinished">Mostrar:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="521"/>
        <source>数据库</source>
        <translation type="unfinished">Base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="531"/>
        <source>数据库链接</source>
        <translation type="unfinished">Enlace a BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="545"/>
        <source>按钮文本：</source>
        <translation type="unfinished">Texto de botón:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="559"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="742"/>
        <source>文本设置</source>
        <translation type="unfinished">Config. de texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="566"/>
        <source>文本颜色：</source>
        <translation type="unfinished">Color de texto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="588"/>
        <source>功能：</source>
        <translation type="unfinished">Función:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="607"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1086"/>
        <source>调用命令</source>
        <translation type="unfinished">Invocar comando</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="617"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1167"/>
        <source>发送消息</source>
        <translation type="unfinished">Enviar mensaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="624"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="839"/>
        <source>调用模板</source>
        <translation type="unfinished">Llamar plantilla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="634"/>
        <source>高级脚本</source>
        <translation type="unfinished">Script avanzado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="641"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="689"/>
        <source>调用画面</source>
        <translation type="unfinished">Invocar pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="654"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1228"/>
        <source>下拉菜单</source>
        <translation type="unfinished">Menú desplegable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="661"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1052"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1060"/>
        <source>调用功能</source>
        <translation type="unfinished">Invocar función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="671"/>
        <source>退出窗口</source>
        <translation type="unfinished">Salir de ventana</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="678"/>
        <source>响应替换</source>
        <translation type="unfinished">Reemplazo de respuesta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="697"/>
        <source>应用名：</source>
        <translation type="unfinished">Nombre de app:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="709"/>
        <source>应用共享</source>
        <translation type="unfinished">Compartir app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="725"/>
        <source>相对路径</source>
        <translation type="unfinished">Ruta relativa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="728"/>
        <source>画面路径：</source>
        <translation type="unfinished">Ruta de pantalla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="739"/>
        <source>方式选择：</source>
        <translation type="unfinished">Selección de modo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="748"/>
        <source>替换</source>
        <translation type="unfinished">Reemplazar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="761"/>
        <source>新窗口</source>
        <translation type="unfinished">Nueva ventana</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="774"/>
        <source>分图</source>
        <translation type="unfinished">Subgráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="787"/>
        <source>非模式</source>
        <translation type="unfinished">No modal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="800"/>
        <source>浮动窗口</source>
        <translation type="unfinished">Ventana flotante</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="826"/>
        <source>调用方式：</source>
        <translation type="unfinished">Modo de invocación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="847"/>
        <source>模板路径：</source>
        <translation type="unfinished">Ruta de plantilla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="884"/>
        <source>解析模板替换规则</source>
        <translation type="unfinished">Analizar reglas reemplazo plantilla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="891"/>
        <source>模板匹配规则：</source>
        <translation type="unfinished">Regla de coincidencia de plantilla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="904"/>
        <source>通配符替换配置</source>
        <translation type="unfinished">Config. reemplazo comodín</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="911"/>
        <source>通配符</source>
        <translation type="unfinished">Comodín</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="916"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1029"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="921"/>
        <source>替换值</source>
        <translation type="unfinished">Valor de reemplazo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="926"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1039"/>
        <source>域</source>
        <translation type="unfinished">Dominio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="935"/>
        <source>应用库实例替换配置</source>
        <translation type="unfinished">Config. reemplazo instancia BD app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="942"/>
        <source>源集合</source>
        <translation type="unfinished">Conjunto fuente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="947"/>
        <source>源应用</source>
        <translation type="unfinished">App de origen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="952"/>
        <source>源库名</source>
        <translation type="unfinished">Nombre de BD fuente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="957"/>
        <source>源实例</source>
        <translation type="unfinished">Instancia fuente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="962"/>
        <source>目标应用</source>
        <translation type="unfinished">App objetivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="967"/>
        <source>目标库名</source>
        <translation type="unfinished">Nombre BD destino</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="972"/>
        <source>目标实例</source>
        <translation type="unfinished">Instancia destino</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="981"/>
        <source>字符串静态替换</source>
        <translation type="unfinished">Reemplazo estático de cadenas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1002"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1249"/>
        <source>添加</source>
        <translation type="unfinished">Agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1009"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1256"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1019"/>
        <source>源字符串值</source>
        <translation type="unfinished">Valor cadena fuente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1024"/>
        <source>目标字符值</source>
        <translation type="unfinished">Valor de carácter objetivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1034"/>
        <source>是否替换光敏点</source>
        <translation type="unfinished">¿Reemplazar punto sensible?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1101"/>
        <source>参数：</source>
        <translation type="unfinished">Parámetros:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1112"/>
        <source>名称：</source>
        <translation type="unfinished">Nombre:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1126"/>
        <source>选择程序</source>
        <translation type="unfinished">Seleccionar programa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1137"/>
        <source>提示信息</source>
        <translation type="unfinished">Info. de indicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1175"/>
        <source>消息类型：</source>
        <translation type="unfinished">Tipo de mensaje:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1189"/>
        <source>函数名：</source>
        <translation type="unfinished">Nombre de función:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1201"/>
        <source>参数定义</source>
        <translation type="unfinished">Definición de parámetros</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1209"/>
        <source>参数名</source>
        <translation type="unfinished">Nombre de parámetro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1214"/>
        <source>参数类型</source>
        <translation type="unfinished">Tipo de parámetro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1219"/>
        <source>参数值</source>
        <translation type="unfinished">Valor de parámetros</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1266"/>
        <source>菜单名称</source>
        <translation type="unfinished">Nombre del menú</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1271"/>
        <source>菜单图标</source>
        <translation type="unfinished">Ícono de menú</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1276"/>
        <source>跳转画面</source>
        <translation type="unfinished">Pantalla de salto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="51"/>
        <source>顺控操作</source>
        <translation type="unfinished">Secuencial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="88"/>
        <source>文件选择</source>
        <translation type="unfinished">Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="100"/>
        <source>动态模板选择</source>
        <translation type="unfinished">Seleccionar plantilla dinámica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="126"/>
        <source>中对齐</source>
        <translation type="unfinished">Alineación centro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="127"/>
        <source>左对齐</source>
        <translation type="unfinished">Alineación izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="128"/>
        <source>右对齐</source>
        <translation type="unfinished">Alineación derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="129"/>
        <source>上对齐</source>
        <translation type="unfinished">Alineación arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="130"/>
        <source>下对齐</source>
        <translation type="unfinished">Alineación abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="233"/>
        <source>水平</source>
        <translation type="unfinished">Horizontal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="237"/>
        <source>垂直</source>
        <translation type="unfinished">Vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="241"/>
        <source>左斜</source>
        <translation type="unfinished">Diagonal izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="245"/>
        <source>右斜</source>
        <translation type="unfinished">Diagonal derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="482"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="484"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="719"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1440"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1573"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1575"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="483"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="484"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1441"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1574"/>
        <source>否</source>
        <translation type="unfinished">Falso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="791"/>
        <source>字符前景</source>
        <comment>toolName</comment>
        <translation type="unfinished">Carácter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="940"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="940"/>
        <source>模板路径为空</source>
        <translation type="unfinished">Ruta plantilla vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1221"/>
        <source>调用画面</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Llamar Gráfica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1243"/>
        <source>调用模板</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Llamar Modelo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1257"/>
        <source>下拉菜单</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Menú Desplegable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1271"/>
        <source>调用功能</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Llamar Función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1304"/>
        <source>调用命令</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Llamar Comando</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1342"/>
        <source>发送消息</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Enviar Mensaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1391"/>
        <source>图片文件 %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1413"/>
        <source>选择文件</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar Archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1416"/>
        <source>文件选择</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1601"/>
        <source>打开图片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1679"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1679"/>
        <source>所选文件没有执行权限!</source>
        <translation type="unfinished">¡Archivo seleccionado sin permisos ejecución!</translation>
    </message>
</context>
<context>
    <name>DlgRectTable</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="20"/>
        <source>通用属性</source>
        <translation type="unfinished">Atributos generales</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="28"/>
        <source>模式:</source>
        <translation type="unfinished">Modo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="38"/>
        <source>单页行数:</source>
        <translation type="unfinished">Líneas por página:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="58"/>
        <source>分栏:</source>
        <translation type="unfinished">Sección:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="72"/>
        <source>分栏间隔：</source>
        <translation type="unfinished">Espacio entre secciones:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="92"/>
        <source>分栏行显示</source>
        <translation type="unfinished">Visualización de línea de col</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="106"/>
        <source>列高：</source>
        <translation type="unfinished">Altura de columna:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="148"/>
        <source>网格颜色:</source>
        <translation type="unfinished">Color de cuadrícula:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="204"/>
        <source>跳转凹凸</source>
        <translation type="unfinished">Salto cóncavo/convexo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="197"/>
        <source>首/尾页</source>
        <translation type="unfinished">Primera/última página</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="211"/>
        <source>行显示</source>
        <translation type="unfinished">Visualización de línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="162"/>
        <source>显示网格线</source>
        <translation type="unfinished">Mostrar líneas de cuadrícula</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="183"/>
        <source>显示翻页</source>
        <translation type="unfinished">Mostrar Paginación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="169"/>
        <source>翻页颜色:</source>
        <translation type="unfinished">Color de paginación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="14"/>
        <source>静态表格属性</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="99"/>
        <source>列头属性</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="120"/>
        <source>列宽：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="134"/>
        <source>宽高自适应：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="190"/>
        <source>支持跳转</source>
        <translation type="unfinished">Soporte de salto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="218"/>
        <source>显示标题</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="225"/>
        <source>标题属性</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="232"/>
        <source>标题高度：</source>
        <translation type="unfinished">Altura de título:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="242"/>
        <source>标题间距：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="274"/>
        <source>列属性</source>
        <translation type="unfinished">Atributos de columna</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="295"/>
        <source>修改</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="302"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="441"/>
        <source>添加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="309"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="455"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="316"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="462"/>
        <source>上移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Mover arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="323"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="469"/>
        <source>下移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Mover hacia abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="330"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="476"/>
        <source>移动至</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Mover A</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="375"/>
        <source>清除条件</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Borrar condiciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="382"/>
        <source>检索</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Buscar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="389"/>
        <source>检查条件</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Verificar condiciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="396"/>
        <source>添加对象</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Agregar objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="420"/>
        <source>清空对象</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Borrar objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="434"/>
        <source>复制对象</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Copiar objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="448"/>
        <source>修改</source>
        <translation type="unfinished">Modificar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="507"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="514"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="343"/>
        <source>行属性</source>
        <translation type="unfinished">Atributos de fila</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="351"/>
        <source>应用:</source>
        <translation type="unfinished">Aplicación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="361"/>
        <source>条件:</source>
        <translation type="unfinished">Condición:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="854"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="860"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="868"/>
        <source>普通字符</source>
        <translation type="unfinished">Caracteres normales</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="913"/>
        <source>光字牌配置</source>
        <translation type="unfinished">Config del anunciador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="929"/>
        <source>列名</source>
        <translation type="unfinished">Nombre de columna</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="929"/>
        <source>前景类型</source>
        <translation type="unfinished">Tipo de primer plano</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="929"/>
        <source>颜色决策</source>
        <translation type="unfinished">Decisión de color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="929"/>
        <source>符号决策</source>
        <translation type="unfinished">Decisión de símbolo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="929"/>
        <source>光敏字符表ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="929"/>
        <source>光敏字符域ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="930"/>
        <source>文本决策</source>
        <translation type="unfinished">Decisión de texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="930"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Decisión de parpadeo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="930"/>
        <source>使能决策</source>
        <translation type="unfinished">Decisión de habilitación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="930"/>
        <source>元素宽度</source>
        <translation type="unfinished">Ancho de elemento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="930"/>
        <source>元素高度</source>
        <translation type="unfinished">Altura de elemento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="930"/>
        <source>行间距</source>
        <translation type="unfinished">Espacio entre filas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="930"/>
        <source>列间距</source>
        <translation type="unfinished">Espacio entre columnas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="930"/>
        <source>图元名</source>
        <translation type="unfinished">Nombre de elemento gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="931"/>
        <source>因子路径</source>
        <translation type="unfinished">Ruta de factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="931"/>
        <source>属性设置</source>
        <translation type="unfinished">Config. de atributos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="931"/>
        <source>属性表ID</source>
        <translation type="unfinished">ID de lista de atributos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="931"/>
        <source>属性域ID</source>
        <translation type="unfinished">ID de campo de atributos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="931"/>
        <source>起始序号</source>
        <translation type="unfinished">Núm. de serie inicial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="931"/>
        <source>序号通配符</source>
        <translation type="unfinished">Comodín de núm. de serie</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="932"/>
        <source>序号有效位</source>
        <translation type="unfinished">Dígitos válidos de núm. de serie</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="932"/>
        <source>应用名</source>
        <translation type="unfinished">Nombre de app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="932"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1009"/>
        <source>库名</source>
        <translation type="unfinished">Nombre de biblioteca</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1003"/>
        <source>清除</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1008"/>
        <source>对象路径</source>
        <translation type="unfinished">Ruta de objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1008"/>
        <source>数据库类型</source>
        <translation type="unfinished">Tipo de base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1008"/>
        <source>全应用名称</source>
        <translation type="unfinished">Nombre completo App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1008"/>
        <source>对象条件</source>
        <translation type="unfinished">Condiciones del objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1009"/>
        <source>应用名称</source>
        <translation type="unfinished">Nombre de aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1009"/>
        <source>实例ID</source>
        <translation type="unfinished">ID de instancia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1009"/>
        <source>对象OID</source>
        <translation type="unfinished">OID de objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1043"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2369"/>
        <source>对象选择</source>
        <translation type="unfinished">Selección de objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1047"/>
        <source>不自适应</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1048"/>
        <source>分栏间距</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1049"/>
        <source>行列间距</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1050"/>
        <source>元素宽高</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1178"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3968"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3979"/>
        <source>单页行数</source>
        <translation type="unfinished">Filas por página</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1181"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3986"/>
        <source>单行个数</source>
        <translation type="unfinished">Elementos por línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1307"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2812"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3139"/>
        <source>图元名称：</source>
        <translation type="unfinished">Nombre del icono:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1319"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2874"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3185"/>
        <source>颜色决策：</source>
        <translation type="unfinished">Decisión de color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1324"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2879"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3181"/>
        <source>符号决策：</source>
        <translation type="unfinished">Decisión de símbolo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1329"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2884"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3189"/>
        <source>闪烁决策：</source>
        <translation type="unfinished">Decisión de parpadeo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1334"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2889"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3193"/>
        <source>使能决策：</source>
        <translation type="unfinished">Habilitar decisión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1503"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1513"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1522"/>
        <source>表格宽度小于上下页按钮预留宽度</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1503"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1513"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1522"/>
        <source>是否继续</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1771"/>
        <source>是否创建当前元素</source>
        <translation type="unfinished">¿Crear elemento actual?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1897"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2290"/>
        <source>是否删除当前选中行</source>
        <translation type="unfinished">¿Eliminar fila seleccionada actual?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1966"/>
        <source>重复对象提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1984"/>
        <source>合并(跳过重复)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1985"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1986"/>
        <source>重新选择</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2374"/>
        <source>条件检索</source>
        <translation type="unfinished">Búsqueda por condición</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2468"/>
        <source>请仅选择一行进行修改</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2528"/>
        <source>数据库连接失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2550"/>
        <source>选择的对象与现有对象重复，不允许修改</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2587"/>
        <source>是否清空所有对象</source>
        <translation type="unfinished">¿Borrar todos los objetos?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3572"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3793"/>
        <source>移动至</source>
        <comment>toolName</comment>
        <translation type="unfinished">Mover A</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3572"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3793"/>
        <source>目标行:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="4029"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="4029"/>
        <source>表格对象或标题属性为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="4037"/>
        <source>标题设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1496"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1770"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1896"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2289"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2468"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2528"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2550"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2586"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3271"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3354"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3361"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3366"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="812"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="818"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="826"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="910"/>
        <source>静态表格配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1968"/>
        <source>发现 %1 个重复的测点对象：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1973"/>
        <source>路径: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1977"/>
        <source>... 还有 %1 个重复对象</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1980"/>
        <source>请选择处理方式：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2750"/>
        <source>字符前景</source>
        <translation type="unfinished">Carácter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3271"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Seleccione datos para operar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3354"/>
        <source>检索失败</source>
        <translation type="unfinished">Búsqueda fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3361"/>
        <source>检索结果大于10000条,请检查条件</source>
        <translation type="unfinished">Resultados &gt; 10000, verifique condiciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3366"/>
        <source>检索结果%1条</source>
        <translation type="unfinished">Elementos de resultado de búsqueda: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="4000"/>
        <source>双击单元格进行属性设置编辑</source>
        <translation type="unfinished">Haga doble clic en la celda para editar la configuración de atributos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="4016"/>
        <source>双击此处编辑属性设置</source>
        <translation type="unfinished">Haga doble clic aquí para editar propiedades</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="4017"/>
        <source>&lt;双击编辑&gt;</source>
        <translation type="unfinished">&lt;Haga doble clic en editar&gt;</translation>
    </message>
</context>
<context>
    <name>DlgSignalSlotConfig</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="26"/>
        <source>发送方对象：</source>
        <translation type="unfinished">Objeto emisor:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="40"/>
        <source>发送方信号列表：</source>
        <translation type="unfinished">Lista de señales emisor:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="54"/>
        <source>信号签名：</source>
        <translation type="unfinished">Firma de señal:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="76"/>
        <source>接收方对象：</source>
        <translation type="unfinished">Objeto receptor:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="90"/>
        <source>接收方响应列表：</source>
        <translation type="unfinished">Lista de respuestas receptor:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="104"/>
        <source>响应函数签名：</source>
        <translation type="unfinished">Firma de función respuesta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="139"/>
        <source>添加</source>
        <translation type="unfinished">Agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="146"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="186"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="193"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="69"/>
        <source>信号配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Config de Señal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="123"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="129"/>
        <source>发送方名称</source>
        <translation type="unfinished">Nombre del emisor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="135"/>
        <source>发送方信号描述</source>
        <translation type="unfinished">Señal del remitente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="141"/>
        <source>接收方名称</source>
        <translation type="unfinished">Nombre del destinatario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="147"/>
        <source>接收方信号描述</source>
        <translation type="unfinished">Señal del receptor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="339"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="344"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="349"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="354"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="366"/>
        <source>添加失败</source>
        <translation type="unfinished">Agregar fallido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="339"/>
        <source>无可用的发送方对象</source>
        <translation type="unfinished">No hay objetos emisor disponibles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="344"/>
        <source>无可用的接收方对象</source>
        <translation type="unfinished">No hay objetos receptores disponibles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="349"/>
        <source>无可用的发送方信号</source>
        <translation type="unfinished">No hay señal de emisor disponible</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="354"/>
        <source>无可用的接收方响应</source>
        <translation type="unfinished">No hay respuestas del receptor disponibles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="366"/>
        <source>链接已存在</source>
        <translation type="unfinished">Enlace ya existe</translation>
    </message>
</context>
<context>
    <name>DlgStateSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="20"/>
        <source>状态前景</source>
        <translation type="unfinished">Primer plano de estado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="32"/>
        <source>基本设置：</source>
        <translation type="unfinished">Config. básica:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="62"/>
        <source>文本：</source>
        <translation type="unfinished">Texto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="69"/>
        <source>显示文本</source>
        <translation type="unfinished">Mostrar Texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="80"/>
        <source>文字颜色：</source>
        <translation type="unfinished">Color de texto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="87"/>
        <source>文字颜色</source>
        <translation type="unfinished">Color de texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="98"/>
        <source>前景颜色：</source>
        <translation type="unfinished">Color de primer plano:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="105"/>
        <source>填充色</source>
        <translation type="unfinished">Color de relleno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="112"/>
        <source>填充颜色</source>
        <translation type="unfinished">Color de relleno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="128"/>
        <source>对齐：</source>
        <translation type="unfinished">Alineación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="138"/>
        <source>竖排</source>
        <translation type="unfinished">Vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="146"/>
        <source>枚举</source>
        <translation type="unfinished">Enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="154"/>
        <source>边框色</source>
        <translation type="unfinished">Color de borde</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="161"/>
        <source>边框颜色</source>
        <translation type="unfinished">Color del borde</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="177"/>
        <source>函数取值</source>
        <translation type="unfinished">Valor de función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="188"/>
        <source>X坐标：</source>
        <translation type="unfinished">Coordenada X:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="198"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Coordenada Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="212"/>
        <source>宽度：</source>
        <translation type="unfinished">Ancho:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="222"/>
        <source>高度：</source>
        <translation type="unfinished">Alto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="581"/>
        <source>条件：</source>
        <translation type="unfinished">Condición:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="595"/>
        <source>对象ID：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="243"/>
        <source>符号图元选择：</source>
        <translation type="unfinished">Selección de elemento de símbolo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="252"/>
        <source>图元名称：</source>
        <translation type="unfinished">Nombre de elemento gráfico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="287"/>
        <source>字体设置：</source>
        <translation type="unfinished">Config. de fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="310"/>
        <source>字体：</source>
        <translation type="unfinished">Fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="324"/>
        <source>字体大小：</source>
        <translation type="unfinished">Tamaño de fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="340"/>
        <source>效果：</source>
        <translation type="unfinished">Efecto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="347"/>
        <source>粗体</source>
        <translation type="unfinished">Negrita</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="354"/>
        <source>斜体</source>
        <translation type="unfinished">Cursiva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="361"/>
        <source>删除线</source>
        <translation type="unfinished">Tachado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="368"/>
        <source>下划线</source>
        <translation type="unfinished">Subrayado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="386"/>
        <source>决策：</source>
        <translation type="unfinished">Decisión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="404"/>
        <source>颜色决策</source>
        <translation type="unfinished">Decisión de color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="414"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="435"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="456"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="477"/>
        <source>更多</source>
        <translation type="unfinished">Más</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="425"/>
        <source>符号决策</source>
        <translation type="unfinished">Decisión de símbolo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="446"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Decisión de parpadeo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="467"/>
        <source>使能决策</source>
        <translation type="unfinished">Decisión de habilitación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="495"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="526"/>
        <source>数据库：</source>
        <translation type="unfinished">Base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="262"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="549"/>
        <source>清除</source>
        <translation type="unfinished">Borrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="513"/>
        <source>应用：</source>
        <translation type="unfinished">App:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="556"/>
        <source>检索</source>
        <translation type="unfinished">Búsqueda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="567"/>
        <source>链接路径：</source>
        <translation type="unfinished">Ruta de enlace:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="605"/>
        <source>对象域：</source>
        <translation type="unfinished">Dominio de objeto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="635"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="642"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.cpp" line="54"/>
        <source>图元选择</source>
        <translation type="unfinished">Seleccionar icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.cpp" line="66"/>
        <source>中对齐</source>
        <translation type="unfinished">Alineación centro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.cpp" line="67"/>
        <source>左对齐</source>
        <translation type="unfinished">Alineación izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.cpp" line="68"/>
        <source>右对齐</source>
        <translation type="unfinished">Alineación derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.cpp" line="69"/>
        <source>上对齐</source>
        <translation type="unfinished">Alineación arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.cpp" line="70"/>
        <source>下对齐</source>
        <translation type="unfinished">Alineación abajo</translation>
    </message>
</context>
<context>
    <name>DlgStateTemplateSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="20"/>
        <source>状态前景</source>
        <translation type="unfinished">Estado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="30"/>
        <source>数据配置</source>
        <translation type="unfinished">Datos de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="41"/>
        <source>数据路径：</source>
        <translation type="unfinished">Ruta de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="51"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="386"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="683"/>
        <source>清除</source>
        <translation type="unfinished">Borrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="61"/>
        <source>条件配置</source>
        <translation type="unfinished">Condiciones de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="84"/>
        <source>应用：</source>
        <translation type="unfinished">App:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="94"/>
        <source>库名：</source>
        <translation type="unfinished">Nombre de la base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="104"/>
        <source>实例号：</source>
        <translation type="unfinished">Número de instancia:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="114"/>
        <source>条件：</source>
        <translation type="unfinished">Condición:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="127"/>
        <source>属性定义</source>
        <translation type="unfinished">Definir atributos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="139"/>
        <source>基本设置：</source>
        <translation type="unfinished">Configuraciones básicas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="159"/>
        <source>文本：</source>
        <translation type="unfinished">Texto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="179"/>
        <source>高级配置</source>
        <translation type="unfinished">Configuración avanzada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="186"/>
        <source>显示文本</source>
        <translation type="unfinished">Mostrar Texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="197"/>
        <source>对齐：</source>
        <translation type="unfinished">Alineación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="207"/>
        <source>竖排</source>
        <translation type="unfinished">Fila vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="218"/>
        <source>文字颜色：</source>
        <translation type="unfinished">Color del texto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="225"/>
        <source>文字颜色</source>
        <translation type="unfinished">Color del texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="234"/>
        <source>枚举</source>
        <translation type="unfinished">Enum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="245"/>
        <source>前景颜色：</source>
        <translation type="unfinished">Color de primer plano:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="252"/>
        <source>填充色</source>
        <translation type="unfinished">Color de relleno:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="261"/>
        <source>填充颜色</source>
        <translation type="unfinished">Color de relleno:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="272"/>
        <source>边框颜色</source>
        <translation type="unfinished">Color del borde</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="279"/>
        <source>边框色</source>
        <translation type="unfinished">Color del borde</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="294"/>
        <source>函数取值</source>
        <translation type="unfinished">Valor de la función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="305"/>
        <source>X坐标：</source>
        <translation type="unfinished">Coordenada X:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="315"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Coordenada Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="329"/>
        <source>宽度： </source>
        <translation type="unfinished">Ancho:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="339"/>
        <source>高度： </source>
        <translation type="unfinished">Alto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="372"/>
        <source>延展</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="393"/>
        <source>等比缩放</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="644"/>
        <source>应用：    </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="715"/>
        <source>条件：    </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="729"/>
        <source>对象ID：  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="360"/>
        <source>符号图元选择：</source>
        <translation type="unfinished">Seleccionar icono:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="379"/>
        <source>图元名称：</source>
        <translation type="unfinished">Nombre del icono:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="418"/>
        <source>字体设置：</source>
        <translation type="unfinished">Configuración de fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="441"/>
        <source>字体：</source>
        <translation type="unfinished">Fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="455"/>
        <source>字体大小：</source>
        <translation type="unfinished">Tamaño de fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="471"/>
        <source>效果：</source>
        <translation type="unfinished">Efecto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="478"/>
        <source>粗体</source>
        <translation type="unfinished">Tipo negrita</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="485"/>
        <source>斜体</source>
        <translation type="unfinished">Cursiva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="492"/>
        <source>删除线</source>
        <translation type="unfinished">Línea tachada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="499"/>
        <source>下划线</source>
        <translation type="unfinished">Subrayado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="517"/>
        <source>决策：</source>
        <translation type="unfinished">Decisión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="535"/>
        <source>颜色决策</source>
        <translation type="unfinished">Decisión de color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="545"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="566"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="587"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="608"/>
        <source>更多</source>
        <translation type="unfinished">Más</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="556"/>
        <source>符号决策</source>
        <translation type="unfinished">Decisión de símbolo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="577"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Decisión de parpadeo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="598"/>
        <source>使能决策</source>
        <translation type="unfinished">Decisión de habilitación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="626"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="657"/>
        <source>数据库：</source>
        <translation type="unfinished">Base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="690"/>
        <source>检索</source>
        <translation type="unfinished">Buscar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="701"/>
        <source>链接路径：</source>
        <translation type="unfinished">Ruta de enlace:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="739"/>
        <source>对象域：</source>
        <translation type="unfinished">Campo de objeto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="760"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="780"/>
        <source>确定并退出</source>
        <translation type="unfinished">Confirmar y salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="787"/>
        <source>添加</source>
        <translation type="unfinished">Agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="137"/>
        <source>图元选择</source>
        <translation type="unfinished">Selección de elemento gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="149"/>
        <source>中对齐</source>
        <translation type="unfinished">Alinear al centro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="150"/>
        <source>左对齐</source>
        <translation type="unfinished">Alinear a la izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="151"/>
        <source>右对齐</source>
        <translation type="unfinished">Alinear a la derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="152"/>
        <source>上对齐</source>
        <translation type="unfinished">Alinear arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="153"/>
        <source>下对齐</source>
        <translation type="unfinished">Alinear abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="223"/>
        <source>退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="235"/>
        <source>确认并退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar y salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="289"/>
        <source>应用全名:</source>
        <translation type="unfinished">Nombre completo App:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="315"/>
        <source>搜索画面...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="317"/>
        <source>全选</source>
        <translation type="unfinished">Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="318"/>
        <source>清空</source>
        <translation type="unfinished">Borrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="320"/>
        <source>画面选择:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="338"/>
        <source>已选画面:</source>
        <translation type="unfinished">Pantallas seleccionadas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="339"/>
        <source>(0个)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="347"/>
        <source>双击可移除选中的画面</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="362"/>
        <source>画面配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="463"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="491"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="706"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="734"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1105"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1133"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1941"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="464"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="707"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1106"/>
        <source>勾选填充色则符号图元不生效，是否清除符号图元</source>
        <translation type="unfinished">Si color relleno seleccionado, icono símbolo no actúa. ¿Borrar icono símbolo?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="492"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="735"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1134"/>
        <source>勾选边框色则符号图元不生效，是否清除符号图元</source>
        <translation type="unfinished">Si color borde seleccionado, icono símbolo no actúa. ¿Borrar icono símbolo?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="677"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="3607"/>
        <source>双击移除</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="685"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="3615"/>
        <source>(%1个)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1188"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1395"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1188"/>
        <source>请选择至少一个画面</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1395"/>
        <source>修改后的前景配置在二维表中已存在，请修改为不同的配置。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1942"/>
        <source>选择符号图元则填充色和边框色不生效，是否清除填充色和边框色勾选</source>
        <translation type="unfinished">Si selecciona icono símbolo, color relleno y borde no actúan. ¿Borrar casillas color relleno y borde?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="2295"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="2295"/>
        <source>条件配置为空是否保存?</source>
        <translation type="unfinished">Si la condición está vacía, ¿desea guardar?</translation>
    </message>
</context>
<context>
    <name>DlgStateTextTemplateSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="14"/>
        <source>字符前景</source>
        <translation type="unfinished">Primer plano carácter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="24"/>
        <source>数据配置</source>
        <translation type="unfinished">Config. de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="42"/>
        <source>数据路径：</source>
        <translation type="unfinished">Ruta de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="52"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="561"/>
        <source>清除</source>
        <translation type="unfinished">Borrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="62"/>
        <source>属性定义</source>
        <translation type="unfinished">Definición de atributos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="74"/>
        <source>基本设置：</source>
        <translation type="unfinished">Config. básica:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="94"/>
        <source>文本：</source>
        <translation type="unfinished">Texto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="108"/>
        <source>显示文本</source>
        <translation type="unfinished">Mostrar Texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="119"/>
        <source>对齐：</source>
        <translation type="unfinished">Alineación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="129"/>
        <source>竖排</source>
        <translation type="unfinished">Vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="136"/>
        <source>启用延展</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="150"/>
        <source>文字颜色：</source>
        <translation type="unfinished">Color de texto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="157"/>
        <source>文字颜色</source>
        <translation type="unfinished">Color de texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="166"/>
        <source>枚举</source>
        <translation type="unfinished">Enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="177"/>
        <source>前景颜色：</source>
        <translation type="unfinished">Color de primer plano:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="184"/>
        <source>填充色</source>
        <translation type="unfinished">Color de relleno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="193"/>
        <source>填充颜色</source>
        <translation type="unfinished">Color de relleno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="204"/>
        <source>边框色</source>
        <translation type="unfinished">Color de borde</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="211"/>
        <source>边框颜色</source>
        <translation type="unfinished">Color del borde</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="226"/>
        <source>函数取值</source>
        <translation type="unfinished">Valor de función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="237"/>
        <source>X坐标：</source>
        <translation type="unfinished">Coordenada X:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="247"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Coordenada Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="261"/>
        <source>宽度：</source>
        <translation type="unfinished">Ancho:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="271"/>
        <source>高度：</source>
        <translation type="unfinished">Alto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="579"/>
        <source>链接路径：</source>
        <translation type="unfinished">Ruta de enlace:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="292"/>
        <source>字体设置：</source>
        <translation type="unfinished">Config. de fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="315"/>
        <source>字体：</source>
        <translation type="unfinished">Fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="329"/>
        <source>字体大小：</source>
        <translation type="unfinished">Tamaño de fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="345"/>
        <source>效果：</source>
        <translation type="unfinished">Efecto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="352"/>
        <source>粗体</source>
        <translation type="unfinished">Negrita</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="359"/>
        <source>斜体</source>
        <translation type="unfinished">Cursiva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="366"/>
        <source>删除线</source>
        <translation type="unfinished">Tachado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="373"/>
        <source>下划线</source>
        <translation type="unfinished">Subrayado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="391"/>
        <source>决策：</source>
        <translation type="unfinished">Decisión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="409"/>
        <source>颜色决策</source>
        <translation type="unfinished">Decisión de color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="419"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="440"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="461"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="482"/>
        <source>更多</source>
        <translation type="unfinished">Más</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="430"/>
        <source>字符决策</source>
        <translation type="unfinished">Decisión de carácter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="451"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Decisión de parpadeo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="472"/>
        <source>使能决策</source>
        <translation type="unfinished">Decisión de habilitación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="500"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="535"/>
        <source>数据库：</source>
        <translation type="unfinished">Base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="518"/>
        <source>应用：    </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="568"/>
        <source>检索</source>
        <translation type="unfinished">Búsqueda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="593"/>
        <source>条件：    </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="607"/>
        <source>对象ID：  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="617"/>
        <source>对象域：</source>
        <translation type="unfinished">Dominio de objeto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="638"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="658"/>
        <source>确定并退出</source>
        <translation type="unfinished">Confirmar y salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="665"/>
        <source>添加</source>
        <translation type="unfinished">Agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.cpp" line="121"/>
        <source>中对齐</source>
        <translation type="unfinished">Alineación centro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.cpp" line="122"/>
        <source>左对齐</source>
        <translation type="unfinished">Alineación izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.cpp" line="123"/>
        <source>右对齐</source>
        <translation type="unfinished">Alineación a la derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.cpp" line="124"/>
        <source>上对齐</source>
        <translation type="unfinished">Alineación arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.cpp" line="125"/>
        <source>下对齐</source>
        <translation type="unfinished">Alineación abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.cpp" line="129"/>
        <source>向右延展</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.cpp" line="181"/>
        <source>退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.cpp" line="193"/>
        <source>确认并退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar y salir</translation>
    </message>
</context>
<context>
    <name>DlgTextAdvancedConfig</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="39"/>
        <source>文本高级配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="57"/>
        <source>前缀文本：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="60"/>
        <source>在主文本前显示的内容</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="66"/>
        <source>后缀文本：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="69"/>
        <source>在主文本后显示的内容</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="75"/>
        <source>过滤文本：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="78"/>
        <source>用于过滤的文本条件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="84"/>
        <source>自动刷新文本：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="89"/>
        <source>启用</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="92"/>
        <source>点击按钮选择刷新字段</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="93"/>
        <source>选择字段</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="108"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="110"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>DlgValueTemplateSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="14"/>
        <source>数值前景</source>
        <translation type="unfinished">Primer plano numérico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="24"/>
        <source>数据配置</source>
        <translation type="unfinished">Config. de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="42"/>
        <source>数据路径：</source>
        <translation type="unfinished">Ruta de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="52"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="679"/>
        <source>清除</source>
        <translation type="unfinished">Borrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="62"/>
        <source>属性定义</source>
        <translation type="unfinished">Definición de atributos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="74"/>
        <source>基本设置：</source>
        <translation type="unfinished">Config. básica:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="94"/>
        <source>文本：</source>
        <translation type="unfinished">Texto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="108"/>
        <source>显示文本</source>
        <translation type="unfinished">Mostrar Texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="119"/>
        <source>对齐：</source>
        <translation type="unfinished">Alineación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="129"/>
        <source>竖排</source>
        <translation type="unfinished">Vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="140"/>
        <source>文字颜色：</source>
        <translation type="unfinished">Color de texto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="147"/>
        <source>文字颜色</source>
        <translation type="unfinished">Color de texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="156"/>
        <source>枚举</source>
        <translation type="unfinished">Enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="167"/>
        <source>前景颜色：</source>
        <translation type="unfinished">Color de primer plano:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="174"/>
        <source>填充色</source>
        <translation type="unfinished">Color de relleno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="183"/>
        <source>填充颜色</source>
        <translation type="unfinished">Color de relleno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="194"/>
        <source>边框色</source>
        <translation type="unfinished">Color de borde</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="201"/>
        <source>边框颜色</source>
        <translation type="unfinished">Color del borde</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="216"/>
        <source>函数取值</source>
        <translation type="unfinished">Valor de función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="227"/>
        <source>X坐标：</source>
        <translation type="unfinished">Coordenada X:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="237"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Coordenada Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="251"/>
        <source>宽度：</source>
        <translation type="unfinished">Ancho:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="261"/>
        <source>高度：</source>
        <translation type="unfinished">Alto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="282"/>
        <source>字体设置：</source>
        <translation type="unfinished">Config. de fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="305"/>
        <source>字体：</source>
        <translation type="unfinished">Fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="319"/>
        <source>字体大小：</source>
        <translation type="unfinished">Tamaño de fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="335"/>
        <source>效果：</source>
        <translation type="unfinished">Efecto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="342"/>
        <source>粗体</source>
        <translation type="unfinished">Negrita</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="349"/>
        <source>斜体</source>
        <translation type="unfinished">Cursiva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="356"/>
        <source>删除线</source>
        <translation type="unfinished">Tachado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="363"/>
        <source>下划线</source>
        <translation type="unfinished">Subrayado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="381"/>
        <source>显示：</source>
        <translation type="unfinished">Mostrar:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="402"/>
        <source>显示格式：</source>
        <translation type="unfinished">Formato de visualización:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="459"/>
        <source>显示前缀：</source>
        <translation type="unfinished">Mostrar prefijo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="441"/>
        <source>显示后缀：</source>
        <translation type="unfinished">Mostrar sufijo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="420"/>
        <source>小数点位数：</source>
        <translation type="unfinished">Núm. de decimales:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="432"/>
        <source>LCD显示</source>
        <translation type="unfinished">Visualización LCD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="477"/>
        <source>是否延展</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="489"/>
        <source>允许修改</source>
        <translation type="unfinished">Permitir modificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="505"/>
        <source>决策：</source>
        <translation type="unfinished">Decisión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="523"/>
        <source>颜色决策</source>
        <translation type="unfinished">Decisión de color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="533"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="554"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="575"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="596"/>
        <source>更多</source>
        <translation type="unfinished">Más</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="544"/>
        <source>字符决策</source>
        <translation type="unfinished">Decisión de carácter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="565"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Decisión de parpadeo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="586"/>
        <source>使能决策</source>
        <translation type="unfinished">Decisión de habilitación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="614"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="649"/>
        <source>数据库：</source>
        <translation type="unfinished">Base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="697"/>
        <source>链接路径：</source>
        <translation type="unfinished">Ruta de enlace:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="686"/>
        <source>检索</source>
        <translation type="unfinished">Búsqueda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="632"/>
        <source>应用：    </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="711"/>
        <source>条件：    </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="725"/>
        <source>对象ID：  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="735"/>
        <source>对象域：</source>
        <translation type="unfinished">Dominio de objeto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="756"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="776"/>
        <source>确定并退出</source>
        <translation type="unfinished">Confirmar y salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="783"/>
        <source>添加</source>
        <translation type="unfinished">Agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.cpp" line="119"/>
        <source>中对齐</source>
        <translation type="unfinished">Alineación centro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.cpp" line="120"/>
        <source>左对齐</source>
        <translation type="unfinished">Alineación izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.cpp" line="121"/>
        <source>右对齐</source>
        <translation type="unfinished">Alineación derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.cpp" line="122"/>
        <source>上对齐</source>
        <translation type="unfinished">Alineación arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.cpp" line="123"/>
        <source>下对齐</source>
        <translation type="unfinished">Alineación abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.cpp" line="127"/>
        <source>向右延展</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.cpp" line="195"/>
        <source>退出</source>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.cpp" line="204"/>
        <source>确认并退出</source>
        <translation type="unfinished">Confirmar y salir</translation>
    </message>
</context>
<context>
    <name>DrawView</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="1189"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="4292"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="4656"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="4761"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7584"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="10183"/>
        <source>场景指针为空,无法进行刷新操作</source>
        <translation type="unfinished">El puntero de la escena está vacío y no se puede actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="2313"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="2800"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="3257"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="19171"/>
        <source>场景指针为空,无法进行获取操作</source>
        <translation type="unfinished">El puntero de la escena está vacío y no se puede obtener</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="2972"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="3062"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="3192"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="19327"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="19423"/>
        <source>跳转</source>
        <translation type="unfinished">Saltar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5173"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5253"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5384"/>
        <source>颜色决策[%1]未找到</source>
        <translation type="unfinished">No se encontró la decisión de color [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5184"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5273"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5395"/>
        <source>使能决策[%1]未找到</source>
        <translation type="unfinished">No se encontró la decisión de habilitar [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5195"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5293"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5406"/>
        <source>字符决策[%1]未找到</source>
        <translation type="unfinished">No se encontró la decisión de carácter [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5206"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5313"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5417"/>
        <source>符号决策[%1]未找到</source>
        <translation type="unfinished">No se encontró la decisión de símbolo [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5217"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5333"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5428"/>
        <source>闪烁决策[%1]未找到</source>
        <translation type="unfinished">No se encontró la decisión de parpadeo [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5228"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5353"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5439"/>
        <source>函数决策[%1]未找到</source>
        <translation type="unfinished">No se encontró la decisión de función [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5261"/>
        <source>颜色决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished">Decisión color [%1] aplicación [%2] inconsistente con gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5281"/>
        <source>使能决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished">Decisión habilitar [%1] aplicación [%2] inconsistente con gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5301"/>
        <source>字符决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished">Decisión carácter [%1] aplicación [%2] inconsistente con gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5321"/>
        <source>符号决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished">Decisión símbolo [%1] aplicación [%2] inconsistente con gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5341"/>
        <source>闪烁决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished">Decisión parpadeo [%1] aplicación [%2] inconsistente con gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5361"/>
        <source>函数决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished">Decisión función [%1] aplicación [%2] inconsistente con gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5467"/>
        <source>当前画面背景资源文件[%1]无效</source>
        <translation type="unfinished">Archivo recursos fondo [%1] actual inválido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5500"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5507"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5539"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5546"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5619"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5626"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5658"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5665"/>
        <source>%1资源文件[%2]不在iasp目录下</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5516"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5555"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5635"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5674"/>
        <source>%1资源文件[%2]不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5837"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5858"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5879"/>
        <source>当前场景中的元素[%1]所处位置已经完全超出画布范围</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5987"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6016"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6084"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6102"/>
        <source>当前场景中的元素[%1]所处位置部分超出画布范围</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6443"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6448"/>
        <source>%1数据未关联</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6472"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6477"/>
        <source>%1数据未生效:获取目标对象oid失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6494"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6499"/>
        <source>%1数据未生效:目标对象oid[%2]与当前保存oid[%3]不一致</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6585"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6603"/>
        <source>%1不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6610"/>
        <source>%1存在空挂</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7103"/>
        <source>当前前景图元超过了一个元素</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7136"/>
        <source>当前前景图元没有元素</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7594"/>
        <source>文件[%1]已存在，是否覆盖并将词条重新写入该文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7599"/>
        <source>文件[%1]已存在，词条导出失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7651"/>
        <source>文件[%1]打开失败，词条导出失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7764"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8217"/>
        <source>默认值</source>
        <translation type="unfinished">Valor predeterminado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8826"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8898"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9224"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9281"/>
        <source>打开文件</source>
        <translation type="unfinished">Abrir archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8889"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8911"/>
        <source>填库失败</source>
        <translation type="unfinished">Fallo al llenar base datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8890"/>
        <source>当前画面属性未勾选填库，无法进行填库操作！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8912"/>
        <source>当前应用程序接口插件不可用，无法进行填库操作！</source>
        <translation type="unfinished">Plugin api actual no disponible, no puede llenar biblioteca!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8914"/>
        <source>填库结束</source>
        <translation type="unfinished">Fin del relleno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8964"/>
        <source>映射设备信息</source>
        <comment>toolName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9297"/>
        <source>映射结束</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9301"/>
        <source>映射失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9302"/>
        <source>当前应用程序接口插件不可用，无法进行映射操作！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9388"/>
        <source>已经缩放最大到最小比例32倍</source>
        <translation type="unfinished">Se ha escalado hasta 32 veces de la escala máxima a mínima</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9430"/>
        <source>已经缩放到最小比例0.05倍</source>
        <translation type="unfinished">Se ha escalado a 0.05 veces la escala mínima</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9457"/>
        <source>drawing%1.icoxml</source>
        <translation type="unfinished">drawing%1.icoxml</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9461"/>
        <source>drawing%1.xml</source>
        <translation type="unfinished">drawing%1.xml</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9706"/>
        <source>下载文件{}失败，返回值为{}</source>
        <translation type="unfinished">Fallo al descargar archivo {}, retorno {}</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9735"/>
        <source>G文件错误,请修改</source>
        <translation type="unfinished">Error en archivo G, modifique</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="10057"/>
        <source>删除图元提示</source>
        <translation type="unfinished">Eliminar icono de aviso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11663"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11982"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13920"/>
        <source>警告</source>
        <comment>toolName</comment>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11664"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11983"/>
        <source>图元态存在异常项，是否自动处理并保存?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11667"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11986"/>
        <source>处理并保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11668"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11987"/>
        <source>终止操作</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13921"/>
        <source>&apos;%1&apos; 已经被修改,是否保存</source>
        <translation type="unfinished">&apos;%1&apos; ha sido modificado, desea guardarlo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13924"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13925"/>
        <source>放弃</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Abortar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13926"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13977"/>
        <source>(草稿)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="19618"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="19618"/>
        <source>自动刷新连接数据库失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11545"/>
        <source>Save As</source>
        <translation type="unfinished">Guardar como</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11591"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11907"/>
        <source>%1至少有一个%2元素</source>
        <translation type="unfinished">%1 debe tener al menos un elemento %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11604"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11625"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11920"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11941"/>
        <source>%1只能有一个%2元素</source>
        <translation type="unfinished">%1 solo puede tener un elemento %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15210"/>
        <source>%1不在清除范围内</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15218"/>
        <source>%1不在清除范围内，其余项清除完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7593"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11590"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11603"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11624"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11820"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11824"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11906"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11919"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11940"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12139"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12143"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12193"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12491"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13885"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15243"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="17086"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="18837"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="19000"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8826"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9224"/>
        <source>无法写入文件 %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8898"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9281"/>
        <source>无法打开文件 %1:%2.</source>
        <translation type="unfinished">No se puede abrir archivo %1:%2.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="10058"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="10063"/>
        <source>以下图元已被删除：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="10923"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="18673"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="18846"/>
        <source>寻找连接关系对象</source>
        <comment>toolName</comment>
        <translation type="unfinished">Encontrar el Objeto de Rrelación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11086"/>
        <source>创建连接关系</source>
        <comment>toolName</comment>
        <translation type="unfinished">Crear Relación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11820"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12139"/>
        <source>图元文件保存成功！但文件大小超过500KB，请检查！</source>
        <translation type="unfinished">¡Archivo gráfico guardado! Tamaño &gt; 500KB, revise</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11824"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12143"/>
        <source>图元文件保存成功！</source>
        <translation type="unfinished">¡Archivo gráfico guardado con éxito!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12193"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12491"/>
        <source>画面应用信息或层信息为空，无法保存，请打开配置！</source>
        <translation type="unfinished">Info. de app o capa vacía, no se guarda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13369"/>
        <source>拖拽模式下不支持滚轮缩放</source>
        <translation type="unfinished">Modo arrastre no soporta zoom con rueda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13885"/>
        <source>当前用户没有操作权限,不保存直接退出</source>
        <translation type="unfinished">Sin permiso, salir sin guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="14003"/>
        <source>(草稿版本)</source>
        <translation type="unfinished">(Versión borrador)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="14007"/>
        <source>(最新版本)</source>
        <translation type="unfinished">(Última versión)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="14011"/>
        <source>(版本</source>
        <translation type="unfinished">(Versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15001"/>
        <source>二维表</source>
        <translation type="unfinished">Tabla 2d</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15006"/>
        <source>柱状图</source>
        <translation type="unfinished">Barras</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15011"/>
        <source>饼图</source>
        <translation type="unfinished">Gráfico circular</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15016"/>
        <source>进度条</source>
        <translation type="unfinished">Barra de progreso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15021"/>
        <source>环形图</source>
        <translation type="unfinished">Gráfico de anillo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15026"/>
        <source>电池</source>
        <translation type="unfinished">Batería</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15031"/>
        <source>仪表盘</source>
        <translation type="unfinished">Tablero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15038"/>
        <source>二维表中的子项</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15161"/>
        <source>是否清除所选元素的数据库连接，请确认</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15165"/>
        <source>是否清除该画面所有元素的数据库连接，请确认</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15170"/>
        <source>当前画面没有需要被清除数据库连接的元素</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15175"/>
        <source>清除数据库连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15223"/>
        <source>清除完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15243"/>
        <source>请先选择图元后再生成标签。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="17086"/>
        <source>路径更新完成</source>
        <translation type="unfinished">Ruta de actualización completada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="18837"/>
        <source>获取路径完成!</source>
        <translation type="unfinished">¡Ruta completada!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="19000"/>
        <source>获取OID完成!</source>
        <translation type="unfinished">Obteniendo OID completado!</translation>
    </message>
</context>
<context>
    <name>IconNodeList</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="33"/>
        <source>图元列表</source>
        <translation type="unfinished">Lista de figuras</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="33"/>
        <source>对象源名称</source>
        <translation type="unfinished">Nombre de fuente de objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="175"/>
        <source>添加图元类型</source>
        <translation type="unfinished">Agregar tipo de icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="178"/>
        <source>刷新图元字典</source>
        <translation type="unfinished">Actualizar directorio de iconos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="181"/>
        <source>添加图元</source>
        <translation type="unfinished">Agregar icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="187"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="190"/>
        <source>删除图元类型</source>
        <translation type="unfinished">Eliminar tipo de icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="199"/>
        <source>删除图元</source>
        <translation type="unfinished">Eliminar icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="205"/>
        <source>删除草稿</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="208"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="402"/>
        <source>显示待发布</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="395"/>
        <source>显示全部</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="723"/>
        <source>删除图元时指针为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="791"/>
        <source>图元[%1]删除失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="801"/>
        <source>删除图元类型时指针为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="808"/>
        <source>图元类型[%1]下存在未删除的图元，图元类型删除失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="840"/>
        <source>图元类型[%1]删除失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="854"/>
        <source>提示</source>
        <comment>toolName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="855"/>
        <source>请确认是否删除当前图元类型以及该图元类型下的所有图元</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="902"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="906"/>
        <source>信息</source>
        <translation type="unfinished">Mensaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="906"/>
        <source>图元类型以及图元类型下的图元全部删除成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="911"/>
        <source>该图元节点不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="184"/>
        <source>修改图元类型</source>
        <translation type="unfinished">Editar tipo de icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="196"/>
        <source>修改图元</source>
        <translation type="unfinished">Modificar icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="193"/>
        <source>发布图元</source>
        <translation type="unfinished">Publicar icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="202"/>
        <source>另存为</source>
        <translation type="unfinished">Guardar como</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="497"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="911"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="498"/>
        <source>图元已在节点：%1,进程号：%2,注册名：%3 中打开</source>
        <translation type="unfinished">El icono se ha abierto en el nodo: %1, PID: %2, NombreReg: %3</translation>
    </message>
</context>
<context>
    <name>PicNodeList</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="43"/>
        <source>画面列表</source>
        <translation type="unfinished">Lista de pantallas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="43"/>
        <source>对象源名称</source>
        <translation type="unfinished">Nombre de fuente de objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="152"/>
        <source>添加应用</source>
        <translation type="unfinished">Añadir aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="172"/>
        <source>发布画面类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="180"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="188"/>
        <source>删除应用</source>
        <translation type="unfinished">Eliminar App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="184"/>
        <source>修改应用</source>
        <translation type="unfinished">Modificar App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="160"/>
        <source>添加画面类型</source>
        <translation type="unfinished">Agregar tipo de gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="164"/>
        <source>修改画面类型</source>
        <translation type="unfinished">Editar tipo de gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="168"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="176"/>
        <source>删除画面类型</source>
        <translation type="unfinished">Eliminar tipo de gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="148"/>
        <source>添加画面</source>
        <translation type="unfinished">Agregar gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="200"/>
        <source>删除画面</source>
        <translation type="unfinished">Eliminar gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="196"/>
        <source>修改画面</source>
        <translation type="unfinished">Editar gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="156"/>
        <source>刷新列表</source>
        <translation type="unfinished">Actualizar lista</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="192"/>
        <source>发布画面</source>
        <translation type="unfinished">Publicar gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="204"/>
        <source>另存为</source>
        <translation type="unfinished">Guardar como</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="208"/>
        <source>清空历史版本</source>
        <translation type="unfinished">Limpiar versión histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="313"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="318"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="373"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="378"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="416"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="518"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="523"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="686"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="691"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="926"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="313"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="373"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="416"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="926"/>
        <source>目录名称已存在，请重新输入！</source>
        <translation type="unfinished">Nombre de dir. ya existe, reingrese</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="318"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="378"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="523"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="691"/>
        <source>添加失败！</source>
        <translation type="unfinished">¡Fallo al agregar!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="495"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="663"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="876"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1824"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1872"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1886"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1896"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1936"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1978"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2009"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2038"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2067"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2103"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2145"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2174"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2453"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2476"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2481"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2497"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2589"/>
        <source>提示</source>
        <translation type="unfinished">Consejo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="495"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="663"/>
        <source>请在库中先配置应用图类型</source>
        <translation type="unfinished">Configure tipo de gráfico de app en BD primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="518"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="686"/>
        <source>画面名称重复，请重新输入！</source>
        <translation type="unfinished">¡Nombre de pantalla repetido, reingrese!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="550"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="710"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2794"/>
        <source>草稿版本</source>
        <translation type="unfinished">Versión borrador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="790"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1484"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1568"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1674"/>
        <source>提示</source>
        <comment>toolName</comment>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="791"/>
        <source>请确认是否删除当前应用</source>
        <translation type="unfinished">Confirme si elimina app actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="884"/>
        <source>修改应用</source>
        <comment>toolName</comment>
        <translation type="unfinished">Modificar Aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1070"/>
        <source>删除画面失败，指针为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1123"/>
        <source>画面[%1]已在节点：%2,进程号：%3,注册名：%4 中打开</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1184"/>
        <source>画面[%1]删除失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1203"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1289"/>
        <source>删除画面目录失败，指针为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1273"/>
        <source>画面目录[%1]删除失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1280"/>
        <source>删除的画面目录[%1]不为空，删除失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1364"/>
        <source>应用目录[%1]删除失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1371"/>
        <source>删除的应用目录[%1]不为空，请检查报表和画面应用子对象数量，先将子对象全部删除</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1384"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1440"/>
        <source>画面指针为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1392"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1448"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1503"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1595"/>
        <source>获取待删除列表失败，当前最多支持创建10层画面类型,请检查</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1485"/>
        <source>请确认是否删除当前画面类型以及画面类型下所有的画面目录和画面</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1569"/>
        <source>请确认是否删除当前应用以及应用下所有的画面目录和画面</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1503"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1541"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1551"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1556"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1595"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1634"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1644"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1649"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1693"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1709"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1541"/>
        <source>该画面类型以及所有子项全部删除成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1556"/>
        <source>画面类型节点不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1634"/>
        <source>该画面应用以及所有子项全部删除成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1649"/>
        <source>画面应用节点不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1675"/>
        <source>当前操作会发布画面类型下所有的画面，请确认是否继续？</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1693"/>
        <source>获取待发布列表失败，当前最多支持创建10层画面类型,请检查</source>
        <translation type="unfinished">No se pudo obtener la lista para publicar. Actualmente, se pueden crear un máximo de 10 capas de tipos de gráficas. Verifique</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1709"/>
        <source>当前画面目录下没有需要发布的画面</source>
        <translation type="unfinished">No hay gráficas que necesiten ser publicados en el directorio de gráficas actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1719"/>
        <source>信息</source>
        <translation type="unfinished">Mensaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1824"/>
        <source>未查询到历史版本，无需清理！</source>
        <translation type="unfinished">No hay versiones hist., no hay que limpiar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1873"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2590"/>
        <source>画面已在节点：%1,进程号：%2,注册名：%3 中打开</source>
        <translation type="unfinished">El gráfico ya está abierto en el nodo: %1, PID: %2, NombreReg: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1887"/>
        <source>是</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1888"/>
        <source>否</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1897"/>
        <source>归零</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Establecer en cero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1898"/>
        <source>不归零</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No establecer en cero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1899"/>
        <source>取消操作</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1936"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2009"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2038"/>
        <source>版本归零成功！</source>
        <translation type="unfinished">¡Versión anulada con éxito!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1978"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2067"/>
        <source>版本归零失败！</source>
        <translation type="unfinished">¡Falló la anulación de versión!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2103"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2174"/>
        <source>清空历史版本成功！</source>
        <translation type="unfinished">¡Historial de versiones limpiado con éxito!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2145"/>
        <source>清空历史版本失败！</source>
        <translation type="unfinished">¡Falló al limpiar versiones históricas!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2207"/>
        <source>隐藏历史版本</source>
        <comment>menuName</comment>
        <translation type="unfinished">Ocult vers hist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2211"/>
        <source>显示历史版本</source>
        <comment>menuName</comment>
        <translation type="unfinished">Vers histor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="145"/>
        <source>显示历史版本</source>
        <translation type="unfinished">Mostrar versión histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="876"/>
        <source>删除的应用目录不为空，请检查报表和画面应用子对象数量，先将子对象全部删除</source>
        <translation type="unfinished">El directorio de la aplicación eliminada no está vacío. Verifique el número de subobjetos en el informe y las aplicaciones de gráficas, y elimine todos los subobjetos primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1886"/>
        <source>此操作将删除所有历史版本，是否继续</source>
        <translation type="unfinished">Eliminará todas las versiones hist., ¿seguir?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1896"/>
        <source>是否版本归零</source>
        <translation type="unfinished">¿Volver versión a cero?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2453"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2476"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2481"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2497"/>
        <source>未找到有效版本！</source>
        <translation type="unfinished">¡No se encontró versión válida!</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="3226"/>
        <source>草稿版本</source>
        <comment>PictureItem::displayChildren</comment>
        <translation type="unfinished">Versión de borrador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="3235"/>
        <source>最新版本</source>
        <comment>PictureItem::displayChildren</comment>
        <translation type="unfinished">Última versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="3258"/>
        <source>历史版本</source>
        <comment>PictureItem::displayChildren</comment>
        <translation type="unfinished">Versión histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="3312"/>
        <source>版本%1</source>
        <comment>HistoryItem::displayChildren</comment>
        <translation type="unfinished">Versión %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6659"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6666"/>
        <source>图元信息获取失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6719"/>
        <source>图元态信息中的图元态名为空的图元态信息删除完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6738"/>
        <source>图元态名称为空的图元态删除完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6746"/>
        <source>图元态名称为空,无法删除获取不到图元态信息的图元态名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6789"/>
        <source>根据图元名称[%1]获取不到图元信息的图元态名删除完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6797"/>
        <source>图元态名称为空,无法删除获取不到图元态名称的图元态信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6818"/>
        <source>根据图元态[%1]信息获取到了图元态名称，无需删除图元态[%1]信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6767"/>
        <source>根据图元态[%1]名称获取到了图元态信息，无需删除图元态名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6870"/>
        <source>根据图元态信息[%1]获取不到图元名称的图元态信息删除完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6878"/>
        <source>图元态名称为空,无法删除重复的图元态名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6899"/>
        <source>根据图元态[%1]名称获取不到图元态信息，请重新进行正确性检查</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6929"/>
        <source>图元态[%1]名称重复处理完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6937"/>
        <source>图元态名称为空,无法删除重复的图元态信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6958"/>
        <source>根据图元态[%1]信息获取不到图元态名称，请重新进行正确性检查</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7048"/>
        <source>图元态[%1]信息重复处理完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11695"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12014"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15171"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15210"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15218"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15223"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
</context>
<context>
    <name>SimplePictureTreeWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="3365"/>
        <source>画面选择</source>
        <translation type="unfinished">Seleccionar gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="3365"/>
        <source>原始名称</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
