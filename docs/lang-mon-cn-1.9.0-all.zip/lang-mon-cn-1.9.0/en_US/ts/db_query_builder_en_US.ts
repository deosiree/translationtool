<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>DbQueryBuilderEdit</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.ui" line="304"/>
        <source>=</source>
        <translation type="unfinished">=</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.ui" line="311"/>
        <source>!=</source>
        <translation type="unfinished">!=</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.ui" line="318"/>
        <source>&gt;</source>
        <translation type="unfinished">&gt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.ui" line="325"/>
        <source>&lt;</source>
        <translation type="unfinished">&lt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.ui" line="332"/>
        <source>&gt;=</source>
        <translation type="unfinished">&gt;=</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.ui" line="339"/>
        <source>&lt;=</source>
        <translation type="unfinished">&lt;=</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.ui" line="346"/>
        <source>LIKE</source>
        <translation type="unfinished">LIKE</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.ui" line="353"/>
        <source>AND</source>
        <translation type="unfinished">AND</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.ui" line="360"/>
        <source>OR</source>
        <translation type="unfinished">OR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.ui" line="367"/>
        <source>NOT</source>
        <translation type="unfinished">NOT</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.ui" line="374"/>
        <source>IN</source>
        <translation type="unfinished">IN</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.ui" line="381"/>
        <source>（</source>
        <translation type="unfinished">（</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.ui" line="388"/>
        <source>）</source>
        <translation type="unfinished">）</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.ui" line="448"/>
        <source>Cancel</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.ui" line="455"/>
        <source>OK</source>
        <translation type="unfinished">OK</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.cpp" line="76"/>
        <source>字段和条件 &gt; </source>
        <comment>buttonName</comment>
        <translation type="unfinished">Fields &amp;&amp; conds &gt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.cpp" line="77"/>
        <source>添加字段和条件</source>
        <translation type="unfinished">Add fields &amp;&amp; conds</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.cpp" line="78"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="49"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.cpp" line="79"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="50"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.cpp" line="81"/>
        <source>字段选择</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Field Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.cpp" line="82"/>
        <source>条件选择</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Condition Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.cpp" line="89"/>
        <source>修改</source>
        <comment>toolName</comment>
        <translation type="unfinished">Edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.cpp" line="179"/>
        <source>条件构造字段选择</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Select Construct Field</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.cpp" line="210"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_cond.cpp" line="137"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_cond.cpp" line="147"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_cond.cpp" line="153"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_cond.cpp" line="217"/>
        <source>条件生成器</source>
        <translation type="unfinished">Condition Generator</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_dlg.cpp" line="38"/>
        <source>条件生成器</source>
        <comment>toolName</comment>
        <translation type="unfinished">Condition Generator</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_dlg.cpp" line="107"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="412"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_dlg.cpp" line="108"/>
        <source>是否关闭条件生成器？</source>
        <translation type="unfinished">Whether to close the condition generator?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="68"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="579"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="598"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="605"/>
        <source>修改</source>
        <translation type="unfinished">Edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.cpp" line="210"/>
        <source>括号不匹配</source>
        <translation type="unfinished">Mismatched parentheses</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_cond.cpp" line="20"/>
        <source>操作符:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Operator:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_cond.cpp" line="21"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_field.cpp" line="18"/>
        <source>可选字段:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Optional fields:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_cond.cpp" line="22"/>
        <source>可选值:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Optional values:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_cond.cpp" line="23"/>
        <source>条件串选择结果:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Condition string result:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_cond.cpp" line="137"/>
        <source>请选择字段</source>
        <translation type="unfinished">Please select a field</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_cond.cpp" line="147"/>
        <source>请选择输入或者选择一个值!</source>
        <translation type="unfinished">Please choose input or select a value!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_cond.cpp" line="153"/>
        <source>请选择一个值!</source>
        <translation type="unfinished">Please select a value!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_cond.cpp" line="217"/>
        <source>请先输入左括号</source>
        <translation type="unfinished">Please enter the left parenthesis first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_table_model.cpp" line="158"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_table_model.cpp" line="162"/>
        <source>表名</source>
        <translation type="unfinished">Table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_table_model.cpp" line="168"/>
        <source>条件构造字段</source>
        <translation type="unfinished">Condition construct field</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_table_model.cpp" line="172"/>
        <source>已选字段</source>
        <translation type="unfinished">Selected fields</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_table_model.cpp" line="177"/>
        <source>条件串</source>
        <translation type="unfinished">Condition string</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_table_model.cpp" line="181"/>
        <source>操作</source>
        <translation type="unfinished">Operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="167"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="200"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="226"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="424"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="446"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="167"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="200"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="226"/>
        <source>数据库连接为空</source>
        <translation type="unfinished">DB connection is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="243"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="434"/>
        <source>条件解析失败</source>
        <translation type="unfinished">Condition parsing failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="47"/>
        <source>数据关联</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Data link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="51"/>
        <source>添加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="52"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="333"/>
        <source>高级配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="340"/>
        <source>快捷配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Quick config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="400"/>
        <source>是否删除</source>
        <translation type="unfinished">Whether to delete it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="401"/>
        <source>是否删除所选行及以下数据</source>
        <translation type="unfinished">Whether to delete the selected row and the following data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="412"/>
        <source>请选择要删除的行</source>
        <translation type="unfinished">Please select the row to be deleted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="424"/>
        <source>条件为空</source>
        <translation type="unfinished">Condition is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="446"/>
        <source>最后一行表不是目标表</source>
        <translation type="unfinished">The last row table is not the destination table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="456"/>
        <source>是否取消</source>
        <translation type="unfinished">Whether to cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_wgt.cpp" line="457"/>
        <source>是否取消操作并退出？</source>
        <translation type="unfinished">Whether to cancel the operation and exit?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_field.cpp" line="19"/>
        <source>已选字段:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Selected fields:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_table.cpp" line="18"/>
        <source>关系名:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Relationship name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_table.cpp" line="19"/>
        <source>表名:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Table name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit_table.cpp" line="20"/>
        <source>表选择:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Table Selection:</translation>
    </message>
</context>
<context>
    <name>iasp::dbms::DbQueryBuilderEdit</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.cpp" line="110"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_edit.cpp" line="110"/>
        <source>异常输入，请重新输入</source>
        <translation type="unfinished">Invalid input; please re-enter</translation>
    </message>
</context>
<context>
    <name>iasp::dbms::DbQueryBuilderTextEdit</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_text_edit.cpp" line="46"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_text_edit.cpp" line="59"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_text_edit.cpp" line="46"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_query_builder/db_query_builder_text_edit.cpp" line="59"/>
        <source>异常输入，请重新输入</source>
        <translation type="unfinished">Invalid input; please re-enter</translation>
    </message>
</context>
</TS>
