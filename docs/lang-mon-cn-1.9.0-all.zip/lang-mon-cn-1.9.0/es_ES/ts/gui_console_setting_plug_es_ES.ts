<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>AppSettingModuleConfigWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="62"/>
        <source>一级标题栏，%1重复</source>
        <translation type="unfinished">Barra de título principal, %1 está duplicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="66"/>
        <source>二级导航栏，%1重复</source>
        <translation type="unfinished">La barra de navegación secundaria, %1 está duplicada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="92"/>
        <source>重置文件</source>
        <translation type="unfinished">Restablecer archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="92"/>
        <source>是否重置</source>
        <translation type="unfinished">Desea restablecerlo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="92"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="120"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="203"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="211"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="92"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="120"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="120"/>
        <source>应用发布</source>
        <translation type="unfinished">Publicación de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="120"/>
        <source>是否发布</source>
        <translation type="unfinished">Publicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="144"/>
        <source>应用发布</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Publicar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="149"/>
        <source>取消修改</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar cambios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="151"/>
        <source>取消工具配置修改</source>
        <translation type="unfinished">Cancelar la modificación de la configuración de la herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="153"/>
        <source>上传</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Subir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="203"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="211"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="211"/>
        <source>发布成功，重启控制台生效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="62"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="66"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="70"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="74"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="70"/>
        <source>%1</source>
        <translation type="unfinished"> %1 </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="74"/>
        <source>保存失败</source>
        <translation type="unfinished">Error al guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="147"/>
        <source>发布配置</source>
        <translation type="unfinished">Publicar configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="155"/>
        <source>上传文件</source>
        <translation type="unfinished">Subir archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="203"/>
        <source>发布失败</source>
        <translation type="unfinished">Fallo en la publicación</translation>
    </message>
</context>
<context>
    <name>FCustomTreeWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="58"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="69"/>
        <source>请输入名称</source>
        <translation type="unfinished">Ingrese nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="71"/>
        <source>请添加描述</source>
        <translation type="unfinished">Agregue descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="72"/>
        <source>请输入启动命令</source>
        <translation type="unfinished">Ingrese comando de inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="103"/>
        <source>删除节点</source>
        <translation type="unfinished">Eliminar nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="59"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="70"/>
        <source>请选择图标</source>
        <translation type="unfinished">Seleccione ícono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="75"/>
        <source>不跟随启动</source>
        <translation type="unfinished">Sin inicio de seguimiento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="103"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="103"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="103"/>
        <source>是否删除</source>
        <translation type="unfinished">¿Eliminar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="359"/>
        <source>新建</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="362"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="365"/>
        <source>上移</source>
        <translation type="unfinished">Mover Arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="367"/>
        <source>下移</source>
        <translation type="unfinished">Mover hacia Abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="370"/>
        <source>验证</source>
        <translation type="unfinished">Validar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="382"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="382"/>
        <source>图标</source>
        <translation type="unfinished">Icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="382"/>
        <source>权限</source>
        <translation type="unfinished">Permiso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="382"/>
        <source>参数</source>
        <translation type="unfinished">Parámetro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="382"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="383"/>
        <source>跟随启动</source>
        <translation type="unfinished">Inicio acompañado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="383"/>
        <source>跟随关闭</source>
        <translation type="unfinished">Cierre acompañado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="383"/>
        <source>常驻</source>
        <translation type="unfinished">Residente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="383"/>
        <source>推画面最大进程数量</source>
        <translation type="unfinished">Máx. procesos de pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="384"/>
        <source>手动启动最大进程数量</source>
        <translation type="unfinished">Máx. procesos manuales</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="384"/>
        <source>ID</source>
        <translation type="unfinished">ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="384"/>
        <source>B端参数</source>
        <translation type="unfinished">Parámetros B-end</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="384"/>
        <source>启动弹窗</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MyDelegate</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="93"/>
        <source>选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Seleccionar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="110"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="174"/>
        <source>选择图标文件</source>
        <translation type="unfinished">Seleccionar archivo de ícono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="112"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="176"/>
        <source>PNG 文件</source>
        <translation type="unfinished">Archivo PNG</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="112"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="176"/>
        <source>SVG 文件</source>
        <translation type="unfinished">Archivo SVG</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="112"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="176"/>
        <source>JPG 文件</source>
        <translation type="unfinished">Archivo JPG</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="113"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="177"/>
        <source>图标文件</source>
        <translation type="unfinished">Archivo de icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="113"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="177"/>
        <source>所有文件</source>
        <translation type="unfinished">Todos los archivos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="140"/>
        <source>不跟随启动</source>
        <translation type="unfinished">No iniciar acompañado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="140"/>
        <source>自启动</source>
        <translation type="unfinished">Autoarranque</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="140"/>
        <source>自启动守护</source>
        <translation type="unfinished">Guardián de autoarranque</translation>
    </message>
</context>
<context>
    <name>SettinWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="47"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="48"/>
        <source>基础配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Config Básica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="50"/>
        <source>平台工具配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Herramienta de Plataforma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="51"/>
        <source>平台工具配置</source>
        <translation type="unfinished">Herramienta de Plataforma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="57"/>
        <source>应用工具配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Herramienta de la Aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="58"/>
        <source>应用工具配置</source>
        <translation type="unfinished">Configuración de la herramienta de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="73"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="73"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="73"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="73"/>
        <source>存在未保存修改，是否保存发布？</source>
        <translation type="unfinished">Hay modificaciones no guardadas. Desea guardarlas y publicarlas</translation>
    </message>
</context>
<context>
    <name>SettingBaseConfigWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="108"/>
        <source>固定</source>
        <translation type="unfinished">Fijo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="105"/>
        <source>任务栏高度设置：</source>
        <translation type="unfinished">Ajuste de altura de barra de tareas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="95"/>
        <source>启动画面显示屏设置：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="97"/>
        <source>主屏</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="98"/>
        <source>副屏</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="110"/>
        <source>高度：</source>
        <translation type="unfinished">Alto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="128"/>
        <source>显示搜索</source>
        <translation type="unfinished">Mostrar búsqueda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="129"/>
        <source>解裂退出</source>
        <translation type="unfinished">Salida dividida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="130"/>
        <source>控制台异机监护</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="164"/>
        <source>应用发布</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Publicación de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="166"/>
        <source>取消修改</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar cambios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="277"/>
        <source>发布成功，重启控制台生效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="283"/>
        <source>应用发布</source>
        <translation type="unfinished">Publicación de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="283"/>
        <source>是否发布</source>
        <translation type="unfinished">Publicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="297"/>
        <source>取消修改</source>
        <translation type="unfinished">Cancelar cambios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="297"/>
        <source>是否取消修改</source>
        <translation type="unfinished">Si desea cancelar la modificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="268"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="277"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="283"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="297"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="268"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="277"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="268"/>
        <source>发布失败</source>
        <translation type="unfinished">Fallo en la publicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="283"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="297"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>SettingModuleConfigWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="92"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="120"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="203"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="212"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="92"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="120"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="62"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="66"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="70"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="74"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="62"/>
        <source>一级导航栏，%1重复</source>
        <translation type="unfinished">Barra de navegación de primer nivel, %1 repetido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="66"/>
        <source>二级工具栏，%1重复</source>
        <translation type="unfinished">Barra de herramientas secundaria, %1 repetido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="70"/>
        <source>%1</source>
        <translation type="unfinished">%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="74"/>
        <source>保存失败</source>
        <translation type="unfinished">Guardado falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="92"/>
        <source>取消修改</source>
        <translation type="unfinished">Cancelar cambios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="92"/>
        <source>是否取消修改</source>
        <translation type="unfinished">Si desea cancelar la modificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="120"/>
        <source>应用发布</source>
        <translation type="unfinished">Publicación de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="120"/>
        <source>是否发布</source>
        <translation type="unfinished">Publicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="144"/>
        <source>应用发布</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Publicación de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="149"/>
        <source>取消修改</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar cambios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="151"/>
        <source>取消工具配置</source>
        <translation type="unfinished">Cancelar Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="153"/>
        <source>上传</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Subir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="155"/>
        <source>将本地文件上传到文件服务</source>
        <translation type="unfinished">Subir archivos locales al servicio de archivos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="203"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="212"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="212"/>
        <source>发布成功，重启控制台生效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="147"/>
        <source>发布配置</source>
        <translation type="unfinished">Config. de publicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="203"/>
        <source>发布失败</source>
        <translation type="unfinished">Publicación falló</translation>
    </message>
</context>
</TS>
