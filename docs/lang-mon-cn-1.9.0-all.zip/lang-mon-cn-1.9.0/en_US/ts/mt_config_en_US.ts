<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>iasp::smg::ExecutionDetailsDialog</name>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1146"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1276"/>
        <source>执行详情</source>
        <comment>toolName</comment>
        <translation type="unfinished">Exec Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1166"/>
        <source>应用名</source>
        <translation type="unfinished">App name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1166"/>
        <source>执行进度</source>
        <translation type="unfinished">Execution schedule</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1385"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1385"/>
        <source>执行结束</source>
        <translation type="unfinished">Execution completed</translation>
    </message>
</context>
<context>
    <name>iasp::smg::MtConfigWidgetImp</name>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="177"/>
        <source>应用名</source>
        <translation type="unfinished">App name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="177"/>
        <source>维护应用状态</source>
        <translation type="unfinished">Maint. App state</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="177"/>
        <source>维护节点</source>
        <translation type="unfinished">Maint. node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="177"/>
        <source>值班节点</source>
        <translation type="unfinished">Duty node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="177"/>
        <source>操作</source>
        <translation type="unfinished">Operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="229"/>
        <source>原维护节点维护库</source>
        <translation type="unfinished">MTDB of original maintenance node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="230"/>
        <source>值班节点运行库</source>
        <translation type="unfinished">TDB of duty node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="241"/>
        <source>数据源：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Data source:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="248"/>
        <source>新维护节点：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">New maintenance node:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="257"/>
        <source>应用</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Apply</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="260"/>
        <source>应用修改内容</source>
        <translation type="unfinished">Apply modification content</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="264"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="267"/>
        <source>刷新当前页面</source>
        <translation type="unfinished">Refresh current page</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="473"/>
        <source>历史版本</source>
        <comment>buttonName</comment>
        <translation type="unfinished">History version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="490"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="501"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="520"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="627"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="490"/>
        <source>当前应用没有维护节点</source>
        <translation type="unfinished">The current application does not have a maintenance node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="499"/>
        <source>查询[%1 %2]的维护库备份目录失败</source>
        <translation type="unfinished"> Failed to query the MTDB backup dir of [%1 %2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="518"/>
        <source>没有可用的数据库历史版本</source>
        <translation type="unfinished">No db history versions are available</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="627"/>
        <source>未选中维护应用, 请重新选择</source>
        <translation type="unfinished">No maintenance application is selected, please select one</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="717"/>
        <source>开始执行</source>
        <translation type="unfinished">Start execution</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="742"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="804"/>
        <source>系统管理接口实例获取失败</source>
        <translation type="unfinished">Failed to retrieve system management interface instance</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="762"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="861"/>
        <source>维护应用[%1]停止失败</source>
        <translation type="unfinished">Failed to stop maintenance application [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="776"/>
        <source>维护应用[%1]去除维护节点失败</source>
        <translation type="unfinished">Maintenance application [%1] failed to remove the maintenance node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="783"/>
        <source>维护应用[%1]去除维护节点, 执行完成</source>
        <translation type="unfinished">Removing the maintenance node in maintenance application [%1] is completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="792"/>
        <source>维护应用[%1]没有维护节点, 无需修改</source>
        <translation type="unfinished">The maintenance application [%1] does not have a maintenance node and does not need to be modified</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="816"/>
        <source>根据维护应用[%1]查询应用定义失败</source>
        <translation type="unfinished">Failed to query the application definition according to maintenance application [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="827"/>
        <source>根据应用定义[%1]查询应用定义失败</source>
        <translation type="unfinished">Failed to query the application definition according to the application definition [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="839"/>
        <source>查询应用[%1]的维护库失败</source>
        <translation type="unfinished">Failed to query the MTDB of application [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="868"/>
        <source>维护应用[%1]停止</source>
        <translation type="unfinished">Maintenance App [%1] stopped</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="884"/>
        <source>维护应用[%1]启动失败</source>
        <translation type="unfinished">Maintenance App [%1] failed to start</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="892"/>
        <source>维护应用[%1]启动</source>
        <translation type="unfinished">Maintenance App [%1] started</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="917"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="924"/>
        <source>数据源是维护库, 但应用[%1]原维护节点为空</source>
        <translation type="unfinished">The data source is the MTDB, but the original maintenance node of app [%1] is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="933"/>
        <source>数据源是维护库, 但应用[%1]新维护节点与旧维护节点都为[%2], 请检查配置重新设置</source>
        <translation type="unfinished">The data source is the MTDB, but [%1] is applied to both the new maintenance node and the old maintenance node as [%2], please check the config and reset</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="944"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="950"/>
        <source>查询运行库[%1 %2 %3 %4]的值班节点失败</source>
        <translation type="unfinished">Failed to query the duty node of the TDB [%1 %2 %3 %4]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="962"/>
        <source>实时库[%1]检查数据完成, 旧维护节点:%2, 新维护节点:%3, 数据源:%4</source>
        <translation type="unfinished">TDB [%1] finished checking data, old maintenance node:%2, new maintenance node:%3, data source:%4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="984"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1054"/>
        <source>ftp登录节点[%1]失败</source>
        <translation type="unfinished">Failed to log in to ftp node [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1000"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1066"/>
        <source>实时库[%1]从节点[%2][%3]下载到节点[%4][%5]失败</source>
        <translation type="unfinished">TDB [%1] failed to be downloaded from node [%2][%3] to node [%4][%5]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1025"/>
        <source>实时库[%1]删除索引文件失败</source>
        <translation type="unfinished">RTDB [%1] failed to delete index file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1032"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1083"/>
        <source>实时库[%1]从节点[%2][%3]下载到节点[%4][%5]完成</source>
        <translation type="unfinished">TDB [%1] is downloaded from node [%2][%3] to node [%4][%5]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1097"/>
        <source>实时库[%1]从节点[%2]目录[%3]拷贝到目录[%4]失败</source>
        <translation type="unfinished">Failed to copy TDB [%1] from node [%2] dir [%3] to dir [%4]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1111"/>
        <source>实时库[%1]传输完成</source>
        <translation type="unfinished">TDB [%1] transfer completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1121"/>
        <source>设置维护应用[%1]的新维护节点[%2]失败</source>
        <translation type="unfinished">In maintenance application [%1], failed to set new maintenance node [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1128"/>
        <source>维护应用[%1]设置新的维护节点</source>
        <translation type="unfinished">Maintenance application [%1] set a new maintenance node</translation>
    </message>
</context>
<context>
    <name>iasp::smg::ProgressDialog</name>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="283"/>
        <source>执行详情</source>
        <comment>toolName</comment>
        <translation type="unfinished">Exec Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="362"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="362"/>
        <source>执行结束</source>
        <translation type="unfinished">Execution completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="391"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="478"/>
        <source>开始执行</source>
        <translation type="unfinished">Start execution</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="413"/>
        <source>维护应用[%1]停止失败</source>
        <translation type="unfinished">Failed to stop maintenance application [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="419"/>
        <source>维护应用[%1]停止</source>
        <translation type="unfinished">Maintenance App [%1] stopped</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="435"/>
        <source>需要回退的数据库版本: %1</source>
        <translation type="unfinished">DB version need to be rolled back: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="461"/>
        <source>维护应用[%1]启动失败</source>
        <translation type="unfinished">Maintenance App [%1] failed to start</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="467"/>
        <source>维护应用[%1]启动</source>
        <translation type="unfinished">Maintenance App [%1] started</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="492"/>
        <source>解析全应用名[{}]失败</source>
        <translation type="unfinished">Parsing full App name [{}] failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="506"/>
        <source>系统管理接口实例获取失败</source>
        <translation type="unfinished">Failed to retrieve system management interface instance</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="533"/>
        <source>ftp登录节点[%1]失败</source>
        <translation type="unfinished">Failed to log in to ftp node [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="553"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="607"/>
        <source>实时库[%1]从节点[%2][%3]下载到节点[%4][%5]失败</source>
        <translation type="unfinished">TDB [%1] failed to be downloaded from node [%2][%3] to node [%4][%5]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="565"/>
        <source>实时库[%1]备份数据下载完成</source>
        <translation type="unfinished">TDB [%1] backup data download completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="583"/>
        <source>实时库[%1]从[%2]解压到节点[%3]失败</source>
        <translation type="unfinished">Failed to extract TDB [%1] from [%2] to node [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="591"/>
        <source>实时库[%1]备份数据解压完成</source>
        <translation type="unfinished">TDB [%1] backup data is extracted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="620"/>
        <source>实时库[%1]备份数据上传完成</source>
        <translation type="unfinished">TDB [%1] backup data upload completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="628"/>
        <source>实时库[%1]从节点[%2]目录[%3]拷贝到目录[%4]失败</source>
        <translation type="unfinished">Failed to copy TDB [%1] from node [%2] dir [%3] to dir [%4]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="641"/>
        <source>实时库[%1]回退到[%2]完成</source>
        <translation type="unfinished">TDB [%1] rollback to [%2] is completed</translation>
    </message>
</context>
<context>
    <name>iasp::smg::RollbackDialog</name>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="106"/>
        <source>不回退</source>
        <translation type="unfinished">No rollback</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="125"/>
        <source>回退版本</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Rollback</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="150"/>
        <source>数据库版本选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">DB Versions Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="177"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="177"/>
        <source>未选择数据库版本, 请重新选择</source>
        <translation type="unfinished">No db version is selected. Please select one</translation>
    </message>
</context>
</TS>
