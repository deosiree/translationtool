<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>BaseInfoWidget</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="206"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="210"/>
        <source>导入配置</source>
        <translation type="unfinished">Import config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="51"/>
        <source>请选择导入的配置文件:</source>
        <translation type="unfinished">Please select the config file to import:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="48"/>
        <source>导入配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Import config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="53"/>
        <source>导出配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Export config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="58"/>
        <source>设置系统数据标签</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Set system data tags</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="61"/>
        <source>触发运行库更新数据时标</source>
        <translation type="unfinished">Trigger RTDB to update data timestamp</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="63"/>
        <source>清除系统数据标签</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Erase system data tags</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="66"/>
        <source>触发运行库清除数据时标</source>
        <translation type="unfinished">Trigger RTDB to clear data timestamp</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="68"/>
        <source>系统数据跨现场同步</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cross-site sync</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="143"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="147"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="158"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="162"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="173"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="177"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="143"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="158"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="173"/>
        <source>触发成功</source>
        <translation type="unfinished">Triggered successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="147"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="162"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="177"/>
        <source>触发失败</source>
        <translation type="unfinished">Trigger failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="227"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="231"/>
        <source>导出配置</source>
        <translation type="unfinished">Export config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="56"/>
        <source>导出的配置文件:</source>
        <translation type="unfinished">Exported config file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="71"/>
        <source>触发运行库同步数据到外现场</source>
        <translation type="unfinished">Trigger RTDB to synchronize data to the external site</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="192"/>
        <source>无法导入配置</source>
        <translation type="unfinished">Unable to import config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="192"/>
        <source>请在无系统下执行导入</source>
        <translation type="unfinished">Please execute the import with no system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="206"/>
        <source>导入失败</source>
        <translation type="unfinished">Import failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="210"/>
        <source>%1导入成功，重启生效!</source>
        <translation type="unfinished">%1 import successful, restart effective!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="227"/>
        <source>导出失败</source>
        <translation type="unfinished">Export failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/base_info_widget.cpp" line="231"/>
        <source>%1导出成功</source>
        <translation type="unfinished">%1 export succeeded</translation>
    </message>
</context>
<context>
    <name>DlgAppDefDetails</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="40"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="41"/>
        <source>定义详情</source>
        <comment>toolName</comment>
        <translation type="unfinished">Definition Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="61"/>
        <source>现场依赖</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Site Dependency</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="62"/>
        <source>现场依赖</source>
        <translation type="unfinished">Site Dependency</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="63"/>
        <source>节点依赖</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Node Dependency</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="64"/>
        <source>节点依赖</source>
        <translation type="unfinished">Node Dependency</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="108"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="108"/>
        <source>获取应用定义表名失败</source>
        <translation type="unfinished">Failed to retrieve the application definition table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="142"/>
        <source>选中状态</source>
        <translation type="unfinished">Selected status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="142"/>
        <source>oid</source>
        <translation type="unfinished">Oid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="142"/>
        <source>全应用名</source>
        <translation type="unfinished">Full app name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="142"/>
        <source>基础应用名</source>
        <translation type="unfinished">Base app name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_appdef_details.cpp" line="142"/>
        <source>描述</source>
        <translation type="unfinished">Description</translation>
    </message>
</context>
<context>
    <name>DlgDefinitionDetails</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="41"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="42"/>
        <source>应用配置定义详情</source>
        <comment>toolName</comment>
        <translation type="unfinished">App Config Definition Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="55"/>
        <source>名称:</source>
        <translation type="unfinished">Name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="58"/>
        <source>别名:</source>
        <translation type="unfinished">Alias:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="61"/>
        <source>态类型:</source>
        <translation type="unfinished">State type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="74"/>
        <source>所属系统类型:</source>
        <translation type="unfinished">Assigned system type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="77"/>
        <source>启动优先级:</source>
        <translation type="unfinished">Startup priority:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="109"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="117"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="125"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="133"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="147"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="160"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="109"/>
        <source>获取应用进程表名失败</source>
        <translation type="unfinished">Failed to retrieve application process table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="117"/>
        <source>获取应用库定义表名失败</source>
        <translation type="unfinished">Failed to retrieve application db definition table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="125"/>
        <source>获取应用模块定义表名失败</source>
        <translation type="unfinished">Failed to retrieve application module definition table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="133"/>
        <source>获取应用进程失败</source>
        <translation type="unfinished">Failed to retrieve application process</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="147"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_definition_details.cpp" line="160"/>
        <source>获取应用库定义表失败</source>
        <translation type="unfinished">Failed to retrieve application db definition table</translation>
    </message>
</context>
<context>
    <name>DlgProgress</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="50"/>
        <source>任务切换</source>
        <comment>toolName</comment>
        <translation type="unfinished">Switch Task</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="58"/>
        <source>失败详情:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Failure details:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="77"/>
        <source>正在处理，请稍后...</source>
        <translation type="unfinished">Processing, please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="92"/>
        <source>正在执行操作，稍后可点击关闭!</source>
        <translation type="unfinished">Executing operation, you can click to close later!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="95"/>
        <source>退出对话框</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="305"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="327"/>
        <source>显示详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="321"/>
        <source>隐藏详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="105"/>
        <source>点击强制退出，可关闭当前执行操作框!</source>
        <translation type="unfinished">Click to force exit to close the current execution action box!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="152"/>
        <source>正在执行，请稍后...</source>
        <translation type="unfinished">Executing, please wait…</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="358"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="417"/>
        <source>关闭</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_progress.cpp" line="421"/>
        <source>正在执行操作，稍后可点击关闭</source>
        <translation type="unfinished">The operation is in progress. You can click to close it later.</translation>
    </message>
</context>
<context>
    <name>DlgSvcprocOrTdbrunInfo</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_svcproc_or_tdbrun_info.cpp" line="43"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_svcproc_or_tdbrun_info.cpp" line="44"/>
        <source>应用进程定义</source>
        <comment>toolName</comment>
        <translation type="unfinished">App Process Definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_svcproc_or_tdbrun_info.cpp" line="50"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_svcproc_or_tdbrun_info.cpp" line="51"/>
        <source>应用库定义</source>
        <comment>toolName</comment>
        <translation type="unfinished">App DB Definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_svcproc_or_tdbrun_info.cpp" line="56"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_svcproc_or_tdbrun_info.cpp" line="57"/>
        <source>应用定义</source>
        <comment>toolName</comment>
        <translation type="unfinished">App Definition</translation>
    </message>
</context>
<context>
    <name>DlgSwichSystem</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_swich_system.cpp" line="38"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_swich_system.cpp" line="85"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_swich_system.cpp" line="95"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_swich_system.cpp" line="38"/>
        <source>获取系统类型列表错误</source>
        <translation type="unfinished">Failed to retrieve system type list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_swich_system.cpp" line="53"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_swich_system.cpp" line="54"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_swich_system.cpp" line="85"/>
        <source>新增系统失败</source>
        <translation type="unfinished">Failed to add system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/dlg_swich_system.cpp" line="95"/>
        <source>系统名称为空，请重新输入</source>
        <translation type="unfinished">System name is empty, please re-enter</translation>
    </message>
</context>
<context>
    <name>HandleTableData</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="261"/>
        <source>(*可编辑)</source>
        <translation type="unfinished">(* Editable)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="267"/>
        <source>在线时运行</source>
        <translation type="unfinished">Running online</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="280"/>
        <source>进程类型</source>
        <translation type="unfinished">Process type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="292"/>
        <source>操作</source>
        <translation type="unfinished">Operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="296"/>
        <source>节点IP</source>
        <translation type="unfinished">Node IP</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="493"/>
        <source>不选择</source>
        <translation type="unfinished">No select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="913"/>
        <source>关键进程</source>
        <translation type="unfinished">Key Process</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="917"/>
        <source>普通进程</source>
        <translation type="unfinished">General process</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/handle_table_data.cpp" line="1070"/>
        <source>查看定义</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Definition</translation>
    </message>
</context>
<context>
    <name>LeftSysDeptTree</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="64"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="80"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="89"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="98"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="64"/>
        <source>获取现场部署失败</source>
        <translation type="unfinished">Failed to retrieve field deployment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="80"/>
        <source>获取现场表名称失败</source>
        <translation type="unfinished">Failed to retrieve the field table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="89"/>
        <source>获取节点表名称失败</source>
        <translation type="unfinished">Failed to retrieve node table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="98"/>
        <source>获取应用部署表名称失败</source>
        <translation type="unfinished">Failed to retrieve application deployment table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="156"/>
        <source>运行应用</source>
        <translation type="unfinished">Running App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="210"/>
        <source>维护应用</source>
        <translation type="unfinished">Maintenance App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/left_sysdep_tree.cpp" line="318"/>
        <source>获取系统列表错误</source>
        <translation type="unfinished">Obtain system list error</translation>
    </message>
</context>
<context>
    <name>RightSysdepInfoFrame</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="66"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="69"/>
        <source>新增</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="70"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="73"/>
        <source>批量增</source>
        <translation type="unfinished">Batch Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="74"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="77"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="79"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="82"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="84"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="87"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="172"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="237"/>
        <source>名称:</source>
        <translation type="unfinished">Name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="192"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="254"/>
        <source>描述:</source>
        <translation type="unfinished">Description:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="211"/>
        <source>现场类型:</source>
        <translation type="unfinished">Site type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="271"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="362"/>
        <source>部署应用:</source>
        <translation type="unfinished">Deploying App:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="309"/>
        <source>关联的应用定义:</source>
        <translation type="unfinished">Linked App definitions:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="314"/>
        <source>维护节点:</source>
        <translation type="unfinished">Maint. node:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="319"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="568"/>
        <source>部署节点:</source>
        <translation type="unfinished">Deployment node:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="399"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="407"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="469"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="477"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="846"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="871"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="899"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="925"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="958"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1034"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1056"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1079"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1111"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1140"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="399"/>
        <source>获取服务进程部署表名失败</source>
        <translation type="unfinished">Failed to retrieve service process deployment table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="407"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="477"/>
        <source>获取运行库部署表名失败</source>
        <translation type="unfinished">Failed to retrieve RTDB deployment table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="469"/>
        <source>获取维护库表名失败</source>
        <translation type="unfinished">Failed to retrieve MTDB table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="529"/>
        <source>运行库值班信息</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">RTDB Duty Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="530"/>
        <source>运行库值班信息</source>
        <translation type="unfinished">RTDB Duty Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="555"/>
        <source>核心进程</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Core Process</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="556"/>
        <source>核心进程</source>
        <translation type="unfinished">core process</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="656"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="687"/>
        <source>值班节点名称</source>
        <translation type="unfinished">Duty node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="656"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="687"/>
        <source>库名称</source>
        <translation type="unfinished">DB name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="656"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="687"/>
        <source>库描述</source>
        <translation type="unfinished">DB description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="846"/>
        <source>获取服务进程失败</source>
        <translation type="unfinished">Failed to retrieve service process</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="871"/>
        <source>获取运行库信息失败</source>
        <translation type="unfinished">Failed to retrieve RTDB info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="899"/>
        <source>获取维护库信息失败</source>
        <translation type="unfinished">Failed to retrieve MTDB info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="925"/>
        <source>获取维护进程信息失败</source>
        <translation type="unfinished">Failed to retrieve maintenance process info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="958"/>
        <source>获取节点:{}的核心进程失败</source>
        <translation type="unfinished">Failed to retrieve the core process of node: {}</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1034"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1111"/>
        <source>应用部署表失败</source>
        <translation type="unfinished">Failed to apply deployment table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1056"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1140"/>
        <source>节点表失败</source>
        <translation type="unfinished">Node table failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_frame.cpp" line="1079"/>
        <source>获取应用定义表失败</source>
        <translation type="unfinished">Failed to retrieve application definition table</translation>
    </message>
</context>
<context>
    <name>RightSysdepInfoTable</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="598"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="671"/>
        <source>整数输入</source>
        <translation type="unfinished">Integer Input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="598"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="671"/>
        <source>请输入一个1-10整数:</source>
        <translation type="unfinished">Please enter an integer between 1 and 10:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="898"/>
        <source>保存修改</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1075"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1157"/>
        <source>是否停应用</source>
        <translation type="unfinished">Stop App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="359"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="395"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="431"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="445"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="474"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="488"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="516"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="541"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="574"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="634"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1111"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1207"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1217"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1272"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1294"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1740"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1865"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1891"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1922"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1945"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2358"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2689"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2706"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2840"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2856"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2920"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2932"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3115"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3126"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3612"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="574"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="634"/>
        <source>验证失败</source>
        <translation type="unfinished">Validated failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="693"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="938"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1312"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1472"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2040"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2898"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3087"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3323"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="939"/>
        <source>此操作将停止正在运行的应用或服务，是否删除</source>
        <translation type="unfinished">This operation will stop the running application or service. Whether to delete it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1629"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3993"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1728"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2169"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2332"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2462"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2528"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2617"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2671"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2816"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3065"/>
        <source>失败</source>
        <translation type="unfinished">Fail</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1728"/>
        <source>无法删除</source>
        <translation type="unfinished">Unable to delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1736"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2079"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2143"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1736"/>
        <source>删除成功</source>
        <translation type="unfinished">Delete successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="693"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2040"/>
        <source>没有数据被修改</source>
        <translation type="unfinished">No data was modified</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2079"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2143"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2332"/>
        <source>现场名称重复</source>
        <translation type="unfinished">Duplicate site name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2169"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2365"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2373"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2496"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2504"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2714"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2963"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2971"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3157"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3165"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2365"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2496"/>
        <source>请检查!</source>
        <translation type="unfinished">Please check!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2373"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2504"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2971"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3165"/>
        <source>名称不能为空</source>
        <translation type="unfinished">Name is required</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2617"/>
        <source>应用部署所属应用定义重复</source>
        <translation type="unfinished">Duplicate Application Deployment of Assigned Application Definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2671"/>
        <source>应用部署重复</source>
        <translation type="unfinished">Duplicate application deployment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2816"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3065"/>
        <source>节点应用重复</source>
        <translation type="unfinished">Node App duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="359"/>
        <source>获取应用进程失败</source>
        <translation type="unfinished">Failed to retrieve application process</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="395"/>
        <source>获取应用库失败</source>
        <translation type="unfinished">Failed to retrieve application db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="431"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="474"/>
        <source>获取应用部署失败</source>
        <translation type="unfinished">Failed to retrieve application deployment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="445"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="488"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="516"/>
        <source>获取应用定义失败</source>
        <translation type="unfinished">Failed to retrieve application definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="541"/>
        <source>刷新系统类型失败</source>
        <translation type="unfinished">Failed to refresh system type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="898"/>
        <source>存在未保存更改，是否保存</source>
        <translation type="unfinished">Unsaved changes. Save?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1076"/>
        <source>修改值班优先级，需要停止节点应用，是否确认</source>
        <translation type="unfinished">To modify the duty priority, stop it on all nodes. Are you sure</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1111"/>
        <source>检查节点应用是否停止失败</source>
        <translation type="unfinished">Check whether the node App fails to stop</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1158"/>
        <source>修改维护节点，需要停止维护节点应用，是否确认</source>
        <translation type="unfinished">To modify the maintain node, stop the app on all maintenance nodes. Are you sure</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1207"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1217"/>
        <source>维护应用停止失败</source>
        <translation type="unfinished">Failed to stop maintenance application</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1272"/>
        <source>%1节点正在运行，不可删除</source>
        <translation type="unfinished">%1 node is running and cannot be deleted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1294"/>
        <source>%1现场正在运行，不可删除!</source>
        <translation type="unfinished">%1 the site is running and cannot be deleted!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1313"/>
        <source>删除配置项,会停止正在运行配置项的相关配置，是否确认</source>
        <translation type="unfinished">Deleting the config item will stop the related config of the running config item. Are you sure</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1472"/>
        <source>当前无权限</source>
        <translation type="unfinished">No permission</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1629"/>
        <source>删除后不可恢复，是否继续</source>
        <translation type="unfinished">It cannot be recovered after deletion.Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1740"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Please select the data to be operated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1865"/>
        <source>获取节点下的节点应用失败</source>
        <translation type="unfinished">Failed to retrieve the node App under the node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1891"/>
        <source>获取应用部署下的节点应用失败</source>
        <translation type="unfinished">Failed to retrieve node App under application deployment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1922"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2689"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2840"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2920"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3115"/>
        <source>刷新应用部署失败</source>
        <translation type="unfinished">Refresh application deployment failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="1945"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2856"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2932"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3126"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3612"/>
        <source>刷新节点失败</source>
        <translation type="unfinished">Refresh node failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2280"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2297"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2406"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2420"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2595"/>
        <source>异常输出</source>
        <translation type="unfinished">Abnormal output</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2280"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2297"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2406"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2420"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2595"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished">Abnormal query data, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2358"/>
        <source>刷新现场失败</source>
        <translation type="unfinished">Refresh site failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2462"/>
        <source>名称重复</source>
        <translation type="unfinished">Duplicate name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2528"/>
        <source>应用描述重复</source>
        <translation type="unfinished">Duplicate App description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2706"/>
        <source>添加失败</source>
        <translation type="unfinished">Add failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2714"/>
        <source>应用描述不可为空</source>
        <translation type="unfinished">Application description cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2899"/>
        <source>修改模块会停止当前应用,是否确认</source>
        <translation type="unfinished">Modifying the module will stop the current application. Are you sure</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="2963"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3157"/>
        <source>请检查</source>
        <translation type="unfinished">Please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3088"/>
        <source>此操作会停止当前应用,是否确认</source>
        <translation type="unfinished">This operation will stop the current application. Are you sure</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3195"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3197"/>
        <source>启动</source>
        <translation type="unfinished">Startup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3199"/>
        <source>停止</source>
        <translation type="unfinished">Stop</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3201"/>
        <source>禁用</source>
        <translation type="unfinished">Disable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3203"/>
        <source>解除禁用</source>
        <translation type="unfinished">Enable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3205"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3921"/>
        <source>实时日志</source>
        <translation type="unfinished">Real-time log</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3208"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3948"/>
        <source>历史日志</source>
        <translation type="unfinished">History log</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3211"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3964"/>
        <source>崩溃报告</source>
        <translation type="unfinished">Crash report</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3214"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3983"/>
        <source>数据交互</source>
        <translation type="unfinished">Data interaction</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3236"/>
        <source>恢复</source>
        <translation type="unfinished">Recover</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3323"/>
        <source>执行失败，应用部署下节点应用为空</source>
        <translation type="unfinished">Execution failed, the node application under application deployment is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="3993"/>
        <source>%1打开失败</source>
        <translation type="unfinished">%1 open failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/widget/right_sysdep_info_table.cpp" line="4181"/>
        <source>失败原因:%1</source>
        <translation type="unfinished">Reason for failure: %1</translation>
    </message>
</context>
<context>
    <name>RunSwitchThread</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/thread/run_switch_thread.cpp" line="410"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/thread/run_switch_thread.cpp" line="411"/>
        <source>当前无其他可值班节点，是否确定切离线</source>
        <translation type="unfinished">Currently, there are no other on duty nodes. Are you sure to switch off line</translation>
    </message>
</context>
<context>
    <name>SysDepMainWidget</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="79"/>
        <source>更新</source>
        <translation type="unfinished">Update</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="80"/>
        <source>部署内容存在修改，是否更新</source>
        <translation type="unfinished">The deployment content has been modified. Should it be updated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="85"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="285"/>
        <source>基础操作</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Basic Operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="286"/>
        <source>基础操作</source>
        <translation type="unfinished">Basic Operations</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="298"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="298"/>
        <source>获取现场部署失败</source>
        <translation type="unfinished">Failed to retrieve field deployment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="378"/>
        <source>现场基本信息</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Local Site Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="379"/>
        <source>现场基本信息</source>
        <translation type="unfinished">Local Site Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="380"/>
        <source>系统管理</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Sysmgr</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="381"/>
        <source>系统管理</source>
        <translation type="unfinished">Sysmgr</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="382"/>
        <source>运维管理</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Sysops</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="383"/>
        <source>运维管理</source>
        <translation type="unfinished">Sysops</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="388"/>
        <source>维护库切换</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">M-RTDB Switch</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="389"/>
        <source>维护库切换</source>
        <translation type="unfinished">MTDB Switch</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="599"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_mainwidget.cpp" line="599"/>
        <source>%1存在更改，请检查</source>
        <translation type="unfinished">%1 has changes, please check</translation>
    </message>
</context>
<context>
    <name>SysDepPlugin</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_plugin.cpp" line="115"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_plugin.cpp" line="126"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_plugin.cpp" line="115"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysdep_plugin.cpp" line="126"/>
        <source>%1存在修改项!</source>
        <translation type="unfinished">Modifications exist in %1!</translation>
    </message>
</context>
<context>
    <name>SysRunPlugin</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/sysrun_pugin.cpp" line="115"/>
        <source>应用部署</source>
        <translation type="unfinished">App Deployment</translation>
    </message>
</context>
<context>
    <name>SysrunSiteNumberInfo</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="66"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="73"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="100"/>
        <source>信息展示:</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="105"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="107"/>
        <source>别名</source>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="109"/>
        <source>现场类型</source>
        <translation type="unfinished">Site type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="136"/>
        <source>是否是本现场</source>
        <translation type="unfinished">Local site</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="138"/>
        <source>所属的系统</source>
        <translation type="unfinished">Assigned system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="141"/>
        <source>应用部署数量</source>
        <translation type="unfinished">Number of App deployments</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysmonitor/src/dialog/sysrun_site_number_info.cpp" line="143"/>
        <source>节点数量</source>
        <translation type="unfinished">Nodes count</translation>
    </message>
</context>
</TS>
