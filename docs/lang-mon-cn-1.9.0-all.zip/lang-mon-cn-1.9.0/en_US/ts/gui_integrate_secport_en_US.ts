<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>PortInfo</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.ui" line="14"/>
        <source>PortInfo</source>
        <translation type="unfinished">PortInfo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.ui" line="32"/>
        <source>开放端口</source>
        <translation type="unfinished">Open Port</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.ui" line="72"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.cpp" line="71"/>
        <source>WINDOWS节点不支持加固，无法获取端口信息</source>
        <translation type="unfinished">WINDOWS nodes do not support reinforcement and cannot retrieve port info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.cpp" line="74"/>
        <source>端口信息</source>
        <translation type="unfinished">Port info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.cpp" line="76"/>
        <source>当前节点未进行加固, 无法获取端口信息</source>
        <translation type="unfinished">The current node has not been reinforced and cannot retrieve port info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.cpp" line="129"/>
        <source>协议</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Protocol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.cpp" line="129"/>
        <source>端口</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Port</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.cpp" line="149"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.cpp" line="149"/>
        <source>刷新成功</source>
        <translation type="unfinished">Refresh successfully</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/plugin_sec_port.cpp" line="42"/>
        <source>开放端口</source>
        <translation type="unfinished">Open Port</translation>
    </message>
</context>
</TS>
