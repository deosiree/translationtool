<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>DlgSubviewConfig</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/dlg_subview_config.ui" line="22"/>
        <source>画面名称：</source>
        <translation type="unfinished">Graph name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/dlg_subview_config.ui" line="32"/>
        <source>选择画面</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/dlg_subview_config.ui" line="43"/>
        <source>是否显示横向滚动条</source>
        <translation type="unfinished">Display horizontal scrollbar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/dlg_subview_config.ui" line="50"/>
        <source>是否显示纵向滚动条</source>
        <translation type="unfinished">Display vertical scrollbar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/dlg_subview_config.ui" line="61"/>
        <source>是否背景透明</source>
        <translation type="unfinished">Background transparent</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/dlg_subview_config.ui" line="98"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/dlg_subview_config.ui" line="105"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/dlg_subview_config.cpp" line="35"/>
        <source>分图插件配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Sub-graph Plugin Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/dlg_subview_config.cpp" line="111"/>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/dlg_subview_config.cpp" line="116"/>
        <source>输入有误</source>
        <translation type="unfinished">Input error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/dlg_subview_config.cpp" line="111"/>
        <source>该画面不存在</source>
        <translation type="unfinished">This graph does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/dlg_subview_config.cpp" line="116"/>
        <source>不能使用主图配置分画面</source>
        <translation type="unfinished">Cannot use main graph to configure sub-graph</translation>
    </message>
</context>
<context>
    <name>GraphicSubviewPlugin</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/graphic_subview_plugin.cpp" line="35"/>
        <source>平台分图对象插件集合</source>
        <translation type="unfinished">Platform Sub-graph object plug-in collection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/graphic_subview_plugin.cpp" line="43"/>
        <source>分图对象插件</source>
        <translation type="unfinished">Sub-graph object plugin</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/graphic_subview_plugin.cpp" line="114"/>
        <source>画面名称</source>
        <translation type="unfinished">Graph name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/graphic_subview_plugin.cpp" line="120"/>
        <source>画面对象oid</source>
        <translation type="unfinished">Graph object Oid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/graphic_subview_plugin.cpp" line="126"/>
        <source>是否背景透明</source>
        <translation type="unfinished">Background transparent</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/graphic_subview_plugin.cpp" line="132"/>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/graphic_subview_plugin.cpp" line="138"/>
        <source>是否显示横向滚动条</source>
        <translation type="unfinished">Display horizontal scrollbar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/graphic_subview_plugin.cpp" line="417"/>
        <source>跳转画面响应</source>
        <translation type="unfinished">Jump graph response</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/graphic_subview_plugin.cpp" line="420"/>
        <source>跳转动态模板响应</source>
        <translation type="unfinished">Jump dynamic template response</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/main.cpp" line="124"/>
        <source>用户 %1 没有对应的权限! </source>
        <comment>graphic_subview_plug::main</comment>
        <translation type="unfinished">User %1 does not have corresponding permissions!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/main.cpp" line="125"/>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/main.cpp" line="203"/>
        <source>提示</source>
        <comment>graphic_subview_plug::main</comment>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_subview_plug/main.cpp" line="203"/>
        <source>注册失败</source>
        <comment>graphic_subview_plug::main</comment>
        <translation type="unfinished">Reg failed</translation>
    </message>
</context>
</TS>
