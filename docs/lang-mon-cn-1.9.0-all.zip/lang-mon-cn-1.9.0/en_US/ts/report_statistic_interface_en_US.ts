<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>ReportStatisticInterface</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/report_statistic_interface.cpp" line="66"/>
        <source>算法</source>
        <translation type="unfinished">Algorithm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/report_statistic_interface.cpp" line="67"/>
        <source>统计任务</source>
        <translation type="unfinished">Statistical tasks</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/report_statistic_interface.cpp" line="71"/>
        <source>任务名称</source>
        <translation type="unfinished">Task name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/report_statistic_interface.cpp" line="77"/>
        <source>测点</source>
        <translation type="unfinished">Measuring point</translation>
    </message>
</context>
<context>
    <name>StatisticDefineWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="20"/>
        <source>统计配置</source>
        <translation type="unfinished">Statistics Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="48"/>
        <source>统计配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Statistics Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="55"/>
        <source>模拟量单点</source>
        <translation type="unfinished">Analog single point</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="60"/>
        <source>累积量多点</source>
        <translation type="unfinished">More cumulative amount</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="65"/>
        <source>遥控多点</source>
        <translation type="unfinished">Multi-Point telecontrol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="79"/>
        <source>统计任务：</source>
        <translation type="unfinished">Statistical tasks:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="87"/>
        <source>常规日统计</source>
        <translation type="unfinished">Regular day statistics</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="92"/>
        <source>越限日统计</source>
        <translation type="unfinished">Statistics of days exceeded</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="97"/>
        <source>常规月统计</source>
        <translation type="unfinished">Regular monthly statistics</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="111"/>
        <source>算法：</source>
        <translation type="unfinished">Algorithm:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="125"/>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="293"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="130"/>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="298"/>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="135"/>
        <source>3</source>
        <translation type="unfinished">3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="140"/>
        <source>4</source>
        <translation type="unfinished">4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="145"/>
        <source>名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="150"/>
        <source>别名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="155"/>
        <source>选择</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="239"/>
        <source>测点配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Measuring Points Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="245"/>
        <source>上移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Move up</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="252"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="259"/>
        <source>下移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Move down</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="165"/>
        <source>平均值</source>
        <translation type="unfinished">Avg</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="183"/>
        <source>最大值</source>
        <translation type="unfinished">Maximum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="201"/>
        <source>最小值</source>
        <translation type="unfinished">Minimum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="222"/>
        <source>负荷率</source>
        <translation type="unfinished">Load rate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="266"/>
        <source>...</source>
        <translation type="unfinished">…</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="303"/>
        <source>测点名称</source>
        <translation type="unfinished">Measuring point name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="308"/>
        <source>测点路径</source>
        <translation type="unfinished">Measuring point path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="313"/>
        <source>tag1</source>
        <translation type="unfinished">tag1</translation>
    </message>
</context>
</TS>
