<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>GuiSmartSetupTool</name>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="111"/>
        <source>初始化失败，请检查配置后重试</source>
        <translation type="unfinished">Fallo en la inicialización. Verifique la configuración e intente de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="311"/>
        <source>连接地址：</source>
        <translation type="unfinished">Dirección de conexión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="319"/>
        <source>本地连接</source>
        <translation type="unfinished">Conexión local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="340"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="471"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="543"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="641"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="706"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="363"/>
        <source>节点名称：</source>
        <translation type="unfinished">Nombre del nodo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="369"/>
        <source>系统名称：</source>
        <translation type="unfinished">Nombre del Sistema:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="404"/>
        <source>A网地址 ：</source>
        <translation type="unfinished">Dirección de red A:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="407"/>
        <source>B网地址 ：</source>
        <translation type="unfinished">Dirección de red B:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="423"/>
        <source>IP信息：</source>
        <translation type="unfinished">Info de IP:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="424"/>
        <source>修改记录</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Editar registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="444"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3566"/>
        <source>新增IP</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Agregar IP</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="445"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3567"/>
        <source>删除IP</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar IP</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="447"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3569"/>
        <source>网口备注：</source>
        <translation type="unfinished">Observaciones de la interfaz de red:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="472"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="544"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="642"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="707"/>
        <source>应用</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Aplicar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="493"/>
        <source>工具界面：</source>
        <translation type="unfinished">Interfaz de la herramienta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="495"/>
        <source>操作系统：</source>
        <translation type="unfinished">Sistema operativo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="497"/>
        <source>后台服务：</source>
        <translation type="unfinished">Servicios de respaldo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="515"/>
        <source>本地平台界面语言设置，需重启本地gui_manager</source>
        <translation type="unfinished">La configuración del idioma de la interfaz de la plataforma local requiere reiniciar el gui_Manager local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="519"/>
        <source>本地操作系统语言设置，需重启本地操作系统</source>
        <translation type="unfinished">La configuración de idioma del sistema operativo local requiere un reinicio del sistema operativo local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="523"/>
        <source>本现场后台服务语言部署，在线修改</source>
        <translation type="unfinished">Despliegue del idioma del servicio de backend en el sitio, modificación en línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="607"/>
        <source>历史库类型：</source>
        <translation type="unfinished">Tipo de BD de histórica:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="622"/>
        <source>备注：现场所有系统停止到核心进程后生效，并将清理和重建历史库</source>
        <translation type="unfinished">Observación: Todos los sistemas en el sitio tomarán efecto después de que el proceso central se detenga, y la BD de historial será limpiada y reconstruida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="688"/>
        <source>新增节点</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Agregar nuevos nodos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="678"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1578"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3072"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3176"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3242"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3292"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3481"/>
        <source>以本现场节点为模板</source>
        <translation type="unfinished">Usar nodo en el sitio como modelo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="682"/>
        <source>部署提示：原则1现场节点数量不少于模板节点 原则2模板都需要被选择且不重复</source>
        <translation type="unfinished">Consejo de despliegue: Principio 1: El número de nodos en el sitio no debe ser menor que los nodos del modelo. Principio 2: Los modelos deben ser seleccionados y no duplicados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="689"/>
        <source>删除节点</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="695"/>
        <source>选择模板来源：</source>
        <translation type="unfinished">Seleccionar fuente del modelo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="771"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3601"/>
        <source>平台版本信息：暂无</source>
        <translation type="unfinished">Información de versión de la plataforma: temporalmente no disponible</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="775"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3605"/>
        <source>平台版本:</source>
        <translation type="unfinished">Versión de la plataforma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="885"/>
        <source>配置校验......</source>
        <translation type="unfinished">Verificando config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="890"/>
        <source>AB网地址错误，无法上传</source>
        <translation type="unfinished">Error en la dirección de red AB, no se puede subir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="986"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="995"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1006"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1020"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1026"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1040"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1077"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1222"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1291"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1295"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1301"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1304"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1309"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1346"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1353"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1558"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1666"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1714"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1784"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1827"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1884"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1913"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1930"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1971"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1975"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2019"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2033"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2046"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2059"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2072"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3058"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3364"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3611"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3614"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4050"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4094"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4157"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="995"/>
        <source>当前将多个网口设置网关，可能影响默认路由</source>
        <translation type="unfinished">Los gateways están configurados para múltiples puertos de red, lo que puede afectar la ruta predeterminada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="997"/>
        <source>是否继续修改</source>
        <translation type="unfinished">Desea continuar modificando</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1006"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1668"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1932"/>
        <source>节点名应为任意小写字母、数字和连字符组合</source>
        <translation type="unfinished">El nombre del nodo debe ser cualquier combinación de letras minúsculas, números y guiones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1008"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1669"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1933"/>
        <source>(连字符不能在开头或结尾)</source>
        <translation type="unfinished">(El guion no puede estar al principio ni al final)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1010"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1030"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1669"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1933"/>
        <source>且最大长度为31个字符</source>
        <translation type="unfinished">Y la longitud máxima es de 31 caracteres</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1026"/>
        <source>系统名应为任意字母、数字、连字符和下划线组合</source>
        <translation type="unfinished">El nombre del sistema debe ser cualquier combinación de letras, número, guiones y guiones bajos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1028"/>
        <source>(开头或结尾不能为符号)</source>
        <translation type="unfinished">(El inicio o el final no puede ser un símbolo)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1034"/>
        <source>校验完成......</source>
        <translation type="unfinished">Verificado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1040"/>
        <source>平台正在运行，是否停止平台以应用修改</source>
        <translation type="unfinished">La plataforma está en funcionamiento. Desea detener la plataforma para aplicar modificaciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1042"/>
        <source>(此操作会自动重启设备)</source>
        <translation type="unfinished">(Esta operación reiniciará el dispositivo)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1048"/>
        <source>停止平台中......</source>
        <translation type="unfinished">Deteniendo la plataforma 	</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1067"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1071"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1326"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1570"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1589"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1595"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1606"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1616"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1648"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1658"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1677"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1707"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1755"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1769"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1922"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4191"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1067"/>
        <source>平台停止命令执行失败，请重试</source>
        <translation type="unfinished">Falló la ejecución del comando de detención de la plataforma, por favor intente de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1071"/>
        <source>停止超时，请重试</source>
        <translation type="unfinished">Tiempo de espera agotado, por favor intente de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1077"/>
        <source>配置后会自动重启设备，是否继续</source>
        <translation type="unfinished">Después de la configuración, el dispositivo se reiniciará. ¿Continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1083"/>
        <source>配置中......</source>
        <translation type="unfinished">Configurando</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1103"/>
        <source>网口备注设置失败</source>
        <translation type="unfinished">Fallo al establecer comentarios del puerto de red</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1094"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1110"/>
        <source>系统名称配置失败</source>
        <translation type="unfinished">No se pudo establecer el nombre del sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1125"/>
        <source>配置节点名称失败</source>
        <translation type="unfinished">Error al configurar el nombre del nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1144"/>
        <source>ABC网配置失败</source>
        <translation type="unfinished">Fallo al configurar la red ABC</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1162"/>
        <source>IP配置失败</source>
        <translation type="unfinished">Falló la config de IP</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1195"/>
        <source>配置修改失败，请重试</source>
        <translation type="unfinished">Falló la config, por favor intente de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1198"/>
        <source>修改成功，重启机器......</source>
        <translation type="unfinished">Si la modificación es exitosa, reinicie la máquina......</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1291"/>
        <source>配置后台服务语言失败</source>
        <translation type="unfinished">Fallo al configurar el idioma del servicio de backend</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1295"/>
        <source>配置工具界面语言失败</source>
        <translation type="unfinished">Falló la configuración del idioma de la interfaz de la herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1301"/>
        <source>配置操作系统语言失败</source>
        <translation type="unfinished">Falló la configuración del idioma del sistema operativo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1304"/>
        <source>配置语言成功</source>
        <translation type="unfinished">Configuración del idioma exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1309"/>
        <source>配置语言成功,将立即重启</source>
        <translation type="unfinished">Configuración de idioma exitosa, se reiniciará inmediatamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1365"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1388"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1420"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1434"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1466"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1635"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1365"/>
        <source>初始化Sysmdl失败</source>
        <translation type="unfinished">Error al inicializar Sysmdl</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1398"/>
        <source>失败</source>
        <translation type="unfinished">Fallido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1388"/>
        <source>查找部署历史库服务的节点失败</source>
        <translation type="unfinished">No se pudo buscar nodos en el servicio de BD de historial de despliegue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1398"/>
        <source>当前没有部署历史库服务的节点，不执行切库</source>
        <translation type="unfinished">No hay nodos que hayan implementado el servicio de BD histórica, prohibido realizar particionamiento de bases de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1449"/>
        <source>正在停止节点非核心进程:</source>
        <translation type="unfinished">Deteniendo los procesos no esenciales del nodo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1462"/>
        <source>节点停止成功</source>
        <translation type="unfinished">Nodo detenido exitosamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1465"/>
        <source>节点停止失败</source>
        <translation type="unfinished">Fallo al detener el nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1466"/>
        <source>切库失败，节点%1停止失败</source>
        <translation type="unfinished">Fallo en el corte de la biblioteca, el nodo %1 no se detuvo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1476"/>
        <source>正在清理、重建数据库: %p%</source>
        <translation type="unfinished">Limpiando y reconstruyendo la BD:%p %</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1536"/>
        <source>超时</source>
        <translation type="unfinished">tiempo de espera</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1538"/>
        <source>清理旧数据库90s内未完成，是否继续等待</source>
        <translation type="unfinished">La limpieza de la antigua base de datos no se ha completado en 90 segundos. Desea continuar esperando</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1538"/>
        <source>(若取消需稍后重新设置)</source>
        <translation type="unfinished">(Si se cancela, restablecer más tarde)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="986"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1540"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1558"/>
        <source>库类型已切换</source>
        <translation type="unfinished">El tipo de BD ha sido cambiado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1570"/>
        <source>请选择一个模板并部署对应节点</source>
        <translation type="unfinished">Seleccione un modelo y despliegue el nodo correspondiente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1589"/>
        <source>来源节点选择重复</source>
        <translation type="unfinished">Selección duplicada de nodo fuente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1595"/>
        <source>存在模板节点未选择</source>
        <translation type="unfinished">Nodo de modelo no seleccionado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1606"/>
        <source>本节点未选模板，请选择</source>
        <translation type="unfinished">No se ha seleccionado un modelo para este nodo. Haga una selección</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1616"/>
        <source>当前存在节点未选模板</source>
        <translation type="unfinished">Actualmente hay nodos sin modelo seleccionado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1658"/>
        <source>现场节点名不能为空</source>
        <translation type="unfinished">El nombre del nodo en el sitio no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1677"/>
        <source>现场节点名称重复</source>
        <translation type="unfinished">Nombres de nodos duplicados en el sitio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1714"/>
        <source>模板校验通过，请确认停止所有节点的非核心进程(等待中途请勿操作)</source>
        <translation type="unfinished">La verificación de la plantilla fue exitosa, por favor confirme detener todos los procesos no esenciales de los nodos (no opere mientras espera)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1755"/>
        <source>停止非核心进程失败,请检查后重试</source>
        <translation type="unfinished">Error al detener los procesos no esenciales. Verifique e intente de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1769"/>
        <source>更新系统部署失败</source>
        <translation type="unfinished">Error al actualizar el despliegue del sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1778"/>
        <source>系统部署完成,等待重启</source>
        <translation type="unfinished">Despliegue del sistema completado, esperando reinicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1784"/>
        <source>系统部署成功，请确认重启部署节点系统</source>
        <translation type="unfinished">Despliegue del sistema exitoso, por favor confirme para reiniciar el sistema del nodo de despliegue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1789"/>
        <source>重启</source>
        <translation type="unfinished">Reiniciar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1793"/>
        <source>节点%1重启失败，请手动重启</source>
        <translation type="unfinished">El nodo %1 falló al reiniciar, por favor reinicie manualmente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1845"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4113"/>
        <source>已启动</source>
        <translation type="unfinished">Iniciado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1847"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4115"/>
        <source>平台已启动，正在启动应用</source>
        <translation type="unfinished">La plataforma ha comenzado. Iniciando la aplicación...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1849"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4117"/>
        <source>正在启动</source>
        <translation type="unfinished">Está iniciando</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1851"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4119"/>
        <source>系统未启动</source>
        <translation type="unfinished">Sistema no iniciado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1853"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4121"/>
        <source>系统正在退出</source>
        <translation type="unfinished">El sistema está saliendo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1880"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4147"/>
        <source>重启成功</source>
        <translation type="unfinished">Reinicio exitoso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1884"/>
        <source>在线节点重启成功，系统部署完成</source>
        <translation type="unfinished">Reinicio de nodo en línea exitoso, despliegue del sistema completado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1896"/>
        <source>获取待重启节点失败，请重试</source>
        <translation type="unfinished">No se pudo recuperar el nodo a reiniciar, por favor intente de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1913"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1971"/>
        <source>请先新增节点</source>
        <translation type="unfinished">Agregue un nuevo nodo primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1948"/>
        <source>，错误详情：</source>
        <translation type="unfinished">, detalles del error:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1953"/>
        <source>新增节点%1成功，模板%2</source>
        <translation type="unfinished">Nodo %1 agregado con éxito, modelo %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1959"/>
        <source>新增节点执行结束</source>
        <translation type="unfinished">Ejecución del nuevo nodo completada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3297"/>
        <source>注意</source>
        <translation type="unfinished">Atención</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3297"/>
        <source>无法删除现场节点部署</source>
        <translation type="unfinished">No se puede eliminar el despliegue del nodo en el sitio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3996"/>
        <source>清理初始化库成功，等待切换库类型</source>
        <translation type="unfinished">Biblioteca de inicialización limpiada con éxito, esperando cambiar tipos de biblioteca</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4002"/>
        <source>清理初始化库失败，请人工介入！</source>
        <translation type="unfinished">¡La limpieza de la biblioteca de inicialización falló, por favor intervenga manualmente!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4023"/>
        <source>---清理初始化库结束，成功%1个节点，失败%2个节点</source>
        <translation type="unfinished">---Limpieza de BD de inicialización completada, %1 nodos exitosos, %2 nodos fallidos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4152"/>
        <source>重启节点成功</source>
        <translation type="unfinished">Reinicio del nodo exitoso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1886"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4160"/>
        <source>本次操作执行结束，请确认关闭工具</source>
        <translation type="unfinished">Esta operación ha sido completada. Confirme para cerrar la herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4174"/>
        <source>重启节点失败</source>
        <translation type="unfinished">Falló el reinicio del nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4175"/>
        <source>重启失败请重试</source>
        <translation type="unfinished">Reinicio fallido, por favor intente de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1922"/>
        <source>节点名称不可为空</source>
        <translation type="unfinished">El nombre del nodo no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1860"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1869"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4128"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4136"/>
        <source>等待启动</source>
        <translation type="unfinished">Esperar inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1947"/>
        <source>新增节点%1失败</source>
        <translation type="unfinished">Fallo al agregar el nodo %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1975"/>
        <source>当前配置已部署</source>
        <translation type="unfinished">La configuración actual ha sido desplegada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4159"/>
        <source>在线节点系统启动成功，数据库类型切换完成</source>
        <translation type="unfinished">El sistema de nodo en línea se ha iniciado con éxito, y el cambio de tipo de BD se ha completado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="737"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="860"/>
        <source>网络地址</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Dirección de Red</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="90"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="100"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="300"/>
        <source>环境配置工具</source>
        <comment>toolName</comment>
        <translation type="unfinished">Herramienta de Configuración del Entorno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="568"/>
        <source>高级</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Avanzado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="559"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="574"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3392"/>
        <source>收起</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Colapsar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="738"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1226"/>
        <source>语言类型</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Tipo de Idioma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="739"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1340"/>
        <source>数据库类型</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Tipo de BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="740"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="760"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1565"/>
        <source>系统部署</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Despliegue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="742"/>
        <source>维护库切换</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Cambio de MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="896"/>
        <source>存在AB网未选，是否继续</source>
        <translation type="unfinished">La red AB no está seleccionada, ¿desea continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1222"/>
        <source>系统已重启，请退出工具</source>
        <translation type="unfinished">El sistema se ha reiniciado, por favor salga de la herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1326"/>
        <source>平台停止超时，请重试</source>
        <translation type="unfinished">Tiempo agotado parada plataforma, intentar de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1346"/>
        <source>未查询到历史库类型，请检查或刷新</source>
        <translation type="unfinished">No se encontró el tipo de BD de historial, por favor verifique o actualice</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1353"/>
        <source>此操作将会清空旧库数据并重启本现场节点，是否继续</source>
        <translation type="unfinished">Esta operación borrará los datos antiguos de la BD y reiniciará el nodo local. Desea continuar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1420"/>
        <source>切库失败，请确认部署历史库服务的节点在线</source>
        <translation type="unfinished">El cambio de base de datos falló. Por favor verifique si el nodo donde se despliega el servicio de BD de historial está en línea.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1434"/>
        <source>切库失败，存在未完全启动的节点，请稍候重试</source>
        <translation type="unfinished">El cambio de base de datos falló. Algunos nodos de despliegue aún no están completamente operativos. Por favor intente de nuevo más tarde.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1619"/>
        <source>节点会根据配置文件调整，新增或删除,是否继续</source>
        <translation type="unfinished">Los nodos serán ajustados, añadidos o eliminados de acuerdo con el archivo de configuración. Desea continuar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1635"/>
        <source>部署失败，存在未完全启动的节点，请稍候重试</source>
        <translation type="unfinished">El despliegue falló. Hay nodos que no han iniciado completamente. Por favor espere e intente de nuevo.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1707"/>
        <source>应用失败，当前部署的状态未通过检查</source>
        <translation type="unfinished">Aplicación fallida, estado despliegue actual no aprobado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1883"/>
        <source>系统部署完成</source>
        <translation type="unfinished">Despliegue del sistema completado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2019"/>
        <source>网络地址的修改未应用，</source>
        <translation type="unfinished">La modificación de la dirección de red no ha sido aplicada,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2021"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2035"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2048"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2061"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2074"/>
        <source>是否仍要退出</source>
        <translation type="unfinished">Desea salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2021"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2035"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2048"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2061"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2074"/>
        <source>退出</source>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2033"/>
        <source>语言类型的修改未应用，</source>
        <translation type="unfinished">La modificación del tipo de idioma no ha sido aplicada,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2046"/>
        <source>数据库类型的修改未应用，</source>
        <translation type="unfinished">La modificación del tipo de BD no se aplicó.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2059"/>
        <source>系统部署的修改未应用，</source>
        <translation type="unfinished">Las modificaciones al despliegue del sistema no se han aplicado,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2072"/>
        <source>维护库切换的修改未应用，</source>
        <translation type="unfinished">La modificación para el cambio de MTDB no ha sido aplicada.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2093"/>
        <source>IP地址</source>
        <translation type="unfinished">Dirección IP</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2094"/>
        <source>子网掩码</source>
        <translation type="unfinished">Máscara de subred</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="932"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2097"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2149"/>
        <source>网关</source>
        <translation type="unfinished">Puerta de enlace</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="380"/>
        <source>节点类型：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="383"/>
        <source>工作站</source>
        <translation type="unfinished">Estación de trabajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="383"/>
        <source>服务器</source>
        <translation type="unfinished">Servidor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="951"/>
        <source>网址重复：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="954"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="967"/>
        <source>网口 %1，行 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="964"/>
        <source>网段重复：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="976"/>
        <source>告警</source>
        <translation type="unfinished">Alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="976"/>
        <source>当前存在未填IP/掩码</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="986"/>
        <source>存在重复IP或网段</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="986"/>
        <source>确定</source>
        <translation type="unfinished">Determinar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1020"/>
        <source>节点不允许与现有节点名称重复</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1648"/>
        <source>现场节点必须大于等于模板中的节点数</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1829"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4096"/>
        <source>%1重启进程异常</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1830"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4097"/>
        <source>执行超时，请确认关闭工具</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2355"/>
        <source>读取历史记录失败</source>
        <translation type="unfinished">Falló la lectura de la historia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2785"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2959"/>
        <source>空</source>
        <translation type="unfinished">Nulo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2804"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2984"/>
        <source>不使用</source>
        <translation type="unfinished">No utilizado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3058"/>
        <source>获取本地节点失败</source>
        <translation type="unfinished">Fallo al obtener el nodo local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3095"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3145"/>
        <source>详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Detalles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3101"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3151"/>
        <source>应用详情展示</source>
        <translation type="unfinished">Visualización de detalles de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3111"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3162"/>
        <source>(维护应用)</source>
        <translation type="unfinished">(Aplicación de maint.)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3348"/>
        <source>正在获取数据......</source>
        <translation type="unfinished">Obteniendo datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3356"/>
        <source>刷新中......</source>
        <translation type="unfinished">Actualizando...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3364"/>
        <source>远程断开连接，请重新连接</source>
        <translation type="unfinished">Desconexión remota, por favor reconéctese</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3611"/>
        <source>节点名称获取失败</source>
        <translation type="unfinished">No se pudo recuperar el nombre del nodo </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3614"/>
        <source>AB网获取失败</source>
        <translation type="unfinished">Fallo en la adquisición de la red AB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3648"/>
        <source>节点名称修改记录</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Registro de modificación del nombre del nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3659"/>
        <source>原名称</source>
        <translation type="unfinished">Nombre original</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3659"/>
        <source>现名称</source>
        <translation type="unfinished">Nombre del sitio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3659"/>
        <source>平台确认</source>
        <translation type="unfinished">Validación de la plataforma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3659"/>
        <source>监控确认</source>
        <translation type="unfinished">Validación de monitoreo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3682"/>
        <source>网络信息修改记录</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Registro de modificación de información de red</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3688"/>
        <source>网口</source>
        <translation type="unfinished">Interfaz de red</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3688"/>
        <source>原网络信息</source>
        <translation type="unfinished">Info de red original</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3688"/>
        <source>现网络信息(重启生效)</source>
        <translation type="unfinished">Info de red actual (Efectiva después de reiniciar)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3728"/>
        <source>现场节点</source>
        <translation type="unfinished">Nodos en el sitio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3728"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3742"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3746"/>
        <source>模板节点</source>
        <translation type="unfinished">Nodo modelo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3742"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3742"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3746"/>
        <source>应用详情</source>
        <translation type="unfinished">Detalles de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3987"/>
        <source>节点-</source>
        <translation type="unfinished">Nodo-</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3996"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4002"/>
        <source>节点</source>
        <translation type="unfinished">nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4032"/>
        <source>---切换库%1操作失败，请人工介入！</source>
        <translation type="unfinished">---Falló la operación de cambio de BD %1, ¡por favor intervenga manualmente!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4038"/>
        <source>---切换库%1操作成功，等待重启</source>
        <translation type="unfinished">---Cambio de BD %1 operación exitosa, esperando reinicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4046"/>
        <source>所有节点系统重启</source>
        <translation type="unfinished">Reiniciar todos los sistemas de nodos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4047"/>
        <source>正在重启节点</source>
        <translation type="unfinished">Reiniciando nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4050"/>
        <source>数据库类型切换结束，即将重启所有节点系统</source>
        <translation type="unfinished">El cambio de tipo de BD ha terminado y todos los sistemas de nodos se reiniciarán pronto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4100"/>
        <source>状态异常</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4191"/>
        <source>切库操作中断，清理初始化库失败</source>
        <translation type="unfinished">El cambio de tipo de base de datos se interrumpió y la limpieza e inicialización de la base de datos falló</translation>
    </message>
</context>
<context>
    <name>ToolIPTableDelegate</name>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="57"/>
        <source> 字节</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
