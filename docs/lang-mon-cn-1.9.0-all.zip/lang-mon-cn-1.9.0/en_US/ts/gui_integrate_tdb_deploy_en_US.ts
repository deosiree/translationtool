<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>Destfile</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/destfile.cpp" line="52"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/destfile.cpp" line="56"/>
        <source>选择路径</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/destfile.cpp" line="53"/>
        <source>选择路径</source>
        <translation type="unfinished">Select path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/destfile.ui" line="112"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/destfile.ui" line="138"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/destfile.ui" line="212"/>
        <source>目标路径：</source>
        <translation type="unfinished">Dest path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/destfile.cpp" line="63"/>
        <source>选择旧库</source>
        <translation type="unfinished">Select old db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/destfile.h" line="72"/>
        <source>旧库文件选择</source>
        <translation type="unfinished">Old DB File Selection</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="115"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1230"/>
        <source> 参数配置：</source>
        <translation type="unfinished">Params Config:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="132"/>
        <source>保留动态元数据</source>
        <translation type="unfinished">Preserve dynamic metadata</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="196"/>
        <source>迁移方式：   </source>
        <translation type="unfinished">Migration mode:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="341"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="87"/>
        <source>旧库文件夹：</source>
        <translation type="unfinished">Old db folder:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="303"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="504"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="776"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="220"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="221"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="222"/>
        <source>选择文件</source>
        <translation type="unfinished">Select file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="571"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="88"/>
        <source>新库文件夹：</source>
        <translation type="unfinished">New db folder:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="741"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="89"/>
        <source>目标文件夹：</source>
        <translation type="unfinished">Dest folder:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="966"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1777"/>
        <source>配置信息：</source>
        <translation type="unfinished">Config info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1020"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="223"/>
        <source>生成配置</source>
        <translation type="unfinished">Gen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1129"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="2003"/>
        <source>消息日志：</source>
        <translation type="unfinished">Message log:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1148"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="224"/>
        <source>开始迁移</source>
        <translation type="unfinished">Migrate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1291"/>
        <source>节点：</source>
        <translation type="unfinished">Node:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1338"/>
        <source>应用名：</source>
        <translation type="unfinished">App name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1369"/>
        <source>库  名：</source>
        <translation type="unfinished">DB name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1405"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1662"/>
        <source>获取配置</source>
        <translation type="unfinished">Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1434"/>
        <source>下载</source>
        <translation type="unfinished">Download</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1463"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1663"/>
        <source>扩容迁移</source>
        <translation type="unfinished">Expand &amp; migrate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="331"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="574"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="828"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2086"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2107"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2626"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2720"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="74"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="681"/>
        <source>旧库文件夹不能为空</source>
        <translation type="unfinished">The old db folder cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="75"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="690"/>
        <source>新库文件夹不能为空</source>
        <translation type="unfinished">The new db db cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="76"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="698"/>
        <source>目标文件夹不能为空</source>
        <translation type="unfinished">The destination folder cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="83"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="84"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="85"/>
        <source>请输入内容</source>
        <translation type="unfinished">Please enter content</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="86"/>
        <source>迁移方式：</source>
        <translation type="unfinished">Migration mode:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="93"/>
        <source>应用名不能为空</source>
        <translation type="unfinished">The application name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="94"/>
        <source>库名不能为空</source>
        <translation type="unfinished">The db name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="99"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1833"/>
        <source>库大小：0(M)</source>
        <translation type="unfinished">DB size: 0(M)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="148"/>
        <source>创建空库</source>
        <translation type="unfinished">Create DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="149"/>
        <source>保留oid</source>
        <translation type="unfinished">Reserved Oid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="150"/>
        <source>初始化oid</source>
        <translation type="unfinished">Initialize Oid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="183"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1646"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1653"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="184"/>
        <source>库信息总览</source>
        <translation type="unfinished">DB Info Overview</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="185"/>
        <source>导入配置</source>
        <translation type="unfinished">Import Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="186"/>
        <source>导出配置</source>
        <translation type="unfinished">Export config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="195"/>
        <source>全部清除</source>
        <translation type="unfinished">Clear all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="552"/>
        <source>迁移成功，是否重启应用？</source>
        <translation type="unfinished">If the migration is successful, restart the application.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="626"/>
        <source>重启失败</source>
        <translation type="unfinished">Restart failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="633"/>
        <source>节点启动完成</source>
        <translation type="unfinished">Node startup completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="142"/>
        <source>迁移升级</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Upgrade</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="143"/>
        <source>迁移扩容</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Expansion</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="231"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="234"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="237"/>
        <source>选择文件</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="241"/>
        <source>生成配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Gen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="242"/>
        <source>开始迁移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Migrate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="330"/>
        <source>升级前，需停止除核心平台(系统管理、系统运维)外的应用系统</source>
        <translation type="unfinished">Before upgrading, all application systems except for the core platform (system management, system operation and maintenance) need to be stopped</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="342"/>
        <source>节点【{%1}】下所有普通应用取消停止</source>
        <translation type="unfinished">Cancel stop of all general applications under node [{%1}]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="468"/>
        <source>迁移结束</source>
        <translation type="unfinished">Migration completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="492"/>
        <source>迁移失败，是否重启应用？</source>
        <translation type="unfinished">Migration failed, whether to restart the application?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="781"/>
        <source>选择目标路径</source>
        <comment>toolName</comment>
        <translation type="unfinished">Select Dest Path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="828"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2107"/>
        <source>是否覆盖，重新生成</source>
        <translation type="unfinished">Whether to overwrite and regenerate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="900"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1133"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1212"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1542"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2176"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2516"/>
        <source>库大小：</source>
        <translation type="unfinished">DB size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="901"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1134"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1213"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1543"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2178"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2517"/>
        <source>(M)</source>
        <translation type="unfinished">(M)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="580"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="834"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1017"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1169"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1260"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1527"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2092"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2113"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2632"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2726"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="359"/>
        <source>停止中......请等待</source>
        <translation type="unfinished">Stopping... Please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="456"/>
        <source>升级中......请等待</source>
        <translation type="unfinished">Upgrading... Please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="581"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="835"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1026"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1031"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1037"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1173"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1264"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1531"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2093"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2114"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2633"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2727"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="604"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2657"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2754"/>
        <source>重启应用中......请等待</source>
        <translation type="unfinished">Restarting application... Please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1105"/>
        <source>获取配置文件</source>
        <translation type="unfinished">Get config file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1333"/>
        <source>表ID</source>
        <translation type="unfinished">Table ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1333"/>
        <source>表名</source>
        <translation type="unfinished">Table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1333"/>
        <source>数据大小[K]</source>
        <translation type="unfinished">Data size [K]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1668"/>
        <source>获取配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1670"/>
        <source>扩容迁移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Expand/migrate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1887"/>
        <source>实例号</source>
        <translation type="unfinished">Instance No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1887"/>
        <source>应用描述</source>
        <translation type="unfinished">App description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1887"/>
        <source>节点名</source>
        <translation type="unfinished">Node name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1887"/>
        <source>临时本地旧库路径</source>
        <translation type="unfinished">Temporary local old db	 path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1887"/>
        <source>临时本地新库路径</source>
        <translation type="unfinished">Temporary local new db path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1888"/>
        <source>旧维护库路径</source>
        <translation type="unfinished">Old MTDB path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1888"/>
        <source>新维护库路径</source>
        <translation type="unfinished">New MTDB path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2021"/>
        <source>下载中......请等待</source>
        <translation type="unfinished">Downloading... Please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2148"/>
        <source>加载中......请等待</source>
        <translation type="unfinished">Loading... Please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2603"/>
        <source>发布中......请等待</source>
        <translation type="unfinished">Publishing... Please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2048"/>
        <source>下载结束失败原因：</source>
        <translation type="unfinished">Reason for download failure:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2085"/>
        <source>扩容前，需停止除核心平台(系统管理、系统运维)外的应用系统</source>
        <translation type="unfinished">Before expansion, all application systems except for the core platform (system management, system operation and maintenance) need to be stopped</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2058"/>
        <source>数据库下载结束</source>
        <translation type="unfinished">DB download completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1573"/>
        <source>基础配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Basic Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1574"/>
        <source>循环表配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Config Loop Table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1575"/>
        <source>扩容库列表</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Expanded DB List</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2233"/>
        <source>循环父表名称</source>
        <translation type="unfinished">Loop parent table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2233"/>
        <source>循环父端关联字段</source>
        <translation type="unfinished">Loop parent linked field</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2233"/>
        <source>循环父表容量</source>
        <translation type="unfinished">Loop parent table capacity</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2233"/>
        <source>循环子对象个数</source>
        <translation type="unfinished">Loop sub-objects count</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2234"/>
        <source>循环子表名称</source>
        <translation type="unfinished">Loop subtable name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2234"/>
        <source>循环子表容量</source>
        <translation type="unfinished">Loop subtable capacity</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2234"/>
        <source>字段ID</source>
        <translation type="unfinished">Field ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2624"/>
        <source>扩容失败</source>
        <translation type="unfinished">Expansion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2626"/>
        <source>扩容失败，是否重启应用？</source>
        <translation type="unfinished">Expansion failed, whether to restart the application?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2720"/>
        <source>扩容完成，是否重启应用？</source>
        <translation type="unfinished">If the expansion is successful, restart the application.</translation>
    </message>
</context>
<context>
    <name>NewFile</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="95"/>
        <source>选择路径</source>
        <translation type="unfinished">Select path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="20"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="113"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="20"/>
        <source>旧库路径有误</source>
        <translation type="unfinished">The old db path is incorrect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="52"/>
        <source>新库文件选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">New DB Files Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="131"/>
        <source>选择新库</source>
        <comment>toolName</comment>
        <translation type="unfinished">Select New DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="93"/>
        <source>输入非负整数如:8</source>
        <translation type="unfinished">Enter a non-negative integer such as 8</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="98"/>
        <source>选择路径</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="113"/>
        <source>路径无效</source>
        <translation type="unfinished">Invalid path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.ui" line="69"/>
        <source>库版本号：</source>
        <translation type="unfinished">DB version No.:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.ui" line="133"/>
        <source>新库路径：</source>
        <translation type="unfinished">New DB path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.ui" line="287"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.ui" line="321"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>OldFile</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.ui" line="84"/>
        <source>文件路径：</source>
        <translation type="unfinished">File path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.ui" line="181"/>
        <source>库模式：</source>
        <translation type="unfinished">DB mode:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.ui" line="243"/>
        <source> 应用名：</source>
        <translation type="unfinished">App name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.ui" line="277"/>
        <source>态：</source>
        <translation type="unfinished">Mode:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.ui" line="314"/>
        <source>实例号：</source>
        <translation type="unfinished">Instance No.:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.ui" line="362"/>
        <source> 库名：</source>
        <translation type="unfinished">DB name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.ui" line="496"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.ui" line="528"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.cpp" line="42"/>
        <source>旧库文件选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">Old DB File Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.cpp" line="100"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.cpp" line="101"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.cpp" line="105"/>
        <source>0</source>
        <translation type="unfinished">0</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.cpp" line="109"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.cpp" line="113"/>
        <source>选择路径</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.cpp" line="110"/>
        <source>选择路径</source>
        <translation type="unfinished">Select path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.cpp" line="121"/>
        <source>选择旧库</source>
        <comment>toolName</comment>
        <translation type="unfinished">Select Old DB</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/infodbDlg.cpp" line="26"/>
        <source>库信息总览</source>
        <comment>toolName</comment>
        <translation type="unfinished">DB Info Overview</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/noticeDlg.cpp" line="83"/>
        <source>信息</source>
        <comment>toolName</comment>
        <translation type="unfinished">Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="46"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="64"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="293"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="378"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="414"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="476"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="542"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
</context>
<context>
    <name>Worker</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="124"/>
        <source>开始将库保存在临时目录下</source>
        <translation type="unfinished">Start saving the DB in a temporary dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="66"/>
        <source>正在停止节点%1涉及库%2的所有普通应用</source>
        <translation type="unfinished">Stopping all general applications of node %1 involving DB %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="73"/>
        <source>节点%1进程停止失败</source>
        <translation type="unfinished">Node %1 process failed to stop</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="79"/>
        <source>节点%1进程停止成功</source>
        <translation type="unfinished">Node %1 process stopped successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="111"/>
        <source>开始登录节点%1失败</source>
        <translation type="unfinished">Failed to start logging into node %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="119"/>
        <source>登录节点%1获取配置</source>
        <translation type="unfinished">Login node %1 to retrieve config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="129"/>
        <source>从节点%1远程下载运行库%2至本地%3失败，返回码=%4</source>
        <translation type="unfinished">From node %1, remote download of RTDB %2 to local %3 failed with return code= %4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="139"/>
        <source>从节点%1远程下载运行库%2至本地%3成功</source>
        <translation type="unfinished">From node %1 , download RTDB %2 remotely to local %3 successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="146"/>
        <source>临时文件保存结束，生成初始配置信息中</source>
        <translation type="unfinished">Temporary file saved, generating initial config info...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="158"/>
        <source>初始配置信息生成结束</source>
        <translation type="unfinished">Initial config info generation is completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="170"/>
        <source>节点%1正在启动</source>
        <translation type="unfinished">Node %1 is starting up</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="175"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="207"/>
        <source>节点%1启动失败</source>
        <translation type="unfinished">Node %1 failed to start</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="179"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="211"/>
        <source>节点%1应用启动成功</source>
        <translation type="unfinished">Node %1 application started successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="277"/>
        <source>登录节点%1失败，下载中止</source>
        <translation type="unfinished">Login node %1 failed, download aborted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="345"/>
        <source>从节点%1路径%2下载运行库%3至本地%4失败，返回码=%5</source>
        <translation type="unfinished">From node %1 path %2, failed to download RTDB %3 to local %4, return code = %5</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="360"/>
        <source>从节点%1路径%2下载运行库%3至本地%4成功</source>
        <translation type="unfinished">From node %1 path %2, download RTDB %3 to local %4 successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="383"/>
        <source>应用【%1.%2.%3】未部署维护节点</source>
        <translation type="unfinished">Application [%1.%2.%3] has not deployed maintenance nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="427"/>
        <source>ftp登录维护节点 %1失败，错误信息=%2</source>
        <translation type="unfinished">FTP login maintenance node %1 failed with error message = %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="436"/>
        <source>从维护节点%1路径%2下载维护库%3至本地%4失败，错误信息=%5</source>
        <translation type="unfinished">From maintenance node %1 path %2, failed to download MTDB %3 to local %4, error message =%5</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="453"/>
        <source>从维护节点%1路径%2下载维护库%3至本地%4成功</source>
        <translation type="unfinished">From maintenance node %1 path %2 ,download MTDB %3 to local %4 successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="552"/>
        <source>用户:%1运行库%2迁移扩容失败</source>
        <translation type="unfinished">User:%1 RTDB %2 migration and expansion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="560"/>
        <source>用户:%1 运行库%2迁移扩容成功</source>
        <translation type="unfinished">User:%1 RTDB %2 migration and expansion successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="603"/>
        <source>用户:%1 数据库%2从路径%3至%4迁移扩容失败</source>
        <translation type="unfinished">User:%1 DB %2 failed to migrate and expand from path %3 to %4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="613"/>
        <source>用户:%1 数据库%2从路径%3至%4迁移扩容成功</source>
        <translation type="unfinished">User:%1 DB %2 migrated and expanded from path %3 to %4 successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="667"/>
        <source>用户:%1路径%2上传%3迁移扩容失败</source>
        <translation type="unfinished">User: %1 Path %2 Upload %3 migration and expansion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="702"/>
        <source>用户:%1 路径%2上传%3扩容迁移完成</source>
        <translation type="unfinished">User:%1 Path %2 Upload %3 capacity expansion and migration completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="714"/>
        <source>登录节点%1上传成功</source>
        <translation type="unfinished">Login node %1 successfully uploaded</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="239"/>
        <source>请至少选择一个数据源</source>
        <translation type="unfinished">Please select at least one data source</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="261"/>
        <source>数据源节点不可为空</source>
        <translation type="unfinished">The data source node cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="419"/>
        <source>远程登录维护节点【{%1}】</source>
        <translation type="unfinished">Remote login maintenance node [{%1}]</translation>
    </message>
</context>
<context>
    <name>noticeDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/noticeDlg.cpp" line="58"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
</context>
<context>
    <name>noticeWid</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/noticeWid.cpp" line="11"/>
        <source>信息</source>
        <translation type="unfinished">Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/noticeWid.cpp" line="18"/>
        <source>迁移结束</source>
        <translation type="unfinished">Migration completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/noticeWid.cpp" line="32"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
</context>
</TS>
