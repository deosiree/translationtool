<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>DlgAlarmToGraph</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_alarm_to_graph.cpp" line="33"/>
        <source>告警推画面</source>
        <translation type="unfinished">Pantalla de alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_alarm_to_graph.cpp" line="71"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_alarm_to_graph.cpp" line="77"/>
        <source>画面名</source>
        <translation type="unfinished">Nombre de pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_alarm_to_graph.cpp" line="83"/>
        <source>厂站名</source>
        <translation type="unfinished">Nombre de planta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_alarm_to_graph.cpp" line="89"/>
        <source>告警次数</source>
        <translation type="unfinished">Núm. de alertas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_alarm_to_graph.cpp" line="95"/>
        <source>操作</source>
        <translation type="unfinished">Operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_alarm_to_graph.ui" line="41"/>
        <source>关闭</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cerrar</translation>
    </message>
</context>
<context>
    <name>DlgAppChange</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_app_change.cpp" line="32"/>
        <source>应用切换</source>
        <translation type="unfinished">Cambio de app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_app_change.ui" line="48"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_app_change.ui" line="55"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>DlgCycleSet</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_cycle_set.ui" line="28"/>
        <source>画面名：</source>
        <translation type="unfinished">Nombre del gráfico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_cycle_set.ui" line="59"/>
        <source>刷新周期：</source>
        <translation type="unfinished">Ciclo de actualización:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_cycle_set.ui" line="69"/>
        <source>秒</source>
        <translation type="unfinished">seg</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_cycle_set.ui" line="96"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_cycle_set.ui" line="103"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_cycle_set.cpp" line="31"/>
        <source>刷新周期设置</source>
        <translation type="unfinished">Config. de ciclo de actualización</translation>
    </message>
</context>
<context>
    <name>DlgEquipList</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_equip_list.ui" line="29"/>
        <source>开关</source>
        <translation type="unfinished">Interruptor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_equip_list.ui" line="34"/>
        <source>母线</source>
        <translation type="unfinished">Barra</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_equip_list.ui" line="39"/>
        <source>变压器</source>
        <translation type="unfinished">Transformador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_equip_list.cpp" line="29"/>
        <source>设备列表</source>
        <translation type="unfinished">Lista de dispositivos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_equip_list.cpp" line="51"/>
        <source>序号</source>
        <translation type="unfinished">Núm.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_equip_list.cpp" line="57"/>
        <source>设备名</source>
        <translation type="unfinished">Nombre de equipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_equip_list.cpp" line="63"/>
        <source>类型</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_equip_list.cpp" line="69"/>
        <source>操作</source>
        <translation type="unfinished">Operación</translation>
    </message>
</context>
<context>
    <name>DlgFavorites</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.cpp" line="44"/>
        <source>收藏夹</source>
        <translation type="unfinished">Favoritos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.cpp" line="82"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.cpp" line="88"/>
        <source>画面名</source>
        <translation type="unfinished">Nombre de pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.cpp" line="94"/>
        <source>操作</source>
        <translation type="unfinished">Operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.cpp" line="167"/>
        <source>添加失败</source>
        <translation type="unfinished">Fallo al agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.cpp" line="167"/>
        <source>该画面已添存在收藏夹列表中</source>
        <translation type="unfinished">Pantalla ya en lista de favoritos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.ui" line="47"/>
        <source>收藏当前画面</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Favoritos gráfica actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.ui" line="58"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.ui" line="89"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.ui" line="96"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>DlgPicShortCut</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.cpp" line="43"/>
        <source>快捷键设置</source>
        <translation type="unfinished">Config. de atajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.cpp" line="73"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.cpp" line="79"/>
        <source>快捷键</source>
        <translation type="unfinished">Atajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.cpp" line="85"/>
        <source>画面对象</source>
        <translation type="unfinished">Objeto pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.cpp" line="204"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.cpp" line="211"/>
        <source>保存失败</source>
        <translation type="unfinished">Fallo al guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.cpp" line="204"/>
        <source>画面对象不能为空！</source>
        <translation type="unfinished">¡Objeto pantalla no vacío!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.cpp" line="211"/>
        <source>快捷键不能为空！</source>
        <translation type="unfinished">¡Atajo no vacío!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.ui" line="41"/>
        <source>增加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.ui" line="52"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.ui" line="83"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.ui" line="90"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>DlgPrint</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.ui" line="28"/>
        <source>打印画面：</source>
        <translation type="unfinished">Imprimir gráfico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.ui" line="82"/>
        <source>画面颜色：</source>
        <translation type="unfinished">Color del gráfico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.ui" line="96"/>
        <source>黑白</source>
        <translation type="unfinished">Monocromático</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.ui" line="150"/>
        <source>打印</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.ui" line="157"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.ui" line="89"/>
        <source>原色</source>
        <translation type="unfinished">Color primario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.ui" line="103"/>
        <source>白底</source>
        <translation type="unfinished">Fondo blanco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.ui" line="110"/>
        <source>反色</source>
        <translation type="unfinished">Invertir color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.cpp" line="46"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.cpp" line="65"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.cpp" line="155"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.cpp" line="162"/>
        <source>打印</source>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.cpp" line="61"/>
        <source>区域打印</source>
        <translation type="unfinished">Impresión de área</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.cpp" line="155"/>
        <source>打印画面成功！</source>
        <translation type="unfinished">¡Pantalla impresa con éxito!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.cpp" line="162"/>
        <source>未找到可用打印设备！</source>
        <translation type="unfinished">¡No se encontró dispositivo de impresión!</translation>
    </message>
</context>
<context>
    <name>DlgRecentOpen</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_recent_open.cpp" line="37"/>
        <source>最近打开</source>
        <translation type="unfinished">Abierto recientemente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_recent_open.cpp" line="70"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_recent_open.cpp" line="76"/>
        <source>画面名</source>
        <translation type="unfinished">Nombre de pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_recent_open.cpp" line="82"/>
        <source>操作</source>
        <translation type="unfinished">Operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_recent_open.ui" line="47"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_recent_open.ui" line="81"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_recent_open.ui" line="88"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>DlgScreenExchange</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_screen_exchange.ui" line="14"/>
        <source>显示屏幕设置</source>
        <translation type="unfinished">Configuración de pantalla de visualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_screen_exchange.ui" line="22"/>
        <source>弹出画面显示屏幕选择：</source>
        <translation type="unfinished">Gráfica emergente para selección de visualización:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_screen_exchange.ui" line="50"/>
        <source>主屏幕</source>
        <translation type="unfinished">Pantalla principal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_screen_exchange.ui" line="57"/>
        <source>副屏幕</source>
        <translation type="unfinished">Pantalla secundaria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_screen_exchange.ui" line="82"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_screen_exchange.ui" line="89"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>DlgVoltageColor</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="29"/>
        <source>接地</source>
        <translation type="unfinished">Conexión a tierra</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="30"/>
        <source>带电</source>
        <translation type="unfinished">Energizado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="31"/>
        <source>无效</source>
        <translation type="unfinished">Inválido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="45"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="203"/>
        <source>电压等级设置</source>
        <translation type="unfinished">Config. de nivel de voltaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="64"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="89"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="70"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="95"/>
        <source>颜色</source>
        <translation type="unfinished">Color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="76"/>
        <source>电压等级</source>
        <translation type="unfinished">Nivel de voltaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="101"/>
        <source>拓扑类型</source>
        <translation type="unfinished">Tipo de topología</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="207"/>
        <source>拓扑着色设置</source>
        <translation type="unfinished">Config. de color de topología</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.ui" line="47"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.ui" line="54"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8316"/>
        <source>%1 没有此工具的打开权限</source>
        <translation type="unfinished">%1 sin permiso para abrir esta herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5166"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8219"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8247"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8317"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="467"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4368"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4818"/>
        <source>打开字典</source>
        <comment>menuName</comment>
        <translation type="unfinished">Abr dicc</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="468"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4369"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4819"/>
        <source>打开字典</source>
        <translation type="unfinished">Abrir diccionario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2269"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4388"/>
        <source>显示状态栏</source>
        <comment>menuName</comment>
        <translation type="unfinished">Mostr barra</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4389"/>
        <source>显示状态栏</source>
        <translation type="unfinished">Mostrar barra de estado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="568"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="577"/>
        <source>画面字典</source>
        <translation type="unfinished">Diccionario de gráficos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2062"/>
        <source>工具栏</source>
        <translation type="unfinished">Barra de herramientas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3236"/>
        <source>区域打印</source>
        <translation type="unfinished">Impresión de área</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3467"/>
        <source>区域放大</source>
        <translation type="unfinished">Ampliación de área</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4751"/>
        <source>画面全屏</source>
        <translation type="unfinished">Pantalla completa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3701"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4910"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4939"/>
        <source>停止刷新</source>
        <translation type="unfinished">Detener actualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2223"/>
        <source>重载画面</source>
        <translation type="unfinished">Recargar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4113"/>
        <source>启动拓扑</source>
        <translation type="unfinished">Topo de inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4310"/>
        <source>关闭声音</source>
        <translation type="unfinished">Silencio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4361"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4812"/>
        <source>关闭字典</source>
        <translation type="unfinished">Cerrar diccionario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="582"/>
        <source>画面</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Gráfica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="268"/>
        <source>图形监视工具(节点名:%1)</source>
        <comment>toolName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="612"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="612"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="763"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="781"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2681"/>
        <source>调试信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="794"/>
        <source>关闭</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1892"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1927"/>
        <source>文件</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1896"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1944"/>
        <source>视图</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Ver</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1900"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1974"/>
        <source>操作</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1904"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1994"/>
        <source>设置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Configuraciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1908"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2005"/>
        <source>应用</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1912"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2014"/>
        <source>窗口</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Ventana</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1951"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2088"/>
        <source>缩放</source>
        <comment>subTitle</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2085"/>
        <source>缩放</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2139"/>
        <source>应用扩展工具栏</source>
        <translation type="unfinished">Barra de herramientas de extensión de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2177"/>
        <source>最近打开</source>
        <comment>menuName</comment>
        <translation type="unfinished">Reciente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2181"/>
        <source>管理收藏</source>
        <comment>menuName</comment>
        <translation type="unfinished">Favoritos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2182"/>
        <source>打印画面</source>
        <comment>menuName</comment>
        <translation type="unfinished">Imp graf</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2184"/>
        <source>区域打印</source>
        <comment>menuName</comment>
        <translation type="unfinished">Imp area</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2188"/>
        <source>导出SVG</source>
        <comment>menuName</comment>
        <translation type="unfinished">Exp SVG</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2190"/>
        <source>导出图片</source>
        <comment>menuName</comment>
        <translation type="unfinished">Exp imagen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2192"/>
        <source>关闭窗口</source>
        <comment>menuName</comment>
        <translation type="unfinished">Cerr vent</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2196"/>
        <source>画面放大</source>
        <comment>menuName</comment>
        <translation type="unfinished">Acercar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2197"/>
        <source>画面缩小</source>
        <comment>menuName</comment>
        <translation type="unfinished">Alejar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2200"/>
        <source>比例缩放</source>
        <comment>menuName</comment>
        <translation type="unfinished">Escala</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2202"/>
        <source>区域放大</source>
        <comment>menuName</comment>
        <translation type="unfinished">Amp area</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2204"/>
        <source>重置缩放</source>
        <comment>menuName</comment>
        <translation type="unfinished">Restablecer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2206"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4750"/>
        <source>画面全屏</source>
        <comment>menuName</comment>
        <translation type="unfinished">Graf comp</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2207"/>
        <source>画面满屏</source>
        <comment>menuName</comment>
        <translation type="unfinished">Aj graf</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2210"/>
        <source>编辑画面</source>
        <comment>menuName</comment>
        <translation type="unfinished">Edit graf</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2212"/>
        <source>设备查找</source>
        <comment>menuName</comment>
        <translation type="unfinished">Dispositivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2214"/>
        <source>间隔查找</source>
        <comment>menuName</comment>
        <translation type="unfinished">Busc interv</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2216"/>
        <source>文本查找</source>
        <comment>menuName</comment>
        <translation type="unfinished">Texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2218"/>
        <source>告警推画面</source>
        <comment>menuName</comment>
        <translation type="unfinished">Notif alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2220"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3700"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4909"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4938"/>
        <source>停止刷新</source>
        <comment>menuName</comment>
        <translation type="unfinished">Det act</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2222"/>
        <source>手动刷新</source>
        <comment>menuName</comment>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2225"/>
        <source>重载所有</source>
        <comment>menuName</comment>
        <translation type="unfinished">Rec todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2227"/>
        <source>设备列表</source>
        <comment>menuName</comment>
        <translation type="unfinished">List disp</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2231"/>
        <source>电压等级</source>
        <comment>menuName</comment>
        <translation type="unfinished">Niv voltaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2233"/>
        <source>拓扑颜色</source>
        <comment>menuName</comment>
        <translation type="unfinished">Col topo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2234"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4112"/>
        <source>启动拓扑</source>
        <comment>menuName</comment>
        <translation type="unfinished">Ini topol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2244"/>
        <source>启动画面</source>
        <comment>menuName</comment>
        <translation type="unfinished">Graf inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2246"/>
        <source>快捷设置</source>
        <comment>menuName</comment>
        <translation type="unfinished">Conf rápid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2248"/>
        <source>刷新周期</source>
        <comment>menuName</comment>
        <translation type="unfinished">Ciclo act</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2249"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4309"/>
        <source>关闭声音</source>
        <comment>menuName</comment>
        <translation type="unfinished">Silenciar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2250"/>
        <source>保持电压等级颜色</source>
        <comment>menuName</comment>
        <translation type="unfinished">Mant col tens</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2259"/>
        <source>应用切换</source>
        <comment>menuName</comment>
        <translation type="unfinished">Camb app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2260"/>
        <source>应用扩展</source>
        <comment>menuName</comment>
        <translation type="unfinished">Ext app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2261"/>
        <source>顺控操作</source>
        <comment>menuName</comment>
        <translation type="unfinished">Secuencial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2267"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4360"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4811"/>
        <source>关闭字典</source>
        <comment>menuName</comment>
        <translation type="unfinished">Cerr dicc</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2271"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4424"/>
        <source>调试模式</source>
        <comment>menuName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2274"/>
        <source>层叠窗口</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2276"/>
        <source>平铺窗口</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2305"/>
        <source>添加收藏</source>
        <translation type="unfinished">Añadir a favoritos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2349"/>
        <source>上一页</source>
        <comment>menuName</comment>
        <translation type="unfinished">Anterior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2350"/>
        <source>上一页</source>
        <translation type="unfinished">Anterior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2355"/>
        <source>下一页</source>
        <comment>menuName</comment>
        <translation type="unfinished">Siguiente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2356"/>
        <source>下一页</source>
        <translation type="unfinished">Siguiente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2368"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4691"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4770"/>
        <source>隐藏菜单栏</source>
        <comment>menuName</comment>
        <translation type="unfinished">Ocultar menú</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2369"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4692"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4771"/>
        <source>隐藏菜单栏</source>
        <translation type="unfinished">Ocultar menú</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2374"/>
        <source>当前时间：</source>
        <translation type="unfinished">Hora actual:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2380"/>
        <source>坐标：</source>
        <translation type="unfinished">Coordenadas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2663"/>
        <source>决策查询</source>
        <translation type="unfinished">Consulta de decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2672"/>
        <source>清空标识</source>
        <translation type="unfinished">Borrar identificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8538"/>
        <source>已修改，是否更新？</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8542"/>
        <source>操作确认</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2690"/>
        <source>画面信息查询</source>
        <translation type="unfinished">Consulta de info. de pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3047"/>
        <source>关于 %1</source>
        <translation type="unfinished">Acerca de %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3049"/>
        <source>版本  %2</source>
        <translation type="unfinished">Versión %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3126"/>
        <source>添加失败</source>
        <translation type="unfinished">Fallo al agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3126"/>
        <source>该画面已添存在收藏夹列表中</source>
        <translation type="unfinished">Pantalla añadida a lista de favoritos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3138"/>
        <source>添加成功</source>
        <translation type="unfinished">Añadido con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3138"/>
        <source>画面已添加至收藏夹中</source>
        <translation type="unfinished">Pantalla añadida a favoritos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3218"/>
        <source>打印</source>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3218"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3236"/>
        <source>暂无需要打印的画面</source>
        <translation type="unfinished">No hay pantallas para imprimir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3335"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3346"/>
        <source>保存SVG文件</source>
        <translation type="unfinished">Guardar archivos SVG</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3346"/>
        <source>保存SVG文件:%1 成功!</source>
        <translation type="unfinished">¡Guardado SVG:%1 con éxito!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3375"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3390"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3398"/>
        <source>保存图片</source>
        <translation type="unfinished">Guardar imagen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3391"/>
        <source>保存图片:%1 失败!%2 错误信息:%3</source>
        <translation type="unfinished">¡Guardado imagen:%1 falló! Error:%2, info:%3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3398"/>
        <source>保存图片:%1 成功!</source>
        <translation type="unfinished">¡Imagen guardada:%1 con éxito!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3467"/>
        <source>暂无需要区域放大的画面</source>
        <translation type="unfinished">No hay pantalla para ampliar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3623"/>
        <source>设备查找</source>
        <comment>toolName</comment>
        <translation type="unfinished">Dispositivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3641"/>
        <source>间隔查找</source>
        <comment>toolName</comment>
        <translation type="unfinished">Búsqueda por Intervalo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3660"/>
        <source>文本查找</source>
        <comment>toolName</comment>
        <translation type="unfinished">Texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3689"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4915"/>
        <source>恢复刷新</source>
        <comment>menuName</comment>
        <translation type="unfinished">Act recup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3690"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4916"/>
        <source>恢复刷新</source>
        <translation type="unfinished">Recuperación de actualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3861"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4019"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5631"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5752"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5857"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5984"/>
        <source>图形监视工具(节点名:%1)[画面名：%2]</source>
        <comment>toolName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4102"/>
        <source>关闭拓扑</source>
        <comment>menuName</comment>
        <translation type="unfinished">Cerr topo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4103"/>
        <source>关闭拓扑</source>
        <translation type="unfinished">Cerrar topo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4295"/>
        <source>刷新周期设置</source>
        <translation type="unfinished">Ajustes de ciclo de actualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4295"/>
        <source>暂无需要设置周期的画面</source>
        <translation type="unfinished">No hay pantallas con ciclo por configurar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4304"/>
        <source>开启声音</source>
        <comment>menuName</comment>
        <translation type="unfinished">Act sonido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4305"/>
        <source>开启声音</source>
        <translation type="unfinished">Desmutear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4322"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4323"/>
        <source>取消保持电压颜色</source>
        <translation type="unfinished">Cancelar color de voltaje retenido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4329"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4330"/>
        <source>保持电压颜色</source>
        <translation type="unfinished">Mantener color de voltaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4380"/>
        <source>隐藏状态栏</source>
        <comment>menuName</comment>
        <translation type="unfinished">Ocult barra</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4381"/>
        <source>隐藏状态栏</source>
        <translation type="unfinished">Ocultar barra de estado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4401"/>
        <source>关闭调试模式</source>
        <comment>menuName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4402"/>
        <source>关闭调试模式</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4425"/>
        <source>调试模式</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4528"/>
        <source>鼠标左键单击需要查看调试信息的元素</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4699"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4778"/>
        <source>显示菜单栏</source>
        <comment>menuName</comment>
        <translation type="unfinished">Mostrar menú</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4700"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4779"/>
        <source>显示菜单栏</source>
        <translation type="unfinished">Mostrar menú</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4712"/>
        <source>取消全屏</source>
        <comment>menuName</comment>
        <translation type="unfinished">Canc pant</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4713"/>
        <source>取消全屏</source>
        <translation type="unfinished">Cancelar pantalla completa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5166"/>
        <source>是否关闭图形监视工具?</source>
        <translation type="unfinished">¿Desea cerrar la herramienta de monitoreo gráfico?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5167"/>
        <source>是</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5168"/>
        <source>否</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7001"/>
        <source>请先关闭之前打开的窗口</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8247"/>
        <source>无操作权限</source>
        <translation type="unfinished">Sin Permiso Operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5548"/>
        <source>(草稿版本)</source>
        <translation type="unfinished">(Versión borrador)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2193"/>
        <source>退出</source>
        <comment>menuName</comment>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5549"/>
        <source>(草稿版本)*</source>
        <translation type="unfinished">(Versión borrador)*</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5556"/>
        <source>(最新版本)</source>
        <translation type="unfinished">(Última versión)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5557"/>
        <source>(最新版本)*</source>
        <translation type="unfinished">(Versión más reciente)*</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6827"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6834"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6840"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7000"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6827"/>
        <source>可执行程序路径不能为空!</source>
        <translation type="unfinished">¡Ruta de programa ejecutable no puede estar vacía!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6834"/>
        <source>可执行程序不存在!</source>
        <translation type="unfinished">¡Programa ejecutable no existe!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6840"/>
        <source>所选文件没有执行权限!</source>
        <translation type="unfinished">¡Archivo seleccionado sin permiso de ejecución!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6857"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6861"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6893"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6919"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6857"/>
        <source>程序异常退出!</source>
        <translation type="unfinished">¡Programa terminó anormalmente!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6861"/>
        <source>程序退出码: %1</source>
        <translation type="unfinished">Código de salida de programa:%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6875"/>
        <source>程序启动失败</source>
        <translation type="unfinished">Inicio de programa falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6878"/>
        <source>程序崩溃</source>
        <translation type="unfinished">Colapso de programa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6881"/>
        <source>操作超时</source>
        <translation type="unfinished">Tiempo de operación agotado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6884"/>
        <source>写入错误</source>
        <translation type="unfinished">Error de escritura</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6887"/>
        <source>读取错误</source>
        <translation type="unfinished">Error de lectura</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6890"/>
        <source>未知错误</source>
        <translation type="unfinished">Error desconocido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6919"/>
        <source>启动程序异常: %1</source>
        <translation type="unfinished">Inicio de programa anormal:%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7280"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7446"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7470"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7633"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7672"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7847"/>
        <source>查找失败</source>
        <translation type="unfinished">Búsqueda fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7280"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7470"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7672"/>
        <source>查询条件不能为空</source>
        <translation type="unfinished">Condición de consulta no puede estar vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7446"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7633"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7847"/>
        <source>未找到符合条件的图形对象</source>
        <translation type="unfinished">No se encontraron objetos gráficos válidos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7947"/>
        <source>打开失败</source>
        <translation type="unfinished">Apertura falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7947"/>
        <source>未找到相关画面：%1</source>
        <translation type="unfinished">Pantalla relacionada no encontrada:%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8176"/>
        <source> 登录时限:</source>
        <translation type="unfinished">Límite de tiempo de login:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8218"/>
        <source>%1 没有此工具的打开权限! </source>
        <translation type="unfinished">%1 sin permiso para abrir esta herramienta!</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/main.cpp" line="283"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/main.cpp" line="679"/>
        <source>%1 没有此工具的打开权限</source>
        <comment>gui_graphviewer::main</comment>
        <translation type="unfinished">%1 sin permiso para abrir esta herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/main.cpp" line="284"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/main.cpp" line="323"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/main.cpp" line="680"/>
        <source>提示</source>
        <comment>gui_graphviewer::main</comment>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/main.cpp" line="324"/>
        <source>注册失败</source>
        <comment>gui_graphviewer::main</comment>
        <translation type="unfinished">Fallo al registrar</translation>
    </message>
</context>
</TS>
