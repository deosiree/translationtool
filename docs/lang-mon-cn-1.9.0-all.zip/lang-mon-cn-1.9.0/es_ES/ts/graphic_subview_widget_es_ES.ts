<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>GraphicSubviewWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_subview_widget/graphic_subview_widget.cpp" line="1317"/>
        <source>决策查询</source>
        <translation type="unfinished">Consulta de decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_subview_widget/graphic_subview_widget.cpp" line="1327"/>
        <source>清空标识</source>
        <translation type="unfinished">Limpiar ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_subview_widget/graphic_subview_widget.cpp" line="1336"/>
        <source>对象信息查询</source>
        <translation type="unfinished">Consulta de información del objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_subview_widget/graphic_subview_widget.cpp" line="1345"/>
        <source>画面信息查询</source>
        <translation type="unfinished">Consulta de información del gráfico</translation>
    </message>
</context>
</TS>
