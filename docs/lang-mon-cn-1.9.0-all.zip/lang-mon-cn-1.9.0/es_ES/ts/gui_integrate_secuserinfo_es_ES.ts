<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CUserInfoWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="30"/>
        <source>个人信息配置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Info personal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="61"/>
        <source>邮箱：        </source>
        <translation type="unfinished">Correo electrónico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="71"/>
        <source>密码到期时间：</source>
        <translation type="unfinished">Tiempo de expiración de la contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="78"/>
        <source>新密码：      </source>
        <translation type="unfinished">Nueva contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="88"/>
        <source>确认新密码：  </source>
        <translation type="unfinished">Confirmar nueva contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="98"/>
        <source>电话：        </source>
        <translation type="unfinished">Teléfono:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="105"/>
        <source>密码修改时间：</source>
        <translation type="unfinished">Tiempo de cambio de contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="118"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="144"/>
        <source>修改密码</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cambiar contraseña</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="154"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="134"/>
        <source>密码：        </source>
        <translation type="unfinished">Contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="79"/>
        <source>修改密码</source>
        <translation type="unfinished">Cambiar contraseña</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="161"/>
        <source>用户名称：    </source>
        <translation type="unfinished">Usuario:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="168"/>
        <source>角色：        </source>
        <translation type="unfinished">Caracteres:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="63"/>
        <source>操作员</source>
        <translation type="unfinished">Operador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="155"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="161"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="166"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="175"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="193"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="218"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="229"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="240"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="258"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="298"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="307"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="315"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="337"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="371"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="392"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="406"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="458"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="155"/>
        <source>原密码错误</source>
        <translation type="unfinished">Error en la contraseña antigua</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="161"/>
        <source>两次输入密码不一致</source>
        <translation type="unfinished">Las contraseñas que ingresó no coinciden</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="166"/>
        <source>新旧密码相同</source>
        <translation type="unfinished">Contraseña nueva y antigua iguales</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="193"/>
        <source>密码已使用</source>
        <translation type="unfinished">Contraseña ya usada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="218"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="229"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="240"/>
        <source>密码修改失败</source>
        <translation type="unfinished">Fallo al modificar contraseña</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="258"/>
        <source>输入包含非法字符，请检查</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="271"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="278"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="336"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="354"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="370"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="388"/>
        <source>用户信息配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="298"/>
        <source>修改密码成功</source>
        <translation type="unfinished">Contraseña cambiada con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="307"/>
        <source>请检查电话是否设置正确</source>
        <translation type="unfinished">Por favor verifique si el teléfono está configurado correctamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="315"/>
        <source>请检查邮箱是否设置正确</source>
        <translation type="unfinished">Por favor verifique si el correo está configurado correctamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="337"/>
        <source>修改失败</source>
        <translation type="unfinished">Fallo al modificar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="371"/>
        <source>用户信息修改失败</source>
        <translation type="unfinished">Fallo al modificar info. de usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="392"/>
        <source>修改成功</source>
        <translation type="unfinished">Modificación exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="406"/>
        <source>刷新失败</source>
        <translation type="unfinished">Actualización fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="458"/>
        <source>刷新成功</source>
        <translation type="unfinished">Actualización exitosa</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/pluginsecuserinfo.cpp" line="45"/>
        <source>个人信息</source>
        <translation type="unfinished">Info personal</translation>
    </message>
</context>
</TS>
