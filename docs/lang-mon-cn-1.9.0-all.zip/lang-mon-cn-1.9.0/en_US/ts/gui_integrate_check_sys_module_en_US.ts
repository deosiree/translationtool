<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.ui" line="26"/>
        <source>查验</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.ui" line="33"/>
        <source>节点：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.ui" line="40"/>
        <source>时间段：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.ui" line="66"/>
        <source>检测点：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.ui" line="81"/>
        <source>--&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.ui" line="93"/>
        <source>模块：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.ui" line="108"/>
        <source>进度</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.ui" line="122"/>
        <source>停止</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="124"/>
        <source>序号</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="124"/>
        <source>告警时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="124"/>
        <source>告警等级</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="124"/>
        <source>发送方</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="124"/>
        <source>告警项</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="125"/>
        <source>告警项描述</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="125"/>
        <source>告警对象oid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="125"/>
        <source>告警对象</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="125"/>
        <source>告警内容</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="176"/>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="189"/>
        <source>全部</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="177"/>
        <source>日志</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="178"/>
        <source>告警</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="199"/>
        <source>自定义</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="200"/>
        <source>过去一小时</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="201"/>
        <source>过去一天</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="202"/>
        <source>过去一个月</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="206"/>
        <source>网络</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="207"/>
        <source>数据库</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="210"/>
        <source>当前状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="211"/>
        <source>历史状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="315"/>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="322"/>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="329"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="315"/>
        <source>请选择节点</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="322"/>
        <source>请选择模块</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/mainwindow.cpp" line="329"/>
        <source>请选择检测点</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/plugin_net_check.cpp" line="49"/>
        <source>安全信息检查</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RealStatus</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/real_status.ui" line="14"/>
        <source>RealStatus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/real_status.cpp" line="182"/>
        <source>应用名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/real_status.cpp" line="182"/>
        <source>进程名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/real_status.cpp" line="182"/>
        <source>状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sys_module/real_status.cpp" line="182"/>
        <source>操作</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
