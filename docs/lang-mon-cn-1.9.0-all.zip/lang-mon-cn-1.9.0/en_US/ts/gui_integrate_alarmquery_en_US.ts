<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AlarmInfoTableModel</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="243"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="258"/>
        <source>告警项描述</source>
        <translation type="unfinished">Alarm item description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="264"/>
        <source>告警等级</source>
        <translation type="unfinished">Alarm level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="270"/>
        <source>操作</source>
        <translation type="unfinished">Operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="190"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="319"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="326"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="338"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="346"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="358"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="389"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="396"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="408"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="500"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="190"/>
        <source>历史库链接失败!</source>
        <translation type="unfinished">HDB link failed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="319"/>
        <source>获取告警表信息失败</source>
        <translation type="unfinished">Failed to retrieve alarm table info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="326"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="346"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="396"/>
        <source>获取告警表字段信息失败</source>
        <translation type="unfinished">Failed to retrieve alarm table field info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="338"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="389"/>
        <source>查询历史表信息失败</source>
        <translation type="unfinished">Failed to query historical table info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="358"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="408"/>
        <source>获取历史告警总数失败</source>
        <translation type="unfinished">Failed to retrieve the total number of history alarms</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_model.cpp" line="500"/>
        <source>%1调用查询失败</source>
        <translation type="unfinished">%1 query failed</translation>
    </message>
</context>
<context>
    <name>AlarmInfoTableView</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="27"/>
        <source>详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="69"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="73"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="83"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="86"/>
        <source>查询告警</source>
        <translation type="unfinished">Alarm query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="69"/>
        <source>查询完成</source>
        <translation type="unfinished">Query completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="73"/>
        <source>查询为空</source>
        <translation type="unfinished">Query is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="83"/>
        <source>未注册网络</source>
        <translation type="unfinished">Unregistered net</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_info_table_view.cpp" line="86"/>
        <source>查询失败</source>
        <translation type="unfinished">Query failed</translation>
    </message>
</context>
<context>
    <name>AlarmQueryCriteria</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="63"/>
        <source>本地</source>
        <translation type="unfinished">Local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="64"/>
        <source>历史</source>
        <translation type="unfinished">History</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="71"/>
        <source>按编辑条件，查询平台告警</source>
        <translation type="unfinished">Query platform alarms according to editing conditions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="117"/>
        <source>重置查询条件，默认查询最近一个小时</source>
        <translation type="unfinished">Reset the query conditions and query the last hour by default</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="122"/>
        <source>打开告警配置工具</source>
        <translation type="unfinished">Open alarm config tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="134"/>
        <source>编辑查询条件</source>
        <translation type="unfinished">Edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="139"/>
        <source>当前节点的本地缓存,删除后不可恢复</source>
        <translation type="unfinished">The local cache of the current node, which cannot be recovered after deletion</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="284"/>
        <source>是否确认重置告警查询条件</source>
        <translation type="unfinished">Confirm whether to reset alarm query conditions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="481"/>
        <source>是否查询</source>
        <translation type="unfinished">Whether to query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="283"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="481"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="69"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="114"/>
        <source>重置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Reset</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="129"/>
        <source>编辑条件</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Edit conditions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="357"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="393"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="357"/>
        <source>已启动,打开失败</source>
        <translation type="unfinished">Started; open failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="393"/>
        <source>打开失败</source>
        <translation type="unfinished">Open failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="400"/>
        <source>询问</source>
        <translation type="unfinished">Ask</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="400"/>
        <source>是否确定删除当前节点本地缓存</source>
        <translation type="unfinished">Are you sure to delete the local cache of the current node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="423"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="423"/>
        <source>清空缓存失败</source>
        <translation type="unfinished">Failed to clear cache</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="428"/>
        <source>清空缓存</source>
        <translation type="unfinished">Clear cache </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="428"/>
        <source>清空缓存成功</source>
        <translation type="unfinished">Cache cleared successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="501"/>
        <source>查询历史告警</source>
        <translation type="unfinished">Query history alarms</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="512"/>
        <source>去这该节点查告警</source>
        <translation type="unfinished">Go to this node to check the alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="542"/>
        <source>告警级别：</source>
        <translation type="unfinished">Alarm level:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="548"/>
        <source>时间范围：</source>
        <translation type="unfinished">Time range:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="559"/>
        <source>告警项：</source>
        <translation type="unfinished">Alarm items:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="566"/>
        <source>告警项描述：</source>
        <translation type="unfinished">Alarm item description:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="573"/>
        <source>发送方：</source>
        <translation type="unfinished">Sender:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="580"/>
        <source>告警对象：</source>
        <translation type="unfinished">Alarm object:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="587"/>
        <source>告警内容：</source>
        <translation type="unfinished">Alarm content:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/alarm_query_criteria.cpp" line="594"/>
        <source>告警对象</source>
        <translation type="unfinished">Alarm object</translation>
    </message>
</context>
<context>
    <name>DlgAlarmItemInfo</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="26"/>
        <source>告警项详情</source>
        <comment>toolName</comment>
        <translation type="unfinished">Alarm Item Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="51"/>
        <source>告警项名称：</source>
        <translation type="unfinished">Alarm item name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="52"/>
        <source>告警项描述：</source>
        <translation type="unfinished">Alarm item description:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="53"/>
        <source>推送画面：</source>
        <translation type="unfinished">Push graph:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="53"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="54"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="55"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="56"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="57"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="53"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="54"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="55"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="56"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="57"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="54"/>
        <source>语音播放：</source>
        <translation type="unfinished">Voice playback:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="55"/>
        <source>音响播放：</source>
        <translation type="unfinished">Audio playback:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="56"/>
        <source>发送短信：</source>
        <translation type="unfinished">Send message:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="57"/>
        <source>发送邮件：</source>
        <translation type="unfinished">Send email:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="79"/>
        <source>告警项：</source>
        <translation type="unfinished">Alarm items:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="80"/>
        <source>发送方：</source>
        <translation type="unfinished">Sender:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="85"/>
        <source>告警时间：</source>
        <translation type="unfinished">Alarm time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="88"/>
        <source>告警对象oid：</source>
        <translation type="unfinished">Alarm object Oid:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="91"/>
        <source>告警对象：</source>
        <translation type="unfinished">Alarm object:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_alarm_item_info.cpp" line="94"/>
        <source>告警内容：</source>
        <translation type="unfinished">Alarm content:</translation>
    </message>
</context>
<context>
    <name>DlgEditCondition</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="95"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="95"/>
        <source>oid不符合规范，无法作为查询条件</source>
        <translation type="unfinished">oid is invalid and cannot be used as a query condition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="211"/>
        <source>平台告警过滤条件选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">Select Alarm Filters</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="277"/>
        <source>请输入告警等级以应用筛选</source>
        <translation type="unfinished">Please enter alarm level to apply filtering</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="278"/>
        <source>请输入告警项描述以应用筛选</source>
        <translation type="unfinished">Please enter the alarm item description to apply the filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="279"/>
        <source>请输入告警项以应用筛选</source>
        <translation type="unfinished">Please enter the alarm item to apply the filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="281"/>
        <source>请输入对象oid</source>
        <translation type="unfinished">Please enter the object oid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="282"/>
        <source>请输入对象描述</source>
        <translation type="unfinished">Please enter an object description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="283"/>
        <source>请输入发送方</source>
        <translation type="unfinished">Please enter the sender</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="284"/>
        <source>请输入告警内容</source>
        <translation type="unfinished">Please enter the alarm content</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="384"/>
        <source>时间范围</source>
        <translation type="unfinished">Time range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="491"/>
        <source>时间范围：</source>
        <translation type="unfinished">Time range:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="527"/>
        <source>告警等级：</source>
        <translation type="unfinished">Alarm level:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="543"/>
        <source>告警项：</source>
        <translation type="unfinished">Alarm items:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="564"/>
        <source>告警项描述：</source>
        <translation type="unfinished">Alarm item description:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="579"/>
        <source>发送方：</source>
        <translation type="unfinished">Sender:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="594"/>
        <source>告警对象：</source>
        <translation type="unfinished">Alarm object:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="609"/>
        <source>告警内容：</source>
        <translation type="unfinished">Alarm content:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="478"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="478"/>
        <source>开始时间不能晚于结束时间</source>
        <translation type="unfinished">The start time cannot be later than the end time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.cpp" line="624"/>
        <source>告警对象</source>
        <translation type="unfinished">Alarm object</translation>
    </message>
</context>
<context>
    <name>PaginationWidget</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="25"/>
        <source>首页</source>
        <comment>buttonName</comment>
        <translation type="unfinished">First</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="26"/>
        <source>上一页</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Previous</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="27"/>
        <source>下一页</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Next</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="28"/>
        <source>尾页</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Last</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="77"/>
        <source>共有%1数据</source>
        <translation type="unfinished">Total %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="85"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="92"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="105"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="113"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="124"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="143"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="158"/>
        <source>/ %1</source>
        <translation type="unfinished">/ %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="130"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="148"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="163"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="130"/>
        <source>页数不合法</source>
        <translation type="unfinished">Invalid number of pages</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="148"/>
        <source>已经是第一页</source>
        <translation type="unfinished">Already the first page</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/widget/pagination_widge.cpp" line="163"/>
        <source>已经是最后一页</source>
        <translation type="unfinished">Already the last page</translation>
    </message>
</context>
<context>
    <name>dlg_edit_condition</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="23"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="44"/>
        <source>可选字段：</source>
        <translation type="unfinished">Optional fields:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="52"/>
        <source>告警时间</source>
        <translation type="unfinished">Alarm time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="57"/>
        <source>告警等级</source>
        <translation type="unfinished">Alarm level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="62"/>
        <source>发送方</source>
        <translation type="unfinished">Sender</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="67"/>
        <source>告警项</source>
        <translation type="unfinished">Alarm items</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="72"/>
        <source>告警项描述</source>
        <translation type="unfinished">Alarm item description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="77"/>
        <source>告警对象oid</source>
        <translation type="unfinished">Alarm object Oid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="82"/>
        <source>告警对象</source>
        <translation type="unfinished">Alarm object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="87"/>
        <source>告警内容</source>
        <translation type="unfinished">Alarm content</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="101"/>
        <source>可选值：</source>
        <translation type="unfinished">Optional values:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="119"/>
        <source>一小时</source>
        <translation type="unfinished">One hour</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="126"/>
        <source>三小时</source>
        <translation type="unfinished">Three hours</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="133"/>
        <source>八小时</source>
        <translation type="unfinished">Eight hours</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="144"/>
        <source>一天</source>
        <translation type="unfinished">One day</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="151"/>
        <source>三天</source>
        <translation type="unfinished">Three days</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="158"/>
        <source>一周</source>
        <translation type="unfinished">One week</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="169"/>
        <source>一月</source>
        <translation type="unfinished">One month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="176"/>
        <source>一年</source>
        <translation type="unfinished">One year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="183"/>
        <source>任意时间</source>
        <translation type="unfinished">Any time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="207"/>
        <source>开始时间</source>
        <translation type="unfinished">Start time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="217"/>
        <source>结束时间</source>
        <translation type="unfinished">End Time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="400"/>
        <source>条件选择结果：</source>
        <translation type="unfinished">Result of Condition Selection:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmquery/src/dialog/dlg_edit_condition.ui" line="420"/>
        <source>清空</source>
        <translation type="unfinished">Clear</translation>
    </message>
</context>
</TS>
