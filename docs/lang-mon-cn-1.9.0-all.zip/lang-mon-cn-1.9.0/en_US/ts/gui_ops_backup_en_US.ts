<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="430"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="817"/>
        <source>文件服务</source>
        <translation type="unfinished">File Service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1555"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1575"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1555"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1575"/>
        <source>取消历史备份失败</source>
        <translation type="unfinished">Failed to cancel historical backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/main.cpp" line="353"/>
        <source>登录模式不支持，请检查系统</source>
        <translation type="unfinished">Login mode is not supported, please check the system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/main.cpp" line="287"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/main.cpp" line="334"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/main.cpp" line="354"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/main.cpp" line="287"/>
        <source>本地系统正在运行，请先退出</source>
        <translation type="unfinished">The local system is running. Please exit first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/main.cpp" line="334"/>
        <source>远程机器系统正在运行，请先退出</source>
        <translation type="unfinished">The remote machine system is running. Please exit first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/main.cpp" line="506"/>
        <source>登录时限：</source>
        <translation type="unfinished">Login time limit:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/rtdb_info.cpp" line="474"/>
        <source>系统管理</source>
        <translation type="unfinished">Sysmgr</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/rtdb_info.cpp" line="481"/>
        <source>系统信息库</source>
        <translation type="unfinished">System info DB</translation>
    </message>
</context>
<context>
    <name>backupStacked</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_stackedwidget.cpp" line="63"/>
        <source>备份工具</source>
        <comment>toolName</comment>
        <translation type="unfinished">Backup Tools</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_stackedwidget.cpp" line="128"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_stackedwidget.cpp" line="137"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_stackedwidget.cpp" line="434"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_stackedwidget.cpp" line="479"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_stackedwidget.cpp" line="485"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_stackedwidget.cpp" line="128"/>
        <source>当前系统没有节点部署历史应用</source>
        <translation type="unfinished">Current system: no nodes with history app deployed.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_stackedwidget.cpp" line="137"/>
        <source>当前节点未部署历史应用，无法进行全库导出</source>
        <translation type="unfinished">Current node has not deployed any history applications and cannot export all db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_stackedwidget.cpp" line="434"/>
        <source>将进行最小系统启动，请稍等...</source>
        <translation type="unfinished">The minimum system startup will be carried out. Please wait for a moment...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_stackedwidget.cpp" line="479"/>
        <source>最小系统启动失败,程序退出</source>
        <translation type="unfinished">Failed to start minimum system, program exited</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_stackedwidget.cpp" line="485"/>
        <source>最小系统启动成功</source>
        <translation type="unfinished">The minimum system started successfully</translation>
    </message>
</context>
<context>
    <name>backup_config</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="41"/>
        <source>可执行程序</source>
        <translation type="unfinished">Executable program</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="48"/>
        <source>资源文件</source>
        <translation type="unfinished">Resource files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="55"/>
        <source>配置文件</source>
        <translation type="unfinished">Config files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="62"/>
        <source>画面文件</source>
        <translation type="unfinished">Graph file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="84"/>
        <source>实时数据库</source>
        <translation type="unfinished">TDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="233"/>
        <source>节点名称：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="240"/>
        <source>服务地址：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Service address:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="247"/>
        <source>开始时间：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Start time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="254"/>
        <source>结束时间：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">End time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="294"/>
        <source>应用全部</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Apply all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="348"/>
        <source>实时数据库配置：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">TDB config:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="114"/>
        <source>脚本目录</source>
        <translation type="unfinished">Script dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="121"/>
        <source>日志文件</source>
        <translation type="unfinished">Log files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="128"/>
        <source>数据文件</source>
        <translation type="unfinished">Data files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="150"/>
        <source>文件服务备份</source>
        <translation type="unfinished">File service backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="217"/>
        <source>历史数据备份</source>
        <translation type="unfinished">Historical data backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="157"/>
        <source>全版本</source>
        <translation type="unfinished">Full version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="91"/>
        <source>详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.ui" line="170"/>
        <source>最新版本</source>
        <translation type="unfinished">Latest version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.cpp" line="34"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.cpp" line="39"/>
        <source>详情</source>
        <translation type="unfinished">Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.cpp" line="328"/>
        <source>名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.cpp" line="328"/>
        <source>别名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.cpp" line="328"/>
        <source>运行库数据源</source>
        <comment>subTitle</comment>
        <translation type="unfinished">RTDB data source</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.cpp" line="329"/>
        <source>维护库数据源</source>
        <comment>subTitle</comment>
        <translation type="unfinished">MTDB data source</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.cpp" line="345"/>
        <source>实时库数据</source>
        <translation type="unfinished">TDB data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.cpp" line="666"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_config.cpp" line="666"/>
        <source>日期选择错误，请重新选择</source>
        <translation type="unfinished">Date selection error, please select again</translation>
    </message>
</context>
<context>
    <name>backup_exec</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="143"/>
        <source>选择路径</source>
        <translation type="unfinished">Select path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="68"/>
        <source>备份进度：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup progress:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="99"/>
        <source>备份清单：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup list:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="133"/>
        <source>备份包路径：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup package path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="168"/>
        <source>备份名称：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="196"/>
        <source>软件版本：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Software version:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="224"/>
        <source>并发数量：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Concurrent count:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="252"/>
        <source>节点信息：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="280"/>
        <source>备份信息：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="344"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="490"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="591"/>
        <source>图片</source>
        <translation type="unfinished">Picture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="351"/>
        <source>节点备份中</source>
        <translation type="unfinished">Node backup in progress</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="374"/>
        <source>进行中</source>
        <translation type="unfinished">In progress</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="428"/>
        <source>上一步</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Previous</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="435"/>
        <source>备份结果</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Backup results</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="442"/>
        <source>终止备份</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Stop backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="449"/>
        <source>开始备份</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Start backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="459"/>
        <source>详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="533"/>
        <source>任务详情：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Task details:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.ui" line="621"/>
        <source>失败信息</source>
        <translation type="unfinished">Error info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="113"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="187"/>
        <source>已完成</source>
        <translation type="unfinished">Completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="114"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="115"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="188"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="189"/>
        <source>准备进行备份</source>
        <translation type="unfinished">Preparing for backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="238"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="453"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="652"/>
        <source>可执行程序</source>
        <translation type="unfinished">Executable program</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="282"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="489"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="688"/>
        <source>画面文件</source>
        <translation type="unfinished">Graph file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="289"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="496"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="695"/>
        <source>配置文件</source>
        <translation type="unfinished">Config files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="295"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="502"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="701"/>
        <source>资源文件</source>
        <translation type="unfinished">Resource files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="302"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="509"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="708"/>
        <source>脚本文件</source>
        <translation type="unfinished">Script files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="309"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="516"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="715"/>
        <source>日志文件</source>
        <translation type="unfinished">Log files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="316"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="523"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="722"/>
        <source>数据文件</source>
        <translation type="unfinished">Data files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="325"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="731"/>
        <source>运行库数据</source>
        <translation type="unfinished">RTDB data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="338"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="371"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="744"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="779"/>
        <source>数据服务_%1</source>
        <translation type="unfinished">Data service_%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="358"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="766"/>
        <source>维护库数据</source>
        <translation type="unfinished">MTDB data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="393"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="538"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="579"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="616"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="833"/>
        <source>历史数据</source>
        <translation type="unfinished">Historical Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="409"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="554"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="595"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="632"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="849"/>
        <source>数据导出_%1</source>
        <translation type="unfinished">Data export_%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="420"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="807"/>
        <source>文件服务数据</source>
        <translation type="unfinished">File service data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="530"/>
        <source>实时库文件</source>
        <translation type="unfinished">TDB files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="566"/>
        <source>文件服务文件</source>
        <translation type="unfinished">File service file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="961"/>
        <source>没有需要备份的数据</source>
        <translation type="unfinished">No data to back up.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="967"/>
        <source>软件版本不能包含斜杠或反斜杠</source>
        <translation type="unfinished">Software version cannot include slashes or backslashes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1223"/>
        <source>参数错误或历史库异常</source>
        <translation type="unfinished">Param error or HDB exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1227"/>
        <source>远程备份数据失败</source>
        <translation type="unfinished">Remote backup data failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1231"/>
        <source>文件压缩失败</source>
        <translation type="unfinished">File compression failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1235"/>
        <source>环境文件备份失败</source>
        <translation type="unfinished">Environment file backup failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1239"/>
        <source>历史备份取消</source>
        <translation type="unfinished">Cancel historical backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1278"/>
        <source>备份已终止，可退出备份工具</source>
        <translation type="unfinished">Backup terminated, you can exit the backup tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1523"/>
        <source>选择备份包目录</source>
        <comment>toolName</comment>
        <translation type="unfinished">Select Backup Package DIR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1070"/>
        <source>备份进度：</source>
        <translation type="unfinished">Backup progress:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1071"/>
        <source>备份中</source>
        <translation type="unfinished">Backing up</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="961"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="967"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1078"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1278"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="103"/>
        <source>名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="103"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="119"/>
        <source>备份路径</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="103"/>
        <source>数据源</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Data source</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="103"/>
        <source>完成情况</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Completion</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="119"/>
        <source>备份结果</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup results</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="119"/>
        <source>详情</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="136"/>
        <source>节点名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="136"/>
        <source>操作系统</source>
        <comment>subTitle</comment>
        <translation type="unfinished">operating system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="136"/>
        <source>系统架构</source>
        <comment>subTitle</comment>
        <translation type="unfinished">System architecture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1079"/>
        <source>备份任务未完成，请确认是否中断备份任务。</source>
        <translation type="unfinished">The backup task is not completed. Please confirm whether to interrupt the backup task.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1130"/>
        <source>已完成 %1 %</source>
        <translation type="unfinished">%1 % completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1155"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1157"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1211"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1213"/>
        <source>失败</source>
        <translation type="unfinished">Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_exec.cpp" line="1251"/>
        <source>此次备份共产生 %1 条结果：其中已完成 %2 条，失败 %3 条。</source>
        <translation type="unfinished">This backup produced %1 results in total: %2 of them were completed and %3 failed.</translation>
    </message>
</context>
<context>
    <name>backup_info_wg</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="60"/>
        <source>系统备份</source>
        <translation type="unfinished">System Backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="66"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="90"/>
        <source>节点备份</source>
        <translation type="unfinished">Node backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="72"/>
        <source>历史在线时段备份</source>
        <translation type="unfinished">History online time backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="78"/>
        <source>历史离线全库备份</source>
        <translation type="unfinished">History offline all DB backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="84"/>
        <source>历史在线全库备份</source>
        <translation type="unfinished">History online all DB backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="193"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="248"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="389"/>
        <source>全局配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Global config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="429"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="442"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="454"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="461"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="544"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="429"/>
        <source>请选择备份内容</source>
        <translation type="unfinished">Please select backup content</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="442"/>
        <source>请配置历史数据库IP信息</source>
        <translation type="unfinished">Please configure HDB IP info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="454"/>
        <source>历史在线时段备份时备份时间不能超过一年</source>
        <translation type="unfinished">When backing up during historical online time periods, the backup time cannot exceed one year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="463"/>
        <source>历史离线备份将停止节点系统，是否继续！</source>
        <translation type="unfinished">History offline backup will stop the node system. Whether to continue!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="464"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="465"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="544"/>
        <source>节点系统停止失败</source>
        <translation type="unfinished">Node system stop failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.cpp" line="96"/>
        <source>类型异常</source>
        <translation type="unfinished">Type exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.ui" line="41"/>
        <source>备份方式：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup method:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.ui" line="74"/>
        <source>备份内容：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup contents:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.ui" line="109"/>
        <source>上一步</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Previous</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_info_wg.ui" line="116"/>
        <source>下一步</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Next</translation>
    </message>
</context>
<context>
    <name>backup_node_opt_dlg</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="228"/>
        <source>在线</source>
        <translation type="unfinished">Online</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="228"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="239"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="608"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="633"/>
        <source>离线</source>
        <translation type="unfinished">Offline</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="253"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="430"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="634"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="739"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="752"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="762"/>
        <source>可用</source>
        <translation type="unfinished">Available</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="253"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="271"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="434"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="554"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="601"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="609"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="625"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="626"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="781"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="782"/>
        <source>不可用</source>
        <translation type="unfinished">Unavailable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="153"/>
        <source>节点链接</source>
        <comment>toolName</comment>
        <translation type="unfinished">Node Link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="172"/>
        <source>节点名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="172"/>
        <source>系统状态</source>
        <comment>subTitle</comment>
        <translation type="unfinished">System status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="172"/>
        <source>系统网络</source>
        <comment>subTitle</comment>
        <translation type="unfinished">System net</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="173"/>
        <source>IP</source>
        <comment>subTitle</comment>
        <translation type="unfinished">IP</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="173"/>
        <source>RPC状态</source>
        <comment>subTitle</comment>
        <translation type="unfinished">RPC status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="173"/>
        <source>RPC链接</source>
        <comment>subTitle</comment>
        <translation type="unfinished">RPC link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="174"/>
        <source>网络链接</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Net link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="174"/>
        <source>系统操作</source>
        <comment>subTitle</comment>
        <translation type="unfinished">System operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="281"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="290"/>
        <source>链接</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="299"/>
        <source>停止</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Stop</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="424"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="436"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="473"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="478"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="483"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="488"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="493"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="507"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="545"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="683"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="770"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="775"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="784"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="424"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="775"/>
        <source>请输入正确的IP地址</source>
        <translation type="unfinished">Please enter the correct IP address</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="438"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="786"/>
        <source>节点 %1 rpc 链接失败</source>
        <translation type="unfinished">Node %1 RPC link failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="473"/>
        <source>节点RPC链接状态不可用，禁止停止系统</source>
        <translation type="unfinished">The RPC link status of the node is unavailable. Do not stop the system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="478"/>
        <source>节点已离线，无法停止</source>
        <translation type="unfinished">The node is offline and cannot be stopped</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="483"/>
        <source>节点状态未知，请建立链接</source>
        <translation type="unfinished">Node status unknown, please establish a link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="488"/>
        <source>节点正在停止中，请稍后</source>
        <translation type="unfinished">The node is stopping. Please wait a moment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="495"/>
        <source>是否停止节点 %1</source>
        <translation type="unfinished">Whether to stop node %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="496"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="497"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="509"/>
        <source>节点 %1 rpc 链接失败,禁止停止系统</source>
        <translation type="unfinished">Node %1 rpc connection failed. Do not stop the system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="547"/>
        <source>节点 %1 ipc 链接失败,禁止停止系统</source>
        <translation type="unfinished">Node %1 IPC connection failed. Do not stop the system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="552"/>
        <source>停止中</source>
        <translation type="unfinished">Stopping</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="602"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="627"/>
        <source>未知</source>
        <translation type="unfinished">Unknown</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="683"/>
        <source>节点%1网络链接不可用</source>
        <translation type="unfinished">Node %1 net link is unavailable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="770"/>
        <source>节点停止中，禁止进行网络链接</source>
        <translation type="unfinished">Node stopped, net connection prohibited</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="791"/>
        <source>链接中</source>
        <translation type="unfinished">Is linking</translation>
    </message>
</context>
<context>
    <name>backup_ret</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="87"/>
        <source>备份失败，备份包生成失败</source>
        <translation type="unfinished">Backup failed, backup package generation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="103"/>
        <source>备份成功</source>
        <translation type="unfinished">Backup successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="96"/>
        <source>备份完成，存在异常项目</source>
        <translation type="unfinished">Backup completed, abnormal items exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="28"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="162"/>
        <source>名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="28"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="162"/>
        <source>备份路径</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="28"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="162"/>
        <source>数据源</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Data source</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="28"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="162"/>
        <source>备份结果</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup results</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="37"/>
        <source>节点名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="37"/>
        <source>操作系统</source>
        <comment>subTitle</comment>
        <translation type="unfinished">operating system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="37"/>
        <source>系统架构</source>
        <comment>subTitle</comment>
        <translation type="unfinished">System architecture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="124"/>
        <source>此次备份共产生 %1 条结果：其中已完成 %2 条，失败 %3 条</source>
        <translation type="unfinished">A total of %1 results were gened from this backup: %2 were completed and %3 failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="176"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.cpp" line="176"/>
        <source>是否退出备份工具</source>
        <translation type="unfinished">Whether to exit the backup tool?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.ui" line="94"/>
        <source>退出工具</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.ui" line="101"/>
        <source>重新备份</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Rebackup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.ui" line="157"/>
        <source>备份包信息：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup package info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.ui" line="198"/>
        <source>备份包名称：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup package name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.ui" line="243"/>
        <source>备份包路径：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup package path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.ui" line="288"/>
        <source>备份包详情：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup package details:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.ui" line="333"/>
        <source>备份包大小：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup package size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.ui" line="378"/>
        <source>节点信息：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.ui" line="406"/>
        <source>软件版本：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Software version:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.ui" line="451"/>
        <source>备注信息：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Remarks:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_ret.ui" line="488"/>
        <source>备份结果详情：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup result details:</translation>
    </message>
</context>
<context>
    <name>backup_with_title</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_with_title.cpp" line="13"/>
        <source>系统备份工具</source>
        <comment>toolName</comment>
        <translation type="unfinished">System Backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_with_title.cpp" line="21"/>
        <source>系统备份工具(节点名:%1)</source>
        <comment>toolName</comment>
        <translation type="unfinished">System Backup (Node: %1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_with_title.cpp" line="87"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_with_title.cpp" line="98"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_with_title.cpp" line="87"/>
        <source>%1无权限打开此工具。</source>
        <translation type="unfinished">%1 does not have permission to open this tool.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/backup_with_title.cpp" line="98"/>
        <source>请等待全部备份任务执行完成</source>
        <translation type="unfinished">Please wait until all backup tasks are completed</translation>
    </message>
</context>
<context>
    <name>choose_backup_mode</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_mode.cpp" line="228"/>
        <source>历史在线时段备份</source>
        <translation type="unfinished">History online time backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_mode.cpp" line="240"/>
        <source>历史离线全库备份</source>
        <translation type="unfinished">History offline all DB backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_mode.cpp" line="216"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_mode.cpp" line="222"/>
        <source>节点备份</source>
        <translation type="unfinished">Node backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_mode.cpp" line="41"/>
        <source>历史在线时段备份</source>
        <comment>menuName</comment>
        <translation type="unfinished">History online time backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_mode.cpp" line="42"/>
        <source>历史离线全库备份</source>
        <comment>menuName</comment>
        <translation type="unfinished">History offline all db backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_mode.cpp" line="43"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_mode.cpp" line="44"/>
        <source>节点备份</source>
        <comment>menuName</comment>
        <translation type="unfinished">Node backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_mode.cpp" line="45"/>
        <source>系统备份</source>
        <comment>menuName</comment>
        <translation type="unfinished">System backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_mode.cpp" line="46"/>
        <source>历史在线全库备份</source>
        <comment>menuName</comment>
        <translation type="unfinished">History online all DB backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_mode.cpp" line="210"/>
        <source>系统备份</source>
        <translation type="unfinished">System Backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_mode.cpp" line="234"/>
        <source>历史在线全库备份</source>
        <translation type="unfinished">History online all DB backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_mode.ui" line="109"/>
        <source>下一步</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Next</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_mode.ui" line="165"/>
        <source>高级</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Advanced</translation>
    </message>
</context>
<context>
    <name>choose_backup_node</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="48"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="168"/>
        <source>请选择需要停止系统的节点</source>
        <translation type="unfinished">Please select the node to stop the system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="56"/>
        <source>请最后进行本机离线，否则相连节点状态可能获取异常</source>
        <translation type="unfinished">Please take the machine offline at last, otherwise the status of connected nodes may retrieve abnormal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="93"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="342"/>
        <source>在线</source>
        <translation type="unfinished">Online</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="93"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="347"/>
        <source>离线</source>
        <translation type="unfinished">Offline</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="168"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="305"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="318"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="326"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="180"/>
        <source>是否停止该节点的系统</source>
        <translation type="unfinished">Whether to stop the system of this node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="192"/>
        <source>登录节点已离线，无法进行离线操作</source>
        <translation type="unfinished">The login node is offline and cannot be operated offline</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="326"/>
        <source>请选择离线备份的节点</source>
        <translation type="unfinished">Please select the node for offline backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="174"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="192"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="39"/>
        <source>节点名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="39"/>
        <source>节点状态</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="55"/>
        <source>请选择离线节点进行备份，在线节点需停止系统后才可进行离线备份</source>
        <translation type="unfinished">Please select an offline node for backup. Online nodes can only be backed up offline after the system is stopped</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="70"/>
        <source>节点信息</source>
        <comment>toolName</comment>
        <translation type="unfinished">Node Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="174"/>
        <source>所选节点均已离线</source>
        <translation type="unfinished">The selected nodes are all offline</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="179"/>
        <source>停止系统节点</source>
        <translation type="unfinished">Stop the system node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="207"/>
        <source>系统停止中</source>
        <translation type="unfinished">The system is stopping.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="305"/>
        <source>节点信息为空，无法进行离线备份</source>
        <translation type="unfinished">The node info is empty and offline backup is not possible.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.cpp" line="318"/>
        <source>请停止所选节点的系统</source>
        <translation type="unfinished">Please stop the system of the selected node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.ui" line="98"/>
        <source>停止系统</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Stop system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.ui" line="118"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_backup_node.ui" line="125"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
</context>
<context>
    <name>choose_node_dlg</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="29"/>
        <source>节点选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">Node Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="64"/>
        <source>节点名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="64"/>
        <source>节点状态</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="84"/>
        <source>在线</source>
        <translation type="unfinished">Online</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="84"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="94"/>
        <source>离线</source>
        <translation type="unfinished">Offline</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="142"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/choose_node.cpp" line="142"/>
        <source>请选择节点</source>
        <translation type="unfinished">Please select the node</translation>
    </message>
</context>
<context>
    <name>ipc_connect_widget</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/ipc_connect_widget.cpp" line="24"/>
        <source>请输入主机IP地址</source>
        <translation type="unfinished">Enter the host IP address</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/ipc_connect_widget.cpp" line="37"/>
        <source>链接</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/ipc_connect_widget.cpp" line="39"/>
        <source>关闭</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/ipc_connect_widget.cpp" line="52"/>
        <source>链接</source>
        <comment>toolName</comment>
        <translation type="unfinished">Link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/ipc_connect_widget.cpp" line="65"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/ipc_connect_widget.cpp" line="71"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/ipc_connect_widget.cpp" line="79"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/ipc_connect_widget.cpp" line="84"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/ipc_connect_widget.cpp" line="65"/>
        <source>IP格式不正确</source>
        <translation type="unfinished">The IP address format is incorrect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/ipc_connect_widget.cpp" line="71"/>
        <source>端口号不在合法范围内</source>
        <translation type="unfinished">The port number is invalid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/ipc_connect_widget.cpp" line="77"/>
        <source>已链接</source>
        <translation type="unfinished">Linked</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/ipc_connect_widget.cpp" line="79"/>
        <source>链接成功</source>
        <translation type="unfinished">Link successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/ipc_connect_widget.cpp" line="84"/>
        <source>链接失败，请检查参数</source>
        <translation type="unfinished">Link failed, please check the params</translation>
    </message>
</context>
<context>
    <name>online_nodeinfo_dlg</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.cpp" line="13"/>
        <source>节点信息</source>
        <comment>toolName</comment>
        <translation type="unfinished">Node Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.cpp" line="29"/>
        <source>应用名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">App name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.cpp" line="29"/>
        <source>应用别名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Application aliases</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.cpp" line="29"/>
        <source>应用状态</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Application status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.cpp" line="29"/>
        <source>备份运行数据节点</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Back up the running data node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.cpp" line="29"/>
        <source>备份维护数据节点</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup and maintain data nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.cpp" line="43"/>
        <source>系统信息</source>
        <comment>subTitle</comment>
        <translation type="unfinished">System info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.cpp" line="43"/>
        <source>架构信息</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Architecture info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.cpp" line="43"/>
        <source>包含节点</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Included nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.cpp" line="43"/>
        <source>备份节点</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.cpp" line="149"/>
        <source>运行应用异常</source>
        <translation type="unfinished">Application running abnormality</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.cpp" line="153"/>
        <source>维护应用异常</source>
        <translation type="unfinished">Maintenance application exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.cpp" line="157"/>
        <source>应用异常</source>
        <translation type="unfinished">Application exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.ui" line="23"/>
        <source>异常应用信息：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Abnormal application info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.ui" line="39"/>
        <source>可执行程序备份信息：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Executable program backup info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.ui" line="68"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/online_nodeinfo_dlg.ui" line="75"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
</context>
<context>
    <name>status_widget</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/base_widget.cpp" line="36"/>
        <source>等待中</source>
        <translation type="unfinished">Waiting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/base_widget.cpp" line="47"/>
        <source>进行中</source>
        <translation type="unfinished">In progress</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/base_widget.cpp" line="60"/>
        <source>失败</source>
        <translation type="unfinished">Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_backup/src/base_widget.cpp" line="71"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
</context>
</TS>
