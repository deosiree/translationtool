<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/data/report_statistic_data.cpp" line="22"/>
        <source>数据块测试数据</source>
        <comment>ReportStatisticData::getDataBlockData</comment>
        <translation type="unfinished">Data block test data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/data/report_statistic_data.cpp" line="23"/>
        <source>测试1</source>
        <comment>ReportStatisticData::getDataBlockData</comment>
        <translation type="unfinished">3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/data/report_statistic_data.cpp" line="23"/>
        <source>测试2</source>
        <comment>ReportStatisticData::getDataBlockData</comment>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/data/report_statistic_data.cpp" line="36"/>
        <source>序号</source>
        <comment>ReportStatisticData::getDataBlockData</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/data/report_statistic_data.cpp" line="36"/>
        <source>对象</source>
        <comment>ReportStatisticData::getDataBlockData</comment>
        <translation type="unfinished">Object</translation>
    </message>
</context>
</TS>
