<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_decisioneditor/main.cpp" line="59"/>
        <source>用户%1没有对应的权限</source>
        <comment>gui_decisioneditor::main</comment>
        <translation type="unfinished">User %1 does not have corresponding permissions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_decisioneditor/main.cpp" line="60"/>
        <location filename="../../../../src/plat/gui/tool/gui_decisioneditor/main.cpp" line="124"/>
        <source>提示</source>
        <comment>gui_decisioneditor::main</comment>
        <translation type="unfinished">Tip</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_decisioneditor/main.cpp" line="124"/>
        <source>注册失败</source>
        <comment>gui_decisioneditor::main</comment>
        <translation type="unfinished">Registration failed</translation>
    </message>
</context>
</TS>
