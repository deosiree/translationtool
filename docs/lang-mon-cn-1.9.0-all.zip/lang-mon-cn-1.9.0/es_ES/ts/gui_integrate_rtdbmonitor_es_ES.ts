<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/plugin_rtdb_monitor.cpp" line="58"/>
        <source>实时库监视</source>
        <translation type="unfinished">Monitor de TDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="828"/>
        <source>选择计算剩余存储时间的时间单位（1小时/1天）</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="834"/>
        <source>1小时</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="835"/>
        <source>1天</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="193"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="555"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="526"/>
        <source>%1 年</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="528"/>
        <source>%1 月</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 M</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="530"/>
        <source>%1 天</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 D</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="532"/>
        <source>%1 小时</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 H</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="235"/>
        <source>关系库(RDB)</source>
        <translation type="unfinished">RDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="22"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="743"/>
        <source>历史库容量估计</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="23"/>
        <source>历史库容量估计（剩余容量不足）</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="193"/>
        <source>获取%1节点库类型失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="240"/>
        <source>时序库(SDB)</source>
        <translation type="unfinished">SDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="245"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="280"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="289"/>
        <source>未知</source>
        <translation type="unfinished">Desconocido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="509"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="536"/>
        <source>剩余空间不足，将自动删除旧数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="513"/>
        <source>待计算</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="555"/>
        <source>请先连接数据库</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="623"/>
        <source>历史库基础信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="726"/>
        <source>数据库节点</source>
        <translation type="unfinished">Nodo de BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="727"/>
        <source>数据库型号</source>
        <translation type="unfinished">Tipo de BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="728"/>
        <source>数据库名称</source>
        <translation type="unfinished">Nombre de la BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="729"/>
        <source>数据库版本</source>
        <translation type="unfinished">Versión de la BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="730"/>
        <source>数据库类型</source>
        <translation type="unfinished">Tipo de BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="731"/>
        <source>当前连接时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="799"/>
        <source>历史库磁盘完整容量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="800"/>
        <source>历史库磁盘当前使用容量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="803"/>
        <source>历史库磁盘剩余容量</source>
        <translation type="unfinished">Capacidad de disco restante de la BD histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="808"/>
        <source>历史库当前容量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="827"/>
        <source>存储计算时间依据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="850"/>
        <source>计算基准容量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="855"/>
        <source>计算基准容量记录时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="861"/>
        <source>历史库数据保留天数</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="861"/>
        <source>历史库磁盘清理阈值</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="864"/>
        <source>数据天数超过该值后，会自动清理历史库数据，如需修改该参数，请在历史库管理工具中进行设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="865"/>
        <source>磁盘空间超过该值时，会自动清理历史库数据，如需修改该参数，请在历史库管理工具中进行设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="920"/>
        <source>历史库理论剩余容量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="926"/>
        <source>历史库理论剩余可存时间</source>
        <translation type="unfinished">Tiempo teórico restante de almacenamiento de la BD histórica</translation>
    </message>
</context>
<context>
    <name>db_mainwindow</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/mainwindow.cpp" line="28"/>
        <source>实时库</source>
        <translation type="unfinished">TDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/mainwindow.cpp" line="29"/>
        <source>历史库</source>
        <translation type="unfinished">Lib. histórica</translation>
    </message>
</context>
<context>
    <name>hisdb_mainwindow</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="185"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="185"/>
        <source>历史库链接失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="442"/>
        <source>%1天</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="893"/>
        <source>历史库自动清理阈值，范围是20-95%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="923"/>
        <source>历史库理论剩余容量，根据当前磁盘使用情况和清理阈值计算</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/hisdb_mainwindow.cpp" line="929"/>
        <source>历史库理论剩余可存时间，根据历史库理论剩余容量与近期历史库数据增长计算</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>rtdb_mainwindow</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="70"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="70"/>
        <source>库信息</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Info de BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="70"/>
        <source>表名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="70"/>
        <source>表容量</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Capacidad de la Tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="71"/>
        <source>表记录数</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Conteo de registros de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="71"/>
        <source>表余量</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tabla restante</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="71"/>
        <source>余量占比（%）</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Proporción de stock restante (%)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="72"/>
        <source>对象大小（B）</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tamaño del objeto (B)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="72"/>
        <source>表大小（MB）</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tamaño de la tabla (MB)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="103"/>
        <source>核心实时库</source>
        <translation type="unfinished">TDB central</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="107"/>
        <source>应用实时库</source>
        <translation type="unfinished">TDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="144"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="251"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="151"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="251"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="217"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="353"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="217"/>
        <source>节点实时库信息获取失败</source>
        <translation type="unfinished">Fallo en la adquisición de info de TDB del nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_rtdbmonitor/rtdb_mainwindow.cpp" line="355"/>
        <source>输入内容超长</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
