<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CurveMainWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_curveeditor/curve_mainwidget.cpp" line="83"/>
        <source>日期设置</source>
        <translation type="unfinished">Date setting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_curveeditor/curve_mainwidget.cpp" line="342"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_curveeditor/curve_mainwidget.cpp" line="342"/>
        <source>曲线组名称不可为空</source>
        <translation type="unfinished">Curve group name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_curveeditor/curve_mainwidget.cpp" line="358"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_curveeditor/curve_mainwidget.cpp" line="358"/>
        <source>暂未实现，敬请期待</source>
        <translation type="unfinished">Not yet realized, please look forward to it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_curveeditor/curve_mainwidget.cpp" line="416"/>
        <source>开启实时刷新</source>
        <translation type="unfinished">Enable real-time refresh</translation>
    </message>
</context>
</TS>
