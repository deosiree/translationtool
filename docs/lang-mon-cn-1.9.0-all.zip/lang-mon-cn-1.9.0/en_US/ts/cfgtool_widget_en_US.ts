<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/cfgtool_widget.cpp" line="108"/>
        <source>没有读取权限</source>
        <translation type="unfinished">No read permission</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/cfgtool_widget.cpp" line="123"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/cfgtool_widget.cpp" line="123"/>
        <source>请先保存正在编辑的配置组</source>
        <translation type="unfinished">Please save the config group you are editing first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/cfgtool_widget.cpp" line="264"/>
        <source>配置运行目录失败</source>
        <translation type="unfinished">Failed to configure the running dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="216"/>
        <source>无效的节点！</source>
        <translation type="unfinished">Invalid node!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="222"/>
        <source>名称未改变！</source>
        <translation type="unfinished">The name has not changed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="242"/>
        <source>重命名失败！</source>
        <translation type="unfinished">Failed to rename!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="552"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="581"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="613"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="648"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="672"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="751"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="775"/>
        <source>不是配置组！</source>
        <translation type="unfinished">Not config group!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="564"/>
        <source>打开配置组失败！</source>
        <translation type="unfinished">Failed to open config group!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="587"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="619"/>
        <source>配置组未打开！</source>
        <translation type="unfinished">Config group not open!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="593"/>
        <source>未申请编辑！</source>
        <translation type="unfinished">No editing requested!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="599"/>
        <source>保存配置组失败！</source>
        <translation type="unfinished">Failed to save config group!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="625"/>
        <source>关闭配置组失败！</source>
        <translation type="unfinished">Failed to close config group!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="661"/>
        <source>导出头文件失败！

1. 请检查配置组能否正确打开
2. 请检查是否存在自定义类型（没有自定义类型则无法导出）</source>
        <translation type="unfinished">Failed to export the header file! 1. Please check if the configuration group can be opened correctly; 2. Please check if there are custom types (if there are no custom types, export cannot be performed)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="678"/>
        <source>配置组未关闭！</source>
        <translation type="unfinished">The config group is not closed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="694"/>
        <source>删除配置组失败！</source>
        <translation type="unfinished">Failed to delete config group!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="706"/>
        <source>不是目录！</source>
        <translation type="unfinished">Not a dir!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="712"/>
        <source>存在配置组未关闭！</source>
        <translation type="unfinished">Open config group exists!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="740"/>
        <source>删除目录失败！</source>
        <translation type="unfinished">Failed to delete dir!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="763"/>
        <source>发布配置组失败！</source>
        <translation type="unfinished">Failed to publish config group!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="786"/>
        <source>清除草稿失败！</source>
        <translation type="unfinished">Clearing draft failed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="799"/>
        <source>不是配置组</source>
        <translation type="unfinished">Not config group</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="805"/>
        <source>文件不存在或不是文件</source>
        <translation type="unfinished">The file does not exist or is not a file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="829"/>
        <source>无法加载指定的文件，请检查文件格式是否正确</source>
        <translation type="unfinished">The specified file cannot be loaded. Please check whether the file format is correct</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="833"/>
        <source>导入数据失败，无法查找到指定配置组</source>
        <translation type="unfinished">Failed to import data; the specified config group cannot be found.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="837"/>
        <source>无法关闭指定的文件，请尽快保存并重启工具</source>
        <translation type="unfinished">Unable to close the specified file, please save and restart the tool as soon as possible</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1116"/>
        <source>名称不能为空！</source>
        <translation type="unfinished">The name cannot be empty!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1130"/>
        <source>名称重复！</source>
        <translation type="unfinished">Duplicate name!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1181"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1206"/>
        <source>名称不合法！</source>
        <translation type="unfinished">The name is invalid!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1194"/>
        <source>创建目录失败！</source>
        <translation type="unfinished">Failed to create dir!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1219"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1254"/>
        <source>创建文件失败！</source>
        <translation type="unfinished">Failed to create file!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1233"/>
        <source>配置组名不合法！</source>
        <translation type="unfinished">Configuring group name is invalid!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1267"/>
        <source>目录</source>
        <translation type="unfinished">DIR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1269"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="72"/>
        <source>配置组</source>
        <translation type="unfinished">Config group</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1271"/>
        <source>类型总览</source>
        <translation type="unfinished">Type overview</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1273"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1493"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1496"/>
        <source>配置项</source>
        <translation type="unfinished">Config items</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1275"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1492"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1495"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="74"/>
        <source>自定义类型</source>
        <translation type="unfinished">Custom types</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1277"/>
        <source>数据项</source>
        <translation type="unfinished">Data item</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1279"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="90"/>
        <source>未知</source>
        <translation type="unfinished">Unknown</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="76"/>
        <source>键值对</source>
        <translation type="unfinished">Key-value pairs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="78"/>
        <source>数据节点</source>
        <translation type="unfinished">Data node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="80"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="104"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="112"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="119"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="92"/>
        <source>整数</source>
        <translation type="unfinished">Integer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="94"/>
        <source>浮点数</source>
        <translation type="unfinished">Float</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="96"/>
        <source>字符串</source>
        <translation type="unfinished">String</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="98"/>
        <source>布尔</source>
        <translation type="unfinished">Boolean</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="100"/>
        <source>枚举</source>
        <translation type="unfinished">Enum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="102"/>
        <source>结构体</source>
        <translation type="unfinished">Struct</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="129"/>
        <source>数组</source>
        <translation type="unfinished">Array</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="194"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="194"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="28"/>
        <source>权限不足</source>
        <translation type="unfinished">Insufficient permissions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="28"/>
        <source>无写权限</source>
        <translation type="unfinished">No write permission</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgDataDelegate</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_data_viewer/cfg_data_delegate.cpp" line="55"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_data_viewer/cfg_data_delegate.cpp" line="123"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_data_viewer/cfg_data_delegate.cpp" line="55"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_data_viewer/cfg_data_delegate.cpp" line="124"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgDataModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_data_viewer/cfg_data_model.cpp" line="318"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_data_viewer/cfg_data_model.cpp" line="322"/>
        <source>值</source>
        <translation type="unfinished">Value</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgHierarchyModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="255"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="261"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="706"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="727"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="429"/>
        <source>当前有文件正在编辑中，请先保存！</source>
        <translation type="unfinished">File being edited. Save first!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="452"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="476"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="502"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="531"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="556"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="573"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="605"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="636"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="660"/>
        <source>无效的节点！</source>
        <translation type="unfinished">Invalid node!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="482"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="514"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="537"/>
        <source>文件未打开！</source>
        <translation type="unfinished">File not opened!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="508"/>
        <source>无写权限！</source>
        <translation type="unfinished">No write permission!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="579"/>
        <source>目录下存在打开的文件，无法删除！</source>
        <translation type="unfinished">Dir has open files. Cannot delete!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="611"/>
        <source>文件已打开，无法删除！</source>
        <translation type="unfinished">The file is opened and cannot be deleted!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="642"/>
        <source>文件正在编辑中，无法发布！</source>
        <translation type="unfinished">The file is being edited and cannot be published!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="666"/>
        <source>不存在草稿</source>
        <translation type="unfinished">No draft exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="684"/>
        <source>无效的节点</source>
        <translation type="unfinished">Invalid node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="714"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="714"/>
        <source>当前有文件正在编辑！</source>
        <translation type="unfinished">File being edited!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="768"/>
        <source>未发布</source>
        <translation type="unfinished">Unpublished</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgHierarchyTree</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="91"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="704"/>
        <source>创建目录</source>
        <translation type="unfinished">Create dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="124"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="703"/>
        <source>创建配置组</source>
        <translation type="unfinished"> Create Config Group</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="139"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="145"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="171"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="177"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="184"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="709"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="710"/>
        <source>重命名</source>
        <translation type="unfinished">Rename</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="139"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="177"/>
        <source>文件存在草稿，请先处理草稿</source>
        <translation type="unfinished">File has draft. Process draft first.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="145"/>
        <source>是否申请重命名？</source>
        <translation type="unfinished">Whether to apply for renaming?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="171"/>
        <source>文件已打开，请先关闭文件</source>
        <translation type="unfinished">The file is already open; please close it first.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="183"/>
        <source>重命名会修改配置组名 【</source>
        <translation type="unfinished">Renaming will modify the config group name [</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="183"/>
        <source>】, 而非显示名 【</source>
        <translation type="unfinished">】, instead of the display name【</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="183"/>
        <source>】, 是否继续?</source>
        <translation type="unfinished">]. Continue?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="228"/>
        <source>打开文件</source>
        <translation type="unfinished">Open file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="241"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="251"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="257"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="263"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="272"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="290"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="713"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="241"/>
        <source>是否删除？</source>
        <translation type="unfinished">Whether to delete?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="251"/>
        <source>无法删除该节点</source>
        <translation type="unfinished">Unable to delete the node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="257"/>
        <source>目录下存在已打开的配置组，请先关闭配置组</source>
        <translation type="unfinished">Dir has open config group. Close first.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="263"/>
        <source>配置组已打开，请先关闭文件</source>
        <translation type="unfinished">The config group is already open, please close the file first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="272"/>
        <source>文件存在草稿，是否同时删除草稿？</source>
        <translation type="unfinished">File has draft. Delete draft too?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="314"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="323"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="327"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="715"/>
        <source>发布</source>
        <translation type="unfinished">Publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="314"/>
        <source>是否发布？</source>
        <translation type="unfinished">Whether to publish?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="327"/>
        <source>发布成功</source>
        <translation type="unfinished">Published successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="339"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="343"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="717"/>
        <source>清除草稿</source>
        <translation type="unfinished">Clear draft</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="343"/>
        <source>清除成功</source>
        <translation type="unfinished">Clear successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="364"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="371"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="707"/>
        <source>申请编辑</source>
        <translation type="unfinished">Apply edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="364"/>
        <source>只能同时编辑一个配置组</source>
        <translation type="unfinished">Only one config group can be edited at a time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="418"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="422"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="482"/>
        <source>保存文件</source>
        <translation type="unfinished">Save file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="422"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="437"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="444"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="448"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="455"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="462"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="466"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="727"/>
        <source>导出头文件</source>
        <translation type="unfinished">Export Header File</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="437"/>
        <source>文件未保存，无法导出</source>
        <translation type="unfinished">File not saved, cannot be exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="443"/>
        <source>文件正在编辑中，导出的头文件将是编辑前的版本，是否继续？</source>
        <translation type="unfinished">The file is being edited. The exported header file will be the version before editing. Whether to continue?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="454"/>
        <source>本配置组存在草稿，是否使用草稿导出头文件？</source>
        <translation type="unfinished">A draft exists for this config group. Whether to use the draft to export the header file?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="466"/>
        <source>导出成功</source>
        <translation type="unfinished">Export Successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="483"/>
        <source>文件正在编辑中，请保存后再关闭</source>
        <translation type="unfinished">File is currently being edited. Please save it before closing it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="490"/>
        <source>关闭文件</source>
        <translation type="unfinished">Close file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="501"/>
        <source>选择文件</source>
        <translation type="unfinished">Select file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="501"/>
        <source>XML 文件 (*.xml)</source>
        <translation type="unfinished">XML file (*.xml)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="506"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="510"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="718"/>
        <source>导入数据</source>
        <translation type="unfinished">Import data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="510"/>
        <source>导入成功</source>
        <translation type="unfinished">Import successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="712"/>
        <source>打开</source>
        <translation type="unfinished">Open</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="714"/>
        <source>同步</source>
        <translation type="unfinished">Sync</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="716"/>
        <source>关闭</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="720"/>
        <source>添加类型</source>
        <translation type="unfinished">Add type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="721"/>
        <source>删除类型</source>
        <translation type="unfinished">Delete type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="723"/>
        <source>构造数据</source>
        <translation type="unfinished">Construct Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="724"/>
        <source>验证数据</source>
        <translation type="unfinished">Verify data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="726"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgLeftPane</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_left_pane.ui" line="465"/>
        <source>请输入关键字查询</source>
        <translation type="unfinished">Please enter keyword search</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgOptionDelegate</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_delegate.cpp" line="55"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_delegate.cpp" line="165"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_delegate.cpp" line="55"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_delegate.cpp" line="166"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgOptionModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="50"/>
        <source>键名</source>
        <translation type="unfinished">Key name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="51"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="52"/>
        <source>描述</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="53"/>
        <source>值</source>
        <translation type="unfinished">Value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="54"/>
        <source>类型</source>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="55"/>
        <source>基础类型</source>
        <translation type="unfinished">Basic types</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="56"/>
        <source>引用类型</source>
        <translation type="unfinished">Reference types</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="57"/>
        <source>默认值</source>
        <translation type="unfinished">Default value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="58"/>
        <source>最小值</source>
        <translation type="unfinished">Minimum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="59"/>
        <source>最大值</source>
        <translation type="unfinished">Maximum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="60"/>
        <source>数组</source>
        <translation type="unfinished">Array</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="61"/>
        <source>数组最大容量</source>
        <translation type="unfinished">Maximum capacity of an array</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="62"/>
        <source>字符串长度</source>
        <translation type="unfinished">String length</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="63"/>
        <source>规则</source>
        <translation type="unfinished">Rule</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgOptionViewer</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_viewer.cpp" line="136"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_viewer.cpp" line="136"/>
        <source>无法删除键值对!</source>
        <translation type="unfinished">Unable to delete key-value pair!</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgPageHinter</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_work_widget/cfg_page_hinter.h" line="54"/>
        <source>类型总览</source>
        <translation type="unfinished">Type overview</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_work_widget/cfg_page_hinter.h" line="58"/>
        <source>配置项总览</source>
        <translation type="unfinished">Config item overview</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgPropModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="29"/>
        <source>对象</source>
        <translation type="unfinished">Object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="30"/>
        <source>键名</source>
        <translation type="unfinished">Key name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="31"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="32"/>
        <source>描述</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="34"/>
        <source>基础类型</source>
        <translation type="unfinished">Basic types</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="35"/>
        <source>引用类型</source>
        <translation type="unfinished">Reference types</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="36"/>
        <source>默认值</source>
        <translation type="unfinished">Default value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="37"/>
        <source>最小值</source>
        <translation type="unfinished">Minimum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="38"/>
        <source>最大值</source>
        <translation type="unfinished">Maximum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="39"/>
        <source>数组</source>
        <translation type="unfinished">Array</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="40"/>
        <source>最大容量</source>
        <translation type="unfinished">Maximum capacity</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="41"/>
        <source>字符串长度</source>
        <translation type="unfinished">String length</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="42"/>
        <source>规则</source>
        <translation type="unfinished">Rule</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="110"/>
        <source>属性</source>
        <translation type="unfinished">Attr</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="114"/>
        <source>值</source>
        <translation type="unfinished">Value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="228"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="228"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgPropertyWidget</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_property_widget.ui" line="508"/>
        <source>属性</source>
        <translation type="unfinished">Attr</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgSearchBar</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/search_bar/cfg_search_bar.cpp" line="29"/>
        <source>请输入关键词查询</source>
        <translation type="unfinished">Please enter a keyword query</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgTypeComboBox</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_type_combobox/cfg_type_combobox.cpp" line="73"/>
        <source>整数</source>
        <translation type="unfinished">Integer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_type_combobox/cfg_type_combobox.cpp" line="74"/>
        <source>浮点数</source>
        <translation type="unfinished">Float</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_type_combobox/cfg_type_combobox.cpp" line="75"/>
        <source>字符串</source>
        <translation type="unfinished">string</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_type_combobox/cfg_type_combobox.cpp" line="76"/>
        <source>布尔值</source>
        <translation type="unfinished">Boolean</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgTypeModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_type_viewer/cfg_type_model.cpp" line="126"/>
        <source>新建字段</source>
        <translation type="unfinished">New Field</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgtoolWidget</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/cfgtool_widget.cpp" line="306"/>
        <source>正在编辑</source>
        <translation type="unfinished">Editing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/cfgtool_widget.cpp" line="307"/>
        <source>当前有文件正在编辑，确认退出？</source>
        <translation type="unfinished">File is being edited. Exit?</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::DlgCreateDir</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_dir/dlg_create_dir.ui" line="14"/>
        <source>创建目录</source>
        <translation type="unfinished">Create dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_dir/dlg_create_dir.ui" line="22"/>
        <source>目录名称</source>
        <translation type="unfinished">DIR name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_dir/dlg_create_dir.ui" line="29"/>
        <source>不可重复，不可包含 .\\/:*?&quot;&lt;&gt;|</source>
        <translation type="unfinished">Must be unique and must not contain .\\/:*?&quot;&lt;&gt;|</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_dir/dlg_create_dir.cpp" line="47"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_dir/dlg_create_dir.cpp" line="47"/>
        <source>文件夹名称不合法</source>
        <translation type="unfinished">The folder name is invalid</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::DlgCreateFile</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.ui" line="14"/>
        <source>创建配置组</source>
        <translation type="unfinished">Create Config Group</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.ui" line="22"/>
        <source>显示名称</source>
        <translation type="unfinished">Display name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.ui" line="29"/>
        <source>若为空，则和组名一致</source>
        <translation type="unfinished">If empty, it will be the same as the group name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.ui" line="36"/>
        <source>配置组名</source>
        <translation type="unfinished">Config group name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.ui" line="52"/>
        <source>不可重复，不可包含 .\\/:*?&quot;&lt;&gt;|</source>
        <translation type="unfinished">Must be unique and must not contain .\\/:*?&quot;&lt;&gt;|</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.ui" line="61"/>
        <source>配置描述</source>
        <translation type="unfinished">Config description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.ui" line="75"/>
        <source>若取消此项，配置组在保存时才会真正创建</source>
        <translation type="unfinished">If you cancel this option , the config group will not be created until it is saved.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.ui" line="78"/>
        <source>直接创建(需要权限)</source>
        <translation type="unfinished">Create directly (requires permission)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.cpp" line="67"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.cpp" line="67"/>
        <source>配置组名不合法</source>
        <translation type="unfinished">The config group name is invalid.</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::DlgCreateKVPair</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="14"/>
        <source>创建键值对</source>
        <translation type="unfinished">Create key-value pairs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="20"/>
        <source>基础信息</source>
        <translation type="unfinished">Basic Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="26"/>
        <source>键名</source>
        <translation type="unfinished">Key name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="33"/>
        <source>不可重复，仅允许字母数字下划线，且不能以数字开头</source>
        <translation type="unfinished">Cannot be duplicated, only letters, numbers and base lines are allowed, and cannot start with a number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="40"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="50"/>
        <source>类型</source>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="60"/>
        <source>描述</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="70"/>
        <source>是否数组</source>
        <translation type="unfinished">Array</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="79"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="252"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="86"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="253"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="101"/>
        <source>拓展信息</source>
        <translation type="unfinished">Further info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="107"/>
        <source>范围</source>
        <translation type="unfinished">range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="128"/>
        <source>~</source>
        <translation type="unfinished">～</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="140"/>
        <source>默认值</source>
        <translation type="unfinished">Default value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="147"/>
        <source>数组最大容量</source>
        <translation type="unfinished">Maximum capacity of an array</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="154"/>
        <source>字符串最大长度</source>
        <translation type="unfinished">Maximum string length</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="167"/>
        <source>规则</source>
        <translation type="unfinished">Rule</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="300"/>
        <source>键名不合法</source>
        <translation type="unfinished">Invalid key name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="105"/>
        <source>输入不合法</source>
        <translation type="unfinished">Invalid input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="127"/>
        <source>创建失败</source>
        <translation type="unfinished">Creation failed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="127"/>
        <source>创建失败！</source>
        <translation type="unfinished">Creation failed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="311"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="324"/>
        <source>最小值不能超过最大值</source>
        <translation type="unfinished">Minimum cannot exceed maximum value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="315"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="328"/>
        <source>默认值需要在最大值和最小值之间</source>
        <translation type="unfinished">The default value needs to be between the maximum and minimum values</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::DlgCreateUType</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.ui" line="14"/>
        <source>创建自定义类型</source>
        <translation type="unfinished">Create custom types</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.ui" line="22"/>
        <source>键名</source>
        <translation type="unfinished">Key name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.ui" line="29"/>
        <source>不可重复，仅允许字母数字下划线，且不能以数字开头</source>
        <translation type="unfinished">Cannot be duplicated, only letters, numbers and base lines are allowed, and cannot start with a number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.ui" line="36"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.ui" line="46"/>
        <source>描述</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.ui" line="73"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.ui" line="80"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.cpp" line="61"/>
        <source>键名不合法</source>
        <translation type="unfinished">Invalid key name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.cpp" line="61"/>
        <source>键名不合法！</source>
        <translation type="unfinished">The key name is invalid!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.cpp" line="66"/>
        <source>名称不能为空</source>
        <translation type="unfinished">Name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.cpp" line="66"/>
        <source>名称不能为空！</source>
        <translation type="unfinished">The name cannot be empty!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.cpp" line="73"/>
        <source>创建失败</source>
        <translation type="unfinished">Creation failed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.cpp" line="73"/>
        <source>创建失败！</source>
        <translation type="unfinished">Creation failed!</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::FileInfoModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="80"/>
        <source>属性</source>
        <translation type="unfinished">Attr</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="82"/>
        <source>值</source>
        <translation type="unfinished">Value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="183"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="186"/>
        <source>节点类型</source>
        <translation type="unfinished">Node type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="183"/>
        <source>配置组名</source>
        <translation type="unfinished">Config group name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="183"/>
        <source>显示名称</source>
        <translation type="unfinished">Display name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="183"/>
        <source>配置描述</source>
        <translation type="unfinished">Config description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="186"/>
        <source>目录名</source>
        <translation type="unfinished">DIR name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="193"/>
        <source>普通配置</source>
        <translation type="unfinished">General config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="201"/>
        <source>目录</source>
        <translation type="unfinished">DIR</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::TypeOverviewModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_model.cpp" line="241"/>
        <source>类型</source>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_model.cpp" line="243"/>
        <source>键名</source>
        <translation type="unfinished">Key name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_model.cpp" line="245"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_model.cpp" line="247"/>
        <source>描述</source>
        <translation type="unfinished">Description</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::TypeOverviewWidget</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_widget.cpp" line="111"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_widget.cpp" line="136"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_widget.cpp" line="111"/>
        <source>请选择要删除的类型！</source>
        <translation type="unfinished">Please select the type to delete!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_widget.cpp" line="120"/>
        <source>删除该类型将会对已有的数据或类型造成影响，是否继续？
</source>
        <translation type="unfinished">Deleting this type will affect existing data or types. Do you want to continue? 
</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_widget.cpp" line="123"/>
        <source>
以下 【字段】 将会被删除：
</source>
        <translation type="unfinished">The following [fields] will be deleted:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_widget.cpp" line="130"/>
        <source>
以下 【数据节点】 将会被删除（仅展示 ID）：
</source>
        <translation type="unfinished">The following [data nodes] will be deleted (only IDs are displayed):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_widget.cpp" line="145"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_widget.cpp" line="145"/>
        <source>删除成功！</source>
        <translation type="unfinished">Deleted successfully!</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::WorkWidgetToolbar</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/work_widget_toolbar/work_widget_toolbar.cpp" line="136"/>
        <source>增加</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/work_widget_toolbar/work_widget_toolbar.cpp" line="138"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/work_widget_toolbar/work_widget_toolbar.cpp" line="140"/>
        <source>上移</source>
        <translation type="unfinished">Move up</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/work_widget_toolbar/work_widget_toolbar.cpp" line="142"/>
        <source>下移</source>
        <translation type="unfinished">Move down</translation>
    </message>
</context>
</TS>
