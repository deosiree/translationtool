<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="en_US">
<context>
    <name>QDeclarativeGeoMap</name>
    <message>
        <source>No Map</source>
        <translation />
    </message>
    <message>
        <source>Plugin does not support mapping.</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeGeoRouteModel</name>
    <message>
        <source>Plugin does not support routing.</source>
        <translation />
    </message>
    <message>
        <source>Cannot route, plugin not set.</source>
        <translation />
    </message>
    <message>
        <source>Cannot route, route manager not set.</source>
        <translation />
    </message>
    <message>
        <source>Cannot route, valid query not set.</source>
        <translation />
    </message>
    <message>
        <source>Not enough waypoints for routing.</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeGeocodeModel</name>
    <message>
        <source>Cannot geocode, plugin not set.</source>
        <translation />
    </message>
    <message>
        <source>Cannot geocode, geocode manager not set.</source>
        <translation />
    </message>
    <message>
        <source>Cannot geocode, valid query not set.</source>
        <translation />
    </message>
    <message>
        <source>Plugin does not support (reverse) geocoding.</source>
        <translation />
    </message>
</context>
<context>
    <name>QGeoServiceProviderFactoryMapbox</name>
    <message>
        <source>Mapbox plugin requires a 'mapbox.access_token' parameter.
Please visit https://www.mapbox.com</source>
        <translation />
    </message>
</context>
<context>
    <name>QGeoTileFetcherNokia</name>
    <message>
        <source>Mapping manager no longer exists</source>
        <translation />
    </message>
</context>
<context>
    <name>QGeoTiledMappingManagerEngineMapbox</name>
    <message>
        <source>Street</source>
        <extracomment>Noun describing map type 'Street map'</extracomment>
        <translation />
    </message>
    <message>
        <source>Light</source>
        <extracomment>Noun describing type of a map using light colors (weak contrast)</extracomment>
        <translation />
    </message>
    <message>
        <source>Dark</source>
        <extracomment>Noun describing type of a map using dark colors</extracomment>
        <translation />
    </message>
    <message>
        <source>Satellite</source>
        <extracomment>Noun describing type of a map created by satellite</extracomment>
        <translation />
    </message>
    <message>
        <source>Streets Satellite</source>
        <extracomment>Noun describing type of a street map created by satellite</extracomment>
        <translation />
    </message>
    <message>
        <source>Wheatpaste</source>
        <extracomment>Noun describing type of a map using wheat paste colors</extracomment>
        <translation />
    </message>
    <message>
        <source>Streets Basic</source>
        <extracomment>Noun describing type of a basic street map</extracomment>
        <translation />
    </message>
    <message>
        <source>Comic</source>
        <extracomment>Noun describing type of a map using cartoon-style fonts</extracomment>
        <translation />
    </message>
    <message>
        <source>Outdoors</source>
        <extracomment>Noun describing type of a map for outdoor activities</extracomment>
        <translation />
    </message>
    <message>
        <source>Run Bike Hike</source>
        <extracomment>Noun describing type of a map for sports</extracomment>
        <translation />
    </message>
    <message>
        <source>Pencil</source>
        <extracomment>Noun describing type of a map drawn by pencil</extracomment>
        <translation />
    </message>
    <message>
        <source>Pirates</source>
        <extracomment>Noun describing type of a treasure map with pirate boat watermark</extracomment>
        <translation />
    </message>
    <message>
        <source>Emerald</source>
        <extracomment>Noun describing type of a map using emerald colors</extracomment>
        <translation />
    </message>
    <message>
        <source>High Contrast</source>
        <extracomment>Noun describing type of a map with high contrast</extracomment>
        <translation />
    </message>
</context>
<context>
    <name>QGeoTiledMappingManagerEngineNokia</name>
    <message>
        <source>Street Map</source>
        <translation />
    </message>
    <message>
        <source>Normal map view in daylight mode</source>
        <translation />
    </message>
    <message>
        <source>Satellite Map</source>
        <translation />
    </message>
    <message>
        <source>Satellite map view in daylight mode</source>
        <translation />
    </message>
    <message>
        <source>Terrain Map</source>
        <translation />
    </message>
    <message>
        <source>Terrain map view in daylight mode</source>
        <translation />
    </message>
    <message>
        <source>Hybrid Map</source>
        <translation />
    </message>
    <message>
        <source>Satellite map view with streets in daylight mode</source>
        <translation />
    </message>
    <message>
        <source>Transit Map</source>
        <translation />
    </message>
    <message>
        <source>Color-reduced map view with public transport scheme in daylight mode</source>
        <translation />
    </message>
    <message>
        <source>Gray Street Map</source>
        <translation />
    </message>
    <message>
        <source>Color-reduced map view in daylight mode</source>
        <translation />
    </message>
    <message>
        <source>Mobile Street Map</source>
        <translation />
    </message>
    <message>
        <source>Mobile normal map view in daylight mode</source>
        <translation />
    </message>
    <message>
        <source>Mobile Terrain Map</source>
        <translation />
    </message>
    <message>
        <source>Mobile terrain map view in daylight mode</source>
        <translation />
    </message>
    <message>
        <source>Mobile Hybrid Map</source>
        <translation />
    </message>
    <message>
        <source>Mobile satellite map view with streets in daylight mode</source>
        <translation />
    </message>
    <message>
        <source>Mobile Transit Map</source>
        <translation />
    </message>
    <message>
        <source>Mobile color-reduced map view with public transport scheme in daylight mode</source>
        <translation />
    </message>
    <message>
        <source>Mobile Gray Street Map</source>
        <translation />
    </message>
    <message>
        <source>Mobile color-reduced map view in daylight mode</source>
        <translation />
    </message>
    <message>
        <source>Custom Street Map</source>
        <translation />
    </message>
    <message>
        <source>Night Street Map</source>
        <translation />
    </message>
    <message>
        <source>Normal map view in night mode</source>
        <translation />
    </message>
    <message>
        <source>Mobile Night Street Map</source>
        <translation />
    </message>
    <message>
        <source>Mobile normal map view in night mode</source>
        <translation />
    </message>
    <message>
        <source>Gray Night Street Map</source>
        <translation />
    </message>
    <message>
        <source>Color-reduced map view in night mode (especially used for background maps)</source>
        <translation />
    </message>
    <message>
        <source>Mobile Gray Night Street Map</source>
        <translation />
    </message>
    <message>
        <source>Mobile color-reduced map view in night mode (especially used for background maps)</source>
        <translation />
    </message>
    <message>
        <source>Pedestrian Street Map</source>
        <translation />
    </message>
    <message>
        <source>Pedestrian map view in daylight mode</source>
        <translation />
    </message>
    <message>
        <source>Mobile Pedestrian Street Map</source>
        <translation />
    </message>
    <message>
        <source>Mobile pedestrian map view in daylight mode for mobile usage</source>
        <translation />
    </message>
    <message>
        <source>Pedestrian Night Street Map</source>
        <translation />
    </message>
    <message>
        <source>Pedestrian map view in night mode</source>
        <translation />
    </message>
    <message>
        <source>Mobile Pedestrian Night Street Map</source>
        <translation />
    </message>
    <message>
        <source>Mobile pedestrian map view in night mode for mobile usage</source>
        <translation />
    </message>
    <message>
        <source>Car Navigation Map</source>
        <translation />
    </message>
    <message>
        <source>Normal map view in daylight mode for car navigation</source>
        <translation />
    </message>
</context>
<context>
    <name>QGeoTiledMappingManagerEngineOsm</name>
    <message>
        <source>Street Map</source>
        <translation />
    </message>
    <message>
        <source>Street map view in daylight mode</source>
        <translation />
    </message>
    <message>
        <source>Satellite Map</source>
        <translation />
    </message>
    <message>
        <source>Satellite map view in daylight mode</source>
        <translation />
    </message>
    <message>
        <source>Cycle Map</source>
        <translation />
    </message>
    <message>
        <source>Cycle map view in daylight mode</source>
        <translation />
    </message>
    <message>
        <source>Transit Map</source>
        <translation />
    </message>
    <message>
        <source>Public transit map view in daylight mode</source>
        <translation />
    </message>
    <message>
        <source>Night Transit Map</source>
        <translation />
    </message>
    <message>
        <source>Public transit map view in night mode</source>
        <translation />
    </message>
    <message>
        <source>Terrain Map</source>
        <translation />
    </message>
    <message>
        <source>Terrain map view</source>
        <translation />
    </message>
    <message>
        <source>Hiking Map</source>
        <translation />
    </message>
    <message>
        <source>Hiking map view</source>
        <translation />
    </message>
    <message>
        <source>Custom URL Map</source>
        <translation />
    </message>
    <message>
        <source>Custom url map view set via urlprefix parameter</source>
        <translation />
    </message>
</context>
<context>
    <name>QPlaceManagerEngineOsm</name>
    <message>
        <source>Aeroway</source>
        <translation />
    </message>
    <message>
        <source>Amenity</source>
        <translation />
    </message>
    <message>
        <source>Building</source>
        <translation />
    </message>
    <message>
        <source>Highway</source>
        <translation />
    </message>
    <message>
        <source>Historic</source>
        <translation />
    </message>
    <message>
        <source>Land use</source>
        <translation />
    </message>
    <message>
        <source>Leisure</source>
        <translation />
    </message>
    <message>
        <source>Man made</source>
        <translation />
    </message>
    <message>
        <source>Natural</source>
        <translation />
    </message>
    <message>
        <source>Place</source>
        <translation />
    </message>
    <message>
        <source>Railway</source>
        <translation />
    </message>
    <message>
        <source>Shop</source>
        <translation />
    </message>
    <message>
        <source>Tourism</source>
        <translation />
    </message>
    <message>
        <source>Waterway</source>
        <translation />
    </message>
    <message>
        <source>Network request error</source>
        <translation />
    </message>
</context>
<context>
    <name>QPlaceSearchReplyOsm</name>
    <message>
        <source>Response parse error</source>
        <translation />
    </message>
</context>
<context>
    <name>QtLocationQML</name>
    <message>
        <source>Plugin property is not set.</source>
        <translation />
    </message>
    <message>
        <source>Plugin Error (%1): %2</source>
        <translation />
    </message>
    <message>
        <source>Plugin Error (%1): Could not instantiate provider</source>
        <translation />
    </message>
    <message>
        <source>Plugin is not valid</source>
        <translation />
    </message>
    <message>
        <source>Unable to initialize categories</source>
        <translation />
    </message>
    <message>
        <source>Unable to create request</source>
        <translation />
    </message>
    <message>
        <source>Index '%1' out of range</source>
        <translation />
    </message>
    <message>
        <source>Qt Location requires apiKey parameter.
Please register at https://developer.here.com/ to get your personal application credentials.</source>
        <translation />
    </message>
    <message>
        <source>Saving places is not supported.</source>
        <translation />
    </message>
    <message>
        <source>Removing places is not supported.</source>
        <translation />
    </message>
    <message>
        <source>Saving categories is not supported.</source>
        <translation />
    </message>
    <message>
        <source>Removing categories is not supported.</source>
        <translation />
    </message>
    <message>
        <source>Error parsing response.</source>
        <translation />
    </message>
    <message>
        <source>Network error.</source>
        <translation />
    </message>
    <message>
        <source>Request was canceled.</source>
        <translation />
    </message>
    <message>
        <source>The response from the service was not in a recognizable format.</source>
        <translation />
    </message>
    <message>
        <source>Qt Location requires app_id and token parameters.
Please register at https://developer.here.com/ to get your personal application credentials.</source>
        <translation type="vanished" />
    </message>
</context>
<context>
    <name>QGeoRouteParserOsrmV5</name>
    <message>
        <source>North</source>
        <extracomment>Translations exist at https://github.com/Project-OSRM/osrm-text-instructions. Always used in "Head %1 [onto &lt;street name&gt;]"</extracomment>
        <translation />
    </message>
    <message>
        <source>East</source>
        <translation />
    </message>
    <message>
        <source>South</source>
        <translation />
    </message>
    <message>
        <source>West</source>
        <translation />
    </message>
    <message>
        <source>first</source>
        <comment>roundabout exit</comment>
        <extracomment>always used in " and take the %1 exit [onto &lt;street name&gt;]"</extracomment>
        <translation />
    </message>
    <message>
        <source>second</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>third</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>fourth</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>fifth</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>sixth</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>seventh</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>eighth</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>ninth</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>tenth</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>eleventh</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>twelfth</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>thirteenth</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>fourteenth</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>fifteenth</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>sixteenth</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>seventeenth</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>eighteenth</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>nineteenth</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source>twentieth</source>
        <comment>roundabout exit</comment>
        <translation />
    </message>
    <message>
        <source> and take the %1 exit</source>
        <extracomment>Always appended to one of the following strings: - "Enter the roundabout" - "Enter the rotary" - "Enter the rotary &lt;rotaryname&gt;"</extracomment>
        <translation />
    </message>
    <message>
        <source> and take the %1 exit onto %2</source>
        <translation />
    </message>
    <message>
        <source>You have arrived at your destination, straight ahead</source>
        <translation />
    </message>
    <message>
        <source>You have arrived at your destination, on the left</source>
        <translation />
    </message>
    <message>
        <source>You have arrived at your destination, on the right</source>
        <translation />
    </message>
    <message>
        <source>You have arrived at your destination</source>
        <translation />
    </message>
    <message>
        <source>Continue straight</source>
        <translation />
    </message>
    <message>
        <source>Continue straight on %1</source>
        <translation />
    </message>
    <message>
        <source>Continue left</source>
        <translation />
    </message>
    <message>
        <source>Continue left onto %1</source>
        <translation />
    </message>
    <message>
        <source>Continue slightly left</source>
        <translation />
    </message>
    <message>
        <source>Continue slightly left on %1</source>
        <translation />
    </message>
    <message>
        <source>Continue right</source>
        <translation />
    </message>
    <message>
        <source>Continue right onto %1</source>
        <translation />
    </message>
    <message>
        <source>Continue slightly right</source>
        <translation />
    </message>
    <message>
        <source>Continue slightly right on %1</source>
        <translation />
    </message>
    <message>
        <source>Make a U-turn</source>
        <translation />
    </message>
    <message>
        <source>Make a U-turn onto %1</source>
        <translation />
    </message>
    <message>
        <source>Continue</source>
        <translation />
    </message>
    <message>
        <source>Continue on %1</source>
        <translation />
    </message>
    <message>
        <source>Head %1</source>
        <extracomment>%1 is "North", "South", "East" or "West"</extracomment>
        <translation />
    </message>
    <message>
        <source>Head %1 onto %2</source>
        <translation />
    </message>
    <message>
        <source>Depart</source>
        <translation />
    </message>
    <message>
        <source>Depart onto %1</source>
        <translation />
    </message>
    <message>
        <source>At the end of the road, turn left</source>
        <translation />
    </message>
    <message>
        <source>At the end of the road, turn left onto %1</source>
        <translation />
    </message>
    <message>
        <source>At the end of the road, turn right</source>
        <translation />
    </message>
    <message>
        <source>At the end of the road, turn right onto %1</source>
        <translation />
    </message>
    <message>
        <source>At the end of the road, make a U-turn</source>
        <translation />
    </message>
    <message>
        <source>At the end of the road, make a U-turn onto %1</source>
        <translation />
    </message>
    <message>
        <source>At the end of the road, continue straight</source>
        <translation />
    </message>
    <message>
        <source>At the end of the road, continue straight onto %1</source>
        <translation />
    </message>
    <message>
        <source>At the end of the road, continue</source>
        <translation />
    </message>
    <message>
        <source>At the end of the road, continue onto %1</source>
        <translation />
    </message>
    <message>
        <source>Take the ferry</source>
        <translation />
    </message>
    <message>
        <source>At the fork, take a sharp left</source>
        <translation />
    </message>
    <message>
        <source>At the fork, take a sharp left onto %1</source>
        <translation />
    </message>
    <message>
        <source>At the fork, turn left</source>
        <translation />
    </message>
    <message>
        <source>At the fork, turn left onto %1</source>
        <translation />
    </message>
    <message>
        <source>At the fork, keep left</source>
        <translation />
    </message>
    <message>
        <source>At the fork, keep left onto %1</source>
        <translation />
    </message>
    <message>
        <source>At the fork, take a sharp right</source>
        <translation />
    </message>
    <message>
        <source>At the fork, take a sharp right onto %1</source>
        <translation />
    </message>
    <message>
        <source>At the fork, turn right</source>
        <translation />
    </message>
    <message>
        <source>At the fork, turn right onto %1</source>
        <translation />
    </message>
    <message>
        <source>At the fork, keep right</source>
        <translation />
    </message>
    <message>
        <source>At the fork, keep right onto %1</source>
        <translation />
    </message>
    <message>
        <source>At the fork, continue straight ahead</source>
        <translation />
    </message>
    <message>
        <source>At the fork, continue straight ahead onto %1</source>
        <translation />
    </message>
    <message>
        <source>At the fork, continue</source>
        <translation />
    </message>
    <message>
        <source>At the fork, continue onto %1</source>
        <translation />
    </message>
    <message>
        <source>Merge sharply left</source>
        <translation />
    </message>
    <message>
        <source>Merge sharply left onto %1</source>
        <translation />
    </message>
    <message>
        <source>Merge left</source>
        <translation />
    </message>
    <message>
        <source>Merge left onto %1</source>
        <translation />
    </message>
    <message>
        <source>Merge slightly left</source>
        <translation />
    </message>
    <message>
        <source>Merge slightly left on %1</source>
        <translation />
    </message>
    <message>
        <source>Merge sharply right</source>
        <translation />
    </message>
    <message>
        <source>Merge sharply right onto %1</source>
        <translation />
    </message>
    <message>
        <source>Merge right</source>
        <translation />
    </message>
    <message>
        <source>Merge right onto %1</source>
        <translation />
    </message>
    <message>
        <source>Merge slightly right</source>
        <translation />
    </message>
    <message>
        <source>Merge slightly right on %1</source>
        <translation />
    </message>
    <message>
        <source>Merge straight</source>
        <translation />
    </message>
    <message>
        <source>Merge straight on %1</source>
        <translation />
    </message>
    <message>
        <source>Merge</source>
        <translation />
    </message>
    <message>
        <source>Merge onto %1</source>
        <translation />
    </message>
    <message>
        <source>Take a sharp left</source>
        <translation />
    </message>
    <message>
        <source>Take a sharp left onto %1</source>
        <translation />
    </message>
    <message>
        <source>Turn left</source>
        <translation />
    </message>
    <message>
        <source>Turn left onto %1</source>
        <translation />
    </message>
    <message>
        <source>Continue slightly left onto %1</source>
        <translation />
    </message>
    <message>
        <source>Take a sharp right</source>
        <translation />
    </message>
    <message>
        <source>Take a sharp right onto %1</source>
        <translation />
    </message>
    <message>
        <source>Turn right</source>
        <translation />
    </message>
    <message>
        <source>Turn right onto %1</source>
        <translation />
    </message>
    <message>
        <source>Continue slightly right onto %1</source>
        <translation />
    </message>
    <message>
        <source>Continue straight onto %1</source>
        <translation />
    </message>
    <message>
        <source>Continue onto %1</source>
        <translation />
    </message>
    <message>
        <source>Continue on the left</source>
        <translation />
    </message>
    <message>
        <source>Continue on the left on %1</source>
        <translation />
    </message>
    <message>
        <source>Continue on the right</source>
        <translation />
    </message>
    <message>
        <source>Continue on the right on %1</source>
        <translation />
    </message>
    <message>
        <source>Take the ramp on the left</source>
        <translation />
    </message>
    <message>
        <source>Take the ramp on the left onto %1</source>
        <translation />
    </message>
    <message>
        <source>Take the ramp on the right</source>
        <translation />
    </message>
    <message>
        <source>Take the ramp on the right onto %1</source>
        <translation />
    </message>
    <message>
        <source>Take the ramp</source>
        <translation />
    </message>
    <message>
        <source>Take the ramp onto %1</source>
        <translation />
    </message>
    <message>
        <source>Get off the bike and push</source>
        <translation />
    </message>
    <message>
        <source>Get off the bike and push onto %1</source>
        <translation />
    </message>
    <message>
        <source>Enter the rotary</source>
        <extracomment>This string will be prepended to " and take the &lt;nth&gt; exit [onto &lt;streetname&gt;]</extracomment>
        <translation />
    </message>
    <message>
        <source>Enter the roundabout</source>
        <extracomment>This string will be prepended to " and take the &lt;nth&gt; exit [onto &lt;streetname&gt;]</extracomment>
        <translation />
    </message>
    <message>
        <source>At the roundabout, continue straight</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout, continue straight on %1</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout, turn left</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout, turn left onto %1</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout, turn right</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout, turn right onto %1</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout, turn around</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout, turn around onto %1</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout, continue</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout, continue onto %1</source>
        <translation />
    </message>
    <message>
        <source>Take the train</source>
        <translation />
    </message>
    <message>
        <source>Take the train [%1]</source>
        <translation />
    </message>
    <message>
        <source>Go straight</source>
        <translation />
    </message>
    <message>
        <source>Go straight onto %1</source>
        <translation />
    </message>
    <message>
        <source>Turn slightly left</source>
        <translation />
    </message>
    <message>
        <source>Turn slightly left onto %1</source>
        <translation />
    </message>
    <message>
        <source>Turn slightly right</source>
        <translation />
    </message>
    <message>
        <source>Turn slightly right onto %1</source>
        <translation />
    </message>
    <message>
        <source>Turn</source>
        <translation />
    </message>
    <message>
        <source>Turn onto %1</source>
        <translation />
    </message>
    <message>
        <source> and continue straight</source>
        <extracomment>This string will be prepended with lane instructions. E.g., "Use the left or the right lane and continue straight"</extracomment>
        <translation />
    </message>
    <message>
        <source> and continue straight onto %1</source>
        <translation />
    </message>
    <message>
        <source> and make a sharp left</source>
        <translation />
    </message>
    <message>
        <source> and make a sharp left onto %1</source>
        <translation />
    </message>
    <message>
        <source> and turn left</source>
        <translation />
    </message>
    <message>
        <source> and turn left onto %1</source>
        <translation />
    </message>
    <message>
        <source> and make a slight left</source>
        <translation />
    </message>
    <message>
        <source> and make a slight left onto %1</source>
        <translation />
    </message>
    <message>
        <source> and make a sharp right</source>
        <translation />
    </message>
    <message>
        <source> and make a sharp right onto %1</source>
        <translation />
    </message>
    <message>
        <source> and turn right</source>
        <translation />
    </message>
    <message>
        <source> and turn right onto %1</source>
        <translation />
    </message>
    <message>
        <source> and make a slight right</source>
        <translation />
    </message>
    <message>
        <source> and make a slight right onto %1</source>
        <translation />
    </message>
    <message>
        <source> and make a U-turn</source>
        <translation />
    </message>
    <message>
        <source> and make a U-turn onto %1</source>
        <translation />
    </message>
</context>
<context>
    <name>GeoServiceProviderFactoryEsri</name>
    <message>
        <source>Esri plugin requires a 'esri.token' parameter.
Please visit https://developers.arcgis.com/authentication/accessing-arcgis-online-services/</source>
        <translation />
    </message>
</context>
<context>
    <name>PlaceSearchReplyEsri</name>
    <message>
        <source>Response parse error</source>
        <translation />
    </message>
</context>
<context>
    <name>QGeoMappingManagerEngineItemsOverlay</name>
    <message>
        <source>Empty Map</source>
        <translation />
    </message>
</context>
<context>
    <name>QGeoCodeReplyMapbox</name>
    <message>
        <source>Response parse error</source>
        <translation />
    </message>
</context>
<context>
    <name>QPlaceSearchReplyMapbox</name>
    <message>
        <source>Response parse error</source>
        <translation />
    </message>
</context>
<context>
    <name>QPlaceSearchSuggestionReplyMapbox</name>
    <message>
        <source>Response parse error</source>
        <translation />
    </message>
</context>
<context>
    <name>QGeoMapMapboxGL</name>
    <message>
        <source>Development access token, do not use in production.</source>
        <translation />
    </message>
</context>
<context>
    <name>QGeoMappingManagerEngineMapboxGL</name>
    <message>
        <source>China Streets</source>
        <translation />
    </message>
    <message>
        <source>China Light</source>
        <translation />
    </message>
    <message>
        <source>China Dark</source>
        <translation />
    </message>
    <message>
        <source>Streets</source>
        <translation />
    </message>
    <message>
        <source>Basic</source>
        <translation />
    </message>
    <message>
        <source>Bright</source>
        <translation />
    </message>
    <message>
        <source>Outdoors</source>
        <translation />
    </message>
    <message>
        <source>Satellite</source>
        <translation />
    </message>
    <message>
        <source>Satellite Streets</source>
        <translation />
    </message>
    <message>
        <source>Light</source>
        <translation />
    </message>
    <message>
        <source>Dark</source>
        <translation />
    </message>
    <message>
        <source>Navigation Preview Day</source>
        <translation />
    </message>
    <message>
        <source>Navigation Preview Night</source>
        <translation />
    </message>
    <message>
        <source>Navigation Guidance Day</source>
        <translation />
    </message>
    <message>
        <source>Navigation Guidance Night</source>
        <translation />
    </message>
    <message>
        <source>User provided style</source>
        <translation />
    </message>
</context>
<context>
    <name>QGeoRouteParserOsrmV4</name>
    <message>
        <source>Go straight.</source>
        <translation />
    </message>
    <message>
        <source>Go straight onto %1.</source>
        <translation />
    </message>
    <message>
        <source>Turn slightly right.</source>
        <translation />
    </message>
    <message>
        <source>Turn slightly right onto %1.</source>
        <translation />
    </message>
    <message>
        <source>Turn right.</source>
        <translation />
    </message>
    <message>
        <source>Turn right onto %1.</source>
        <translation />
    </message>
    <message>
        <source>Make a sharp right.</source>
        <translation />
    </message>
    <message>
        <source>Make a sharp right onto %1.</source>
        <translation />
    </message>
    <message>
        <source>When it is safe to do so, perform a U-turn.</source>
        <translation />
    </message>
    <message>
        <source>Make a sharp left.</source>
        <translation />
    </message>
    <message>
        <source>Make a sharp left onto %1.</source>
        <translation />
    </message>
    <message>
        <source>Turn left.</source>
        <translation />
    </message>
    <message>
        <source>Turn left onto %1.</source>
        <translation />
    </message>
    <message>
        <source>Turn slightly left.</source>
        <translation />
    </message>
    <message>
        <source>Turn slightly left onto %1.</source>
        <translation />
    </message>
    <message>
        <source>Reached waypoint.</source>
        <translation />
    </message>
    <message>
        <source>Head on.</source>
        <translation />
    </message>
    <message>
        <source>Head onto %1.</source>
        <translation />
    </message>
    <message>
        <source>Enter the roundabout.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the first exit.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the first exit onto %1.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the second exit.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the second exit onto %1.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the third exit.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the third exit onto %1.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the fourth exit.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the fourth exit onto %1.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the fifth exit.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the fifth exit onto %1.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the sixth exit.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the sixth exit onto %1.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the seventh exit.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the seventh exit onto %1.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the eighth exit.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the eighth exit onto %1.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the ninth exit.</source>
        <translation />
    </message>
    <message>
        <source>At the roundabout take the ninth exit onto %1.</source>
        <translation />
    </message>
    <message>
        <source>Leave the roundabout.</source>
        <translation />
    </message>
    <message>
        <source>Leave the roundabout onto %1.</source>
        <translation />
    </message>
    <message>
        <source>Stay on the roundabout.</source>
        <translation />
    </message>
    <message>
        <source>Start at the end of the street.</source>
        <translation />
    </message>
    <message>
        <source>Start at the end of %1.</source>
        <translation />
    </message>
    <message>
        <source>You have reached your destination.</source>
        <translation />
    </message>
    <message>
        <source>Don't know what to say for '%1'</source>
        <translation />
    </message>
</context>
</TS>