<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CurveConfigWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="81"/>
        <source>基本属性</source>
        <translation type="unfinished">Atributos Básicos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="126"/>
        <source>线色：</source>
        <translation type="unfinished">Color de línea:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="130"/>
        <source>单位:</source>
        <translation type="unfinished">Unidad:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="132"/>
        <source>请输入单位</source>
        <translation type="unfinished">Ingrese la unidad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="148"/>
        <source>小数点精度：</source>
        <translation type="unfinished">Precisión del punto decimal:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="153"/>
        <source>线宽：</source>
        <translation type="unfinished">Ancho de línea:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="169"/>
        <source>数据点形状：</source>
        <translation type="unfinished">Forma del punto de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="73"/>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="172"/>
        <source>空心圆</source>
        <translation type="unfinished">Círculo hueco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="74"/>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="172"/>
        <source>实心圆</source>
        <translation type="unfinished">Círculo sólido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="75"/>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="172"/>
        <source>正方形</source>
        <translation type="unfinished">Cuadrado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="76"/>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="172"/>
        <source>三角形</source>
        <translation type="unfinished">Triángulo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="183"/>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="264"/>
        <source>显示数据点</source>
        <translation type="unfinished">Mostrar puntos de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="212"/>
        <source>今日曲线</source>
        <translation type="unfinished">Curva de hoy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="217"/>
        <source>昨日曲线</source>
        <translation type="unfinished">Curva de ayer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="222"/>
        <source>历史日曲线</source>
        <translation type="unfinished">Curva diaria histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="227"/>
        <source>当月曲线</source>
        <translation type="unfinished">Curva mensual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="232"/>
        <source>历史月曲线</source>
        <translation type="unfinished">Curva histórica mensual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="237"/>
        <source>时曲线</source>
        <translation type="unfinished">Curva por hora</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="242"/>
        <source>历史时曲线</source>
        <translation type="unfinished">Curva histórica por hora</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="247"/>
        <source>周曲线</source>
        <translation type="unfinished">Curva semanal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="252"/>
        <source>历史周曲线</source>
        <translation type="unfinished">Curva histórica semanal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="263"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="263"/>
        <source>线色</source>
        <translation type="unfinished">Color de línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="263"/>
        <source>单位</source>
        <translation type="unfinished">Unidad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="263"/>
        <source>小数点精度</source>
        <translation type="unfinished">Precisión del punto decimal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="263"/>
        <source>线宽</source>
        <translation type="unfinished">Ancho de línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="263"/>
        <source>基本点形状</source>
        <translation type="unfinished">Forma básica del punto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="341"/>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="507"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="341"/>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="507"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
</context>
<context>
    <name>CurveGrpAttribConfig</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="129"/>
        <source>左边距:</source>
        <translation type="unfinished">Margen izquierdo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="132"/>
        <source>下边距:</source>
        <translation type="unfinished">Margen inferior:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="147"/>
        <source>背景颜色:</source>
        <translation type="unfinished">BG color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="154"/>
        <source>阈值颜色:</source>
        <translation type="unfinished">Color del umbral:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="168"/>
        <source>阈值上限:</source>
        <translation type="unfinished">Umbral superior:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="172"/>
        <source>阈值下限:</source>
        <translation type="unfinished">Umbral inferior:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="212"/>
        <source>展示形式:</source>
        <translation type="unfinished">Formato de visualización:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="216"/>
        <source>点</source>
        <translation type="unfinished">Punto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="216"/>
        <source>线</source>
        <translation type="unfinished">Línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="216"/>
        <source>向下填充</source>
        <translation type="unfinished">Rellenar hacia abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="236"/>
        <source>平滑曲线</source>
        <translation type="unfinished">Curva suave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="239"/>
        <source>曲线详情</source>
        <translation type="unfinished">Detalles de la curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="242"/>
        <source>显示阈值</source>
        <translation type="unfinished">Umbral de visualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="246"/>
        <source>漏点断开</source>
        <translation type="unfinished">Ruptura de fuga</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="250"/>
        <source>绝对值曲线</source>
        <translation type="unfinished">Curva de valor absoluto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="280"/>
        <source>标题栏</source>
        <translation type="unfinished">Barra de título</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="281"/>
        <source>网格</source>
        <translation type="unfinished">Cuadrícula</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="282"/>
        <source>图例</source>
        <translation type="unfinished">Leyenda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="283"/>
        <source>游标</source>
        <translation type="unfinished">Cursor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curvegrp_attrib_config.cpp" line="284"/>
        <source>坐标轴</source>
        <translation type="unfinished">Eje de Coordenadas</translation>
    </message>
</context>
<context>
    <name>CurveViewerConfigDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curve_viewer_config_dlg.cpp" line="56"/>
        <source>曲线组属性</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Atributos del Grupo de Curvas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/curve_viewer_config_dlg.cpp" line="57"/>
        <source>曲线属性</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Propiedades de la Curva</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="336"/>
        <location filename="../../../../src/plat/gui/api/graphic_today_curve_setting/src/cmy_curve_definition.cpp" line="500"/>
        <source>未知(%1)</source>
        <translation type="unfinished">Desconocido (%1)</translation>
    </message>
</context>
</TS>
