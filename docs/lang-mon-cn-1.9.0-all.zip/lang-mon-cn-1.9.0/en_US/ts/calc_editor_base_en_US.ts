<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CalcEditorImpl</name>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.ui" line="34"/>
        <source>公式名称:</source>
        <translation type="unfinished">Formula name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.ui" line="44"/>
        <source>目标路径:</source>
        <translation type="unfinished">Dest path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.ui" line="54"/>
        <source>检索</source>
        <translation type="unfinished">Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.ui" line="72"/>
        <source>因子列表</source>
        <translation type="unfinished">Factor List</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.ui" line="91"/>
        <source>表达式</source>
        <translation type="unfinished">Expression</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.ui" line="99"/>
        <source>快捷函数</source>
        <translation type="unfinished">Quick Functions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.ui" line="125"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.ui" line="132"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
</context>
<context>
    <name>CalcFactorModel</name>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="388"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="409"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="436"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="459"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="388"/>
        <source>数据类型不匹配,目标类型为bool</source>
        <translation type="unfinished">Data type mismatch, destination type is bool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="409"/>
        <source>数据类型不匹配,目标类型为double</source>
        <translation type="unfinished">Data type mismatch, destination type is double</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="436"/>
        <source>数据类型不匹配,目标类型为long long</source>
        <translation type="unfinished">Data type mismatch, destination type is long long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="459"/>
        <source>数据类型不匹配,目标类型为无符号</source>
        <translation type="unfinished">Data type mismatch, destination type is unsigned</translation>
    </message>
</context>
<context>
    <name>CalcFormulaEditor</name>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="72"/>
        <source>快捷函数：</source>
        <translation type="unfinished">Quick function:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="177"/>
        <source>试算</source>
        <translation type="unfinished">Trial calculation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="192"/>
        <source>基本操作</source>
        <translation type="unfinished">Basic</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="201"/>
        <source>(</source>
        <translation type="unfinished">(</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="211"/>
        <source>)</source>
        <translation type="unfinished">)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="221"/>
        <source>==</source>
        <translation type="unfinished">==</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="231"/>
        <source>!=</source>
        <translation type="unfinished">!=</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="241"/>
        <source>&gt;</source>
        <translation type="unfinished">&gt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="251"/>
        <source>&lt;</source>
        <translation type="unfinished">&lt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="261"/>
        <source>&gt;=</source>
        <translation type="unfinished">&gt;=</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="271"/>
        <source>&lt;=</source>
        <translation type="unfinished">&lt;=</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="281"/>
        <source>AND</source>
        <translation type="unfinished">AND</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="291"/>
        <source>OR</source>
        <translation type="unfinished">OR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="301"/>
        <source>NOT</source>
        <translation type="unfinished">NOT</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="311"/>
        <source>%</source>
        <translation type="unfinished">%</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="321"/>
        <source>+</source>
        <translation type="unfinished">+</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="331"/>
        <source>-</source>
        <translation type="unfinished">-</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="341"/>
        <source>×</source>
        <translation type="unfinished">×</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="351"/>
        <source>÷</source>
        <translation type="unfinished">÷</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="368"/>
        <source>IF用例</source>
        <translation type="unfinished">IF case</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="376"/>
        <source>高级操作</source>
        <translation type="unfinished">Advanced</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="384"/>
        <source>类型：</source>
        <translation type="unfinished">Type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="400"/>
        <source>说明</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="408"/>
        <source>计算引擎内部支持的函数说明</source>
        <translation type="unfinished">Description of functions supported internally by the computing engine</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="236"/>
        <source>函数名</source>
        <translation type="unfinished">Function name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="236"/>
        <source>函数说明</source>
        <translation type="unfinished">Function Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="236"/>
        <source>示例</source>
        <translation type="unfinished">Example</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="255"/>
        <source>浮点数x向下取整</source>
        <translation type="unfinished">Floating point number x rounded down</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="259"/>
        <source>浮点数x向上取整</source>
        <translation type="unfinished">Floating point number x rounded up</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="263"/>
        <source>浮点数x四舍五入</source>
        <translation type="unfinished">Floating point number x rounded to the nearest integer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="396"/>
        <source>单点全与等于0</source>
        <translation type="unfinished">Single-point all-AND equals 0</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="397"/>
        <source>单点全与等于1</source>
        <translation type="unfinished">Single-point all-AND equals 1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="398"/>
        <source>单点全或等于0</source>
        <translation type="unfinished">Single-point all-OR equals 0</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="399"/>
        <source>单点全或等于1</source>
        <translation type="unfinished">Single-point all-OR equals 1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="59"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="323"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="177"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="256"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="284"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="296"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="349"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="424"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="59"/>
        <source>是否清除公式?</source>
        <translation type="unfinished">Are you sure to clear the formula?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="76"/>
        <source>括号个数不匹配!</source>
        <translation type="unfinished">The number of brackets does not match!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="252"/>
        <source>计算失败</source>
        <translation type="unfinished">Calculation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="254"/>
        <source>试算失败:%1,注意检查公式</source>
        <translation type="unfinished">Trial failure: %1, check the formula</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="260"/>
        <source>公式不合法</source>
        <translation type="unfinished">Formula is illegal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="264"/>
        <source>公式不合法:%1</source>
        <translation type="unfinished">The formula is illegal: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="246"/>
        <source>表达式无效! : %1</source>
        <translation type="unfinished">The expression is invalid! : %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="253"/>
        <source>保存失败，表达式为空</source>
        <translation type="unfinished">Save failed, expression is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="324"/>
        <source>因子[%1]未在公式中使用!</source>
        <translation type="unfinished">Factor [%1] not used in the formula!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="289"/>
        <source>因子[%1]在因子列表中未找到!</source>
        <translation type="unfinished">Factor [%1] not found in factor list!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="42"/>
        <source>因子</source>
        <translation type="unfinished">Factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="44"/>
        <source>因子路径</source>
        <translation type="unfinished">Factor path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="46"/>
        <source>因子值描述</source>
        <translation type="unfinished">Factor value description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="48"/>
        <source>因子值</source>
        <translation type="unfinished">Factor value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="50"/>
        <source>按单点计算</source>
        <translation type="unfinished">Compute by point</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="76"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="254"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="264"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="246"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="253"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="288"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="188"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="235"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="285"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="325"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="526"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="543"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="189"/>
        <source>因子[%1]已存在,不再添加</source>
        <translation type="unfinished">Factor [%1] already exists and will not be added again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="235"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="285"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="326"/>
        <source>因子已存在:%1</source>
        <translation type="unfinished">Factor already exists: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="136"/>
        <source>增加因子</source>
        <translation type="unfinished">Increase Factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="172"/>
        <source>删除因子</source>
        <translation type="unfinished">Delete Factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="177"/>
        <source>确定删除选中的因子吗？</source>
        <translation type="unfinished">Are you sure to delete the selected factors?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="193"/>
        <source>修改因子</source>
        <translation type="unfinished">Edit factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="219"/>
        <source>编辑因子</source>
        <translation type="unfinished">Edit factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="246"/>
        <source>查看关联计算目标</source>
        <translation type="unfinished">View linked calculation destinations</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="256"/>
        <source>没有计算目标</source>
        <translation type="unfinished">No calculated destination</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="264"/>
        <source>计算目标</source>
        <translation type="unfinished">Calculation destination</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="271"/>
        <source>查看嵌套计算目标</source>
        <translation type="unfinished">View nested compute destinations</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="284"/>
        <source>存在多个相同计算目标</source>
        <translation type="unfinished">Multiple identical compute destinations</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="296"/>
        <source>没有嵌套目标</source>
        <translation type="unfinished">No nested destinations</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="300"/>
        <source>嵌套目标</source>
        <translation type="unfinished">Nested dest</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="185"/>
        <source>加</source>
        <translation type="unfinished">Plus</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="186"/>
        <source>减</source>
        <translation type="unfinished">Minus</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="187"/>
        <source>乘</source>
        <translation type="unfinished">Multiply</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="188"/>
        <source>除</source>
        <translation type="unfinished">Divide</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="189"/>
        <source>取模</source>
        <translation type="unfinished">Take mold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="190"/>
        <source>等于</source>
        <translation type="unfinished">Equal to</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="191"/>
        <source>不等于</source>
        <translation type="unfinished">Not equal to</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="192"/>
        <source>小于</source>
        <translation type="unfinished">Less than</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="193"/>
        <source>小于等于</source>
        <translation type="unfinished">Less than or equal to</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="194"/>
        <source>大于</source>
        <translation type="unfinished">Greater than</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="195"/>
        <source>大于等于</source>
        <translation type="unfinished">Greater than or equal to</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="196"/>
        <source>逻辑与</source>
        <translation type="unfinished">AND</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="197"/>
        <source>逻辑或</source>
        <translation type="unfinished">OR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="198"/>
        <source>逻辑非</source>
        <translation type="unfinished">NOT</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="199"/>
        <source>清空</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="269"/>
        <source>常量</source>
        <translation type="unfinished">Constant</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="270"/>
        <source>位运算</source>
        <translation type="unfinished">Bit operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="271"/>
        <source>生成表达式</source>
        <translation type="unfinished">Gen expression</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="349"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="425"/>
        <source>是否清空当前公式?</source>
        <translation type="unfinished">Whether to clear the current formula?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="371"/>
        <source>真</source>
        <translation type="unfinished">True</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="372"/>
        <source>假</source>
        <translation type="unfinished">False</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="373"/>
        <source>年</source>
        <translation type="unfinished">Year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="374"/>
        <source>月</source>
        <translation type="unfinished">Month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="375"/>
        <source>日</source>
        <translation type="unfinished">Day</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="376"/>
        <source>时</source>
        <translation type="unfinished">Hour</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="377"/>
        <source>分</source>
        <translation type="unfinished">Minute</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="378"/>
        <source>秒</source>
        <translation type="unfinished">sec</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="379"/>
        <source>π</source>
        <translation type="unfinished">π</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="384"/>
        <source>右移</source>
        <translation type="unfinished">Right shift</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="385"/>
        <source>左移</source>
        <translation type="unfinished">Left shift</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="386"/>
        <source>异或</source>
        <translation type="unfinished">XOR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="387"/>
        <source>按位与</source>
        <translation type="unfinished">Bitwise and</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="388"/>
        <source>按位或</source>
        <translation type="unfinished">Bitwise or</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="389"/>
        <source>按位非</source>
        <translation type="unfinished">Bitwise non</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="393"/>
        <source>生成求和表达式</source>
        <translation type="unfinished">Gen SUM expression</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="394"/>
        <source>生成与表达式</source>
        <translation type="unfinished">Generation AND expression</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="395"/>
        <source>生成或表达式</source>
        <translation type="unfinished">Gen OR expression</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="396"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="397"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="398"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="399"/>
        <source>例:%1</source>
        <translation type="unfinished">Example: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="526"/>
        <source>参数的个数和函数所需参数个数不匹配!</source>
        <translation type="unfinished">The number of params does not match the number of params required by the function!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="543"/>
        <source>函数参数[%1]类型不符合输入要求!</source>
        <translation type="unfinished">The function param [%1] type does not meet the input requirements!</translation>
    </message>
</context>
<context>
    <name>iasp::calc::CalcEditorImpl</name>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="279"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="314"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="281"/>
        <source>部分因子在因子列表中未找到!</source>
        <translation type="unfinished">Some factors were not found in the factor list!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="316"/>
        <source>部分因子未在公式中使用!</source>
        <translation type="unfinished">Some factors are not used in the formula!</translation>
    </message>
</context>
</TS>
