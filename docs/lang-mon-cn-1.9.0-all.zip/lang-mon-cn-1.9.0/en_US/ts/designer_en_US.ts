<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="en_US">
<context>
    <name>AbstractFindWidget</name>
    <message>
        <source>&amp;Previous</source>
        <translation />
    </message>
    <message>
        <source>&amp;Next</source>
        <translation />
    </message>
    <message>
        <source>&amp;Case sensitive</source>
        <translation />
    </message>
    <message>
        <source>Whole &amp;words</source>
        <translation />
    </message>
    <message>
        <source>&lt;img src=":/qt-project.org/shared/images/wrap.png"&gt;&amp;nbsp;Search wrapped</source>
        <translation />
    </message>
    <message>
        <source>&amp;Find in Text...</source>
        <translation />
    </message>
</context>
<context>
    <name>AbstractItemEditor</name>
    <message>
        <source>Selectable</source>
        <translation />
    </message>
    <message>
        <source>Editable</source>
        <translation />
    </message>
    <message>
        <source>DragEnabled</source>
        <translation />
    </message>
    <message>
        <source>DropEnabled</source>
        <translation />
    </message>
    <message>
        <source>UserCheckable</source>
        <translation />
    </message>
    <message>
        <source>Enabled</source>
        <translation />
    </message>
    <message>
        <source>Tristate</source>
        <translation />
    </message>
    <message>
        <source>Unchecked</source>
        <translation />
    </message>
    <message>
        <source>PartiallyChecked</source>
        <translation />
    </message>
    <message>
        <source>Checked</source>
        <translation />
    </message>
</context>
<context>
    <name>AddLinkDialog</name>
    <message>
        <source>Insert Link</source>
        <translation />
    </message>
    <message>
        <source>Title:</source>
        <translation />
    </message>
    <message>
        <source>URL:</source>
        <translation />
    </message>
</context>
<context>
    <name>AppFontDialog</name>
    <message>
        <source>Additional Fonts</source>
        <translation />
    </message>
</context>
<context>
    <name>AppFontManager</name>
    <message>
        <source>'%1' is not a file.</source>
        <translation />
    </message>
    <message>
        <source>The font file '%1' does not have read permissions.</source>
        <translation />
    </message>
    <message>
        <source>The font file '%1' is already loaded.</source>
        <translation />
    </message>
    <message>
        <source>The font file '%1' could not be loaded.</source>
        <translation />
    </message>
    <message>
        <source>'%1' is not a valid font id.</source>
        <translation />
    </message>
    <message>
        <source>There is no loaded font matching the id '%1'.</source>
        <translation />
    </message>
    <message>
        <source>The font '%1' (%2) could not be unloaded.</source>
        <translation />
    </message>
</context>
<context>
    <name>AppFontWidget</name>
    <message>
        <source>Fonts</source>
        <translation />
    </message>
    <message>
        <source>Add font files</source>
        <translation />
    </message>
    <message>
        <source>Remove current font file</source>
        <translation />
    </message>
    <message>
        <source>Remove all font files</source>
        <translation />
    </message>
    <message>
        <source>Add Font Files</source>
        <translation />
    </message>
    <message>
        <source>Font files (*.ttf)</source>
        <translation />
    </message>
    <message>
        <source>Error Adding Fonts</source>
        <translation />
    </message>
    <message>
        <source>Error Removing Fonts</source>
        <translation />
    </message>
    <message>
        <source>Remove Fonts</source>
        <translation />
    </message>
    <message>
        <source>Would you like to remove all fonts?</source>
        <translation />
    </message>
</context>
<context>
    <name>AppearanceOptionsWidget</name>
    <message>
        <source>Form</source>
        <translation />
    </message>
    <message>
        <source>User Interface Mode</source>
        <translation />
    </message>
</context>
<context>
    <name>AssistantClient</name>
    <message>
        <source>Unable to send request: Assistant is not responding.</source>
        <translation />
    </message>
    <message>
        <source>The binary '%1' does not exist.</source>
        <translation />
    </message>
    <message>
        <source>Unable to launch assistant (%1).</source>
        <translation />
    </message>
</context>
<context>
    <name>BrushPropertyManager</name>
    <message>
        <source>Style</source>
        <translation />
    </message>
    <message>
        <source>No brush</source>
        <translation />
    </message>
    <message>
        <source>Solid</source>
        <translation />
    </message>
    <message>
        <source>Dense 1</source>
        <translation />
    </message>
    <message>
        <source>Dense 2</source>
        <translation />
    </message>
    <message>
        <source>Dense 3</source>
        <translation />
    </message>
    <message>
        <source>Dense 4</source>
        <translation />
    </message>
    <message>
        <source>Dense 5</source>
        <translation />
    </message>
    <message>
        <source>Dense 6</source>
        <translation />
    </message>
    <message>
        <source>Dense 7</source>
        <translation />
    </message>
    <message>
        <source>Horizontal</source>
        <translation />
    </message>
    <message>
        <source>Vertical</source>
        <translation />
    </message>
    <message>
        <source>Cross</source>
        <translation />
    </message>
    <message>
        <source>Backward diagonal</source>
        <translation />
    </message>
    <message>
        <source>Forward diagonal</source>
        <translation />
    </message>
    <message>
        <source>Crossing diagonal</source>
        <translation />
    </message>
    <message>
        <source>Color</source>
        <translation />
    </message>
    <message>
        <source>[%1, %2]</source>
        <translation />
    </message>
</context>
<context>
    <name>Command</name>
    <message>
        <source>Change signal</source>
        <translation />
    </message>
    <message>
        <source>Change slot</source>
        <translation />
    </message>
    <message>
        <source>Change signal-slot connection</source>
        <translation />
    </message>
    <message>
        <source>Change sender</source>
        <translation />
    </message>
    <message>
        <source>Change receiver</source>
        <translation />
    </message>
    <message>
        <source>Add connection</source>
        <translation />
    </message>
    <message>
        <source>Adjust connection</source>
        <translation />
    </message>
    <message>
        <source>Delete connections</source>
        <translation />
    </message>
    <message>
        <source>Change source</source>
        <translation />
    </message>
    <message>
        <source>Change target</source>
        <translation />
    </message>
    <message>
        <source>Insert '%1'</source>
        <translation />
    </message>
    <message>
        <source>Raise '%1'</source>
        <translation />
    </message>
    <message>
        <source>Lower '%1'</source>
        <translation />
    </message>
    <message>
        <source>Delete '%1'</source>
        <translation />
    </message>
    <message>
        <source>Reparent '%1'</source>
        <translation />
    </message>
    <message>
        <source>Promote to custom widget</source>
        <translation />
    </message>
    <message>
        <source>Demote from custom widget</source>
        <translation />
    </message>
    <message>
        <source>Lay out using grid</source>
        <translation />
    </message>
    <message>
        <source>Lay out vertically</source>
        <translation />
    </message>
    <message>
        <source>Lay out horizontally</source>
        <translation />
    </message>
    <message>
        <source>Break layout</source>
        <translation />
    </message>
    <message>
        <source>Move Page</source>
        <translation />
    </message>
    <message>
        <source>Delete Page</source>
        <translation />
    </message>
    <message>
        <source>Page</source>
        <translation />
    </message>
    <message>
        <source>Insert Page</source>
        <translation />
    </message>
    <message>
        <source>Change Tab order</source>
        <translation />
    </message>
    <message>
        <source>Create Menu Bar</source>
        <translation />
    </message>
    <message>
        <source>Delete Menu Bar</source>
        <translation />
    </message>
    <message>
        <source>Create Status Bar</source>
        <translation />
    </message>
    <message>
        <source>Delete Status Bar</source>
        <translation />
    </message>
    <message>
        <source>Add Tool Bar</source>
        <translation />
    </message>
    <message>
        <source>Add Dock Window</source>
        <translation />
    </message>
    <message>
        <source>Adjust Size of '%1'</source>
        <translation />
    </message>
    <message>
        <source>Change Form Layout Item Geometry</source>
        <translation />
    </message>
    <message>
        <source>Change Layout Item Geometry</source>
        <translation />
    </message>
    <message>
        <source>Change Table Contents</source>
        <translation />
    </message>
    <message>
        <source>Change Tree Contents</source>
        <translation />
    </message>
    <message>
        <source>Add action</source>
        <translation />
    </message>
    <message>
        <source>Remove action</source>
        <translation />
    </message>
    <message>
        <source>Add menu</source>
        <translation />
    </message>
    <message>
        <source>Remove menu</source>
        <translation />
    </message>
    <message>
        <source>Create submenu</source>
        <translation />
    </message>
    <message>
        <source>Delete Tool Bar</source>
        <translation />
    </message>
    <message>
        <source>Set action text</source>
        <translation />
    </message>
    <message>
        <source>Insert action</source>
        <translation />
    </message>
    <message>
        <source>Move action</source>
        <translation />
    </message>
    <message>
        <source>Change Title</source>
        <translation />
    </message>
    <message>
        <source>Insert Menu</source>
        <translation />
    </message>
    <message>
        <source>Change signals/slots</source>
        <translation />
    </message>
    <message>
        <source>Delete Subwindow</source>
        <translation />
    </message>
    <message>
        <source>Insert Subwindow</source>
        <translation />
    </message>
    <message>
        <source>Subwindow</source>
        <translation />
    </message>
    <message>
        <source>Change Z-order of '%1'</source>
        <translation />
    </message>
    <message>
        <source>Simplify Grid Layout</source>
        <translation />
    </message>
    <message>
        <source>Create button group</source>
        <translation />
    </message>
    <message>
        <source>Break button group</source>
        <translation />
    </message>
    <message>
        <source>Break button group '%1'</source>
        <translation />
    </message>
    <message>
        <source>Add buttons to group</source>
        <translation />
    </message>
    <message>
        <source>Remove buttons from group</source>
        <translation />
    </message>
    <message>
        <source>Morph %1/'%2' into %3</source>
        <extracomment>MorphWidgetCommand description</extracomment>
        <translation />
    </message>
    <message>
        <source>Change layout of '%1' from %2 to %3</source>
        <translation />
    </message>
    <message>
        <source>Change layout alignment</source>
        <translation />
    </message>
    <message>
        <source>Add '%1' to '%2'</source>
        <extracomment>Command description for adding buttons to a QButtonGroup</extracomment>
        <translation />
    </message>
    <message>
        <source>Remove '%1' from '%2'</source>
        <extracomment>Command description for removing buttons from a QButtonGroup</extracomment>
        <translation />
    </message>
    <message>
        <source>Changed '%1' of '%2'</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>Changed '%1' of %n objects</source>
        <translatorcomment>Singular will never be shown</translatorcomment>
        <translation><numerusform>Eigenschaft '%1' eines Objekts geändert</numerusform>
            <numerusform>Eigenschaft '%1' von %n Objekten geändert</numerusform>
        </translation>
    </message>
    <message>
        <source>Reset '%1' of '%2'</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>Reset '%1' of %n objects</source>
        <translatorcomment>Singular will never be shown</translatorcomment>
        <translation><numerusform>'%1' eines Objekts zurücksetzen</numerusform>
            <numerusform>'%1' von %n Objekten zurücksetzen</numerusform>
        </translation>
    </message>
    <message>
        <source>Add dynamic property '%1' to '%2'</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>Add dynamic property '%1' to %n objects</source>
        <translatorcomment>Singular will never be shown</translatorcomment>
        <translation><numerusform>Dynamische Eigenschaft '%1' zu einem Objekt hinzufügen</numerusform>
            <numerusform>Dynamische Eigenschaft '%1' zu %n Objekten hinzufügen</numerusform>
        </translation>
    </message>
    <message>
        <source>Remove dynamic property '%1' from '%2'</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>Remove dynamic property '%1' from %n objects</source>
        <translation><numerusform>Dynamische Eigenschaft '%1' des Objektes entfernen</numerusform>
            <numerusform>Dynamische Eigenschaft '%1' von %n Objekten entfernen</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>ConnectDialog</name>
    <message>
        <source>Configure Connection</source>
        <translation />
    </message>
    <message>
        <source>GroupBox</source>
        <translation />
    </message>
    <message>
        <source>Edit...</source>
        <translation />
    </message>
    <message>
        <source>Show signals and slots inherited from QWidget</source>
        <translation />
    </message>
</context>
<context>
    <name>ConnectionDelegate</name>
    <message>
        <source>&lt;object&gt;</source>
        <translation />
    </message>
    <message>
        <source>&lt;signal&gt;</source>
        <translation />
    </message>
    <message>
        <source>&lt;slot&gt;</source>
        <translation />
    </message>
</context>
<context>
    <name>DPI_Chooser</name>
    <message>
        <source>Standard (96 x 96)</source>
        <extracomment>Embedded device standard screen resolution</extracomment>
        <translation />
    </message>
    <message>
        <source>Greenphone (179 x 185)</source>
        <extracomment>Embedded device screen resolution</extracomment>
        <translation />
    </message>
    <message>
        <source>High (192 x 192)</source>
        <extracomment>Embedded device high definition screen resolution</extracomment>
        <translation />
    </message>
</context>
<context>
    <name>Designer</name>
    <message>
        <source>Qt Widgets Designer</source>
        <translation />
    </message>
    <message>
        <source>%1 does not exist.</source>
        <translation />
    </message>
    <message>
        <source>Unable to launch %1: %2</source>
        <translation />
    </message>
    <message>
        <source>%1 timed out.</source>
        <translation />
    </message>
    <message>
        <source>This file cannot be read because the extra info extension failed to load.</source>
        <translation />
    </message>
    <message>
        <source>Custom Widgets</source>
        <translation />
    </message>
    <message>
        <source>Promoted Widgets</source>
        <translation />
    </message>
</context>
<context>
    <name>DesignerMetaEnum</name>
    <message>
        <source>%1 is not a valid enumeration value of '%2'.</source>
        <translation />
    </message>
    <message>
        <source>'%1' could not be converted to an enumeration value of type '%2'.</source>
        <translation />
    </message>
</context>
<context>
    <name>DesignerMetaFlags</name>
    <message>
        <source>'%1' could not be converted to a flag value of type '%2'.</source>
        <translation />
    </message>
</context>
<context>
    <name>DeviceProfile</name>
    <message>
        <source>'%1' is not a number.</source>
        <extracomment>Reading a number for an embedded device profile</extracomment>
        <translation />
    </message>
    <message>
        <source>An invalid tag &lt;%1&gt; was encountered.</source>
        <translation />
    </message>
</context>
<context>
    <name>DeviceProfileDialog</name>
    <message>
        <source>&amp;Family</source>
        <translation />
    </message>
    <message>
        <source>&amp;Point Size</source>
        <translation />
    </message>
    <message>
        <source>Style</source>
        <translation />
    </message>
    <message>
        <source>Device DPI</source>
        <translation />
    </message>
    <message>
        <source>Name</source>
        <translation />
    </message>
</context>
<context>
    <name>DeviceSkin</name>
    <message>
        <source>The image file '%1' could not be loaded.</source>
        <translation />
    </message>
    <message>
        <source>The skin directory '%1' does not contain a configuration file.</source>
        <translation />
    </message>
    <message>
        <source>The skin configuration file '%1' could not be opened.</source>
        <translation />
    </message>
    <message>
        <source>Syntax error: %1</source>
        <translation />
    </message>
    <message>
        <source>The skin cursor image file '%1' does not exist.</source>
        <translation />
    </message>
    <message>
        <source>Syntax error in area definition: %1</source>
        <translation />
    </message>
    <message>
        <source>Mismatch in number of areas, expected %1, got %2.</source>
        <translation />
    </message>
    <message>
        <source>The skin configuration file '%1' could not be read: %2</source>
        <translation />
    </message>
    <message>
        <source>The skin "up" image file '%1' does not exist.</source>
        <translation />
    </message>
    <message>
        <source>The skin "down" image file '%1' does not exist.</source>
        <translation />
    </message>
    <message>
        <source>The skin "closed" image file '%1' does not exist.</source>
        <translation />
    </message>
</context>
<context>
    <name>EmbeddedOptionsControl</name>
    <message>
        <source>&lt;html&gt;&lt;table&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Font&lt;/b&gt;&lt;/td&gt;&lt;td&gt;%1, %2&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Style&lt;/b&gt;&lt;/td&gt;&lt;td&gt;%3&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Resolution&lt;/b&gt;&lt;/td&gt;&lt;td&gt;%4 x %5&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/html&gt;</source>
        <extracomment>Format embedded device profile description</extracomment>
        <translation />
    </message>
</context>
<context>
    <name>EmbeddedOptionsPage</name>
    <message>
        <source>Embedded Design</source>
        <extracomment>Tab in preferences dialog</extracomment>
        <translation />
    </message>
    <message>
        <source>Device Profiles</source>
        <extracomment>EmbeddedOptionsControl group box"</extracomment>
        <translation />
    </message>
</context>
<context>
    <name>FontPanel</name>
    <message>
        <source>Font</source>
        <translation />
    </message>
    <message>
        <source>&amp;Writing system</source>
        <translation />
    </message>
    <message>
        <source>&amp;Family</source>
        <translation />
    </message>
    <message>
        <source>&amp;Style</source>
        <translation />
    </message>
    <message>
        <source>&amp;Point size</source>
        <translation />
    </message>
</context>
<context>
    <name>FontPropertyManager</name>
    <message>
        <source>PreferDefault</source>
        <translation />
    </message>
    <message>
        <source>NoAntialias</source>
        <translation />
    </message>
    <message>
        <source>PreferAntialias</source>
        <translation />
    </message>
    <message>
        <source>PreferDefaultHinting</source>
        <comment>QFont::StyleStrategy combo</comment>
        <translation />
    </message>
    <message>
        <source>PreferNoHinting</source>
        <comment>QFont::StyleStrategy combo</comment>
        <translation />
    </message>
    <message>
        <source>PreferVerticalHinting</source>
        <comment>QFont::StyleStrategy combo</comment>
        <translation />
    </message>
    <message>
        <source>PreferFullHinting</source>
        <comment>QFont::StyleStrategy combo</comment>
        <translation />
    </message>
    <message>
        <source>Antialiasing</source>
        <translation />
    </message>
    <message>
        <source>HintingPreference</source>
        <translation />
    </message>
    <message>
        <source>Thin</source>
        <comment>QFont::Weight combo</comment>
        <translation />
    </message>
    <message>
        <source>ExtraLight</source>
        <comment>QFont::Weight combo</comment>
        <translation />
    </message>
    <message>
        <source>Light</source>
        <comment>QFont::Weight combo</comment>
        <translation />
    </message>
    <message>
        <source>Normal</source>
        <comment>QFont::Weight combo</comment>
        <translation />
    </message>
    <message>
        <source>Medium</source>
        <comment>QFont::Weight combo</comment>
        <translation />
    </message>
    <message>
        <source>DemiBold</source>
        <comment>QFont::Weight combo</comment>
        <translation />
    </message>
    <message>
        <source>Bold</source>
        <comment>QFont::Weight combo</comment>
        <translation />
    </message>
    <message>
        <source>ExtraBold</source>
        <comment>QFont::Weight combo</comment>
        <translation />
    </message>
    <message>
        <source>Black</source>
        <comment>QFont::Weight combo</comment>
        <translation />
    </message>
</context>
<context>
    <name>FormBuilder</name>
    <message>
        <source>Invalid stretch value for '%1': '%2'</source>
        <extracomment>Parsing layout stretch values</extracomment>
        <translation />
    </message>
    <message>
        <source>Invalid minimum size for '%1': '%2'</source>
        <extracomment>Parsing grid layout minimum size values</extracomment>
        <translation />
    </message>
</context>
<context>
    <name>FormEditorOptionsPage</name>
    <message>
        <source>%1 %</source>
        <extracomment>Zoom percentage</extracomment>
        <translation />
    </message>
    <message>
        <source>Preview Zoom</source>
        <translation />
    </message>
    <message>
        <source>Default Zoom</source>
        <translation />
    </message>
    <message>
        <source>Forms</source>
        <extracomment>Tab in preferences dialog</extracomment>
        <translation />
    </message>
    <message>
        <source>Default Grid</source>
        <translation />
    </message>
    <message>
        <source>Object Naming Convention</source>
        <translation />
    </message>
    <message>
        <source>Naming convention used for generating action object names from their text</source>
        <translation />
    </message>
    <message>
        <source>Camel Case</source>
        <translation />
    </message>
    <message>
        <source>Underscore</source>
        <translation />
    </message>
</context>
<context>
    <name>FormLayoutRowDialog</name>
    <message>
        <source>Add Form Layout Row</source>
        <translation />
    </message>
    <message>
        <source>&amp;Label text:</source>
        <translation />
    </message>
    <message>
        <source>Field &amp;type:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Field name:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Buddy:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Row:</source>
        <translation />
    </message>
    <message>
        <source>Label &amp;name:</source>
        <translation />
    </message>
</context>
<context>
    <name>FormWindow</name>
    <message>
        <source>Unexpected element &lt;%1&gt;</source>
        <translation />
    </message>
    <message>
        <source>Error while pasting clipboard contents at line %1, column %2: %3</source>
        <translation />
    </message>
</context>
<context>
    <name>FormWindowSettings</name>
    <message>
        <source>Form Settings</source>
        <translation />
    </message>
    <message>
        <source>Layout &amp;Default</source>
        <translation />
    </message>
    <message>
        <source>&amp;Spacing:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Margin:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Layout Function</source>
        <translation />
    </message>
    <message>
        <source>Ma&amp;rgin:</source>
        <translation />
    </message>
    <message>
        <source>Spa&amp;cing:</source>
        <translation />
    </message>
    <message>
        <source>Embedded Design</source>
        <translation />
    </message>
    <message>
        <source>&amp;Author</source>
        <translation />
    </message>
    <message>
        <source>&amp;Include Hints</source>
        <translation />
    </message>
    <message>
        <source>&amp;Pixmap Function</source>
        <translation />
    </message>
    <message>
        <source>Grid</source>
        <translation />
    </message>
    <message>
        <source>Translations</source>
        <translation />
    </message>
    <message>
        <source>ID-based</source>
        <translation />
    </message>
    <message>
        <source>Connections</source>
        <translation />
    </message>
    <message>
        <source>Connect slots by name</source>
        <translation />
    </message>
</context>
<context>
    <name>IconSelector</name>
    <message>
        <source>The pixmap file '%1' cannot be read.</source>
        <translation />
    </message>
    <message>
        <source>The file '%1' does not appear to be a valid pixmap file: %2</source>
        <translation />
    </message>
    <message>
        <source>The file '%1' could not be read: %2</source>
        <translation />
    </message>
    <message>
        <source>All Pixmaps (</source>
        <translation />
    </message>
    <message>
        <source>Choose a Pixmap</source>
        <translation />
    </message>
    <message>
        <source>Pixmap Read Error</source>
        <translation />
    </message>
    <message>
        <source>...</source>
        <translation />
    </message>
    <message>
        <source>Normal Off</source>
        <translation />
    </message>
    <message>
        <source>Normal On</source>
        <translation />
    </message>
    <message>
        <source>Disabled Off</source>
        <translation />
    </message>
    <message>
        <source>Disabled On</source>
        <translation />
    </message>
    <message>
        <source>Active Off</source>
        <translation />
    </message>
    <message>
        <source>Active On</source>
        <translation />
    </message>
    <message>
        <source>Selected Off</source>
        <translation />
    </message>
    <message>
        <source>Selected On</source>
        <translation />
    </message>
    <message>
        <source>Choose Resource...</source>
        <translation />
    </message>
    <message>
        <source>Choose File...</source>
        <translation />
    </message>
    <message>
        <source>Reset</source>
        <translation />
    </message>
    <message>
        <source>Reset All</source>
        <translation />
    </message>
</context>
<context>
    <name>ItemPropertyBrowser</name>
    <message>
        <source>XX Icon Selected off</source>
        <extracomment>Sample string to determinate the width for the first column of the list item property browser</extracomment>
        <translation />
    </message>
</context>
<context>
    <name>MainWindowBase</name>
    <message>
        <source>Main</source>
        <extracomment>Not currently used (main tool bar)</extracomment>
        <translation />
    </message>
    <message>
        <source>File</source>
        <translation />
    </message>
    <message>
        <source>Edit</source>
        <translation />
    </message>
    <message>
        <source>Tools</source>
        <translation />
    </message>
    <message>
        <source>Form</source>
        <translation />
    </message>
    <message>
        <source>Qt Widgets Designer</source>
        <translation />
    </message>
</context>
<context>
    <name>NewForm</name>
    <message>
        <source>C&amp;reate</source>
        <translation />
    </message>
    <message>
        <source>Recent</source>
        <translation />
    </message>
    <message>
        <source>&amp;Close</source>
        <translation />
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation />
    </message>
    <message>
        <source>&amp;Recent Forms</source>
        <translation />
    </message>
    <message>
        <source>Read error</source>
        <translation />
    </message>
    <message>
        <source>A temporary form file could not be created in %1: %2</source>
        <translation />
    </message>
    <message>
        <source>The temporary form file %1 could not be written: %2</source>
        <translation />
    </message>
    <message>
        <source>New Form</source>
        <translation />
    </message>
    <message>
        <source>Show this Dialog on Startup</source>
        <translation />
    </message>
</context>
<context>
    <name>ObjectInspectorModel</name>
    <message>
        <source>Object</source>
        <translation />
    </message>
    <message>
        <source>Class</source>
        <translation />
    </message>
    <message>
        <source>separator</source>
        <translation />
    </message>
    <message>
        <source>&lt;noname&gt;</source>
        <translation />
    </message>
</context>
<context>
    <name>ObjectNameDialog</name>
    <message>
        <source>Change Object Name</source>
        <translation />
    </message>
    <message>
        <source>Object Name</source>
        <translation />
    </message>
</context>
<context>
    <name>PluginDialog</name>
    <message>
        <source>Plugin Information</source>
        <translation />
    </message>
    <message>
        <source>1</source>
        <translation />
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>Preferences</source>
        <translation />
    </message>
</context>
<context>
    <name>PreviewConfigurationWidget</name>
    <message>
        <source>Form</source>
        <translation />
    </message>
    <message>
        <source>Print/Preview Configuration</source>
        <translation />
    </message>
    <message>
        <source>Style</source>
        <translation />
    </message>
    <message>
        <source>Style sheet</source>
        <translation />
    </message>
    <message>
        <source>...</source>
        <translation />
    </message>
    <message>
        <source>Device skin</source>
        <translation />
    </message>
</context>
<context>
    <name>PromotionModel</name>
    <message>
        <source>Not used</source>
        <extracomment>Usage of promoted widgets</extracomment>
        <translation />
    </message>
</context>
<context>
    <name>QAbstractFormBuilder</name>
    <message>
        <source>An error has occurred while reading the UI file at line %1, column %2: %3</source>
        <translation />
    </message>
    <message>
        <source>This file was created using Designer from Qt-%1 and cannot be read.</source>
        <translation />
    </message>
    <message>
        <source>This file cannot be read because it was created using %1.</source>
        <translation />
    </message>
    <message>
        <source>Invalid UI file: The root element &lt;ui&gt; is missing.</source>
        <translation />
    </message>
    <message>
        <source>Invalid UI file</source>
        <translation />
    </message>
    <message>
        <source>The creation of a widget of the class '%1' failed.</source>
        <translation />
    </message>
    <message>
        <source>Attempt to add child that is not of class QWizardPage to QWizard.</source>
        <translation />
    </message>
    <message>
        <source>Attempt to add a layout to a widget '%1' (%2) which already has a layout of non-box type %3.
This indicates an inconsistency in the ui-file.</source>
        <translation />
    </message>
    <message>
        <source>Empty widget item in %1 '%2'.</source>
        <translation />
    </message>
    <message>
        <source>Flags property are not supported yet.</source>
        <translation />
    </message>
    <message>
        <source>While applying tab stops: The widget '%1' could not be found.</source>
        <translation />
    </message>
    <message>
        <source>Invalid QButtonGroup reference '%1' referenced by '%2'.</source>
        <translation />
    </message>
</context>
<context>
    <name>QAxWidgetPlugin</name>
    <message>
        <source>ActiveX control</source>
        <translation />
    </message>
    <message>
        <source>ActiveX control widget</source>
        <translation />
    </message>
</context>
<context>
    <name>QAxWidgetTaskMenu</name>
    <message>
        <source>Set Control</source>
        <translation />
    </message>
    <message>
        <source>Reset Control</source>
        <translation />
    </message>
    <message>
        <source>Licensed Control</source>
        <translation />
    </message>
    <message>
        <source>The control requires a design-time license</source>
        <translation />
    </message>
</context>
<context>
    <name>QCoreApplication</name>
    <message>
        <source>%1 is not a promoted class.</source>
        <translation />
    </message>
    <message>
        <source>The base class %1 is invalid.</source>
        <translation />
    </message>
    <message>
        <source>The class %1 already exists.</source>
        <translation />
    </message>
    <message>
        <source>Promoted Widgets</source>
        <translation />
    </message>
    <message>
        <source>The class %1 cannot be removed</source>
        <translation />
    </message>
    <message>
        <source>The class %1 cannot be removed because it is still referenced.</source>
        <translation />
    </message>
    <message>
        <source>The class %1 cannot be renamed</source>
        <translation />
    </message>
    <message>
        <source>The class %1 cannot be renamed to an empty name.</source>
        <translation />
    </message>
    <message>
        <source>There is already a class named %1.</source>
        <translation />
    </message>
    <message>
        <source>Cannot set an empty include file.</source>
        <translation />
    </message>
</context>
<context>
    <name>QDesigner</name>
    <message>
        <source>%1 - warning</source>
        <translation />
    </message>
</context>
<context>
    <name>QDesignerActions</name>
    <message>
        <source>Edit Widgets</source>
        <translation />
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation />
    </message>
    <message>
        <source>&amp;Minimize</source>
        <translation />
    </message>
    <message>
        <source>Bring All to Front</source>
        <translation />
    </message>
    <message>
        <source>Preferences...</source>
        <translation />
    </message>
    <message>
        <source>Clear &amp;Menu</source>
        <translation />
    </message>
    <message>
        <source>CTRL+SHIFT+S</source>
        <translation />
    </message>
    <message>
        <source>CTRL+R</source>
        <translation />
    </message>
    <message>
        <source>CTRL+M</source>
        <translation />
    </message>
    <message>
        <source>Qt Widgets Designer &amp;Help</source>
        <translation />
    </message>
    <message>
        <source>Current Widget Help</source>
        <translation />
    </message>
    <message>
        <source>About Plugins</source>
        <translation />
    </message>
    <message>
        <source>About Qt Widgets Designer</source>
        <translation />
    </message>
    <message>
        <source>About Qt</source>
        <translation />
    </message>
    <message>
        <source>Open Form</source>
        <translation />
    </message>
    <message>
        <source>Designer UI files (*.%1);;All Files (*)</source>
        <translation />
    </message>
    <message>
        <source>Saved %1.</source>
        <translation />
    </message>
    <message>
        <source>View &amp;C++ Code...</source>
        <translation />
    </message>
    <message>
        <source>View &amp;Python Code...</source>
        <translation />
    </message>
    <message>
        <source>&amp;Recent Forms</source>
        <translation />
    </message>
    <message>
        <source>Designer</source>
        <translation />
    </message>
    <message>
        <source>Feature not implemented yet!</source>
        <translation />
    </message>
    <message>
        <source>Read error</source>
        <translation />
    </message>
    <message>
        <source>%1
Do you want to update the file location or generate a new form?</source>
        <translation />
    </message>
    <message>
        <source>&amp;Update</source>
        <translation />
    </message>
    <message>
        <source>&amp;New Form</source>
        <translation />
    </message>
    <message>
        <source>Qt Widgets Designer</source>
        <translation />
    </message>
    <message>
        <source>Save Form?</source>
        <translation />
    </message>
    <message>
        <source>Could not open file</source>
        <translation />
    </message>
    <message>
        <source>Save Form</source>
        <translation />
    </message>
    <message>
        <source>The backup directory %1 could not be created.</source>
        <translation />
    </message>
    <message>
        <source>Please close all forms to enable the loading of additional fonts.</source>
        <translation />
    </message>
    <message>
        <source>Select New File</source>
        <translation />
    </message>
    <message>
        <source>Could not write file</source>
        <translation />
    </message>
    <message>
        <source>&amp;Close Preview</source>
        <translation />
    </message>
    <message>
        <source>Save &amp;Image...</source>
        <translation />
    </message>
    <message>
        <source>&amp;Print...</source>
        <translation />
    </message>
    <message>
        <source>Additional Fonts...</source>
        <translation />
    </message>
    <message>
        <source>The file %1 could not be opened.
Reason: %2
Would you like to retry or select a different file?</source>
        <translation />
    </message>
    <message>
        <source>It was not possible to write the file %1 to disk.
Reason: %2</source>
        <translation />
    </message>
    <message>
        <source>The backup file %1 could not be written: %2</source>
        <translation />
    </message>
    <message>
        <source>Image files (*.%1)</source>
        <translation />
    </message>
    <message>
        <source>Save Image</source>
        <translation />
    </message>
    <message>
        <source>The file %1 could not be written.</source>
        <translation />
    </message>
    <message>
        <source>&amp;New...</source>
        <translation />
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation />
    </message>
    <message>
        <source>&amp;Save</source>
        <translation />
    </message>
    <message>
        <source>Save &amp;As...</source>
        <translation />
    </message>
    <message>
        <source>Save A&amp;ll</source>
        <translation />
    </message>
    <message>
        <source>Save As &amp;Template...</source>
        <translation />
    </message>
    <message>
        <source>&amp;Close</source>
        <translation />
    </message>
    <message>
        <source>Save Form As</source>
        <translation />
    </message>
    <message>
        <source>Preview failed</source>
        <translation />
    </message>
    <message>
        <source>Code generation failed</source>
        <translation />
    </message>
    <message>
        <source>Assistant</source>
        <translation />
    </message>
    <message>
        <source>Saved image %1.</source>
        <translation />
    </message>
    <message>
        <source>Printed %1.</source>
        <translation />
    </message>
    <message>
        <source>ALT+CTRL+S</source>
        <translation />
    </message>
</context>
<context>
    <name>QDesignerAppearanceOptionsPage</name>
    <message>
        <source>Appearance</source>
        <extracomment>Tab in preferences dialog</extracomment>
        <translation />
    </message>
</context>
<context>
    <name>QDesignerAppearanceOptionsWidget</name>
    <message>
        <source>Docked Window</source>
        <translation />
    </message>
    <message>
        <source>Multiple Top-Level Windows</source>
        <translation />
    </message>
    <message>
        <source>Toolwindow Font</source>
        <translation />
    </message>
</context>
<context>
    <name>QDesignerAxWidget</name>
    <message>
        <source>Reset control</source>
        <translation />
    </message>
    <message>
        <source>Set control</source>
        <translation />
    </message>
    <message>
        <source>Control loaded</source>
        <translation />
    </message>
    <message>
        <source>A COM exception occurred when executing a meta call of type %1, index %2 of "%3".</source>
        <translation />
    </message>
</context>
<context>
    <name>QDesignerFormBuilder</name>
    <message>
        <source>The preview failed to build.</source>
        <translation />
    </message>
    <message>
        <source>Designer</source>
        <translation />
    </message>
</context>
<context>
    <name>QDesignerFormWindow</name>
    <message>
        <source>%1 - %2[*]</source>
        <translation />
    </message>
    <message>
        <source>Save Form?</source>
        <translation />
    </message>
    <message>
        <source>Do you want to save the changes to this document before closing?</source>
        <translation />
    </message>
    <message>
        <source>If you don't save, your changes will be lost.</source>
        <translation />
    </message>
</context>
<context>
    <name>QDesignerMenu</name>
    <message>
        <source>Type Here</source>
        <translation />
    </message>
    <message>
        <source>Add Separator</source>
        <translation />
    </message>
    <message>
        <source>Insert separator</source>
        <translation />
    </message>
    <message>
        <source>Remove action '%1'</source>
        <translation />
    </message>
    <message>
        <source>Remove separator</source>
        <translation />
    </message>
    <message>
        <source>Add separator</source>
        <translation />
    </message>
    <message>
        <source>Insert action</source>
        <translation />
    </message>
</context>
<context>
    <name>QDesignerMenuBar</name>
    <message>
        <source>Type Here</source>
        <translation />
    </message>
    <message>
        <source>Remove Menu '%1'</source>
        <translation />
    </message>
    <message>
        <source>Remove Menu Bar</source>
        <translation />
    </message>
    <message>
        <source>Menu</source>
        <translation />
    </message>
</context>
<context>
    <name>QDesignerPluginManager</name>
    <message>
        <source>An XML error was encountered when parsing the XML of the custom widget %1: %2</source>
        <translation />
    </message>
    <message>
        <source>A required attribute ('%1') is missing.</source>
        <translation />
    </message>
    <message>
        <source>An invalid property specification ('%1') was encountered. Supported types: %2</source>
        <translation />
    </message>
    <message>
        <source>'%1' is not a valid string property specification.</source>
        <translation />
    </message>
    <message>
        <source>The XML of the custom widget %1 does not contain any of the elements &lt;widget&gt; or &lt;ui&gt;.</source>
        <translation />
    </message>
    <message>
        <source>The class attribute for the class %1 is missing.</source>
        <translation />
    </message>
    <message>
        <source>The class attribute for the class %1 does not match the class name %2.</source>
        <translation />
    </message>
</context>
<context>
    <name>QDesignerPropertySheet</name>
    <message>
        <source>Dynamic Properties</source>
        <translation />
    </message>
</context>
<context>
    <name>QDesignerResource</name>
    <message>
        <source>The layout type '%1' is not supported, defaulting to grid.</source>
        <translation />
    </message>
    <message>
        <source>The container extension of the widget '%1' (%2) returned a widget not managed by Designer '%3' (%4) when queried for page #%5.
Container pages should only be added by specifying them in XML returned by the domXml() method of the custom widget.</source>
        <translation />
    </message>
    <message>
        <source>Unexpected element &lt;%1&gt;</source>
        <extracomment>Parsing clipboard contents</extracomment>
        <translation />
    </message>
    <message>
        <source>Error while pasting clipboard contents at line %1, column %2: %3</source>
        <extracomment>Parsing clipboard contents</extracomment>
        <translation />
    </message>
    <message>
        <source>Error while pasting clipboard contents: The root element &lt;ui&gt; is missing.</source>
        <extracomment>Parsing clipboard contents</extracomment>
        <translation />
    </message>
</context>
<context>
    <name>QDesignerSharedSettings</name>
    <message>
        <source>The template path %1 could not be created.</source>
        <translation />
    </message>
    <message>
        <source>An error has been encountered while parsing device profile XML: %1</source>
        <translation />
    </message>
</context>
<context>
    <name>QDesignerTaskMenu</name>
    <message>
        <source>no signals available</source>
        <translation />
    </message>
</context>
<context>
    <name>QDesignerToolWindow</name>
    <message>
        <source>Property Editor</source>
        <translation />
    </message>
    <message>
        <source>Action Editor</source>
        <translation />
    </message>
    <message>
        <source>Object Inspector</source>
        <translation />
    </message>
    <message>
        <source>Resource Browser</source>
        <translation />
    </message>
    <message>
        <source>Signal/Slot Editor</source>
        <translation />
    </message>
    <message>
        <source>Widget Box</source>
        <translation />
    </message>
</context>
<context>
    <name>QDesignerWorkbench</name>
    <message>
        <source>&amp;File</source>
        <translation />
    </message>
    <message>
        <source>F&amp;orm</source>
        <translation />
    </message>
    <message>
        <source>Preview in</source>
        <translation />
    </message>
    <message>
        <source>&amp;Window</source>
        <translation />
    </message>
    <message>
        <source>&amp;Help</source>
        <translation />
    </message>
    <message>
        <source>Toolbars</source>
        <translation />
    </message>
    <message>
        <source>Save Forms?</source>
        <translation />
    </message>
    <message>
        <source>&amp;View</source>
        <translation />
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation />
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation />
    </message>
    <message>
        <source>Widget Box</source>
        <translation />
    </message>
    <message>
        <source>If you do not review your documents, all your changes will be lost.</source>
        <translation />
    </message>
    <message>
        <source>Discard Changes</source>
        <translation />
    </message>
    <message>
        <source>Review Changes</source>
        <translation />
    </message>
    <message>
        <source>Backup Information</source>
        <translation />
    </message>
    <message>
        <source>The last session of Designer was not terminated correctly. Backup files were left behind. Do you want to load them?</source>
        <translation />
    </message>
    <message>
        <source>The file &lt;b&gt;%1&lt;/b&gt; could not be opened: %2</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>There are %n forms with unsaved changes. Do you want to review these changes before quitting?</source>
        <translation><numerusform>Das Formular wurde geändert. Möchten Sie sich die Änderungen ansehen, bevor Sie das Programm beenden?</numerusform>
            <numerusform>%n Formulare  wurden geändert. Möchten Sie sich die Änderungen ansehen, bevor Sie das Programm beenden?</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>QFormBuilder</name>
    <message>
        <source>An empty class name was passed on to %1 (object name: '%2').</source>
        <extracomment>Empty class name passed to widget factory method</extracomment>
        <translation />
    </message>
    <message>
        <source>QFormBuilder was unable to create a custom widget of the class '%1'; defaulting to base class '%2'.</source>
        <translation />
    </message>
    <message>
        <source>QFormBuilder was unable to create a widget of the class '%1'.</source>
        <translation />
    </message>
    <message>
        <source>The layout type `%1' is not supported.</source>
        <translation />
    </message>
    <message>
        <source>The set-type property %1 could not be read.</source>
        <translation />
    </message>
    <message>
        <source>The value "%1" of the set-type property %2 could not be read.</source>
        <translation />
    </message>
    <message>
        <source>The enumeration-type property %1 could not be read.</source>
        <translation />
    </message>
    <message>
        <source>The value "%1" of the enum-type property %2 could not be read.</source>
        <translation />
    </message>
    <message>
        <source>Reading properties of the type %1 is not supported yet.</source>
        <translation />
    </message>
    <message>
        <source>The property %1 could not be written. The type %2 is not supported yet.</source>
        <translation />
    </message>
    <message>
        <source>The enumeration-value '%1' is invalid. The default value '%2' will be used instead.</source>
        <translation />
    </message>
    <message>
        <source>The flag-value '%1' is invalid. Zero will be used instead.</source>
        <translation />
    </message>
</context>
<context>
    <name>QStackedWidgetEventFilter</name>
    <message>
        <source>Previous Page</source>
        <translation />
    </message>
    <message>
        <source>Next Page</source>
        <translation />
    </message>
    <message>
        <source>Delete</source>
        <translation />
    </message>
    <message>
        <source>Before Current Page</source>
        <translation />
    </message>
    <message>
        <source>After Current Page</source>
        <translation />
    </message>
    <message>
        <source>Change Page Order...</source>
        <translation />
    </message>
    <message>
        <source>Change Page Order</source>
        <translation />
    </message>
    <message>
        <source>Page %1 of %2</source>
        <translation />
    </message>
    <message>
        <source>Insert Page</source>
        <translation />
    </message>
</context>
<context>
    <name>QStackedWidgetPreviewEventFilter</name>
    <message>
        <source>Go to previous page of %1 '%2' (%3/%4).</source>
        <translation />
    </message>
    <message>
        <source>Go to next page of %1 '%2' (%3/%4).</source>
        <translation />
    </message>
</context>
<context>
    <name>QTabWidgetEventFilter</name>
    <message>
        <source>Delete</source>
        <translation />
    </message>
    <message>
        <source>Before Current Page</source>
        <translation />
    </message>
    <message>
        <source>After Current Page</source>
        <translation />
    </message>
    <message>
        <source>Page %1 of %2</source>
        <translation />
    </message>
    <message>
        <source>Insert Page</source>
        <translation />
    </message>
</context>
<context>
    <name>QToolBoxHelper</name>
    <message>
        <source>Delete Page</source>
        <translation />
    </message>
    <message>
        <source>Before Current Page</source>
        <translation />
    </message>
    <message>
        <source>After Current Page</source>
        <translation />
    </message>
    <message>
        <source>Change Page Order...</source>
        <translation />
    </message>
    <message>
        <source>Change Page Order</source>
        <translation />
    </message>
    <message>
        <source>Page %1 of %2</source>
        <translation />
    </message>
    <message>
        <source>Insert Page</source>
        <translation />
    </message>
</context>
<context>
    <name>QtBoolEdit</name>
    <message>
        <source>True</source>
        <translation />
    </message>
    <message>
        <source>False</source>
        <translation />
    </message>
</context>
<context>
    <name>QtBoolPropertyManager</name>
    <message>
        <source>True</source>
        <translation />
    </message>
    <message>
        <source>False</source>
        <translation />
    </message>
</context>
<context>
    <name>QtCharEdit</name>
    <message>
        <source>Clear Char</source>
        <translation />
    </message>
</context>
<context>
    <name>QtColorEditWidget</name>
    <message>
        <source>...</source>
        <translation />
    </message>
</context>
<context>
    <name>QtColorPropertyManager</name>
    <message>
        <source>Red</source>
        <translation />
    </message>
    <message>
        <source>Green</source>
        <translation />
    </message>
    <message>
        <source>Blue</source>
        <translation />
    </message>
    <message>
        <source>Alpha</source>
        <translation />
    </message>
</context>
<context>
    <name>QtCursorDatabase</name>
    <message>
        <source>Arrow</source>
        <translation />
    </message>
    <message>
        <source>Up Arrow</source>
        <translation />
    </message>
    <message>
        <source>Cross</source>
        <translation />
    </message>
    <message>
        <source>Wait</source>
        <translation />
    </message>
    <message>
        <source>IBeam</source>
        <translation />
    </message>
    <message>
        <source>Size Vertical</source>
        <translation />
    </message>
    <message>
        <source>Size Horizontal</source>
        <translation />
    </message>
    <message>
        <source>Size Backslash</source>
        <translation />
    </message>
    <message>
        <source>Size Slash</source>
        <translation />
    </message>
    <message>
        <source>Size All</source>
        <translation />
    </message>
    <message>
        <source>Blank</source>
        <translation />
    </message>
    <message>
        <source>Split Vertical</source>
        <translation />
    </message>
    <message>
        <source>Split Horizontal</source>
        <translation />
    </message>
    <message>
        <source>Pointing Hand</source>
        <translation />
    </message>
    <message>
        <source>Forbidden</source>
        <translation />
    </message>
    <message>
        <source>Open Hand</source>
        <translation />
    </message>
    <message>
        <source>Closed Hand</source>
        <translation />
    </message>
    <message>
        <source>What's This</source>
        <translation />
    </message>
    <message>
        <source>Busy</source>
        <translation />
    </message>
</context>
<context>
    <name>QtFontEditWidget</name>
    <message>
        <source>...</source>
        <translation />
    </message>
    <message>
        <source>Select Font</source>
        <translation />
    </message>
</context>
<context>
    <name>QtFontPropertyManager</name>
    <message>
        <source>Family</source>
        <translation />
    </message>
    <message>
        <source>Point Size</source>
        <translation />
    </message>
    <message>
        <source>Bold</source>
        <comment>Bold toggle</comment>
        <translation />
    </message>
    <message>
        <source>Italic</source>
        <translation />
    </message>
    <message>
        <source>Underline</source>
        <translation />
    </message>
    <message>
        <source>Strikeout</source>
        <translation />
    </message>
    <message>
        <source>Kerning</source>
        <translation />
    </message>
    <message>
        <source>Weight</source>
        <translation />
    </message>
</context>
<context>
    <name>QtGradientDialog</name>
    <message>
        <source>Edit Gradient</source>
        <translation />
    </message>
</context>
<context>
    <name>QtGradientEditor</name>
    <message>
        <source>Start X</source>
        <translation />
    </message>
    <message>
        <source>Start Y</source>
        <translation />
    </message>
    <message>
        <source>Final X</source>
        <translation />
    </message>
    <message>
        <source>Final Y</source>
        <translation />
    </message>
    <message>
        <source>Central X</source>
        <translation />
    </message>
    <message>
        <source>Central Y</source>
        <translation />
    </message>
    <message>
        <source>Focal X</source>
        <translation />
    </message>
    <message>
        <source>Focal Y</source>
        <translation />
    </message>
    <message>
        <source>Radius</source>
        <translation />
    </message>
    <message>
        <source>Angle</source>
        <translation />
    </message>
    <message>
        <source>Linear</source>
        <translation />
    </message>
    <message>
        <source>Radial</source>
        <translation />
    </message>
    <message>
        <source>Conical</source>
        <translation />
    </message>
    <message>
        <source>Pad</source>
        <translation />
    </message>
    <message>
        <source>Repeat</source>
        <translation />
    </message>
    <message>
        <source>Reflect</source>
        <translation />
    </message>
    <message>
        <source>Form</source>
        <translation />
    </message>
    <message>
        <source>Gradient Editor</source>
        <translation />
    </message>
    <message>
        <source>1</source>
        <translation />
    </message>
    <message>
        <source>2</source>
        <translation />
    </message>
    <message>
        <source>3</source>
        <translation />
    </message>
    <message>
        <source>4</source>
        <translation />
    </message>
    <message>
        <source>5</source>
        <translation />
    </message>
    <message>
        <source>Gradient Stops Editor</source>
        <translation />
    </message>
    <message>
        <source>This area allows you to edit gradient stops. Double click on the existing stop handle to duplicate it. Double click outside of the existing stop handles to create a new stop. Drag &amp; drop the handle to reposition it. Use right mouse button to popup context menu with extra actions.</source>
        <translation />
    </message>
    <message>
        <source>Zoom</source>
        <translation />
    </message>
    <message>
        <source>Position</source>
        <translation />
    </message>
    <message>
        <source>Hue</source>
        <translation />
    </message>
    <message>
        <source>H</source>
        <translation />
    </message>
    <message>
        <source>Saturation</source>
        <translation />
    </message>
    <message>
        <source>S</source>
        <translation />
    </message>
    <message>
        <source>Sat</source>
        <translation />
    </message>
    <message>
        <source>Value</source>
        <translation />
    </message>
    <message>
        <source>V</source>
        <translation />
    </message>
    <message>
        <source>Val</source>
        <translation />
    </message>
    <message>
        <source>Alpha</source>
        <translation />
    </message>
    <message>
        <source>A</source>
        <translation />
    </message>
    <message>
        <source>Type</source>
        <translation />
    </message>
    <message>
        <source>Spread</source>
        <translation />
    </message>
    <message>
        <source>Color</source>
        <translation />
    </message>
    <message>
        <source>Current stop's color</source>
        <translation />
    </message>
    <message>
        <source>HSV</source>
        <translation />
    </message>
    <message>
        <source>RGB</source>
        <translation />
    </message>
    <message>
        <source>Current stop's position</source>
        <translation />
    </message>
    <message>
        <source>%</source>
        <translation />
    </message>
    <message>
        <source>Zoom In</source>
        <translation />
    </message>
    <message>
        <source>Zoom Out</source>
        <translation />
    </message>
    <message>
        <source>Toggle details extension</source>
        <translation />
    </message>
    <message>
        <source>&gt;</source>
        <translation />
    </message>
    <message>
        <source>Linear Type</source>
        <translation />
    </message>
    <message>
        <source>...</source>
        <translation />
    </message>
    <message>
        <source>Radial Type</source>
        <translation />
    </message>
    <message>
        <source>Conical Type</source>
        <translation />
    </message>
    <message>
        <source>Pad Spread</source>
        <translation />
    </message>
    <message>
        <source>Repeat Spread</source>
        <translation />
    </message>
    <message>
        <source>Reflect Spread</source>
        <translation />
    </message>
    <message>
        <source>This area shows a preview of the gradient being edited. It also allows you to edit parameters specific to the gradient's type such as start and final point, radius, etc. by drag &amp; drop.</source>
        <translation />
    </message>
    <message>
        <source>Show HSV specification</source>
        <translation />
    </message>
    <message>
        <source>Show RGB specification</source>
        <translation />
    </message>
    <message>
        <source>Reset Zoom</source>
        <translation />
    </message>
</context>
<context>
    <name>QtGradientStopsWidget</name>
    <message>
        <source>New Stop</source>
        <translation />
    </message>
    <message>
        <source>Delete</source>
        <translation />
    </message>
    <message>
        <source>Flip All</source>
        <translation />
    </message>
    <message>
        <source>Select All</source>
        <translation />
    </message>
    <message>
        <source>Zoom In</source>
        <translation />
    </message>
    <message>
        <source>Zoom Out</source>
        <translation />
    </message>
    <message>
        <source>Reset Zoom</source>
        <translation />
    </message>
</context>
<context>
    <name>QtGradientView</name>
    <message>
        <source>Grad</source>
        <translation />
    </message>
    <message>
        <source>Remove Gradient</source>
        <translation />
    </message>
    <message>
        <source>Are you sure you want to remove the selected gradient?</source>
        <translation />
    </message>
    <message>
        <source>New...</source>
        <translation />
    </message>
    <message>
        <source>Edit...</source>
        <translation />
    </message>
    <message>
        <source>Rename</source>
        <translation />
    </message>
    <message>
        <source>Remove</source>
        <translation />
    </message>
    <message>
        <source>Gradient View</source>
        <translation />
    </message>
</context>
<context>
    <name>QtGradientViewDialog</name>
    <message>
        <source>Select Gradient</source>
        <translation />
    </message>
</context>
<context>
    <name>QtLocalePropertyManager</name>
    <message>
        <source>&lt;Invalid&gt;</source>
        <translation />
    </message>
    <message>
        <source>%1, %2</source>
        <translation />
    </message>
    <message>
        <source>Language</source>
        <translation />
    </message>
    <message>
        <source>Territory</source>
        <translation />
    </message>
</context>
<context>
    <name>QtPointFPropertyManager</name>
    <message>
        <source>(%1, %2)</source>
        <translation />
    </message>
    <message>
        <source>X</source>
        <translation />
    </message>
    <message>
        <source>Y</source>
        <translation />
    </message>
</context>
<context>
    <name>QtPointPropertyManager</name>
    <message>
        <source>(%1, %2)</source>
        <translation />
    </message>
    <message>
        <source>X</source>
        <translation />
    </message>
    <message>
        <source>Y</source>
        <translation />
    </message>
</context>
<context>
    <name>QtPropertyBrowserUtils</name>
    <message>
        <source>[%1, %2, %3] (%4)</source>
        <translation />
    </message>
    <message>
        <source>[%1, %2]</source>
        <translation />
    </message>
</context>
<context>
    <name>QtRectFPropertyManager</name>
    <message>
        <source>[(%1, %2), %3 x %4]</source>
        <translation />
    </message>
    <message>
        <source>X</source>
        <translation />
    </message>
    <message>
        <source>Y</source>
        <translation />
    </message>
    <message>
        <source>Width</source>
        <translation />
    </message>
    <message>
        <source>Height</source>
        <translation />
    </message>
</context>
<context>
    <name>QtRectPropertyManager</name>
    <message>
        <source>[(%1, %2), %3 x %4]</source>
        <translation />
    </message>
    <message>
        <source>X</source>
        <translation />
    </message>
    <message>
        <source>Y</source>
        <translation />
    </message>
    <message>
        <source>Width</source>
        <translation />
    </message>
    <message>
        <source>Height</source>
        <translation />
    </message>
</context>
<context>
    <name>QtResourceEditorDialog</name>
    <message>
        <source>Edit Resources</source>
        <translation />
    </message>
    <message>
        <source>New...</source>
        <translation />
    </message>
    <message>
        <source>New Resource File</source>
        <translation />
    </message>
    <message>
        <source>&lt;p&gt;&lt;b&gt;Warning:&lt;/b&gt; The file&lt;/p&gt;&lt;p&gt;%1&lt;/p&gt;&lt;p&gt;is outside of the current resource file's parent directory.&lt;/p&gt;</source>
        <translation />
    </message>
    <message>
        <source>&lt;p&gt;To resolve the issue, press:&lt;/p&gt;&lt;table&gt;&lt;tr&gt;&lt;th align="left"&gt;Copy&lt;/th&gt;&lt;td&gt;to copy the file to the resource file's parent directory.&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;th align="left"&gt;Copy As...&lt;/th&gt;&lt;td&gt;to copy the file into a subdirectory of the resource file's parent directory.&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;th align="left"&gt;Keep&lt;/th&gt;&lt;td&gt;to use its current location.&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;</source>
        <translation />
    </message>
    <message>
        <source>Could not copy
%1
to
%2</source>
        <translation />
    </message>
    <message>
        <source>A parse error occurred at line %1, column %2 of %3:
%4</source>
        <translation />
    </message>
    <message>
        <source>Open...</source>
        <translation />
    </message>
    <message>
        <source>Remove</source>
        <translation />
    </message>
    <message>
        <source>Move Up</source>
        <translation />
    </message>
    <message>
        <source>Move Down</source>
        <translation />
    </message>
    <message>
        <source>Add Prefix</source>
        <translation />
    </message>
    <message>
        <source>Add Files...</source>
        <translation />
    </message>
    <message>
        <source>Change Prefix</source>
        <translation />
    </message>
    <message>
        <source>Change Language</source>
        <translation />
    </message>
    <message>
        <source>Change Alias</source>
        <translation />
    </message>
    <message>
        <source>Clone Prefix...</source>
        <translation />
    </message>
    <message>
        <source>Prefix / Path</source>
        <translation />
    </message>
    <message>
        <source>Language / Alias</source>
        <translation />
    </message>
    <message>
        <source>&lt;html&gt;&lt;p&gt;&lt;b&gt;Warning:&lt;/b&gt; There have been problems while reloading the resources:&lt;/p&gt;&lt;pre&gt;%1&lt;/pre&gt;&lt;/html&gt;</source>
        <translation />
    </message>
    <message>
        <source>Resource Warning</source>
        <translation />
    </message>
    <message>
        <source>Dialog</source>
        <translation />
    </message>
    <message>
        <source>New File</source>
        <translation />
    </message>
    <message>
        <source>N</source>
        <translation />
    </message>
    <message>
        <source>Remove File</source>
        <translation />
    </message>
    <message>
        <source>R</source>
        <translation />
    </message>
    <message>
        <source>I</source>
        <translation />
    </message>
    <message>
        <source>New Resource</source>
        <translation />
    </message>
    <message>
        <source>A</source>
        <translation />
    </message>
    <message>
        <source>Remove Resource or File</source>
        <translation />
    </message>
    <message>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation />
    </message>
    <message>
        <source>The file does not appear to be a resource file; element '%1' was found where '%2' was expected.</source>
        <translation />
    </message>
    <message>
        <source>%1 [read-only]</source>
        <translation />
    </message>
    <message>
        <source>%1 [missing]</source>
        <translation />
    </message>
    <message>
        <source>&lt;no prefix&gt;</source>
        <translation />
    </message>
    <message>
        <source>Resource files (*.qrc)</source>
        <translation />
    </message>
    <message>
        <source>Import Resource File</source>
        <translation />
    </message>
    <message>
        <source>newPrefix</source>
        <translation />
    </message>
    <message>
        <source>Add Files</source>
        <translation />
    </message>
    <message>
        <source>Incorrect Path</source>
        <translation />
    </message>
    <message>
        <source>Copy</source>
        <translation />
    </message>
    <message>
        <source>Copy As...</source>
        <translation />
    </message>
    <message>
        <source>Keep</source>
        <translation />
    </message>
    <message>
        <source>Skip</source>
        <translation />
    </message>
    <message>
        <source>Clone Prefix</source>
        <translation />
    </message>
    <message>
        <source>Enter the suffix which you want to add to the names of the cloned files.
This could for example be a language extension like "_de".</source>
        <translation />
    </message>
    <message>
        <source>Copy As</source>
        <translation />
    </message>
    <message>
        <source>&lt;p&gt;The selected file:&lt;/p&gt;&lt;p&gt;%1&lt;/p&gt;&lt;p&gt;is outside of the current resource file's directory:&lt;/p&gt;&lt;p&gt;%2&lt;/p&gt;&lt;p&gt;Please select another path within this directory.&lt;p&gt;</source>
        <translation />
    </message>
    <message>
        <source>Could not overwrite %1.</source>
        <translation />
    </message>
    <message>
        <source>Save Resource File</source>
        <translation />
    </message>
    <message>
        <source>Could not write %1: %2</source>
        <translation />
    </message>
    <message>
        <source>Open Resource File</source>
        <translation />
    </message>
</context>
<context>
    <name>QtResourceView</name>
    <message>
        <source>Size: %1 x %2
%3</source>
        <translation />
    </message>
    <message>
        <source>Edit Resources...</source>
        <translation />
    </message>
    <message>
        <source>Reload</source>
        <translation />
    </message>
    <message>
        <source>Copy Path</source>
        <translation />
    </message>
    <message>
        <source>Filter</source>
        <translation />
    </message>
</context>
<context>
    <name>QtResourceViewDialog</name>
    <message>
        <source>Select Resource</source>
        <translation />
    </message>
</context>
<context>
    <name>QtSizeFPropertyManager</name>
    <message>
        <source>%1 x %2</source>
        <translation />
    </message>
    <message>
        <source>Width</source>
        <translation />
    </message>
    <message>
        <source>Height</source>
        <translation />
    </message>
</context>
<context>
    <name>QtSizePolicyPropertyManager</name>
    <message>
        <source>&lt;Invalid&gt;</source>
        <translation />
    </message>
    <message>
        <source>[%1, %2, %3, %4]</source>
        <translation />
    </message>
    <message>
        <source>Horizontal Policy</source>
        <translation />
    </message>
    <message>
        <source>Vertical Policy</source>
        <translation />
    </message>
    <message>
        <source>Horizontal Stretch</source>
        <translation />
    </message>
    <message>
        <source>Vertical Stretch</source>
        <translation />
    </message>
</context>
<context>
    <name>QtSizePropertyManager</name>
    <message>
        <source>%1 x %2</source>
        <translation />
    </message>
    <message>
        <source>Width</source>
        <translation />
    </message>
    <message>
        <source>Height</source>
        <translation />
    </message>
</context>
<context>
    <name>QtToolBarDialog</name>
    <message>
        <source>&lt; S E P A R A T O R &gt;</source>
        <translation />
    </message>
    <message>
        <source>Customize Toolbars</source>
        <translation />
    </message>
    <message>
        <source>1</source>
        <translation />
    </message>
    <message>
        <source>Actions</source>
        <translation />
    </message>
    <message>
        <source>Toolbars</source>
        <translation />
    </message>
    <message>
        <source>New</source>
        <translation />
    </message>
    <message>
        <source>Remove</source>
        <translation />
    </message>
    <message>
        <source>Rename</source>
        <translation />
    </message>
    <message>
        <source>Up</source>
        <translation />
    </message>
    <message>
        <source>&lt;-</source>
        <translation />
    </message>
    <message>
        <source>-&gt;</source>
        <translation />
    </message>
    <message>
        <source>Down</source>
        <translation />
    </message>
    <message>
        <source>Current Toolbar Actions</source>
        <translation />
    </message>
    <message>
        <source>Custom Toolbar</source>
        <translation />
    </message>
    <message>
        <source>Add new toolbar</source>
        <translation />
    </message>
    <message>
        <source>Remove selected toolbar</source>
        <translation />
    </message>
    <message>
        <source>Rename toolbar</source>
        <translation />
    </message>
    <message>
        <source>Move action up</source>
        <translation />
    </message>
    <message>
        <source>Remove action from toolbar</source>
        <translation />
    </message>
    <message>
        <source>Add action to toolbar</source>
        <translation />
    </message>
    <message>
        <source>Move action down</source>
        <translation />
    </message>
</context>
<context>
    <name>QtTreePropertyBrowser</name>
    <message>
        <source>Property</source>
        <translation />
    </message>
    <message>
        <source>Value</source>
        <translation />
    </message>
</context>
<context>
    <name>SaveFormAsTemplate</name>
    <message>
        <source>Add path...</source>
        <translation />
    </message>
    <message>
        <source>Template Exists</source>
        <translation />
    </message>
    <message>
        <source>A template with the name %1 already exists.
Do you want overwrite the template?</source>
        <translation />
    </message>
    <message>
        <source>Overwrite Template</source>
        <translation />
    </message>
    <message>
        <source>Open Error</source>
        <translation />
    </message>
    <message>
        <source>There was an error opening template %1 for writing. Reason: %2</source>
        <translation />
    </message>
    <message>
        <source>Write Error</source>
        <translation />
    </message>
    <message>
        <source>There was an error writing the template %1 to disk. Reason: %2</source>
        <translation />
    </message>
    <message>
        <source>Pick a directory to save templates in</source>
        <translation />
    </message>
    <message>
        <source>Save Form As Template</source>
        <translation />
    </message>
    <message>
        <source>&amp;Category:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Name:</source>
        <translation />
    </message>
</context>
<context>
    <name>SelectSignalDialog</name>
    <message>
        <source>Go to slot</source>
        <translation />
    </message>
    <message>
        <source>Select signal</source>
        <translation />
    </message>
    <message>
        <source>signal</source>
        <translation />
    </message>
    <message>
        <source>class</source>
        <translation />
    </message>
</context>
<context>
    <name>SignalSlotConnection</name>
    <message>
        <source>SENDER(%1), SIGNAL(%2), RECEIVER(%3), SLOT(%4)</source>
        <translation />
    </message>
</context>
<context>
    <name>SignalSlotDialogClass</name>
    <message>
        <source>Signals and slots</source>
        <translation />
    </message>
    <message>
        <source>Slots</source>
        <translation />
    </message>
    <message>
        <source>...</source>
        <translation />
    </message>
    <message>
        <source>Signals</source>
        <translation />
    </message>
    <message>
        <source>Add</source>
        <translation />
    </message>
    <message>
        <source>Delete</source>
        <translation />
    </message>
</context>
<context>
    <name>Spacer</name>
    <message>
        <source>Horizontal Spacer '%1', %2 x %3</source>
        <translation />
    </message>
    <message>
        <source>Vertical Spacer '%1', %2 x %3</source>
        <translation />
    </message>
</context>
<context>
    <name>TemplateOptionsPage</name>
    <message>
        <source>Template Paths</source>
        <extracomment>Tab in preferences dialog</extracomment>
        <translation />
    </message>
</context>
<context>
    <name>ToolBarManager</name>
    <message>
        <source>Configure Toolbars...</source>
        <translation />
    </message>
    <message>
        <source>Window</source>
        <translation />
    </message>
    <message>
        <source>Help</source>
        <translation />
    </message>
    <message>
        <source>Style</source>
        <translation />
    </message>
    <message>
        <source>Dock views</source>
        <translation />
    </message>
    <message>
        <source>File</source>
        <translation />
    </message>
    <message>
        <source>Edit</source>
        <translation />
    </message>
    <message>
        <source>Tools</source>
        <translation />
    </message>
    <message>
        <source>Form</source>
        <translation />
    </message>
    <message>
        <source>Toolbars</source>
        <translation />
    </message>
</context>
<context>
    <name>VersionDialog</name>
    <message>
        <source>&lt;h3&gt;%1&lt;/h3&gt;&lt;br/&gt;&lt;br/&gt;Version %2</source>
        <translation />
    </message>
    <message>
        <source>Qt Widgets Designer</source>
        <translation />
    </message>
    <message>
        <source>&lt;br/&gt;Qt Widgets Designer is a graphical user interface designer for Qt applications.&lt;br/&gt;</source>
        <translation />
    </message>
    <message>
        <source>%1&lt;br/&gt;Copyright (C) The Qt Company Ltd. and other contributors.</source>
        <translation />
    </message>
</context>
<context>
    <name>WidgetDataBase</name>
    <message>
        <source>Abstract base class that cannot be instantiated. For promotion/custom widget usage only.</source>
        <translation />
    </message>
    <message>
        <source>The file contains a custom widget '%1' whose base class (%2) differs from the current entry in the widget database (%3). The widget database is left unchanged.</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::ActionEditor</name>
    <message>
        <source>Actions</source>
        <translation />
    </message>
    <message>
        <source>New...</source>
        <translation />
    </message>
    <message>
        <source>Delete</source>
        <translation />
    </message>
    <message>
        <source>New action</source>
        <translation />
    </message>
    <message>
        <source>Edit action</source>
        <translation />
    </message>
    <message>
        <source>Edit...</source>
        <translation />
    </message>
    <message>
        <source>Go to slot...</source>
        <translation />
    </message>
    <message>
        <source>Copy</source>
        <translation />
    </message>
    <message>
        <source>Cut</source>
        <translation />
    </message>
    <message>
        <source>Paste</source>
        <translation />
    </message>
    <message>
        <source>Select all</source>
        <translation />
    </message>
    <message>
        <source>Icon View</source>
        <translation />
    </message>
    <message>
        <source>Detailed View</source>
        <translation />
    </message>
    <message>
        <source>Filter</source>
        <translation />
    </message>
    <message>
        <source>Remove actions</source>
        <translation />
    </message>
    <message>
        <source>Remove action '%1'</source>
        <translation />
    </message>
    <message>
        <source>Used In</source>
        <translation />
    </message>
    <message>
        <source>Configure Action Editor</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::ActionModel</name>
    <message>
        <source>Name</source>
        <translation />
    </message>
    <message>
        <source>Used</source>
        <translation />
    </message>
    <message>
        <source>Text</source>
        <translation />
    </message>
    <message>
        <source>Shortcut</source>
        <translation />
    </message>
    <message>
        <source>Checkable</source>
        <translation />
    </message>
    <message>
        <source>ToolTip</source>
        <translation />
    </message>
    <message>
        <source>MenuRole</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::BuddyEditor</name>
    <message>
        <source>Add buddy</source>
        <translation />
    </message>
    <message>
        <source>Remove buddies</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>Remove %n buddies</source>
        <translation><numerusform>Buddy  löschen</numerusform>
            <numerusform>%n Buddies löschen</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>Add %n buddies</source>
        <translation><numerusform>Buddy hinzufügen</numerusform>
            <numerusform>%n Buddies hinzufügen</numerusform>
        </translation>
    </message>
    <message>
        <source>Set automatically</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::BuddyEditorPlugin</name>
    <message>
        <source>Edit Buddies</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::BuddyEditorTool</name>
    <message>
        <source>Edit Buddies</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::ButtonGroupMenu</name>
    <message>
        <source>Select members</source>
        <translation />
    </message>
    <message>
        <source>Break</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::ButtonTaskMenu</name>
    <message>
        <source>Assign to button group</source>
        <translation />
    </message>
    <message>
        <source>Button group</source>
        <translation />
    </message>
    <message>
        <source>New button group</source>
        <translation />
    </message>
    <message>
        <source>Change text...</source>
        <translation />
    </message>
    <message>
        <source>None</source>
        <translation />
    </message>
    <message>
        <source>Button group '%1'</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::CodeDialog</name>
    <message>
        <source>Save...</source>
        <translation />
    </message>
    <message>
        <source>Copy All</source>
        <translation />
    </message>
    <message>
        <source>A temporary form file could not be created in %1.</source>
        <translation />
    </message>
    <message>
        <source>The temporary form file %1 could not be written.</source>
        <translation />
    </message>
    <message>
        <source>%1 - [%2 Code]</source>
        <translation />
    </message>
    <message>
        <source>Save Code</source>
        <translation />
    </message>
    <message>
        <source>The file %1 could not be opened: %2</source>
        <translation />
    </message>
    <message>
        <source>The file %1 could not be written: %2</source>
        <translation />
    </message>
    <message>
        <source>%1 - Error</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::ColorAction</name>
    <message>
        <source>Text Color</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::ComboBoxTaskMenu</name>
    <message>
        <source>Edit Items...</source>
        <translation />
    </message>
    <message>
        <source>Change Combobox Contents</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::CommandLinkButtonTaskMenu</name>
    <message>
        <source>Change description...</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::ConnectionEdit</name>
    <message>
        <source>Select All</source>
        <translation />
    </message>
    <message>
        <source>Delete</source>
        <translation />
    </message>
    <message>
        <source>Deselect All</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::ConnectionModel</name>
    <message>
        <source>Sender</source>
        <translation />
    </message>
    <message>
        <source>Signal</source>
        <translation />
    </message>
    <message>
        <source>Receiver</source>
        <translation />
    </message>
    <message>
        <source>Slot</source>
        <translation />
    </message>
    <message>
        <source>&lt;sender&gt;</source>
        <translation />
    </message>
    <message>
        <source>&lt;signal&gt;</source>
        <translation />
    </message>
    <message>
        <source>&lt;receiver&gt;</source>
        <translation />
    </message>
    <message>
        <source>&lt;slot&gt;</source>
        <translation />
    </message>
    <message>
        <source>Signal and Slot Editor</source>
        <translation />
    </message>
    <message>
        <source>The connection already exists!&lt;br&gt;%1</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::ContainerWidgetTaskMenu</name>
    <message>
        <source>Insert Page Before Current Page</source>
        <translation />
    </message>
    <message>
        <source>Insert Page After Current Page</source>
        <translation />
    </message>
    <message>
        <source>Add Subwindow</source>
        <translation />
    </message>
    <message>
        <source>Delete</source>
        <translation />
    </message>
    <message>
        <source>Insert</source>
        <translation />
    </message>
    <message>
        <source>Subwindow</source>
        <translation />
    </message>
    <message>
        <source>Page</source>
        <translation />
    </message>
    <message>
        <source>Page %1 of %2</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::DPI_Chooser</name>
    <message>
        <source> x </source>
        <extracomment>DPI X/Y separator</extracomment>
        <translation />
    </message>
    <message>
        <source>System (%1 x %2)</source>
        <extracomment>System resolution</extracomment>
        <translation />
    </message>
    <message>
        <source>User defined</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::DesignerPropertyManager</name>
    <message>
        <source>id</source>
        <translation />
    </message>
    <message>
        <source>AlignLeft</source>
        <translation />
    </message>
    <message>
        <source>AlignHCenter</source>
        <translation />
    </message>
    <message>
        <source>AlignRight</source>
        <translation />
    </message>
    <message>
        <source>AlignJustify</source>
        <translation />
    </message>
    <message>
        <source>AlignTop</source>
        <translation />
    </message>
    <message>
        <source>AlignVCenter</source>
        <translation />
    </message>
    <message>
        <source>AlignBottom</source>
        <translation />
    </message>
    <message>
        <source>%1, %2</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>Customized (%n roles)</source>
        <translation><numerusform>Angepasst (eine Rolle)</numerusform>
            <numerusform>Angepasst (%n Rollen)</numerusform>
        </translation>
    </message>
    <message>
        <source>Inherited</source>
        <translation />
    </message>
    <message>
        <source>Horizontal</source>
        <translation />
    </message>
    <message>
        <source>Vertical</source>
        <translation />
    </message>
    <message>
        <source>Theme</source>
        <translation />
    </message>
    <message>
        <source>XDG Theme</source>
        <translation />
    </message>
    <message>
        <source>Normal Off</source>
        <translation />
    </message>
    <message>
        <source>Normal On</source>
        <translation />
    </message>
    <message>
        <source>Disabled Off</source>
        <translation />
    </message>
    <message>
        <source>Disabled On</source>
        <translation />
    </message>
    <message>
        <source>Active Off</source>
        <translation />
    </message>
    <message>
        <source>Active On</source>
        <translation />
    </message>
    <message>
        <source>Selected Off</source>
        <translation />
    </message>
    <message>
        <source>Selected On</source>
        <translation />
    </message>
    <message>
        <source>disambiguation</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::DeviceProfileDialog</name>
    <message>
        <source>Device Profiles (*.%1)</source>
        <translation />
    </message>
    <message>
        <source>Default</source>
        <translation />
    </message>
    <message>
        <source>Save Profile</source>
        <translation />
    </message>
    <message>
        <source>Save Profile - Error</source>
        <translation />
    </message>
    <message>
        <source>Unable to open the file '%1' for writing: %2</source>
        <translation />
    </message>
    <message>
        <source>Unable to open the file '%1' for reading: %2</source>
        <translation />
    </message>
    <message>
        <source>'%1' is not a valid profile: %2</source>
        <translation />
    </message>
    <message>
        <source>Open profile</source>
        <translation />
    </message>
    <message>
        <source>Open Profile - Error</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::Dialog</name>
    <message>
        <source>Dialog</source>
        <translation />
    </message>
    <message>
        <source>StringList</source>
        <translation />
    </message>
    <message>
        <source>New String</source>
        <translation />
    </message>
    <message>
        <source>&amp;New</source>
        <translation />
    </message>
    <message>
        <source>Delete String</source>
        <translation />
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation />
    </message>
    <message>
        <source>&amp;Value:</source>
        <translation />
    </message>
    <message>
        <source>Move String Up</source>
        <translation />
    </message>
    <message>
        <source>Up</source>
        <translation />
    </message>
    <message>
        <source>Move String Down</source>
        <translation />
    </message>
    <message>
        <source>Down</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::EmbeddedOptionsControl</name>
    <message>
        <source>None</source>
        <translation />
    </message>
    <message>
        <source>Add a profile</source>
        <translation />
    </message>
    <message>
        <source>Edit the selected profile</source>
        <translation />
    </message>
    <message>
        <source>Delete the selected profile</source>
        <translation />
    </message>
    <message>
        <source>Add Profile</source>
        <translation />
    </message>
    <message>
        <source>New profile</source>
        <translation />
    </message>
    <message>
        <source>Edit Profile</source>
        <translation />
    </message>
    <message>
        <source>Delete Profile</source>
        <translation />
    </message>
    <message>
        <source>Would you like to delete the profile '%1'?</source>
        <translation />
    </message>
    <message>
        <source>Default</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::FormEditor</name>
    <message>
        <source>Resource File Changed</source>
        <translation />
    </message>
    <message>
        <source>The file "%1" has changed outside Designer. Do you want to reload it?</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::FormLayoutMenu</name>
    <message>
        <source>Add form layout row...</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::FormWindow</name>
    <message>
        <source>Edit contents</source>
        <translation />
    </message>
    <message>
        <source>F2</source>
        <translation />
    </message>
    <message>
        <source>Resize</source>
        <translation />
    </message>
    <message>
        <source>Key Move</source>
        <translation />
    </message>
    <message>
        <source>Paste error</source>
        <translation />
    </message>
    <message>
        <source>Lay out</source>
        <translation />
    </message>
    <message>
        <source>Drop widget</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>Paste %n action(s)</source>
        <translation><numerusform>Eine Aktion einfügen</numerusform>
            <numerusform>%n Aktionen einfügen</numerusform>
        </translation>
    </message>
    <message>
        <source>Insert widget '%1'</source>
        <translation />
    </message>
    <message>
        <source>Key Resize</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>Paste %n widget(s)</source>
        <translation><numerusform>Widget einfügen</numerusform>
            <numerusform>%n Widgets einfügen</numerusform>
        </translation>
    </message>
    <message>
        <source>Paste (%1 widgets, %2 actions)</source>
        <translation />
    </message>
    <message>
        <source>Cannot paste widgets. Designer could not find a container without a layout to paste into.</source>
        <translation />
    </message>
    <message>
        <source>Break the layout of the container you want to paste into, select this container and then paste again.</source>
        <translation />
    </message>
    <message>
        <source>Select Ancestor</source>
        <translation />
    </message>
    <message>
        <source>A QMainWindow-based form does not contain a central widget.</source>
        <translation />
    </message>
    <message>
        <source>Raise widgets</source>
        <translation />
    </message>
    <message>
        <source>Lower widgets</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::FormWindowBase</name>
    <message>
        <source>Delete</source>
        <translation />
    </message>
    <message>
        <source>Delete '%1'</source>
        <translation />
    </message>
    <message>
        <source>Invalid form</source>
        <translation />
    </message>
    <message>
        <source>&lt;p&gt;This file contains top level spacers.&lt;br/&gt;They will &lt;b&gt;not&lt;/b&gt; be saved.&lt;/p&gt;&lt;p&gt;Perhaps you forgot to create a layout?&lt;/p&gt;</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::FormWindowManager</name>
    <message>
        <source>Cu&amp;t</source>
        <translation />
    </message>
    <message>
        <source>Cuts the selected widgets and puts them on the clipboard</source>
        <translation />
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation />
    </message>
    <message>
        <source>Copies the selected widgets to the clipboard</source>
        <translation />
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation />
    </message>
    <message>
        <source>Pastes the clipboard's contents</source>
        <translation />
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation />
    </message>
    <message>
        <source>Deletes the selected widgets</source>
        <translation />
    </message>
    <message>
        <source>Select &amp;All</source>
        <translation />
    </message>
    <message>
        <source>Selects all widgets</source>
        <translation />
    </message>
    <message>
        <source>Bring to &amp;Front</source>
        <translation />
    </message>
    <message>
        <source>Raises the selected widgets</source>
        <translation />
    </message>
    <message>
        <source>Send to &amp;Back</source>
        <translation />
    </message>
    <message>
        <source>Lowers the selected widgets</source>
        <translation />
    </message>
    <message>
        <source>Adjust &amp;Size</source>
        <translation />
    </message>
    <message>
        <source>Adjusts the size of the selected widget</source>
        <translation />
    </message>
    <message>
        <source>Lay Out &amp;Horizontally</source>
        <translation />
    </message>
    <message>
        <source>Lays out the selected widgets horizontally</source>
        <translation />
    </message>
    <message>
        <source>Lay Out &amp;Vertically</source>
        <translation />
    </message>
    <message>
        <source>Lays out the selected widgets vertically</source>
        <translation />
    </message>
    <message>
        <source>Lay Out in a &amp;Grid</source>
        <translation />
    </message>
    <message>
        <source>Lays out the selected widgets in a grid</source>
        <translation />
    </message>
    <message>
        <source>Lay Out Horizontally in S&amp;plitter</source>
        <translation />
    </message>
    <message>
        <source>Lays out the selected widgets horizontally in a splitter</source>
        <translation />
    </message>
    <message>
        <source>Lay Out Vertically in Sp&amp;litter</source>
        <translation />
    </message>
    <message>
        <source>Lays out the selected widgets vertically in a splitter</source>
        <translation />
    </message>
    <message>
        <source>&amp;Break Layout</source>
        <translation />
    </message>
    <message>
        <source>Breaks the selected layout</source>
        <translation />
    </message>
    <message>
        <source>&amp;Preview...</source>
        <translation />
    </message>
    <message>
        <source>Preview current form</source>
        <translation />
    </message>
    <message>
        <source>Form &amp;Settings...</source>
        <translation />
    </message>
    <message>
        <source>Break Layout</source>
        <translation />
    </message>
    <message>
        <source>Adjust Size</source>
        <translation />
    </message>
    <message>
        <source>Could not create form preview</source>
        <comment>Title of warning message box</comment>
        <translation />
    </message>
    <message>
        <source>Form Settings - %1</source>
        <translation />
    </message>
    <message>
        <source>Removes empty columns and rows</source>
        <translation />
    </message>
    <message>
        <source>Lay Out in a &amp;Form Layout</source>
        <translation />
    </message>
    <message>
        <source>Lays out the selected widgets in a form layout</source>
        <translation />
    </message>
    <message>
        <source>Si&amp;mplify Grid Layout</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::FormWindowSettings</name>
    <message>
        <source>None</source>
        <translation />
    </message>
    <message>
        <source>Device Profile: %1</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::GridPanel</name>
    <message>
        <source>Visible</source>
        <translation />
    </message>
    <message>
        <source>Snap</source>
        <translation />
    </message>
    <message>
        <source>Reset</source>
        <translation />
    </message>
    <message>
        <source>Form</source>
        <translation />
    </message>
    <message>
        <source>Grid</source>
        <translation />
    </message>
    <message>
        <source>Grid &amp;X</source>
        <translation />
    </message>
    <message>
        <source>Grid &amp;Y</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::GroupBoxTaskMenu</name>
    <message>
        <source>Change title...</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::HtmlTextEdit</name>
    <message>
        <source>Insert HTML entity</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::IconThemeDialog</name>
    <message>
        <source>Set Icon From XDG Theme</source>
        <translation />
    </message>
    <message>
        <source>Select icon name from XDG theme:</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::ItemListEditor</name>
    <message>
        <source>Properties &amp;&lt;&lt;</source>
        <translation />
    </message>
    <message>
        <source>Properties &amp;&gt;&gt;</source>
        <translation />
    </message>
    <message>
        <source>Items List</source>
        <translation />
    </message>
    <message>
        <source>New Item</source>
        <translation />
    </message>
    <message>
        <source>&amp;New</source>
        <translation />
    </message>
    <message>
        <source>Delete Item</source>
        <translation />
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation />
    </message>
    <message>
        <source>Move Item Up</source>
        <translation />
    </message>
    <message>
        <source>U</source>
        <translation />
    </message>
    <message>
        <source>Move Item Down</source>
        <translation />
    </message>
    <message>
        <source>D</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::LabelTaskMenu</name>
    <message>
        <source>Change rich text...</source>
        <translation />
    </message>
    <message>
        <source>Change plain text...</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::LanguageResourceDialog</name>
    <message>
        <source>Choose Resource</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::LineEditTaskMenu</name>
    <message>
        <source>Change text...</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::ListWidgetEditor</name>
    <message>
        <source>Edit List Widget</source>
        <translation />
    </message>
    <message>
        <source>Edit Combobox</source>
        <translation />
    </message>
    <message>
        <source>New Item</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::ListWidgetTaskMenu</name>
    <message>
        <source>Edit Items...</source>
        <translation />
    </message>
    <message>
        <source>Change List Contents</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::MdiContainerWidgetTaskMenu</name>
    <message>
        <source>Next Subwindow</source>
        <translation />
    </message>
    <message>
        <source>Previous Subwindow</source>
        <translation />
    </message>
    <message>
        <source>Tile</source>
        <translation />
    </message>
    <message>
        <source>Cascade</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::MenuTaskMenu</name>
    <message>
        <source>Remove</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::MorphMenu</name>
    <message>
        <source>Morph into</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::NewActionDialog</name>
    <message>
        <source>New Action...</source>
        <translation />
    </message>
    <message>
        <source>&amp;Text:</source>
        <translation />
    </message>
    <message>
        <source>...</source>
        <translation />
    </message>
    <message>
        <source>&amp;Icon:</source>
        <translation />
    </message>
    <message>
        <source>Object &amp;name:</source>
        <translation />
    </message>
    <message>
        <source>T&amp;oolTip:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Checkable:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Shortcut:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Menu role:</source>
        <translation />
    </message>
    <message>
        <source>Icon &amp;XDG theme:</source>
        <translation />
    </message>
    <message>
        <source>Icon &amp;theme:</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::NewDynamicPropertyDialog</name>
    <message>
        <source>Set Property Name</source>
        <translation />
    </message>
    <message>
        <source>The current object already has a property named '%1'.
Please select another, unique one.</source>
        <translation />
    </message>
    <message>
        <source>Create Dynamic Property</source>
        <translation />
    </message>
    <message>
        <source>Property Name</source>
        <translation />
    </message>
    <message>
        <source>Property Type</source>
        <translation />
    </message>
    <message>
        <source>The '_q_' prefix is reserved for the Qt library.
Please select another name.</source>
        <translation />
    </message>
    <message>
        <source>horizontalSpacer</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::NewFormWidget</name>
    <message>
        <source>Default size</source>
        <translation />
    </message>
    <message>
        <source>QVGA portrait (240x320)</source>
        <translation />
    </message>
    <message>
        <source>QVGA landscape (320x240)</source>
        <translation />
    </message>
    <message>
        <source>VGA portrait (480x640)</source>
        <translation />
    </message>
    <message>
        <source>VGA landscape (640x480)</source>
        <translation />
    </message>
    <message>
        <source>Widgets</source>
        <extracomment>New Form Dialog Categories</extracomment>
        <translation />
    </message>
    <message>
        <source>Custom Widgets</source>
        <translation />
    </message>
    <message>
        <source>None</source>
        <translation />
    </message>
    <message>
        <source>Error loading form</source>
        <translation />
    </message>
    <message>
        <source>Unable to open the form template file '%1': %2</source>
        <translation />
    </message>
    <message>
        <source>Internal error: No template selected.</source>
        <translation />
    </message>
    <message>
        <source>0</source>
        <translation />
    </message>
    <message>
        <source>Choose a template for a preview</source>
        <translation />
    </message>
    <message>
        <source>Embedded Design</source>
        <translation />
    </message>
    <message>
        <source>Device:</source>
        <translation />
    </message>
    <message>
        <source>Screen Size:</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::NewPromotedClassPanel</name>
    <message>
        <source>Add</source>
        <translation />
    </message>
    <message>
        <source>New Promoted Class</source>
        <translation />
    </message>
    <message>
        <source>Base class name:</source>
        <translation />
    </message>
    <message>
        <source>Promoted class name:</source>
        <translation />
    </message>
    <message>
        <source>Header file for C++ classes or module name for Qt for Python.</source>
        <translation />
    </message>
    <message>
        <source>Header file:</source>
        <translation />
    </message>
    <message>
        <source>Indicates that the header file is a global header file. Does not have any effect on Qt for Python.</source>
        <translation />
    </message>
    <message>
        <source>Global include</source>
        <translation />
    </message>
    <message>
        <source>Reset</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::ObjectInspector</name>
    <message>
        <source>Filter</source>
        <translation />
    </message>
    <message>
        <source>Change Current Page</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::OrderDialog</name>
    <message>
        <source>Index %1 (%2)</source>
        <translation />
    </message>
    <message>
        <source>Change Page Order</source>
        <translation />
    </message>
    <message>
        <source>Page Order</source>
        <translation />
    </message>
    <message>
        <source>Move page up</source>
        <translation />
    </message>
    <message>
        <source>Move page down</source>
        <translation />
    </message>
    <message>
        <source>%1 %2</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PaletteEditor</name>
    <message>
        <source>Edit Palette</source>
        <translation />
    </message>
    <message>
        <source>Tune Palette</source>
        <translation />
    </message>
    <message>
        <source>Show Details</source>
        <translation />
    </message>
    <message>
        <source>Compute Details</source>
        <translation />
    </message>
    <message>
        <source>Quick</source>
        <translation />
    </message>
    <message>
        <source>Preview</source>
        <translation />
    </message>
    <message>
        <source>Disabled</source>
        <translation />
    </message>
    <message>
        <source>Inactive</source>
        <translation />
    </message>
    <message>
        <source>Active</source>
        <translation />
    </message>
    <message>
        <source>Save...</source>
        <translation />
    </message>
    <message>
        <source>Load...</source>
        <translation />
    </message>
    <message>
        <source>Preview (%1)</source>
        <translation />
    </message>
    <message>
        <source>Lighter</source>
        <translation />
    </message>
    <message>
        <source>Darker</source>
        <translation />
    </message>
    <message>
        <source>Copy color %1</source>
        <translation />
    </message>
    <message>
        <source>QPalette UI file (*.xml)</source>
        <translation />
    </message>
    <message>
        <source>Cannot open %1 for writing: %2</source>
        <translation />
    </message>
    <message>
        <source>Cannot write %1: %2</source>
        <translation />
    </message>
    <message>
        <source>Cannot read palette from %1:%2:%3</source>
        <translation />
    </message>
    <message>
        <source>Cannot open %1 for reading: %2</source>
        <translation />
    </message>
    <message>
        <source>Invalid element "%1", expected "palette".</source>
        <translation />
    </message>
    <message>
        <source>Save Palette</source>
        <translation />
    </message>
    <message>
        <source>Error Writing Palette</source>
        <translation />
    </message>
    <message>
        <source>Load Palette</source>
        <translation />
    </message>
    <message>
        <source>Error Reading Palette</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PaletteEditorButton</name>
    <message>
        <source>Change Palette</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PaletteModel</name>
    <message>
        <source>Color Role</source>
        <translation />
    </message>
    <message>
        <source>Active</source>
        <translation />
    </message>
    <message>
        <source>Inactive</source>
        <translation />
    </message>
    <message>
        <source>Disabled</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PixmapEditor</name>
    <message>
        <source>Copy Path</source>
        <translation />
    </message>
    <message>
        <source>Paste Path</source>
        <translation />
    </message>
    <message>
        <source>Choose Resource...</source>
        <translation />
    </message>
    <message>
        <source>Choose File...</source>
        <translation />
    </message>
    <message>
        <source>Set Icon From Theme...</source>
        <translation />
    </message>
    <message>
        <source>Set Icon From XDG Theme...</source>
        <translation />
    </message>
    <message>
        <source>...</source>
        <translation />
    </message>
    <message>
        <source>[Theme] %1</source>
        <translation />
    </message>
    <message>
        <source>[Theme] %1 (missing)</source>
        <translation />
    </message>
    <message>
        <source>%1 (fallback)</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PlainTextEditorDialog</name>
    <message>
        <source>Edit text</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PluginDialog</name>
    <message>
        <source>Components</source>
        <translation />
    </message>
    <message>
        <source>Plugin Information</source>
        <translation />
    </message>
    <message>
        <source>Refresh</source>
        <translation />
    </message>
    <message>
        <source>Scan for newly installed custom widget plugins.</source>
        <translation />
    </message>
    <message>
        <source>Loaded Plugins</source>
        <translation />
    </message>
    <message>
        <source>Failed Plugins</source>
        <translation />
    </message>
    <message>
        <source>Qt Widgets Designer couldn't find any plugins</source>
        <translation />
    </message>
    <message>
        <source>Qt Widgets Designer found the following plugins</source>
        <translation />
    </message>
    <message>
        <source>New custom widget plugins have been found.</source>
        <translation />
    </message>
    <message>
        <source>Copy</source>
        <extracomment>Copy error text</extracomment>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PreviewActionGroup</name>
    <message>
        <source>%1 Style</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PreviewConfigurationWidget</name>
    <message>
        <source>Default</source>
        <translation />
    </message>
    <message>
        <source>None</source>
        <translation />
    </message>
    <message>
        <source>Browse...</source>
        <translation />
    </message>
    <message>
        <source>Load Custom Device Skin</source>
        <translation />
    </message>
    <message>
        <source>All QVFB Skins (*.%1)</source>
        <translation />
    </message>
    <message>
        <source>%1 - Duplicate Skin</source>
        <translation />
    </message>
    <message>
        <source>The skin '%1' already exists.</source>
        <translation />
    </message>
    <message>
        <source>%1 - Error</source>
        <translation />
    </message>
    <message>
        <source>%1 is not a valid skin directory:
%2</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PreviewDeviceSkin</name>
    <message>
        <source>&amp;Portrait</source>
        <translation />
    </message>
    <message>
        <source>Landscape (&amp;CCW)</source>
        <extracomment>Rotate form preview counter-clockwise</extracomment>
        <translation />
    </message>
    <message>
        <source>&amp;Landscape (CW)</source>
        <extracomment>Rotate form preview clockwise</extracomment>
        <translation />
    </message>
    <message>
        <source>&amp;Close</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PreviewManager</name>
    <message>
        <source>%1 - [Preview]</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PreviewMdiArea</name>
    <message>
        <source>The moose in the noose
ate the goose who was loose.</source>
        <extracomment>Palette editor background</extracomment>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PreviewWidget</name>
    <message>
        <source>Preview Window</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>LineEdit</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>ComboBox</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>PushButton</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>CheckBox1</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>RadioButton1</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>RadioButton2</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>RadioButton3</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>Buttons</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>Tristate CheckBox</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>ToggleButton</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>ToolButton</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>Menu</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>Item Views</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>Column 1</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>Top Level 1</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>Nested Item 1</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>Nested Item 2</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>Nested Item 3</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>Simple Input Widgets</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>Item1</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>Item2</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>Display Widgets</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>QLabel</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>QLabel with frame</source>
        <extracomment>Palette Editor Preview Widget</extracomment>
        <translation />
    </message>
    <message>
        <source>Option 1</source>
        <translation />
    </message>
    <message>
        <source>Checkable</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PromotionModel</name>
    <message>
        <source>Name</source>
        <translation />
    </message>
    <message>
        <source>Header file</source>
        <translation />
    </message>
    <message>
        <source>Global include</source>
        <translation />
    </message>
    <message>
        <source>Usage</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PromotionTaskMenu</name>
    <message>
        <source>Promoted widgets...</source>
        <translation />
    </message>
    <message>
        <source>Promote to ...</source>
        <translation />
    </message>
    <message>
        <source>Promote to</source>
        <translation />
    </message>
    <message>
        <source>Demote to %1</source>
        <translation />
    </message>
    <message>
        <source>Change signals/slots...</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PropertyEditor</name>
    <message>
        <source>Add Dynamic Property...</source>
        <translation />
    </message>
    <message>
        <source>Remove Dynamic Property</source>
        <translation />
    </message>
    <message>
        <source>Tree View</source>
        <translation />
    </message>
    <message>
        <source>Drop Down Button View</source>
        <translation />
    </message>
    <message>
        <source>Filter</source>
        <translation />
    </message>
    <message>
        <source>Object: %1
Class: %2</source>
        <translation />
    </message>
    <message>
        <source>Sorting</source>
        <translation />
    </message>
    <message>
        <source>Color Groups</source>
        <translation />
    </message>
    <message>
        <source>Configure Property Editor</source>
        <translation />
    </message>
    <message>
        <source>String...</source>
        <translation />
    </message>
    <message>
        <source>Bool...</source>
        <translation />
    </message>
    <message>
        <source>Other...</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PropertyLineEdit</name>
    <message>
        <source>Insert line break</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::QDesignerPromotionDialog</name>
    <message>
        <source>Promoted Widgets</source>
        <translation />
    </message>
    <message>
        <source>Promoted Classes</source>
        <translation />
    </message>
    <message>
        <source>Promote</source>
        <translation />
    </message>
    <message>
        <source>%1 - Error</source>
        <translation />
    </message>
    <message>
        <source>Change signals/slots...</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::QDesignerResource</name>
    <message>
        <source>Loading qrc file</source>
        <translation />
    </message>
    <message>
        <source>The specified qrc file &lt;p&gt;&lt;b&gt;%1&lt;/b&gt;&lt;/p&gt;&lt;p&gt;could not be found. Do you want to update the file location?&lt;/p&gt;</source>
        <translation />
    </message>
    <message>
        <source>New location for %1</source>
        <translation />
    </message>
    <message>
        <source>Resource files (*.qrc)</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::QDesignerTaskMenu</name>
    <message>
        <source>Change objectName...</source>
        <translation />
    </message>
    <message>
        <source>Change toolTip...</source>
        <translation />
    </message>
    <message>
        <source>Change whatsThis...</source>
        <translation />
    </message>
    <message>
        <source>Change styleSheet...</source>
        <translation />
    </message>
    <message>
        <source>Create Menu Bar</source>
        <translation />
    </message>
    <message>
        <source>Add Tool Bar</source>
        <translation />
    </message>
    <message>
        <source>Create Status Bar</source>
        <translation />
    </message>
    <message>
        <source>Remove Status Bar</source>
        <translation />
    </message>
    <message>
        <source>Change signals/slots...</source>
        <translation />
    </message>
    <message>
        <source>Go to slot...</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>Set size constraint on %n widget(s)</source>
        <translation><numerusform>Größenbeschränkung eines Widgets festlegen</numerusform>
            <numerusform>Größenbeschränkung von %n Widgets festlegen</numerusform>
        </translation>
    </message>
    <message>
        <source>Size Constraints</source>
        <translation />
    </message>
    <message>
        <source>Layout Alignment</source>
        <translation />
    </message>
    <message>
        <source>No Horizontal Alignment</source>
        <translation />
    </message>
    <message>
        <source>Left</source>
        <translation />
    </message>
    <message>
        <source>Center Horizontally</source>
        <translation />
    </message>
    <message>
        <source>Right</source>
        <translation />
    </message>
    <message>
        <source>No Vertical Alignment</source>
        <translation />
    </message>
    <message>
        <source>Top</source>
        <translation />
    </message>
    <message>
        <source>Center Vertically</source>
        <translation />
    </message>
    <message>
        <source>Bottom</source>
        <translation />
    </message>
    <message>
        <source>Add Tool Bar to Other Area</source>
        <translation />
    </message>
    <message>
        <source>Set Minimum Width</source>
        <translation />
    </message>
    <message>
        <source>Set Minimum Height</source>
        <translation />
    </message>
    <message>
        <source>Set Minimum Size</source>
        <translation />
    </message>
    <message>
        <source>Set Maximum Width</source>
        <translation />
    </message>
    <message>
        <source>Set Maximum Height</source>
        <translation />
    </message>
    <message>
        <source>Set Maximum Size</source>
        <translation />
    </message>
    <message>
        <source>Edit ToolTip</source>
        <translation />
    </message>
    <message>
        <source>Edit WhatsThis</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::QDesignerWidgetBox</name>
    <message>
        <source>Unexpected element &lt;%1&gt;</source>
        <translation />
    </message>
    <message>
        <source>A parse error occurred at line %1, column %2 of the XML code specified for the widget %3: %4
%5</source>
        <translation />
    </message>
    <message>
        <source>The XML code specified for the widget %1 does not contain any widget elements.
%2</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::QtGradientStopsController</name>
    <message>
        <source>H</source>
        <translation />
    </message>
    <message>
        <source>S</source>
        <translation />
    </message>
    <message>
        <source>V</source>
        <translation />
    </message>
    <message>
        <source>Hue</source>
        <translation />
    </message>
    <message>
        <source>Sat</source>
        <translation />
    </message>
    <message>
        <source>Val</source>
        <translation />
    </message>
    <message>
        <source>Saturation</source>
        <translation />
    </message>
    <message>
        <source>Value</source>
        <translation />
    </message>
    <message>
        <source>R</source>
        <translation />
    </message>
    <message>
        <source>G</source>
        <translation />
    </message>
    <message>
        <source>B</source>
        <translation />
    </message>
    <message>
        <source>Red</source>
        <translation />
    </message>
    <message>
        <source>Green</source>
        <translation />
    </message>
    <message>
        <source>Blue</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::RichTextEditorDialog</name>
    <message>
        <source>Edit text</source>
        <translation />
    </message>
    <message>
        <source>&amp;OK</source>
        <translation />
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation />
    </message>
    <message>
        <source>Rich Text</source>
        <translation />
    </message>
    <message>
        <source>Source</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::RichTextEditorToolBar</name>
    <message>
        <source>Bold</source>
        <translation />
    </message>
    <message>
        <source>CTRL+B</source>
        <translation />
    </message>
    <message>
        <source>Italic</source>
        <translation />
    </message>
    <message>
        <source>CTRL+I</source>
        <translation />
    </message>
    <message>
        <source>Underline</source>
        <translation />
    </message>
    <message>
        <source>CTRL+U</source>
        <translation />
    </message>
    <message>
        <source>Left Align</source>
        <translation />
    </message>
    <message>
        <source>Center</source>
        <translation />
    </message>
    <message>
        <source>Right Align</source>
        <translation />
    </message>
    <message>
        <source>Justify</source>
        <translation />
    </message>
    <message>
        <source>Right to Left</source>
        <translation />
    </message>
    <message>
        <source>Superscript</source>
        <translation />
    </message>
    <message>
        <source>Subscript</source>
        <translation />
    </message>
    <message>
        <source>Insert &amp;Link</source>
        <translation />
    </message>
    <message>
        <source>Insert &amp;Image</source>
        <translation />
    </message>
    <message>
        <source>Simplify Rich Text</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::SignalSlotDialog</name>
    <message>
        <source>There is already a slot with the signature '%1'.</source>
        <translation />
    </message>
    <message>
        <source>There is already a signal with the signature '%1'.</source>
        <translation />
    </message>
    <message>
        <source>%1 - Duplicate Signature</source>
        <translation />
    </message>
    <message>
        <source>Signals/Slots of %1</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::SignalSlotEditorPlugin</name>
    <message>
        <source>Edit Signals/Slots</source>
        <translation />
    </message>
    <message>
        <source>F4</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::SignalSlotEditorTool</name>
    <message>
        <source>Edit Signals/Slots</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::StatusBarTaskMenu</name>
    <message>
        <source>Remove</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::StringListEditorButton</name>
    <message>
        <source>Change String List</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::StyleSheetEditorDialog</name>
    <message>
        <source>Edit Style Sheet</source>
        <translation />
    </message>
    <message>
        <source>Valid Style Sheet</source>
        <translation />
    </message>
    <message>
        <source>Invalid Style Sheet</source>
        <translation />
    </message>
    <message>
        <source>Add Resource...</source>
        <translation />
    </message>
    <message>
        <source>Add Gradient...</source>
        <translation />
    </message>
    <message>
        <source>Add Color...</source>
        <translation />
    </message>
    <message>
        <source>Add Font...</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::TabOrderEditor</name>
    <message>
        <source>Start from Here</source>
        <translation />
    </message>
    <message>
        <source>Restart</source>
        <translation />
    </message>
    <message>
        <source>Tab Order List...</source>
        <translation />
    </message>
    <message>
        <source>Tab Order List</source>
        <translation />
    </message>
    <message>
        <source>Tab Order</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::TabOrderEditorPlugin</name>
    <message>
        <source>Edit Tab Order</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::TabOrderEditorTool</name>
    <message>
        <source>Edit Tab Order</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::TableWidgetEditor</name>
    <message>
        <source>New Column</source>
        <translation />
    </message>
    <message>
        <source>New Row</source>
        <translation />
    </message>
    <message>
        <source>&amp;Columns</source>
        <translation />
    </message>
    <message>
        <source>&amp;Rows</source>
        <translation />
    </message>
    <message>
        <source>Properties &amp;&lt;&lt;</source>
        <translation />
    </message>
    <message>
        <source>Properties &amp;&gt;&gt;</source>
        <translation />
    </message>
    <message>
        <source>Edit Table Widget</source>
        <translation />
    </message>
    <message>
        <source>&amp;Items</source>
        <translation />
    </message>
    <message>
        <source>Table Items</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::TableWidgetTaskMenu</name>
    <message>
        <source>Edit Items...</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::TemplateOptionsWidget</name>
    <message>
        <source>Pick a directory to save templates in</source>
        <translation />
    </message>
    <message>
        <source>Form</source>
        <translation />
    </message>
    <message>
        <source>Additional Template Paths</source>
        <translation />
    </message>
    <message>
        <source>...</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::TextEditTaskMenu</name>
    <message>
        <source>Change HTML...</source>
        <translation />
    </message>
    <message>
        <source>Edit HTML</source>
        <translation />
    </message>
    <message>
        <source>Edit Text</source>
        <translation />
    </message>
    <message>
        <source>Change Plain Text...</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::TextEditor</name>
    <message>
        <source>Choose Resource...</source>
        <translation />
    </message>
    <message>
        <source>Choose File...</source>
        <translation />
    </message>
    <message>
        <source>Choose a File</source>
        <translation />
    </message>
    <message>
        <source>...</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::ToolBarEventFilter</name>
    <message>
        <source>Insert Separator</source>
        <translation />
    </message>
    <message>
        <source>Remove action '%1'</source>
        <translation />
    </message>
    <message>
        <source>Remove Toolbar '%1'</source>
        <translation />
    </message>
    <message>
        <source>Insert Separator before '%1'</source>
        <translation />
    </message>
    <message>
        <source>Append Separator</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::TreeWidgetEditor</name>
    <message>
        <source>&amp;Columns</source>
        <translation />
    </message>
    <message>
        <source>Per column properties</source>
        <translation />
    </message>
    <message>
        <source>Common properties</source>
        <translation />
    </message>
    <message>
        <source>New Item</source>
        <translation />
    </message>
    <message>
        <source>Properties &amp;&lt;&lt;</source>
        <translation />
    </message>
    <message>
        <source>Properties &amp;&gt;&gt;</source>
        <translation />
    </message>
    <message>
        <source>New Column</source>
        <translation />
    </message>
    <message>
        <source>Edit Tree Widget</source>
        <translation />
    </message>
    <message>
        <source>&amp;Items</source>
        <translation />
    </message>
    <message>
        <source>Tree Items</source>
        <translation />
    </message>
    <message>
        <source>New Subitem</source>
        <translation />
    </message>
    <message>
        <source>New &amp;Subitem</source>
        <translation />
    </message>
    <message>
        <source>Delete Item</source>
        <translation />
    </message>
    <message>
        <source>Move Item Left (before Parent Item)</source>
        <translation />
    </message>
    <message>
        <source>L</source>
        <translation />
    </message>
    <message>
        <source>Move Item Right (as a First Subitem of the Next Sibling Item)</source>
        <translation />
    </message>
    <message>
        <source>R</source>
        <translation />
    </message>
    <message>
        <source>Move Item Up</source>
        <translation />
    </message>
    <message>
        <source>U</source>
        <translation />
    </message>
    <message>
        <source>Move Item Down</source>
        <translation />
    </message>
    <message>
        <source>D</source>
        <translation />
    </message>
    <message>
        <source>1</source>
        <translation />
    </message>
    <message>
        <source>&amp;New</source>
        <translation />
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::TreeWidgetTaskMenu</name>
    <message>
        <source>Edit Items...</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::WidgetBox</name>
    <message>
        <source>Warning: Widget creation failed in the widget box. This could be caused by invalid custom widget XML.</source>
        <translation />
    </message>
    <message>
        <source>Filter</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::WidgetBoxTreeWidget</name>
    <message>
        <source>Scratchpad</source>
        <translation />
    </message>
    <message>
        <source>Custom Widgets</source>
        <translation />
    </message>
    <message>
        <source>Expand all</source>
        <translation />
    </message>
    <message>
        <source>Collapse all</source>
        <translation />
    </message>
    <message>
        <source>List View</source>
        <translation />
    </message>
    <message>
        <source>Icon View</source>
        <translation />
    </message>
    <message>
        <source>Remove</source>
        <translation />
    </message>
    <message>
        <source>Edit name</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::WidgetDataBase</name>
    <message>
        <source>A custom widget plugin whose class name (%1) matches that of an existing class has been found.</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::WidgetEditorTool</name>
    <message>
        <source>Edit Widgets</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::WidgetFactory</name>
    <message>
        <source>The custom widget factory registered for widgets of class %1 returned 0.</source>
        <translation />
    </message>
    <message>
        <source>A class name mismatch occurred when creating a widget using the custom widget factory registered for widgets of class %1. It returned a widget of class %2.</source>
        <translation />
    </message>
    <message>
        <source>The current page of the container '%1' (%2) could not be determined while creating a layout.This indicates an inconsistency in the ui-file, probably a layout being constructed on a container widget.</source>
        <translation />
    </message>
    <message>
        <source>Attempt to add a layout to a widget '%1' (%2) which already has an unmanaged layout of type %3.
This indicates an inconsistency in the ui-file.</source>
        <translation />
    </message>
    <message>
        <source>Cannot create style '%1'.</source>
        <translation />
    </message>
    <message>
        <source>%1 Widget</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::WizardContainerWidgetTaskMenu</name>
    <message>
        <source>Next</source>
        <translation />
    </message>
    <message>
        <source>Back</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::ZoomMenu</name>
    <message>
        <source>%1 %</source>
        <extracomment>Zoom factor</extracomment>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::ZoomablePreviewDeviceSkin</name>
    <message>
        <source>&amp;Zoom</source>
        <translation />
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Dialog</source>
        <translation />
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>MainWindow</source>
        <translation />
    </message>
</context>
<context>
    <name>Form</name>
    <message>
        <source>Form</source>
        <translation />
    </message>
</context>
<context>
    <name>QDesignerWidgetBox</name>
    <message>
        <source>An error has been encountered at line %1 of %2: %3</source>
        <translation />
    </message>
    <message>
        <source>Unexpected element &lt;%1&gt; encountered when parsing for &lt;widget&gt; or &lt;ui&gt;</source>
        <translation />
    </message>
    <message>
        <source>Unexpected end of file encountered when parsing widgets.</source>
        <translation />
    </message>
    <message>
        <source>A widget element could not be found.</source>
        <translation />
    </message>
</context>
<context>
    <name>QView3DPlugin</name>
    <message>
        <source>3D View</source>
        <translation />
    </message>
</context>
<context>
    <name>QView3DTool</name>
    <message>
        <source>3DView</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::PropertySheetValue</name>
    <message>
        <source>translatable</source>
        <translation />
    </message>
    <message>
        <source>comment</source>
        <translation />
    </message>
</context>
<context>
    <name>qdesigner_internal::IconThemeEnumDialog</name>
    <message>
        <source>Set Icon From Theme</source>
        <translation />
    </message>
    <message>
        <source>Select icon name from theme:</source>
        <translation />
    </message>
</context>
</TS>