<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CInfoDlgPack</name>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/upgrade_info.cpp" line="37"/>
        <source>升级中...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.ui" line="20"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.ui" line="41"/>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="286"/>
        <source>选择目录</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.ui" line="85"/>
        <source>应用当前版本：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.ui" line="74"/>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.ui" line="92"/>
        <source>未发现</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.ui" line="67"/>
        <source>平台当前版本：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.ui" line="123"/>
        <source>升级包列表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.ui" line="136"/>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="483"/>
        <source>系统停止</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.ui" line="156"/>
        <source>开始升级</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.ui" line="170"/>
        <source>详细信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="134"/>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="200"/>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="324"/>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="331"/>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="443"/>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="449"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="200"/>
        <source>请选择连续的升级包</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="308"/>
        <source>未选择路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="324"/>
        <source>未选择升级包</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="331"/>
        <source>系统已启动，请先停止系统</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="109"/>
        <source>包名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="109"/>
        <source>操作系统名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="109"/>
        <source>需要平台版本</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="109"/>
        <source>需要应用版本</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="109"/>
        <source>目标平台版本</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="110"/>
        <source>目标应用版本</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="134"/>
        <source>当前目录未发现升级包</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="355"/>
        <source>升级包信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="365"/>
        <source>更新包名称: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="367"/>
        <source>发行系统版本: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="369"/>
        <source>需要平台版本: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="371"/>
        <source>需要应用版本: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="373"/>
        <source>目标平台版本: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="375"/>
        <source>目标应用版本: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="377"/>
        <source>更新项总数: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="383"/>
        <source>更新项信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="386"/>
        <source>数据库文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="388"/>
        <source>配置文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="390"/>
        <source>脚本文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="392"/>
        <source>普通文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="443"/>
        <source>系统未启动</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="449"/>
        <source>确认要停止系统吗？</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="401"/>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="407"/>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="413"/>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="419"/>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="425"/>
        <source>更新项路径: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="491"/>
        <source>系统退出中</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/mainwindow.cpp" line="505"/>
        <source>系统升级工具</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/upgrade_info.cpp" line="34"/>
        <source>升级中...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpgradeInfo</name>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/upgrade_info.ui" line="20"/>
        <source>UpgradeInfo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/upgrade_info.ui" line="28"/>
        <source>信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/upgrade_info.ui" line="45"/>
        <source>0/10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/upgrade_info.ui" line="81"/>
        <source>退出工具</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/upgrade_info.cpp" line="113"/>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/upgrade_info.cpp" line="117"/>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/upgrade_info.cpp" line="121"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/upgrade_info.cpp" line="113"/>
        <source>升级失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/upgrade_info.cpp" line="117"/>
        <source>取消升级</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_update_tool/upgrade_info.cpp" line="121"/>
        <source>升级成功</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
