<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/plugin_disk_monitor.cpp" line="60"/>
        <source>磁盘监视</source>
        <translation type="unfinished">Disk Monitor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/file_curve_wg.cpp" line="107"/>
        <source>(含告警)</source>
        <translation type="unfinished">(Including alarms)</translation>
    </message>
</context>
<context>
    <name>common_file_para</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="59"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="144"/>
        <source>监视</source>
        <translation type="unfinished">Monitor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="59"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="144"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="358"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="479"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="857"/>
        <source>管理</source>
        <translation type="unfinished">Manage</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="199"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="219"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="225"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="244"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="249"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="268"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="273"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="281"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="286"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="307"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="312"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="321"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="348"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="364"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="373"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="386"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="437"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="440"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="447"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="458"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="463"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="485"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="504"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="508"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="512"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="517"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="525"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="942"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="199"/>
        <source>数据库服务异常，新增失败</source>
        <translation type="unfinished">DB service exception, adding failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="219"/>
        <source>数据库服务异常，删除失败</source>
        <translation type="unfinished">DB service exception, deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="225"/>
        <source>无可删除项</source>
        <translation type="unfinished">No deletable items</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="244"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="504"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Please select the data to be operated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="249"/>
        <source>删除不可恢复，是否继续</source>
        <translation type="unfinished">Deletion cannot be recovered. Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="164"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="164"/>
        <source>路径</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="164"/>
        <source>类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="164"/>
        <source>删除类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Delete type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="164"/>
        <source>启动（%）</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Startup(%):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="165"/>
        <source>停止（%）</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Stop(%)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="165"/>
        <source>告警（%）</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alarm(%)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="249"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="276"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="440"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="508"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="249"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="277"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="440"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="508"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="268"/>
        <source>删除失败</source>
        <translation type="unfinished">Deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="275"/>
        <source>全局数据修改成功，是否同步删除各节点配置</source>
        <translation type="unfinished">Global data modification successful, whether to synchronously delete the configs of each node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="281"/>
        <source>数据同步删除失败</source>
        <translation type="unfinished">Data synchronization deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="286"/>
        <source>数据同步删除成功</source>
        <translation type="unfinished">Data synchronization deleted successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="307"/>
        <source>数据库服务异常，保存失败</source>
        <translation type="unfinished">DB service exception, save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="312"/>
        <source>无需保存</source>
        <translation type="unfinished">No need to save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="321"/>
        <source>分区启动删除阈值不能小于分区停止删除阈值</source>
        <translation type="unfinished">The partition start deletion threshold cannot be less than the partition stop deletion threshold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="350"/>
        <source>第%1行路径异常，请检查</source>
        <translation type="unfinished">Path exception on line %1, please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="366"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="388"/>
        <source>第%1行数据异常，保存失败</source>
        <translation type="unfinished">Line %1 data exception, save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="375"/>
        <source>第%1行数据异常，文件删除类型不允许为空，保存失败</source>
        <translation type="unfinished">Line %1 data exception, file deletion type cannot be empty, save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="437"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="440"/>
        <source>分区阈值参数变更，是否同步到所有分区</source>
        <translation type="unfinished">The partition threshold param is changed. Whether to synchronize the param to all partitions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="447"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="458"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="525"/>
        <source>数据库服务异常，应用失败</source>
        <translation type="unfinished">DB service exception, application failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="463"/>
        <source>请先保存数据</source>
        <translation type="unfinished">Please save the data first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="487"/>
        <source>第{}行数据异常，保存失败</source>
        <translation type="unfinished">Line {} data exception, save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="508"/>
        <source>是否同步勾选数据至各节点</source>
        <translation type="unfinished">Whether to synchronize data to each node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="512"/>
        <source>数据同步失败</source>
        <translation type="unfinished">Data synchronization failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="517"/>
        <source>数据同步成功</source>
        <translation type="unfinished">Data synchronization successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.cpp" line="944"/>
        <source>存在重复路径，保存失败</source>
        <translation type="unfinished">Duplicate paths. Save failed.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.ui" line="35"/>
        <source>启动删除（%）：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Start deletion(%):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.ui" line="52"/>
        <source>停止删除（%）：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Stop deletion(%):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.ui" line="75"/>
        <source>添加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.ui" line="82"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.ui" line="89"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/common_file_para.ui" line="96"/>
        <source>全部应用</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Apply all</translation>
    </message>
</context>
<context>
    <name>file_curve_wg</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/file_curve_wg.cpp" line="50"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
</context>
<context>
    <name>file_para_wg</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/file_para_wg.cpp" line="71"/>
        <source>全局参数</source>
        <translation type="unfinished">Global params</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/file_para_wg.cpp" line="151"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/file_para_wg.cpp" line="194"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/file_para_wg.cpp" line="151"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/file_para_wg.cpp" line="194"/>
        <source>存在未保存更改，是否保存</source>
        <translation type="unfinished">Unsaved changes. Save?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/file_para_wg.cpp" line="151"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/file_para_wg.cpp" line="194"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/file_para_wg.cpp" line="151"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/file_para_wg.cpp" line="194"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
</context>
<context>
    <name>node_file_para</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="200"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="317"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="529"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="695"/>
        <source>管理</source>
        <translation type="unfinished">Manage</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="200"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="317"/>
        <source>监视</source>
        <translation type="unfinished">Monitor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="376"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="404"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="415"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="434"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="438"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="456"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="473"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="478"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="487"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="514"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="535"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="544"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="558"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="589"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="633"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="939"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="960"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="996"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="1002"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="1019"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="1026"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="376"/>
        <source>数据库服务异常，新增失败</source>
        <translation type="unfinished">DB service exception, adding failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="404"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="996"/>
        <source>数据库服务异常，删除失败</source>
        <translation type="unfinished">DB service exception, deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="415"/>
        <source>无可删除项</source>
        <translation type="unfinished">No deletable items</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="434"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="1019"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Please select the data to be operated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="438"/>
        <source>删除不可恢复，是否继续</source>
        <translation type="unfinished">Deletion cannot be recovered. Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="238"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="238"/>
        <source>路径</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="238"/>
        <source>实际路径</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Actual path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="238"/>
        <source>分区</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Partition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="238"/>
        <source>类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="238"/>
        <source>删除类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Delete type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="238"/>
        <source>分区容量(M)</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Partition capacity (M)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="239"/>
        <source>启动（%）</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Startup(%):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="239"/>
        <source>启动（M）</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Startup(M):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="239"/>
        <source>停止（%）</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Stop(%)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="239"/>
        <source>停止（M）</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Stop(M)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="239"/>
        <source>告警（%）</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alarm(%)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="239"/>
        <source>告警（M）</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alarm(M)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="438"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="438"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="456"/>
        <source>删除失败</source>
        <translation type="unfinished">Deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="473"/>
        <source>数据库服务异常，保存失败</source>
        <translation type="unfinished">DB service exception, save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="478"/>
        <source>无需保存</source>
        <translation type="unfinished">No need to save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="487"/>
        <source>分区启动删除阈值不能小于分区停止删除阈值</source>
        <translation type="unfinished">The partition start deletion threshold cannot be less than the partition stop deletion threshold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="516"/>
        <source>第%1行路径异常，请检查</source>
        <translation type="unfinished">Path exception on line %1, please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="537"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="560"/>
        <source>第%1行数据异常，保存失败</source>
        <translation type="unfinished">Line %1 data exception, save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="546"/>
        <source>第%1行数据异常，文件删除类型不允许为空，保存失败</source>
        <translation type="unfinished">Line %1 data exception, file deletion type cannot be empty, save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="589"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="633"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="939"/>
        <source>分区信息不能为空</source>
        <translation type="unfinished">Partition info cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="1002"/>
        <source>无可刷新数据</source>
        <translation type="unfinished">No refreshable data available</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="1026"/>
        <source>路径分区查询失败</source>
        <translation type="unfinished">Path partition query failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.cpp" line="960"/>
        <source>存在重复路径，保存失败</source>
        <translation type="unfinished">Duplicate paths. Save failed.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.ui" line="41"/>
        <source>分区容量（G）：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Partition capacity (G):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.ui" line="62"/>
        <source>磁盘占比：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Disk ratio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.ui" line="76"/>
        <source>已用容量（G）：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Used capacity (G):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.ui" line="103"/>
        <source>分区查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Partition query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.ui" line="110"/>
        <source>重置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Reset</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.ui" line="117"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.ui" line="169"/>
        <source>删除阈值：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Delete threshold:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.ui" line="176"/>
        <source>启动（%）：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Startup(%):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.ui" line="193"/>
        <source>启动（G）：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Startup(G):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.ui" line="210"/>
        <source>停止（%）：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Stop(%):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.ui" line="227"/>
        <source>停止（G）：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Stop(G):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.ui" line="250"/>
        <source>添加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/gui_integrate_diskmonitor/node_file_para.ui" line="257"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
</context>
</TS>
