<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>DlgIpAddress</name>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_Ip_Address.cpp" line="14"/>
        <source>设置文本</source>
        <translation type="unfinished">Establecer texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_Ip_Address.cpp" line="19"/>
        <source>请输入IP地址:</source>
        <translation type="unfinished">Por favor, ingrese la dirección IP:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_Ip_Address.cpp" line="45"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_Ip_Address.cpp" line="45"/>
        <source>请检查输入地址</source>
        <translation type="unfinished">Por favor revise la dirección ingresada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_Ip_Address.cpp" line="45"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
</context>
<context>
    <name>DlgVerifyLicense</name>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="41"/>
        <source>请输入机器码</source>
        <translation type="unfinished">Por favor, ingrese el código</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="88"/>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="95"/>
        <source>注册码验证工具</source>
        <translation type="unfinished">Herramienta de verificación de código de registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="161"/>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="166"/>
        <source>%1</source>
        <translation type="unfinished">%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="194"/>
        <source>永久有效</source>
        <translation type="unfinished">Válido permanentemente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="201"/>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="242"/>
        <source>验证成功</source>
        <translation type="unfinished">Validado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="210"/>
        <source>失败</source>
        <translation type="unfinished">Fallido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="210"/>
        <source>写入文件失败!</source>
        <translation type="unfinished">¡Fallo al escribir el archivo!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="210"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="215"/>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="246"/>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="251"/>
        <source>注册码错误!</source>
        <translation type="unfinished">¡Código de registro incorrecto!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="219"/>
        <source>时间超限!</source>
        <translation type="unfinished">¡Tiempo límite excedido!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="223"/>
        <source>机器码不对应!</source>
        <translation type="unfinished">¡El código de la máquina no coincide!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="227"/>
        <source>程序错误!</source>
        <translation type="unfinished">¡Error en el programa!</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.cpp" line="88"/>
        <source>(节点名:</source>
        <translation type="unfinished">(Nodo:</translation>
    </message>
</context>
<context>
    <name>dlg_verify_license</name>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.ui" line="40"/>
        <source>验证区</source>
        <translation type="unfinished">Área de verificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.ui" line="50"/>
        <source>机器码:</source>
        <translation type="unfinished">Código de la máquina:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.ui" line="60"/>
        <source>注册码：</source>
        <translation type="unfinished">Código de registro:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.ui" line="93"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.ui" line="106"/>
        <source>验证</source>
        <translation type="unfinished">Verificar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.ui" line="120"/>
        <source>验证结果</source>
        <translation type="unfinished">Resultados de verificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.ui" line="200"/>
        <source>验证信息：</source>
        <translation type="unfinished">Información de verificación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.ui" line="233"/>
        <source>版本号：</source>
        <translation type="unfinished">Número de versión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.ui" line="247"/>
        <source>过期时间：</source>
        <translation type="unfinished">Tiempo de expiración:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.ui" line="261"/>
        <source>客户名称：</source>
        <translation type="unfinished">Nombre del cliente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/api/iasp_license_api/src/dlg_verify_license.ui" line="268"/>
        <source>产品名称：</source>
        <translation type="unfinished">Nombre del producto:</translation>
    </message>
</context>
</TS>
