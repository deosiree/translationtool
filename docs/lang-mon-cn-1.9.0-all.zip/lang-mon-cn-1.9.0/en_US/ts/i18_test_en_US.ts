<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>MainWindow</name>
        <message>
            <location line="14" filename="../../../../src/plat/i18n/test/i18n_test/test_ui/mainwindow.ui"/>
            <location line="73" filename="../../../../src/plat/i18n/test/i18n_test/cmake-build-debug-visual-studio-64/i18_test_autogen/include/ui_mainwindow.h"/>
            <location line="72" filename="../../../../src/plat/i18n/test/i18n_test/test_ui/ui_mainwindow.h"/>
            <source>MainWindow</source>
            <translation type="unfinished">fe</translation>
        </message>
        <message>
            <source>切换</source>
            <comment/>
            <translation>fe</translation>
        </message>
        <message>
            <source>低位在前</source>
            <comment/>
            <translation>bbrrt</translation>
        </message>
    </context>
    <context>
        <name>QObject</name>
        <message>
            <location line="419" filename="../../../../src/plat/i18n/test/i18n_test/test.cpp"/>
            <source>赵鸿鹏</source>
            <comment>测试1</comment>
            <translation type="unfinished">de</translation>
        </message>
        <message>
            <source>赵鸿鹏</source>
            <comment>测试2</comment>
            <translation>fee</translation>
        </message>
        <message>
            <source>赵鸿鹏</source>
            <comment></comment>
            <translation>fe</translation>
        </message>
    </context>
    <context>
        <name/>
        <message>
            <source>a</source>
            <comment/>
            <translation>g4</translation>
        </message>
    </context>
</TS>
