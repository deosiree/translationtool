<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CrossEventModel</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossEventModel.cpp" line="54"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossEventModel.cpp" line="56"/>
        <source>服务提供者</source>
        <translation type="unfinished">Proveedor de servicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossEventModel.cpp" line="58"/>
        <source>事件功能</source>
        <translation type="unfinished">Función de evento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossEventModel.cpp" line="60"/>
        <source>事件功能分组</source>
        <translation type="unfinished">Agrupación de funciones de evento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossEventModel.cpp" line="62"/>
        <source>固定事件号</source>
        <translation type="unfinished">ID de evento fijo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossEventModel.cpp" line="64"/>
        <source>事件号</source>
        <translation type="unfinished">ID de evento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossEventModel.cpp" line="817"/>
        <source>警告</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossEventModel.cpp" line="817"/>
        <source>没有复制任何数据</source>
        <translation type="unfinished">No se copian datos</translation>
    </message>
</context>
<context>
    <name>CrossSite</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.ui" line="14"/>
        <source>CrossSite</source>
        <translation type="unfinished">Entre sitios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.ui" line="111"/>
        <source>跨现场转发信息</source>
        <translation type="unfinished">Reenvío de información entre sitios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.ui" line="175"/>
        <source>跨现场事件转发表</source>
        <translation type="unfinished">Tabla de reenvío de eventos entre sitios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="126"/>
        <source>本现场 (%1) 跨现场转发信息</source>
        <translation type="unfinished">El sitio local (%1) reenvía información entre sitios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="162"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="399"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="599"/>
        <source>新增</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="190"/>
        <source>导入</source>
        <translation type="unfinished">Importar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="197"/>
        <source>打开文件</source>
        <translation type="unfinished">Abrir archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="218"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="282"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="528"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="834"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="218"/>
        <source>导入成功</source>
        <translation type="unfinished">Importación exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="175"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="222"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="245"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="287"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="300"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="304"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="333"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="338"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="349"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="440"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="449"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="464"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="472"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="480"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="488"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="496"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="504"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="522"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="541"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="545"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="637"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="654"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="658"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="817"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="830"/>
        <source>警告</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="170"/>
        <source>编辑</source>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="175"/>
        <source>请选择一行进行编辑</source>
        <translation type="unfinished">Seleccione una línea para editar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="222"/>
        <source>导入失败</source>
        <translation type="unfinished">Importación fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="228"/>
        <source>导出</source>
        <translation type="unfinished">Exportar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="239"/>
        <source>选择导出文件</source>
        <translation type="unfinished">Seleccionar archivo de exportación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="245"/>
        <source>文件名不能为空！</source>
        <translation type="unfinished">¡El nombre del archivo no puede estar vacío!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="264"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="272"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="264"/>
        <source>命令启动失败</source>
        <translation type="unfinished">Falló el lanzamiento del comando</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="272"/>
        <source>命令执行超时</source>
        <translation type="unfinished">Tiempo de espera de ejecución de comando</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="282"/>
        <source>导出成功</source>
        <translation type="unfinished">Éxito en la exportación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="287"/>
        <source>导出失败</source>
        <translation type="unfinished">Exportación fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="293"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="534"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="648"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="300"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="333"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="541"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="654"/>
        <source>请至少选择一行</source>
        <translation type="unfinished">Por favor, seleccione al menos una línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="305"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="546"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="659"/>
        <source>删除无法恢复，是否删除？</source>
        <translation type="unfinished">La eliminación no se puede restaurar. ¿Desea eliminarlo?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="322"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="569"/>
        <source>代理节点IP信息</source>
        <translation type="unfinished">Dirección IP del nodo proxy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="323"/>
        <source>跨现场转发事件表</source>
        <translation type="unfinished">Tablas de eventos de reenvío entre sitios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="327"/>
        <source>查看详情</source>
        <translation type="unfinished">Ver detalles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="338"/>
        <source>只能选择一行</source>
        <translation type="unfinished">Solo se puede seleccionar una línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="349"/>
        <source>反向类型没有代理节点信息</source>
        <translation type="unfinished">El tipo inverso no tiene información de nodo proxy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="357"/>
        <source>同构类型详情</source>
        <translation type="unfinished">Detalles de tipo isomórfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="360"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="383"/>
        <source>目的现场</source>
        <translation type="unfinished">Sitio de destino</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="364"/>
        <source>源现场</source>
        <translation type="unfinished">Sitio de origen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="380"/>
        <source>正向类型详情</source>
        <translation type="unfinished">Detalles del tipo de reenvío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="412"/>
        <source>批量编辑</source>
        <translation type="unfinished">Edición por lotes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="430"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="440"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="449"/>
        <source>没有修改数据</source>
        <translation type="unfinished">No hay datos modificados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="464"/>
        <source>%1 的A网和B网IP地址至少需要填写一个</source>
        <translation type="unfinished">Al menos una de las direcciones IP (Red A o Red B) para %1 debe ser completada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="472"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="496"/>
        <source>%1 的A网IP地址不合法</source>
        <translation type="unfinished">La dirección IP de la red A de %1 es ilegal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="480"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="488"/>
        <source>%1 的B网IP地址不合法</source>
        <translation type="unfinished">La dirección IP de la red B de %1 es ilegal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="504"/>
        <source>%1 的A网和B网IP地址都不合法</source>
        <translation type="unfinished">Ambas direcciones IP de la red A y la red B de %1 son inválidas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="522"/>
        <source>保存失败</source>
        <translation type="unfinished">Fallo al guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="528"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="623"/>
        <source>新增固定事件号</source>
        <translation type="unfinished">Agregar ID de evento fijo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="631"/>
        <source>复制全部事件</source>
        <translation type="unfinished">Copiar todos los eventos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="637"/>
        <source>没有数据可复制</source>
        <translation type="unfinished">No hay datos para copiar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="644"/>
        <source>粘贴</source>
        <translation type="unfinished">Pegar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="685"/>
        <source>目的现场 (%1) 代理节点IP信息列表</source>
        <translation type="unfinished">Lista de información de IP de nodo proxy del sitio de destino (%1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="686"/>
        <source>目的现场 (%1) 跨现场转发事件列表</source>
        <translation type="unfinished">Lista de eventos de reenvío entre sitios del sitio de destino (%1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="817"/>
        <source>请输入有效的十六进制数！</source>
        <translation type="unfinished">¡Por favor, ingrese un número hexadecimal válido!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="830"/>
        <source>保存失败！</source>
        <translation type="unfinished">¡Fallo al guardar!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/crosssite.cpp" line="834"/>
        <source>保存成功！</source>
        <translation type="unfinished">¡Guardado exitosamente!</translation>
    </message>
</context>
<context>
    <name>CrossSiteDetailModel</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossSiteDetailModel.cpp" line="32"/>
        <source>节点</source>
        <translation type="unfinished">Nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossSiteDetailModel.cpp" line="34"/>
        <source>A网IP</source>
        <translation type="unfinished">Dirección IP de A-net</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossSiteDetailModel.cpp" line="36"/>
        <source>B网IP</source>
        <translation type="unfinished">Dirección IP de B-net</translation>
    </message>
</context>
<context>
    <name>CrosssiteModel</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="34"/>
        <source>目的现场</source>
        <translation type="unfinished">Sitio de destino</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="36"/>
        <source>转发类型</source>
        <translation type="unfinished">Tipo de reenvío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="62"/>
        <source>未配置</source>
        <translation type="unfinished">No configurado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="63"/>
        <source>跨对等现场</source>
        <translation type="unfinished">Entre sitios de pares</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="64"/>
        <source>跨正向隔离</source>
        <translation type="unfinished">Aislamiento de reenvío cruzado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="65"/>
        <source>跨反向隔离</source>
        <translation type="unfinished">Aislamiento inverso cruzado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="66"/>
        <source>未知类型</source>
        <translation type="unfinished">Tipo desconocido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="191"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="193"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="225"/>
        <source>代理节点</source>
        <translation type="unfinished">Nodo proxy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="191"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="193"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="225"/>
        <source>节点ip1</source>
        <translation type="unfinished">IP del nodo 1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="191"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="193"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrosssiteModel.cpp" line="225"/>
        <source>节点ip2</source>
        <translation type="unfinished">IP del nodo 2</translation>
    </message>
</context>
<context>
    <name>MEventGroupModel</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/MEventGroupModel.cpp" line="37"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/MEventGroupModel.cpp" line="39"/>
        <source>分组名</source>
        <translation type="unfinished">Nombre del grupo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/MEventGroupModel.cpp" line="41"/>
        <source>分组描述</source>
        <translation type="unfinished">Descripción del grupo</translation>
    </message>
</context>
<context>
    <name>MTdbModel</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/MTdbModel.cpp" line="37"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/MTdbModel.cpp" line="39"/>
        <source>应用名</source>
        <translation type="unfinished">Nombre de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/MTdbModel.cpp" line="41"/>
        <source>库名</source>
        <translation type="unfinished">Nombre de la base de datos</translation>
    </message>
</context>
<context>
    <name>NewCrossEvent</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.ui" line="14"/>
        <source>新建跨现场转发事件</source>
        <translation type="unfinished">Nuevo evento de reenvío entre sitios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.ui" line="68"/>
        <source>服务提供者选择：</source>
        <translation type="unfinished">Seleccione proveedor de servicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.ui" line="75"/>
        <source>实时库</source>
        <translation type="unfinished">TDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.ui" line="82"/>
        <source>应用</source>
        <translation type="unfinished">App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.ui" line="182"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="91"/>
        <source>转发事件功能选择</source>
        <translation type="unfinished">Selección de función de evento de reenvío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.ui" line="312"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="92"/>
        <source>转发事件功能分组选择</source>
        <translation type="unfinished">Seleccionar grupo de evento de reenvío </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="57"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="58"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="404"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="404"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="415"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="421"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="430"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="437"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="461"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="470"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="479"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="493"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="502"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="511"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="527"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="536"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="545"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="559"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="568"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="577"/>
        <source>警告</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="415"/>
        <source>请至少选择一个实时库</source>
        <translation type="unfinished">Por favor, seleccione al menos un TDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="421"/>
        <source>请至少选择一个应用</source>
        <translation type="unfinished">Por favor, seleccione al menos una aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="430"/>
        <source>请至少选择一个功能项</source>
        <translation type="unfinished">Por favor, seleccione al menos una función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="437"/>
        <source>请至少选择一个事件组</source>
        <translation type="unfinished">Por favor, seleccione al menos un grupo de eventos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="460"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="469"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="478"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="492"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="501"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="510"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="526"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="535"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="544"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="558"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="567"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrossevent.cpp" line="576"/>
        <source>写入数据库失败，错误码：</source>
        <translation type="unfinished">Fallo al escribir en la base de datos, código de fallo:</translation>
    </message>
</context>
<context>
    <name>NewCrossSiteDialog</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.ui" line="14"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="68"/>
        <source>新建跨现场</source>
        <translation type="unfinished">Nuevo entre sitios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.ui" line="25"/>
        <source>目的现场名：</source>
        <translation type="unfinished">Nombre del sitio de destino:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.ui" line="39"/>
        <source>转发类型：</source>
        <translation type="unfinished">Tipo de reenvío:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.ui" line="46"/>
        <source>正向</source>
        <translation type="unfinished">Dirección de reenvío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.ui" line="53"/>
        <source>反向</source>
        <translation type="unfinished">Inverso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.ui" line="60"/>
        <source>同构</source>
        <translation type="unfinished">Isomorfismo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="28"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="29"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="49"/>
        <source>编辑跨现场</source>
        <translation type="unfinished">Editar sitio cruzado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="136"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="148"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="167"/>
        <source>警告</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="136"/>
        <source>现场名称不能为空！</source>
        <translation type="unfinished">¡El nombre del sitio no puede estar vacío!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="148"/>
        <source>获取跨现场信息失败！</source>
        <translation type="unfinished">¡Error al obtener la información del sitio cruzado!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="167"/>
        <source>保存失败！</source>
        <translation type="unfinished">¡Fallo al guardar!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="171"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/newcrosssitedialog.cpp" line="171"/>
        <source>保存成功！</source>
        <translation type="unfinished">¡Guardado exitosamente!</translation>
    </message>
</context>
<context>
    <name>ProxyNodeDialog</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="22"/>
        <source>A网地址</source>
        <translation type="unfinished">Dirección A_Net</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="22"/>
        <source>B网地址</source>
        <translation type="unfinished">Dirección B_Net</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="31"/>
        <source>新增代理节点</source>
        <translation type="unfinished">Nuevo nodo proxy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="32"/>
        <source>删除代理节点</source>
        <translation type="unfinished">Eliminar nodo proxy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="33"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="46"/>
        <source>节点管理</source>
        <translation type="unfinished">Gestión de nodos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="55"/>
        <source>编辑节点</source>
        <translation type="unfinished">Editar nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="58"/>
        <source>新增节点</source>
        <translation type="unfinished">Nuevo nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="75"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="93"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="183"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="75"/>
        <source>获取节点IP数据失败</source>
        <translation type="unfinished">Error al obtener los datos de IP del nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="93"/>
        <source>请选择要删除的节点</source>
        <translation type="unfinished">Seleccione el nodo a eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="183"/>
        <source>删除原有节点IP失败</source>
        <translation type="unfinished">Error al eliminar la IP original del nodo</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="126"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="197"/>
        <source>保存失败</source>
        <translation type="unfinished">Fallo al guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="126"/>
        <source>无效的oid！</source>
        <translation type="unfinished">¡OID no válido!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="148"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="158"/>
        <source>无效IP地址</source>
        <translation type="unfinished">Dirección IP no válida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="149"/>
        <source>第 %1 行的 A 网地址不合法！</source>
        <translation type="unfinished">¡La dirección A-net en la línea %1 no es legal!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="159"/>
        <source>第 %1 行的 B 网地址不合法！</source>
        <translation type="unfinished">¡La dirección B-net en la línea %1 no es legal!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="197"/>
        <source>保存代理节点失败！</source>
        <translation type="unfinished">¡Fallo al guardar el nodo proxy!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="201"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/addIPDialog.cpp" line="201"/>
        <source>所有代理节点已成功保存！</source>
        <translation type="unfinished">¡Todos los nodos de agente guardados con éxito!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/CrossSiteDetailModel.cpp" line="171"/>
        <source>节点%1</source>
        <translation type="unfinished">Nodo %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/HexSaveDialog.cpp" line="5"/>
        <source>固定事件号</source>
        <translation type="unfinished">Núm. de evento fijo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/HexSaveDialog.cpp" line="9"/>
        <source>请输入8字节的16进制数：</source>
        <translation type="unfinished">Ingrese número hexadecimal de 8 bytes:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/HexSaveDialog.cpp" line="19"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/HexSaveDialog.cpp" line="30"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/HexSaveDialog.cpp" line="40"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/HexSaveDialog.cpp" line="30"/>
        <source>输入有效的8字节16进制数</source>
        <translation type="unfinished">Ingrese hexadecimal válido de 8 bytes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/HexSaveDialog.cpp" line="40"/>
        <source>16进制数长度不足8字节</source>
        <translation type="unfinished">Hexadecimal &lt; 8 bytes</translation>
    </message>
</context>
<context>
    <name>eventMenu</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/eventMenu.cpp" line="11"/>
        <source>新增</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/eventMenu.cpp" line="40"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_transcfg/eventMenu.cpp" line="41"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
</context>
</TS>
