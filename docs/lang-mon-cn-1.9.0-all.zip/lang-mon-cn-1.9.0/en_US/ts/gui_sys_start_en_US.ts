<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/tool/gui_sys_start/src/widget.cpp" line="222"/>
        <source>系统退出界面</source>
        <comment>toolName</comment>
        <translation type="unfinished">System Exit Interface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/tool/gui_sys_start/src/widget.cpp" line="226"/>
        <source>系统启动界面</source>
        <comment>toolName</comment>
        <translation type="unfinished">System Startup Interface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/tool/gui_sys_start/src/widget.cpp" line="263"/>
        <source>系统退出</source>
        <translation type="unfinished">System exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/tool/gui_sys_start/src/widget.cpp" line="265"/>
        <source>系统启动</source>
        <translation type="unfinished">System boot</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/tool/gui_sys_start/src/widget.cpp" line="382"/>
        <location filename="../../../../src/plat/sysmgr/tool/gui_sys_start/src/widget.cpp" line="384"/>
        <source>详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/tool/gui_sys_start/src/widget.cpp" line="417"/>
        <source>登录系统</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Login</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/tool/gui_sys_start/src/widget.cpp" line="470"/>
        <source>退出系统</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exit system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/tool/gui_sys_start/src/widget.cpp" line="486"/>
        <source>退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/tool/gui_sys_start/src/widget.cpp" line="595"/>
        <source>异常信息</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Abnormal info</translation>
    </message>
</context>
<context>
    <name>Widget</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/tool/gui_sys_start/src/widget.ui" line="22"/>
        <source>sieyuan</source>
        <translation type="unfinished">Sieyuan</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/tool/gui_sys_start/src/widget.ui" line="91"/>
        <source>监控系统</source>
        <translation type="unfinished">Monitor system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/tool/gui_sys_start/src/widget.ui" line="333"/>
        <source>失败</source>
        <translation type="unfinished">Fail</translation>
    </message>
</context>
</TS>
