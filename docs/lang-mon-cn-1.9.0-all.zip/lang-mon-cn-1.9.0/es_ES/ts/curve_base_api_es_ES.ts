<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CMyBasicPlot</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_plot.cpp" line="291"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_plot.cpp" line="302"/>
        <source>年</source>
        <translation type="unfinished">Año</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_plot.cpp" line="302"/>
        <source>周</source>
        <translation type="unfinished">Semana</translation>
    </message>
</context>
<context>
    <name>CMyBasicTracer</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_tracer.cpp" line="295"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_tracer.cpp" line="300"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_tracer.cpp" line="320"/>
        <source>时间:%1 %2</source>
        <translation type="unfinished">Tiempo:%1 %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_tracer.cpp" line="305"/>
        <source>日:%1 %2</source>
        <translation type="unfinished">Día:%1 %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_tracer.cpp" line="310"/>
        <source>%1 %2</source>
        <translation type="unfinished">%1 %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_tracer.cpp" line="315"/>
        <source>月:%1 %2</source>
        <translation type="unfinished">Mes:%1 %2</translation>
    </message>
</context>
<context>
    <name>CMyCanvasArea</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2190"/>
        <source>保存曲线数据</source>
        <translation type="unfinished">Guardar datos de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2210"/>
        <source>%1-x轴(时间), </source>
        <translation type="unfinished">%1-eje X (tiempo),</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2210"/>
        <source>%1-y轴(值)</source>
        <translation type="unfinished">%1-eje Y (valor)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2249"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2305"/>
        <source>成功</source>
        <translation type="unfinished">Éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2249"/>
        <source>曲线数据已成功导出!</source>
        <translation type="unfinished">¡Datos de curva exportados con éxito!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2254"/>
        <source>导入曲线数据</source>
        <translation type="unfinished">Importar datos de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2261"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2261"/>
        <source>无法打开文件 %1</source>
        <translation type="unfinished">No se puede abrir archivo %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2305"/>
        <source>数据导入成功</source>
        <translation type="unfinished">Datos importados con éxito</translation>
    </message>
</context>
<context>
    <name>CMyCurveDefinition</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="144"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="145"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="171"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="175"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1151"/>
        <source>当前区间</source>
        <translation type="unfinished">Intervalo actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="149"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="150"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1143"/>
        <source>本月</source>
        <translation type="unfinished">Este mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="154"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="155"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1147"/>
        <source>本年</source>
        <translation type="unfinished">Este año</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="159"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="160"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1139"/>
        <source>本日</source>
        <translation type="unfinished">Hoy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="190"/>
        <source>基本属性</source>
        <translation type="unfinished">Atributos básicos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="264"/>
        <source>请输入曲线名称</source>
        <translation type="unfinished">Ingrese nombre de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="261"/>
        <source>曲线名称：</source>
        <translation type="unfinished">Nombre de curva:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="267"/>
        <source>线色：</source>
        <translation type="unfinished">Color de línea:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="283"/>
        <source>小数点精度：</source>
        <translation type="unfinished">Precisión decimal:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="288"/>
        <source>线宽：</source>
        <translation type="unfinished">Ancho de línea:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="304"/>
        <source>对象检索：</source>
        <translation type="unfinished">Búsqueda de objeto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="307"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="389"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="394"/>
        <source>检索</source>
        <comment>buttonName</comment>
        <translation type="unfinished">La recuperación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="309"/>
        <source>起始时间：</source>
        <translation type="unfinished">Hora de inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="313"/>
        <source>设置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Configurar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="340"/>
        <source>数据点形状：</source>
        <translation type="unfinished">Forma de punto de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="343"/>
        <source>空心圆</source>
        <translation type="unfinished">Círculo hueco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="343"/>
        <source>实心圆</source>
        <translation type="unfinished">Círculo sólido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="343"/>
        <source>正方形</source>
        <translation type="unfinished">Cuadrado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="343"/>
        <source>三角形</source>
        <translation type="unfinished">Triángulo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="353"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="506"/>
        <source>显示数据点</source>
        <translation type="unfinished">Mostrar puntos de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="367"/>
        <source>计算曲线</source>
        <translation type="unfinished">Curva calculada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="375"/>
        <source>配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="474"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Añadir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="476"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="478"/>
        <source>上移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Mover arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="480"/>
        <source>下移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Mover abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="482"/>
        <source>复制</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Copiar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="854"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">determinar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="855"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">cancelación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="386"/>
        <source>X轴数据源:</source>
        <translation type="unfinished">Fuente de datos eje X:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="391"/>
        <source>Y轴数据源:</source>
        <translation type="unfinished">Fuente de datos eje Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="409"/>
        <source>单位:</source>
        <translation type="unfinished">Unidad:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="411"/>
        <source>请输入单位</source>
        <translation type="unfinished">Ingrese unidad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="419"/>
        <source>Y轴配置:</source>
        <translation type="unfinished">Config. de eje Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="506"/>
        <source>曲线名称</source>
        <translation type="unfinished">Nombre de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="506"/>
        <source>线色</source>
        <translation type="unfinished">Color de línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="506"/>
        <source>线宽</source>
        <translation type="unfinished">Ancho de línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="506"/>
        <source>基本点形状</source>
        <translation type="unfinished">Forma de punto básico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="506"/>
        <source>对象检索</source>
        <translation type="unfinished">Búsqueda de objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="570"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1080"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="570"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1080"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="818"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="921"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1171"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="818"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="921"/>
        <source>曲线数量超过限制</source>
        <translation type="unfinished">Cantidad de curvas excede límite</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="823"/>
        <source>线</source>
        <translation type="unfinished">Línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="849"/>
        <source>删除</source>
        <comment>toolName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="851"/>
        <source>删除不可恢复，是否继续</source>
        <translation type="unfinished">Eliminación irreversible, ¿continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="943"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="954"/>
        <source>-副本(%1)</source>
        <translation type="unfinished">-Copia (%1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="947"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="949"/>
        <source>-副本</source>
        <translation type="unfinished">-Copia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1171"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Seleccione datos para operar</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupAttribute</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="103"/>
        <source>曲线组名称：</source>
        <translation type="unfinished">Nombre de grupo de curva:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="105"/>
        <source>请输入</source>
        <translation type="unfinished">Ingrese</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="115"/>
        <source>曲线组类型:</source>
        <translation type="unfinished">Tipo de grupo de curva:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="119"/>
        <source>日曲线</source>
        <translation type="unfinished">Curva diaria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="119"/>
        <source>月曲线</source>
        <translation type="unfinished">Curva mensual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="119"/>
        <source>年曲线</source>
        <translation type="unfinished">Curva anual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="119"/>
        <source>区间曲线</source>
        <translation type="unfinished">Curva de intervalo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="119"/>
        <source>实时曲线</source>
        <translation type="unfinished">Curva en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="144"/>
        <source>展示形式:</source>
        <translation type="unfinished">Forma de mostrar:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="148"/>
        <source>点</source>
        <translation type="unfinished">Punto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="148"/>
        <source>线</source>
        <translation type="unfinished">Línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="148"/>
        <source>向下填充</source>
        <translation type="unfinished">Relleno hacia abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="171"/>
        <source>左边距:</source>
        <translation type="unfinished">Margen izquierdo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="174"/>
        <source>下边距:</source>
        <translation type="unfinished">Margen inferior:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="189"/>
        <source>背景颜色:</source>
        <translation type="unfinished">Color de fondo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="196"/>
        <source>阈值颜色:</source>
        <translation type="unfinished">Color de umbral:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="210"/>
        <source>阈值上限:</source>
        <translation type="unfinished">Umbral superior:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="214"/>
        <source>阈值下限:</source>
        <translation type="unfinished">Umbral inferior:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="228"/>
        <source>刷新周期%1</source>
        <translation type="unfinished">Ciclo de actualización %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="246"/>
        <source>区间配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Config. de intervalo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="311"/>
        <source>标题栏</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Barra de título</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="312"/>
        <source>网格</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Cuadrícula</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="313"/>
        <source>图例</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Leyenda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="314"/>
        <source>游标</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Cursor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="315"/>
        <source>坐标轴</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Eje de coordenadas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="320"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="444"/>
        <source>多Y轴</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Múltiples ejes Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="260"/>
        <source>背景透明</source>
        <translation type="unfinished">Fondo transparente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="263"/>
        <source>平滑曲线</source>
        <translation type="unfinished">Curva suave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="266"/>
        <source>曲线详情</source>
        <translation type="unfinished">Detalles de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="269"/>
        <source>显示阈值</source>
        <translation type="unfinished">Mostrar umbral</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="272"/>
        <source>漏点断开</source>
        <translation type="unfinished">Desconexión de punto débil</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="276"/>
        <source>绝对值曲线</source>
        <translation type="unfinished">Curva de valor absoluto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="427"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="432"/>
        <source>至</source>
        <translation type="unfinished">Hasta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="470"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="529"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="471"/>
        <source>切换曲线类型,需要清空曲线，是否确定?</source>
        <translation type="unfinished">Cambiar tipo curva borra datos, ¿confirmar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="529"/>
        <source>暂不支持该类型曲线</source>
        <translation type="unfinished">Curva no soportada</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupAxis</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="96"/>
        <source>坐标轴自适应</source>
        <translation type="unfinished">Ejes autoajustables</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="100"/>
        <source>多Y轴</source>
        <translation type="unfinished">Múltiples ejes Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="103"/>
        <source>是否固定轴</source>
        <translation type="unfinished">¿Eje fijo?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="132"/>
        <source>X轴主刻度:</source>
        <translation type="unfinished">Escala principal eje X:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="137"/>
        <source>Y轴主刻度:</source>
        <translation type="unfinished">Escala principal eje Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="156"/>
        <source>X轴字体:</source>
        <translation type="unfinished">Fuente eje X:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="159"/>
        <source>Y轴字体:</source>
        <translation type="unfinished">Fuente eje Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="173"/>
        <source>坐标轴线宽:</source>
        <translation type="unfinished">Ancho línea eje:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="179"/>
        <source>坐标轴颜色:</source>
        <translation type="unfinished">Color de ejes:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="194"/>
        <source>y轴最小值:</source>
        <translation type="unfinished">Valor mín. eje Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="199"/>
        <source>y轴最大值:</source>
        <translation type="unfinished">Valor máx. eje Y:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="217"/>
        <source>曲线轴区间:</source>
        <translation type="unfinished">Rango eje curva:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="221"/>
        <source>设置实时曲线的轴范围</source>
        <translation type="unfinished">Config. rango eje curva en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="223"/>
        <source>显示历史</source>
        <translation type="unfinished">Mostrar la historia</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupCursor</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="36"/>
        <source>显示游标</source>
        <translation type="unfinished">Mostrar cursor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="39"/>
        <source>显示日期</source>
        <translation type="unfinished">Mostrar fecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="42"/>
        <source>背景透明</source>
        <translation type="unfinished">Fondo transparente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="60"/>
        <source>背景颜色：</source>
        <translation type="unfinished">Color de fondo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="61"/>
        <source>字体大小：</source>
        <translation type="unfinished">Tamaño de fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="75"/>
        <source>字体颜色：</source>
        <translation type="unfinished">Color de fuente:</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupGrid</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_grid.cpp" line="56"/>
        <source>不显示</source>
        <translation type="unfinished">No mostrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_grid.cpp" line="57"/>
        <source>多列</source>
        <translation type="unfinished">Múltiples columnas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_grid.cpp" line="58"/>
        <source>少列</source>
        <translation type="unfinished">Menos columnas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_grid.cpp" line="69"/>
        <source>网格线颜色:</source>
        <translation type="unfinished">Color de líneas de cuadrícula:</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupLegend</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="70"/>
        <source>隐藏图例</source>
        <translation type="unfinished">Ocultar leyenda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="74"/>
        <source>图例间距：</source>
        <translation type="unfinished">Espaciado de leyenda:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="78"/>
        <source>图例方向：</source>
        <translation type="unfinished">Dirección de leyenda:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>上左</source>
        <translation type="unfinished">Superior izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>上中</source>
        <translation type="unfinished">Centro superior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>上右</source>
        <translation type="unfinished">Superior derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>中左</source>
        <translation type="unfinished">Centro izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>正中</source>
        <translation type="unfinished">Centro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>中右</source>
        <translation type="unfinished">Centro derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>下左</source>
        <translation type="unfinished">Inferior izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>下中</source>
        <translation type="unfinished">Centro inferior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="82"/>
        <source>下右</source>
        <translation type="unfinished">Inferior derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="95"/>
        <source>排列方式:</source>
        <translation type="unfinished">Arreglo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="98"/>
        <source>水平</source>
        <translation type="unfinished">Horizontal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="98"/>
        <source>垂直</source>
        <translation type="unfinished">Vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="102"/>
        <source>换行:</source>
        <translation type="unfinished">Salto de línea:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="106"/>
        <source>设置图例自动换行，0表示不换行</source>
        <translation type="unfinished">Ajustar leyenda a salto auto, 0 sin salto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="120"/>
        <source>图例字体:</source>
        <translation type="unfinished">Fuente de leyenda:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="124"/>
        <source>图例颜色:</source>
        <translation type="unfinished">Color de leyenda:</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupTitleBar</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="37"/>
        <source>显示标题栏</source>
        <translation type="unfinished">Mostrar barra de título</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="40"/>
        <source>背景透明</source>
        <translation type="unfinished">Fondo transparente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="43"/>
        <source>显示按钮</source>
        <translation type="unfinished">Mostrar botón</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="52"/>
        <source>背景颜色:</source>
        <translation type="unfinished">Color de fondo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="53"/>
        <source>字体颜色:</source>
        <translation type="unfinished">Color de fuente:</translation>
    </message>
</context>
<context>
    <name>CMyCurveNewCreate</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="54"/>
        <source>曲线组属性</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Atributos de grupo de curvas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="55"/>
        <source>曲线定义</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Definición de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="58"/>
        <source>设置曲线属性</source>
        <translation type="unfinished">Establecer atributos de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="139"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="147"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="152"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="158"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="164"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="169"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="139"/>
        <source>对象检索为空,请关联曲线数据</source>
        <translation type="unfinished">Recuperación de objeto vacía, enlace curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="147"/>
        <source>曲线名称不可为空</source>
        <translation type="unfinished">Nombre de curva no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="152"/>
        <source>曲线重复</source>
        <translation type="unfinished">Curva repetida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="158"/>
        <source>曲线名称不可重复</source>
        <translation type="unfinished">Nombres de curvas no repetidos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="164"/>
        <source>y轴最小值大于y轴最大值</source>
        <translation type="unfinished">Valor mín. eje Y mayor que máx.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="169"/>
        <source>阈值下限大于阈值上限</source>
        <translation type="unfinished">Umbral inferior mayor que superior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="175"/>
        <source>曲线组名称不能为空!</source>
        <translation type="unfinished">¡Nombre de grupo de curvas no vacío!</translation>
    </message>
</context>
<context>
    <name>CMyMultipleYAxis</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="40"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Añadir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="42"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>编号</source>
        <translation type="unfinished">Núm.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>Y轴名称</source>
        <translation type="unfinished">Nombre eje Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>Y轴颜色</source>
        <translation type="unfinished">Color eje Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>最大值</source>
        <translation type="unfinished">Máximo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>最小值</source>
        <translation type="unfinished">Mínimo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>是否显示</source>
        <translation type="unfinished">¿Mostrar?</translation>
    </message>
</context>
<context>
    <name>CmyStatisticalTable</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="130"/>
        <source>曲线名称</source>
        <translation type="unfinished">Nombre de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="130"/>
        <source>线色</source>
        <translation type="unfinished">Color de línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="130"/>
        <source>最大值</source>
        <translation type="unfinished">Máximo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="130"/>
        <source>最小值</source>
        <translation type="unfinished">Mínimo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="130"/>
        <source>对象检索</source>
        <translation type="unfinished">Objeto de recuperación</translation>
    </message>
</context>
<context>
    <name>ContextMenu</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="29"/>
        <source>编辑画面</source>
        <translation type="unfinished">Editar pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="33"/>
        <source>另存为</source>
        <translation type="unfinished">Guardar como</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="34"/>
        <source>打开</source>
        <translation type="unfinished">Abrir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="39"/>
        <source>曲线详情</source>
        <translation type="unfinished">Detalles de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="48"/>
        <source>平滑曲线</source>
        <translation type="unfinished">Curva suave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="57"/>
        <source>绝对值曲线</source>
        <translation type="unfinished">Curva de valor absoluto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="67"/>
        <source>开启实时刷新</source>
        <translation type="unfinished">Habilitar actualización en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="75"/>
        <source>导出数据</source>
        <translation type="unfinished">Exportar datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="76"/>
        <source>刷新</source>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="77"/>
        <source>重置</source>
        <translation type="unfinished">Reiniciar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="79"/>
        <source>查询</source>
        <translation type="unfinished">Consulta</translation>
    </message>
</context>
<context>
    <name>DlgIntervalTime</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="36"/>
        <source>设置日期</source>
        <comment>toolName</comment>
        <translation type="unfinished">Configurar fecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="64"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="77"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="64"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="77"/>
        <source>日期选择错误，请重新选择</source>
        <translation type="unfinished">Error en selección de fecha, reintente</translation>
    </message>
</context>
<context>
    <name>DlgQuery</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_query.cpp" line="23"/>
        <source>查询</source>
        <comment>toolName</comment>
        <translation type="unfinished">Consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_query.cpp" line="47"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">cancelación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_query.cpp" line="48"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Consulta</translation>
    </message>
</context>
<context>
    <name>DlgRelativeTime</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="69"/>
        <source>本日</source>
        <translation type="unfinished">Hoy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="70"/>
        <source>昨日</source>
        <translation type="unfinished">Ayer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="71"/>
        <source>明日</source>
        <translation type="unfinished">Mañana</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="72"/>
        <source>上周今日</source>
        <translation type="unfinished">Semana pasada hoy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="73"/>
        <source>上月今日</source>
        <translation type="unfinished">Hoy mes pasado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="74"/>
        <source>去年今日</source>
        <translation type="unfinished">Hoy año pasado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="80"/>
        <source>本月</source>
        <translation type="unfinished">Este mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="81"/>
        <source>上月</source>
        <translation type="unfinished">Mes pasado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="82"/>
        <source>下月</source>
        <translation type="unfinished">Próximo mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="83"/>
        <source>去年该月</source>
        <translation type="unfinished">Mes pasado año pasado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="86"/>
        <source>月前</source>
        <translation type="unfinished">Meses atrás</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="91"/>
        <source>本年</source>
        <translation type="unfinished">Este año</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="92"/>
        <source>去年</source>
        <translation type="unfinished">Año pasado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="93"/>
        <source>下年</source>
        <translation type="unfinished">Próximo año</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="94"/>
        <source>去年该年</source>
        <translation type="unfinished">Año pasado este año</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="98"/>
        <source>年前</source>
        <translation type="unfinished">Años atrás</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="68"/>
        <source>日曲线时间配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Config. de tiempo de curva diaria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="79"/>
        <source>月曲线时间配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Config. de tiempo de curva mensual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="90"/>
        <source>年曲线时间配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Config. de tiempo de curva anual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="102"/>
        <source>区间曲线时间配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Config. de tiempo de curva de intervalo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="103"/>
        <source>当前区间</source>
        <translation type="unfinished">Intervalo actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="104"/>
        <source>昨天该区间</source>
        <translation type="unfinished">Ayer este intervalo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="105"/>
        <source>明天该区间</source>
        <translation type="unfinished">Mañana este intervalo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="106"/>
        <source>上周该区间</source>
        <translation type="unfinished">Semana pasada este intervalo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="107"/>
        <source>上月该区间</source>
        <translation type="unfinished">Mes pasado este intervalo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="108"/>
        <source>去年该区间</source>
        <translation type="unfinished">Mismo intervalo del año pasado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="128"/>
        <source>请输入数字（范围1～365）</source>
        <translation type="unfinished">Ingrese número (rango 1-365)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="149"/>
        <source>请输入数字（范围1～99）</source>
        <translation type="unfinished">Ingrese número (rango 1-99)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="170"/>
        <source>请输入数字（范围1～9）</source>
        <translation type="unfinished">Ingrese número (rango 1-9)</translation>
    </message>
</context>
<context>
    <name>PrinterHandle</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/printer_handle.cpp" line="35"/>
        <source>打印错误</source>
        <translation type="unfinished">Error de impresión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/printer_handle.cpp" line="35"/>
        <source>无法找到打印机</source>
        <translation type="unfinished">No se encuentra impresora</translation>
    </message>
</context>
<context>
    <name>XMLFileHandle</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="22"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="22"/>
        <source>文件打开或创建失败</source>
        <translation type="unfinished">Apertura o creación de archivo falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="25"/>
        <source>文件保存中</source>
        <translation type="unfinished">Guardando archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="96"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="96"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="654"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="659"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="665"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="673"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="697"/>
        <source>告警</source>
        <translation type="unfinished">Alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="654"/>
        <source>文件不存在</source>
        <translation type="unfinished">Archivo no existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="659"/>
        <source>文件打开失败</source>
        <translation type="unfinished">Apertura de archivo falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="665"/>
        <source>操作的文件不是XML格式</source>
        <translation type="unfinished">Archivo no es formato XML</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="673"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="697"/>
        <source>曲线文件格式无效</source>
        <translation type="unfinished">Formato de archivo de curva inválido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="702"/>
        <source>曲线文件读取中</source>
        <translation type="unfinished">Lectura de archivo de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="702"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>dlg_interval_time</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.ui" line="22"/>
        <source>开始时间：</source>
        <translation type="unfinished">Hora de inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.ui" line="36"/>
        <source>结束时间：</source>
        <translation type="unfinished">Hora de fin:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.ui" line="63"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.ui" line="70"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>dlg_relative_time</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="22"/>
        <source>今天</source>
        <translation type="unfinished">Hoy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="29"/>
        <source>昨天</source>
        <translation type="unfinished">Ayer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="36"/>
        <source>明天</source>
        <translation type="unfinished">Mañana</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="47"/>
        <source>上周今天</source>
        <translation type="unfinished">Semana pasada hoy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="54"/>
        <source>上月今天</source>
        <translation type="unfinished">Mes pasado hoy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="61"/>
        <source>去年今天</source>
        <translation type="unfinished">Hoy año pasado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="72"/>
        <source>自定义</source>
        <translation type="unfinished">Personalizado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="82"/>
        <source>天前</source>
        <translation type="unfinished">Días atrás</translation>
    </message>
</context>
</TS>
