<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>ArrowWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/taskbarwidget/arrow_widget.cpp" line="26"/>
        <source>悬浮菜单</source>
        <translation type="unfinished">Floating menu</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/taskbarwidget/arrow_widget.cpp" line="176"/>
        <source>全部关闭</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Close all</translation>
    </message>
</context>
<context>
    <name>CardFrameControl</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/cardframe/card_frame_control.cpp" line="159"/>
        <source>启动命令：</source>
        <translation type="unfinished">Start command: </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/cardframe/card_frame_control.cpp" line="159"/>
        <source>描述：</source>
        <translation type="unfinished">Description:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/cardframe/card_frame_control.cpp" line="182"/>
        <source>启动失败</source>
        <translation type="unfinished">Startup failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/cardframe/card_frame_control.cpp" line="183"/>
        <source>工具启动数量已达最大限制</source>
        <translation type="unfinished">The number of tool starts has reached the maximum limit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/cardframe/card_frame_control.cpp" line="212"/>
        <source>关闭%1</source>
        <translation type="unfinished">Close %1</translation>
    </message>
</context>
<context>
    <name>CommandManager</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="174"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="373"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="415"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="450"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="470"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="594"/>
        <source>启动失败</source>
        <translation type="unfinished">Startup failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="175"/>
        <source>配置了单启动，进程已存在，不可重复启动</source>
        <translation type="unfinished">Single startup is configured. The process already exists and cannot be started duplicatedly</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="374"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="416"/>
        <source>无法找到当前工具权限配置</source>
        <translation type="unfinished">Unable to find the current tool permission config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="430"/>
        <source>工具已启动，请检查</source>
        <translation type="unfinished">Tool started, please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="451"/>
        <source>当前节点支持最大启动进程数为%1，启动失败</source>
        <translation type="unfinished">The maximum number of startup processes supported by the current node is %1. Failed to start </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="470"/>
        <source>用户未登录，请登录</source>
        <translation type="unfinished">User is not logged in, please log in</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="559"/>
        <source>(自动)</source>
        <translation type="unfinished">(Auto)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="594"/>
        <source>工具打开失败</source>
        <translation type="unfinished">Tool open failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="682"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="696"/>
        <source>(推画面)</source>
        <translation type="unfinished">(Push graph)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/event/command_manager.cpp" line="430"/>
        <source>已启动</source>
        <translation type="unfinished">Started</translation>
    </message>
</context>
<context>
    <name>GuiManagerMainWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="207"/>
        <source>界面管理器</source>
        <translation type="unfinished">Interface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="638"/>
        <source>关闭</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="540"/>
        <source>切换用户</source>
        <translation type="unfinished">Switch User</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="638"/>
        <source>是否确认关闭</source>
        <translation type="unfinished">Are you sure to close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="655"/>
        <source>全屏</source>
        <translation type="unfinished">Full Screen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="661"/>
        <source>退出全屏</source>
        <translation type="unfinished">Exit Full Screen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1349"/>
        <source>重启生效</source>
        <translation type="unfinished">Effective after restart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1349"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1374"/>
        <source>停用系统</source>
        <translation type="unfinished">Stop system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1374"/>
        <source>是否停用</source>
        <translation type="unfinished">Whether to deactivate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1399"/>
        <source>重启设备</source>
        <translation type="unfinished">Restart device</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1399"/>
        <source>是否重启</source>
        <translation type="unfinished">Whether to restart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1424"/>
        <source>关闭电源</source>
        <translation type="unfinished">Power off</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1424"/>
        <source>是否关闭</source>
        <translation type="unfinished">Whether to close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1627"/>
        <source>：未配置权限</source>
        <translation type="unfinished">: No permissions configured</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1636"/>
        <source>失败原因:</source>
        <translation type="unfinished">Failure reason:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1884"/>
        <source>退出当前会话</source>
        <translation type="unfinished">Exit This Session</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1885"/>
        <source>长时间内未做任何操作，退出当前会话</source>
        <translation type="unfinished">No action has been taken for a long time; exiting the current session</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="797"/>
        <source>版本信息</source>
        <translation type="unfinished">Version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="540"/>
        <source>是否切换用户?</source>
        <translation type="unfinished">Whether to switch users?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="541"/>
        <source>是</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="542"/>
        <source>否</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1337"/>
        <source>应用错误</source>
        <translation type="unfinished">Apply error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1338"/>
        <source>界面处于最大化，无法记录当前界面尺寸</source>
        <translation type="unfinished">The interface is maximized and the current interface size cannot be recorded</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/gui_manager_mainwidget.cpp" line="1635"/>
        <source>跟随启动失败</source>
        <translation type="unfinished">Follow start failed</translation>
    </message>
</context>
<context>
    <name>LinuxMsgBox</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/popupdialog/linux_msgbox.cpp" line="47"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/popupdialog/linux_msgbox.cpp" line="51"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/popupdialog/linux_msgbox.cpp" line="95"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/popupdialog/linux_msgbox.cpp" line="52"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/popupdialog/linux_msgbox.cpp" line="96"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>MainMenu</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="34"/>
        <source>帮助中心</source>
        <translation type="unfinished">Help Center</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="39"/>
        <source>关于界面</source>
        <translation type="unfinished">Interface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="43"/>
        <source>停止系统</source>
        <translation type="unfinished">Stop system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="47"/>
        <source>重启系统</source>
        <translation type="unfinished">Restart system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="51"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="75"/>
        <source>关闭电源</source>
        <translation type="unfinished">Power off</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="55"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="76"/>
        <source>全屏</source>
        <translation type="unfinished">Full Screen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="71"/>
        <source>帮助</source>
        <translation type="unfinished">Help</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="72"/>
        <source>关于</source>
        <translation type="unfinished">About</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="73"/>
        <source>停用系统</source>
        <translation type="unfinished">Stop system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/main_menu.cpp" line="74"/>
        <source>重启设备</source>
        <translation type="unfinished">Restart device</translation>
    </message>
</context>
<context>
    <name>MsgLovelyBox</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/popupdialog/msg_lovelybox.cpp" line="23"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/popupdialog/msg_lovelybox.cpp" line="24"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="211"/>
        <source>系统已启动</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">System has started</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="212"/>
        <source>当前不允许无系统登录，请使用其他方式登录</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Currently no system login is allowed, please use other methods to log in</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="289"/>
        <source>参数解析失败</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Params parsing failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="289"/>
        <source>请检查</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="336"/>
        <source>磁盘告警</source>
        <comment>gui_manager::main</comment>
        <translation type="unfinished">Disk alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="337"/>
        <source>磁盘已使用%1%,请注意!</source>
        <comment>gui_manager::main</comment>
        <translation type="unfinished">The disk has been used %1%, please note!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="376"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="406"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="469"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="477"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="516"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="542"/>
        <source>提示</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="377"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="407"/>
        <source>初始化失败，程序退出</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Initialization failed, program exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="470"/>
        <source>已配置单启动，程序退出</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Single start configured, program exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="478"/>
        <source>不是自启动模式，程序退出</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Not in auto-start mode, program exits</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="517"/>
        <source>统一初始化失败，程序退出</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Uniform initialization failed, program exited</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/main.cpp" line="543"/>
        <source>获取用户支持的工具列表错误，程序退出</source>
        <comment>gui_manager</comment>
        <translation type="unfinished">Error in retrieving the list of tools supported by the user, program exits</translation>
    </message>
</context>
<context>
    <name>ShowIconDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/popupdialog/show_icon_dialog.cpp" line="45"/>
        <source>展示图标</source>
        <translation type="unfinished">Display icon</translation>
    </message>
</context>
<context>
    <name>TitleWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="73"/>
        <source>登录时限：</source>
        <translation type="unfinished">Login time limit:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="80"/>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="229"/>
        <source>换肤</source>
        <translation type="unfinished">Skin change</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="230"/>
        <source>主菜单</source>
        <translation type="unfinished">Main menu</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="231"/>
        <source>最小化</source>
        <translation type="unfinished">Minimize</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="232"/>
        <source>最大化</source>
        <translation type="unfinished">Maximize</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="233"/>
        <source>关闭</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="537"/>
        <source>柔性异构一体化平台</source>
        <comment>toolName</comment>
        <translation type="unfinished">Flex-Hetero Platform</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="573"/>
        <source>授权到期时间：</source>
        <translation type="unfinished">Authorization expiration time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="568"/>
        <source>(节点名：</source>
        <translation type="unfinished">(Node:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="89"/>
        <source>临时许可</source>
        <translation type="unfinished">Temporary License</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="562"/>
        <source>(系统名：</source>
        <translation type="unfinished">(System:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="562"/>
        <source>现场名：</source>
        <translation type="unfinished">Site name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/title_widget.cpp" line="563"/>
        <source>节点名：</source>
        <translation type="unfinished">Node name:</translation>
    </message>
</context>
<context>
    <name>WaveBallWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/wave_ball_widget.cpp" line="203"/>
        <source>显示主界面</source>
        <translation type="unfinished">Display the main interface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/wave_ball_widget.cpp" line="204"/>
        <source>退出</source>
        <translation type="unfinished">Logout</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_manager/src/widget/wave_ball_widget.cpp" line="205"/>
        <source>隐藏</source>
        <translation type="unfinished">Hide</translation>
    </message>
</context>
</TS>
