<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AppSettingModuleConfigWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="62"/>
        <source>一级标题栏，%1重复</source>
        <translation type="unfinished">Main title bar, %1 is duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="66"/>
        <source>二级导航栏，%1重复</source>
        <translation type="unfinished">Secondary navigation bar, %1 is duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="92"/>
        <source>重置文件</source>
        <translation type="unfinished">Reset file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="92"/>
        <source>是否重置</source>
        <translation type="unfinished">Whether to reset it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="92"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="120"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="203"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="211"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="92"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="120"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="120"/>
        <source>应用发布</source>
        <translation type="unfinished">Application Publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="120"/>
        <source>是否发布</source>
        <translation type="unfinished">Published</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="144"/>
        <source>应用发布</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="149"/>
        <source>取消修改</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel changes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="151"/>
        <source>取消工具配置修改</source>
        <translation type="unfinished">Cancel the modification of tool config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="153"/>
        <source>上传</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Upload</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="203"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="211"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="211"/>
        <source>发布成功，重启控制台生效</source>
        <translation type="unfinished">Successfully published, restart the console to take effect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="62"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="66"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="70"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="74"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="70"/>
        <source>%1</source>
        <translation type="unfinished">%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="74"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="147"/>
        <source>发布配置</source>
        <translation type="unfinished">Publish Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="155"/>
        <source>上传文件</source>
        <translation type="unfinished">Upload file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/app_setting_module_config_widget.cpp" line="203"/>
        <source>发布失败</source>
        <translation type="unfinished">Publish failed</translation>
    </message>
</context>
<context>
    <name>FCustomTreeWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="58"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="69"/>
        <source>请输入名称</source>
        <translation type="unfinished">Please enter name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="71"/>
        <source>请添加描述</source>
        <translation type="unfinished">Please add a description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="72"/>
        <source>请输入启动命令</source>
        <translation type="unfinished">Please enter the start command</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="103"/>
        <source>删除节点</source>
        <translation type="unfinished">Delete node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="59"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="70"/>
        <source>请选择图标</source>
        <translation type="unfinished">Please select the icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="75"/>
        <source>不跟随启动</source>
        <translation type="unfinished">No follow start</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="103"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="103"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="103"/>
        <source>是否删除</source>
        <translation type="unfinished">Whether to delete it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="359"/>
        <source>新建</source>
        <translation type="unfinished">New</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="362"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="365"/>
        <source>上移</source>
        <translation type="unfinished">Move up</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="367"/>
        <source>下移</source>
        <translation type="unfinished">Move down</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="370"/>
        <source>验证</source>
        <translation type="unfinished">Verify</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="382"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="382"/>
        <source>图标</source>
        <translation type="unfinished">Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="382"/>
        <source>权限</source>
        <translation type="unfinished">Permission</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="382"/>
        <source>参数</source>
        <translation type="unfinished">Param</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="382"/>
        <source>描述</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="383"/>
        <source>跟随启动</source>
        <translation type="unfinished">Follow start</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="383"/>
        <source>跟随关闭</source>
        <translation type="unfinished">Follow close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="383"/>
        <source>常驻</source>
        <translation type="unfinished">Permanent</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="383"/>
        <source>推画面最大进程数量</source>
        <translation type="unfinished">Maximum Proc. for pushing graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="384"/>
        <source>手动启动最大进程数量</source>
        <translation type="unfinished">Manual Maximum Proc.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="384"/>
        <source>ID</source>
        <translation type="unfinished">ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="384"/>
        <source>B端参数</source>
        <translation type="unfinished">Params of browser</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget.cpp" line="384"/>
        <source>启动弹窗</source>
        <translation type="unfinished">Startup Dialog</translation>
    </message>
</context>
<context>
    <name>MyDelegate</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="93"/>
        <source>选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="110"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="174"/>
        <source>选择图标文件</source>
        <translation type="unfinished">Select icon file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="112"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="176"/>
        <source>PNG 文件</source>
        <translation type="unfinished">PNG file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="112"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="176"/>
        <source>SVG 文件</source>
        <translation type="unfinished">SVG file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="112"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="176"/>
        <source>JPG 文件</source>
        <translation type="unfinished">JPG file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="113"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="177"/>
        <source>图标文件</source>
        <translation type="unfinished">Icon file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="113"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="177"/>
        <source>所有文件</source>
        <translation type="unfinished">All files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="140"/>
        <source>不跟随启动</source>
        <translation type="unfinished">No follow start</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="140"/>
        <source>自启动</source>
        <translation type="unfinished">Self starting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_treewidget_delegate.cpp" line="140"/>
        <source>自启动守护</source>
        <translation type="unfinished">Self starting guard</translation>
    </message>
</context>
<context>
    <name>SettinWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="47"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="48"/>
        <source>基础配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Basic Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="50"/>
        <source>平台工具配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Platform Tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="51"/>
        <source>平台工具配置</source>
        <translation type="unfinished">Platform Tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="57"/>
        <source>应用工具配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">App Tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="58"/>
        <source>应用工具配置</source>
        <translation type="unfinished">Application Tool Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="73"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="73"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="73"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_widget.cpp" line="73"/>
        <source>存在未保存修改，是否保存发布？</source>
        <translation type="unfinished">Unsaved modifications. Save &amp; publish?</translation>
    </message>
</context>
<context>
    <name>SettingBaseConfigWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="108"/>
        <source>固定</source>
        <translation type="unfinished">Fixed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="105"/>
        <source>任务栏高度设置：</source>
        <translation type="unfinished">Taskbar height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="95"/>
        <source>启动画面显示屏设置：</source>
        <translation type="unfinished">Startup graph display screen setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="97"/>
        <source>主屏</source>
        <translation type="unfinished">Main screen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="98"/>
        <source>副屏</source>
        <translation type="unfinished">Secondary screen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="110"/>
        <source>高度：</source>
        <translation type="unfinished">Height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="128"/>
        <source>显示搜索</source>
        <translation type="unfinished">Show Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="129"/>
        <source>解裂退出</source>
        <translation type="unfinished">Split exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="130"/>
        <source>控制台异机监护</source>
        <translation type="unfinished">Console foreign machine monitor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="164"/>
        <source>应用发布</source>
        <comment>buttonName</comment>
        <translation type="unfinished">App publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="166"/>
        <source>取消修改</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel changes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="277"/>
        <source>发布成功，重启控制台生效</source>
        <translation type="unfinished">Successfully published, restart the console to take effect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="283"/>
        <source>应用发布</source>
        <translation type="unfinished">Application Publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="283"/>
        <source>是否发布</source>
        <translation type="unfinished">Published</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="297"/>
        <source>取消修改</source>
        <translation type="unfinished">Cancel changes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="297"/>
        <source>是否取消修改</source>
        <translation type="unfinished">Whether to cancel the modification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="268"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="277"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="283"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="297"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="268"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="277"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="268"/>
        <source>发布失败</source>
        <translation type="unfinished">Publish failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="283"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_base_config_widget.cpp" line="297"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>SettingModuleConfigWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="92"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="120"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="203"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="212"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="92"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="120"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="62"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="66"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="70"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="74"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="62"/>
        <source>一级导航栏，%1重复</source>
        <translation type="unfinished">First-level navigation bar, %1 duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="66"/>
        <source>二级工具栏，%1重复</source>
        <translation type="unfinished">Secondary toolbar,%1 duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="70"/>
        <source>%1</source>
        <translation type="unfinished">%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="74"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="92"/>
        <source>取消修改</source>
        <translation type="unfinished">Cancel changes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="92"/>
        <source>是否取消修改</source>
        <translation type="unfinished">Whether to cancel the modification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="120"/>
        <source>应用发布</source>
        <translation type="unfinished">Application Publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="120"/>
        <source>是否发布</source>
        <translation type="unfinished">Published</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="144"/>
        <source>应用发布</source>
        <comment>buttonName</comment>
        <translation type="unfinished">App publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="149"/>
        <source>取消修改</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel changes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="151"/>
        <source>取消工具配置</source>
        <translation type="unfinished">Cancel Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="153"/>
        <source>上传</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Upload</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="155"/>
        <source>将本地文件上传到文件服务</source>
        <translation type="unfinished">Upload local files to file service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="203"/>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="212"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="212"/>
        <source>发布成功，重启控制台生效</source>
        <translation type="unfinished">Successfully published, restart the console to take effect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="147"/>
        <source>发布配置</source>
        <translation type="unfinished">Publish Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_console_setting_plug/src/setting_module_config_widget.cpp" line="203"/>
        <source>发布失败</source>
        <translation type="unfinished">Publish failed</translation>
    </message>
</context>
</TS>
