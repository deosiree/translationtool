<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>GraphicInfoViewerPlug</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_info_viewer_plug.cpp" line="49"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_info_viewer_plug.cpp" line="54"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_info_viewer_plug.cpp" line="78"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_info_viewer_plug.cpp" line="49"/>
        <source>对象为空</source>
        <translation type="unfinished">Objeto vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_info_viewer_plug.cpp" line="54"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_info_viewer_plug.cpp" line="78"/>
        <source>前景为空</source>
        <translation type="unfinished">Primer plano vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_info_viewer_plug.cpp" line="59"/>
        <source>对象信息查询</source>
        <comment>toolName</comment>
        <translation type="unfinished">Consulta de Info del Objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_info_viewer_plug.cpp" line="84"/>
        <source>画面信息查询</source>
        <comment>toolName</comment>
        <translation type="unfinished">Consulta de Info del Gráfica</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2190"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
</context>
<context>
    <name>ViewerGraphInfoWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="14"/>
        <source>画面信息</source>
        <translation type="unfinished">Información del gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="22"/>
        <source>当前画面模式应用:</source>
        <translation type="unfinished">Modo de gráfica actual:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="36"/>
        <source>当前画面模式库:</source>
        <translation type="unfinished">Base de datos de modo actual del gráfico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="50"/>
        <source>应用全名:</source>
        <translation type="unfinished">Nombre completo de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="64"/>
        <source>库名:</source>
        <translation type="unfinished">Nombre de la base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="78"/>
        <source>画面刷新周期:</source>
        <translation type="unfinished">Ciclo de actualización del gráfico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="92"/>
        <source>画面文件名称:</source>
        <translation type="unfinished">Nombre del archivo del gráfico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="106"/>
        <source>画面名称:</source>
        <translation type="unfinished">Nombre del gráfico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="120"/>
        <source>画面Oid:</source>
        <translation type="unfinished">Oid del gráfico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="148"/>
        <source>缓存画面版本:</source>
        <translation type="unfinished">Versión de caché del gráfico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="155"/>
        <source>TODO</source>
        <translation type="unfinished">TODO</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="134"/>
        <source>最新画面版本:</source>
        <translation type="unfinished">Última versión del gráfico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="168"/>
        <source>通配符</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Comodín</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="175"/>
        <source>通配符</source>
        <translation type="unfinished">Comodín</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="180"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="185"/>
        <source>替换值</source>
        <translation type="unfinished">Reemplazar valor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="190"/>
        <source>域</source>
        <translation type="unfinished">Área</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="199"/>
        <source>静态文本</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Texto Estático</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="206"/>
        <source>源字符串值</source>
        <comment>subTitle </comment>
        <translation type="unfinished">Valor de cadena de origen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="211"/>
        <source>描述</source>
        <comment>subTitle </comment>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="216"/>
        <source>目标字符串值</source>
        <comment>subTitle </comment>
        <translation type="unfinished">Valor de cadena objetivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="221"/>
        <source>是否替换光敏点</source>
        <comment>subTitle </comment>
        <translation type="unfinished">Reemplazar el punto fotosensible</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.ui" line="226"/>
        <source>域</source>
        <comment>subTitle </comment>
        <translation type="unfinished">Área</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.cpp" line="202"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Verdadero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_graphinfo_widegt.cpp" line="202"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
</context>
<context>
    <name>ViewerObjectInfoWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="14"/>
        <source>对象信息</source>
        <translation type="unfinished">Información del objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="173"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="212"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="251"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="290"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="329"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="649"/>
        <source>决策表达式</source>
        <translation type="unfinished">Expresión de decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="183"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="222"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="261"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="300"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="339"/>
        <source>决策因子</source>
        <translation type="unfinished">Factor de decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="35"/>
        <source>对象信息：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="105"/>
        <source>决策信息：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="116"/>
        <source>颜色决策</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Decisión de Color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="134"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="1782"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="1817"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="1879"/>
        <source>决策表达式列表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="144"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="815"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="1964"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2408"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2804"/>
        <source>决策因子列表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="155"/>
        <source>符号决策</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Decisión de Símbolo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="194"/>
        <source>闪烁决策</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Decisión de Parpadeo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="233"/>
        <source>字符决策</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Decisión de Carácter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="272"/>
        <source>函数决策</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Decisión Funcional</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="311"/>
        <source>使能决策</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Habilitar Decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="375"/>
        <source>刷新因子值</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Factor de actualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.ui" line="368"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="450"/>
        <source>无</source>
        <translation type="unfinished">Ninguno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="545"/>
        <source>状态前景</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="592"/>
        <source>光敏点</source>
        <translation type="unfinished">Punto fotosensible</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="631"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="923"/>
        <source>序号</source>
        <translation type="unfinished">Núm.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="637"/>
        <source>命中</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="655"/>
        <source>字符色</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="684"/>
        <source>填充色</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="713"/>
        <source>边框色</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="929"/>
        <source>名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="935"/>
        <source>拼接条件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="941"/>
        <source>表名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="947"/>
        <source>取值oid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="953"/>
        <source>域名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="959"/>
        <source>库值</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="965"/>
        <source>缓存值</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="1071"/>
        <source>提示：该对象没有前景信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2057"/>
        <source>域:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2099"/>
        <source>应用:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2099"/>
        <source>库:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2099"/>
        <source>表:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2103"/>
        <source>图元名称：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2186"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2190"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2238"/>
        <source>库值：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="643"/>
        <source>决策名</source>
        <translation type="unfinished">Nombre de la decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="660"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="665"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="670"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="675"/>
        <source>决策值</source>
        <translation type="unfinished">Valor de decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="689"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="694"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="699"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="704"/>
        <source>决策值2</source>
        <translation type="unfinished">Valor de decisión 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="718"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="723"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="728"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="733"/>
        <source>决策值3</source>
        <translation type="unfinished">Valor de decisión 3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2071"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2081"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2220"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2237"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2238"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2302"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2352"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2360"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2388"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2472"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2473"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2474"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2475"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2476"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2477"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2535"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2537"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2538"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2567"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2596"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2612"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2614"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2615"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2623"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2624"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2625"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2626"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2627"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2628"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2755"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2216"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2231"/>
        <source>空</source>
        <translation type="unfinished">Nulo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2216"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2220"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2231"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2237"/>
        <source>缓存值：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2242"/>
        <source>对象OID：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2302"/>
        <source>无法获取决策类型索引</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2352"/>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2755"/>
        <source>表格指针为空</source>
        <translation type="unfinished">Puntero de tabla vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2360"/>
        <source>未选中决策表达式行</source>
        <translation type="unfinished">Fila de expr. de decisión no seleccionada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_info_viewer_plug/graphic_viewer_objectinfo_widegt.cpp" line="2388"/>
        <source>pExpressionTmp为空</source>
        <translation type="unfinished">pExpressionTmp vacío</translation>
    </message>
</context>
</TS>
