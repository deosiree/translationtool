<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CalcEditorCalcMdl</name>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.ui" line="38"/>
        <source>验证</source>
        <translation type="unfinished">Verificar</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="57"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="155"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="461"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="471"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="480"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="498"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="504"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="510"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="516"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="522"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="283"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="360"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="58"/>
        <source>打开%1计算库失败,请检查应用是否配置</source>
        <translation type="unfinished">Fallo la apertura de la base de datos de cálculo %1, por favor verifique si la aplicación está configurada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="149"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="237"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="287"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="487"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="295"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="149"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="487"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="295"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="155"/>
        <source>保存失败</source>
        <translation type="unfinished">Fallo al guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="224"/>
        <source>添加计算目标组</source>
        <translation type="unfinished">Nuevo grupo de objetivos de cálculo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="234"/>
        <source>删除计算目标组</source>
        <translation type="unfinished">Eliminar grupo de objetivos de cálculo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="237"/>
        <source>是否删除该计算目标组?</source>
        <translation type="unfinished">¿Eliminar el grupo de objetivos de cálculo?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="275"/>
        <source>添加计算目标</source>
        <translation type="unfinished">Agregar objetivo de cálculo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="284"/>
        <source>删除计算目标</source>
        <translation type="unfinished">Eliminar objetivo de cálculo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="287"/>
        <source>是否删除该计算目标?</source>
        <translation type="unfinished">¿Eliminar este objetivo de cálculo?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="295"/>
        <source>修改计算目标</source>
        <translation type="unfinished">Modificar objetivos de cálculo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_editor_calcmdl.cpp" line="309"/>
        <source>全部</source>
        <translation type="unfinished">Todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_delegate.cpp" line="182"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="119"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_delegate.cpp" line="183"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="123"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="55"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="54"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="57"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="59"/>
        <source>应用</source>
        <translation type="unfinished">App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="61"/>
        <source>数据库</source>
        <translation type="unfinished">Base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="63"/>
        <source>链接类型</source>
        <translation type="unfinished">Tipo de enlace</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="65"/>
        <source>表名</source>
        <translation type="unfinished">Nombre de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="67"/>
        <source>值字段</source>
        <translation type="unfinished">Campo de valor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="69"/>
        <source>时间字段</source>
        <translation type="unfinished">Campo de tiempo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="71"/>
        <source>标志字段</source>
        <translation type="unfinished">Campo de indicador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="73"/>
        <source>计算方式</source>
        <translation type="unfinished">Método de cálculo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="75"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="70"/>
        <source>计算周期</source>
        <translation type="unfinished">Ciclo de cálculo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="127"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="165"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="125"/>
        <source>未知类型</source>
        <translation type="unfinished">Tipo desconocido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="196"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="154"/>
        <source>未知周期</source>
        <translation type="unfinished">Ciclo desconocido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="415"/>
        <source>重复警告</source>
        <translation type="unfinished">Advertencia repetida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="415"/>
        <source>计算表格信息重复，请重新选择</source>
        <translation type="unfinished">La información de la tabla de cálculo está duplicada, por favor seleccione nuevamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="430"/>
        <source>修改警告</source>
        <translation type="unfinished">Modificar advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="431"/>
        <source>修改计算结果配置信息会导致计算结果丢失，是否继续？</source>
        <translation type="unfinished">Modificar la información de configuración del resultado de cálculo resultará en la pérdida del resultado de cálculo. ¿Desea continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="461"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="283"/>
        <source>名称包含非法字符，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="471"/>
        <source>添加数据失败</source>
        <translation type="unfinished">Fallo al agregar datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="480"/>
        <source>更新数据失败</source>
        <translation type="unfinished">Fallo al actualizar datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="498"/>
        <source>第%1行名称为空，请重新输入</source>
        <translation type="unfinished">El nombre en la línea %1 está vacío, por favor vuelva a ingresarlo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="504"/>
        <source>第%1行应用为空，请重新输入</source>
        <translation type="unfinished">La aplicación en la línea %1 está vacía, por favor ingrésela de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="510"/>
        <source>第%1行数据库为空，请重新输入</source>
        <translation type="unfinished">La base de datos en la línea %1 está vacía, por favor ingrésela de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="516"/>
        <source>第%1行表名为空，请重新输入</source>
        <translation type="unfinished">El nombre de la tabla en la fila %1 está vacío, por favor ingréselo de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_grp_cfg_model.cpp" line="522"/>
        <source>第%1行值字段为空，请重新输入</source>
        <translation type="unfinished">El campo de valor en la línea %1 está vacío, por favor ingréselo de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="58"/>
        <source>任务名称</source>
        <translation type="unfinished">Nombre de la tarea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="62"/>
        <source>目标路径</source>
        <translation type="unfinished">Ruta de destino</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="66"/>
        <source>计算类型</source>
        <translation type="unfinished">Tipo de cálculo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_calcmdl/calc_mgr_tag_model.cpp" line="360"/>
        <source>计算目标[%1]已存在</source>
        <translation type="unfinished">El objetivo de cálculo [%1] ya existe</translation>
    </message>
</context>
</TS>
