<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>ChoseUpFile</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/choseUpFile.cpp" line="127"/>
        <source>选择文件</source>
        <translation type="unfinished">Select file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/choseUpFile.ui" line="54"/>
        <source>上传文件：</source>
        <translation type="unfinished">Upload file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/choseUpFile.ui" line="149"/>
        <source>上传方式：</source>
        <translation type="unfinished">Upload method:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/choseUpFile.ui" line="95"/>
        <source>文件描述：</source>
        <translation type="unfinished">File description:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/choseUpFile.ui" line="112"/>
        <source>版本备注：</source>
        <translation type="unfinished">Version remark:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/choseUpFile.ui" line="166"/>
        <source>上传版本：</source>
        <translation type="unfinished">Upload version:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/choseUpFile.ui" line="263"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/choseUpFile.ui" line="279"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/choseUpFile.cpp" line="60"/>
        <source>文件选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">File Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/choseUpFile.cpp" line="76"/>
        <source>普通上传</source>
        <translation type="unfinished">General upload</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/choseUpFile.cpp" line="77"/>
        <source>显式上传[图形]</source>
        <translation type="unfinished">Explicit upload [graphic]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/choseUpFile.cpp" line="127"/>
        <source>全部文件%1</source>
        <translation type="unfinished">All the files %1</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.ui" line="59"/>
        <source>节点：</source>
        <translation type="unfinished">Node:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.ui" line="88"/>
        <source>目录：</source>
        <translation type="unfinished">DIR:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.ui" line="46"/>
        <source>文件服务：</source>
        <translation type="unfinished">File service:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.ui" line="162"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.ui" line="184"/>
        <source>上传</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Upload</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.ui" line="206"/>
        <source>下载</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Download</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.ui" line="222"/>
        <source>一键下载</source>
        <comment>buttonName</comment>
        <translation type="unfinished">One-click download</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.ui" line="265"/>
        <source>搜索</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.ui" line="278"/>
        <source>过滤</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.ui" line="296"/>
        <source>*提示：仅显示服务器文件信息</source>
        <translation type="unfinished">*Tip: Only display server file info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="137"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="513"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="667"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="924"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="137"/>
        <source>无系统模式</source>
        <translation type="unfinished">No system mode</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="147"/>
        <source>下载中……请等待</source>
        <translation type="unfinished">Downloading... Please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="182"/>
        <source>请输入内容</source>
        <translation type="unfinished">Please enter content</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="255"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="351"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="426"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="508"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="724"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="956"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="1089"/>
        <source>错误信息</source>
        <translation type="unfinished">Error message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="310"/>
        <source>路径</source>
        <translation type="unfinished">Path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="310"/>
        <source>文件名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">File name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="310"/>
        <source>类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="310"/>
        <source>文件大小[B]</source>
        <comment>subTitle</comment>
        <translation type="unfinished">File size[B]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="310"/>
        <source>修改时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Modification time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="450"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="552"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="616"/>
        <source>无版本托管配置文件</source>
        <translation type="unfinished">Config file without version control</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="462"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="564"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="628"/>
        <source>无版本托管运行文件</source>
        <translation type="unfinished">Running file without version control</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="494"/>
        <source>查询中......请等待</source>
        <translation type="unfinished">Querying...Please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="513"/>
        <source>查询文件个数：%1</source>
        <translation type="unfinished">Number of queried files: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="667"/>
        <source>上传目标目录不能为空</source>
        <translation type="unfinished">The upload destination dir cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="741"/>
        <source>上传文件【%1】%2至目录{%3}</source>
        <translation type="unfinished">Upload file [%1] %2 to directory {%3}</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="745"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="854"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="916"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="928"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="1107"/>
        <source>信息</source>
        <translation type="unfinished">Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="916"/>
        <source>请选择需要下载文件</source>
        <translation type="unfinished">Please select the file to download</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="936"/>
        <source>下载中......请等待</source>
        <translation type="unfinished">Downloading... Please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="1107"/>
        <source>刷新完成</source>
        <translation type="unfinished">Refresh completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="896"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="454"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="556"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="620"/>
        <source>隐式版本托管配置文件</source>
        <translation type="unfinished">Implicit version hosting configuration file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="458"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="560"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="624"/>
        <source>显式版本托管配置文件</source>
        <translation type="unfinished">Explicit version hosting configuration file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="466"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="568"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="632"/>
        <source>隐式版本托管运行文件</source>
        <translation type="unfinished">Implicit version hosting running file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="470"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="572"/>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="636"/>
        <source>显式版本托管运行文件</source>
        <translation type="unfinished">Explicit version hosting running files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="896"/>
        <source>下载失败</source>
        <translation type="unfinished">Download failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="907"/>
        <source>下载成功</source>
        <translation type="unfinished">Download successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="924"/>
        <source>打包所有文件至 %1/tempFileMgr.zip 并且解压文件至 %2/tempFileMgr</source>
        <translation type="unfinished">Pack all files to %1/tempFileMgr.zip and unzip the files to %2/tempFileMgr</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_local_sync/mainwindow.cpp" line="965"/>
        <source>下载完成</source>
        <translation type="unfinished">Download completed</translation>
    </message>
</context>
</TS>
