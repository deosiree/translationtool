<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CSecPwWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="108"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="111"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="65"/>
        <source>类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="67"/>
        <source>用户名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Username</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="69"/>
        <source>密码</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="83"/>
        <source>时序库默认用户</source>
        <translation type="unfinished">Default user of STDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="84"/>
        <source>时序库管理员用户</source>
        <translation type="unfinished">STDB administrator</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="85"/>
        <source>时序库操作员用户</source>
        <translation type="unfinished">STDB operator</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="86"/>
        <source>关系库操作员用户</source>
        <translation type="unfinished">RDB operator user</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="87"/>
        <source>备用用户</source>
        <translation type="unfinished">Backup user</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="109"/>
        <source>新增</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="110"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="184"/>
        <source>记录</source>
        <translation type="unfinished">Records</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="184"/>
        <source>是否删除</source>
        <translation type="unfinished">Whether to delete it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="185"/>
        <source>询问</source>
        <translation type="unfinished">Ask</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="243"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="272"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="278"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="272"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.cpp" line="278"/>
        <source>刷新成功</source>
        <translation type="unfinished">Refresh successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.ui" line="51"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/secpwwidget.ui" line="63"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secpw/pluginsecpw.cpp" line="40"/>
        <source>安全密码配置</source>
        <translation type="unfinished">Security Password Config</translation>
    </message>
</context>
</TS>
