<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="24"/>
        <source>人员/设备管理</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="32"/>
        <source>设备管理</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="42"/>
        <source>设备名称：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="56"/>
        <source>设备串口：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="70"/>
        <source>中心号码：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="80"/>
        <source>获取中心号码</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="94"/>
        <source>人员管理</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="117"/>
        <source>导入用户列表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="124"/>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="198"/>
        <source>新增</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="131"/>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="205"/>
        <source>删除</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="158"/>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="232"/>
        <source>保存</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="175"/>
        <source>短信策略配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="244"/>
        <source>短信历史记录</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="252"/>
        <source>查询条件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="262"/>
        <source>发送时间：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="279"/>
        <source>人员名称：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="297"/>
        <source>角色类型：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="311"/>
        <source>短信类型：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="325"/>
        <source>短信内容：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="342"/>
        <source>查询结果</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="365"/>
        <source>查询</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="385"/>
        <source>短信发送测试</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="395"/>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.cpp" line="137"/>
        <source>短信类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.ui" line="425"/>
        <source>发送</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.cpp" line="91"/>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.cpp" line="137"/>
        <source>人员名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.cpp" line="91"/>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.cpp" line="114"/>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.cpp" line="137"/>
        <source>角色</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.cpp" line="91"/>
        <source>手机号</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.cpp" line="91"/>
        <source>接收时间段</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.cpp" line="114"/>
        <source>类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.cpp" line="114"/>
        <source>短信特征</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_sms_tool/mainwindow.cpp" line="137"/>
        <source>短信内容</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
