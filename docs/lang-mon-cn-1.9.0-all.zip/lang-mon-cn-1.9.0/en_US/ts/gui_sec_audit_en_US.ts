<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CAuditConfigDlg</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="28"/>
        <source>审计日志保存时间(月):</source>
        <translation type="unfinished">Audit log retention period (month):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="64"/>
        <source>审计容量检测周期(s):</source>
        <translation type="unfinished">Audit capacity detection cycle (s):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="35"/>
        <source>审计日志告警阈值(GB):    </source>
        <translation type="unfinished">Audit log alarm threshold (GB):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="71"/>
        <source>审计告警比例(%):</source>
        <translation type="unfinished">Audit alarms ratio (%):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="20"/>
        <source>审计容量参数</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Audit capacity params</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="110"/>
        <source>审计日志完整性保护</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Audit log integrity protection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="124"/>
        <source>日志级别:</source>
        <translation type="unfinished">Log level:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="134"/>
        <source>紧急</source>
        <translation type="unfinished">Exigency</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="144"/>
        <source>重要</source>
        <translation type="unfinished">Importance</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="151"/>
        <source>次要</source>
        <translation type="unfinished">Secondary</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="158"/>
        <source>一般</source>
        <translation type="unfinished">Normal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="165"/>
        <source>告知</source>
        <translation type="unfinished">Inform</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="189"/>
        <source>检测周期(s):</source>
        <translation type="unfinished">Detection cycle (s):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="222"/>
        <source>审计日志天数:</source>
        <translation type="unfinished">Audit log days:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="229"/>
        <source>不限</source>
        <translation type="unfinished">Unlimited</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="267"/>
        <source>审计类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Audit type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="298"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.ui" line="305"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.cpp" line="79"/>
        <source>事件</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Event</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.cpp" line="79"/>
        <source>是否记录</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.cpp" line="493"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.cpp" line="493"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
</context>
<context>
    <name>CAuditConfigDlgPack</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.cpp" line="25"/>
        <source>审计工具配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Audit Tool Config</translation>
    </message>
</context>
<context>
    <name>CAuditItemModel</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/caudititemmodel.cpp" line="79"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/caudititemmodel.cpp" line="79"/>
        <source>失败</source>
        <translation type="unfinished">Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/caudititemmodel.cpp" line="142"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/caudititemmodel.cpp" line="144"/>
        <source>时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/caudititemmodel.cpp" line="146"/>
        <source>用户名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">User name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/caudititemmodel.cpp" line="148"/>
        <source>用户ID</source>
        <comment>subTitle</comment>
        <translation type="unfinished">User ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/caudititemmodel.cpp" line="150"/>
        <source>IP地址</source>
        <comment>subTitle</comment>
        <translation type="unfinished">IP address</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/caudititemmodel.cpp" line="152"/>
        <source>主体</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Main body</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/caudititemmodel.cpp" line="154"/>
        <source>客体</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/caudititemmodel.cpp" line="156"/>
        <source>类别</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Category</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/caudititemmodel.cpp" line="158"/>
        <source>事件</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Event</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/caudititemmodel.cpp" line="160"/>
        <source>级别</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/caudititemmodel.cpp" line="162"/>
        <source>结果</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Result</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/caudititemmodel.cpp" line="164"/>
        <source>内容</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Content</translation>
    </message>
</context>
<context>
    <name>CAuditMain</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="203"/>
        <source>登录超时，重新登录</source>
        <translation type="unfinished">Login timeout, login again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="206"/>
        <source>长时间未操作，重新登录</source>
        <translation type="unfinished">Long time no operation, login again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="208"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
</context>
<context>
    <name>CDlgQueryDb</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/dlgquerydb.cpp" line="19"/>
        <source>查询数据</source>
        <comment>toolName</comment>
        <translation type="unfinished">Query Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/dlgquerydb.cpp" line="61"/>
        <source>退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exit</translation>
    </message>
</context>
<context>
    <name>CQueryDbThread</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/querydbthread.cpp" line="66"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/querydbthread.cpp" line="73"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/querydbthread.cpp" line="79"/>
        <source>正在查询数据...</source>
        <comment>正在查询数据...</comment>
        <translation type="unfinished">Querying data...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/querydbthread.cpp" line="68"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/querydbthread.cpp" line="75"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/querydbthread.cpp" line="81"/>
        <source>查询数据结束</source>
        <comment>查询数据结束</comment>
        <translation type="unfinished">Querying data ends</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="69"/>
        <source>用户：</source>
        <translation type="unfinished">Users:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="83"/>
        <source>类别：</source>
        <translation type="unfinished">Category:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="56"/>
        <source>开始：</source>
        <translation type="unfinished">Start:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="22"/>
        <source>配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="103"/>
        <source>结束：</source>
        <translation type="unfinished">End:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="116"/>
        <source>事件：</source>
        <translation type="unfinished">Event:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="130"/>
        <source>级别：</source>
        <translation type="unfinished">Levels:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="150"/>
        <source>全文搜索：</source>
        <translation type="unfinished">Full text search:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="167"/>
        <source>清空</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="204"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="211"/>
        <source>分析</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Analyze</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="246"/>
        <source>导出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="292"/>
        <source>第一页</source>
        <comment>buttonName</comment>
        <translation type="unfinished">First</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="302"/>
        <source>上一页</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Previous</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="330"/>
        <source>下一页</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Next</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="340"/>
        <source>最后一页</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Last</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="382"/>
        <source>actUserLevel</source>
        <translation type="unfinished">actUserLevel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="385"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="953"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="963"/>
        <source>用户级别统计</source>
        <comment>subTitle</comment>
        <translation type="unfinished">User level statistics</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="397"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="996"/>
        <source>审计类型统计</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Audit type statistics</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="409"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1020"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1028"/>
        <source>按用户统计</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Statistics by user</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="421"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1060"/>
        <source>按级别统计</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Statistics by level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="438"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="941"/>
        <source>用户级别统计</source>
        <translation type="unfinished">User level statistics</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="394"/>
        <source>actAuditType</source>
        <translation type="unfinished">actAuditType</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="975"/>
        <source>审计类型统计</source>
        <translation type="unfinished">Audit Type Statistics</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="406"/>
        <source>actUser</source>
        <translation type="unfinished">actUser</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1008"/>
        <source>按用户统计</source>
        <translation type="unfinished">Statistics by user</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="418"/>
        <source>actLevel</source>
        <translation type="unfinished">actLevel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1040"/>
        <source>按级别统计</source>
        <translation type="unfinished">Statistics by level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="430"/>
        <source>actTile</source>
        <translation type="unfinished">actTile</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.ui" line="433"/>
        <source>平铺</source>
        <translation type="unfinished">Tiled</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="298"/>
        <source>所有类别</source>
        <translation type="unfinished">All categories</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="362"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="363"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="364"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="365"/>
        <source>%1条/页</source>
        <translation type="unfinished">%1 /page</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="407"/>
        <source>审计查询工具</source>
        <comment>toolName</comment>
        <translation type="unfinished">Audit Query Tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="409"/>
        <source>配置</source>
        <translation type="unfinished">Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="410"/>
        <source>查询</source>
        <translation type="unfinished">Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="411"/>
        <source>分析</source>
        <translation type="unfinished">Analyze</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="412"/>
        <source>导出</source>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="413"/>
        <source>清空</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="518"/>
        <source>所有事件</source>
        <translation type="unfinished">All events</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="545"/>
        <source>所有用户</source>
        <translation type="unfinished">All users</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="566"/>
        <source>所有级别</source>
        <translation type="unfinished">All levels</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="571"/>
        <source>紧急</source>
        <translation type="unfinished">Exigency</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="572"/>
        <source>重要</source>
        <translation type="unfinished">Important</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="573"/>
        <source>次要</source>
        <translation type="unfinished">Secondary</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="574"/>
        <source>一般</source>
        <translation type="unfinished">Normal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="575"/>
        <source>告知</source>
        <translation type="unfinished">Inform</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="649"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1153"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1600"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="649"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1153"/>
        <source>查询开始时间要小于结束时间</source>
        <translation type="unfinished">The query start time must be smaller than the end time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="669"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="765"/>
        <source>异常输入</source>
        <translation type="unfinished">Abnormal input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="669"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="766"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished">Abnormal query data, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="675"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="680"/>
        <source>审计工具</source>
        <translation type="unfinished">Audit Tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="987"/>
        <source>审计事件类型统计</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Audit event type statistics</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1052"/>
        <source>按告警级别统计</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Statistics by alarm level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1503"/>
        <source>另存为</source>
        <comment>toolName</comment>
        <translation type="unfinished">Save As</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1505"/>
        <source>Excel文件</source>
        <translation type="unfinished">Excel File</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1522"/>
        <source>Error</source>
        <comment>TN</comment>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1251"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1300"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1600"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/dlgquerydb.cpp" line="81"/>
        <source>查询数据</source>
        <translation type="unfinished">Query data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/main.cpp" line="117"/>
        <source>登录模式不支持，请检查</source>
        <translation type="unfinished">Login mode not supported, please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/main.cpp" line="118"/>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/main.cpp" line="189"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/main.cpp" line="188"/>
        <source>网络注册失败，请检查</source>
        <translation type="unfinished">Net reg failed, please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/main.cpp" line="273"/>
        <source>登录时限：</source>
        <translation type="unfinished">Login time limit:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="163"/>
        <source>审计工具</source>
        <comment>toolName</comment>
        <translation type="unfinished">Audit Tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="163"/>
        <source>节点名</source>
        <comment>toolName</comment>
        <translation type="unfinished">Node Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="674"/>
        <source>%1输入异常字符，可能存在篡改、恶意攻击行为</source>
        <translation type="unfinished">%1 contains abnormal characters; possible tampering/malicious attack detected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="718"/>
        <source>共%1条数据,%2页</source>
        <translation type="unfinished">Total %1 items , %2 pages</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1277"/>
        <source>Top审计事件总数:%1</source>
        <translation type="unfinished">Total number of top audit events: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/mainwindow.cpp" line="1523"/>
        <source>写文件失败(%1) %2</source>
        <translation type="unfinished">File writing failed (%1) %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/gui_sec_audit/auditconfigdlg.cpp" line="23"/>
        <source>审计工具配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Audit Tool Config</translation>
    </message>
</context>
</TS>
