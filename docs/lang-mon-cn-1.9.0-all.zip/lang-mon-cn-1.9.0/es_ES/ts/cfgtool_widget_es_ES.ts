<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/cfgtool_widget.cpp" line="108"/>
        <source>没有读取权限</source>
        <translation type="unfinished">Sin permiso de lectura</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/cfgtool_widget.cpp" line="123"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/cfgtool_widget.cpp" line="123"/>
        <source>请先保存正在编辑的配置组</source>
        <translation type="unfinished">Por favor, guarde el grupo de configuración que está editando primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/cfgtool_widget.cpp" line="264"/>
        <source>配置运行目录失败</source>
        <translation type="unfinished">No se pudo configurar el directorio de ejecución</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="216"/>
        <source>无效的节点！</source>
        <translation type="unfinished">¡Nodo no válido!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="222"/>
        <source>名称未改变！</source>
        <translation type="unfinished">¡El nombre no ha cambiado!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="242"/>
        <source>重命名失败！</source>
        <translation type="unfinished">¡Fallo al renombrar!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="552"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="581"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="613"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="648"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="672"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="751"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="775"/>
        <source>不是配置组！</source>
        <translation type="unfinished">¡No es un grupo de configuración!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="564"/>
        <source>打开配置组失败！</source>
        <translation type="unfinished">¡Fallo al abrir el grupo de configuración!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="587"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="619"/>
        <source>配置组未打开！</source>
        <translation type="unfinished">¡Grupo de configuración no abierto!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="593"/>
        <source>未申请编辑！</source>
        <translation type="unfinished">¡No se solicitó edición!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="599"/>
        <source>保存配置组失败！</source>
        <translation type="unfinished">¡Fallo al guardar el grupo de configuración!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="625"/>
        <source>关闭配置组失败！</source>
        <translation type="unfinished">¡Fallo al cerrar el grupo de configuración!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="661"/>
        <source>导出头文件失败！

1. 请检查配置组能否正确打开
2. 请检查是否存在自定义类型（没有自定义类型则无法导出）</source>
        <translation type="unfinished">¡Fallo al exportar el archivo de encabezado! 
1 Verifique si el grupo de configuración se puede abrir correctamente
2 Verifique si hay un tipo personalizado (si no hay tipo personalizado, no se puede exportar)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="678"/>
        <source>配置组未关闭！</source>
        <translation type="unfinished">¡El grupo de configuración no está cerrado!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="694"/>
        <source>删除配置组失败！</source>
        <translation type="unfinished">¡Fallo al borrar el grupo de configuración!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="706"/>
        <source>不是目录！</source>
        <translation type="unfinished">¡No es un directorio!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="712"/>
        <source>存在配置组未关闭！</source>
        <translation type="unfinished">¡Hay un grupo de configuración que no está cerrado!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="740"/>
        <source>删除目录失败！</source>
        <translation type="unfinished">¡Fallo al borrar el directorio!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="763"/>
        <source>发布配置组失败！</source>
        <translation type="unfinished">¡Fallo al publicar el grupo de configuración!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="786"/>
        <source>清除草稿失败！</source>
        <translation type="unfinished">¡Fallo al borrar el borrador!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="799"/>
        <source>不是配置组</source>
        <translation type="unfinished">No es un grupo de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="805"/>
        <source>文件不存在或不是文件</source>
        <translation type="unfinished">El archivo no existe o no es un archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="829"/>
        <source>无法加载指定的文件，请检查文件格式是否正确</source>
        <translation type="unfinished">No se puede cargar el archivo especificado. Verifique si el formato del archivo es correcto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="833"/>
        <source>导入数据失败，无法查找到指定配置组</source>
        <translation type="unfinished">Fallo al importar datos. No se puede encontrar el grupo de configuración especificado.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="837"/>
        <source>无法关闭指定的文件，请尽快保存并重启工具</source>
        <translation type="unfinished">No se puede cerrar el archivo especificado, guarde y reinicie la herramienta lo antes posible</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1116"/>
        <source>名称不能为空！</source>
        <translation type="unfinished">¡El nombre no puede estar vacío!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1130"/>
        <source>名称重复！</source>
        <translation type="unfinished">¡Nombre duplicado!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1181"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1206"/>
        <source>名称不合法！</source>
        <translation type="unfinished">¡El nombre no es válido!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1194"/>
        <source>创建目录失败！</source>
        <translation type="unfinished">¡Fallo al crear el directorio!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1219"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1254"/>
        <source>创建文件失败！</source>
        <translation type="unfinished">¡Fallo al crear el archivo!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1233"/>
        <source>配置组名不合法！</source>
        <translation type="unfinished">¡El nombre del grupo de configuración no es válido!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1267"/>
        <source>目录</source>
        <translation type="unfinished">Directorio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1269"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="72"/>
        <source>配置组</source>
        <translation type="unfinished">Grupo de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1271"/>
        <source>类型总览</source>
        <translation type="unfinished">Visión general del tipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1273"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1493"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1496"/>
        <source>配置项</source>
        <translation type="unfinished">Elementos de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1275"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1492"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1495"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="74"/>
        <source>自定义类型</source>
        <translation type="unfinished">Tipos personalizados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1277"/>
        <source>数据项</source>
        <translation type="unfinished">Elemento de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_hierarchy_item.cpp" line="1279"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="90"/>
        <source>未知</source>
        <translation type="unfinished">Desconocido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="76"/>
        <source>键值对</source>
        <translation type="unfinished">Pares clave-valor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="78"/>
        <source>数据节点</source>
        <translation type="unfinished">Nodo de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="80"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="104"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="112"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="119"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="92"/>
        <source>整数</source>
        <translation type="unfinished">Entero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="94"/>
        <source>浮点数</source>
        <translation type="unfinished">Flotante</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="96"/>
        <source>字符串</source>
        <translation type="unfinished">Cadena</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="98"/>
        <source>布尔</source>
        <translation type="unfinished">Booleano</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="100"/>
        <source>枚举</source>
        <translation type="unfinished">Enum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="102"/>
        <source>结构体</source>
        <translation type="unfinished">Estructura</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="129"/>
        <source>数组</source>
        <translation type="unfinished">Arreglo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="194"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/common/cfg_query.cpp" line="194"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="28"/>
        <source>权限不足</source>
        <translation type="unfinished">Permisos insuficientes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="28"/>
        <source>无写权限</source>
        <translation type="unfinished">Sin permiso de escritura</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgDataDelegate</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_data_viewer/cfg_data_delegate.cpp" line="55"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_data_viewer/cfg_data_delegate.cpp" line="123"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_data_viewer/cfg_data_delegate.cpp" line="55"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_data_viewer/cfg_data_delegate.cpp" line="124"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgDataModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_data_viewer/cfg_data_model.cpp" line="318"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_data_viewer/cfg_data_model.cpp" line="322"/>
        <source>值</source>
        <translation type="unfinished">Valor</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgHierarchyModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="255"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="261"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="706"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="727"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="429"/>
        <source>当前有文件正在编辑中，请先保存！</source>
        <translation type="unfinished">Hay un archivo siendo editado, ¡por favor guárdelo primero!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="452"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="476"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="502"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="531"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="556"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="573"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="605"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="636"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="660"/>
        <source>无效的节点！</source>
        <translation type="unfinished">¡Nodo no válido!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="482"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="514"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="537"/>
        <source>文件未打开！</source>
        <translation type="unfinished">¡Archivo no abierto!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="508"/>
        <source>无写权限！</source>
        <translation type="unfinished">¡No tiene permiso de escritura!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="579"/>
        <source>目录下存在打开的文件，无法删除！</source>
        <translation type="unfinished">¡Existen archivos abiertos en el directorio y no se pueden eliminar!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="611"/>
        <source>文件已打开，无法删除！</source>
        <translation type="unfinished">¡El archivo está abierto y no se puede eliminar!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="642"/>
        <source>文件正在编辑中，无法发布！</source>
        <translation type="unfinished">¡El archivo está siendo editado y no puede ser publicado!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="666"/>
        <source>不存在草稿</source>
        <translation type="unfinished">No existe un borrador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="684"/>
        <source>无效的节点</source>
        <translation type="unfinished">Nodo inválido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="714"/>
        <source>警告</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="714"/>
        <source>当前有文件正在编辑！</source>
        <translation type="unfinished">¡Hay un archivo actualmente siendo editado!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_model.cpp" line="768"/>
        <source>未发布</source>
        <translation type="unfinished">No publicado</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgHierarchyTree</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="91"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="704"/>
        <source>创建目录</source>
        <translation type="unfinished">Nuevo directorio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="124"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="703"/>
        <source>创建配置组</source>
        <translation type="unfinished"> Nuevo grupo de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="139"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="145"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="171"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="177"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="184"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="709"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="710"/>
        <source>重命名</source>
        <translation type="unfinished">Renombrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="139"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="177"/>
        <source>文件存在草稿，请先处理草稿</source>
        <translation type="unfinished">Existen un archivo borrador, por favor procese el borrador primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="145"/>
        <source>是否申请重命名？</source>
        <translation type="unfinished">¿Desea solicitar el cambio de nombre?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="171"/>
        <source>文件已打开，请先关闭文件</source>
        <translation type="unfinished">El archivo ya está abierto, por favor ciérrelo primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="183"/>
        <source>重命名会修改配置组名 【</source>
        <translation type="unfinished">El cambio de nombre modificará el nombre del grupo de configuración【</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="183"/>
        <source>】, 而非显示名 【</source>
        <translation type="unfinished">】, en lugar del nombre mostrado 【</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="183"/>
        <source>】, 是否继续?</source>
        <translation type="unfinished">】 ¿Desea continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="228"/>
        <source>打开文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="241"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="251"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="257"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="263"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="272"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="290"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="713"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="241"/>
        <source>是否删除？</source>
        <translation type="unfinished">¿Desea eliminar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="251"/>
        <source>无法删除该节点</source>
        <translation type="unfinished">No se puede eliminar el nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="257"/>
        <source>目录下存在已打开的配置组，请先关闭配置组</source>
        <translation type="unfinished">Existe un grupo de configuración abierto en el directorio. Por favor cierre el grupo de configuración primero.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="263"/>
        <source>配置组已打开，请先关闭文件</source>
        <translation type="unfinished">El grupo de configuración ya está abierto, por favor cierre el archivo primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="272"/>
        <source>文件存在草稿，是否同时删除草稿？</source>
        <translation type="unfinished">Existen borradores del archivo. ¿Desea eliminar también el borrador?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="314"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="323"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="327"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="715"/>
        <source>发布</source>
        <translation type="unfinished">Publicar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="314"/>
        <source>是否发布？</source>
        <translation type="unfinished">¿Desea publicar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="327"/>
        <source>发布成功</source>
        <translation type="unfinished">Publicación exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="339"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="343"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="717"/>
        <source>清除草稿</source>
        <translation type="unfinished">Borrar borrador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="343"/>
        <source>清除成功</source>
        <translation type="unfinished">Borrado exitoso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="364"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="371"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="707"/>
        <source>申请编辑</source>
        <translation type="unfinished">Aplicar edición</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="364"/>
        <source>只能同时编辑一个配置组</source>
        <translation type="unfinished">Solo un grupo de configuración puede ser editado a la vez</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="418"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="422"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="482"/>
        <source>保存文件</source>
        <translation type="unfinished">Guardar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="422"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="437"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="444"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="448"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="455"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="462"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="466"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="727"/>
        <source>导出头文件</source>
        <translation type="unfinished">Exportar archivo de encabezado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="437"/>
        <source>文件未保存，无法导出</source>
        <translation type="unfinished">El archivo no guardado no puede ser exportado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="443"/>
        <source>文件正在编辑中，导出的头文件将是编辑前的版本，是否继续？</source>
        <translation type="unfinished">El archivo está siendo editado. El archivo de encabezado exportado será la versión anterior a la edición. ¿Desea continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="454"/>
        <source>本配置组存在草稿，是否使用草稿导出头文件？</source>
        <translation type="unfinished">Existen borradores para este grupo de configuración. ¿Desea utilizar el borrador para exportar el archivo de encabezado?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="466"/>
        <source>导出成功</source>
        <translation type="unfinished">Exportación exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="483"/>
        <source>文件正在编辑中，请保存后再关闭</source>
        <translation type="unfinished">El archivo está siendo editado actualmente. Guárdelo antes de cerrarlo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="490"/>
        <source>关闭文件</source>
        <translation type="unfinished">Cerrar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="501"/>
        <source>选择文件</source>
        <translation type="unfinished">Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="501"/>
        <source>XML 文件 (*.xml)</source>
        <translation type="unfinished">Archivo XML (*.xml)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="506"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="510"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="718"/>
        <source>导入数据</source>
        <translation type="unfinished">Importar datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="510"/>
        <source>导入成功</source>
        <translation type="unfinished">Importación exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="712"/>
        <source>打开</source>
        <translation type="unfinished">Abrir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="714"/>
        <source>同步</source>
        <translation type="unfinished">sincronización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="716"/>
        <source>关闭</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="720"/>
        <source>添加类型</source>
        <translation type="unfinished">Agregar tipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="721"/>
        <source>删除类型</source>
        <translation type="unfinished">Eliminar tipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="723"/>
        <source>构造数据</source>
        <translation type="unfinished">Construir datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="724"/>
        <source>验证数据</source>
        <translation type="unfinished">Verificar datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_hierarchy_tree.cpp" line="726"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgLeftPane</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_left_pane/cfg_left_pane.ui" line="465"/>
        <source>请输入关键字查询</source>
        <translation type="unfinished">Por favor, ingrese la búsqueda por palabra clave</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgOptionDelegate</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_delegate.cpp" line="55"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_delegate.cpp" line="165"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_delegate.cpp" line="55"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_delegate.cpp" line="166"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgOptionModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="50"/>
        <source>键名</source>
        <translation type="unfinished">Nombre de la clave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="51"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="52"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="53"/>
        <source>值</source>
        <translation type="unfinished">Valor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="54"/>
        <source>类型</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="55"/>
        <source>基础类型</source>
        <translation type="unfinished">Tipos básicos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="56"/>
        <source>引用类型</source>
        <translation type="unfinished">Tipos de referencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="57"/>
        <source>默认值</source>
        <translation type="unfinished">Valor predeterminado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="58"/>
        <source>最小值</source>
        <translation type="unfinished">Mín</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="59"/>
        <source>最大值</source>
        <translation type="unfinished">Máx.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="60"/>
        <source>数组</source>
        <translation type="unfinished">Arreglo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="61"/>
        <source>数组最大容量</source>
        <translation type="unfinished">Capacidad máxima de un array</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="62"/>
        <source>字符串长度</source>
        <translation type="unfinished">Longitud de cadena</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_model.cpp" line="63"/>
        <source>规则</source>
        <translation type="unfinished">Regla</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgOptionViewer</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_viewer.cpp" line="136"/>
        <source>警告</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_option_viewer/cfg_option_viewer.cpp" line="136"/>
        <source>无法删除键值对!</source>
        <translation type="unfinished">¡No se puede eliminar el par clave-valor!</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgPageHinter</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_work_widget/cfg_page_hinter.h" line="54"/>
        <source>类型总览</source>
        <translation type="unfinished">Visión general del tipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_work_widget/cfg_page_hinter.h" line="58"/>
        <source>配置项总览</source>
        <translation type="unfinished">Descripción general del elemento de configuración</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgPropModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="29"/>
        <source>对象</source>
        <translation type="unfinished">Objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="30"/>
        <source>键名</source>
        <translation type="unfinished">Nombre de la clave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="31"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="32"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="34"/>
        <source>基础类型</source>
        <translation type="unfinished">Tipos básicos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="35"/>
        <source>引用类型</source>
        <translation type="unfinished">Tipos de referencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="36"/>
        <source>默认值</source>
        <translation type="unfinished">Valor predeterminado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="37"/>
        <source>最小值</source>
        <translation type="unfinished">Mín</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="38"/>
        <source>最大值</source>
        <translation type="unfinished">Máx.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="39"/>
        <source>数组</source>
        <translation type="unfinished">Arreglo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="40"/>
        <source>最大容量</source>
        <translation type="unfinished">Capacidad máxima</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="41"/>
        <source>字符串长度</source>
        <translation type="unfinished">Longitud de cadena</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="42"/>
        <source>规则</source>
        <translation type="unfinished">Regla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="110"/>
        <source>属性</source>
        <translation type="unfinished">Atributo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="114"/>
        <source>值</source>
        <translation type="unfinished">Valor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="228"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_prop_model.cpp" line="228"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgPropertyWidget</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_property_widget/cfg_property_widget.ui" line="508"/>
        <source>属性</source>
        <translation type="unfinished">Atributo</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgSearchBar</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/search_bar/cfg_search_bar.cpp" line="29"/>
        <source>请输入关键词查询</source>
        <translation type="unfinished">Por favor, ingrese una palabra clave de búsqueda</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgTypeComboBox</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_type_combobox/cfg_type_combobox.cpp" line="73"/>
        <source>整数</source>
        <translation type="unfinished">Entero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_type_combobox/cfg_type_combobox.cpp" line="74"/>
        <source>浮点数</source>
        <translation type="unfinished">Flotante</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_type_combobox/cfg_type_combobox.cpp" line="75"/>
        <source>字符串</source>
        <translation type="unfinished">cadena</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_type_combobox/cfg_type_combobox.cpp" line="76"/>
        <source>布尔值</source>
        <translation type="unfinished">Booleano</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgTypeModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_type_viewer/cfg_type_model.cpp" line="126"/>
        <source>新建字段</source>
        <translation type="unfinished">Nuevo campo</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::CfgtoolWidget</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/cfgtool_widget.cpp" line="306"/>
        <source>正在编辑</source>
        <translation type="unfinished">Editando</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/cfgtool_widget.cpp" line="307"/>
        <source>当前有文件正在编辑，确认退出？</source>
        <translation type="unfinished">Hay Archivo Editándose, ¿Seguro Salir?</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::DlgCreateDir</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_dir/dlg_create_dir.ui" line="14"/>
        <source>创建目录</source>
        <translation type="unfinished">Nuevo directorio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_dir/dlg_create_dir.ui" line="22"/>
        <source>目录名称</source>
        <translation type="unfinished">Nombre del directorio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_dir/dlg_create_dir.ui" line="29"/>
        <source>不可重复，不可包含 .\\/:*?&quot;&lt;&gt;|</source>
        <translation type="unfinished">Debe ser único y no debe contener .\\/:*?&quot;|</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_dir/dlg_create_dir.cpp" line="47"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_dir/dlg_create_dir.cpp" line="47"/>
        <source>文件夹名称不合法</source>
        <translation type="unfinished">El nombre de la carpeta no es válido</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::DlgCreateFile</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.ui" line="14"/>
        <source>创建配置组</source>
        <translation type="unfinished"> Nuevo grupo de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.ui" line="22"/>
        <source>显示名称</source>
        <translation type="unfinished">Nombre de visualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.ui" line="29"/>
        <source>若为空，则和组名一致</source>
        <translation type="unfinished">Si está vacío, será el mismo que el nombre del grupo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.ui" line="36"/>
        <source>配置组名</source>
        <translation type="unfinished">Nombre del grupo de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.ui" line="52"/>
        <source>不可重复，不可包含 .\\/:*?&quot;&lt;&gt;|</source>
        <translation type="unfinished">Debe ser único y no debe contener .\\/:*?&quot;|</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.ui" line="61"/>
        <source>配置描述</source>
        <translation type="unfinished">Descripción de la configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.ui" line="75"/>
        <source>若取消此项，配置组在保存时才会真正创建</source>
        <translation type="unfinished">Si cancela esta opción, el grupo de configuración no se creará hasta que se guarde.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.ui" line="78"/>
        <source>直接创建(需要权限)</source>
        <translation type="unfinished">Crear directamente (requiere permiso)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.cpp" line="67"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_file/dlg_create_file.cpp" line="67"/>
        <source>配置组名不合法</source>
        <translation type="unfinished">El nombre del grupo de configuración no es válido.</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::DlgCreateKVPair</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="14"/>
        <source>创建键值对</source>
        <translation type="unfinished">Nuevos pares clave-valor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="20"/>
        <source>基础信息</source>
        <translation type="unfinished">Información básica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="26"/>
        <source>键名</source>
        <translation type="unfinished">Nombre de la clave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="33"/>
        <source>不可重复，仅允许字母数字下划线，且不能以数字开头</source>
        <translation type="unfinished">No puede repetirse, solo se permiten letras, números y guiones bajos, y no puede comenzar con un número</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="40"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="50"/>
        <source>类型</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="60"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="70"/>
        <source>是否数组</source>
        <translation type="unfinished">Arreglo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="79"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="252"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="86"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="253"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="101"/>
        <source>拓展信息</source>
        <translation type="unfinished">Más información</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="107"/>
        <source>范围</source>
        <translation type="unfinished">rango</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="128"/>
        <source>~</source>
        <translation type="unfinished">～</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="140"/>
        <source>默认值</source>
        <translation type="unfinished">Valor predeterminado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="147"/>
        <source>数组最大容量</source>
        <translation type="unfinished">Capacidad máxima de un array</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="154"/>
        <source>字符串最大长度</source>
        <translation type="unfinished">Longitud máxima de cadena</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.ui" line="167"/>
        <source>规则</source>
        <translation type="unfinished">Regla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="105"/>
        <source>输入不合法</source>
        <translation type="unfinished">Entrada inválida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="127"/>
        <source>创建失败</source>
        <translation type="unfinished">Creación fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="127"/>
        <source>创建失败！</source>
        <translation type="unfinished">¡Creación fallida!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="300"/>
        <source>键名不合法</source>
        <translation type="unfinished">Nombre de clave no válido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="311"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="324"/>
        <source>最小值不能超过最大值</source>
        <translation type="unfinished">El valor mínimo no puede exceder el valor máximo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="315"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_kvpair/dlg_create_kvpair.cpp" line="328"/>
        <source>默认值需要在最大值和最小值之间</source>
        <translation type="unfinished">El valor predeterminado debe estar entre el valor máximo y mínimo</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::DlgCreateUType</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.ui" line="14"/>
        <source>创建自定义类型</source>
        <translation type="unfinished">Crear tipos personalizados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.ui" line="22"/>
        <source>键名</source>
        <translation type="unfinished">Nombre de la clave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.ui" line="29"/>
        <source>不可重复，仅允许字母数字下划线，且不能以数字开头</source>
        <translation type="unfinished">No puede repetirse, solo se permiten letras, números y guiones bajos, y no puede comenzar con un número</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.ui" line="36"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.ui" line="46"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.ui" line="73"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.ui" line="80"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.cpp" line="61"/>
        <source>键名不合法</source>
        <translation type="unfinished">Nombre de clave no válido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.cpp" line="61"/>
        <source>键名不合法！</source>
        <translation type="unfinished">¡El nombre de la clave es ilegal!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.cpp" line="66"/>
        <source>名称不能为空</source>
        <translation type="unfinished">El nombre no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.cpp" line="66"/>
        <source>名称不能为空！</source>
        <translation type="unfinished">¡El nombre no puede estar vacío!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.cpp" line="73"/>
        <source>创建失败</source>
        <translation type="unfinished">Creación fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/dialogs/dlg_create_user_type/dlg_create_utype.cpp" line="73"/>
        <source>创建失败！</source>
        <translation type="unfinished">¡Creación fallida!</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::FileInfoModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="80"/>
        <source>属性</source>
        <translation type="unfinished">Atributo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="82"/>
        <source>值</source>
        <translation type="unfinished">Valor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="183"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="186"/>
        <source>节点类型</source>
        <translation type="unfinished">Tipo de nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="183"/>
        <source>配置组名</source>
        <translation type="unfinished">Nombre del grupo de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="183"/>
        <source>显示名称</source>
        <translation type="unfinished">Nombre de visualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="183"/>
        <source>配置描述</source>
        <translation type="unfinished">Descripción de la configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="186"/>
        <source>目录名</source>
        <translation type="unfinished">Nombre del directorio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="193"/>
        <source>普通配置</source>
        <translation type="unfinished">Configuración común</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/cfg_file_viewer/file_info_model.cpp" line="201"/>
        <source>目录</source>
        <translation type="unfinished">Directorio</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::TypeOverviewModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_model.cpp" line="241"/>
        <source>类型</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_model.cpp" line="243"/>
        <source>键名</source>
        <translation type="unfinished">Nombre de la clave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_model.cpp" line="245"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_model.cpp" line="247"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::TypeOverviewWidget</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_widget.cpp" line="111"/>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_widget.cpp" line="136"/>
        <source>警告</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_widget.cpp" line="111"/>
        <source>请选择要删除的类型！</source>
        <translation type="unfinished">¡Por favor, seleccione el tipo para eliminar!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_widget.cpp" line="120"/>
        <source>删除该类型将会对已有的数据或类型造成影响，是否继续？
</source>
        <translation type="unfinished">Eliminar este tipo afectará los datos o tipos existentes. ¿Desea continuar? 
</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_widget.cpp" line="123"/>
        <source>
以下 【字段】 将会被删除：
</source>
        <translation type="unfinished">
Los siguientes [Campos] serán eliminados:
</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_widget.cpp" line="130"/>
        <source>
以下 【数据节点】 将会被删除（仅展示 ID）：
</source>
        <translation type="unfinished">
Los siguientes [nodos de datos] serán eliminados (solo se muestran los ID):
</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_widget.cpp" line="145"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/type_overview_widget/type_overview_widget.cpp" line="145"/>
        <source>删除成功！</source>
        <translation type="unfinished">¡Eliminación exitosa!</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::WorkWidgetToolbar</name>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/work_widget_toolbar/work_widget_toolbar.cpp" line="136"/>
        <source>增加</source>
        <translation type="unfinished">Agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/work_widget_toolbar/work_widget_toolbar.cpp" line="138"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/work_widget_toolbar/work_widget_toolbar.cpp" line="140"/>
        <source>上移</source>
        <translation type="unfinished">Mover arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/cfgtool_widget/components/work_widget_toolbar/work_widget_toolbar.cpp" line="142"/>
        <source>下移</source>
        <translation type="unfinished">Mover abajo</translation>
    </message>
</context>
</TS>
