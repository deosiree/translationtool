<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>AppSettingModuleConfigWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="74"/>
        <source>一级标题栏，%1重复</source>
        <translation type="unfinished">Barra de título principal, %1 está duplicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="78"/>
        <source>二级导航栏，%1重复</source>
        <translation type="unfinished">La barra de navegación secundaria, %1 está duplicada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="86"/>
        <source>三级工具栏，%1重复</source>
        <translation type="unfinished">La barra de herramientas terciaria, %1 está duplicada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="108"/>
        <source>重置文件</source>
        <translation type="unfinished">Restablecer archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="108"/>
        <source>是否重置文件</source>
        <translation type="unfinished">Desea restablecer el archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="108"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="142"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="234"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="242"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="108"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="142"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="142"/>
        <source>应用发布</source>
        <translation type="unfinished">Publicación de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="142"/>
        <source>是否发布</source>
        <translation type="unfinished">Publicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="166"/>
        <source>应用发布</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Publicar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="170"/>
        <source>取消修改</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar cambios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="172"/>
        <source>取消工具配置</source>
        <translation type="unfinished">Cancelar Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="174"/>
        <source>上传</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Subir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="234"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="242"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="242"/>
        <source>发布成功，重启界面管理器生效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="74"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="78"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="82"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="86"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="90"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="82"/>
        <source>%1</source>
        <translation type="unfinished"> %1 </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="90"/>
        <source>保存失败</source>
        <translation type="unfinished">Error al guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="168"/>
        <source>发布配置</source>
        <translation type="unfinished">Publicar configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="176"/>
        <source>将本地文件上传到文件服务</source>
        <translation type="unfinished">Subir archivos locales al servicio de archivos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/app_setting_module_config_widget.cpp" line="234"/>
        <source>发布失败</source>
        <translation type="unfinished">Fallo en la publicación</translation>
    </message>
</context>
<context>
    <name>FCustomTreeWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="57"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="67"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="77"/>
        <source>请输入名称</source>
        <translation type="unfinished">Ingrese nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="58"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="68"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="78"/>
        <source>请选择图标</source>
        <translation type="unfinished">Seleccione ícono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="79"/>
        <source>请添加描述</source>
        <translation type="unfinished">Agregue descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="80"/>
        <source>请输入启动命令</source>
        <translation type="unfinished">Ingrese comando de inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="114"/>
        <source>删除节点</source>
        <translation type="unfinished">Eliminar nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="114"/>
        <source>是否确定</source>
        <translation type="unfinished">¿Confirmar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="114"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="114"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="369"/>
        <source>新建</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="371"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="374"/>
        <source>上移</source>
        <translation type="unfinished">Mover Arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="376"/>
        <source>下移</source>
        <translation type="unfinished">Mover hacia Abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="379"/>
        <source>验证</source>
        <translation type="unfinished">Validar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="392"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="392"/>
        <source>图标</source>
        <translation type="unfinished">Icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="392"/>
        <source>权限</source>
        <translation type="unfinished">Permiso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="392"/>
        <source>参数</source>
        <translation type="unfinished">Parámetro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="392"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="393"/>
        <source>跟随启动</source>
        <translation type="unfinished">Inicio acompañado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="393"/>
        <source>跟随关闭</source>
        <translation type="unfinished">Cierre acompañado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="393"/>
        <source>推画面最大进程数量</source>
        <translation type="unfinished">Máximo de procesos para empujar gráficos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="394"/>
        <source>手动启动最大进程数量</source>
        <translation type="unfinished">Máx. procesos manuales</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="394"/>
        <source>ID</source>
        <translation type="unfinished">ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="394"/>
        <source>B端URL</source>
        <translation type="unfinished">URL B-end</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="394"/>
        <source>B端参数</source>
        <translation type="unfinished">Parámetros B-end</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="395"/>
        <source>登录类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget.cpp" line="395"/>
        <source>启动弹窗</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MyDelegate</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="94"/>
        <source>选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Seleccionar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="122"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="179"/>
        <source>选择图标文件</source>
        <translation type="unfinished">Seleccionar archivo de ícono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="124"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="181"/>
        <source>PNG 文件</source>
        <translation type="unfinished">Archivo PNG</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="124"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="181"/>
        <source>SVG 文件</source>
        <translation type="unfinished">Archivo SVG</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="124"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="181"/>
        <source>JPG 文件</source>
        <translation type="unfinished">Archivo JPG</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="125"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="182"/>
        <source>图标文件</source>
        <translation type="unfinished">Archivo de icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="125"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_treewidget_delegate.cpp" line="182"/>
        <source>所有文件</source>
        <translation type="unfinished">Todos los archivos</translation>
    </message>
</context>
<context>
    <name>SettinWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="109"/>
        <source>基础配置</source>
        <translation type="unfinished">Config. básica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="44"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="44"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="44"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="44"/>
        <source>存在未保存修改，是否保存发布？</source>
        <translation type="unfinished">Hay modificaciones no guardadas. Desea guardarlas y publicarlas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="108"/>
        <source>基础配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Config Básica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="111"/>
        <source>平台工具配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Herramienta de Plataforma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="112"/>
        <source>平台工具配置</source>
        <translation type="unfinished">Herramienta de Plataforma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="119"/>
        <source>应用工具配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Herramienta de la Aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_widget.cpp" line="120"/>
        <source>应用工具配置</source>
        <translation type="unfinished">Configuración de la herramienta de la aplicación</translation>
    </message>
</context>
<context>
    <name>SettingBaseConfigWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="66"/>
        <source>启动画面显示屏设置：</source>
        <translation type="unfinished">Configuración de visualización de la gráfica de inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="68"/>
        <source>主屏</source>
        <translation type="unfinished">Pantalla principal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="69"/>
        <source>副屏</source>
        <translation type="unfinished">Pantalla secundaria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="76"/>
        <source>界面缩放：</source>
        <translation type="unfinished">Escalado de interfaz:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="77"/>
        <source>允许缩放</source>
        <translation type="unfinished">Habilitar escala</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="81"/>
        <source>工具窗口设置：</source>
        <translation type="unfinished">Config. de ventana de herramienta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="82"/>
        <source>最小化到托盘</source>
        <translation type="unfinished">Minimizar a bandeja</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="85"/>
        <source>最小化到悬浮球</source>
        <translation type="unfinished">Minimizar a bola flotante</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="86"/>
        <source>隐藏最大化按钮</source>
        <translation type="unfinished">Ocultar botón maximizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="88"/>
        <source>提示音设置：</source>
        <translation type="unfinished">Ajuste de tono:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="89"/>
        <source>告警声音</source>
        <translation type="unfinished">Sonido de alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="91"/>
        <source>音量：</source>
        <translation type="unfinished">Volumen:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="97"/>
        <source>系统行为设置：</source>
        <translation type="unfinished">Configuración del comportamiento del sistema:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="98"/>
        <source>解列退出</source>
        <translation type="unfinished">Salida dividida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="99"/>
        <source>跟随启动守护</source>
        <translation type="unfinished">Seguir al guardián de inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="163"/>
        <source>取消修改</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar cambios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="166"/>
        <source>应用发布</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Publicación de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="507"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="516"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="507"/>
        <source>发布失败</source>
        <translation type="unfinished">Fallo en la publicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="507"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="516"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="522"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="531"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="516"/>
        <source>发布成功，重启界面管理器生效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="522"/>
        <source>应用发布</source>
        <translation type="unfinished">Publicación de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="522"/>
        <source>是否发布</source>
        <translation type="unfinished">Publicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="522"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="531"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="531"/>
        <source>取消修改</source>
        <translation type="unfinished">Cancelar cambios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_base_config_widget.cpp" line="531"/>
        <source>是否取消修改</source>
        <translation type="unfinished">Si desea cancelar la modificación</translation>
    </message>
</context>
<context>
    <name>SettingModuleConfigWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="74"/>
        <source>一级标题栏，%1重复</source>
        <translation type="unfinished">Barra de título principal, %1 está duplicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="78"/>
        <source>二级导航栏，%1重复</source>
        <translation type="unfinished">La barra de navegación secundaria, %1 está duplicada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="86"/>
        <source>三级工具栏，%1重复</source>
        <translation type="unfinished">La barra de herramientas terciaria, %1 está duplicada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="107"/>
        <source>重置文件</source>
        <translation type="unfinished">Reiniciar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="107"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="141"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="233"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="242"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="107"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="141"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="107"/>
        <source>是否重置文件</source>
        <translation type="unfinished">¿Reiniciar archivo?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="74"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="78"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="82"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="86"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="90"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="82"/>
        <source>%1</source>
        <translation type="unfinished">%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="90"/>
        <source>保存失败</source>
        <translation type="unfinished">Guardado falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="141"/>
        <source>应用发布</source>
        <translation type="unfinished">Publicación de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="141"/>
        <source>是否发布</source>
        <translation type="unfinished">Publicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="165"/>
        <source>发布应用</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Publicar aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="169"/>
        <source>取消修改</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar cambios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="171"/>
        <source>取消工具配置</source>
        <translation type="unfinished">Cancelar Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="173"/>
        <source>上传</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Subir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="175"/>
        <source>将本地文件上传到文件服务</source>
        <translation type="unfinished">Subir archivos locales al servicio de archivos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="233"/>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="242"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="242"/>
        <source>发布成功，重启界面管理器生效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="167"/>
        <source>发布配置</source>
        <translation type="unfinished">Config. de publicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_manager_setting_plug/src/setting_module_config_widget.cpp" line="233"/>
        <source>发布失败</source>
        <translation type="unfinished">Publicación falló</translation>
    </message>
</context>
</TS>
