<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>iasp::smg::ExecutionDetailsDialog</name>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1146"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1276"/>
        <source>执行详情</source>
        <comment>toolName</comment>
        <translation type="unfinished">Detalles de la Ejecución</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1166"/>
        <source>应用名</source>
        <translation type="unfinished">Nombre de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1166"/>
        <source>执行进度</source>
        <translation type="unfinished">Horario de ejecución</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1385"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1385"/>
        <source>执行结束</source>
        <translation type="unfinished">Ejecución completada</translation>
    </message>
</context>
<context>
    <name>iasp::smg::MtConfigWidgetImp</name>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="177"/>
        <source>应用名</source>
        <translation type="unfinished">Nombre de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="177"/>
        <source>维护应用状态</source>
        <translation type="unfinished">Maint. Estado de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="177"/>
        <source>维护节点</source>
        <translation type="unfinished">Nodo de maint.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="177"/>
        <source>值班节点</source>
        <translation type="unfinished">Nodo de turno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="177"/>
        <source>操作</source>
        <translation type="unfinished">Operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="229"/>
        <source>原维护节点维护库</source>
        <translation type="unfinished">MTDB del nodo de maint. original</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="230"/>
        <source>值班节点运行库</source>
        <translation type="unfinished">TDB del nodo de turno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="241"/>
        <source>数据源：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Fuente de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="248"/>
        <source>新维护节点：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nuevo nodo de maint.:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="257"/>
        <source>应用</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Aplicar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="260"/>
        <source>应用修改内容</source>
        <translation type="unfinished">Aplicar contenido de modificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="264"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="267"/>
        <source>刷新当前页面</source>
        <translation type="unfinished">Actualizar página actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="473"/>
        <source>历史版本</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Versión histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="490"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="501"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="520"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="627"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="490"/>
        <source>当前应用没有维护节点</source>
        <translation type="unfinished">La aplicación actual no tiene un nodo de maint.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="499"/>
        <source>查询[%1 %2]的维护库备份目录失败</source>
        <translation type="unfinished"> No se pudo consultar el directorio de respaldo del MTDB de [%1 %2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="518"/>
        <source>没有可用的数据库历史版本</source>
        <translation type="unfinished">No hay versiones históricas de la BD disponibles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="627"/>
        <source>未选中维护应用, 请重新选择</source>
        <translation type="unfinished">No se ha seleccionado ninguna aplicación de maint., por favor seleccione una</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="717"/>
        <source>开始执行</source>
        <translation type="unfinished">Iniciar ejecución</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="742"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="804"/>
        <source>系统管理接口实例获取失败</source>
        <translation type="unfinished">Error al obtener la instancia del puerto de gestión del sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="762"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="861"/>
        <source>维护应用[%1]停止失败</source>
        <translation type="unfinished">Error al detener la aplicación de maint. [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="776"/>
        <source>维护应用[%1]去除维护节点失败</source>
        <translation type="unfinished">La aplicación de maint. [%1] no pudo eliminar el nodo de maint.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="783"/>
        <source>维护应用[%1]去除维护节点, 执行完成</source>
        <translation type="unfinished">Aplicación de maint. [%1] Eliminar el nodo de maint., y la operación está completada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="792"/>
        <source>维护应用[%1]没有维护节点, 无需修改</source>
        <translation type="unfinished">La aplicación de maint. [%1] no tiene un nodo de maint. y no necesita ser modificada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="816"/>
        <source>根据维护应用[%1]查询应用定义失败</source>
        <translation type="unfinished">No se pudo consultar la definición de la aplicación según la aplicación de maint. [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="827"/>
        <source>根据应用定义[%1]查询应用定义失败</source>
        <translation type="unfinished">No se pudo consultar la definición de la aplicación según la definición de la aplicación [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="839"/>
        <source>查询应用[%1]的维护库失败</source>
        <translation type="unfinished">No se pudo consultar el MTDB de la aplicación [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="868"/>
        <source>维护应用[%1]停止</source>
        <translation type="unfinished">Aplicación de maint. [%1] detenida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="884"/>
        <source>维护应用[%1]启动失败</source>
        <translation type="unfinished">Aplicación de maint. [%1] no pudo iniciarse</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="892"/>
        <source>维护应用[%1]启动</source>
        <translation type="unfinished">Aplicación de maint. [%1] iniciada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="917"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="924"/>
        <source>数据源是维护库, 但应用[%1]原维护节点为空</source>
        <translation type="unfinished">La fuente de datos es el MTDB, pero el nodo de maint. original de la aplicación [%1] está vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="933"/>
        <source>数据源是维护库, 但应用[%1]新维护节点与旧维护节点都为[%2], 请检查配置重新设置</source>
        <translation type="unfinished">La fuente de datos es el MTDB, pero [%1] se aplica tanto al nuevo nodo de maint. como al antiguo nodo de maint. como [%2], por favor revise la configuración y restablezca</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="944"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="950"/>
        <source>查询运行库[%1 %2 %3 %4]的值班节点失败</source>
        <translation type="unfinished">No se pudo consultar el nodo de responsabilidad del TDB [%1 %2 %3 %4]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="962"/>
        <source>实时库[%1]检查数据完成, 旧维护节点:%2, 新维护节点:%3, 数据源:%4</source>
        <translation type="unfinished">TDB [%1] terminó de verificar los datos, nodo de maint. antiguo:%2, nuevo nodo de maint.:%3, fuente de datos:%4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="984"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1054"/>
        <source>ftp登录节点[%1]失败</source>
        <translation type="unfinished">Error al iniciar sesión en el nodo ftp [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1000"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1066"/>
        <source>实时库[%1]从节点[%2][%3]下载到节点[%4][%5]失败</source>
        <translation type="unfinished">Error al descargar TDB [%1] del nodo [%2][%3] al nodo [%4][%5]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1025"/>
        <source>实时库[%1]删除索引文件失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1032"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1083"/>
        <source>实时库[%1]从节点[%2][%3]下载到节点[%4][%5]完成</source>
        <translation type="unfinished">TDB [%1] se descarga del nodo [%2][%3] al nodo [%4][%5]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1097"/>
        <source>实时库[%1]从节点[%2]目录[%3]拷贝到目录[%4]失败</source>
        <translation type="unfinished">Error al copiar TDB [%1] del nodo [%2] directorio [%3] al directorio [%4]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1111"/>
        <source>实时库[%1]传输完成</source>
        <translation type="unfinished">TDB [%1] transferencia completada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1121"/>
        <source>设置维护应用[%1]的新维护节点[%2]失败</source>
        <translation type="unfinished">Error al configurar la aplicación de maint. [%1] nuevo nodo de maint. [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mt_switch.cpp" line="1128"/>
        <source>维护应用[%1]设置新的维护节点</source>
        <translation type="unfinished">La aplicación de maint. [%1] estableció un nuevo nodo de maint.</translation>
    </message>
</context>
<context>
    <name>iasp::smg::ProgressDialog</name>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="283"/>
        <source>执行详情</source>
        <comment>toolName</comment>
        <translation type="unfinished">Detalles de la Ejecución</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="362"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="362"/>
        <source>执行结束</source>
        <translation type="unfinished">Ejecución completada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="391"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="478"/>
        <source>开始执行</source>
        <translation type="unfinished">Iniciar ejecución</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="413"/>
        <source>维护应用[%1]停止失败</source>
        <translation type="unfinished">Error al detener la aplicación de maint. [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="419"/>
        <source>维护应用[%1]停止</source>
        <translation type="unfinished">Aplicación de maint. [%1] detenida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="435"/>
        <source>需要回退的数据库版本: %1</source>
        <translation type="unfinished">La versión de la BD necesita ser revertida: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="461"/>
        <source>维护应用[%1]启动失败</source>
        <translation type="unfinished">Aplicación de maint. [%1] no pudo iniciarse</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="467"/>
        <source>维护应用[%1]启动</source>
        <translation type="unfinished">Aplicación de maint. [%1] iniciada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="492"/>
        <source>解析全应用名[{}]失败</source>
        <translation type="unfinished">Error al analizar el nombre completo de la aplicación [{}]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="506"/>
        <source>系统管理接口实例获取失败</source>
        <translation type="unfinished">Error al obtener la instancia del puerto de gestión del sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="533"/>
        <source>ftp登录节点[%1]失败</source>
        <translation type="unfinished">Error al iniciar sesión en el nodo ftp [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="553"/>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="607"/>
        <source>实时库[%1]从节点[%2][%3]下载到节点[%4][%5]失败</source>
        <translation type="unfinished">Error al descargar TDB [%1] del nodo [%2][%3] al nodo [%4][%5]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="565"/>
        <source>实时库[%1]备份数据下载完成</source>
        <translation type="unfinished">TDB [%1] descarga de datos de respaldo completada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="583"/>
        <source>实时库[%1]从[%2]解压到节点[%3]失败</source>
        <translation type="unfinished">Error al extraer TDB [%1] de [%2] al nodo [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="591"/>
        <source>实时库[%1]备份数据解压完成</source>
        <translation type="unfinished">Los datos de respaldo de TDB [%1] se han extraído</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="620"/>
        <source>实时库[%1]备份数据上传完成</source>
        <translation type="unfinished">Carga de datos de respaldo de TDB [%1] completada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="628"/>
        <source>实时库[%1]从节点[%2]目录[%3]拷贝到目录[%4]失败</source>
        <translation type="unfinished">Error al copiar TDB [%1] del nodo [%2] directorio [%3] al directorio [%4]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="641"/>
        <source>实时库[%1]回退到[%2]完成</source>
        <translation type="unfinished">La reversión de TDB [%1] a [%2] está completa</translation>
    </message>
</context>
<context>
    <name>iasp::smg::RollbackDialog</name>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="106"/>
        <source>不回退</source>
        <translation type="unfinished">Sin reversión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="125"/>
        <source>回退版本</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Reversión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="150"/>
        <source>数据库版本选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar Versión de la BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="177"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysmgr/mt_config/src/mtdb_rollback.cpp" line="177"/>
        <source>未选择数据库版本, 请重新选择</source>
        <translation type="unfinished">No se ha seleccionado ninguna versión de la BD. Seleccione uno</translation>
    </message>
</context>
</TS>
