<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="20"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="30"/>
        <source>操作系统</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="40"/>
        <source>操作系统日志信息：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="60"/>
        <source>一键查验</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="85"/>
        <source>系统日志</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="101"/>
        <source>节点：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="111"/>
        <source>日志等级：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="121"/>
        <source>时间：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="131"/>
        <source>-&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="154"/>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="303"/>
        <source>重置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="161"/>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="310"/>
        <source>查询</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="175"/>
        <source>系统日志信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="207"/>
        <source>待查验</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="224"/>
        <source>0/20</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="231"/>
        <source>错误信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="238"/>
        <source>停止</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="270"/>
        <source>系统告警</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="286"/>
        <source>历史：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="296"/>
        <source>编辑条件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_log/mainwindow.ui" line="324"/>
        <source>告警查询信息</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
