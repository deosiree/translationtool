<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="en_US">
<context>
    <name>AboutDialog</name>
    <message>
        <source>Qt Linguist</source>
        <translation />
    </message>
</context>
<context>
    <name>BatchTranslationDialog</name>
    <message>
        <source>Qt Linguist - Batch Translation</source>
        <translation />
    </message>
    <message>
        <source>Options</source>
        <translation />
    </message>
    <message>
        <source>Set translated entries to finished</source>
        <translation />
    </message>
    <message>
        <source>Retranslate entries with existing translation</source>
        <translation />
    </message>
    <message>
        <source>Note that the modified entries will be reset to unfinished if 'Set translated entries to finished' above is unchecked</source>
        <translation />
    </message>
    <message>
        <source>Translate also finished entries</source>
        <translation />
    </message>
    <message>
        <source>Phrase book preference</source>
        <translation />
    </message>
    <message>
        <source>Move up</source>
        <translation />
    </message>
    <message>
        <source>Move down</source>
        <translation />
    </message>
    <message>
        <source>The batch translator will search through the selected phrase books in the order given above</source>
        <translation />
    </message>
    <message>
        <source>&amp;Run</source>
        <translation />
    </message>
    <message>
        <source>Cancel</source>
        <translation />
    </message>
    <message>
        <source>Batch Translation of '%1' - Qt Linguist</source>
        <translation />
    </message>
    <message>
        <source>Searching, please wait...</source>
        <translation />
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation />
    </message>
    <message>
        <source>Linguist batch translator</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>Batch translated %n entries</source>
        <translation><numerusform>%n bejegyzés kötegelten lefordítva</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>DataModel</name>
    <message>
        <source>The translation file '%1' will not be loaded because it is empty.</source>
        <translation />
    </message>
    <message>
        <source>&lt;qt&gt;Duplicate messages found in '%1':</source>
        <translation />
    </message>
    <message>
        <source>&lt;p&gt;[more duplicates omitted]</source>
        <translation />
    </message>
    <message>
        <source>&lt;p&gt;* ID: %1</source>
        <translation />
    </message>
    <message>
        <source>&lt;p&gt;* Context: %1&lt;br&gt;* Source: %2</source>
        <translation />
    </message>
    <message>
        <source>&lt;br&gt;* Comment: %3</source>
        <translation />
    </message>
    <message>
        <source>Linguist does not know the plural rules for '%1'.
Will assume a single universal form.</source>
        <translation />
    </message>
    <message>
        <source>Cannot create '%2': %1</source>
        <translation />
    </message>
    <message>
        <source>%1 (%2)</source>
        <extracomment>&lt;language&gt; (&lt;territory&gt;)</extracomment>
        <translation />
    </message>
    <message>
        <source>Universal Form</source>
        <translation />
    </message>
</context>
<context>
    <name>ErrorsView</name>
    <message>
        <source>Accelerator possibly superfluous in translation.</source>
        <translation />
    </message>
    <message>
        <source>Accelerator possibly missing in translation.</source>
        <translation />
    </message>
    <message>
        <source>Translation does not have same leading and trailing whitespace as the source text.</source>
        <translation />
    </message>
    <message>
        <source>Translation does not end with the same punctuation as the source text.</source>
        <translation />
    </message>
    <message>
        <source>A phrase book suggestion for '%1' was ignored.</source>
        <translation />
    </message>
    <message>
        <source>Translation does not refer to the same place markers as in the source text.</source>
        <translation />
    </message>
    <message>
        <source>Translation does not contain the necessary %n/%Ln place marker.</source>
        <translation />
    </message>
    <message>
        <source>Unknown error</source>
        <translation />
    </message>
</context>
<context>
    <name>FindDialog</name>
    <message>
        <source>Find</source>
        <translation />
    </message>
    <message>
        <source>This window allows you to search for some text in the translation source file.</source>
        <translation />
    </message>
    <message>
        <source>&amp;Find what:</source>
        <translation />
    </message>
    <message>
        <source>Type in the text to search for.</source>
        <translation />
    </message>
    <message>
        <source>Options</source>
        <translation />
    </message>
    <message>
        <source>Source texts are searched when checked.</source>
        <translation />
    </message>
    <message>
        <source>&amp;Source texts</source>
        <translation />
    </message>
    <message>
        <source>Translations are searched when checked.</source>
        <translation />
    </message>
    <message>
        <source>&amp;Translations</source>
        <translation />
    </message>
    <message>
        <source>Texts such as 'TeX' and 'tex' are considered as different when checked.</source>
        <translation />
    </message>
    <message>
        <source>&amp;Match case</source>
        <translation />
    </message>
    <message>
        <source>Comments and contexts are searched when checked.</source>
        <translation />
    </message>
    <message>
        <source>&amp;Comments</source>
        <translation />
    </message>
    <message>
        <source>Ignore &amp;accelerators</source>
        <translation />
    </message>
    <message>
        <source>Obsoleted messages are skipped when checked.</source>
        <translation />
    </message>
    <message>
        <source>Skip &amp;obsolete</source>
        <translation />
    </message>
    <message>
        <source>Click here to find the next occurrence of the text you typed in.</source>
        <translation />
    </message>
    <message>
        <source>Find Next</source>
        <translation />
    </message>
    <message>
        <source>Click here to close this window.</source>
        <translation />
    </message>
    <message>
        <source>Cancel</source>
        <translation />
    </message>
    <message>
        <source />
        <comment>Choose Edit|Find from the menu bar or press Ctrl+F to pop up the Find dialog</comment>
        <translation />
    </message>
    <message>
        <source>Lets you use a Perl-compatible regular expression</source>
        <translation />
    </message>
    <message>
        <source>Regular &amp;expression</source>
        <translation />
    </message>
    <message>
        <source>T&amp;ranslation status:</source>
        <translation />
    </message>
    <message>
        <source>Lets you filter the search target by translation status</source>
        <translation />
    </message>
    <message>
        <source>All</source>
        <translation />
    </message>
    <message>
        <source>Finished</source>
        <translation />
    </message>
    <message>
        <source>Unfinished</source>
        <translation />
    </message>
</context>
<context>
    <name>FormMultiWidget</name>
    <message>
        <source>Alt+Delete</source>
        <extracomment>translate, but don't change</extracomment>
        <translation />
    </message>
    <message>
        <source>Shift+Alt+Insert</source>
        <extracomment>translate, but don't change</extracomment>
        <translation />
    </message>
    <message>
        <source>Alt+Insert</source>
        <extracomment>translate, but don't change</extracomment>
        <translation />
    </message>
    <message>
        <source>Confirmation - Qt Linguist</source>
        <translation />
    </message>
    <message>
        <source>Delete non-empty length variant?</source>
        <translation />
    </message>
</context>
<context>
    <name>LRelease</name>
    <message numerus="yes">
        <source>Dropped %n message(s) which had no ID.</source>
        <translation type="vanished"><numerusform>%n üzenet eldobva, amelynek nem volt azonosítója.</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>Excess context/disambiguation dropped from %n message(s).</source>
        <translation type="vanished"><numerusform>Többlet környezet vagy egyértelműség eldobva %n üzenetből.</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>    Generated %n translation(s) (%1 finished and %2 unfinished)</source>
        <translation type="vanished"><numerusform>%n fordítás előállítva (%1 befejezett és %2 befejezetlen)</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>    Ignored %n untranslated source text(s)</source>
        <translation type="vanished"><numerusform>%n lefordítatlan forrásszöveg figyelmen kívül hagyva</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>Linguist</name>
    <message>
        <source>GNU Gettext localization files</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>GNU Gettext localization template files</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Compiled Qt translations</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Qt Linguist 'Phrase Book'</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Qt translation sources</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>XLIFF localization files</source>
        <translation type="vanished" />
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>MainWindow</source>
        <translation />
    </message>
    <message>
        <source>&amp;Phrases</source>
        <translation />
    </message>
    <message>
        <source>&amp;Close Phrase Book</source>
        <translation />
    </message>
    <message>
        <source>&amp;Edit Phrase Book</source>
        <translation />
    </message>
    <message>
        <source>&amp;Print Phrase Book</source>
        <translation />
    </message>
    <message>
        <source>V&amp;alidation</source>
        <translation />
    </message>
    <message>
        <source>&amp;View</source>
        <translation />
    </message>
    <message>
        <source>Vie&amp;ws</source>
        <translation />
    </message>
    <message>
        <source>&amp;Toolbars</source>
        <translation />
    </message>
    <message>
        <source>&amp;Zoom</source>
        <translation />
    </message>
    <message>
        <source>&amp;Help</source>
        <translation />
    </message>
    <message>
        <source>&amp;Translation</source>
        <translation />
    </message>
    <message>
        <source>&amp;File</source>
        <translation />
    </message>
    <message>
        <source>Recently Opened &amp;Files</source>
        <translation />
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation />
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation />
    </message>
    <message>
        <source>Open a Qt translation source file (TS file) for editing</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+O</source>
        <translation />
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation />
    </message>
    <message>
        <source>Close this window and exit.</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+Q</source>
        <translation />
    </message>
    <message>
        <source>Save</source>
        <translation />
    </message>
    <message>
        <source>Save changes made to this Qt translation source file</source>
        <translation />
    </message>
    <message>
        <source>Save &amp;As...</source>
        <translation />
    </message>
    <message>
        <source>Save As...</source>
        <translation />
    </message>
    <message>
        <source>Save changes made to this Qt translation source file into a new file.</source>
        <translation />
    </message>
    <message>
        <source>Release</source>
        <translation />
    </message>
    <message>
        <source>Create a Qt message file suitable for released applications from the current message file.</source>
        <translation />
    </message>
    <message>
        <source>&amp;Print...</source>
        <translation />
    </message>
    <message>
        <source>Print a list of all the translation units in the current translation source file.</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation />
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation />
    </message>
    <message>
        <source>Undo the last editing operation performed on the current translation.</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+Z</source>
        <translation />
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation />
    </message>
    <message>
        <source>Redo an undone editing operation performed on the translation.</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+Y</source>
        <translation />
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation />
    </message>
    <message>
        <source>Copy the selected translation text to the clipboard and deletes it.</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+X</source>
        <translation />
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation />
    </message>
    <message>
        <source>Copy the selected translation text to the clipboard.</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+C</source>
        <translation />
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation />
    </message>
    <message>
        <source>Paste the clipboard text into the translation.</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+V</source>
        <translation />
    </message>
    <message>
        <source>Select &amp;All</source>
        <translation />
    </message>
    <message>
        <source>Select the whole translation text.</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+A</source>
        <translation />
    </message>
    <message>
        <source>&amp;Find...</source>
        <translation />
    </message>
    <message>
        <source>Search for some text in the translation source file.</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+F</source>
        <translation />
    </message>
    <message>
        <source>Find &amp;Next</source>
        <translation />
    </message>
    <message>
        <source>Continue the search where it was left.</source>
        <translation />
    </message>
    <message>
        <source>F3</source>
        <translation />
    </message>
    <message>
        <source>&amp;Prev Unfinished</source>
        <translation />
    </message>
    <message>
        <source>Previous unfinished item</source>
        <translation />
    </message>
    <message>
        <source>Move to the previous unfinished item.</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+K</source>
        <translation />
    </message>
    <message>
        <source>&amp;Next Unfinished</source>
        <translation />
    </message>
    <message>
        <source>Next unfinished item</source>
        <translation />
    </message>
    <message>
        <source>Move to the next unfinished item.</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+J</source>
        <translation />
    </message>
    <message>
        <source>P&amp;rev</source>
        <translation />
    </message>
    <message>
        <source>Move to previous item</source>
        <translation />
    </message>
    <message>
        <source>Move to the previous item.</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+Shift+K</source>
        <translation />
    </message>
    <message>
        <source>Ne&amp;xt</source>
        <translation />
    </message>
    <message>
        <source>Next item</source>
        <translation />
    </message>
    <message>
        <source>Move to the next item.</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+Shift+J</source>
        <translation />
    </message>
    <message>
        <source>&amp;Done and Next</source>
        <translation />
    </message>
    <message>
        <source>Mark item as done and move to the next unfinished item</source>
        <translation />
    </message>
    <message>
        <source>Mark this item as done and move to the next unfinished item.</source>
        <translation />
    </message>
    <message>
        <source>Copy from source text</source>
        <translation />
    </message>
    <message>
        <source>Copies the source text into the translation field</source>
        <translation />
    </message>
    <message>
        <source>Copies the source text into the translation field.</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+B</source>
        <translation />
    </message>
    <message>
        <source>&amp;Accelerators</source>
        <translation />
    </message>
    <message>
        <source>Toggle the validity check of accelerators</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Toggle the validity check of accelerators, i.e. whether the number of ampersands in the source and translation text is the same. If the check fails, a message is shown in the warnings window.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>&amp;Ending Punctuation</source>
        <translation />
    </message>
    <message>
        <source>Toggle the validity check of ending punctuation</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Toggle the validity check of ending punctuation. If the check fails, a message is shown in the warnings window.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>&amp;Phrase matches</source>
        <translation />
    </message>
    <message>
        <source>Toggle checking that phrase suggestions are used</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Toggle checking that phrase suggestions are used. If the check fails, a message is shown in the warnings window.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Place &amp;Marker Matches</source>
        <translation />
    </message>
    <message>
        <source>Toggle the validity check of place markers</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Toggle the validity check of place markers, i.e. whether %1, %2, ... are used consistently in the source text and translation text. If the check fails, a message is shown in the warnings window.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>&amp;New Phrase Book...</source>
        <translation />
    </message>
    <message>
        <source>Create a new phrase book.</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+N</source>
        <translation />
    </message>
    <message>
        <source>&amp;Open Phrase Book...</source>
        <translation />
    </message>
    <message>
        <source>Open a phrase book to assist translation.</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+H</source>
        <translation />
    </message>
    <message>
        <source>&amp;Reset Sorting</source>
        <translation />
    </message>
    <message>
        <source>Sort the items back in the same order as in the message file.</source>
        <translation />
    </message>
    <message>
        <source>&amp;Display guesses</source>
        <translation />
    </message>
    <message>
        <source>Set whether or not to display translation guesses.</source>
        <translation />
    </message>
    <message>
        <source>&amp;Statistics</source>
        <translation />
    </message>
    <message>
        <source>Display translation statistics.</source>
        <translation />
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation />
    </message>
    <message>
        <source>F1</source>
        <translation />
    </message>
    <message>
        <source>About Qt Linguist</source>
        <translation />
    </message>
    <message>
        <source>About Qt</source>
        <translation />
    </message>
    <message>
        <source>Display information about the Qt toolkit by Digia.</source>
        <translation />
    </message>
    <message>
        <source>&amp;What's This?</source>
        <translation />
    </message>
    <message>
        <source>What's This?</source>
        <translation />
    </message>
    <message>
        <source>Enter What's This? mode.</source>
        <translation />
    </message>
    <message>
        <source>Shift+F1</source>
        <translation />
    </message>
    <message>
        <source>&amp;Search And Translate...</source>
        <translation />
    </message>
    <message>
        <source>Replace the translation on all entries that matches the search source text.</source>
        <translation />
    </message>
    <message>
        <source>&amp;Batch Translation...</source>
        <translation />
    </message>
    <message>
        <source>Batch translate all entries using the information in the phrase books.</source>
        <translation />
    </message>
    <message>
        <source>Release As...</source>
        <translation />
    </message>
    <message>
        <source>Create a Qt message file suitable for released applications from the current message file. The filename will automatically be determined from the name of the TS file.</source>
        <translation />
    </message>
    <message>
        <source>File</source>
        <translation />
    </message>
    <message>
        <source>Edit</source>
        <translation />
    </message>
    <message>
        <source>Translation</source>
        <translation />
    </message>
    <message>
        <source>Validation</source>
        <translation />
    </message>
    <message>
        <source>Help</source>
        <translation />
    </message>
    <message>
        <source>Open/Refresh Form &amp;Preview</source>
        <translation />
    </message>
    <message>
        <source>Form Preview Tool</source>
        <translation />
    </message>
    <message>
        <source>F5</source>
        <translation />
    </message>
    <message>
        <source>Translation File &amp;Settings...</source>
        <translation />
    </message>
    <message>
        <source>&amp;Add to Phrase Book</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+T</source>
        <translation />
    </message>
    <message>
        <source>Open Read-O&amp;nly...</source>
        <translation />
    </message>
    <message>
        <source>&amp;Save All</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation />
    </message>
    <message>
        <source>&amp;Release All</source>
        <translation />
    </message>
    <message>
        <source>Close</source>
        <translation />
    </message>
    <message>
        <source>&amp;Close All</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+W</source>
        <translation />
    </message>
    <message>
        <source>Length Variants</source>
        <translation />
    </message>
    <message>
        <source>Visualize whitespace</source>
        <translation />
    </message>
    <message>
        <source>Toggle visualize whitespace in editors</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Increase</source>
        <translation />
    </message>
    <message>
        <source>Ctrl++</source>
        <translation />
    </message>
    <message>
        <source>Decrease</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+-</source>
        <translation />
    </message>
    <message>
        <source>Reset to default</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+0</source>
        <translation />
    </message>
    <message>
        <source />
        <comment>This is the application's main window.</comment>
        <translation />
    </message>
    <message>
        <source>Source text</source>
        <translation />
    </message>
    <message>
        <source>Index</source>
        <translation />
    </message>
    <message>
        <source>Context</source>
        <translation />
    </message>
    <message>
        <source>Items</source>
        <translation />
    </message>
    <message>
        <source>This panel lists the source contexts.</source>
        <translation />
    </message>
    <message>
        <source>Strings</source>
        <translation />
    </message>
    <message>
        <source>Phrases and guesses</source>
        <translation />
    </message>
    <message>
        <source>Sources and Forms</source>
        <translation />
    </message>
    <message>
        <source>Warnings</source>
        <translation />
    </message>
    <message>
        <source> MOD </source>
        <comment>status bar: file(s) modified</comment>
        <translation />
    </message>
    <message>
        <source>Loading...</source>
        <translation />
    </message>
    <message>
        <source>Loading File - Qt Linguist</source>
        <translation />
    </message>
    <message>
        <source>The file '%1' does not seem to be related to the currently open file(s) '%2'.

Close the open file(s) first?</source>
        <translation />
    </message>
    <message>
        <source>The file '%1' does not seem to be related to the file '%2' which is being loaded as well.

Skip loading the first named file?</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>%n translation unit(s) loaded.</source>
        <translation><numerusform>%n fordítási egység betöltve.</numerusform>
        </translation>
    </message>
    <message>
        <source>Related files (%1);;</source>
        <translation />
    </message>
    <message>
        <source>Open Translation Files</source>
        <translation />
    </message>
    <message>
        <source>File saved.</source>
        <translation />
    </message>
    <message>
        <source>Qt message files for released applications (*.qm)
All files (*)</source>
        <translation />
    </message>
    <message>
        <source>File created.</source>
        <translation />
    </message>
    <message>
        <source>Printing...</source>
        <translation />
    </message>
    <message>
        <source>Context: %1</source>
        <translation />
    </message>
    <message>
        <source>finished</source>
        <translation />
    </message>
    <message>
        <source>unresolved</source>
        <translation />
    </message>
    <message>
        <source>obsolete</source>
        <translation />
    </message>
    <message>
        <source>Printing... (page %1)</source>
        <translation />
    </message>
    <message>
        <source>Printing completed</source>
        <translation />
    </message>
    <message>
        <source>Printing aborted</source>
        <translation />
    </message>
    <message>
        <source>Search wrapped.</source>
        <translation />
    </message>
    <message>
        <source>Qt Linguist</source>
        <translation />
    </message>
    <message>
        <source>Cannot find the string '%1'.</source>
        <translation />
    </message>
    <message>
        <source>Search And Translate in '%1' - Qt Linguist</source>
        <translation />
    </message>
    <message>
        <source>Translate - Qt Linguist</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>Translated %n entry(s)</source>
        <translation><numerusform>%n bejegyzés lefordítva</numerusform>
        </translation>
    </message>
    <message>
        <source>No more occurrences of '%1'. Start over?</source>
        <translation />
    </message>
    <message>
        <source>Create New Phrase Book</source>
        <translation />
    </message>
    <message>
        <source>Qt phrase books (*.qph)
All files (*)</source>
        <translation />
    </message>
    <message>
        <source>Phrase book created.</source>
        <translation />
    </message>
    <message>
        <source>Open Phrase Book</source>
        <translation />
    </message>
    <message>
        <source>Qt phrase books (*.qph);;All files (*)</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>%n phrase(s) loaded.</source>
        <translation><numerusform>%n kifejezés betöltve.</numerusform>
        </translation>
    </message>
    <message>
        <source>Add to phrase book</source>
        <translation />
    </message>
    <message>
        <source>No appropriate phrasebook found.</source>
        <translation />
    </message>
    <message>
        <source>Adding entry to phrasebook %1</source>
        <translation />
    </message>
    <message>
        <source>Select phrase book to add to</source>
        <translation />
    </message>
    <message>
        <source>Unable to launch Qt Assistant (%1)</source>
        <translation />
    </message>
    <message>
        <source>Version %1</source>
        <translation />
    </message>
    <message>
        <source>Qt Linguist is a tool for adding translations to Qt applications.</source>
        <translation />
    </message>
    <message>
        <source>Copyright (C) %1 The Qt Company Ltd.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>&lt;center&gt;&lt;img src=":/images/splash.png"/&gt;&lt;/img&gt;&lt;p&gt;%1&lt;/p&gt;&lt;/center&gt;&lt;p&gt;Qt Linguist is a tool for adding translations to Qt applications.&lt;/p&gt;&lt;p&gt;Copyright (C) %2 The Qt Company Ltd.</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Do you want to save the modified files?</source>
        <translation />
    </message>
    <message>
        <source>Do you want to save '%1'?</source>
        <translation />
    </message>
    <message>
        <source>Qt Linguist[*]</source>
        <translation />
    </message>
    <message>
        <source>%1[*] - Qt Linguist</source>
        <translation />
    </message>
    <message>
        <source>No untranslated translation units left.</source>
        <translation />
    </message>
    <message>
        <source>&amp;Window</source>
        <translation />
    </message>
    <message>
        <source>Minimize</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+M</source>
        <translation />
    </message>
    <message>
        <source>Display the manual for %1.</source>
        <translation />
    </message>
    <message>
        <source>Display information about %1.</source>
        <translation />
    </message>
    <message>
        <source>&amp;Save '%1'</source>
        <translation />
    </message>
    <message>
        <source>Save '%1' &amp;As...</source>
        <translation />
    </message>
    <message>
        <source>Release '%1'</source>
        <translation />
    </message>
    <message>
        <source>Release '%1' As...</source>
        <translation />
    </message>
    <message>
        <source>&amp;Close '%1'</source>
        <translation />
    </message>
    <message>
        <source>&amp;Save</source>
        <translation />
    </message>
    <message>
        <source>&amp;Close</source>
        <translation />
    </message>
    <message>
        <source>Save All</source>
        <translation />
    </message>
    <message>
        <source>Close All</source>
        <translation />
    </message>
    <message>
        <source>&amp;Release</source>
        <translation />
    </message>
    <message>
        <source>Translation File &amp;Settings for '%1'...</source>
        <translation />
    </message>
    <message>
        <source>&amp;Batch Translation of '%1'...</source>
        <translation />
    </message>
    <message>
        <source>Search And &amp;Translate in '%1'...</source>
        <translation />
    </message>
    <message>
        <source>Search And &amp;Translate...</source>
        <translation />
    </message>
    <message>
        <source>Cannot read from phrase book '%1'.</source>
        <translation />
    </message>
    <message>
        <source>Close this phrase book.</source>
        <translation />
    </message>
    <message>
        <source>Enables you to add, modify, or delete entries in this phrase book.</source>
        <translation />
    </message>
    <message>
        <source>Print the entries in this phrase book.</source>
        <translation />
    </message>
    <message>
        <source>Cannot create phrase book '%1'.</source>
        <translation />
    </message>
    <message>
        <source>Do you want to save phrase book '%1'?</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>%n unfinished message(s) left.</source>
        <translation><numerusform>%n befejezetlen üzenet van hátra.</numerusform>
        </translation>
    </message>
    <message>
        <source>All</source>
        <translation />
    </message>
    <message>
        <source>Guesses</source>
        <translation />
    </message>
    <message>
        <source>Toggles the validity check of accelerators</source>
        <translation />
    </message>
    <message>
        <source>Toggles the validity check of accelerators, i.e. whether the number of ampersands in the source and translation text is the same. If the check fails, a message is shown in the warnings window.</source>
        <translation />
    </message>
    <message>
        <source>Surrounding &amp;Whitespace</source>
        <translation />
    </message>
    <message>
        <source>Toggles the validity check of surrounding whitespace.</source>
        <translation />
    </message>
    <message>
        <source>Toggles the validity check of surrounding whitespace. If the check fails, a message is shown in the warnings window.</source>
        <translation />
    </message>
    <message>
        <source>Toggles the validity check of ending punctuation</source>
        <translation />
    </message>
    <message>
        <source>Toggles the validity check of ending punctuation. If the check fails, a message is shown in the warnings window.</source>
        <translation />
    </message>
    <message>
        <source>Toggles checking that phrase suggestions are used</source>
        <translation />
    </message>
    <message>
        <source>Toggles checking that phrase suggestions are used. If the check fails, a message is shown in the warnings window.</source>
        <translation />
    </message>
    <message>
        <source>Toggles the validity check of place markers</source>
        <translation />
    </message>
    <message>
        <source>Toggles the validity check of place markers, i.e. whether %1, %2, ... are used consistently in the source text and translation text. If the check fails, a message is shown in the warnings window.</source>
        <translation />
    </message>
    <message>
        <source>Toggles visualize whitespace in editors</source>
        <translation />
    </message>
    <message>
        <source>Show more</source>
        <translation />
    </message>
    <message>
        <source>Alt++</source>
        <translation />
    </message>
    <message>
        <source>Show fewer</source>
        <translation />
    </message>
    <message>
        <source>Alt+-</source>
        <translation />
    </message>
    <message>
        <source>Alt+0</source>
        <translation />
    </message>
    <message>
        <source>D&amp;one</source>
        <translation />
    </message>
    <message>
        <source>Mark item as done</source>
        <translation />
    </message>
    <message>
        <source>Mark this item as done.</source>
        <translation />
    </message>
    <message>
        <source>Find P&amp;revious</source>
        <translation />
    </message>
    <message>
        <source>Shift+F3</source>
        <translation />
    </message>
</context>
<context>
    <name>MessageEditor</name>
    <message>
        <source />
        <comment>This is the right panel of the main window.</comment>
        <translation />
    </message>
    <message>
        <source>Russian</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>German</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Japanese</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>French</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Polish</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Chinese</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>This whole panel allows you to view and edit the translation of some source text.</source>
        <translation />
    </message>
    <message>
        <source>Source text</source>
        <translation />
    </message>
    <message>
        <source>This area shows the source text.</source>
        <translation />
    </message>
    <message>
        <source>Source text (Plural)</source>
        <translation />
    </message>
    <message>
        <source>This area shows the plural form of the source text.</source>
        <translation />
    </message>
    <message>
        <source>Developer comments</source>
        <translation />
    </message>
    <message>
        <source>This area shows a comment that may guide you, and the context in which the text occurs.</source>
        <translation />
    </message>
    <message>
        <source>Here you can enter comments for your own use. They have no effect on the translated applications.</source>
        <translation />
    </message>
    <message>
        <source>Translation to %1 (%2)</source>
        <translation />
    </message>
    <message>
        <source>Translation to %1</source>
        <translation />
    </message>
    <message>
        <source>Translator comments for %1</source>
        <translation />
    </message>
    <message>
        <source>%1 translation (%2)</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>This is where you can enter or modify the translation of the above source text.</source>
        <translation />
    </message>
    <message>
        <source>%1 translation</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>%1 translator comments</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>'%1'
Line: %2</source>
        <translation />
    </message>
</context>
<context>
    <name>MessageModel</name>
    <message>
        <source>Completion status for %1</source>
        <translation />
    </message>
    <message>
        <source>&lt;file header&gt;</source>
        <translation />
    </message>
    <message>
        <source>&lt;context comment&gt;</source>
        <translation />
    </message>
    <message>
        <source>&lt;unnamed context&gt;</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>%n unfinished message(s) left.</source>
        <translation><numerusform>%n befejezetlen üzenet van hátra.</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>PhraseBook</name>
    <message>
        <source>Parse error at line %1, column %2 (%3).</source>
        <translation />
    </message>
</context>
<context>
    <name>PhraseBookBox</name>
    <message>
        <source>Edit Phrase Book</source>
        <translation />
    </message>
    <message>
        <source>This window allows you to add, modify, or delete entries in a phrase book.</source>
        <translation />
    </message>
    <message>
        <source>&amp;Translation:</source>
        <translation />
    </message>
    <message>
        <source>This is the phrase in the target language corresponding to the source phrase.</source>
        <translation />
    </message>
    <message>
        <source>S&amp;ource phrase:</source>
        <translation />
    </message>
    <message>
        <source>This is a definition for the source phrase.</source>
        <translation />
    </message>
    <message>
        <source>This is the phrase in the source language.</source>
        <translation />
    </message>
    <message>
        <source>&amp;Definition:</source>
        <translation />
    </message>
    <message>
        <source>Click here to add the phrase to the phrase book.</source>
        <translation />
    </message>
    <message>
        <source>&amp;New Entry</source>
        <translation />
    </message>
    <message>
        <source>Click here to remove the entry from the phrase book.</source>
        <translation />
    </message>
    <message>
        <source>&amp;Remove Entry</source>
        <translation />
    </message>
    <message>
        <source>Settin&amp;gs...</source>
        <translation />
    </message>
    <message>
        <source>Click here to save the changes made.</source>
        <translation />
    </message>
    <message>
        <source>&amp;Save</source>
        <translation />
    </message>
    <message>
        <source>Click here to close this window.</source>
        <translation />
    </message>
    <message>
        <source>Close</source>
        <translation />
    </message>
    <message>
        <source />
        <comment>Go to Phrase &gt; Edit Phrase Book... The dialog that pops up is a PhraseBookBox.</comment>
        <translation />
    </message>
    <message>
        <source>(New Entry)</source>
        <translation />
    </message>
    <message>
        <source>%1[*] - Qt Linguist</source>
        <translation />
    </message>
    <message>
        <source>Qt Linguist</source>
        <translation />
    </message>
    <message>
        <source>Cannot save phrase book '%1'.</source>
        <translation />
    </message>
</context>
<context>
    <name>PhraseModel</name>
    <message>
        <source>Source phrase</source>
        <translation />
    </message>
    <message>
        <source>Translation</source>
        <translation />
    </message>
    <message>
        <source>Definition</source>
        <translation />
    </message>
</context>
<context>
    <name>PhraseView</name>
    <message>
        <source>Insert</source>
        <translation />
    </message>
    <message>
        <source>Edit</source>
        <translation />
    </message>
    <message>
        <source>Go to</source>
        <translation />
    </message>
    <message>
        <source>Guess from '%1' (%2)</source>
        <translation />
    </message>
    <message>
        <source>Guess from '%1'</source>
        <translation />
    </message>
    <message>
        <source>Guess (%1)</source>
        <translation type="vanished" />
    </message>
    <message>
        <source>Guess</source>
        <translation type="vanished" />
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Translation files (%1);;</source>
        <translation />
    </message>
    <message>
        <source>All files (*)</source>
        <translation />
    </message>
    <message>
        <source>Qt Linguist</source>
        <translation />
    </message>
</context>
<context>
    <name>SourceCodeView</name>
    <message>
        <source>&lt;i&gt;Source code not available&lt;/i&gt;</source>
        <translation />
    </message>
    <message>
        <source>&lt;i&gt;File %1 not available&lt;/i&gt;</source>
        <translation />
    </message>
    <message>
        <source>&lt;i&gt;File %1 not readable&lt;/i&gt;</source>
        <translation />
    </message>
</context>
<context>
    <name>Statistics</name>
    <message>
        <source>Statistics</source>
        <translation />
    </message>
    <message>
        <source>Close</source>
        <translation />
    </message>
    <message>
        <source>Translation</source>
        <translation />
    </message>
    <message>
        <source>Source</source>
        <translation />
    </message>
    <message>
        <source>0</source>
        <translation />
    </message>
    <message>
        <source>Words:</source>
        <translation />
    </message>
    <message>
        <source>Characters:</source>
        <translation />
    </message>
    <message>
        <source>Characters (with spaces):</source>
        <translation />
    </message>
    <message>
        <source>Unfinished</source>
        <translation />
    </message>
    <message>
        <source>Total translatable messages:</source>
        <translation />
    </message>
    <message>
        <source>Total finished:</source>
        <translation />
    </message>
    <message>
        <source>Without warnings:</source>
        <translation />
    </message>
    <message>
        <source>With warnings:</source>
        <translation />
    </message>
    <message>
        <source>Unfinished:</source>
        <translation />
    </message>
    <message>
        <source>Total messages including obsolete:</source>
        <translation />
    </message>
</context>
<context>
    <name>TranslateDialog</name>
    <message>
        <source>This window allows you to search for some text in the translation source file.</source>
        <translation />
    </message>
    <message>
        <source>Type in the text to search for.</source>
        <translation />
    </message>
    <message>
        <source>Find &amp;source text:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Translate to:</source>
        <translation />
    </message>
    <message>
        <source>Search options</source>
        <translation />
    </message>
    <message>
        <source>Texts such as 'TeX' and 'tex' are considered as different when checked.</source>
        <translation />
    </message>
    <message>
        <source>Match &amp;case</source>
        <translation />
    </message>
    <message>
        <source>Mark new translation as &amp;finished</source>
        <translation />
    </message>
    <message>
        <source>Click here to find the next occurrence of the text you typed in.</source>
        <translation />
    </message>
    <message>
        <source>Find Next</source>
        <translation />
    </message>
    <message>
        <source>Translate</source>
        <translation />
    </message>
    <message>
        <source>Translate All</source>
        <translation />
    </message>
    <message>
        <source>Click here to close this window.</source>
        <translation />
    </message>
    <message>
        <source>Cancel</source>
        <translation />
    </message>
</context>
<context>
    <name>TranslationSettingsDialog</name>
    <message>
        <source>Source language</source>
        <translation />
    </message>
    <message>
        <source>Language</source>
        <translation />
    </message>
    <message>
        <source>Country/Region</source>
        <translation />
    </message>
    <message>
        <source>Target language</source>
        <translation />
    </message>
    <message>
        <source>%1 (%2)</source>
        <extracomment>&lt;english&gt; (&lt;endonym&gt;) (language names)</extracomment>
        <translation />
    </message>
    <message>
        <source>Settings for '%1' - Qt Linguist</source>
        <translation />
    </message>
    <message>
        <source>Any Territory</source>
        <translation />
    </message>
    <message>
        <source>Any Country</source>
        <translation type="vanished" />
    </message>
</context>
</TS>