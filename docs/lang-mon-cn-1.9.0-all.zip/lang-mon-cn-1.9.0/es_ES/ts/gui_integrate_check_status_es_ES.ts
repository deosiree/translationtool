<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_status/mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_status/mainwindow.ui" line="62"/>
        <source>详情展示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_status/mainwindow.ui" line="103"/>
        <source>节点：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_status/mainwindow.ui" line="110"/>
        <source>所有节点</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_status/mainwindow.ui" line="130"/>
        <source>查验</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_status/mainwindow.cpp" line="127"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_status/mainwindow.cpp" line="127"/>
        <source>请选择节点</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_status/plugin_net_check.cpp" line="49"/>
        <source>安全信息检查</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RealStatus</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_status/real_status.ui" line="14"/>
        <source>RealStatus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_status/real_status.cpp" line="214"/>
        <source>应用名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_status/real_status.cpp" line="214"/>
        <source>进程名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_status/real_status.cpp" line="214"/>
        <source>状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_status/real_status.cpp" line="214"/>
        <source>操作</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
