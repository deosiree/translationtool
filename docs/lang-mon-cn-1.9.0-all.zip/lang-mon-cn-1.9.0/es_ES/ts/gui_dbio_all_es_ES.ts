<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/main.cpp" line="452"/>
        <source>运行库DBIO</source>
        <comment>gui_dbio_normal_error</comment>
        <translation type="unfinished">RTDB DBIO</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/main.cpp" line="454"/>
        <source>维护库DBIO</source>
        <comment>gui_dbio_normal_error</comment>
        <translation type="unfinished">MTDB DBIO</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/main.cpp" line="463"/>
        <source>--本节点：</source>
        <comment>gui_dbio_normal_error</comment>
        <translation type="unfinished">--Nodo local:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/main.cpp" line="464"/>
        <source>应用名:</source>
        <comment>gui_dbio_normal_error</comment>
        <translation type="unfinished">Nombre de la aplicación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/main.cpp" line="465"/>
        <source>连接节点名：</source>
        <comment>gui_dbio_normal_error</comment>
        <translation type="unfinished">Nombre del nodo conectado:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/main.cpp" line="531"/>
        <source>登录时限：</source>
        <translation type="unfinished">Límite de tiempo de inicio de sesión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/main.cpp" line="560"/>
        <source>%1 没有此工具的打开权限! </source>
        <comment>gui_dbio_normal_error</comment>
        <translation type="unfinished">%1 sin permiso para abrir esta herramienta!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/main.cpp" line="561"/>
        <source>提示</source>
        <comment>gui_dbio_normal_error</comment>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.cpp" line="371"/>
        <source>条件查询对象</source>
        <comment>toolName</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>appAccess</name>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="648"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="686"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="693"/>
        <source>提示</source>
        <translation type="unfinished">Consejo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="648"/>
        <source>无在线应用,是否本地打开</source>
        <translation type="unfinished">No hay aplicación en línea, ¿abrir localmente?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="686"/>
        <source>维护节点应用/库离线</source>
        <translation type="unfinished">Nodo de maint. App/BD están fuera de línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="693"/>
        <source>数据库打开失败</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dbio_dbShowDialog</name>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="54"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="266"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="54"/>
        <source>当前是无系统模式</source>
        <translation type="unfinished">Actualmente en modo sin sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="173"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="288"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="209"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="287"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="266"/>
        <source>当前为镜像库</source>
        <translation type="unfinished">La biblioteca de imágenes está actualmente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="276"/>
        <source>请输入必要参数</source>
        <comment>toolName</comment>
        <translation type="unfinished">Ingrese los Parámetros Requeridos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="283"/>
        <source>库类型：</source>
        <translation type="unfinished">Tipo de base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="295"/>
        <source>应用名：</source>
        <translation type="unfinished">Nombre de la aplicación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="307"/>
        <source>库名称：</source>
        <translation type="unfinished">Nombre de la base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_app_access.cpp" line="321"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
</context>
<context>
    <name>dbio_query_widget</name>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="27"/>
        <source>批量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="34"/>
        <source>获取OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="41"/>
        <source>条件字符串</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="55"/>
        <source>排序表名.字段名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="76"/>
        <source>升序</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="81"/>
        <source>降序</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="90"/>
        <source>关键字</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="95"/>
        <source>标识字段</source>
        <translation type="unfinished">Campo ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="100"/>
        <source>自定义</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="114"/>
        <source>查询</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="121"/>
        <source>清空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="128"/>
        <source>自适应列宽</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="139"/>
        <source>节点名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="152"/>
        <source>默认本节点</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="162"/>
        <source>应用名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="176"/>
        <source>库名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="203"/>
        <source>用本地接口</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="210"/>
        <source>连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="217"/>
        <source>生成条件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.ui" line="231"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;/Substation(name)/VoltageLevel(name)/Bay(name)/Breaker(name)&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;/Breaker(name)/Bay(name)/VoltageLevel(name)/Substation(name)&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;/Breaker/Bay/VoltageLevel/Substation(name)&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.cpp" line="201"/>
        <source>连接实时库</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.cpp" line="201"/>
        <source>连接失败！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.cpp" line="235"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.cpp" line="254"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.cpp" line="256"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.cpp" line="276"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.cpp" line="283"/>
        <source>条件查询</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.cpp" line="236"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.cpp" line="284"/>
        <source>查询成功！返回记录条数为 %1，查询耗时 %2 ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.cpp" line="254"/>
        <source>查询结果为0！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.cpp" line="256"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.cpp" line="276"/>
        <source>查询失败！%1%2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dbio_schema_config</name>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1789"/>
        <source>显示配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Configuración de visualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1796"/>
        <source>库类型</source>
        <translation type="unfinished">Tipo de biblioteca</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1800"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2050"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1801"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2025"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1804"/>
        <source>应用:</source>
        <translation type="unfinished">App:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1814"/>
        <source>库名：</source>
        <translation type="unfinished">Nombre de la base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1822"/>
        <source>表名：</source>
        <translation type="unfinished">Nombre de la tabla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1840"/>
        <source>帮助</source>
        <translation type="unfinished">Ayuda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1847"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1857"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2563"/>
        <source>退出</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2461"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2461"/>
        <source>数据发生变化，是否保存</source>
        <translation type="unfinished">Los datos han sido modificados, ¿desea guardar los cambios?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2554"/>
        <source>更新失败的应用：</source>
        <translation type="unfinished">App que no se actualizó:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2584"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2584"/>
        <source>保存成功!</source>
        <translation type="unfinished">¡Guardado exitosamente!</translation>
    </message>
</context>
<context>
    <name>dbio_schema_table</name>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2615"/>
        <source>检索路径配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Ruta de recuperación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2622"/>
        <source>目标表名：</source>
        <translation type="unfinished">Nombre de la tabla de destino:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2634"/>
        <source>所有路径：</source>
        <translation type="unfinished">Todas las rutas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2648"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2649"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2712"/>
        <source>增加</source>
        <translation type="unfinished">Agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2653"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2654"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2714"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2658"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2659"/>
        <source>撤回</source>
        <translation type="unfinished">Revocar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2676"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2676"/>
        <source>检索名称</source>
        <translation type="unfinished">Nombre de búsqueda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2676"/>
        <source>检索路径</source>
        <translation type="unfinished">Ruta de búsqueda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2676"/>
        <source>操作</source>
        <translation type="unfinished">Operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2676"/>
        <source>默认展开表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2696"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2697"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2700"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2701"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3006"/>
        <source>关闭</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2854"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2939"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3091"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2854"/>
        <source>根据表获取检索信息失败！</source>
        <translation type="unfinished">¡Fallo al recuperar la información según la tabla!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2903"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3047"/>
        <source>检索</source>
        <translation type="unfinished">Buscar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3162"/>
        <source>信息提示</source>
        <comment>toolName</comment>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2635"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2924"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3056"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3145"/>
        <source>共计%1条记录</source>
        <translation type="unfinished">Total de registros %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2939"/>
        <source>保存前,检索路径不能为空！</source>
        <translation type="unfinished">¡Antes de guardar, la ruta de búsqueda no puede estar vacía!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="2999"/>
        <source>更新失败的应用:</source>
        <translation type="unfinished">Aplicación que no se actualizó:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3021"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3021"/>
        <source>保存成功!</source>
        <translation type="unfinished">¡Guardado exitosamente!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3039"/>
        <source>表检索名</source>
        <translation type="unfinished">Nombre de búsqueda de tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3091"/>
        <source>未选中任何行</source>
        <translation type="unfinished">No se seleccionaron filas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3095"/>
        <source>删除警告</source>
        <translation type="unfinished">Advertencia de eliminación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3096"/>
        <source>删除选择对象?</source>
        <translation type="unfinished">¿Eliminar selección?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3163"/>
        <source>确定取消？</source>
        <translation type="unfinished">¿Está seguro de que desea cancelar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3185"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3185"/>
        <source>无服务仅更新本地本库</source>
        <translation type="unfinished">Sin servicio, solo se actualiza la base de datos local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3196"/>
        <source>路径【{%1}】下库【{%2}】连接打开失败,取消更新</source>
        <translation type="unfinished"> La ruta [{%1}], [{%2}] falló al abrir la conexión, cancelando la actualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3208"/>
        <source>路径【{%1}】下库【{%2}】更新检索信息失败</source>
        <translation type="unfinished">Ruta [{%1}], base de datos [{%2}] falló al actualizar la información de recuperación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3250"/>
        <source>应用【{%1}】运行库【{%2}】连接打开失败，更新检索信息失败</source>
        <translation type="unfinished">Aplicación [{%1}] RTDB [{%2}] falló al abrir la conexión, no se pudo actualizar la información de recuperación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3261"/>
        <source>应用【{%1}】运行库【{%2}】更新检索信息失败</source>
        <translation type="unfinished">Aplicación [{%1}] RTDB [{%2}] falló al actualizar la información de recuperación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3271"/>
        <source>应用【{%1}】维护库【{%2}】连接打开失败，更新检索信息失败</source>
        <translation type="unfinished">Aplicación [{%1}] MTDB [{%2}] falló al abrir la conexión, no se pudo actualizar la información de recuperación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="3282"/>
        <source>应用【{%1}】维护库【{%2}】更新检索信息失败</source>
        <translation type="unfinished">Aplicación [{%1}] MTDB [{%2}] falló al actualizar la información de recuperación</translation>
    </message>
</context>
<context>
    <name>dbio_table_config</name>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="57"/>
        <source>别名</source>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="62"/>
        <source>检索器中不可见：</source>
        <translation type="unfinished">No visible en el recuperador:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="68"/>
        <source>存历史</source>
        <translation type="unfinished">Guardar historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="77"/>
        <source>是否库同步更新：</source>
        <translation type="unfinished">Sincronizar base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="86"/>
        <source>字段名称</source>
        <translation type="unfinished">Nombre del campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="87"/>
        <source>字段别名</source>
        <translation type="unfinished">Alias de campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="89"/>
        <source>关键字字段</source>
        <translation type="unfinished">Campo clave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="91"/>
        <source>标识字段</source>
        <translation type="unfinished">Campo ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="92"/>
        <source>检索器展示顺序</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="93"/>
        <source>检索器默认选中</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="94"/>
        <source>是否存历史</source>
        <translation type="unfinished">Guardar historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="95"/>
        <source>是否装库</source>
        <translation type="unfinished">Recarga de base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="96"/>
        <source>维护和运行库同步更新</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="97"/>
        <source>维护库中显示顺序</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="98"/>
        <source>运行库中显示顺序</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="99"/>
        <source>循环子对象个数</source>
        <translation type="unfinished">Cantidad de subobjetos del bucle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="100"/>
        <source>单向关联</source>
        <translation type="unfinished">Enlace unidireccional</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="101"/>
        <source>跨库关联</source>
        <translation type="unfinished">Enlace entre bases de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="102"/>
        <source>是否翻译</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="103"/>
        <source>是否索引</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="276"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="307"/>
        <source>不存历史</source>
        <translation type="unfinished">Sin historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="277"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="302"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1363"/>
        <source>采样存历史（主动）</source>
        <translation type="unfinished">Almacenamiento de historial de muestreo (activo)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="278"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="297"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1368"/>
        <source>事件存历史（被动）</source>
        <translation type="unfinished">Almacenamiento de historial de eventos (pasivo)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="279"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="292"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1373"/>
        <source>统计存历史</source>
        <translation type="unfinished">Almacenamiento de historial de estadísticas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="280"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="287"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1358"/>
        <source>采样加事件</source>
        <translation type="unfinished">Eventos de muestreo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="700"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1108"/>
        <source>应用【{%1}】运行库【{%2}】连接打开失败,取消更新</source>
        <translation type="unfinished">Aplicación [{%1}] RTDB [{%2}] falló al abrir la conexión, cancelando la actualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="714"/>
        <source>应用【{%1}】运行库【{%2}】更新保存失败</source>
        <translation type="unfinished">Application [{%1}] RTDB [{%2}] update save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="745"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1165"/>
        <source>维护节点【{%1}】应用【{%2}】维护库【{%3}】连接打开失败，取消更新</source>
        <translation type="unfinished">Nodo de mantenimiento [{%1}] Aplicación [{%2}] MTDB [{%3}] La conexión falló al abrir, cancelando la actualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="763"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1182"/>
        <source>应用【{%1}】维护库【{%2}】更新失败</source>
        <translation type="unfinished">Application [{%1}] MTDB [{%2}] update failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="785"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1046"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1611"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1665"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="785"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1046"/>
        <source>无服务仅更新本地本库</source>
        <translation type="unfinished">Sin servicio, solo se actualiza la base de datos local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="800"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1061"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1219"/>
        <source>路径【{%1}】下库【{%2}】连接打开失败,取消更新</source>
        <translation type="unfinished"> La ruta [{%1}], [{%2}] falló al abrir la conexión, cancelando la actualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="812"/>
        <source>路径【{%1}】下库【{%2}】更新表属性保存失败</source>
        <translation type="unfinished">Fallo al guardar las propiedades de la tabla actualizada de la base de datos [{%2}] bajo la ruta [{%1}]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="850"/>
        <source>应用【{%1}】运行库【{%2}】连接打开失败</source>
        <translation type="unfinished">Aplicación [{%1}] RTDB [{%2}] falló al abrir la conexión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="861"/>
        <source>应用【{%1}】运行库【{%2}】更新表属性保存失败</source>
        <translation type="unfinished">Aplicación [{%1}] RTDB [{%2}] falló al guardar las propiedades de la tabla actualizada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="883"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1142"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1297"/>
        <source>应用【{%1}】维护库【{%2}】OID【{%3}】系统查询维护节点失败</source>
        <translation type="unfinished">Aplicación [{%1}] MTDB [{%2}] OID [{%3}] El sistema falló al consultar el nodo de mantenimiento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="907"/>
        <source>应用【{%1}】维护库【{%2}】连接打开失败，取消更新</source>
        <translation type="unfinished">Aplicación [{%1}] MTDB [{%2}] falló al abrir la conexión, cancelando la actualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="920"/>
        <source>应用【{%1}】维护库【{%2}】更新表属性失败</source>
        <translation type="unfinished">Aplicación [{%1}] MTDB [{%2}] falló al actualizar las propiedades de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="968"/>
        <source>应用【{%1}】运行库【{%2}】更新表属性失败</source>
        <translation type="unfinished">Aplicación [{%1}] RTDB [{%2}] falló al actualizar las propiedades de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="978"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1278"/>
        <source>应用【{%1}】运行库【{%2}】更新关联信息保存失败</source>
        <translation type="unfinished">Aplicación [{%1}] RTDB [{%2}] falló al guardar la información de asociación actualizada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="995"/>
        <source>应用【{%1}】维护库【{%2}】查询维护节点失败</source>
        <translation type="unfinished">Falló la consulta de un nodo de mantenimiento en el [{%1}] MTDB [{%2}]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1010"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1321"/>
        <source>应用【{%1}】维护库【{%2}】连接打开失败</source>
        <translation type="unfinished">Aplicación [{%1}] MTDB [{%2}] falló al abrir la conexión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1021"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1332"/>
        <source>应用【{%1}】维护库【{%2}】更新关联信息失败</source>
        <translation type="unfinished">Aplicación [{%1}] MTDB [{%2}] falló al actualizar la información de asociación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1073"/>
        <source>路径【{%1}】下库【{%2}】更新字段保存失败</source>
        <translation type="unfinished">Ruta [{%1}], base de datos [{%2}] falló al guardar el campo de actualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1121"/>
        <source>应用【{%1}】运行库【{%2}】更新字段保存失败</source>
        <translation type="unfinished">Aplicación [{%1}] RTDB [{%2}] falló al guardar el campo de actualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1231"/>
        <source>路径【{%1}】下库【{%2}】更新关联信息保存失败</source>
        <translation type="unfinished">La ruta [{%1}], la actualización de la información de asociación [{%2}] no se pudo guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1266"/>
        <source>应用【{%1}】运行库【{%2}】连接打开失败，取消更新</source>
        <translation type="unfinished">Aplicación [{%1}] RTDB [{%2}] falló al abrir la conexión, cancelando la actualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1611"/>
        <source>跨库不能为空</source>
        <translation type="unfinished">No puede estar vacío el enlace entre bases de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_schema_config.cpp" line="1665"/>
        <source>配置格式有误</source>
        <translation type="unfinished">El formato de configuración es incorrecto</translation>
    </message>
</context>
<context>
    <name>dbio_worker</name>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_worker.cpp" line="81"/>
        <source>导出失败</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>mainWindow</name>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="236"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="237"/>
        <source>切换库</source>
        <translation type="unfinished">Cambiar base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="246"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="247"/>
        <source>导出库</source>
        <translation type="unfinished">Exportar base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="256"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="257"/>
        <source>导入库</source>
        <translation type="unfinished">Importar base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="274"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="275"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1151"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1217"/>
        <source>退出</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="289"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="291"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="956"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="1160"/>
        <source>编辑</source>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="306"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="307"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="318"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="319"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="333"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="334"/>
        <source>插入单个</source>
        <translation type="unfinished">Inserción individual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="350"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="351"/>
        <source>插入多个</source>
        <translation type="unfinished">Inserción múltiple</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="365"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="366"/>
        <source>删除选择</source>
        <translation type="unfinished">Eliminar selección</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="382"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="383"/>
        <source>删除所有</source>
        <translation type="unfinished">Eliminar todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="397"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="398"/>
        <source>剪切</source>
        <translation type="unfinished">Cortar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="414"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="415"/>
        <source>拷贝</source>
        <translation type="unfinished">Copiar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="432"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="433"/>
        <source>粘贴</source>
        <translation type="unfinished">Pegar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="449"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="450"/>
        <source>排序</source>
        <translation type="unfinished">Orden</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="460"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="461"/>
        <source>查找</source>
        <translation type="unfinished">Buscar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="473"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="474"/>
        <source>过滤</source>
        <translation type="unfinished">Filtro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="484"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="485"/>
        <source>替换</source>
        <translation type="unfinished">Reemplazar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="501"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="502"/>
        <source>刷新</source>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="531"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="532"/>
        <source>显示配置</source>
        <translation type="unfinished">Configuración de visualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="578"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="579"/>
        <source>同步修改运行库</source>
        <translation type="unfinished">Sincronizar modificar
RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="583"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="584"/>
        <source>同步修改维护库</source>
        <translation type="unfinished">Sincronizar modificar MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="599"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="601"/>
        <source>显示变化</source>
        <translation type="unfinished">Mostrar cambios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="612"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="613"/>
        <source>列宽</source>
        <translation type="unfinished">Ancho de columna</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="624"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="625"/>
        <source>所有列</source>
        <translation type="unfinished">Todas las columnas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="636"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="637"/>
        <source>选择列</source>
        <translation type="unfinished">Columnas del selector</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="648"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="650"/>
        <source>属性页</source>
        <translation type="unfinished">Página de atributos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="661"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="663"/>
        <source>检索器</source>
        <translation type="unfinished">Recuperador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="699"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="700"/>
        <source>文档</source>
        <translation type="unfinished">Documento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="710"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="711"/>
        <source>关于</source>
        <translation type="unfinished">Acerca de</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="720"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="721"/>
        <source>OID转换</source>
        <translation type="unfinished">Conversión OID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="725"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="726"/>
        <source>TID转换</source>
        <translation type="unfinished">Conversión TID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="729"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="730"/>
        <source>OID定位</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="2133"/>
        <source>当前修改未保存,是否需先保存!%1  [确认]: 保存修改!%2  [取消]: 放弃修改!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="735"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="736"/>
        <source>清除无效单向</source>
        <translation type="unfinished">Limpiar el Inválido de Una Vía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="743"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="744"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="749"/>
        <source>检索路径配置</source>
        <translation type="unfinished">Ruta de recuperación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="771"/>
        <source>可用节点：</source>
        <translation type="unfinished">Nodos disponibles:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="778"/>
        <source>仅连值班机</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="784"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="785"/>
        <source>应用发布</source>
        <translation type="unfinished">Publicación de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="932"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="1159"/>
        <source>模型</source>
        <translation type="unfinished">Modelo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="978"/>
        <source>设置</source>
        <translation type="unfinished">Configuraciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="1026"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="1162"/>
        <source>窗口</source>
        <translation type="unfinished">Ventana</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="1038"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="1163"/>
        <source>帮助</source>
        <translation type="unfinished">Ayuda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="1043"/>
        <source>更多</source>
        <translation type="unfinished">Más</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="1161"/>
        <source>工具</source>
        <translation type="unfinished">Herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="1623"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="2132"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_model.cpp" line="42"/>
        <source>维护工具</source>
        <translation type="unfinished">Herramientas de mantenimiento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="2050"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="2070"/>
        <source>保存确认</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="2050"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_func.cpp" line="2071"/>
        <source>保存编辑 是/否?</source>
        <translation type="unfinished">¿Guardar ediciones Sí/No?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_edit.cpp" line="169"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_model.cpp" line="165"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_model.cpp" line="205"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="519"/>
        <source>错误信息</source>
        <translation type="unfinished">Mensaje de error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_edit.cpp" line="171"/>
        <source>保存对象失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_edit.cpp" line="350"/>
        <source>删除选中对象</source>
        <translation type="unfinished">Eliminar selección</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_edit.cpp" line="392"/>
        <source>删除所有对象</source>
        <translation type="unfinished">Eliminar todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_help.cpp" line="53"/>
        <source>节点：</source>
        <translation type="unfinished">Nodo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_help.cpp" line="54"/>
        <source>应用：</source>
        <translation type="unfinished">App:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_help.cpp" line="55"/>
        <source>库名：</source>
        <translation type="unfinished">Nombre de la base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_help.cpp" line="56"/>
        <source>库类型：</source>
        <translation type="unfinished">Tipo de base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_help.cpp" line="73"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="485"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_help.cpp" line="87"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_help.cpp" line="89"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1058"/>
        <source>信息</source>
        <translation type="unfinished">Mensaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_model.cpp" line="132"/>
        <source>保存文件</source>
        <translation type="unfinished">Guardar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_model.cpp" line="43"/>
        <source>当前修改未保存,是否需保存退出! [确认]: 保存后退出! [取消]: 放弃后退出!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_model.cpp" line="126"/>
        <source>请先保存数据！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_model.cpp" line="150"/>
        <source>导出库信息中......请等待</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_model.cpp" line="170"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_model.cpp" line="212"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="385"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_model.cpp" line="170"/>
        <source>导出成功！</source>
        <translation type="unfinished">¡Exportación exitosa!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_model.cpp" line="195"/>
        <source>选择文件</source>
        <translation type="unfinished">Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_model.cpp" line="195"/>
        <source>导入配置文件%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_model.cpp" line="206"/>
        <source>导入失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_model.cpp" line="212"/>
        <source>导入成功！</source>
        <translation type="unfinished">¡Importación exitosa!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="322"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="355"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="610"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="980"/>
        <source>运行库DBIO</source>
        <translation type="unfinished">RTDB DBIO</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="363"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="618"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="983"/>
        <source>维护库DBIO</source>
        <translation type="unfinished">MTDB DBIO</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="368"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="623"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="987"/>
        <source>--本节点：</source>
        <translation type="unfinished">--Nodo local:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="368"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="623"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="987"/>
        <source>应用名:</source>
        <translation type="unfinished">Nombre de la aplicación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="369"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="624"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="988"/>
        <source>连接节点名：</source>
        <translation type="unfinished">Nombre del nodo conectado:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="385"/>
        <source>切换节点成功！</source>
        <translation type="unfinished">¡Cambio de nodo exitoso!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="520"/>
        <source>打开库失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="635"/>
        <source>版本号</source>
        <translation type="unfinished">Número de versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="728"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="908"/>
        <source>主机</source>
        <translation type="unfinished">Host</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="734"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="915"/>
        <source>备用机</source>
        <translation type="unfinished">Dispositivo de respaldo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="952"/>
        <source>实时库非正常状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1014"/>
        <source>需等待，是否继续</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1018"/>
        <source>是</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1019"/>
        <source>否</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1039"/>
        <source>清除无效单向关联......请等待</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1068"/>
        <source>OID转换器</source>
        <comment>toolName</comment>
        <translation type="unfinished">Convertidor OID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1163"/>
        <source>TID转换器</source>
        <comment>toolName</comment>
        <translation type="unfinished">Convertidor TID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1227"/>
        <source>OID定位</source>
        <comment>toolName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1310"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_model.cpp" line="126"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="782"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="800"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="877"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="952"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1014"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1054"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="782"/>
        <source>切换库成功！</source>
        <translation type="unfinished">¡Cambio de base de datos exitoso!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="800"/>
        <source>发生装库事件</source>
        <translation type="unfinished">Ocurre un evento de carga</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="877"/>
        <source>无值班节点</source>
        <translation type="unfinished">Sin nodo de turno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1054"/>
        <source>清除失败</source>
        <translation type="unfinished">Limpiar fallido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1058"/>
        <source>清除结束</source>
        <translation type="unfinished">Finalizando limpieza</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1073"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1232"/>
        <source>例如：1:0:1</source>
        <translation type="unfinished">Ejemplo: 1:00:01</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/main.cpp" line="672"/>
        <source>访问工具</source>
        <translation type="unfinished">Acceso a herramientas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_other.cpp" line="349"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1113"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1136"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1188"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1206"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1272"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1295"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_other.cpp" line="349"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1113"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1136"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1188"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1206"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1272"/>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_main_window_slot_wind.cpp" line="1295"/>
        <source>异常输入，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>queryBaseWidget</name>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_query_widget.cpp" line="393"/>
        <source>退出</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
</context>
<context>
    <name>toolBarObjView</name>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_toolbar_objview.cpp" line="60"/>
        <source>仅对展开树节点查找</source>
        <translation type="unfinished">Buscar solo nodos de árbol expandido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_toolbar_objview.cpp" line="67"/>
        <source>版本号</source>
        <translation type="unfinished">Número de versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/tool/dbio/source/dbio_toolbar_objview.cpp" line="105"/>
        <source>模型</source>
        <translation type="unfinished">Modelo</translation>
    </message>
</context>
</TS>
