<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>BaseInfoWidget</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="42"/>
        <source>正确性校验</source>
        <translation type="unfinished">Correctness Check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="148"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="152"/>
        <source>导入配置</source>
        <translation type="unfinished">Import config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="46"/>
        <source>请选择导入的配置文件%1</source>
        <translation type="unfinished">Please select the config file to import %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="169"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="173"/>
        <source>导出配置</source>
        <translation type="unfinished">Export config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="51"/>
        <source>导出的配置文件为%1</source>
        <translation type="unfinished">Exported config file is %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="56"/>
        <source>设置应用进程及应用库，故障恢复全部启用</source>
        <translation type="unfinished">Set application processes and application dbs, and enable all fault recovery</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="61"/>
        <source>设置应用进程及应用库，故障恢复全部停用</source>
        <translation type="unfinished">Set App processes and App db, and disable all for fault recovery</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="83"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="83"/>
        <source>获取态定义失败</source>
        <translation type="unfinished">Failed to retrieve state definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="90"/>
        <source>态定义</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">State Definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="91"/>
        <source>态定义</source>
        <translation type="unfinished">State Definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="96"/>
        <source>历史库配置</source>
        <translation type="unfinished">HDB Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="135"/>
        <source>无法导入配置</source>
        <translation type="unfinished">Unable to import config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="135"/>
        <source>请在无系统下执行导入</source>
        <translation type="unfinished">Please execute the import with no system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="148"/>
        <source>导入失败</source>
        <translation type="unfinished">Import failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="152"/>
        <source>%1导入成功，重启生效</source>
        <translation type="unfinished">%1 import successful, restart effective</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="169"/>
        <source>导出失败</source>
        <translation type="unfinished">Export failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="173"/>
        <source>%1导出成功</source>
        <translation type="unfinished">%1 export succeeded</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="192"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="211"/>
        <source>设置成功</source>
        <translation type="unfinished">Set successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="221"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="243"/>
        <source>%1存在更改,请检查!</source>
        <translation type="unfinished">%1 has changes, please check!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="192"/>
        <source>全部恢复</source>
        <translation type="unfinished">Recover all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="38"/>
        <source>正确性校验</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Correctness check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="44"/>
        <source>导入配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Import config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="49"/>
        <source>导出配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Export config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="54"/>
        <source>故障恢复全部启用</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Enable all fault recovery</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="59"/>
        <source>故障恢复全部停用</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Disable all fault recovery</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="211"/>
        <source>全部取消恢复</source>
        <translation type="unfinished">Cancel recovery all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="221"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/base_info_widget.cpp" line="243"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
</context>
<context>
    <name>ConfButtonFrame</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_button_frame.cpp" line="34"/>
        <source>新增</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_button_frame.cpp" line="38"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_button_frame.cpp" line="42"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_button_frame.cpp" line="46"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
</context>
<context>
    <name>ConfItemDelegate</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_item_delegate.h" line="24"/>
        <source>请输入内容</source>
        <translation type="unfinished">Please enter content</translation>
    </message>
</context>
<context>
    <name>ConfTreeWidget</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="90"/>
        <source>保存修改</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="127"/>
        <source>请输入名称,名称需要包含%1字符</source>
        <translation type="unfinished">Please enter a name that includes the &apos;%1&apos; character</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="134"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="202"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="217"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="229"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="329"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="358"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="364"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="403"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="443"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="449"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="90"/>
        <source>存在未保存更改，是否保存</source>
        <translation type="unfinished">Unsaved changes. Save?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="217"/>
        <source>根节点不允许删除!</source>
        <translation type="unfinished">The root node cannot be deleted!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="221"/>
        <source>删除节点</source>
        <translation type="unfinished">Delete Node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="221"/>
        <source>是否删除此节点？</source>
        <translation type="unfinished">Whether to delete this node?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="229"/>
        <source>删除成功!</source>
        <translation type="unfinished">Deleted successfully!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="259"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="308"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="308"/>
        <source>保存失败!</source>
        <translation type="unfinished">Save failed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="312"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="312"/>
        <source>保存成功!</source>
        <translation type="unfinished">Saved successfully!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="629"/>
        <source>新增快捷键为Ctrl + N</source>
        <translation type="unfinished">Add shortcut key is Ctrl+N</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="635"/>
        <source>快捷键为Ctrl + D</source>
        <translation type="unfinished">Shortcut is Ctrl+D</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="639"/>
        <source>快捷键为Ctrl + R</source>
        <translation type="unfinished">Shortcut is Ctrl+R</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="643"/>
        <source>保存快捷键为Ctrl + S</source>
        <translation type="unfinished">Save shortcut is Ctrl+S</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="633"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="45"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="46"/>
        <source>通用配置</source>
        <translation type="unfinished">General config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="134"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="202"/>
        <source>不可新增</source>
        <translation type="unfinished">Cannot be added</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="259"/>
        <source>名称不能为空，请检查！</source>
        <translation type="unfinished">The name cannot be empty, please check!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="329"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="358"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="403"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="443"/>
        <source>名称长度不能超过31个字符，请修改</source>
        <translation type="unfinished">The length of the name cannot exceed 31 characters. Please modify it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="364"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="449"/>
        <source>值长度不能超过1023个字符，请修改</source>
        <translation type="unfinished">The value length cannot exceed 1023 characters. Please modify it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="627"/>
        <source>新增配置</source>
        <translation type="unfinished">Add Configs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="631"/>
        <source>新增配置信息</source>
        <translation type="unfinished">Add config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="637"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="641"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="649"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/conf/conf_treewidget.cpp" line="649"/>
        <source>值</source>
        <translation type="unfinished">Value</translation>
    </message>
</context>
<context>
    <name>DlgAppInstance</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_app_instance.cpp" line="34"/>
        <source>是否调整例号%1为 %2，调整后将删除实例号大于%3 的扩展应用</source>
        <translation type="unfinished">Whether to adjust the instance number %1 to %2. After adjustment, the extended application with instance number greater than %3 will be deleted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_app_instance.cpp" line="37"/>
        <source>询问</source>
        <translation type="unfinished">Ask</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_app_instance.cpp" line="68"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_app_instance.cpp" line="189"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_app_instance.cpp" line="68"/>
        <source>设置实例失败</source>
        <translation type="unfinished">Failed to set Instance
</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_app_instance.cpp" line="73"/>
        <source>已经设置最大实例: %1</source>
        <translation type="unfinished">Maximum instances set to: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_app_instance.cpp" line="74"/>
        <source>通知</source>
        <translation type="unfinished">Notification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_app_instance.cpp" line="83"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_app_instance.cpp" line="87"/>
        <source>应用实例详情</source>
        <comment>toolName</comment>
        <translation type="unfinished">App Instance Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_app_instance.cpp" line="93"/>
        <source>调整实例个数</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Instance count</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_app_instance.cpp" line="96"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_app_instance.cpp" line="91"/>
        <source>设置扩展应用实例数量:</source>
        <translation type="unfinished">Set extension instance count</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_app_instance.cpp" line="104"/>
        <source>输入希望设置的实例个数%1,根据输入个数自动调整实例号</source>
        <translation type="unfinished">Please enter instance count %1, auto-adjust instance IDs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_app_instance.cpp" line="189"/>
        <source>获取应用定义实例失败</source>
        <translation type="unfinished">Failed to retrieve application definition instance</translation>
    </message>
</context>
<context>
    <name>DlgDbChildObject</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_db_child_object.cpp" line="59"/>
        <source>显示子对象信息</source>
        <comment>toolName</comment>
        <translation type="unfinished">Sub Object Info</translation>
    </message>
</context>
<context>
    <name>DlgSetDependency</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="29"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="34"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="38"/>
        <source>设置依赖</source>
        <comment>toolName</comment>
        <translation type="unfinished">Set Dependency</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="47"/>
        <source>现场依赖</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Site Dependency</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="48"/>
        <source>节点依赖</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Node Dependency</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="82"/>
        <source>选中状态</source>
        <translation type="unfinished">Selected status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="82"/>
        <source>全应用名</source>
        <translation type="unfinished">Full app name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="82"/>
        <source>基础应用名</source>
        <translation type="unfinished">Base app name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="82"/>
        <source>描述</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="249"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="257"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="249"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="257"/>
        <source>最多配置9个依赖，超过无法保存</source>
        <translation type="unfinished">The maximum number of dependencies configured is 9, which cannot be saved</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="279"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="299"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="279"/>
        <source>设置现场部署失败</source>
        <translation type="unfinished">Failed to set up on-site deployment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="299"/>
        <source>设置节点部署失败</source>
        <translation type="unfinished">Failed to set node deployment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="304"/>
        <source>设置成功</source>
        <translation type="unfinished">Set successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/dialog/dlg_set_dependency.cpp" line="304"/>
        <source>设置依赖成功</source>
        <translation type="unfinished">Successfully set dependency</translation>
    </message>
</context>
<context>
    <name>FileSelectionWidget</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/file_selection_widget.cpp" line="14"/>
        <source>选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/file_selection_widget.cpp" line="56"/>
        <source>选择可执行程序</source>
        <translation type="unfinished">Select Executable Program</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/file_selection_widget.cpp" line="85"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/file_selection_widget.cpp" line="85"/>
        <source>请选择%1目录下的可执行程序</source>
        <translation type="unfinished">Please select the executable program in the %1 dir</translation>
    </message>
</context>
<context>
    <name>HandleTableData</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/handle_table_data.cpp" line="332"/>
        <source>(*可编辑)</source>
        <translation type="unfinished">(* Editable)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/handle_table_data.cpp" line="337"/>
        <source>(*可双击))</source>
        <translation type="unfinished">(* Dbl-clickable)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/handle_table_data.cpp" line="360"/>
        <source>启动依赖管理配置</source>
        <translation type="unfinished">Start dependency management</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/handle_table_data.cpp" line="803"/>
        <source>修改实时库，当前应用状态会改变，需谨慎选择</source>
        <translation type="unfinished">If you modify the TDB, the current application status will change, so you need to choose carefully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/handle_table_data.cpp" line="850"/>
        <source>设置依赖</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Set dependency</translation>
    </message>
</context>
<context>
    <name>LeftSysConfigTree</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/left_sysconfig_tree.cpp" line="32"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/left_sysconfig_tree.cpp" line="39"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/left_sysconfig_tree.cpp" line="55"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/left_sysconfig_tree.cpp" line="62"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/left_sysconfig_tree.cpp" line="120"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/left_sysconfig_tree.cpp" line="127"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/left_sysconfig_tree.cpp" line="32"/>
        <source>获取实时库定义失败</source>
        <translation type="unfinished">Failed to retrieve TDB definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/left_sysconfig_tree.cpp" line="39"/>
        <source>获取库定义表名称失败</source>
        <translation type="unfinished">Failed to retrieve db definition table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/left_sysconfig_tree.cpp" line="55"/>
        <source>获取应用定义失败</source>
        <translation type="unfinished">Failed to retrieve application definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/left_sysconfig_tree.cpp" line="62"/>
        <source>获取应用定义表名称失败</source>
        <translation type="unfinished">Failed to retrieve the name of the application definition table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/left_sysconfig_tree.cpp" line="120"/>
        <source>获取应用集合失败</source>
        <translation type="unfinished">Failed to retrieve application collection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/left_sysconfig_tree.cpp" line="127"/>
        <source>获取应用集合表名称失败</source>
        <translation type="unfinished">Failed to retrieve application collection table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/left_sysconfig_tree.cpp" line="208"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/left_sysconfig_tree.cpp" line="209"/>
        <source>系统类型</source>
        <translation type="unfinished">System type</translation>
    </message>
</context>
<context>
    <name>RightSysconfigInfoFrame</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_frame.cpp" line="37"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_frame.cpp" line="40"/>
        <source>新增</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_frame.cpp" line="41"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_frame.cpp" line="44"/>
        <source>批量增</source>
        <translation type="unfinished">Batch Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_frame.cpp" line="46"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_frame.cpp" line="49"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_frame.cpp" line="51"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_frame.cpp" line="54"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_frame.cpp" line="56"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_frame.cpp" line="59"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
</context>
<context>
    <name>RightSysconfigInfoTable</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="501"/>
        <source>保存修改</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="810"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="920"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1312"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1459"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1749"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1911"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2117"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2183"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2190"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2339"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2422"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2430"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2438"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2446"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2798"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2990"/>
        <source>失败</source>
        <translation type="unfinished">Fail</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="920"/>
        <source>删除失败</source>
        <translation type="unfinished">Deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="926"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1289"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1436"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="926"/>
        <source>删除成功</source>
        <translation type="unfinished">Delete successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="266"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="306"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="931"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="958"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1078"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1484"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1554"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1814"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1819"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="541"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1097"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1181"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1622"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="3595"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="3621"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="3625"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="542"/>
        <source>有删除项， 将停止正在运行的应用、库或服务，是否确认删除</source>
        <translation type="unfinished">Deletion item: stop running app/DB/svc. Confirm delete?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1181"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1622"/>
        <source>没有数据被修改</source>
        <translation type="unfinished">No data was modified</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1195"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1206"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1216"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1231"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1241"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1251"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1261"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1275"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1281"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1312"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1341"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1352"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1362"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1378"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1388"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1398"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1408"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1422"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1428"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1459"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2278"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2538"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2727"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1275"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1422"/>
        <source>名称不能为空</source>
        <translation type="unfinished">Name is required</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1289"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1436"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1484"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1554"/>
        <source>验证失败</source>
        <translation type="unfinished">Validated failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1510"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1593"/>
        <source>整数输入</source>
        <translation type="unfinished">Integer Input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1511"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1594"/>
        <source>请输入一个1-10的整数:</source>
        <translation type="unfinished">Please enter an integer from 1 to 10:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1749"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2183"/>
        <source>实时库名称重复</source>
        <translation type="unfinished">Duplicate TDB name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1814"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1819"/>
        <source>基础应用名称不可输入%1</source>
        <translation type="unfinished">The basic app name cannot be entered %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1911"/>
        <source>全应用名称重复</source>
        <translation type="unfinished">Full application name is duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2117"/>
        <source>模块名称重复</source>
        <translation type="unfinished">Duplicate module name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2190"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2430"/>
        <source>最大重启次数设置范围为0-255</source>
        <translation type="unfinished">The maximum number of restarts ranges from 0 to 255</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="266"/>
        <source>获取刷新数据失败</source>
        <translation type="unfinished">Failed to retrieve refresh data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="306"/>
        <source>获取应用定义实例失败</source>
        <translation type="unfinished">Failed to retrieve application definition instance</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="501"/>
        <source>存在未保存更改，是否保存</source>
        <translation type="unfinished">Unsaved changes. Save?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="810"/>
        <source>删除后不可恢复，是否继续</source>
        <translation type="unfinished">It cannot be recovered after deletion. Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="931"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="958"/>
        <source>请选择一条需要操作的数据</source>
        <translation type="unfinished">Please select a piece of data to operate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1078"/>
        <source>%1系统类型正在运行，不可删除</source>
        <translation type="unfinished">%1 the system type is running and cannot be deleted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1098"/>
        <source>删除配置项,将停止正在运行该配置项的配置，是否修改</source>
        <translation type="unfinished">Deleting a config item will stop the config of the running config item. Whether to modify it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1195"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1231"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1251"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1341"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1378"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1398"/>
        <source>长度超限，名称限制为31个字符</source>
        <translation type="unfinished">Length exceeded, name is limited to 31 characters</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1206"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1352"/>
        <source>长度超限，名称限制为16个字符</source>
        <translation type="unfinished">Length exceeded, name is limited to 16 characters</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1216"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1241"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1261"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1362"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1388"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1408"/>
        <source>长度超限，名称限制为8个字符</source>
        <translation type="unfinished">Length exceeded, name is limited to 8 characters</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1281"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1428"/>
        <source>长度超限，描述限制为63个字符</source>
        <translation type="unfinished">Length exceeded, description is limited to 63 characters</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1685"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1704"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1832"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1853"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2009"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2030"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2286"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2479"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2497"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2523"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2546"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2755"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2774"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2852"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2871"/>
        <source>异常输出</source>
        <translation type="unfinished">Abnormal output</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1685"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1704"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1832"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1853"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2009"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2030"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2286"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2479"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2497"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2523"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2546"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2755"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2774"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2852"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2871"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished">Abnormal query data, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1808"/>
        <source>格式校验错误</source>
        <translation type="unfinished">Format verification error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="1808"/>
        <source>基础应用名称不可输入中文</source>
        <translation type="unfinished">The basic application name cannot be in Chinese</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2278"/>
        <source>长度超限，名称限制为63个字符</source>
        <translation type="unfinished">Length exceeded, name is limited to 63 characters</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2339"/>
        <source>配置所属实时库重复</source>
        <translation type="unfinished">Duplicate Config of Assigned TDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2422"/>
        <source>配置进程名称重复</source>
        <translation type="unfinished">The process name is duplicated in the config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2438"/>
        <source>启动稳定时间设置范围为0-1800</source>
        <translation type="unfinished">The startup stabilization time setting range is 0-1800</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2446"/>
        <source>启动次序设置范围为0-255</source>
        <translation type="unfinished">The startup sequence setting range is 0-255</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2459"/>
        <source>%1不能为空</source>
        <translation type="unfinished">%1 cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2515"/>
        <source>程序路径</source>
        <translation type="unfinished">Program path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2538"/>
        <source>长度超限，命令行参数限制为63个字符</source>
        <translation type="unfinished">Length exceeded, command line argument is limited to 63 characters.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2798"/>
        <source>系统类型名称重复</source>
        <translation type="unfinished">Duplicate system type names</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="2990"/>
        <source>名称重复</source>
        <translation type="unfinished">Duplicate name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="3240"/>
        <source>修改“实时库名称”，需要停止所有使用该实时库名称的应用</source>
        <translation type="unfinished">To modify &apos;RTDB name&apos;, stop it on all nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="3255"/>
        <source>修改“基础应用名称”，需要停止所有节点的该应用</source>
        <translation type="unfinished">To modify &apos;Basic App name&apos;, stop it on all nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="3270"/>
        <source>修改“进程名称”，需要停止所有节点的该应用</source>
        <translation type="unfinished">To modify &apos;Process name&apos;, stop it on all nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="3286"/>
        <source>修改“进程路径”，需要停止所有节点的该应用</source>
        <translation type="unfinished">To modify &apos;Process path&apos;, stop it on all nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="3305"/>
        <source>修改“是否维护进程”，需要停止所有节点的该维护应用及运行应用</source>
        <translation type="unfinished">To modify &apos;Maintain process&apos;, stop its maintenance app and its running app on all nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="3329"/>
        <source>修改“是否维护库”，需要停止维护应用</source>
        <translation type="unfinished">To modify &apos;M-RTDB&apos;, stop the maintenance app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="3341"/>
        <source>是否停应用</source>
        <translation type="unfinished">Stop app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="3594"/>
        <source>正在获取停止应用，请稍候...</source>
        <translation type="unfinished">Getting stop application, please wait...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="3594"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="3621"/>
        <source>停止节点应用成功</source>
        <translation type="unfinished">Stop node App successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/widget/right_sysconfig_info_table.cpp" line="3625"/>
        <source>取消停止节点应用</source>
        <translation type="unfinished">Unstop the node App</translation>
    </message>
</context>
<context>
    <name>SysConfigMainWidget</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="198"/>
        <source>基础信息</source>
        <translation type="unfinished">Basic Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="215"/>
        <source>运维管理相关实时库</source>
        <translation type="unfinished">Sysops related TDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="228"/>
        <source>运维管理相关服务进程</source>
        <translation type="unfinished">Sysops related service processes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="197"/>
        <source>基础信息</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Basic Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="214"/>
        <source>运维管理实时库</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Sysops TDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="227"/>
        <source>运维管理服务进程</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Sysops Process</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="243"/>
        <source>运维管理模块配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Sysops Module</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="244"/>
        <source>运维管理相关模块配置</source>
        <translation type="unfinished">Sysops related modules</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="248"/>
        <source>通用配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">General Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="249"/>
        <source>通用配置</source>
        <translation type="unfinished">General config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="325"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="325"/>
        <source>启动顺序暂未实现</source>
        <translation type="unfinished">Boot sequence is not yet implemented</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="337"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="363"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="380"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="421"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="438"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="509"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="337"/>
        <source>获取系统类型失败</source>
        <translation type="unfinished">Failed to retrieve system type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="363"/>
        <source>获取实时库定义失败</source>
        <translation type="unfinished">Failed to retrieve TDB definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="380"/>
        <source>获取应用定义失败</source>
        <translation type="unfinished">Failed to retrieve application definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="421"/>
        <source>获取应用集合失败</source>
        <translation type="unfinished">Failed to retrieve application collection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="438"/>
        <source>获取应用集合下的应用失败</source>
        <translation type="unfinished">Failed to retrieve the applications under the application collection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="463"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="485"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="463"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="485"/>
        <source>%1存在更改,请检查!</source>
        <translation type="unfinished">%1 has changes, please check!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_mainwidget.cpp" line="509"/>
        <source>获取表信息失败</source>
        <translation type="unfinished">Failed to retrieve table info</translation>
    </message>
</context>
<context>
    <name>SysConfigPlugin</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_plugin.cpp" line="116"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_plugin.cpp" line="125"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_plugin.cpp" line="116"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_sysconfig/src/sysconfig_plugin.cpp" line="125"/>
        <source>%1存在修改项!</source>
        <translation type="unfinished">Modifications exist in %1!</translation>
    </message>
</context>
</TS>
