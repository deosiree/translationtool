<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>GuiSmartSetupTool</name>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="111"/>
        <source>初始化失败，请检查配置后重试</source>
        <translation type="unfinished">Initialization failed. Please check the config and try again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="311"/>
        <source>连接地址：</source>
        <translation type="unfinished">Connection address:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="319"/>
        <source>本地连接</source>
        <translation type="unfinished">Local connection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="340"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="471"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="543"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="641"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="706"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="363"/>
        <source>节点名称：</source>
        <translation type="unfinished">Node name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="369"/>
        <source>系统名称：</source>
        <translation type="unfinished">System name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="404"/>
        <source>A网地址 ：</source>
        <translation type="unfinished">Net A address:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="407"/>
        <source>B网地址 ：</source>
        <translation type="unfinished">Net B address:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="423"/>
        <source>IP信息：</source>
        <translation type="unfinished">IP info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="424"/>
        <source>修改记录</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Edit record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="444"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3566"/>
        <source>新增IP</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add ip</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="445"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3567"/>
        <source>删除IP</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete ip</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="447"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3569"/>
        <source>网口备注：</source>
        <translation type="unfinished">Remarks of net interface:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="472"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="544"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="642"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="707"/>
        <source>应用</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Apply</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="493"/>
        <source>工具界面：</source>
        <translation type="unfinished">Tool interface:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="495"/>
        <source>操作系统：</source>
        <translation type="unfinished">Operating system:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="497"/>
        <source>后台服务：</source>
        <translation type="unfinished">Back-up services:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="515"/>
        <source>本地平台界面语言设置，需重启本地gui_manager</source>
        <translation type="unfinished">The language setting of the local platform interface requires restarting the local gui_manager</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="519"/>
        <source>本地操作系统语言设置，需重启本地操作系统</source>
        <translation type="unfinished">Local operating system language settings require a restart of the local operating system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="523"/>
        <source>本现场后台服务语言部署，在线修改</source>
        <translation type="unfinished">On site backend service language deployment, online modification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="607"/>
        <source>历史库类型：</source>
        <translation type="unfinished">HDB type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="622"/>
        <source>备注：现场所有系统停止到核心进程后生效，并将清理和重建历史库</source>
        <translation type="unfinished">Note: All systems on site will take effect after the core process is stopped, and the HDB will be cleaned up and rebuilt</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="688"/>
        <source>新增节点</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="678"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1578"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3072"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3176"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3242"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3292"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3481"/>
        <source>以本现场节点为模板</source>
        <translation type="unfinished">Use on-site node as a template</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="682"/>
        <source>部署提示：原则1现场节点数量不少于模板节点 原则2模板都需要被选择且不重复</source>
        <translation type="unfinished">Deployment Tip: Principle 1: The number of on-site nodes should not be less than the template nodes. Principle 2: Templates need to be selected and not duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="689"/>
        <source>删除节点</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="695"/>
        <source>选择模板来源：</source>
        <translation type="unfinished">Select template source:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="771"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3601"/>
        <source>平台版本信息：暂无</source>
        <translation type="unfinished">Platform version Info: temporarily unavailable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="775"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3605"/>
        <source>平台版本:</source>
        <translation type="unfinished">Plat version:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="885"/>
        <source>配置校验......</source>
        <translation type="unfinished">Config check ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="890"/>
        <source>AB网地址错误，无法上传</source>
        <translation type="unfinished">Net A/B address error, unable to upload</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="986"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="995"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1006"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1020"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1026"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1040"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1077"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1222"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1291"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1295"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1301"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1304"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1309"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1346"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1353"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1558"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1666"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1714"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1784"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1827"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1884"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1913"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1930"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1971"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1975"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2019"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2033"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2046"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2059"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2072"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3058"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3364"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3611"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3614"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4050"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4094"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4157"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="995"/>
        <source>当前将多个网口设置网关，可能影响默认路由</source>
        <translation type="unfinished">Gateways are configured for multiple net ports, which may affect the default route</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="997"/>
        <source>是否继续修改</source>
        <translation type="unfinished">Whether to continue modifying</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1006"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1668"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1932"/>
        <source>节点名应为任意小写字母、数字和连字符组合</source>
        <translation type="unfinished">The node name should be any combination of lowercase letters, numbers, and hyphens</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1008"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1669"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1933"/>
        <source>(连字符不能在开头或结尾)</source>
        <translation type="unfinished">(The hyphen cannot be at the beginning or end)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1010"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1030"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1669"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1933"/>
        <source>且最大长度为31个字符</source>
        <translation type="unfinished">And the maximum length is 31 characters</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1026"/>
        <source>系统名应为任意字母、数字、连字符和下划线组合</source>
        <translation type="unfinished">The system name should be any combination of letters, numbers, hyphens, and base lines</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1028"/>
        <source>(开头或结尾不能为符号)</source>
        <translation type="unfinished">(The beginning or end cannot be a symbol)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1034"/>
        <source>校验完成......</source>
        <translation type="unfinished">Checked</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1040"/>
        <source>平台正在运行，是否停止平台以应用修改</source>
        <translation type="unfinished">The platform is running. Whether to stop the platform to apply modifications</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1042"/>
        <source>(此操作会自动重启设备)</source>
        <translation type="unfinished">(This operation will restart the device)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1048"/>
        <source>停止平台中......</source>
        <translation type="unfinished">Stopping the platform 	</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1067"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1071"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1326"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1570"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1589"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1595"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1606"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1616"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1648"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1658"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1677"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1707"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1755"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1769"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1922"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4191"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1067"/>
        <source>平台停止命令执行失败，请重试</source>
        <translation type="unfinished">Platform stop command execution failed, please try again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1071"/>
        <source>停止超时，请重试</source>
        <translation type="unfinished">Stop timeout, please try again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1077"/>
        <source>配置后会自动重启设备，是否继续</source>
        <translation type="unfinished">After config, the device will restart. Continue?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1083"/>
        <source>配置中......</source>
        <translation type="unfinished">Configuring</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1103"/>
        <source>网口备注设置失败</source>
        <translation type="unfinished">Failed to set net port remarks</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1094"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1110"/>
        <source>系统名称配置失败</source>
        <translation type="unfinished">Failed to set system name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1125"/>
        <source>配置节点名称失败</source>
        <translation type="unfinished">Failed to configure node name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1144"/>
        <source>ABC网配置失败</source>
        <translation type="unfinished">Failed to set ABC net</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1162"/>
        <source>IP配置失败</source>
        <translation type="unfinished">IP config failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1195"/>
        <source>配置修改失败，请重试</source>
        <translation type="unfinished">Failed to config, please try again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1198"/>
        <source>修改成功，重启机器......</source>
        <translation type="unfinished">If the modification is successful, restart the machine......</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1291"/>
        <source>配置后台服务语言失败</source>
        <translation type="unfinished">Failed to configure backend service language</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1295"/>
        <source>配置工具界面语言失败</source>
        <translation type="unfinished">Failed to configure tool interface language</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1301"/>
        <source>配置操作系统语言失败</source>
        <translation type="unfinished">Failed to configure operating system language</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1304"/>
        <source>配置语言成功</source>
        <translation type="unfinished">Language Config succeeded</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1309"/>
        <source>配置语言成功,将立即重启</source>
        <translation type="unfinished">Language config successful, will restart immediately</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1365"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1388"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1420"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1434"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1466"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1635"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1365"/>
        <source>初始化Sysmdl失败</source>
        <translation type="unfinished">Failed to initialize Sysmdl</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1398"/>
        <source>失败</source>
        <translation type="unfinished">Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1388"/>
        <source>查找部署历史库服务的节点失败</source>
        <translation type="unfinished">Failed to search for nodes in the deployment HDB service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1398"/>
        <source>当前没有部署历史库服务的节点，不执行切库</source>
        <translation type="unfinished">No nodes with HDB service deployed. Skip DB partition.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1449"/>
        <source>正在停止节点非核心进程:</source>
        <translation type="unfinished">Stopping the non-core processes of the node:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1462"/>
        <source>节点停止成功</source>
        <translation type="unfinished">Node stopped successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1465"/>
        <source>节点停止失败</source>
        <translation type="unfinished">Node stop failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1466"/>
        <source>切库失败，节点%1停止失败</source>
        <translation type="unfinished">DB cutting failed, node %1 failed to stop</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1476"/>
        <source>正在清理、重建数据库: %p%</source>
        <translation type="unfinished">Cleaning and rebuilding db: %p %</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1536"/>
        <source>超时</source>
        <translation type="unfinished">timeout</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1538"/>
        <source>清理旧数据库90s内未完成，是否继续等待</source>
        <translation type="unfinished">The old db cleaning has not been completed in 90 seconds. Whether to continue waiting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1538"/>
        <source>(若取消需稍后重新设置)</source>
        <translation type="unfinished">(If cancelled, reset later)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="986"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1540"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1558"/>
        <source>库类型已切换</source>
        <translation type="unfinished">DB type has been switched</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1570"/>
        <source>请选择一个模板并部署对应节点</source>
        <translation type="unfinished">Please select a template and deploy the corresponding node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1589"/>
        <source>来源节点选择重复</source>
        <translation type="unfinished">Duplicate source node selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1595"/>
        <source>存在模板节点未选择</source>
        <translation type="unfinished">Template node not selected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1606"/>
        <source>本节点未选模板，请选择</source>
        <translation type="unfinished">No template is selected for this node. Please make a selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1616"/>
        <source>当前存在节点未选模板</source>
        <translation type="unfinished">Nodes without template selected.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1658"/>
        <source>现场节点名不能为空</source>
        <translation type="unfinished">On-site node name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1677"/>
        <source>现场节点名称重复</source>
        <translation type="unfinished">Duplicate on-site node names</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1714"/>
        <source>模板校验通过，请确认停止所有节点的非核心进程(等待中途请勿操作)</source>
        <translation type="unfinished">Template verification passed, please confirm to stop all non core processes of nodes (do not operate while waiting)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1755"/>
        <source>停止非核心进程失败,请检查后重试</source>
        <translation type="unfinished">Failed to stop non-core processes. Please check and try again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1769"/>
        <source>更新系统部署失败</source>
        <translation type="unfinished">Failed to update system deployment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1778"/>
        <source>系统部署完成,等待重启</source>
        <translation type="unfinished">System deployment completed, waiting for restart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1784"/>
        <source>系统部署成功，请确认重启部署节点系统</source>
        <translation type="unfinished">System deployment successful, please confirm to restart the deployment node system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1789"/>
        <source>重启</source>
        <translation type="unfinished">Restart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1793"/>
        <source>节点%1重启失败，请手动重启</source>
        <translation type="unfinished">Node %1 failed to restart, please manually restart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1845"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4113"/>
        <source>已启动</source>
        <translation type="unfinished">Started</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1847"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4115"/>
        <source>平台已启动，正在启动应用</source>
        <translation type="unfinished">Platform has started. Starting the application...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1849"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4117"/>
        <source>正在启动</source>
        <translation type="unfinished">Is starting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1851"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4119"/>
        <source>系统未启动</source>
        <translation type="unfinished">System not started</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1853"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4121"/>
        <source>系统正在退出</source>
        <translation type="unfinished">System is exiting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1880"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4147"/>
        <source>重启成功</source>
        <translation type="unfinished">Restart successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1884"/>
        <source>在线节点重启成功，系统部署完成</source>
        <translation type="unfinished">Online node restart successfully, system deployment completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1896"/>
        <source>获取待重启节点失败，请重试</source>
        <translation type="unfinished">Failed to retrieve the node to be restarted, please try again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1913"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1971"/>
        <source>请先新增节点</source>
        <translation type="unfinished">Please add a new node first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1948"/>
        <source>，错误详情：</source>
        <translation type="unfinished">, error details:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1953"/>
        <source>新增节点%1成功，模板%2</source>
        <translation type="unfinished">Successfully added node %1, template %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1959"/>
        <source>新增节点执行结束</source>
        <translation type="unfinished">Add node execution completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3297"/>
        <source>注意</source>
        <translation type="unfinished">Attention</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3297"/>
        <source>无法删除现场节点部署</source>
        <translation type="unfinished">Unable to delete on-site node deployment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3996"/>
        <source>清理初始化库成功，等待切换库类型</source>
        <translation type="unfinished">Cleared initialization DB successfully, waiting to switch DB types</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4002"/>
        <source>清理初始化库失败，请人工介入！</source>
        <translation type="unfinished">Cleaning initialization DB failed, please intervene manually!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4023"/>
        <source>---清理初始化库结束，成功%1个节点，失败%2个节点</source>
        <translation type="unfinished">---Cleaning initialization db completed, successful %1 nodes, failed %2 nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4152"/>
        <source>重启节点成功</source>
        <translation type="unfinished">Nod restart successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1886"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4160"/>
        <source>本次操作执行结束，请确认关闭工具</source>
        <translation type="unfinished">This operation has been completed. Please confirm to close the tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4174"/>
        <source>重启节点失败</source>
        <translation type="unfinished">Failed to restart node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4175"/>
        <source>重启失败请重试</source>
        <translation type="unfinished">Restart failed, please try again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1922"/>
        <source>节点名称不可为空</source>
        <translation type="unfinished">Node name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1860"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1869"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4128"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4136"/>
        <source>等待启动</source>
        <translation type="unfinished">Wait for startup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1947"/>
        <source>新增节点%1失败</source>
        <translation type="unfinished">Failed to add node %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1975"/>
        <source>当前配置已部署</source>
        <translation type="unfinished">The current config has been deployed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4159"/>
        <source>在线节点系统启动成功，数据库类型切换完成</source>
        <translation type="unfinished">Online node system has been successfully started, and the db type switch has been completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="737"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="860"/>
        <source>网络地址</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Net Address</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="90"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="100"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="300"/>
        <source>环境配置工具</source>
        <comment>toolName</comment>
        <translation type="unfinished">Environment Config Tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="568"/>
        <source>高级</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Advanced</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="559"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="574"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3392"/>
        <source>收起</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Collapse</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="738"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1226"/>
        <source>语言类型</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Language Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="739"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1340"/>
        <source>数据库类型</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">DB Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="740"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="760"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1565"/>
        <source>系统部署</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Deployment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="742"/>
        <source>维护库切换</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">MTDB Switch</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="896"/>
        <source>存在AB网未选，是否继续</source>
        <translation type="unfinished">Net A/B is not selected, whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1222"/>
        <source>系统已重启，请退出工具</source>
        <translation type="unfinished">The system has been restarted, please exit the tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1326"/>
        <source>平台停止超时，请重试</source>
        <translation type="unfinished">Platform stop timeout, please try again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1346"/>
        <source>未查询到历史库类型，请检查或刷新</source>
        <translation type="unfinished">No HDB type found, please check or refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1353"/>
        <source>此操作将会清空旧库数据并重启本现场节点，是否继续</source>
        <translation type="unfinished">This operation will clear the old db data and restart the on-site node. Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1420"/>
        <source>切库失败，请确认部署历史库服务的节点在线</source>
        <translation type="unfinished">Switching db failed. Please check if the node where the HDB service is deployed is online.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1434"/>
        <source>切库失败，存在未完全启动的节点，请稍候重试</source>
        <translation type="unfinished">Switching db failed. Some deployment nodes are not fully operational yet. Please try again later.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1619"/>
        <source>节点会根据配置文件调整，新增或删除,是否继续</source>
        <translation type="unfinished">Nodes will be adjusted, added or deleted according to the config file. Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1635"/>
        <source>部署失败，存在未完全启动的节点，请稍候重试</source>
        <translation type="unfinished">Deploy failed: nodes not fully started. Wait &amp; retry.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1707"/>
        <source>应用失败，当前部署的状态未通过检查</source>
        <translation type="unfinished">Application failed, the current deployment status did not pass the check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1883"/>
        <source>系统部署完成</source>
        <translation type="unfinished">System deployment completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2019"/>
        <source>网络地址的修改未应用，</source>
        <translation type="unfinished">The modification of the net address has not been applied,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2021"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2035"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2048"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2061"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2074"/>
        <source>是否仍要退出</source>
        <translation type="unfinished">Whether to quit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2021"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2035"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2048"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2061"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2074"/>
        <source>退出</source>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2033"/>
        <source>语言类型的修改未应用，</source>
        <translation type="unfinished">The modification of language type has not been applied,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2046"/>
        <source>数据库类型的修改未应用，</source>
        <translation type="unfinished">The modification of the db type was not applied.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2059"/>
        <source>系统部署的修改未应用，</source>
        <translation type="unfinished">The modifications to the system deployment have not been applied,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2072"/>
        <source>维护库切换的修改未应用，</source>
        <translation type="unfinished">The modification for MTDB switch has not been applied.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2093"/>
        <source>IP地址</source>
        <translation type="unfinished">IP address</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2094"/>
        <source>子网掩码</source>
        <translation type="unfinished">Subnet mask</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="932"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2097"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2149"/>
        <source>网关</source>
        <translation type="unfinished">Gateway</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="380"/>
        <source>节点类型：</source>
        <translation type="unfinished">Node type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="383"/>
        <source>工作站</source>
        <translation type="unfinished">Workstation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="383"/>
        <source>服务器</source>
        <translation type="unfinished">Server</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="951"/>
        <source>网址重复：%1</source>
        <translation type="unfinished">Duplicate URL: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="954"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="967"/>
        <source>网口 %1，行 %2</source>
        <translation type="unfinished">Net port %1, line %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="964"/>
        <source>网段重复：%1</source>
        <translation type="unfinished">Duplicate net segment:%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="976"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="976"/>
        <source>当前存在未填IP/掩码</source>
        <translation type="unfinished">IP/Mask unfilled.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="986"/>
        <source>存在重复IP或网段</source>
        <translation type="unfinished">Duplicate IPs/net segments.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="986"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1020"/>
        <source>节点不允许与现有节点名称重复</source>
        <translation type="unfinished">Nodes are not allowed to have duplicate names with existing nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1648"/>
        <source>现场节点必须大于等于模板中的节点数</source>
        <translation type="unfinished">The number of on-site nodes must be greater than or equal to the number of nodes in the template</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1829"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4096"/>
        <source>%1重启进程异常</source>
        <translation type="unfinished">%1 restart process exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="1830"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4097"/>
        <source>执行超时，请确认关闭工具</source>
        <translation type="unfinished">Execution timeout, please confirm to close the tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2355"/>
        <source>读取历史记录失败</source>
        <translation type="unfinished">Failed to read history</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2785"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2959"/>
        <source>空</source>
        <translation type="unfinished">Null</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2804"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="2984"/>
        <source>不使用</source>
        <translation type="unfinished">Not used</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3058"/>
        <source>获取本地节点失败</source>
        <translation type="unfinished">Failed to retrieve local node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3095"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3145"/>
        <source>详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3101"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3151"/>
        <source>应用详情展示</source>
        <translation type="unfinished">Application details display</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3111"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3162"/>
        <source>(维护应用)</source>
        <translation type="unfinished">(Maintenance application)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3348"/>
        <source>正在获取数据......</source>
        <translation type="unfinished">Getting data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3356"/>
        <source>刷新中......</source>
        <translation type="unfinished">Refreshing...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3364"/>
        <source>远程断开连接，请重新连接</source>
        <translation type="unfinished">Remote disconnection, please reconnect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3611"/>
        <source>节点名称获取失败</source>
        <translation type="unfinished">Failed to retrieve node name </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3614"/>
        <source>AB网获取失败</source>
        <translation type="unfinished">Failed to retrieve Net A/B</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3648"/>
        <source>节点名称修改记录</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node name modification record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3659"/>
        <source>原名称</source>
        <translation type="unfinished">Original name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3659"/>
        <source>现名称</source>
        <translation type="unfinished">Site name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3659"/>
        <source>平台确认</source>
        <translation type="unfinished">Platform validation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3659"/>
        <source>监控确认</source>
        <translation type="unfinished">Monitor validation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3682"/>
        <source>网络信息修改记录</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Net info modification record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3688"/>
        <source>网口</source>
        <translation type="unfinished">Net interface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3688"/>
        <source>原网络信息</source>
        <translation type="unfinished">Original net info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3688"/>
        <source>现网络信息(重启生效)</source>
        <translation type="unfinished">Current net info (Effective after restart)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3728"/>
        <source>现场节点</source>
        <translation type="unfinished">On-site nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3728"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3742"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3746"/>
        <source>模板节点</source>
        <translation type="unfinished">Template node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3742"/>
        <source>描述</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3742"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3746"/>
        <source>应用详情</source>
        <translation type="unfinished">Application details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3987"/>
        <source>节点-</source>
        <translation type="unfinished">Node-</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="3996"/>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4002"/>
        <source>节点</source>
        <translation type="unfinished">node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4032"/>
        <source>---切换库%1操作失败，请人工介入！</source>
        <translation type="unfinished">---Switching DB %1 operation failed, please intervene manually!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4038"/>
        <source>---切换库%1操作成功，等待重启</source>
        <translation type="unfinished">---Switching DB %1 operation successful, waiting for restart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4046"/>
        <source>所有节点系统重启</source>
        <translation type="unfinished">Restart all node systems</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4047"/>
        <source>正在重启节点</source>
        <translation type="unfinished">Restarting node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4050"/>
        <source>数据库类型切换结束，即将重启所有节点系统</source>
        <translation type="unfinished">The db type switch has ended and all node systems will be restarted soon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4100"/>
        <source>状态异常</source>
        <translation type="unfinished">Abnormal status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="4191"/>
        <source>切库操作中断，清理初始化库失败</source>
        <translation type="unfinished">Change db type interrupted and cleaning &amp; initializing db failed</translation>
    </message>
</context>
<context>
    <name>ToolIPTableDelegate</name>
    <message>
        <location filename="../../../../src/plat/tool/gui/gui_smart_setup_tool/gui_smart_setup_tool.cpp" line="57"/>
        <source> 字节</source>
        <translation type="unfinished">Byte</translation>
    </message>
</context>
</TS>
