<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="110"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="1054"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="1071"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="110"/>
        <source>注册失败</source>
        <translation type="unfinished">Reg failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="1113"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="193"/>
        <source>开始时间：</source>
        <translation type="unfinished">Start time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="204"/>
        <source>结束时间：</source>
        <translation type="unfinished">End time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="171"/>
        <source>节点：</source>
        <translation type="unfinished">Node:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="233"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="708"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="952"/>
        <source>失败</source>
        <translation type="unfinished">Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="234"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="716"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="729"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="960"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="973"/>
        <source>进行中</source>
        <translation type="unfinished">In progress</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="235"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="720"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="734"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="964"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="979"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="220"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="236"/>
        <source>全部</source>
        <translation type="unfinished">All</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="214"/>
        <source>操作类型：</source>
        <translation type="unfinished">Operation type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="220"/>
        <source>上传文件</source>
        <translation type="unfinished">Upload file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="220"/>
        <source>申请文件版本号</source>
        <translation type="unfinished">Application file version number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="220"/>
        <source>执行上传文件</source>
        <translation type="unfinished">Upload file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="220"/>
        <source>删除文件</source>
        <translation type="unfinished">Delete file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="221"/>
        <source>删除文件版本</source>
        <translation type="unfinished">Delete file version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="221"/>
        <source>修改文件名</source>
        <translation type="unfinished">Rename file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="221"/>
        <source>移动文件</source>
        <translation type="unfinished">Move file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="221"/>
        <source>冻结文件版本</source>
        <translation type="unfinished">Freeze file version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="221"/>
        <source>锁定文件</source>
        <translation type="unfinished">Lock file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="221"/>
        <source>同步文件</source>
        <translation type="unfinished">sync files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="222"/>
        <source>修改文件描述</source>
        <translation type="unfinished">Modify file description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="222"/>
        <source>获取文件列表</source>
        <translation type="unfinished">Get file list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="222"/>
        <source>下载文件</source>
        <translation type="unfinished">Download file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="222"/>
        <source>获取文件信息</source>
        <translation type="unfinished">Retrieve file info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="223"/>
        <source>创建目录</source>
        <translation type="unfinished">Create dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="223"/>
        <source>删除目录</source>
        <translation type="unfinished">Delete dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="223"/>
        <source>改名目录</source>
        <translation type="unfinished">Change dir name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="223"/>
        <source>移动目录</source>
        <translation type="unfinished">Move dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="223"/>
        <source>打包目录</source>
        <translation type="unfinished">Packaging dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="223"/>
        <source>获得目录树</source>
        <translation type="unfinished">Get dir tree</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="224"/>
        <source>解包目录</source>
        <translation type="unfinished">Unpacking dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="224"/>
        <source>批量发布</source>
        <translation type="unfinished">batch publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="224"/>
        <source>批量发布执行</source>
        <translation type="unfinished">Batch publishing execution</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="228"/>
        <source>执行结果：</source>
        <translation type="unfinished">Execution Result:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="243"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="268"/>
        <source>运行文件同步列表</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Run File Sync List</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="277"/>
        <source>配置文件同步列表</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Config Sync File List</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="292"/>
        <source>搜索内容</source>
        <translation type="unfinished">Search content</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="390"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="425"/>
        <source>请求方</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Requester</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="390"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="425"/>
        <source>请求时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Request time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="390"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="425"/>
        <source>操作类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Operation type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="390"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="425"/>
        <source>执行结果</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Execution Result</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="390"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="425"/>
        <source>操作详情</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Operation details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="465"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="497"/>
        <source>查询中......请等待</source>
        <translation type="unfinished">Querying...Please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="1054"/>
        <source>查询结束</source>
        <translation type="unfinished">Query completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="543"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="776"/>
        <source>数据库连接失败</source>
        <translation type="unfinished">DB connection failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="283"/>
        <source>搜索</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="287"/>
        <source>过滤</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="535"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="767"/>
        <source>重新选择时间范围</source>
        <translation type="unfinished">Reselect the time frame</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="740"/>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="986"/>
        <source>请求</source>
        <translation type="unfinished">request</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_operation_monitor/mainwindow.cpp" line="1113"/>
        <source>起始时间错误</source>
        <translation type="unfinished">Start time error</translation>
    </message>
</context>
</TS>
