<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>DifferentWid</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/differentWid.cpp" line="66"/>
        <source>错误信息</source>
        <translation type="unfinished">Error message</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.ui" line="39"/>
        <source>数据源：</source>
        <translation type="unfinished">Data source:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.ui" line="59"/>
        <source>源节点：</source>
        <translation type="unfinished">Source node:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.ui" line="90"/>
        <source>源目录：</source>
        <translation type="unfinished">Source dir:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.ui" line="155"/>
        <source>目标节点：</source>
        <translation type="unfinished">Dest node:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.ui" line="200"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.ui" line="213"/>
        <source>源对象</source>
        <translation type="unfinished">source object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.ui" line="227"/>
        <source>目标对象</source>
        <translation type="unfinished">dest object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="28"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="705"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="712"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="731"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="736"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="781"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="788"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="966"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1551"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="28"/>
        <source>无系统模式</source>
        <translation type="unfinished">No system mode</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="273"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="959"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1535"/>
        <source>错误信息</source>
        <translation type="unfinished">Error message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="302"/>
        <source>离线</source>
        <translation type="unfinished">offline</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="307"/>
        <source>值班</source>
        <comment>Lower</comment>
        <translation type="unfinished">duty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="311"/>
        <source>备用</source>
        <comment>Lower</comment>
        <translation type="unfinished">backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="319"/>
        <source>离线</source>
        <comment>Lower</comment>
        <translation type="unfinished">offline</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="324"/>
        <source>值班</source>
        <translation type="unfinished">Duty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="328"/>
        <source>备用</source>
        <translation type="unfinished">backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="516"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="551"/>
        <source>查询中......请等待</source>
        <translation type="unfinished">Querying...Please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="705"/>
        <source>查询结束</source>
        <translation type="unfinished">Query completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="705"/>
        <source>%1文件：%2</source>
        <translation type="unfinished">%1 File: %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1161"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1346"/>
        <source>文件名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">File name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1161"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1346"/>
        <source>文件大小[B]</source>
        <comment>subTitle</comment>
        <translation type="unfinished">File size[B]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1161"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1346"/>
        <source>修改时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Modification time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1161"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1346"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1161"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1346"/>
        <source>是否为目录</source>
        <comment>subTitle</comment>
        <translation type="unfinished">DIR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1195"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1382"/>
        <source>差异</source>
        <comment>menuName</comment>
        <translation type="unfinished">Difference</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1197"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1384"/>
        <source>同步</source>
        <comment>menuName</comment>
        <translation type="unfinished">Sync</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1198"/>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1385"/>
        <source>一键到本地</source>
        <comment>menuName</comment>
        <translation type="unfinished">One-click to local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="1551"/>
        <source>刷新完成</source>
        <translation type="unfinished">Refresh completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="731"/>
        <source>源/目标各选一个</source>
        <translation type="unfinished">Select one source/destination</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="736"/>
        <source>需相同文件名进行比较</source>
        <translation type="unfinished">Compare with the same file name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="781"/>
        <source>两者无差异</source>
        <translation type="unfinished">No difference</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="788"/>
        <source>有差异，可选择同步</source>
        <translation type="unfinished">If there are differences, you can choose to synchronize</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="941"/>
        <source>同步中......请等待</source>
        <translation type="unfinished">Syncing... Please wait</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/mainwindow.cpp" line="966"/>
        <source>同步成功</source>
        <translation type="unfinished">Sync successful</translation>
    </message>
</context>
<context>
    <name>noticeWid</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_manage_sync/noticeWid.cpp" line="9"/>
        <source>信息</source>
        <comment>toolName</comment>
        <translation type="unfinished">Info</translation>
    </message>
</context>
</TS>
