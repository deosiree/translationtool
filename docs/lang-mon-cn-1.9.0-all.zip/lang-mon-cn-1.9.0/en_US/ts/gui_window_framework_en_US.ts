<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>GraphWindowBase</name>
    <message>
        <location filename="../../../../src/plat/gui/api/gui_window_framework/graphic_base_window.cpp" line="217"/>
        <source>切换用户</source>
        <translation type="unfinished">Switch User</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/gui_window_framework/graphic_base_window.cpp" line="218"/>
        <source>请确认</source>
        <translation type="unfinished">Please confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/gui_window_framework/graphic_base_window.cpp" line="247"/>
        <source> 登录时限：</source>
        <translation type="unfinished">Login time limit:</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/gui/api/gui_window_framework/mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished">MainWindow</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/gui_window_framework/mainwindow.ui" line="24"/>
        <source>一键顺控切换用户测试按钮</source>
        <comment>buttonName</comment>
        <translation type="unfinished">One-click sequential control switch user testing button</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/gui_window_framework/mainwindow.ui" line="31"/>
        <source>输入用户名</source>
        <translation type="unfinished">Enter user name</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/api/gui_window_framework/graphic_base_window.cpp" line="443"/>
        <source>参数解析失败</source>
        <comment>gui_integrate::main</comment>
        <translation type="unfinished">Params parsing failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/gui_window_framework/graphic_base_window.cpp" line="445"/>
        <source>请检查</source>
        <comment>gui_integrate::main</comment>
        <translation type="unfinished">Please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/gui_window_framework/graphic_base_window.cpp" line="446"/>
        <source>确定</source>
        <comment>gui_integrate::main</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
</context>
</TS>
