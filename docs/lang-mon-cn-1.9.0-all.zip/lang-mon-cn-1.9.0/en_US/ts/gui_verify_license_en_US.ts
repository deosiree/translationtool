<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>DlgVerifyLicense</name>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="40"/>
        <source>请输入机器码</source>
        <translation type="unfinished">Please enter the machine code</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="78"/>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="85"/>
        <source>注册码验证工具</source>
        <translation type="unfinished">Reg Code Verification Tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="151"/>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="156"/>
        <source>%1</source>
        <translation type="unfinished"> %1 </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="181"/>
        <source>永久有效</source>
        <translation type="unfinished">Permanently valid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="188"/>
        <source>验证成功</source>
        <translation type="unfinished">Validated successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="197"/>
        <source>失败</source>
        <translation type="unfinished">Fail</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="197"/>
        <source>写入文件失败!</source>
        <translation type="unfinished">Failed to write file!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="197"/>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="228"/>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="243"/>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="255"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="202"/>
        <source>注册码错误!</source>
        <translation type="unfinished">Wrong reg code!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="206"/>
        <source>时间超限!</source>
        <translation type="unfinished">Time limit exceeded!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="210"/>
        <source>机器码不对应!</source>
        <translation type="unfinished">The machine code does not match!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="214"/>
        <source>程序错误!</source>
        <translation type="unfinished">Program error!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="228"/>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="243"/>
        <source>生成失败</source>
        <translation type="unfinished">Failed to gen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="228"/>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="243"/>
        <source>注册文件生成失败</source>
        <translation type="unfinished">Failed to gen reg file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="247"/>
        <source>注册文件成功保存到%1</source>
        <translation type="unfinished">Reg file saved to %1 successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="252"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="253"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="78"/>
        <source>(节点名:</source>
        <translation type="unfinished">(Node:</translation>
    </message>
</context>
<context>
    <name>dlg_verify_license</name>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="40"/>
        <source>验证区</source>
        <translation type="unfinished">Verification area</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="50"/>
        <source>机器码:</source>
        <translation type="unfinished">Machine code:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="60"/>
        <source>注册码：</source>
        <translation type="unfinished">Reg code:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="80"/>
        <source>生成注册文件</source>
        <translation type="unfinished">Gen reg file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="106"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="119"/>
        <source>验证</source>
        <translation type="unfinished">Verify</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="133"/>
        <source>验证结果</source>
        <translation type="unfinished">Verification results</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="213"/>
        <source>验证信息：</source>
        <translation type="unfinished">Verification info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="246"/>
        <source>版本号：</source>
        <translation type="unfinished">Version No.:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="260"/>
        <source>过期时间：</source>
        <translation type="unfinished">Expiration time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="274"/>
        <source>客户名称：</source>
        <translation type="unfinished">Customer name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="281"/>
        <source>产品名称：</source>
        <translation type="unfinished">Product name:</translation>
    </message>
</context>
</TS>
