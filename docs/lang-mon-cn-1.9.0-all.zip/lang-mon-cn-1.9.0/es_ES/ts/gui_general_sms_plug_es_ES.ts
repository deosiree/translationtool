<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="32"/>
        <source>设备管理</source>
        <translation type="unfinished">Gestión de equipos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="42"/>
        <source>设备名称：</source>
        <translation type="unfinished">Nombre de equipo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="56"/>
        <source>设备串口：</source>
        <translation type="unfinished">Puerto serie de equipo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="70"/>
        <source>中心号码：</source>
        <translation type="unfinished">Número central:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="80"/>
        <source>获取中心号码</source>
        <translation type="unfinished">Obtener número central</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="94"/>
        <source>人员管理</source>
        <translation type="unfinished">Gestión de personal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="24"/>
        <source>人员/设备管理</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Personal/Equipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="117"/>
        <source>导入用户列表</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Importar lista de usuarios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="124"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="198"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="131"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="205"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="158"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="232"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="175"/>
        <source>短信策略配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Política de SMS</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="244"/>
        <source>短信历史记录</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Historial de SMS</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="252"/>
        <source>查询条件</source>
        <translation type="unfinished">Condición de consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="262"/>
        <source>发送时间：</source>
        <translation type="unfinished">Hora de envío:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="279"/>
        <source>人员名称：</source>
        <translation type="unfinished">Nombre de persona:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="297"/>
        <source>角色类型：</source>
        <translation type="unfinished">Tipo de rol:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="311"/>
        <source>短信类型：</source>
        <translation type="unfinished">Tipo de SMS:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="325"/>
        <source>短信内容：</source>
        <translation type="unfinished">Contenido de SMS:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="342"/>
        <source>查询结果</source>
        <translation type="unfinished">Resultados de consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="365"/>
        <source>查询</source>
        <translation type="unfinished">Consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="385"/>
        <source>短信发送测试</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Prueba de SMS</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="425"/>
        <source>发送</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Enviar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="395"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="214"/>
        <source>短信类型</source>
        <translation type="unfinished">Tipo de SMS</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="127"/>
        <source>请输入短信测试内容</source>
        <translation type="unfinished">Ingrese el contenido de prueba del mensaje de texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="128"/>
        <source>请输入短信测试类型</source>
        <translation type="unfinished">Ingrese el tipo de prueba SMS</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="165"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="214"/>
        <source>人员名称</source>
        <translation type="unfinished">Nombre de persona</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="165"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="189"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="214"/>
        <source>角色</source>
        <translation type="unfinished">Rol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="165"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="214"/>
        <source>手机号</source>
        <translation type="unfinished">Teléfono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="165"/>
        <source>接收时间段</source>
        <translation type="unfinished">Período de recepción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="189"/>
        <source>类型</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="189"/>
        <source>短信特征</source>
        <translation type="unfinished">Característica de SMS</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="214"/>
        <source>短信内容</source>
        <translation type="unfinished">Contenido de SMS</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="214"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="214"/>
        <source>发送时间</source>
        <translation type="unfinished">Hora de envío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="245"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="246"/>
        <source>全部</source>
        <translation type="unfinished">Todos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="472"/>
        <source>用户：%1 接收时间段开始时间大于结束时间,请检查</source>
        <translation type="unfinished">Usuario: %1 El tiempo de inicio del período de recepción es mayor que el tiempo de finalización. Verifique</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="504"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="583"/>
        <source>%1 %2 %3 数据重复</source>
        <translation type="unfinished">%1 %2 %3 Datos está duplicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="508"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="520"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="587"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="599"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="870"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="875"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="883"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="916"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="964"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="974"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="1009"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="1024"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="520"/>
        <source>用户信息不全</source>
        <translation type="unfinished">La información del usuario está incompleta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="599"/>
        <source>策略信息不全</source>
        <translation type="unfinished">La información de la política está incompleta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="870"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="964"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado exitosamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="1009"/>
        <source>数据未保存，是否切换</source>
        <translation type="unfinished">Los datos no se guardan. Si se debe cambiar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="1024"/>
        <source>开始时间不能大于结束时间</source>
        <translation type="unfinished">El tiempo de inicio no puede ser mayor que el tiempo de finalización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="1221"/>
        <source>刷新</source>
        <comment>menuName</comment>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="1223"/>
        <source>选中所有</source>
        <comment>menuName</comment>
        <translation type="unfinished">Sel todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="875"/>
        <source>是否需要从安全库导入数据</source>
        <translation type="unfinished">¿Importar datos desde biblioteca segura?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="117"/>
        <source>人员/设备管理</source>
        <translation type="unfinished">Personal/Equipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="118"/>
        <source>短信策略配置</source>
        <translation type="unfinished">Política de SMS</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="119"/>
        <source>短信历史记录</source>
        <translation type="unfinished">Historial de SMS</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="120"/>
        <source>短信发送测试</source>
        <translation type="unfinished">Prueba de SMS</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="875"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="1009"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="875"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="1009"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="883"/>
        <source>导入失败</source>
        <translation type="unfinished">Fallo al importar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="916"/>
        <source>导入成功</source>
        <translation type="unfinished">Importado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="974"/>
        <source>获取中心号码失败</source>
        <translation type="unfinished">Fallo al obtener número central</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/sms_plug.cpp" line="49"/>
        <source>用户登录信息</source>
        <translation type="unfinished">Info de inicio de sesión</translation>
    </message>
</context>
<context>
    <name>TimeRangeWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.h" line="127"/>
        <source>开始</source>
        <translation type="unfinished">Inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.h" line="129"/>
        <source>结束</source>
        <translation type="unfinished">Fin</translation>
    </message>
</context>
</TS>
