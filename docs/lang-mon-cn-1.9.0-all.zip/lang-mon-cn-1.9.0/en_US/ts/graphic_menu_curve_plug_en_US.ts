<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CurveMainWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="260"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="511"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="276"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="260"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="511"/>
        <source>曲线组名称不可为空</source>
        <translation type="unfinished">Curve group name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="276"/>
        <source>暂未实现，敬请期待</source>
        <translation type="unfinished">Not yet realized, please look forward to it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="290"/>
        <source>打开曲线</source>
        <translation type="unfinished">Open curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="290"/>
        <source>曲线文件%1</source>
        <translation type="unfinished">Curve file %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="319"/>
        <source>开启实时刷新</source>
        <translation type="unfinished">Enable real-time refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="627"/>
        <source>至</source>
        <translation type="unfinished">to</translation>
    </message>
</context>
<context>
    <name>CurveTableWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="88"/>
        <source>分</source>
        <translation type="unfinished">Minute</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="95"/>
        <source>秒</source>
        <translation type="unfinished">sec</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="115"/>
        <source>时</source>
        <translation type="unfinished">Hour</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="129"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="167"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="232"/>
        <source>:</source>
        <translation type="unfinished">:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="149"/>
        <source>日</source>
        <translation type="unfinished">th</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="192"/>
        <source>周一</source>
        <translation type="unfinished">Monday</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="195"/>
        <source>周二</source>
        <translation type="unfinished">Tuesday</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="198"/>
        <source>周三</source>
        <translation type="unfinished">Wednesday</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="201"/>
        <source>周四</source>
        <translation type="unfinished">Thursday</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="204"/>
        <source>周五</source>
        <translation type="unfinished">Friday</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="207"/>
        <source>周六</source>
        <translation type="unfinished">Saturday</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="210"/>
        <source>周日</source>
        <translation type="unfinished">Sunday</translation>
    </message>
</context>
<context>
    <name>CurveViewerDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="128"/>
        <source>曲线查询</source>
        <comment>toolName</comment>
        <translation type="unfinished">Curve Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="217"/>
        <source>导出曲线数据</source>
        <translation type="unfinished">Export curve data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="219"/>
        <source>今日曲线</source>
        <translation type="unfinished">Today curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="220"/>
        <source>昨日曲线</source>
        <translation type="unfinished">Yesterday curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="221"/>
        <source>历史日曲线</source>
        <translation type="unfinished">Historical daily curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="222"/>
        <source>本时曲线</source>
        <translation type="unfinished">This hour curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="223"/>
        <source>某时曲线</source>
        <translation type="unfinished">Historical hour curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="224"/>
        <source>本周曲线</source>
        <translation type="unfinished">This week curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="225"/>
        <source>某周曲线</source>
        <translation type="unfinished">Historical week curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="226"/>
        <source>本月曲线</source>
        <translation type="unfinished">This month curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="227"/>
        <source>某月曲线</source>
        <translation type="unfinished">Historical month curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="228"/>
        <source>放大</source>
        <translation type="unfinished">Zoom in</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="229"/>
        <source>缩小</source>
        <translation type="unfinished">Zoom out</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="230"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="328"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1740"/>
        <source>切换表格</source>
        <translation type="unfinished">Switch table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="231"/>
        <source>设置</source>
        <translation type="unfinished">Settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="232"/>
        <source>曲线比较</source>
        <translation type="unfinished">Curve comparison</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="233"/>
        <source>显示阈值</source>
        <translation type="unfinished">Show threshold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="237"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1343"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2169"/>
        <source>显示游标</source>
        <translation type="unfinished">Show cursor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="246"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="250"/>
        <source>平滑曲线</source>
        <translation type="unfinished">Smooth curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="678"/>
        <source>今时曲线已存在，请按今时曲线按钮激活！</source>
        <translation type="unfinished">This hour curve already exists. Click &quot;This hour curve&quot; button to activate!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="761"/>
        <source>本月曲线已存在，请按本月曲线按钮激活！</source>
        <translation type="unfinished">This month curve already exists. Click &quot;This month curve&quot; button to activate!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="3089"/>
        <source>下限值需小于上限值！</source>
        <translation type="unfinished">The lower limit value must be less than the upper limit value!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="218"/>
        <source>打印</source>
        <translation type="unfinished">Print</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="241"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1336"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2165"/>
        <source>隐藏游标</source>
        <translation type="unfinished">Hide cursor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="255"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="259"/>
        <source>曲线详情</source>
        <translation type="unfinished">Curve details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="315"/>
        <source>切换曲线</source>
        <translation type="unfinished">Switch curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="420"/>
        <source>今日</source>
        <translation type="unfinished">Today</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="441"/>
        <source>昨日</source>
        <translation type="unfinished">Yesterday</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="471"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="477"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="490"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="678"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="689"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="761"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="771"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2465"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2478"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="3089"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="471"/>
        <source>昨日曲线已存在，请按昨日曲线按钮激活！</source>
        <translation type="unfinished">Yesterday curve already exists. Click &quot;Yesterday curve&quot; button to activate it!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="477"/>
        <source>今日曲线已存在，请按今日曲线按钮激活！</source>
        <translation type="unfinished">Today curve already exists. Click &quot;Today Curve&quot; button to activate it!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="490"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="689"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="771"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2478"/>
        <source>选择日期已超出当前日期，请重新选择！</source>
        <translation type="unfinished">The selected date has exceeded the current date, please select again!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="497"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1484"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1489"/>
        <source>天前</source>
        <translation type="unfinished">days ago</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="650"/>
        <source>本时</source>
        <translation type="unfinished">This moment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="696"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1497"/>
        <source>小时前</source>
        <translation type="unfinished">Hours ago</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="731"/>
        <source>本月</source>
        <translation type="unfinished">This month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="778"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1493"/>
        <source>月前</source>
        <translation type="unfinished">months ago</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1119"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1592"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2897"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="3185"/>
        <source>W</source>
        <translation type="unfinished">W</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1501"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2488"/>
        <source>周前</source>
        <translation type="unfinished">weeks ago</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2050"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2074"/>
        <source>秒</source>
        <translation type="unfinished">sec</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2062"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2086"/>
        <source>分钟</source>
        <translation type="unfinished">min</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2436"/>
        <source>本周</source>
        <translation type="unfinished">This week</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2465"/>
        <source>本周曲线已存在，请按本周曲线按钮激活！</source>
        <translation type="unfinished">This week curve already exists, Click &quot;This week curve&quot; Button to activate it!</translation>
    </message>
</context>
<context>
    <name>DlgCurveCompare</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="57"/>
        <source>比较曲线</source>
        <translation type="unfinished">Comparison curves</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="131"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="280"/>
        <source>空心圆</source>
        <translation type="unfinished">Hollow circle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="132"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="280"/>
        <source>实心圆</source>
        <translation type="unfinished">Solid circle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="133"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="280"/>
        <source>正方形</source>
        <translation type="unfinished">Square</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="134"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="280"/>
        <source>三角形</source>
        <translation type="unfinished">Triangle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="142"/>
        <source>基本属性</source>
        <translation type="unfinished">Basic attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="149"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="152"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="178"/>
        <source>新增比较曲线</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add comparison curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="180"/>
        <source>删除比较曲线</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete comparison curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="203"/>
        <source>曲线名称</source>
        <translation type="unfinished">Curve name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="203"/>
        <source>线色</source>
        <translation type="unfinished">Line color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="203"/>
        <source>线宽</source>
        <translation type="unfinished">Line width</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="203"/>
        <source>数据单位</source>
        <translation type="unfinished">Data unit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="203"/>
        <source>小数精度</source>
        <translation type="unfinished">Decimal precision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="203"/>
        <source>基本点形状</source>
        <translation type="unfinished">Basic point shape</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="203"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="290"/>
        <source>显示数据点</source>
        <translation type="unfinished">Show data points</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="234"/>
        <source>线色：</source>
        <translation type="unfinished">Line color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="238"/>
        <source>单位:</source>
        <translation type="unfinished">Unit:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="240"/>
        <source>请输入单位</source>
        <translation type="unfinished">Please enter the unit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="256"/>
        <source>小数点精度：</source>
        <translation type="unfinished">Decimal point precision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="261"/>
        <source>线宽：</source>
        <translation type="unfinished">Line width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="277"/>
        <source>数据点形状：</source>
        <translation type="unfinished">Data point shape:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="339"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="339"/>
        <source>比较曲线测点数不多于两个。</source>
        <translation type="unfinished">The number of measuring points cannot exceed two on the comparison curve.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="490"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="499"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="516"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="522"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="538"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="553"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="559"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="567"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="579"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="490"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="499"/>
        <source>所选测点已存在，请重新选择！</source>
        <translation type="unfinished">The selected measuring point already exists, please select again!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="516"/>
        <source>查询历史表信息失败，请重新选择！</source>
        <translation type="unfinished">Failed to query historical table info, please choose again!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="522"/>
        <source>查询历史表数量为空, 该点未配置历史点，请重新选择！</source>
        <translation type="unfinished">The number of history tables in the query is empty, and there is no history point configured for this point. Please select again!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="538"/>
        <source>配置了统计没有配置采样，请重新选择！</source>
        <translation type="unfinished">Statistics have been configured but sampling has not been configured. Please select again!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="553"/>
        <source>查询历史对象信息失败，请重新选择！</source>
        <translation type="unfinished">Failed to query historical object info, please choose again!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="559"/>
        <source>查询历史采样点数量为空, 该点未配置历史点，请重新选择！</source>
        <translation type="unfinished">The number of historical sampling points in the query is empty, and there are no historical points configured for this point. Please select again!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="567"/>
        <source>查询历史采样点失败，请重新选择！</source>
        <translation type="unfinished">Failed to query historical sampling points, please select again!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="579"/>
        <source>当前测点采样周期与基础采样周期不同，请重新选择！</source>
        <translation type="unfinished">The current sampling cycle of the measuring point is different from the basic sampling cycle. Please choose again!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="759"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="1084"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="759"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="1084"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="789"/>
        <source>今日曲线-</source>
        <translation type="unfinished">Today curve -</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="807"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="1038"/>
        <source>昨日曲线-</source>
        <translation type="unfinished">Yesterday curve -</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="825"/>
        <source>历史日曲线-</source>
        <translation type="unfinished">Historical daily curve -</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="843"/>
        <source>当月曲线-</source>
        <translation type="unfinished">This Month Curve -</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="861"/>
        <source>历史月曲线-</source>
        <translation type="unfinished">Historical month curve -</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="879"/>
        <source>本时曲线-</source>
        <translation type="unfinished">This hour curve -</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="897"/>
        <source>历史时曲线-</source>
        <translation type="unfinished">Historical hour curve -</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="915"/>
        <source>本周曲线-</source>
        <translation type="unfinished">This week curve -</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="933"/>
        <source>历史周曲线-</source>
        <translation type="unfinished">Historical week curve -</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="1034"/>
        <source>今时/日/周/月曲线-</source>
        <translation type="unfinished">This hour/daily/week/month curve -</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="1042"/>
        <source>历史时/日/周/月曲线-</source>
        <translation type="unfinished">Historical hour/daily/week/month curve -</translation>
    </message>
</context>
<context>
    <name>GraphicMenuCurvePlug</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/graphic_menu_curve_plug.cpp" line="38"/>
        <source>曲线查询</source>
        <translation type="unfinished">Curve query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/graphic_menu_curve_plug.cpp" line="63"/>
        <source>今日曲线</source>
        <translation type="unfinished">Today curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/graphic_menu_curve_plug.cpp" line="64"/>
        <source>查看今日曲线</source>
        <translation type="unfinished">View today curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/graphic_menu_curve_plug.cpp" line="107"/>
        <source>打开失败</source>
        <translation type="unfinished">Open failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/graphic_menu_curve_plug.cpp" line="107"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/graphic_menu_curve_plug.cpp" line="107"/>
        <source>该点历史曲线查询失败</source>
        <translation type="unfinished">Failed to query the history curve of this point</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/graphic_menu_curve_plug.cpp" line="254"/>
        <source>本日</source>
        <translation type="unfinished">Today</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="753"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="1079"/>
        <source>未知(%1)</source>
        <translation type="unfinished">Unknown (%1)</translation>
    </message>
</context>
<context>
    <name>dlg_day_curve</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.ui" line="168"/>
        <source>采样周期:</source>
        <extracomment>采样周期:</extracomment>
        <translation type="unfinished">Samp. cycle:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.ui" line="194"/>
        <source>历史取数周期:</source>
        <extracomment>历史取数周期:</extracomment>
        <translation type="unfinished">History data cycle:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.ui" line="217"/>
        <source>x采样周期</source>
        <extracomment>x采样周期</extracomment>
        <translation type="unfinished">x samp. cycle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.ui" line="230"/>
        <source>实时采样周期:</source>
        <extracomment>实时采样周期:</extracomment>
        <translation type="unfinished">RT Samp. cycle:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.ui" line="259"/>
        <source>秒</source>
        <extracomment>秒</extracomment>
        <translation type="unfinished">sec</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.ui" line="275"/>
        <source>上限阈值:</source>
        <extracomment>上限阈值:</extracomment>
        <translation type="unfinished">Upper threshold:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.ui" line="298"/>
        <source>下限阈值:</source>
        <extracomment>下限阈值:</extracomment>
        <translation type="unfinished">Lower threshold:</translation>
    </message>
</context>
</TS>
