<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.ui" line="84"/>
        <source>校验数据选择：</source>
        <translation type="unfinished">Verification Data Selection:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.ui" line="117"/>
        <source>本地运行库</source>
        <translation type="unfinished">Local RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.ui" line="137"/>
        <source>本地维护库</source>
        <translation type="unfinished">Local MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.ui" line="165"/>
        <source>本地文件</source>
        <translation type="unfinished">Local file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="185"/>
        <source>文件选择</source>
        <translation type="unfinished">File Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.ui" line="251"/>
        <source>应用名：</source>
        <translation type="unfinished">App name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.ui" line="279"/>
        <source>库名：</source>
        <translation type="unfinished">DB name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.ui" line="358"/>
        <source>日志消息：</source>
        <translation type="unfinished">Log message:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="186"/>
        <source>开始校验</source>
        <translation type="unfinished">Verify</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="35"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="86"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="205"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="259"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="278"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="287"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="306"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="350"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="412"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="35"/>
        <source>注册失败</source>
        <translation type="unfinished">Reg failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="86"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="205"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="412"/>
        <source>系统管理库映射为空</source>
        <translation type="unfinished">Sysmgr db mapping is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="191"/>
        <source>文件选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">File selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="193"/>
        <source>开始校验</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Verify</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="240"/>
        <source>选择文件夹</source>
        <translation type="unfinished">Select folder</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="259"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="287"/>
        <source>库名不能为空</source>
        <translation type="unfinished">The db name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="278"/>
        <source>数据连接失败</source>
        <translation type="unfinished">Data connection failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="306"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="350"/>
        <source>数据连接映射失败</source>
        <translation type="unfinished">Data connection mapping failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="315"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="327"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="340"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="315"/>
        <source>库路径不能为空！</source>
        <translation type="unfinished">The DB path cannot be empty!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="327"/>
        <source>路径下无相关库文件</source>
        <translation type="unfinished">Path: no related DB file.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="340"/>
        <source>库名不能为空！</source>
        <translation type="unfinished">The DB name cannot be empty!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="378"/>
        <source>校验成功!</source>
        <translation type="unfinished">Validation successful!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/mainwindow.cpp" line="390"/>
        <source>检测失败!</source>
        <translation type="unfinished">Detection failed!</translation>
    </message>
</context>
<context>
    <name>NoticeWidget</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/noticewidget.cpp" line="58"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/noticewidget.h" line="65"/>
        <source>通知</source>
        <translation type="unfinished">Notification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_check_plug/noticewidget.ui" line="207"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
</context>
</TS>
