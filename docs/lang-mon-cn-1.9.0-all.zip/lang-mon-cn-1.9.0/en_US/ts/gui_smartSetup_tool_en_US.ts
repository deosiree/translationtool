<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>SmartSetupTool</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="27"/>
        <source>节点信息配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="80"/>
        <source>节点名称：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="89"/>
        <source>请设置节点名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="94"/>
        <source>节点类型：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="97"/>
        <source>工作站</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="97"/>
        <source>服务器</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="107"/>
        <source>IP信息：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="121"/>
        <source>删除IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="122"/>
        <source>新增IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="157"/>
        <source>节点名称修改记录：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="184"/>
        <source>网络信息修改记录：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="222"/>
        <source>信息配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="223"/>
        <source>历史记录</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="226"/>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="347"/>
        <source>退出</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="227"/>
        <source>还原</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="228"/>
        <source>应用</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="240"/>
        <source>平台版本:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="241"/>
        <source>内部版本:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="242"/>
        <source>发布时间:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="299"/>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="311"/>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="347"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="299"/>
        <source>配置已修改，否重启平台</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="311"/>
        <source>是否应用修改</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="347"/>
        <source>当前修改的配置未应用，是否退出</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui/gui_smartSetup_tool/smart_setup_tool.cpp" line="299"/>
        <source>立即重启</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
