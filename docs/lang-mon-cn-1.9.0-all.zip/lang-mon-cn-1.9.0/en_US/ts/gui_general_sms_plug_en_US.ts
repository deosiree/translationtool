<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="32"/>
        <source>设备管理</source>
        <translation type="unfinished">Device management</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="42"/>
        <source>设备名称：</source>
        <translation type="unfinished">Equipment name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="56"/>
        <source>设备串口：</source>
        <translation type="unfinished">Device serial port:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="70"/>
        <source>中心号码：</source>
        <translation type="unfinished">Center No.:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="80"/>
        <source>获取中心号码</source>
        <translation type="unfinished">Get center number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="94"/>
        <source>人员管理</source>
        <translation type="unfinished">Personnel management</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="24"/>
        <source>人员/设备管理</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Person/Equip</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="117"/>
        <source>导入用户列表</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Import user list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="124"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="198"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="131"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="205"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="158"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="232"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="175"/>
        <source>短信策略配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">SMS Policy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="244"/>
        <source>短信历史记录</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">SMS History</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="252"/>
        <source>查询条件</source>
        <translation type="unfinished">Query condition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="262"/>
        <source>发送时间：</source>
        <translation type="unfinished">Send time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="279"/>
        <source>人员名称：</source>
        <translation type="unfinished">Personnel name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="297"/>
        <source>角色类型：</source>
        <translation type="unfinished">Role type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="311"/>
        <source>短信类型：</source>
        <translation type="unfinished">SMS type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="325"/>
        <source>短信内容：</source>
        <translation type="unfinished">SMS content:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="342"/>
        <source>查询结果</source>
        <translation type="unfinished">Query results</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="365"/>
        <source>查询</source>
        <translation type="unfinished">Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="385"/>
        <source>短信发送测试</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">SMS Test</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="425"/>
        <source>发送</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Send</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.ui" line="395"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="214"/>
        <source>短信类型</source>
        <translation type="unfinished">SMS type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="127"/>
        <source>请输入短信测试内容</source>
        <translation type="unfinished">Please enter the text message test content</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="128"/>
        <source>请输入短信测试类型</source>
        <translation type="unfinished">Please enter the SMS test type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="165"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="214"/>
        <source>人员名称</source>
        <translation type="unfinished">Personnel name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="165"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="189"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="214"/>
        <source>角色</source>
        <translation type="unfinished">Role</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="165"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="214"/>
        <source>手机号</source>
        <translation type="unfinished">Mobile number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="165"/>
        <source>接收时间段</source>
        <translation type="unfinished">Receiving period</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="189"/>
        <source>类型</source>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="189"/>
        <source>短信特征</source>
        <translation type="unfinished">SMS features</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="214"/>
        <source>短信内容</source>
        <translation type="unfinished">SMS content</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="214"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="214"/>
        <source>发送时间</source>
        <translation type="unfinished">Sending time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="245"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="246"/>
        <source>全部</source>
        <translation type="unfinished">All</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="472"/>
        <source>用户：%1 接收时间段开始时间大于结束时间,请检查</source>
        <translation type="unfinished">User: %1 The start time of the receiving period is longer than the end time. Please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="504"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="583"/>
        <source>%1 %2 %3 数据重复</source>
        <translation type="unfinished">%1 %2 %3 Data is duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="508"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="520"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="587"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="599"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="870"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="875"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="883"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="916"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="964"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="974"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="1009"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="1024"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="520"/>
        <source>用户信息不全</source>
        <translation type="unfinished">User info is incomplete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="599"/>
        <source>策略信息不全</source>
        <translation type="unfinished">Policy info is incomplete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="870"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="964"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="1009"/>
        <source>数据未保存，是否切换</source>
        <translation type="unfinished">Data is not saved. Whether to switch</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="1024"/>
        <source>开始时间不能大于结束时间</source>
        <translation type="unfinished">The start time cannot be greater than the end time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="1221"/>
        <source>刷新</source>
        <comment>menuName</comment>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="1223"/>
        <source>选中所有</source>
        <comment>menuName</comment>
        <translation type="unfinished">Select all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="875"/>
        <source>是否需要从安全库导入数据</source>
        <translation type="unfinished">Whether to import data from the security DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="117"/>
        <source>人员/设备管理</source>
        <translation type="unfinished">Person/Equip</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="118"/>
        <source>短信策略配置</source>
        <translation type="unfinished">SMS Policy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="119"/>
        <source>短信历史记录</source>
        <translation type="unfinished">SMS History</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="120"/>
        <source>短信发送测试</source>
        <translation type="unfinished">SMS Test</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="875"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="1009"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="875"/>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="1009"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="883"/>
        <source>导入失败</source>
        <translation type="unfinished">Import failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="916"/>
        <source>导入成功</source>
        <translation type="unfinished">Import successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.cpp" line="974"/>
        <source>获取中心号码失败</source>
        <translation type="unfinished">Failed to retrieve the center number</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/sms_plug.cpp" line="49"/>
        <source>用户登录信息</source>
        <translation type="unfinished">Login Info</translation>
    </message>
</context>
<context>
    <name>TimeRangeWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.h" line="127"/>
        <source>开始</source>
        <translation type="unfinished">Start</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_sms_plug/mainwindow.h" line="129"/>
        <source>结束</source>
        <translation type="unfinished">End</translation>
    </message>
</context>
</TS>
