<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="109"/>
        <source>系统恢复中</source>
        <translation type="unfinished">System recovery in progress</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="1047"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="1050"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="1057"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="1047"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="1050"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="1057"/>
        <source>失败</source>
        <translation type="unfinished">Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_base.cpp" line="17"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_base.cpp" line="21"/>
        <source>系统备份</source>
        <translation type="unfinished">System Backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_base.cpp" line="25"/>
        <source>历史在线时段备份</source>
        <translation type="unfinished">History online time backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_base.cpp" line="29"/>
        <source>节点备份</source>
        <translation type="unfinished">Node backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_base.cpp" line="33"/>
        <source>历史离线全库备份</source>
        <translation type="unfinished">History offline all DB backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_base.cpp" line="37"/>
        <source>历史在线全库备份</source>
        <translation type="unfinished">History online all DB backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_base.cpp" line="41"/>
        <source>未知类型</source>
        <translation type="unfinished">Unknown type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="110"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="125"/>
        <source>可执行程序</source>
        <translation type="unfinished">Executable program</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="111"/>
        <source>日志文件</source>
        <translation type="unfinished">Log files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="112"/>
        <source>配置文件</source>
        <translation type="unfinished">Config files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="113"/>
        <source>画面文件</source>
        <translation type="unfinished">Graph file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="114"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="115"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="124"/>
        <source>实时库文件</source>
        <translation type="unfinished">TDB files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="118"/>
        <source>资源文件</source>
        <translation type="unfinished">Resource files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="119"/>
        <source>其他</source>
        <translation type="unfinished">Other</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="120"/>
        <source>文件服务文件</source>
        <translation type="unfinished">File service file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="121"/>
        <source>历史库数据</source>
        <translation type="unfinished">HDB data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="122"/>
        <source>脚本文件</source>
        <translation type="unfinished">Script files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="123"/>
        <source>应用数据文件</source>
        <translation type="unfinished">App data file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="163"/>
        <source>备份包详情</source>
        <translation type="unfinished">Backup package details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="371"/>
        <source>%1 备份包详情</source>
        <translation type="unfinished">%1 backup package details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="757"/>
        <source>备份中历史库类型为%1， 本地历史库类型为%2，禁止进行历史数据恢复</source>
        <translation type="unfinished">The HDB type in the backup is %1, and the local HDB type is %2. Historical data recovery is prohibited</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="122"/>
        <source>服务器</source>
        <translation type="unfinished">Server</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="122"/>
        <source>工作站</source>
        <translation type="unfinished">Workstation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="320"/>
        <source>备份包类型：%1  备份包名称：%2</source>
        <translation type="unfinished">Backup package type: %1 Backup package name: %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="436"/>
        <source>服务器</source>
        <comment>UI</comment>
        <translation type="unfinished">Server</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="436"/>
        <source>工作站</source>
        <comment>UI</comment>
        <translation type="unfinished">Workstation</translation>
    </message>
</context>
<context>
    <name>editpath</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/editpath.ui" line="50"/>
        <source>备份包目录：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup package dir:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/editpath.ui" line="60"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/editpath.ui" line="101"/>
        <source>选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/editpath.ui" line="85"/>
        <source>系统根目录：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">System root dir:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/editpath.cpp" line="11"/>
        <source>设置目录</source>
        <comment>toolName</comment>
        <translation type="unfinished">Set DIR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/editpath.cpp" line="34"/>
        <source>选择备份包目录</source>
        <comment>toolName</comment>
        <translation type="unfinished">Select Backup Package DIR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/editpath.cpp" line="47"/>
        <source>选择恢复根目录</source>
        <comment>toolName</comment>
        <translation type="unfinished">Select Recovery ROOT DIR</translation>
    </message>
</context>
<context>
    <name>exec_info</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="113"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="248"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="113"/>
        <source>生成系统守护进程失败</source>
        <translation type="unfinished">Failed to create the system daemon process</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="168"/>
        <source>系统恢复失败</source>
        <translation type="unfinished">System recovery failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="178"/>
        <source>系统恢复成功</source>
        <translation type="unfinished">System recovery succeeded</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="192"/>
        <source>目标机器已重启</source>
        <translation type="unfinished">Destination machine restarted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="248"/>
        <source>用户密码错误</source>
        <translation type="unfinished">User password error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="183"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="192"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="240"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="114"/>
        <source>系统恢复失败，请重新启动还原工具</source>
        <translation type="unfinished">System recovery failed, please restart the restore tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="174"/>
        <source>系统恢复完成，存在异常项目,请检查</source>
        <translation type="unfinished">System recovery is complete, there are abnormal items, please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="184"/>
        <source>是否重启目标机器？</source>
        <translation type="unfinished">Whether to restart the destination machine?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="206"/>
        <source>系统恢复已终止</source>
        <translation type="unfinished">System recovery has terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="240"/>
        <source>请输入当前系统用户密码：</source>
        <translation type="unfinished">Please enter the current system user password:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.ui" line="106"/>
        <source>终止恢复</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Stop recovery</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.ui" line="113"/>
        <source>启动系统</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Start system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.ui" line="139"/>
        <source>重新恢复</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Recover</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.ui" line="146"/>
        <source>退出工具</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.ui" line="202"/>
        <source>日志详情：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Log details:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.ui" line="222"/>
        <source>收起详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Details</translation>
    </message>
</context>
<context>
    <name>ipc_connect_widget</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/ipc_connect_widget.cpp" line="24"/>
        <source>请输入主机IP地址</source>
        <translation type="unfinished">Enter the host IP address</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/ipc_connect_widget.cpp" line="37"/>
        <source>链接</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/ipc_connect_widget.cpp" line="39"/>
        <source>关闭</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/ipc_connect_widget.cpp" line="52"/>
        <source>链接</source>
        <comment>toolName</comment>
        <translation type="unfinished">Link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/ipc_connect_widget.cpp" line="67"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/ipc_connect_widget.cpp" line="73"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/ipc_connect_widget.cpp" line="81"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/ipc_connect_widget.cpp" line="86"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/ipc_connect_widget.cpp" line="67"/>
        <source>IP格式不正确</source>
        <translation type="unfinished">The IP address format is incorrect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/ipc_connect_widget.cpp" line="73"/>
        <source>端口号不在合法范围内</source>
        <translation type="unfinished">The port number is invalid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/ipc_connect_widget.cpp" line="79"/>
        <source>已链接</source>
        <translation type="unfinished">Linked</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/ipc_connect_widget.cpp" line="81"/>
        <source>链接成功</source>
        <translation type="unfinished">Link successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/ipc_connect_widget.cpp" line="86"/>
        <source>链接失败，请检查参数</source>
        <translation type="unfinished">Link failed, please check the params</translation>
    </message>
</context>
<context>
    <name>recover_mainwindow</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.ui" line="83"/>
        <source> 备份包列表</source>
        <translation type="unfinished">Backup package list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.ui" line="114"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.ui" line="155"/>
        <source>下一步</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Next</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.ui" line="202"/>
        <source>节点信息</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.ui" line="212"/>
        <source>备份包备注：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Backup package remark:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.ui" line="222"/>
        <source>备份包内容：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Contents of the backup package:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.ui" line="189"/>
        <source>备份包</source>
        <translation type="unfinished">Backup package</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="243"/>
        <source>文件缺失</source>
        <translation type="unfinished">File missing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="256"/>
        <source>详情文件异常</source>
        <translation type="unfinished">Detail files exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="296"/>
        <source>备份包详情</source>
        <translation type="unfinished">Backup package details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="378"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="576"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="583"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="589"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="597"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="604"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="616"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="624"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="644"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="658"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="660"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="747"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="760"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="765"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="772"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="826"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="840"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="378"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="597"/>
        <source>备份包详情文件加载失败</source>
        <translation type="unfinished">Failed to load backup package details file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="703"/>
        <source>备份包上传失败，请检查相关节点</source>
        <translation type="unfinished">Failed to upload the backup package. Please check the relevant nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="805"/>
        <source>节点系统停止失败</source>
        <translation type="unfinished">Node system stop failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="827"/>
        <source>机器系统版本获取失败，是否进行数据恢复</source>
        <translation type="unfinished">Failed to retrieve the machine system version. Whether to recover the data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="841"/>
        <source>备份包版本[%1]与机器系统版本[%2]不符，禁止进行数据恢复</source>
        <translation type="unfinished">The backup package version [%1] does not match the machine system version [%2]. Data recovery is prohibited</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="576"/>
        <source>备份包数据为空，无法跳转到下一步</source>
        <translation type="unfinished">Backup package data is empty, unable to jump to the next step</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="165"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="165"/>
        <source>名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="165"/>
        <source>类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="165"/>
        <source>时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="166"/>
        <source>软件版本</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Software version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="191"/>
        <source>节点名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="191"/>
        <source>系统版本</source>
        <comment>subTitle</comment>
        <translation type="unfinished">System version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="191"/>
        <source>CPU架构</source>
        <comment>subTitle</comment>
        <translation type="unfinished">CPU architecture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="206"/>
        <source>备份包刷新</source>
        <comment>menuName</comment>
        <translation type="unfinished">Refresh backup package</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="207"/>
        <source>选取备份包</source>
        <comment>menuName</comment>
        <translation type="unfinished">Select backup package</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="208"/>
        <source>设置备份包目录</source>
        <comment>menuName</comment>
        <translation type="unfinished">Set the backup package dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="495"/>
        <source>选择备份包目录</source>
        <comment>toolName</comment>
        <translation type="unfinished">Select Backup Package DIR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="536"/>
        <source>选择备份包</source>
        <comment>toolName</comment>
        <translation type="unfinished">Select Backup Package</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="583"/>
        <source>未选中备份包，无法跳转到下一步</source>
        <translation type="unfinished">No backup package selected, unable to jump to the next step</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="589"/>
        <source>备份包详情文件异常，请检查备份包文件</source>
        <translation type="unfinished">The backup package details file is abnormal. Please check the backup package file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="604"/>
        <source>备份包详情文件中MD5值异常</source>
        <translation type="unfinished">MD5 value in the backup package details file is abnormal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="616"/>
        <source>备份包文件MD5值计算异常</source>
        <translation type="unfinished">Backup package file MD5 value calculation exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="624"/>
        <source>备份包文件MD5比对异常</source>
        <translation type="unfinished">Backup package file MD5 comparison exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="644"/>
        <source>历史数据恢复暂不支持远程恢复</source>
        <translation type="unfinished">Remote recovery is not currently supported for historical data recovery</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="658"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="765"/>
        <source>进行数据恢复前请将现场全部节点离线</source>
        <translation type="unfinished">Please take all nodes offline before data recovery</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="661"/>
        <source>系统恢复将停止系统，是否继续</source>
        <translation type="unfinished">System recovery will stop the system. Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="709"/>
        <source>平台停止失败，请检查相关节点</source>
        <translation type="unfinished">Platform stop failed, please check related nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="747"/>
        <source>获取本地历史库类型失败，禁止进行历史恢复</source>
        <translation type="unfinished">Failed to retrieve the local HDB type, history recovery is prohibited</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="773"/>
        <source>核心进程存活，判断系统运行中，无法进行系统恢复，是否停止系统</source>
        <translation type="unfinished">The core process survives. Judge whether the system is running and cannot be recovered. Whether to stop the system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="703"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="709"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/recover_mainwindow.cpp" line="805"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
</context>
<context>
    <name>stacked_windows</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/stacked_windows.cpp" line="24"/>
        <source>系统还原工具</source>
        <comment>toolName</comment>
        <translation type="unfinished">System Restore</translation>
    </message>
</context>
<context>
    <name>sys_para</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="116"/>
        <source>备份包信息</source>
        <translation type="unfinished">Backup package info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="129"/>
        <source>现场名称：</source>
        <translation type="unfinished">Site name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="136"/>
        <source>系统名称：</source>
        <translation type="unfinished">System name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="185"/>
        <source>机器信息</source>
        <translation type="unfinished">Machine info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="405"/>
        <source>恢复配置</source>
        <translation type="unfinished">Recover config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="205"/>
        <source>复制节点信息</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Copy node info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="273"/>
        <source>安装目录：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Installation dir:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="358"/>
        <source>现场名称：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Site name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="256"/>
        <source>选择路径</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="266"/>
        <source>系统名称：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">System name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="221"/>
        <source>IP信息：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">IP info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="338"/>
        <source>恢复机器信息：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Recover machine info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="331"/>
        <source>机器名称：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Machine name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="348"/>
        <source>节点类型：</source>
        <translation type="unfinished">Node type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="418"/>
        <source>节点信息：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="428"/>
        <source>可执行程序</source>
        <translation type="unfinished">Executable program</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="435"/>
        <source>配置文件</source>
        <translation type="unfinished">Config files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="442"/>
        <source>画面文件</source>
        <translation type="unfinished">Graph file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="449"/>
        <source>实时库文件</source>
        <translation type="unfinished">TDB files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="456"/>
        <source>文件服务文件</source>
        <translation type="unfinished">File service file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="463"/>
        <source>资源文件</source>
        <translation type="unfinished">Resource files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="470"/>
        <source>日志文件</source>
        <translation type="unfinished">Log files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="477"/>
        <source>应用数据文件</source>
        <translation type="unfinished">App data file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="484"/>
        <source>脚本文件</source>
        <translation type="unfinished">Script files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="494"/>
        <source>历史数据</source>
        <translation type="unfinished">Historical Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="587"/>
        <source>上一步</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Previous</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.ui" line="594"/>
        <source>开始恢复</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Recovery</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="287"/>
        <source>选择备份包目录</source>
        <translation type="unfinished">Select Backup Package DIR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="312"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="353"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="370"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="688"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="313"/>
        <source>备份包详情文件打开失败， 请检查%1文件</source>
        <translation type="unfinished">The backup package details file failed to open, please check the %1 file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="354"/>
        <source>是否保留历史数据？</source>
        <translation type="unfinished">Whether to keep historical data?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="390"/>
        <source>节点</source>
        <translation type="unfinished">Node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="390"/>
        <source>系统版本</source>
        <translation type="unfinished">System version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="390"/>
        <source>CPU架构</source>
        <translation type="unfinished">CPU architecture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="519"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="525"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="535"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="541"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="551"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="557"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="567"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="583"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="594"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="599"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="646"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="519"/>
        <source>请输入系统名称</source>
        <translation type="unfinished">Please enter the system name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="526"/>
        <source>系统名应为任意字母、数字、连字符和下划线组合</source>
        <translation type="unfinished">The system name should be any combination of letters, numbers, hyphens, and base lines</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="526"/>
        <source>(开头或结尾不能为符号）</source>
        <translation type="unfinished">(The beginning or end cannot be a symbol)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="527"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="543"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="559"/>
        <source>且最大长度为31个字符</source>
        <translation type="unfinished">And the maximum length is 31 characters</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="535"/>
        <source>请输入现场名称</source>
        <translation type="unfinished">Please enter the site name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="542"/>
        <source>现场名应为任意字母、数字和连字符组合</source>
        <translation type="unfinished">The on-site name should be any combination of letters, numbers, and hyphens</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="542"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="558"/>
        <source>(连字符不能在开头或结尾）</source>
        <translation type="unfinished">(Hyphens cannot be at the beginning or end)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="551"/>
        <source>请输入机器名称</source>
        <translation type="unfinished">Please enter the machine name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="558"/>
        <source>机器名应为任意小写字母、数字和连字符组合</source>
        <translation type="unfinished">The machine name should be any combination of lowercase letters, numbers, and hyphens</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="583"/>
        <source>请选择要恢复的节点！</source>
        <translation type="unfinished">Please select the node to recover!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="599"/>
        <source>IP信息重复</source>
        <translation type="unfinished">Duplicate IP info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="567"/>
        <source>节点信息异常，请检查备份包描述文件</source>
        <translation type="unfinished">Node info is abnormal. Please check the backup package description file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="371"/>
        <source>备份包恢复至少需要 %1 MB的可用磁盘空间。 %2请确保磁盘空间充足后再继续恢复。</source>
        <translation type="unfinished">Backup package recovery requires at least %1 MB of available disk space. %2 Please ensure sufficient disk space before continuing with the recovery.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="390"/>
        <source>节点类型</source>
        <translation type="unfinished">Node type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="594"/>
        <source>请配置IP信息</source>
        <translation type="unfinished">Please configure IP info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="646"/>
        <source>请勾选需要恢复的内容</source>
        <translation type="unfinished">Please check the content that needs to be recovered</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/sys_para.cpp" line="689"/>
        <source>所选节点%1与机器系统存在差异，本机操作系统版本：%2，CPU架构：%3，是否强制恢复</source>
        <translation type="unfinished">The selected node %1 is different from the machine system, native operating system version: %2. CPU architecture:%3. Whether to force recovery</translation>
    </message>
</context>
<context>
    <name>thread_recoverinfos</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="461"/>
        <source>开始进行系统恢复</source>
        <translation type="unfinished">Start system recovery</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="465"/>
        <source>解压备份文件：[%1]</source>
        <translation type="unfinished">Extract the backup file: [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="518"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="521"/>
        <source>失败</source>
        <translation type="unfinished">Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="525"/>
        <source>解压备份文件：[%1] , 解压结果：[%2]</source>
        <translation type="unfinished">Extract the backup file: [%1], extracted result: [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="564"/>
        <source>开始进行历史数据库恢复</source>
        <translation type="unfinished">Start HDB recovery</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="698"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="713"/>
        <source>历史数据恢复失败</source>
        <translation type="unfinished">Historical data recovery failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="740"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="865"/>
        <source>备份包文件[%1]，创建链接目录[%2]失败</source>
        <translation type="unfinished">Backup package file [%1], failed to create link dir [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="1058"/>
        <source>主机网卡IP及主机名称设置完成，请重启机器</source>
        <translation type="unfinished">The host net card IP and host name are set. Please restart the machine</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="1104"/>
        <source>备份包文件恢复完成</source>
        <translation type="unfinished">Backup package file recovery completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="1110"/>
        <source>恢复终止</source>
        <translation type="unfinished">Resume stop</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="1048"/>
        <source>设置主机网卡IP%1</source>
        <translation type="unfinished">Set host NIC IP %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="534"/>
        <source>备份包详情文件获取失败</source>
        <translation type="unfinished">Failed to retrieve backup package details file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="604"/>
        <source>备份包文件[%1]还原失败, 不支持的数据库类型</source>
        <translation type="unfinished">Backup package file [%1] restoration failed, unsupported db type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="613"/>
        <source>备份包文件[%1]还原失败, 历史库服务停止失败</source>
        <translation type="unfinished">Backup package file [%1] restoration failed, HDB service stopped failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="709"/>
        <source>历史数据恢复成功</source>
        <translation type="unfinished">Historical data recovery successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="629"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="752"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="767"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="775"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="824"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="876"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="891"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="899"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="948"/>
        <source>备份包文件[%1]解压成功</source>
        <translation type="unfinished">Backup package file [%1] extracted successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="573"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="643"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="730"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="756"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="771"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="779"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="832"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="848"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="880"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="895"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="903"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="956"/>
        <source>备份包文件[%1]解压失败</source>
        <translation type="unfinished">Backup package file [%1] failed to extracted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="721"/>
        <source>历史数据恢复暂不支持远程恢复</source>
        <translation type="unfinished">Remote recovery is not currently supported for historical data recovery</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_recover/exec_info.cpp" line="1051"/>
        <source>设置主机名称%1</source>
        <translation type="unfinished">Set host name %1</translation>
    </message>
</context>
</TS>
