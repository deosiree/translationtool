<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AlarmConfigMainWidget</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/alarm_config_mainwidget.cpp" line="82"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/alarm_config_mainwidget.cpp" line="82"/>
        <source>获取告警项配置失败</source>
        <translation type="unfinished">Failed to retrieve alarm item config</translation>
    </message>
</context>
<context>
    <name>AlarmcfgTypenameTableShowData</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/alarmcfg_typename_table_show_data.cpp" line="125"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/alarmcfg_typename_table_show_data.cpp" line="164"/>
        <source>告警等级</source>
        <translation type="unfinished">Alarm level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/alarmcfg_typename_table_show_data.cpp" line="181"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/alarmcfg_typename_table_show_data.cpp" line="185"/>
        <source>失败</source>
        <translation type="unfinished">Failed</translation>
    </message>
</context>
<context>
    <name>InfoDisplayFrame</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="37"/>
        <source>信息配置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Config info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="49"/>
        <source>还原</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Restore</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="52"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="102"/>
        <source>名称:</source>
        <translation type="unfinished">Name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="108"/>
        <source>描述:</source>
        <translation type="unfinished">Description:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="114"/>
        <source>告警配置:</source>
        <translation type="unfinished">Alarm Config:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="121"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="384"/>
        <source>是否推画面</source>
        <translation type="unfinished">Push graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="121"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="385"/>
        <source>是否语音播放</source>
        <translation type="unfinished">Voice play</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="121"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="386"/>
        <source>是否音响播放</source>
        <translation type="unfinished">Audio play</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="121"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="387"/>
        <source>是否发短信</source>
        <translation type="unfinished">Send msg</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="121"/>
        <source>是否发邮件</source>
        <translation type="unfinished">Send email</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="127"/>
        <source>是否写审计:</source>
        <translation type="unfinished">Send to audit:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="131"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="131"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="145"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="152"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="145"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="152"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="135"/>
        <source>告警等级:</source>
        <translation type="unfinished">Alarm level:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="137"/>
        <source>未定义</source>
        <translation type="unfinished">Undefined</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="142"/>
        <source>不转应用:</source>
        <translation type="unfinished">No app redirection:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="149"/>
        <source>不存平台告警:</source>
        <translation type="unfinished">No platform alarm:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="156"/>
        <source>审计事件名:</source>
        <translation type="unfinished">Audit event:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="161"/>
        <source>审计结果:</source>
        <translation type="unfinished">Audit results:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="164"/>
        <source>失败</source>
        <translation type="unfinished">Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="164"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="338"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_frame.cpp" line="338"/>
        <source>名称不可为空</source>
        <translation type="unfinished">Name cannot be empty</translation>
    </message>
</context>
<context>
    <name>InfoDisplayTable</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="64"/>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="194"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="69"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="200"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="64"/>
        <source>请选择一条需要操作的数据</source>
        <translation type="unfinished">Please select a piece of data to operate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="57"/>
        <source>异常输出</source>
        <translation type="unfinished">Abnormal output</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="57"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished">Abnormal query data, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="69"/>
        <source>是否确定</source>
        <translation type="unfinished">Whether to confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="194"/>
        <source>操作失败</source>
        <translation type="unfinished">operation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="200"/>
        <source>操作成功</source>
        <translation type="unfinished">Operation successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="225"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="226"/>
        <source>新增</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="227"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="229"/>
        <source>批量新增</source>
        <translation type="unfinished">Batch Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="309"/>
        <source>整数输入</source>
        <translation type="unfinished">Integer Input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="310"/>
        <source>请输入一个1-10的整数:</source>
        <translation type="unfinished">Please enter an integer from 1 to 10:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="415"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/gui_alarmconfig/src/widget/info_display_table.cpp" line="415"/>
        <source>是否删除选中项</source>
        <translation type="unfinished">Whether to delete selected item</translation>
    </message>
</context>
</TS>
