<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>GeneralVolLevelWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_vol_plug/graphic_general_vol_widget.cpp" line="54"/>
        <source>电压等级配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Nivel de Voltaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_vol_plug/graphic_general_vol_widget.cpp" line="90"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_vol_plug/graphic_general_vol_widget.cpp" line="96"/>
        <source>电压等级</source>
        <translation type="unfinished">Nivel de voltaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_vol_plug/graphic_general_vol_widget.cpp" line="102"/>
        <source>颜色</source>
        <translation type="unfinished">Color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_vol_plug/graphic_general_vol_widget.cpp" line="109"/>
        <source>RGB</source>
        <translation type="unfinished">RGB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_vol_plug/graphic_general_vol_widget.cpp" line="269"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_vol_plug/graphic_general_vol_widget.cpp" line="275"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_vol_plug/graphic_general_vol_widget.cpp" line="269"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_vol_plug/graphic_general_vol_widget.cpp" line="275"/>
        <source>是否重置</source>
        <translation type="unfinished">Desea restablecerlo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_vol_plug/graphic_general_vol_widget.ui" line="41"/>
        <source>应用发布</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Publicación de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_vol_plug/graphic_general_vol_widget.ui" line="48"/>
        <source>取消应用</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar aplicación</translation>
    </message>
</context>
</TS>
