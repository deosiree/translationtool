<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CWarnItemModel</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="420"/>
        <source>序号</source>
        <translation type="unfinished">Número de serie</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="422"/>
        <source>时间</source>
        <translation type="unfinished">Tiempo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="424"/>
        <source>告警节点</source>
        <translation type="unfinished">Nodo de alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="426"/>
        <source>告警项</source>
        <translation type="unfinished">Ítem de alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="428"/>
        <source>告警对象</source>
        <translation type="unfinished">Objeto de alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="430"/>
        <source>告警等级</source>
        <translation type="unfinished">Nivel de alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="432"/>
        <source>告警内容</source>
        <translation type="unfinished">Contenido de alerta</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/dialog.ui" line="13"/>
        <source>Dialog</source>
        <translation type="unfinished">Diálogo</translation>
    </message>
</context>
<context>
    <name>InputDialog</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="156"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="220"/>
        <source>相对路径</source>
        <translation type="unfinished">Ruta relativa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="157"/>
        <source>绝对路径</source>
        <translation type="unfinished">Ruta absoluta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="167"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="168"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="188"/>
        <source>添加文件</source>
        <translation type="unfinished">Agregar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="233"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="237"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="233"/>
        <source>文件或文件夹路径已存在，请勿重复！</source>
        <translation type="unfinished">¡Ruta de archivo/carpeta ya existe, no repetir!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="237"/>
        <source>请检查文件或文件夹参数是否正确！</source>
        <translation type="unfinished">¡Verifique parámetros de archivo/carpeta!</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="139"/>
        <source>名称：</source>
        <translation type="unfinished">Nombre:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="143"/>
        <source>描述：</source>
        <translation type="unfinished">Descripción:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="147"/>
        <source>路径：</source>
        <translation type="unfinished">Ruta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="153"/>
        <source>路径类型：</source>
        <translation type="unfinished">Tipo de ruta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="297"/>
        <source>接收流量</source>
        <translation type="unfinished">Tráfico recibido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="298"/>
        <source>发送流量</source>
        <translation type="unfinished">Tráfico enviado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="299"/>
        <source>收包率</source>
        <translation type="unfinished">Tasa de recepción paquetes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="300"/>
        <source>发包率</source>
        <translation type="unfinished">Tasa de envío paquetes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="301"/>
        <source>内存值</source>
        <translation type="unfinished">Valor de memoria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="302"/>
        <source>句柄数</source>
        <translation type="unfinished">Núm. de manejadores</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="303"/>
        <source>磁盘值</source>
        <translation type="unfinished">Valor de disco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="304"/>
        <source>磁盘读速率</source>
        <translation type="unfinished">Velocidad lectura disco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="305"/>
        <source>磁盘写速率</source>
        <translation type="unfinished">Velocidad escritura disco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="306"/>
        <source>连接数</source>
        <translation type="unfinished">Núm. de conexiones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="307"/>
        <source>对时状态</source>
        <translation type="unfinished">Estado de sincronización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/main.cpp" line="39"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/pluginresmonitor.cpp" line="57"/>
        <source>资源监视</source>
        <translation type="unfinished">Monitoreo de recursos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="14"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="15"/>
        <source>收：</source>
        <translation type="unfinished">Recibir:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="16"/>
        <source>送：</source>
        <translation type="unfinished">Entregar:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="17"/>
        <source>发：</source>
        <translation type="unfinished">Enviar:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="18"/>
        <source>转发：</source>
        <translation type="unfinished">Reenviar:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="19"/>
        <source>读：</source>
        <translation type="unfinished">Leer:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="20"/>
        <source>写：</source>
        <translation type="unfinished">Escribir:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="21"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="22"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="23"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="24"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="25"/>
        <source>当前值：</source>
        <translation type="unfinished">Valor actual:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_csv_info.cpp" line="234"/>
        <source>内存(KB)</source>
        <translation type="unfinished">Memoria (KB)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_csv_info.cpp" line="238"/>
        <source>内存(MB)</source>
        <translation type="unfinished">Memoria (MB)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_csv_info.cpp" line="242"/>
        <source>句柄</source>
        <translation type="unfinished">Manejador</translation>
    </message>
</context>
<context>
    <name>choos_tool_time</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/choos_tool_time.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished">Diálogo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/choos_tool_time.ui" line="20"/>
        <source>工具进程选取时间范围：</source>
        <translation type="unfinished">Rango de tiempo para procesos de herramienta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/choos_tool_time.ui" line="30"/>
        <source>开始时间：</source>
        <translation type="unfinished">Hora de inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/choos_tool_time.ui" line="40"/>
        <source>结束时间：</source>
        <translation type="unfinished">Hora de fin:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/choos_tool_time.ui" line="69"/>
        <source>设置全部节点</source>
        <translation type="unfinished">Configurar todos los nodos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/choos_tool_time.ui" line="76"/>
        <source>设置当前节点</source>
        <translation type="unfinished">Configurar nodo actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/choos_tool_time.ui" line="83"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/choos_tool_time.cpp" line="21"/>
        <source>时间设置</source>
        <translation type="unfinished">Config. de tiempo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/choos_tool_time.cpp" line="37"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/choos_tool_time.cpp" line="37"/>
        <source>时间选择错误</source>
        <translation type="unfinished">Error en selección de tiempo</translation>
    </message>
</context>
<context>
    <name>config_para</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="66"/>
        <source>重新加载</source>
        <translation type="unfinished">Recargar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="73"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="98"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="199"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="521"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="912"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1058"/>
        <source>是否采样：</source>
        <translation type="unfinished">¿Muestrear?:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="120"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="152"/>
        <source>转发流量</source>
        <translation type="unfinished">Tráfico reenviado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="130"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="259"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="581"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="951"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1090"/>
        <source>告警阈值：</source>
        <translation type="unfinished">Umbral de alerta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="183"/>
        <source>转发数据包</source>
        <translation type="unfinished">Paquetes reenviados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="221"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="281"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="543"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="603"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="796"/>
        <source>CPU</source>
        <translation type="unfinished">CPU</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="228"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="312"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="550"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="634"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="827"/>
        <source>内存</source>
        <translation type="unfinished">Memoria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="235"/>
        <source>网络流量</source>
        <translation type="unfinished">Tráfico de red</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="242"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="941"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="973"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1080"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1112"/>
        <source>磁盘值</source>
        <translation type="unfinished">Valor de disco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="249"/>
        <source>节点句柄</source>
        <translation type="unfinished">Manejador de nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="343"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="557"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="665"/>
        <source>网络</source>
        <translation type="unfinished">Red</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="374"/>
        <source>磁盘</source>
        <translation type="unfinished">Disco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="405"/>
        <source>句柄</source>
        <translation type="unfinished">Manejador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="421"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="843"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1020"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1128"/>
        <source>预警：</source>
        <translation type="unfinished">Advertencia:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="443"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="865"/>
        <source>内存预警</source>
        <translation type="unfinished">Advertencia memoria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="474"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1042"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1150"/>
        <source>容量预警</source>
        <translation type="unfinished">Advertencia capacidad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="505"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="896"/>
        <source>句柄预警</source>
        <translation type="unfinished">Advertencia manejador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="564"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="727"/>
        <source>磁盘速率</source>
        <translation type="unfinished">Velocidad de disco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="571"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="758"/>
        <source>进程句柄</source>
        <translation type="unfinished">Manejador de proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="696"/>
        <source>数据包</source>
        <translation type="unfinished">Paquetes de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="774"/>
        <source>配额：</source>
        <translation type="unfinished">Cuota:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="934"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1004"/>
        <source>连接数</source>
        <translation type="unfinished">Núm. de conexiones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1181"/>
        <source>采样周期</source>
        <translation type="unfinished">Ciclo de muestreo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1212"/>
        <source>写历史周期</source>
        <translation type="unfinished">Ciclo escritura histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1243"/>
        <source>告警间隔</source>
        <translation type="unfinished">Intervalo de alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1274"/>
        <source>资源检查周期</source>
        <translation type="unfinished">Ciclo de chequeo recursos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1305"/>
        <source>预警计算周期</source>
        <translation type="unfinished">Ciclo cálculo advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1349"/>
        <source>新建</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1356"/>
        <source>编辑</source>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1363"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1381"/>
        <source>默认监视文件</source>
        <translation type="unfinished">Archivos monitoreados por defecto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1393"/>
        <source>资源监视服务</source>
        <translation type="unfinished">Servicio de monitoreo recursos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1405"/>
        <source>文件</source>
        <translation type="unfinished">Archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1417"/>
        <source>数据库</source>
        <translation type="unfinished">Base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1429"/>
        <source>进程</source>
        <translation type="unfinished">Proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1441"/>
        <source>节点</source>
        <translation type="unfinished">Nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.ui" line="1453"/>
        <source>现场</source>
        <translation type="unfinished">Sitio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.cpp" line="403"/>
        <source>参数保存失败！</source>
        <translation type="unfinished">¡Fallo al guardar parámetros!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.cpp" line="407"/>
        <source>参数保存成功！</source>
        <translation type="unfinished">¡Parámetros guardados con éxito!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.cpp" line="410"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.cpp" line="450"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.cpp" line="443"/>
        <source>参数加载失败！</source>
        <translation type="unfinished">¡Fallo al cargar parámetros!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/config_para.cpp" line="447"/>
        <source>参数加载成功！</source>
        <translation type="unfinished">¡Parámetros cargados con éxito!</translation>
    </message>
</context>
<context>
    <name>my_res_charts_tips</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1782"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1789"/>
        <source>时间点： %1</source>
        <translation type="unfinished">Punto de tiempo: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1783"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1790"/>
        <source>当前值： %1</source>
        <translation type="unfinished">Valor actual: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1791"/>
        <source>最大值： %1</source>
        <translation type="unfinished">Valor máximo: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1792"/>
        <source>最小值： %1</source>
        <translation type="unfinished">Valor mínimo: %1</translation>
    </message>
</context>
<context>
    <name>para_file_path</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.ui" line="51"/>
        <source>新增</source>
        <translation type="unfinished">Añadir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.ui" line="58"/>
        <source>编辑</source>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.ui" line="65"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="26"/>
        <source>序号</source>
        <translation type="unfinished">Número de serie</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="26"/>
        <source>目录名</source>
        <translation type="unfinished">Nombre de directorio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="26"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="26"/>
        <source>相对路径</source>
        <translation type="unfinished">Ruta relativa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="42"/>
        <source>删除文件目录</source>
        <translation type="unfinished">Eliminar directorio de archivos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="43"/>
        <source>新增文件目录</source>
        <translation type="unfinished">Añadir directorio de archivos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="44"/>
        <source>编辑文件目录</source>
        <translation type="unfinished">Editar directorio de archivos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="118"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="122"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="132"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="150"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="154"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="162"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="209"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="213"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="223"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="253"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="257"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="118"/>
        <source>文件路径添加成功</source>
        <translation type="unfinished">Ruta de archivo añadida con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="122"/>
        <source>文件路径添加失败，请检查数据连接</source>
        <translation type="unfinished">Fallo al añadir ruta, verifique conexión BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="132"/>
        <source>当前界面无数据，删除无效</source>
        <translation type="unfinished">Sin datos en interfaz, eliminación inválida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="150"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Seleccione datos para operar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="154"/>
        <source>是否删除</source>
        <translation type="unfinished">¿Eliminar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="209"/>
        <source>文件路径删除失败，请检查数据连接</source>
        <translation type="unfinished">Fallo al eliminar ruta, verifique conexión BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="213"/>
        <source>文件路径删除成功</source>
        <translation type="unfinished">Ruta de archivo eliminada con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="253"/>
        <source>文件路径编辑成功</source>
        <translation type="unfinished">Ruta de archivo editada con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="257"/>
        <source>文件路径编辑失败，请检查数据连接</source>
        <translation type="unfinished">Fallo al editar ruta, verifique conexión BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="163"/>
        <source>是否删除所有节点的同路径的相关资源数据？</source>
        <translation type="unfinished">¿Eliminar datos de recursos de misma ruta?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="223"/>
        <source>请选中需要编辑的行！</source>
        <translation type="unfinished">¡Seleccione fila a editar!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/para_file_path.cpp" line="229"/>
        <source>编辑文件</source>
        <translation type="unfinished">Editar archivo</translation>
    </message>
</context>
<context>
    <name>rec_date_select</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="39"/>
        <source>开始日期</source>
        <translation type="unfinished">Fecha de inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="42"/>
        <source>截止日期</source>
        <translation type="unfinished">Fecha límite</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="43"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="44"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="83"/>
        <source>读取日期</source>
        <translation type="unfinished">Fecha de lectura</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="84"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="101"/>
        <source>选择读取日期</source>
        <translation type="unfinished">Seleccionar fecha de lectura</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/com_widget.cpp" line="100"/>
        <source>起止日期:</source>
        <translation type="unfinished">Fecha inicio-fin:</translation>
    </message>
</context>
<context>
    <name>res_charts</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.ui" line="35"/>
        <source>资源参数配置：</source>
        <translation type="unfinished">Config. de parámetros de recursos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.ui" line="42"/>
        <source>是否采样</source>
        <translation type="unfinished">¿Muestrear?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.ui" line="64"/>
        <source>告警阈值</source>
        <translation type="unfinished">Umbral de alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.ui" line="95"/>
        <source>预警值</source>
        <translation type="unfinished">Valor de advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.ui" line="126"/>
        <source>配额</source>
        <translation type="unfinished">Cuota</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.ui" line="155"/>
        <source>重新加载</source>
        <translation type="unfinished">Recargar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.ui" line="162"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.ui" line="203"/>
        <source>实时</source>
        <translation type="unfinished">Tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.ui" line="210"/>
        <source>日度</source>
        <translation type="unfinished">Diario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.ui" line="217"/>
        <source>月统计</source>
        <translation type="unfinished">Estadísticas mensuales</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.ui" line="224"/>
        <source>月曲线</source>
        <translation type="unfinished">Curva mensual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.ui" line="234"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="81"/>
        <source>前一天</source>
        <translation type="unfinished">Día anterior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="83"/>
        <source>查看表格数据</source>
        <translation type="unfinished">Ver datos de tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="118"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="122"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="728"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="739"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="788"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="849"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="860"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="892"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1184"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1336"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="560"/>
        <source>当前值：</source>
        <translation type="unfinished">Valor actual:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="118"/>
        <source>获取参数对象失败，重新加载参数失败</source>
        <translation type="unfinished">Fallo al obtener obj. param., recarga falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="122"/>
        <source>重新加载参数成功</source>
        <translation type="unfinished">Recarga de parámetros exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="728"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="849"/>
        <source>进程历史数据查询失败</source>
        <translation type="unfinished">Fallo al consultar datos hist. de proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="739"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="860"/>
        <source>进程历史信息查询失败</source>
        <translation type="unfinished">Fallo al consultar info. hist. de proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="788"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="892"/>
        <source>历史数据查询失败</source>
        <translation type="unfinished">Fallo al consultar datos históricos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1184"/>
        <source>获取参数对象失败，保存参数失败</source>
        <translation type="unfinished">Fallo al obtener obj. param., guardar falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1336"/>
        <source>修改参数成功</source>
        <translation type="unfinished">Parámetro modificado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1536"/>
        <source>采样数据</source>
        <translation type="unfinished">Datos muestreados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1543"/>
        <source>无数据</source>
        <translation type="unfinished">Sin datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1550"/>
        <source>采集对象标识</source>
        <translation type="unfinished">ID de objeto recolectado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1550"/>
        <source>采集指标</source>
        <translation type="unfinished">Indicador recolectado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1550"/>
        <source>采集值</source>
        <translation type="unfinished">Valor recolectado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1550"/>
        <source>单位</source>
        <translation type="unfinished">Unidad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1550"/>
        <source>采集值占比(%)</source>
        <translation type="unfinished">Porcentaje de valor recolectado (%)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_charts.cpp" line="1551"/>
        <source>采集时间</source>
        <translation type="unfinished">Tiempo de recolección</translation>
    </message>
</context>
<context>
    <name>res_csv_info</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_csv_info.cpp" line="22"/>
        <source>内存</source>
        <translation type="unfinished">Memoria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_csv_info.cpp" line="30"/>
        <source>句柄数</source>
        <translation type="unfinished">Núm. de manejadores</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_csv_info.cpp" line="67"/>
        <source>查看表格数据</source>
        <translation type="unfinished">Ver datos de tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_csv_info.cpp" line="208"/>
        <source>采样数据</source>
        <translation type="unfinished">Datos muestreados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_csv_info.cpp" line="213"/>
        <source>进程PID</source>
        <translation type="unfinished">PID de proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_csv_info.cpp" line="213"/>
        <source>指标</source>
        <translation type="unfinished">Indicador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_csv_info.cpp" line="213"/>
        <source>采集值</source>
        <translation type="unfinished">Valor recolectado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_csv_info.cpp" line="213"/>
        <source>采集时间</source>
        <translation type="unfinished">Tiempo de recolección</translation>
    </message>
</context>
<context>
    <name>res_file_table</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.ui" line="63"/>
        <source>添加文件</source>
        <translation type="unfinished">Agregar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.ui" line="70"/>
        <source>添加文件夹</source>
        <translation type="unfinished">Agregar carpeta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.ui" line="77"/>
        <source>大文件管理</source>
        <translation type="unfinished">Gestión de archivos grandes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.ui" line="84"/>
        <source>资源可用性分析</source>
        <translation type="unfinished">Análisis de disponibilidad de recursos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="60"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="60"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="95"/>
        <source>序号</source>
        <translation type="unfinished">Número de serie</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="95"/>
        <source>目录名</source>
        <translation type="unfinished">Nombre de directorio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="95"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="95"/>
        <source>路径</source>
        <translation type="unfinished">Ruta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="95"/>
        <source>是否为绝对路径</source>
        <translation type="unfinished">¿Ruta absoluta?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="95"/>
        <source>目录大小（MB）</source>
        <translation type="unfinished">Tamaño de directorio (MB)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="95"/>
        <source>创建时间</source>
        <translation type="unfinished">Fecha de creación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="107"/>
        <source>增加监视文件目录</source>
        <translation type="unfinished">Añadir directorio monitoreado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="109"/>
        <source>删除监视文件目录</source>
        <translation type="unfinished">Eliminar directorio monitoreado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="110"/>
        <source>大文件查找</source>
        <translation type="unfinished">Búsqueda de archivos grandes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="112"/>
        <source>刷新文件数据</source>
        <translation type="unfinished">Actualizar datos de archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="176"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="251"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="271"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="277"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="281"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="176"/>
        <source>文件增加失败，请检查数据库是否正常.</source>
        <translation type="unfinished">Fallo al añadir archivo, verifique BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="183"/>
        <source>选择文件夹</source>
        <translation type="unfinished">Seleccionar carpeta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="189"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="189"/>
        <source>文件夹新增失败！</source>
        <translation type="unfinished">¡Fallo al añadir carpeta!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="251"/>
        <source>是否删除</source>
        <translation type="unfinished">¿Eliminar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="271"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Seleccione datos para operar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="281"/>
        <source>删除文件目录成功</source>
        <translation type="unfinished">Eliminación de directorio exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_file_table.cpp" line="277"/>
        <source>删除文件目录失败，请检查数据库是否正常</source>
        <translation type="unfinished">Fallo al eliminar dir., verifique BD</translation>
    </message>
</context>
<context>
    <name>res_info</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="44"/>
        <source>异常告警</source>
        <translation type="unfinished">Alerta de anomalía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="58"/>
        <source>CPU</source>
        <translation type="unfinished">CPU</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="65"/>
        <source>内存</source>
        <translation type="unfinished">Memoria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="72"/>
        <source>网络</source>
        <translation type="unfinished">Red</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="74"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="82"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="430"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="446"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="479"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="498"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="517"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="823"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="862"/>
        <source>发:</source>
        <translation type="unfinished">Enviar:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="75"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="83"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="432"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="448"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="481"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="500"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="519"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="824"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="863"/>
        <source>收:</source>
        <translation type="unfinished">Recibir:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="80"/>
        <source>包吞吐量</source>
        <translation type="unfinished">Rendimiento de paquetes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="88"/>
        <source>句柄数</source>
        <translation type="unfinished">Núm. de manejadores</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="95"/>
        <source>磁盘速率</source>
        <translation type="unfinished">Velocidad de disco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="97"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="462"/>
        <source>读:</source>
        <translation type="unfinished">Leer:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="98"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="464"/>
        <source>写:</source>
        <translation type="unfinished">Escribir:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="103"/>
        <source>连接数</source>
        <translation type="unfinished">Núm. de conexiones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="110"/>
        <source>磁盘容量</source>
        <translation type="unfinished">Capacidad de disco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="806"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="815"/>
        <source>跨现场流量：%1</source>
        <translation type="unfinished">Tráfico entre sitios: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="845"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info.cpp" line="854"/>
        <source>跨现场包率：%1</source>
        <translation type="unfinished">Tasa de paquetes entre sitios: %1</translation>
    </message>
</context>
<context>
    <name>res_info_table</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="50"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="59"/>
        <source>序号</source>
        <translation type="unfinished">Número de serie</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="50"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="50"/>
        <source>注册名</source>
        <translation type="unfinished">Nombre registrado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="50"/>
        <source>进程号</source>
        <translation type="unfinished">Número de proceso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="50"/>
        <source>CPU利用率</source>
        <translation type="unfinished">Uso de CPU</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="50"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="51"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="52"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="53"/>
        <source>单位</source>
        <translation type="unfinished">Unidad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="50"/>
        <source>内存值</source>
        <translation type="unfinished">Valor de memoria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="51"/>
        <source>句柄数</source>
        <translation type="unfinished">Núm. de manejadores</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="51"/>
        <source>网络接收流量</source>
        <translation type="unfinished">Tráfico de red recibido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="51"/>
        <source>网络发送流量</source>
        <translation type="unfinished">Tráfico de red enviado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="52"/>
        <source>网络收包率</source>
        <translation type="unfinished">Tasa de recepción paquetes red</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="52"/>
        <source>网络发包率</source>
        <translation type="unfinished">Tasa de envío paquetes red</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="52"/>
        <source>磁盘读速率</source>
        <translation type="unfinished">Velocidad lectura disco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="53"/>
        <source>磁盘写速率</source>
        <translation type="unfinished">Velocidad escritura disco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="59"/>
        <source>库信息</source>
        <translation type="unfinished">Info. de BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="59"/>
        <source>表名</source>
        <translation type="unfinished">Nombre de tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="59"/>
        <source>表容量</source>
        <translation type="unfinished">Capacidad de tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="59"/>
        <source>表记录数</source>
        <translation type="unfinished">Núm. de registros tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="59"/>
        <source>表余量</source>
        <translation type="unfinished">Sobrante de tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="60"/>
        <source>余量占比（%）</source>
        <translation type="unfinished">Porcentaje sobrante (%)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="186"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="186"/>
        <source>获取节点实时库信息失败!</source>
        <translation type="unfinished">¡Fallo al obtener info. BD real de nodo!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="244"/>
        <source>维护库</source>
        <translation type="unfinished">BD de mantenimiento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_info_table.cpp" line="244"/>
        <source>运行库</source>
        <translation type="unfinished">BD de ejecución</translation>
    </message>
</context>
<context>
    <name>res_mainwindows</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.ui" line="73"/>
        <source>数据时间范围：</source>
        <translation type="unfinished">Rango de tiempo de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.ui" line="80"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="969"/>
        <source>开始时间</source>
        <translation type="unfinished">Hora de inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.ui" line="90"/>
        <source>结束时间</source>
        <translation type="unfinished">Hora de fin</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.ui" line="113"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.ui" line="120"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="120"/>
        <source>刷新</source>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="119"/>
        <source>设置读取CSV日期</source>
        <translation type="unfinished">Config. fecha lectura CSV</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="121"/>
        <source>设置读取历史日期</source>
        <translation type="unfinished">Config. fecha lectura histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="161"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="174"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="771"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="1087"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="1197"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="161"/>
        <source>资源监视数据库打开失败，只显示本地资源采样数据</source>
        <translation type="unfinished">Fallo al abrir BD monit., solo datos locales</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="174"/>
        <source>资源监视历史库打开失败，历史数据查询受限</source>
        <translation type="unfinished">Fallo al abrir BD hist. monit., consulta limitada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="292"/>
        <source>参数配置</source>
        <translation type="unfinished">Parámetros</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="295"/>
        <source>资源参数配置</source>
        <translation type="unfinished">Config. de parámetros de recursos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="298"/>
        <source>默认监视文件</source>
        <translation type="unfinished">Archivos monitoreados por defecto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="322"/>
        <source>本地信息</source>
        <translation type="unfinished">Info. local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="489"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="492"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="1230"/>
        <source>核心进程</source>
        <translation type="unfinished">Procesos core</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="495"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="498"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="1233"/>
        <source>服务进程</source>
        <translation type="unfinished">Procesos de servicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="501"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="504"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="1236"/>
        <source>工具进程</source>
        <translation type="unfinished">Procesos de herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="507"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="510"/>
        <source>核心实时库</source>
        <translation type="unfinished">BD core en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="513"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="516"/>
        <source>应用实时库</source>
        <translation type="unfinished">BD de app en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="519"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="520"/>
        <source>历史数据库</source>
        <translation type="unfinished">BDH</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="523"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="525"/>
        <source>文件系统</source>
        <translation type="unfinished">Sistema de archivos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="675"/>
        <source>运行库</source>
        <translation type="unfinished">BD de ejecución</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="683"/>
        <source>维护库</source>
        <translation type="unfinished">BD de mantenimiento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="772"/>
        <source>全局参数存在修改，是否进行数据保存？</source>
        <translation type="unfinished">¿Guardar cambios en parámetros globales?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="967"/>
        <source>进程选取时间范围</source>
        <translation type="unfinished">Rango de tiempo selección procesos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="979"/>
        <source>文本选取时间范围</source>
        <translation type="unfinished">Rango de tiempo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="981"/>
        <source>读取日期</source>
        <translation type="unfinished">Fecha de lectura</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="1087"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="1197"/>
        <source>当前时间内无法查询到该程序</source>
        <translation type="unfinished">No hay datos de programa en tiempo actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_mainwindows.cpp" line="1390"/>
        <source>工具进程 [%1 - %2]</source>
        <translation type="unfinished">Procesos herramienta [%1 - %2]</translation>
    </message>
</context>
<context>
    <name>res_warn_info</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_warn_info.cpp" line="30"/>
        <source>异常信息</source>
        <translation type="unfinished">Info. de anomalía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_warn_info.cpp" line="242"/>
        <source>告警时间</source>
        <translation type="unfinished">Tiempo de alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_warn_info.cpp" line="242"/>
        <source>告警节点</source>
        <translation type="unfinished">Nodo de alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_warn_info.cpp" line="242"/>
        <source>告警对象</source>
        <translation type="unfinished">Objeto de alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/res_warn_info.cpp" line="242"/>
        <source>告警信息</source>
        <translation type="unfinished">Info. de alerta</translation>
    </message>
</context>
<context>
    <name>warn_query_wg</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished">Formulario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.ui" line="23"/>
        <source>开始：</source>
        <translation type="unfinished">Inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.ui" line="33"/>
        <source>结束：</source>
        <translation type="unfinished">Fin:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.ui" line="43"/>
        <source>告警项：</source>
        <translation type="unfinished">Ítems de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.ui" line="53"/>
        <source>告警节点：</source>
        <translation type="unfinished">Nodo de alarma:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.ui" line="76"/>
        <source>查询</source>
        <translation type="unfinished">Consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="60"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="65"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="126"/>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="158"/>
        <source>提示</source>
        <translation type="unfinished">Consejo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="60"/>
        <source>日期选择错误</source>
        <translation type="unfinished">Error en selec. de fecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="65"/>
        <source>告警类型为空，无法进行告警查询</source>
        <translation type="unfinished">Tipo de alarma vacío, no se puede consultar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="126"/>
        <source>查询失败，请检查历史数据服务是否正常</source>
        <translation type="unfinished">Consulta falló, revise servicio de datos hist.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="158"/>
        <source>历史告警查询成功</source>
        <translation type="unfinished">Consulta de alarma hist. exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="211"/>
        <source>所有告警类型</source>
        <translation type="unfinished">Todos los tipos de alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_ops_resmonitor/warn_query_wg.cpp" line="260"/>
        <source>本现场所有节点</source>
        <translation type="unfinished">Todos los nodos en sitio</translation>
    </message>
</context>
</TS>
