<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>Destfile</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/destfile.cpp" line="52"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/destfile.cpp" line="56"/>
        <source>选择路径</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Seleccionar ruta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/destfile.cpp" line="53"/>
        <source>选择路径</source>
        <translation type="unfinished">Seleccione ruta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/destfile.ui" line="112"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/destfile.ui" line="138"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/destfile.ui" line="212"/>
        <source>目标路径：</source>
        <translation type="unfinished">Ruta objetivo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/destfile.cpp" line="63"/>
        <source>选择旧库</source>
        <translation type="unfinished">Seleccionar base de datos antigua</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/destfile.h" line="72"/>
        <source>旧库文件选择</source>
        <translation type="unfinished">Seleccionar archivo de base de datos antigua</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="115"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1230"/>
        <source> 参数配置：</source>
        <translation type="unfinished">Configuración de parámetros:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="132"/>
        <source>保留动态元数据</source>
        <translation type="unfinished">Preservar metadatos dinámicos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="196"/>
        <source>迁移方式：   </source>
        <translation type="unfinished">Modo de migración:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="341"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="87"/>
        <source>旧库文件夹：</source>
        <translation type="unfinished">Carpeta de la base de datos antigua:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="303"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="504"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="776"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="220"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="221"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="222"/>
        <source>选择文件</source>
        <translation type="unfinished">Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="571"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="88"/>
        <source>新库文件夹：</source>
        <translation type="unfinished">Nueva carpeta de base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="741"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="89"/>
        <source>目标文件夹：</source>
        <translation type="unfinished">Carpeta de destino:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="966"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1777"/>
        <source>配置信息：</source>
        <translation type="unfinished">Información de configuración:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1020"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="223"/>
        <source>生成配置</source>
        <translation type="unfinished">Generar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1129"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="2003"/>
        <source>消息日志：</source>
        <translation type="unfinished">Registro de mensajes:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1148"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="224"/>
        <source>开始迁移</source>
        <translation type="unfinished">Migrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1291"/>
        <source>节点：</source>
        <translation type="unfinished">Nodo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1338"/>
        <source>应用名：</source>
        <translation type="unfinished">Nombre de la aplicación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1369"/>
        <source>库  名：</source>
        <translation type="unfinished">Nombre de la base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1405"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1662"/>
        <source>获取配置</source>
        <translation type="unfinished">Configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1434"/>
        <source>下载</source>
        <translation type="unfinished">Descargar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.ui" line="1463"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1663"/>
        <source>扩容迁移</source>
        <translation type="unfinished">Expandir &amp;&amp; Migrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="331"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="574"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="828"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2086"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2107"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2626"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2720"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="74"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="681"/>
        <source>旧库文件夹不能为空</source>
        <translation type="unfinished">La carpeta de la base de datos antigua no puede estar vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="75"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="690"/>
        <source>新库文件夹不能为空</source>
        <translation type="unfinished">La nueva base de datos no puede estar vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="76"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="698"/>
        <source>目标文件夹不能为空</source>
        <translation type="unfinished">La carpeta de destino no puede estar vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="83"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="84"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="85"/>
        <source>请输入内容</source>
        <translation type="unfinished">Por favor, ingrese contenido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="86"/>
        <source>迁移方式：</source>
        <translation type="unfinished">Modo de migración:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="93"/>
        <source>应用名不能为空</source>
        <translation type="unfinished">¡El nombre de la aplicación no puede estar vacío!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="94"/>
        <source>库名不能为空</source>
        <translation type="unfinished">El nombre de la base de datos no puede estar vacío.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="99"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1833"/>
        <source>库大小：0(M)</source>
        <translation type="unfinished">Tamaño de la base de datos: 0(M)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="148"/>
        <source>创建空库</source>
        <translation type="unfinished">Nueva base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="149"/>
        <source>保留oid</source>
        <translation type="unfinished">Oid reservado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="150"/>
        <source>初始化oid</source>
        <translation type="unfinished">Inicializar Oid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="183"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1646"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1653"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="184"/>
        <source>库信息总览</source>
        <translation type="unfinished">Resumen de información de la base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="185"/>
        <source>导入配置</source>
        <translation type="unfinished">Importar configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="186"/>
        <source>导出配置</source>
        <translation type="unfinished">Exportar configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="195"/>
        <source>全部清除</source>
        <translation type="unfinished">Borrar todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="552"/>
        <source>迁移成功，是否重启应用？</source>
        <translation type="unfinished">Si la migración es exitosa, reinicie la aplicación.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="626"/>
        <source>重启失败</source>
        <translation type="unfinished">Reinicio fallido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="633"/>
        <source>节点启动完成</source>
        <translation type="unfinished">Inicio del nodo completado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="142"/>
        <source>迁移升级</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="143"/>
        <source>迁移扩容</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Expansión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="231"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="234"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="237"/>
        <source>选择文件</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="241"/>
        <source>生成配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Generar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="242"/>
        <source>开始迁移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Migrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="330"/>
        <source>升级前，需停止除核心平台(系统管理、系统运维)外的应用系统</source>
        <translation type="unfinished">Antes de actualizar, todos los sistemas de aplicaciones, excepto la plataforma central (gestión del sistema, operación y maint. del sistema), deben ser detenidos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="342"/>
        <source>节点【{%1}】下所有普通应用取消停止</source>
        <translation type="unfinished">Cancelar la detención de todas las aplicaciones regulares bajo el nodo [{%1}]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="468"/>
        <source>迁移结束</source>
        <translation type="unfinished">Migración completada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="492"/>
        <source>迁移失败，是否重启应用？</source>
        <translation type="unfinished">La migración falló, ¿desea reiniciar la aplicación?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="781"/>
        <source>选择目标路径</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar Ruta de Destino</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="828"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2107"/>
        <source>是否覆盖，重新生成</source>
        <translation type="unfinished">¿Desea sobrescribir y regenerar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="900"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1133"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1212"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1542"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2176"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2516"/>
        <source>库大小：</source>
        <translation type="unfinished">Tamaño de la base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="901"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1134"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1213"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1543"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2178"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2517"/>
        <source>(M)</source>
        <translation type="unfinished">(M)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="580"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="834"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1017"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1169"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1260"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1527"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2092"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2113"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2632"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2726"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="359"/>
        <source>停止中......请等待</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="456"/>
        <source>升级中......请等待</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="581"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="835"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1026"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1031"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1037"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1173"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1264"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1531"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2093"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2114"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2633"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2727"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="604"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2657"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2754"/>
        <source>重启应用中......请等待</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1105"/>
        <source>获取配置文件</source>
        <translation type="unfinished">Obtener archivo de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1333"/>
        <source>表ID</source>
        <translation type="unfinished">ID de tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1333"/>
        <source>表名</source>
        <translation type="unfinished">Nombre de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1333"/>
        <source>数据大小[K]</source>
        <translation type="unfinished">Tamaño de datos [K]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1668"/>
        <source>获取配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1670"/>
        <source>扩容迁移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Expandir/Migrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1887"/>
        <source>实例号</source>
        <translation type="unfinished">Número de instancia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1887"/>
        <source>应用描述</source>
        <translation type="unfinished">Descripción de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1887"/>
        <source>节点名</source>
        <translation type="unfinished">Nombre del nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1887"/>
        <source>临时本地旧库路径</source>
        <translation type="unfinished">Base de datos temporal local antigua ruta	</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1887"/>
        <source>临时本地新库路径</source>
        <translation type="unfinished">Ruta temporal de nueva base de datos local</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1888"/>
        <source>旧维护库路径</source>
        <translation type="unfinished">Ruta de la base de datos antigua MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1888"/>
        <source>新维护库路径</source>
        <translation type="unfinished">Nueva ruta de MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2021"/>
        <source>下载中......请等待</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2148"/>
        <source>加载中......请等待</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2603"/>
        <source>发布中......请等待</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2048"/>
        <source>下载结束失败原因：</source>
        <translation type="unfinished">Razón del fallo de descarga:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2085"/>
        <source>扩容前，需停止除核心平台(系统管理、系统运维)外的应用系统</source>
        <translation type="unfinished">Antes de la expansión, todos los sistemas de aplicación excepto la plataforma central (gestión del sistema, operación y maint. del sistema) deben detenerse</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2058"/>
        <source>数据库下载结束</source>
        <translation type="unfinished">Descarga de la base de datos completada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1573"/>
        <source>基础配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Config Básica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1574"/>
        <source>循环表配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Tabla de Bucle de Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="1575"/>
        <source>扩容库列表</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Lista de BD Ampliada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2233"/>
        <source>循环父表名称</source>
        <translation type="unfinished">Nombre de tabla principal del bucle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2233"/>
        <source>循环父端关联字段</source>
        <translation type="unfinished">Campo vinculado del padre del bucle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2233"/>
        <source>循环父表容量</source>
        <translation type="unfinished">Capacidad de tabla principal de bucle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2233"/>
        <source>循环子对象个数</source>
        <translation type="unfinished">Cantidad de subobjetos del bucle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2234"/>
        <source>循环子表名称</source>
        <translation type="unfinished">Nombre de subtabla de bucle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2234"/>
        <source>循环子表容量</source>
        <translation type="unfinished">Capacidad de subtabla de bucle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2234"/>
        <source>字段ID</source>
        <translation type="unfinished">ID de campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2624"/>
        <source>扩容失败</source>
        <translation type="unfinished">Expansión fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2626"/>
        <source>扩容失败，是否重启应用？</source>
        <translation type="unfinished">La expansión falló, ¿desea reiniciar la aplicación?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="2720"/>
        <source>扩容完成，是否重启应用？</source>
        <translation type="unfinished">Si la expansión es exitosa, reinicie la aplicación.</translation>
    </message>
</context>
<context>
    <name>NewFile</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="95"/>
        <source>选择路径</source>
        <translation type="unfinished">Seleccione ruta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="20"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="113"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="20"/>
        <source>旧库路径有误</source>
        <translation type="unfinished">La ruta de la base de datos original es incorrecta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="52"/>
        <source>新库文件选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar Nuevos Archivos de BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="131"/>
        <source>选择新库</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar Nueva Base de Datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="93"/>
        <source>输入非负整数如:8</source>
        <translation type="unfinished">Ingrese un número entero no negativo, como 8</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="98"/>
        <source>选择路径</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Seleccionar ruta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.cpp" line="113"/>
        <source>路径无效</source>
        <translation type="unfinished">Ruta no válida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.ui" line="69"/>
        <source>库版本号：</source>
        <translation type="unfinished">Versión de la biblioteca No.:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.ui" line="133"/>
        <source>新库路径：</source>
        <translation type="unfinished">Nueva ruta de la biblioteca:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.ui" line="287"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/newfile.ui" line="321"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>OldFile</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.ui" line="84"/>
        <source>文件路径：</source>
        <translation type="unfinished">Ruta del archivo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.ui" line="181"/>
        <source>库模式：</source>
        <translation type="unfinished">Modo de base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.ui" line="243"/>
        <source> 应用名：</source>
        <translation type="unfinished">Nombre de la aplicación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.ui" line="277"/>
        <source>态：</source>
        <translation type="unfinished">Modo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.ui" line="314"/>
        <source>实例号：</source>
        <translation type="unfinished">Número de instancia:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.ui" line="362"/>
        <source> 库名：</source>
        <translation type="unfinished">Nombre de la base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.ui" line="496"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.ui" line="528"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.cpp" line="42"/>
        <source>旧库文件选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar Archivos de BD Antiguos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.cpp" line="100"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.cpp" line="101"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.cpp" line="105"/>
        <source>0</source>
        <translation type="unfinished">0</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.cpp" line="109"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.cpp" line="113"/>
        <source>选择路径</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Seleccionar ruta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.cpp" line="110"/>
        <source>选择路径</source>
        <translation type="unfinished">Seleccione ruta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/oldfile.cpp" line="121"/>
        <source>选择旧库</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar Base de Datos Antigua</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/infodbDlg.cpp" line="26"/>
        <source>库信息总览</source>
        <comment>toolName</comment>
        <translation type="unfinished">Resumen de Info de la BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/noticeDlg.cpp" line="83"/>
        <source>信息</source>
        <comment>toolName</comment>
        <translation type="unfinished">Información</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="46"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="64"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="293"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="378"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="414"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="476"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/mainwindow.cpp" line="542"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
</context>
<context>
    <name>Worker</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="124"/>
        <source>开始将库保存在临时目录下</source>
        <translation type="unfinished">Iniciando el guardado de la biblioteca en un directorio temporal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="66"/>
        <source>正在停止节点%1涉及库%2的所有普通应用</source>
        <translation type="unfinished">Deteniendo todas las aplicaciones regulares del nodo %1 que involucran la biblioteca %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="73"/>
        <source>节点%1进程停止失败</source>
        <translation type="unfinished">Falló la detención del proceso del nodo %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="79"/>
        <source>节点%1进程停止成功</source>
        <translation type="unfinished">El proceso del nodo %1 se detuvo exitosamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="111"/>
        <source>开始登录节点%1失败</source>
        <translation type="unfinished">Error al iniciar sesión en el nodo %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="119"/>
        <source>登录节点%1获取配置</source>
        <translation type="unfinished">Iniciar sesión en el nodo %1 para obtener configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="129"/>
        <source>从节点%1远程下载运行库%2至本地%3失败，返回码=%4</source>
        <translation type="unfinished">Desde el nodo %1, la descarga remota de RTDB %2 a local %3 falló con el código de retorno= %4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="139"/>
        <source>从节点%1远程下载运行库%2至本地%3成功</source>
        <translation type="unfinished">Desde el nodo %1, descarga remota de RTDB %2 a local %3 exitosamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="146"/>
        <source>临时文件保存结束，生成初始配置信息中</source>
        <translation type="unfinished">Archivo temporal guardado, generando información de configuración inicial...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="158"/>
        <source>初始配置信息生成结束</source>
        <translation type="unfinished">Generación de información de configuración inicial completada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="170"/>
        <source>节点%1正在启动</source>
        <translation type="unfinished">Nodo %1 está iniciando</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="175"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="207"/>
        <source>节点%1启动失败</source>
        <translation type="unfinished">Falló el inicio del nodo %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="179"/>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="211"/>
        <source>节点%1应用启动成功</source>
        <translation type="unfinished">Aplicación del nodo %1 iniciada con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="277"/>
        <source>登录节点%1失败，下载中止</source>
        <translation type="unfinished">Error al iniciar sesión en el nodo %1, descarga abortada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="345"/>
        <source>从节点%1路径%2下载运行库%3至本地%4失败，返回码=%5</source>
        <translation type="unfinished">Desde el nodo %1 ruta %2, no se pudo descargar RTDB %3 a local %4, código de retorno = %5</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="360"/>
        <source>从节点%1路径%2下载运行库%3至本地%4成功</source>
        <translation type="unfinished">Desde el nodo %1 ruta %2, descargar RTDB %3 a local %4 con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="383"/>
        <source>应用【%1.%2.%3】未部署维护节点</source>
        <translation type="unfinished">La aplicación [%1.%2.%3] no ha desplegado nodos de maint.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="427"/>
        <source>ftp登录维护节点 %1失败，错误信息=%2</source>
        <translation type="unfinished">Falló el inicio de sesión FTP en el nodo de maint. %1 con el mensaje de error = %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="436"/>
        <source>从维护节点%1路径%2下载维护库%3至本地%4失败，错误信息=%5</source>
        <translation type="unfinished">Desde el nodo de maint. %1 ruta %2, no se pudo descargar MTDB %3 a local %4, mensaje de error =%5</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="453"/>
        <source>从维护节点%1路径%2下载维护库%3至本地%4成功</source>
        <translation type="unfinished">Desde el nodo de maint. %1 ruta %2, descargar MTDB %3 a local %4 con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="552"/>
        <source>用户:%1运行库%2迁移扩容失败</source>
        <translation type="unfinished">Usuario: %1 Migración y expansión de RTDB %2 fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="560"/>
        <source>用户:%1 运行库%2迁移扩容成功</source>
        <translation type="unfinished">Usuario:%1 Migración y expansión de RTDB %2 exitosamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="603"/>
        <source>用户:%1 数据库%2从路径%3至%4迁移扩容失败</source>
        <translation type="unfinished">Usuario:%1 Falló la migración y expansión de la BD %2 desde la ruta %3 a %4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="613"/>
        <source>用户:%1 数据库%2从路径%3至%4迁移扩容成功</source>
        <translation type="unfinished">Usuario:%1 Base de datos %2 migrada y expandida desde la ruta %3 a %4 exitosamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="667"/>
        <source>用户:%1路径%2上传%3迁移扩容失败</source>
        <translation type="unfinished">Usuario: %1 Ruta %2 Carga %3 migración y expansión fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="702"/>
        <source>用户:%1 路径%2上传%3扩容迁移完成</source>
        <translation type="unfinished">Usuario: %1 Ruta %2 Carga %3 expansión de capacidad completada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="714"/>
        <source>登录节点%1上传成功</source>
        <translation type="unfinished">Inicio de sesión en el nodo %1 cargado exitosamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="239"/>
        <source>请至少选择一个数据源</source>
        <translation type="unfinished">Por favor, seleccione al menos un origen de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="261"/>
        <source>数据源节点不可为空</source>
        <translation type="unfinished">El nodo de origen de datos no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/Worker.cpp" line="419"/>
        <source>远程登录维护节点【{%1}】</source>
        <translation type="unfinished">Nodo de maint. de inicio de sesión remoto [{%1}]</translation>
    </message>
</context>
<context>
    <name>noticeDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/noticeDlg.cpp" line="58"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
</context>
<context>
    <name>noticeWid</name>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/noticeWid.cpp" line="11"/>
        <source>信息</source>
        <translation type="unfinished">Mensaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/noticeWid.cpp" line="18"/>
        <source>迁移结束</source>
        <translation type="unfinished">Fin de la migración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/plug/tdb_deploy_plug/noticeWid.cpp" line="32"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
</context>
</TS>
