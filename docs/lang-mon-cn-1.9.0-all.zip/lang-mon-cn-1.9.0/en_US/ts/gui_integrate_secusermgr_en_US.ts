<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>ConfigParam</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="55"/>
        <source>密码复杂度：</source>
        <translation type="unfinished">Password complexity:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="70"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="1055"/>
        <source>低（无特殊限制）</source>
        <translation type="unfinished">Low (no special restrictions)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="75"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="1056"/>
        <source>中（6位以上，必须包含数字、大小写字母）</source>
        <translation type="unfinished">Medium (more than 6 characters, must include numbers, upper and lower case letters)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="80"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="1058"/>
        <source>高（8位以上，必须包含数字、大小写字母、特殊字符，且不包含用户名）</source>
        <translation type="unfinished">High (more than 8 characters; must include numbers, uppercase and lowercase letters, special characters, and must not include the username)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="114"/>
        <source>密码有效期（天）：</source>
        <translation type="unfinished">Password validity period (days):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="128"/>
        <source>历史密码个数：</source>
        <translation type="unfinished">History passwords count:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="142"/>
        <source>错误密码重试次数：</source>
        <translation type="unfinished">Incorrect password retries:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="156"/>
        <source>用户锁定时长（秒）：</source>
        <translation type="unfinished">User lockout duration (s):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="279"/>
        <source>密码加密存储</source>
        <translation type="unfinished">Cryptographic storage</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="293"/>
        <source>隐藏登录用户名</source>
        <translation type="unfinished">Hide the login username</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="307"/>
        <source>强制修改初始密码</source>
        <translation type="unfinished">Change the initial password forcibly</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="321"/>
        <source>强制修改过期密码</source>
        <translation type="unfinished">Force change of expired password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="40"/>
        <source>密码配置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Config password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="168"/>
        <source>闲置锁定时长（秒）：</source>
        <translation type="unfinished">Idle lock duration(s):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="351"/>
        <source>认证配置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Auth config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="366"/>
        <source>节点认证方式：</source>
        <translation type="unfinished">Node auth mode:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="378"/>
        <source>登录认证方式：</source>
        <translation type="unfinished">Login auth mode:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="395"/>
        <source>白名单</source>
        <translation type="unfinished">Whitelist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="400"/>
        <source>黑名单</source>
        <translation type="unfinished">Blacklist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="414"/>
        <source>用户名+密码</source>
        <translation type="unfinished">Username + Password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="419"/>
        <source>用户名+密码+UKEY</source>
        <translation type="unfinished">Username + Password + UKEY</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="424"/>
        <source>用户名+密码+指纹</source>
        <translation type="unfinished">Username + Password + Fingerprint</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="456"/>
        <source>启用安全身份认证</source>
        <translation type="unfinished">Enable secure auth</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="468"/>
        <source>启用认证白名单</source>
        <translation type="unfinished">Enable auth whitelist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="489"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="511"/>
        <source>调试配置</source>
        <translation type="unfinished">Debug Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="503"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="525"/>
        <source>工程配置</source>
        <translation type="unfinished">Project config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="518"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="539"/>
        <source>安全配置</source>
        <translation type="unfinished">Security Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="534"/>
        <source>版本</source>
        <translation type="unfinished">Version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="561"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="575"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.ui" line="587"/>
        <source>启用内部安全通讯</source>
        <translation type="unfinished">Enable internal secure communication</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="386"/>
        <source>本模式节点认证方式需设置为：白名单</source>
        <translation type="unfinished">In this mode, the node auth mode must be whitelist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="391"/>
        <source>本模式节点认证方式需设置为：黑名单</source>
        <translation type="unfinished">The node auth method in this mode needs to be set to: blacklist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="432"/>
        <source>本模式登录认证需设置为：仅密码</source>
        <translation type="unfinished">The login auth for this mode needs to be set to: Password only</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="437"/>
        <source>本模式登录认证需设置为：Ukey或指纹认证</source>
        <translation type="unfinished">The login auth for this mode needs to be set to: Ukey or fingerprint auth</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="401"/>
        <source>本模式密码复杂度需设置为：低</source>
        <translation type="unfinished">The password complexity in this mode needs to be set to: Low</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="406"/>
        <source>本模式密码复杂度需设置为：中</source>
        <translation type="unfinished">The password complexity in this mode needs to be set to: Medium</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="411"/>
        <source>本模式密码复杂度需设置为：高</source>
        <translation type="unfinished">The password complexity in this mode needs to be set to: High</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="416"/>
        <source>本模式密码复杂度需设置为：低或中</source>
        <translation type="unfinished">The password complexity in this mode needs to be set to: low or medium</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="421"/>
        <source>本模式密码复杂度需设置为：低或高</source>
        <translation type="unfinished">The password complexity in this mode needs to be set to: low or high</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="426"/>
        <source>本模式密码复杂度需设置为：中或高</source>
        <translation type="unfinished">The password complexity in this mode needs to be set to: Medium or High</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="445"/>
        <source>本模式密码有效天数范围: </source>
        <translation type="unfinished">The password validity period for this mode is:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="454"/>
        <source>本模式设置历史密码保存数量: </source>
        <translation type="unfinished">This mode sets the number of historical passwords to be saved:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="463"/>
        <source>本模式错误密码重试次数范围: </source>
        <translation type="unfinished">The range of wrong password retries in this mode:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="472"/>
        <source>本模式用户锁定时长范围: </source>
        <translation type="unfinished">User lockout duration range for this mode:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="478"/>
        <source>本模式需: 启用密码加密功能</source>
        <translation type="unfinished">This mode requires: Enable password encryption</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="482"/>
        <source>本模式需: 启用隐藏登录用户名功能</source>
        <translation type="unfinished">This mode requires enabling the function to hide the login username.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="486"/>
        <source>本模式需: 启用强制修改初始密码功能</source>
        <translation type="unfinished">This mode requires enabling the forced modification of the initial password.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="490"/>
        <source>本模式需: 启用强制修改过期密码功能</source>
        <translation type="unfinished">This mode requires enabling the forced modification of expired passwords.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="494"/>
        <source>本模式需: 启用认证白名单功能功能</source>
        <translation type="unfinished">In this mode, the auth whitelist function needs to be enabled</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="498"/>
        <source>本模式需: 启用安全身份认证功能</source>
        <translation type="unfinished">This mode requires: Enable secure identity auth function</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="582"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="617"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="652"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="674"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="692"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="713"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="583"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="693"/>
        <source>数据库模板名称与配置文件名称不一致或找不到配置名称为：调试配置、工程配置、安全配置的参数</source>
        <translation type="unfinished">DB template name mismatch or missing params for config names: Debug, Project, and Security.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="609"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="614"/>
        <source>检测到当前设置为：</source>
        <translation type="unfinished">The current setting is detected as:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="610"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="615"/>
        <source> 存在以下设置不符合要求：</source>
        <translation type="unfinished">The following settings do not meet the requirements:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="652"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="675"/>
        <source>安全身份认证已启用，请确保系统管理中已配置了认证服务， 并且用户已设置了认证信息</source>
        <translation type="unfinished">Secure Auth is enabled. Verify that the auth service is configured in Sysmgr and user auth info is complete.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="713"/>
        <source>刷新成功</source>
        <translation type="unfinished">Refresh successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="822"/>
        <source>调试配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Debug config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="823"/>
        <source>工程配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Project config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="824"/>
        <source>安全配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Security config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="920"/>
        <source>切换当前安全配置模式为：</source>
        <translation type="unfinished">Switch security mode:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="920"/>
        <source>保存后将重置相关配置，请确认后继续。</source>
        <translation type="unfinished">After saving, the relevant config will be reset. Please confirm and continue.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/configparam.cpp" line="1049"/>
        <source>8位以上，必须包含数字、大小写字母、特殊字符，且不包含用户名</source>
        <translation type="unfinished">More than 8 characters; must include numbers, uppercase and lowercase letters, special characters, and do not include the username</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secusermgr/plugin_sec_usermgr.cpp" line="45"/>
        <source>用户管理参数配置</source>
        <translation type="unfinished">User management params config</translation>
    </message>
</context>
</TS>
