<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>ApiDynRectTable</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="2020"/>
        <source>尾页</source>
        <translation type="unfinished">Last</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="2060"/>
        <source>下一页</source>
        <translation type="unfinished">Next</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="1933"/>
        <source>跳转</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Jump</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="1732"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="1934"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="4478"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="4679"/>
        <source>跳转</source>
        <translation type="unfinished">Jump</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="2131"/>
        <source>上一页</source>
        <translation type="unfinished">Previous</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="2168"/>
        <source>首页</source>
        <translation type="unfinished">Home</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="3639"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="3643"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="6015"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="6019"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="3639"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="6015"/>
        <source>表格宽度超出限制</source>
        <translation type="unfinished">The width of the table exceeds the limit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="3643"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_dynamics_rect_table.cpp" line="6019"/>
        <source>表格高度超出限制</source>
        <translation type="unfinished">The height of the table exceeds the limit</translation>
    </message>
</context>
<context>
    <name>ApiFunction</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="495"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="508"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="530"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="534"/>
        <source>普通字符</source>
        <translation type="unfinished">General characters</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="496"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="512"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="538"/>
        <source>光敏点</source>
        <translation type="unfinished">Photosensitive point</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="497"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="516"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="542"/>
        <source>数值前景</source>
        <translation type="unfinished">Value foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="498"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="520"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="546"/>
        <source>状态前景</source>
        <translation type="unfinished">State foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="499"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="524"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="550"/>
        <source>字符前景</source>
        <translation type="unfinished">Character foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="500"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="528"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="554"/>
        <source>父对象路径</source>
        <translation type="unfinished">Parent object path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="572"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="581"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="587"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="592"/>
        <source>对象选择</source>
        <translation type="unfinished">Object Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="573"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="585"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="596"/>
        <source>条件检索</source>
        <translation type="unfinished">Search Conditions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="724"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="748"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="758"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="765"/>
        <source>全责区</source>
        <translation type="unfinished">Area of responsibility</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="750"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="769"/>
        <source>责任区1</source>
        <translation type="unfinished">AOR 1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="752"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="773"/>
        <source>责任区2</source>
        <translation type="unfinished">AOR 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="754"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="777"/>
        <source>责任区3</source>
        <translation type="unfinished">AOR 3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="756"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="781"/>
        <source>责任区4</source>
        <translation type="unfinished">AOR 4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="804"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="818"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="844"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="849"/>
        <source>常规图元</source>
        <translation type="unfinished">Regular icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="805"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="822"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="853"/>
        <source>母线图元</source>
        <translation type="unfinished">Bus Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="806"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="826"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="857"/>
        <source>连接线图元</source>
        <translation type="unfinished">Connect Line Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="808"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="834"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="865"/>
        <source>状态前景图元</source>
        <translation type="unfinished">State foreground icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="809"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="838"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="869"/>
        <source>数值前景图元</source>
        <translation type="unfinished">Value foreground icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="810"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="842"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="873"/>
        <source>字符前景图元</source>
        <translation type="unfinished">Character foreground icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="885"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="895"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="900"/>
        <source>普通画面</source>
        <translation type="unfinished">General graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="889"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="904"/>
        <source>动态模板</source>
        <translation type="unfinished">Dynamic template</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="893"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="908"/>
        <source>静态模板</source>
        <translation type="unfinished">Static template</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="926"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="935"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="944"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="948"/>
        <source>打开画面</source>
        <translation type="unfinished">Open graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="927"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="939"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="952"/>
        <source>新建画面</source>
        <translation type="unfinished">New graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="928"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="942"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="956"/>
        <source>调用弹窗</source>
        <translation type="unfinished">Call popup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="976"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="987"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1005"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1010"/>
        <source>替换</source>
        <translation type="unfinished">Replace</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="977"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="991"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1014"/>
        <source>新窗口</source>
        <translation type="unfinished">New window</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="978"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="995"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1018"/>
        <source>分图</source>
        <translation type="unfinished">Sub-graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="979"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="999"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1022"/>
        <source>非模式</source>
        <translation type="unfinished">Non-schema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="980"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1003"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1026"/>
        <source>浮动窗口</source>
        <translation type="unfinished">Floating window</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1037"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1047"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1052"/>
        <source>纯色</source>
        <translation type="unfinished">Solid color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1041"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1056"/>
        <source>渐变</source>
        <translation type="unfinished">Gradation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1045"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1060"/>
        <source>图片</source>
        <translation type="unfinished">Picture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1083"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1131"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1194"/>
        <source>无</source>
        <translation type="unfinished">None</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1084"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1134"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1198"/>
        <source>实线</source>
        <translation type="unfinished">Solid Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1085"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1137"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1202"/>
        <source>虚线</source>
        <translation type="unfinished">Dashed Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1086"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1140"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1206"/>
        <source>点线</source>
        <translation type="unfinished">Dotted Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1087"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1143"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1210"/>
        <source>点划线</source>
        <translation type="unfinished">Dot-dash Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1088"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1146"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1214"/>
        <source>点点划线</source>
        <translation type="unfinished">Two-dot-dash Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1149"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1218"/>
        <source>点点点划线</source>
        <translation type="unfinished">Three-dot-dash Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1252"/>
        <source>效果实线</source>
        <translation type="unfinished">Solid Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1253"/>
        <source>效果虚线</source>
        <translation type="unfinished">Dashed Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1254"/>
        <source>效果点线</source>
        <translation type="unfinished">Dotted Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1255"/>
        <source>效果点划线</source>
        <translation type="unfinished">Dot-dash Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1256"/>
        <source>效果点点划线</source>
        <translation type="unfinished">Two-dot-dash Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1257"/>
        <source>效果点点点划线</source>
        <translation type="unfinished">Three-dot-dash Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1264"/>
        <source>无填充</source>
        <translation type="unfinished">Unfilled</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1265"/>
        <source>实填充</source>
        <translation type="unfinished">Real fill</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1266"/>
        <source>网格填充</source>
        <translation type="unfinished">Mesh fill</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1267"/>
        <source>斜线填充</source>
        <translation type="unfinished">Diagonal fill</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1268"/>
        <source>点填充</source>
        <translation type="unfinished">Point fill</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1269"/>
        <source>点划线填充</source>
        <translation type="unfinished">Dot-dash Line fill</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1270"/>
        <source>点点划线填充</source>
        <translation type="unfinished">Two-dot-dash Line fill</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1271"/>
        <source>点点点划线填充</source>
        <translation type="unfinished">Three-dot-dash Line fill</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1278"/>
        <source>水平</source>
        <translation type="unfinished">Horizontal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1279"/>
        <source>垂直</source>
        <translation type="unfinished">Vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1280"/>
        <source>左斜</source>
        <translation type="unfinished">Left Slant</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_function.cpp" line="1281"/>
        <source>右斜</source>
        <translation type="unfinished">Right Slant</translation>
    </message>
</context>
<context>
    <name>ApiGuiCore</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="316"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="487"/>
        <source>空间</source>
        <translation type="unfinished">Space</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="321"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="490"/>
        <source>圆</source>
        <translation type="unfinished">Circle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="326"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="493"/>
        <source>直线</source>
        <translation type="unfinished">Straight line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="331"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="496"/>
        <source>矩形</source>
        <translation type="unfinished">Rectangle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="336"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="499"/>
        <source>椭圆</source>
        <translation type="unfinished">Ellipse</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="341"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="502"/>
        <source>折线</source>
        <translation type="unfinished">Broken line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="346"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="505"/>
        <source>多边形</source>
        <translation type="unfinished">Polygon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="351"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="508"/>
        <source>圆弧</source>
        <translation type="unfinished">Arc</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="356"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="511"/>
        <source>文本</source>
        <translation type="unfinished">Text</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="361"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="514"/>
        <source>贴片</source>
        <translation type="unfinished">chip</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="366"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="517"/>
        <source>图元</source>
        <translation type="unfinished">Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="371"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="520"/>
        <source>端点</source>
        <translation type="unfinished">Endpoints</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="376"/>
        <source>柱状图</source>
        <translation type="unfinished">Bar chart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="381"/>
        <source>数字量</source>
        <translation type="unfinished">Number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="386"/>
        <source>状态量</source>
        <translation type="unfinished">State</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="391"/>
        <source>光敏点</source>
        <translation type="unfinished">Photosensitive point</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="396"/>
        <source>饼图</source>
        <translation type="unfinished">Pie chart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="401"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="541"/>
        <source>图片</source>
        <translation type="unfinished">Picture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="406"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="544"/>
        <source>表格</source>
        <translation type="unfinished">Sheet</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="411"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="547"/>
        <source>设备</source>
        <translation type="unfinished">Equipment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="416"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="551"/>
        <source>母线</source>
        <translation type="unfinished">Bus</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="421"/>
        <source>曲线</source>
        <translation type="unfinished">Curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="426"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="558"/>
        <source>列表</source>
        <translation type="unfinished">list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="431"/>
        <source>仪表</source>
        <translation type="unfinished">Instrument</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="436"/>
        <source>字符量</source>
        <translation type="unfinished">Character</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="441"/>
        <source>环形图</source>
        <translation type="unfinished">Ring chart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="446"/>
        <source>进度条</source>
        <translation type="unfinished">Progress bar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="451"/>
        <source>仪表盘</source>
        <translation type="unfinished">Panel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="456"/>
        <source>高级控件</source>
        <translation type="unfinished">Advanced Controls</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="461"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="580"/>
        <source>自定义控件</source>
        <translation type="unfinished">Custom controls</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="466"/>
        <source>电池</source>
        <translation type="unfinished">Battery</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="481"/>
        <source>静态表格,双击查看详情</source>
        <translation type="unfinished">Static table, double-click to view details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="484"/>
        <source>动态表格,双击查看详情</source>
        <translation type="unfinished">Dynamic table, double-click to view details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="523"/>
        <source>柱状图,双击查看详情</source>
        <translation type="unfinished">Bar chart, double-click to view details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="526"/>
        <source>数值前景</source>
        <translation type="unfinished">Number foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="530"/>
        <source>状态前景</source>
        <translation type="unfinished">State foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="534"/>
        <source>光敏点,双击查看详情</source>
        <translation type="unfinished">Photosensitive point, double-click to view details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="538"/>
        <source>饼图,双击查看详情</source>
        <translation type="unfinished">Pie chart, double-click to view details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="555"/>
        <source>曲线,双击查看详情</source>
        <translation type="unfinished">Curve, double-click to view details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="561"/>
        <source>仪表,双击查看详情</source>
        <translation type="unfinished">Instrument, double-click to view details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="564"/>
        <source>字符前景</source>
        <translation type="unfinished">Character foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="568"/>
        <source>环形图，双击查看详情</source>
        <translation type="unfinished">Ring chart, double-click to view details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="571"/>
        <source>进度条,双击查看详情</source>
        <translation type="unfinished">Progress bar, double-click to view details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="574"/>
        <source>仪表盘,双击查看详情</source>
        <translation type="unfinished">Panel, double-click to view details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="577"/>
        <source>高级控件,双击查看详情</source>
        <translation type="unfinished">Advanced control, double-click to view details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_core.cpp" line="583"/>
        <source>电池,双击查看详情</source>
        <translation type="unfinished">Battery, double-click to view details</translation>
    </message>
</context>
<context>
    <name>ApiPoke</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_poke.cpp" line="61"/>
        <source>跳转画面信号</source>
        <translation type="unfinished">Jump signal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_poke.cpp" line="65"/>
        <source>跳转动态模板信号</source>
        <translation type="unfinished">Jump dynamic template signal</translation>
    </message>
</context>
<context>
    <name>ApiProgressBar</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_progress_bar.cpp" line="392"/>
        <source>越界</source>
        <translation type="unfinished">Out of range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_progress_bar.cpp" line="440"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_progress_bar.cpp" line="440"/>
        <source>数据范围：最大值不可小于最小值</source>
        <translation type="unfinished">Data range: The maximum value cannot be less than the minimum value</translation>
    </message>
</context>
<context>
    <name>ApiRectTable</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_rect_table.cpp" line="1392"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_rect_table.cpp" line="1664"/>
        <source>尾页</source>
        <translation type="unfinished">Last</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_rect_table.cpp" line="1410"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_rect_table.cpp" line="1690"/>
        <source>下一页</source>
        <translation type="unfinished">Next</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_rect_table.cpp" line="1372"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_rect_table.cpp" line="1564"/>
        <source>跳转</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Jump</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_rect_table.cpp" line="1374"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_rect_table.cpp" line="1565"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_rect_table.cpp" line="5348"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_rect_table.cpp" line="5477"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_rect_table.cpp" line="5537"/>
        <source>跳转</source>
        <translation type="unfinished">Jump</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_rect_table.cpp" line="1725"/>
        <source>1/1</source>
        <translation type="unfinished">1/1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_rect_table.cpp" line="1446"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_rect_table.cpp" line="1748"/>
        <source>上一页</source>
        <translation type="unfinished">Previous</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_rect_table.cpp" line="1465"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_rect_table.cpp" line="1775"/>
        <source>首页</source>
        <translation type="unfinished">Front page</translation>
    </message>
</context>
<context>
    <name>ApiTag</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_tag.cpp" line="144"/>
        <source>未找到牌</source>
        <translation type="unfinished">Card not found</translation>
    </message>
</context>
<context>
    <name>ApiTerm</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_term.cpp" line="399"/>
        <source>设置坐标</source>
        <comment>menuName</comment>
        <translation type="unfinished">Set coordinates</translation>
    </message>
</context>
<context>
    <name>ApiValue</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_value.cpp" line="595"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_value.cpp" line="701"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_value.cpp" line="1078"/>
        <source>未定义</source>
        <translation type="unfinished">Undefined</translation>
    </message>
</context>
<context>
    <name>CommonEnv</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/common_env.cpp" line="497"/>
        <source>有功功率</source>
        <translation type="unfinished">P</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/common_env.cpp" line="501"/>
        <source>无功功率</source>
        <translation type="unfinished">Q</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/common_env.cpp" line="505"/>
        <source>电压</source>
        <translation type="unfinished">Voltage</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/common_env.cpp" line="509"/>
        <source>电流</source>
        <translation type="unfinished">Electric current</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/common_env.cpp" line="531"/>
        <source>普通画面</source>
        <translation type="unfinished">General graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/common_env.cpp" line="532"/>
        <source>动态模板</source>
        <translation type="unfinished">Dynamic template</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/common_env.cpp" line="533"/>
        <source>静态模板</source>
        <translation type="unfinished">Static template</translation>
    </message>
</context>
<context>
    <name>DlgBaseAttr</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="20"/>
        <source>基本属性</source>
        <translation type="unfinished">Basic attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="35"/>
        <source>是否边框</source>
        <translation type="unfinished">Border</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="57"/>
        <source>线型：</source>
        <translation type="unfinished">Line type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="50"/>
        <source>线宽：</source>
        <translation type="unfinished">Line width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="81"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="130"/>
        <source>颜色：</source>
        <translation type="unfinished">Color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="88"/>
        <source>效果：</source>
        <translation type="unfinished">Effect:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="109"/>
        <source>纯色</source>
        <translation type="unfinished">Solid color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="148"/>
        <source>模式：</source>
        <translation type="unfinished">Mode:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="158"/>
        <source>方向：</source>
        <translation type="unfinished">Direction:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="172"/>
        <source>路径：</source>
        <translation type="unfinished">Path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="182"/>
        <source>选择文件</source>
        <translation type="unfinished">Select file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="189"/>
        <source>保持比例</source>
        <translation type="unfinished">Keep proportion</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="201"/>
        <source>是否填充</source>
        <translation type="unfinished">Fill</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="211"/>
        <source>渐变</source>
        <translation type="unfinished">Gradation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="221"/>
        <source>图片</source>
        <translation type="unfinished">Picture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="240"/>
        <source>是否模板区域</source>
        <translation type="unfinished">Template area</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="259"/>
        <source>角型：</source>
        <translation type="unfinished">Angle type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="266"/>
        <source>直角</source>
        <translation type="unfinished">Right angle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="276"/>
        <source>弧角</source>
        <translation type="unfinished">Arc angle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="283"/>
        <source>圆角</source>
        <translation type="unfinished">Rounded corner</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="302"/>
        <source>X坐标：</source>
        <translation type="unfinished">X-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="312"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Y-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="322"/>
        <source>宽度：</source>
        <translation type="unfinished">Width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="332"/>
        <source>高度：</source>
        <translation type="unfinished">Height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="342"/>
        <source>X半径:</source>
        <translation type="unfinished">X radius:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="352"/>
        <source>Y半径：</source>
        <translation type="unfinished">Y radius:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="374"/>
        <source>电压等级</source>
        <translation type="unfinished">Voltage level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="396"/>
        <source>起始箭头</source>
        <translation type="unfinished">Starting arrow</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="416"/>
        <source>结束箭头</source>
        <translation type="unfinished">End arrow</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="437"/>
        <source>使能决策</source>
        <translation type="unfinished">Enable decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="464"/>
        <source>清除</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="471"/>
        <source>数据库连接</source>
        <translation type="unfinished">DB connection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="482"/>
        <source>数据路径:</source>
        <translation type="unfinished">Data path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="496"/>
        <source>数据标识:</source>
        <translation type="unfinished">Data id:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="533"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="541"/>
        <source>X坐标</source>
        <translation type="unfinished">X-coordinate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="546"/>
        <source>Y坐标</source>
        <translation type="unfinished">Y-coordinate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="572"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.ui" line="579"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="435"/>
        <source>直线属性</source>
        <comment>toolName</comment>
        <translation type="unfinished">Straight Line Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="455"/>
        <source>矩形属性</source>
        <comment>toolName</comment>
        <translation type="unfinished">Rectangle Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="491"/>
        <source>椭圆属性</source>
        <comment>toolName</comment>
        <translation type="unfinished">Ellipse Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="509"/>
        <source>圆形属性</source>
        <comment>toolName</comment>
        <translation type="unfinished">Circular Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="527"/>
        <source>弧形属性</source>
        <comment>toolName</comment>
        <translation type="unfinished">Arc Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="546"/>
        <source>多边形属性</source>
        <comment>toolName</comment>
        <translation type="unfinished">Polygon Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="565"/>
        <source>折线属性</source>
        <comment>toolName</comment>
        <translation type="unfinished">Broken Line Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="585"/>
        <source>连接线属性</source>
        <comment>toolName</comment>
        <translation type="unfinished">Connect Line Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="604"/>
        <source>连接点属性</source>
        <comment>toolName</comment>
        <translation type="unfinished">Connect Point Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="1130"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="1145"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="1152"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="1166"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="1175"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="1182"/>
        <source>提示</source>
        <comment>Prompt</comment>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="1130"/>
        <source>是否删除当前选中的点?</source>
        <comment>Prompt</comment>
        <translation type="unfinished">Whether to delete the currently selected point?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="1145"/>
        <source>当前点数小于等于3个，不允许删除!</source>
        <comment>Prompt</comment>
        <translation type="unfinished">The current number of points is less than or equal to 3, deletion is not allowed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="1152"/>
        <source>当前点数小于等于2个，不允许删除!</source>
        <comment>Prompt</comment>
        <translation type="unfinished">The current number of points is less than or equal to 2, deletion is not allowed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="1166"/>
        <source>请先选择要删除的点!</source>
        <comment>Prompt</comment>
        <translation type="unfinished">Please select the point to delete first!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="1175"/>
        <source>删除后点数小于3个，不允许删除!</source>
        <comment>Prompt</comment>
        <translation type="unfinished">If the number of points after deletion is less than 3, deletion is not allowed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/element/dlg_base_attr.cpp" line="1182"/>
        <source>删除后点数小于2个，不允许删除!</source>
        <comment>Prompt</comment>
        <translation type="unfinished">The number of points after deletion will be less than 2; deletion not allowed!</translation>
    </message>
</context>
<context>
    <name>DlgCustomBattery</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="14"/>
        <source>电池属性</source>
        <translation type="unfinished">Battery attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="34"/>
        <source>边框圆角角度</source>
        <translation type="unfinished">Angle of border rounded corner</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="48"/>
        <source>头部圆角角度</source>
        <translation type="unfinished">Angle of header rounded corner</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="26"/>
        <source>基本设置</source>
        <translation type="unfinished">Basic Settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="66"/>
        <source>百分比值:</source>
        <translation type="unfinished">Percentage value:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="73"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="96"/>
        <source>内部</source>
        <translation type="unfinished">Interior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="80"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="153"/>
        <source>外部</source>
        <translation type="unfinished">External</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="105"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="162"/>
        <source>字体大小</source>
        <translation type="unfinished">Font size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="115"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="172"/>
        <source>小数点位数</source>
        <translation type="unfinished">Decimal places</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="130"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="187"/>
        <source>显示单位</source>
        <translation type="unfinished">Display units</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="140"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="197"/>
        <source>数值颜色：</source>
        <translation type="unfinished">Value:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="222"/>
        <source>电量状态设置</source>
        <translation type="unfinished">Power status setting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="250"/>
        <source>电量最小值</source>
        <translation type="unfinished">Minimum battery level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="255"/>
        <source>电量最大值</source>
        <translation type="unfinished">Maximum power consumption</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="260"/>
        <source>电池颜色</source>
        <translation type="unfinished">Battery color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="277"/>
        <source>属性配置</source>
        <translation type="unfinished">Attr Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="285"/>
        <source>电池电量：</source>
        <translation type="unfinished">Battery power:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="299"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="359"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="440"/>
        <source>检索</source>
        <translation type="unfinished">Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="310"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="370"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="451"/>
        <source>对象ID：</source>
        <translation type="unfinished">Object ID:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="324"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="384"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="465"/>
        <source>对象域：</source>
        <translation type="unfinished">Object field:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="331"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="391"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="472"/>
        <source>0</source>
        <translation type="unfinished">0</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="345"/>
        <source>充电状态：</source>
        <translation type="unfinished">Charging status:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="405"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="486"/>
        <source>命中条件：</source>
        <translation type="unfinished">Hit condition:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="415"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="496"/>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="426"/>
        <source>放电状态：</source>
        <translation type="unfinished">Discharge status:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="523"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.ui" line="530"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.cpp" line="234"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.cpp" line="340"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.cpp" line="353"/>
        <source>选择颜色</source>
        <translation type="unfinished">Choose color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.cpp" line="573"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_custom_battery.cpp" line="573"/>
        <source>电池控件：最小值不能大于最大值。</source>
        <translation type="unfinished">Battery control: The minimum value cannot be greater than the maximum value.</translation>
    </message>
</context>
<context>
    <name>DlgDynStringSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_dynamics_string_set.ui" line="14"/>
        <source>字体设置</source>
        <translation type="unfinished">Font settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_dynamics_string_set.ui" line="36"/>
        <source>竖排</source>
        <translation type="unfinished">Vertical row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_dynamics_string_set.ui" line="43"/>
        <source>加粗</source>
        <translation type="unfinished">Bold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_dynamics_string_set.ui" line="52"/>
        <source>字体大小：</source>
        <translation type="unfinished">Font size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_dynamics_string_set.ui" line="62"/>
        <source>文本样式：</source>
        <translation type="unfinished">Text style:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_dynamics_string_set.ui" line="69"/>
        <source>文本内容：</source>
        <translation type="unfinished">Text content:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_dynamics_string_set.ui" line="82"/>
        <source>字体类型：</source>
        <translation type="unfinished">Font family:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_dynamics_string_set.ui" line="109"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_dynamics_string_set.ui" line="116"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_dynamics_string_set.cpp" line="26"/>
        <source>中对齐</source>
        <translation type="unfinished">Center align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_dynamics_string_set.cpp" line="27"/>
        <source>左对齐</source>
        <translation type="unfinished">Left align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_dynamics_string_set.cpp" line="28"/>
        <source>右对齐</source>
        <translation type="unfinished">Right align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_dynamics_string_set.cpp" line="29"/>
        <source>上对齐</source>
        <translation type="unfinished">Top align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_dynamics_string_set.cpp" line="30"/>
        <source>下对齐</source>
        <translation type="unfinished">Bottom align</translation>
    </message>
</context>
<context>
    <name>DlgEquipmentSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="14"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="30"/>
        <source>设备属性</source>
        <translation type="unfinished">Device attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="52"/>
        <source>是否直接使用数据库关联</source>
        <translation type="unfinished">Whether to use db link directly</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="55"/>
        <source>是否取库</source>
        <translation type="unfinished">Retrieve db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="87"/>
        <source>数据库链接</source>
        <translation type="unfinished">DB link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="90"/>
        <source>数据库连接</source>
        <translation type="unfinished">DB connection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="103"/>
        <source>清除链接</source>
        <translation type="unfinished">Clear links</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="106"/>
        <source>清除</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="180"/>
        <source>数据库OID</source>
        <translation type="unfinished">DB OID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="38"/>
        <source>图元类型：</source>
        <translation type="unfinished">Icon type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="117"/>
        <source>数据路径：</source>
        <translation type="unfinished">Data path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="138"/>
        <source>条件：</source>
        <translation type="unfinished">Condition:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="159"/>
        <source>电压等级：</source>
        <translation type="unfinished">Voltage level:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="183"/>
        <source>数据标识 ：</source>
        <translation type="unfinished">Data identification:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="197"/>
        <source>标签</source>
        <translation type="unfinished">Tag</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="227"/>
        <source>更多属性...</source>
        <translation type="unfinished">More attrs...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="237"/>
        <source>基本属性</source>
        <translation type="unfinished">Basic attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="252"/>
        <source>X坐标：</source>
        <translation type="unfinished">X-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="262"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Y-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="272"/>
        <source>宽度：</source>
        <translation type="unfinished">Width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="282"/>
        <source>高度：</source>
        <translation type="unfinished">Height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="305"/>
        <source>X坐标</source>
        <translation type="unfinished">X-coordinate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="310"/>
        <source>Y坐标</source>
        <translation type="unfinished">Y-coordinate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="353"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.ui" line="360"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.cpp" line="125"/>
        <source>请链接数据库</source>
        <translation type="unfinished">Please connect to the db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.cpp" line="125"/>
        <source>数据库未连接,请连接数据库</source>
        <translation type="unfinished">The db is not connected. Please connect to the db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.cpp" line="308"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.cpp" line="452"/>
        <source>模板名称：</source>
        <comment>toolName</comment>
        <translation type="unfinished">Template Name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.cpp" line="351"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.cpp" line="482"/>
        <source>字符串</source>
        <translation type="unfinished">string</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.cpp" line="365"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_equipment_set.cpp" line="496"/>
        <source>电压等级</source>
        <translation type="unfinished">Voltage level</translation>
    </message>
</context>
<context>
    <name>DlgGaugePanel</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.cpp" line="189"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.cpp" line="200"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.cpp" line="206"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.cpp" line="212"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.cpp" line="189"/>
        <source>请先关联数据</source>
        <translation type="unfinished">Please link data first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.cpp" line="200"/>
        <source>最大刻度值必须大于最小刻度值</source>
        <translation type="unfinished">The maximum tick value must be greater than the minimum tick value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.cpp" line="206"/>
        <source>上限值必须大于最小值</source>
        <translation type="unfinished">Upper limit must be greater than the minimum value.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.cpp" line="212"/>
        <source>上限值必须小于等于最大值</source>
        <translation type="unfinished">Upper limit must be less than or equal to the maximum value.</translation>
    </message>
</context>
<context>
    <name>DlgGridBoxConfig</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.cpp" line="578"/>
        <source>确认切换</source>
        <translation type="unfinished">Confirm switch</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.cpp" line="579"/>
        <source>切换到统一尺寸模式将重新计算所有列宽和行高，当前的自定义设置将丢失。</source>
        <translation type="unfinished">Switching to uniform size mode will recalculate all column widths and row heights, and these custom settings will be lost.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.cpp" line="579"/>
        <source>确定要继续吗？</source>
        <translation type="unfinished">Whether to continue?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.cpp" line="813"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.cpp" line="959"/>
        <source>第%1列:</source>
        <translation type="unfinished">Col %1:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.cpp" line="888"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.cpp" line="1034"/>
        <source>第%1行:</source>
        <translation type="unfinished">Line %1:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.cpp" line="1132"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.cpp" line="1133"/>
        <source>实线</source>
        <translation type="unfinished">Solid Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.cpp" line="1135"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.cpp" line="1136"/>
        <source>虚线</source>
        <translation type="unfinished">Dashed Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.cpp" line="1138"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.cpp" line="1139"/>
        <source>点线</source>
        <translation type="unfinished">Dotted Line</translation>
    </message>
</context>
<context>
    <name>DlgImageSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="14"/>
        <source>图片</source>
        <translation type="unfinished">Picture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="22"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="29"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="67"/>
        <source>填充方式：</source>
        <translation type="unfinished">Filling method:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="74"/>
        <source>图片信息</source>
        <translation type="unfinished">Picture info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="97"/>
        <source>宽度：  </source>
        <translation type="unfinished">Width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="107"/>
        <source>高度：  </source>
        <translation type="unfinished">Height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="121"/>
        <source>X坐标： </source>
        <translation type="unfinished">X-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="131"/>
        <source>Y坐标： </source>
        <translation type="unfinished">Y-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="158"/>
        <source>边框</source>
        <translation type="unfinished">Border</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="194"/>
        <source>平铺</source>
        <translation type="unfinished">tiled</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="165"/>
        <source>居中</source>
        <translation type="unfinished">Align center</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="60"/>
        <source>图片路径：</source>
        <translation type="unfinished">Pic path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="81"/>
        <source>图片尺寸：</source>
        <translation type="unfinished">Pic size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="88"/>
        <source>图片坐标：</source>
        <translation type="unfinished">Pic coordinates:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="145"/>
        <source>拉伸</source>
        <translation type="unfinished">Stretch</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.ui" line="235"/>
        <source>选择文件</source>
        <translation type="unfinished">Select file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.cpp" line="62"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.cpp" line="217"/>
        <source>图片信息:宽 %1,高 %2  (单位:像素)</source>
        <translation type="unfinished">Image info: width %1, height %2 (in pixels)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.cpp" line="117"/>
        <source>提示!</source>
        <translation type="unfinished">Tips!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.cpp" line="117"/>
        <source>输入的坐标值不能是负数!</source>
        <translation type="unfinished">The input coordinate value cannot be negative!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.cpp" line="209"/>
        <source>打开图片</source>
        <translation type="unfinished">Open image</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.cpp" line="221"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_image_set.cpp" line="221"/>
        <source>当前设置图片大于选择的区域，请将图片模式切换为拉伸模式</source>
        <translation type="unfinished">The current set picture is larger than the selected area, please switch the picture mode to stretch mode</translation>
    </message>
</context>
<context>
    <name>DlgStateTextSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="14"/>
        <source>字符前景</source>
        <translation type="unfinished">Character foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="26"/>
        <source>基本设置：</source>
        <translation type="unfinished">Basic setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="56"/>
        <source>文本：</source>
        <translation type="unfinished">Text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="63"/>
        <source>显示文本</source>
        <translation type="unfinished">Display Text</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="74"/>
        <source>文字颜色：</source>
        <translation type="unfinished">Text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="81"/>
        <source>文字颜色</source>
        <translation type="unfinished">Text color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="92"/>
        <source>前景颜色：</source>
        <translation type="unfinished">Foreground:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="99"/>
        <source>填充色</source>
        <translation type="unfinished">Fill color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="106"/>
        <source>填充颜色</source>
        <translation type="unfinished">Fill color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="122"/>
        <source>对齐：</source>
        <translation type="unfinished">Align:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="132"/>
        <source>竖排</source>
        <translation type="unfinished">Vertical row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="140"/>
        <source>枚举</source>
        <translation type="unfinished">Enum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="148"/>
        <source>边框色</source>
        <translation type="unfinished">Border color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="155"/>
        <source>边框颜色</source>
        <translation type="unfinished">Border color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="171"/>
        <source>函数取值</source>
        <translation type="unfinished">Function value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="182"/>
        <source>X坐标：</source>
        <translation type="unfinished">X-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="192"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Y-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="206"/>
        <source>宽度：</source>
        <translation type="unfinished">Width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="216"/>
        <source>高度：</source>
        <translation type="unfinished">Height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="463"/>
        <source>应用：</source>
        <translation type="unfinished">App:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="521"/>
        <source>链接路径：</source>
        <translation type="unfinished">Link path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="535"/>
        <source>条件：</source>
        <translation type="unfinished">Condition:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="549"/>
        <source>对象ID：</source>
        <translation type="unfinished">Object ID:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="237"/>
        <source>字体设置：</source>
        <translation type="unfinished">Font setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="260"/>
        <source>字体：</source>
        <translation type="unfinished">Font:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="274"/>
        <source>字体大小：</source>
        <translation type="unfinished">Font size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="290"/>
        <source>效果：</source>
        <translation type="unfinished">Effect:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="297"/>
        <source>粗体</source>
        <translation type="unfinished">Bold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="304"/>
        <source>斜体</source>
        <translation type="unfinished">Italic</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="311"/>
        <source>删除线</source>
        <translation type="unfinished">Strikeout Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="318"/>
        <source>下划线</source>
        <translation type="unfinished">Base Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="336"/>
        <source>决策：</source>
        <translation type="unfinished">Decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="354"/>
        <source>颜色决策</source>
        <translation type="unfinished">Color decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="364"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="385"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="406"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="427"/>
        <source>更多</source>
        <translation type="unfinished">More</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="375"/>
        <source>字符决策</source>
        <translation type="unfinished">Character decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="396"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Flashing decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="417"/>
        <source>使能决策</source>
        <translation type="unfinished">Enable decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="445"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="480"/>
        <source>数据库：</source>
        <translation type="unfinished">DB:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="503"/>
        <source>清除</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="510"/>
        <source>检索</source>
        <translation type="unfinished">Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="559"/>
        <source>对象域：</source>
        <translation type="unfinished">Object field:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="589"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.ui" line="596"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.cpp" line="60"/>
        <source>中对齐</source>
        <translation type="unfinished">Center align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.cpp" line="61"/>
        <source>左对齐</source>
        <translation type="unfinished">Left align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.cpp" line="62"/>
        <source>右对齐</source>
        <translation type="unfinished">Right align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.cpp" line="63"/>
        <source>上对齐</source>
        <translation type="unfinished">Top align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_statetext_set.cpp" line="64"/>
        <source>下对齐</source>
        <translation type="unfinished">Bottom align</translation>
    </message>
</context>
<context>
    <name>DlgStringSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="131"/>
        <source>文本内容：</source>
        <translation type="unfinished">Text content:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="44"/>
        <source>文本样式：</source>
        <translation type="unfinished">Text style:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="14"/>
        <source>文本设置</source>
        <translation type="unfinished">Text settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="86"/>
        <source>翻译标签：</source>
        <translation type="unfinished">Translation tags:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="105"/>
        <source>竖排</source>
        <translation type="unfinished">Vertical row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="112"/>
        <source>加粗</source>
        <translation type="unfinished">Bold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="51"/>
        <source>字体类型：</source>
        <translation type="unfinished">Font family:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="79"/>
        <source>字体大小：</source>
        <translation type="unfinished">Font size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="93"/>
        <source>字体颜色：</source>
        <translation type="unfinished">Font:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="58"/>
        <source>字体颜色</source>
        <translation type="unfinished">Font color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="119"/>
        <source>启用后，文本会自动变形充满整个框体</source>
        <translation type="unfinished">After being enabled, the text will automatically adjust to fill the entire box</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="122"/>
        <source>文本自适应</source>
        <translation type="unfinished">Text auto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="147"/>
        <source>翻译</source>
        <translation type="unfinished">Translation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="163"/>
        <source>X坐标：</source>
        <translation type="unfinished">X-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="173"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Y-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="187"/>
        <source>宽度：</source>
        <translation type="unfinished">Width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="197"/>
        <source>高度：</source>
        <translation type="unfinished">Height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="224"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.ui" line="231"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.cpp" line="37"/>
        <source>中对齐</source>
        <translation type="unfinished">Center align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.cpp" line="38"/>
        <source>左对齐</source>
        <translation type="unfinished">Left align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.cpp" line="39"/>
        <source>右对齐</source>
        <translation type="unfinished">Right align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.cpp" line="40"/>
        <source>上对齐</source>
        <translation type="unfinished">Top align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.cpp" line="41"/>
        <source>下对齐</source>
        <translation type="unfinished">Bottom align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.cpp" line="102"/>
        <source>启用后，固定左上角位置，框体会根据文本内容、字号和字体自动调整宽高</source>
        <translation type="unfinished">After activation, the box will be fixed in the top left corner and its width and height will be automatically adjusted according to the text content, font size, and font type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.cpp" line="177"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.cpp" line="269"/>
        <source>框体自适应已启用，对齐方式由框体自动确定</source>
        <translation type="unfinished">The box-auto is enabled, and the alignment method is automatically determined by the box</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.cpp" line="180"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.cpp" line="272"/>
        <source>设置字体大小，框体将根据文本内容自动调整宽高</source>
        <translation type="unfinished">Set the font size, and the box will automatically adjust its width and height according to the text content</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.cpp" line="183"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_string_set.cpp" line="275"/>
        <source>设置字体类型，框体将根据文本内容自动调整宽高</source>
        <translation type="unfinished">Set the font type, and the box will automatically adjust its width and height according to the text content</translation>
    </message>
</context>
<context>
    <name>DlgValueSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="14"/>
        <source>数值前景</source>
        <translation type="unfinished">Value foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="26"/>
        <source>基本设置：</source>
        <translation type="unfinished">Basic setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="53"/>
        <source>文本：</source>
        <translation type="unfinished">Text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="67"/>
        <source>显示文本</source>
        <translation type="unfinished">Display Text</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="78"/>
        <source>文字颜色：</source>
        <translation type="unfinished">Text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="85"/>
        <source>文字颜色</source>
        <translation type="unfinished">Text color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="96"/>
        <source>前景颜色：</source>
        <translation type="unfinished">Foreground:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="103"/>
        <source>填充色</source>
        <translation type="unfinished">Fill color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="110"/>
        <source>填充颜色</source>
        <translation type="unfinished">Fill color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="126"/>
        <source>对齐：</source>
        <translation type="unfinished">Align:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="136"/>
        <source>竖排</source>
        <translation type="unfinished">Vertical row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="144"/>
        <source>枚举</source>
        <translation type="unfinished">Enum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="152"/>
        <source>边框色</source>
        <translation type="unfinished">Border color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="159"/>
        <source>边框颜色</source>
        <translation type="unfinished">Border color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="175"/>
        <source>函数取值</source>
        <translation type="unfinished">Function value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="186"/>
        <source>X坐标：</source>
        <translation type="unfinished">X-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="196"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Y-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="210"/>
        <source>宽度：</source>
        <translation type="unfinished">Width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="220"/>
        <source>高度：</source>
        <translation type="unfinished">Height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="241"/>
        <source>字体设置：</source>
        <translation type="unfinished">Font setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="264"/>
        <source>字体：</source>
        <translation type="unfinished">Font:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="278"/>
        <source>字体大小：</source>
        <translation type="unfinished">Font size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="294"/>
        <source>效果：</source>
        <translation type="unfinished">Effect:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="301"/>
        <source>粗体</source>
        <translation type="unfinished">Bold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="308"/>
        <source>斜体</source>
        <translation type="unfinished">Italic</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="315"/>
        <source>删除线</source>
        <translation type="unfinished">Strikeout Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="322"/>
        <source>下划线</source>
        <translation type="unfinished">Base Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="340"/>
        <source>显示：</source>
        <translation type="unfinished">Display:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="361"/>
        <source>显示格式：</source>
        <translation type="unfinished">Display format:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="379"/>
        <source>显示前缀：</source>
        <translation type="unfinished">Display prefix:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="397"/>
        <source>显示后缀：</source>
        <translation type="unfinished">Display suffix:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="415"/>
        <source>小数点位数：</source>
        <translation type="unfinished">Decimal places:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="429"/>
        <source>LCD显示</source>
        <translation type="unfinished">LCD display</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="436"/>
        <source>允许修改</source>
        <translation type="unfinished">Allow modification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="454"/>
        <source>决策：</source>
        <translation type="unfinished">Decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="472"/>
        <source>颜色决策</source>
        <translation type="unfinished">Color decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="482"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="503"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="524"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="545"/>
        <source>更多</source>
        <translation type="unfinished">More</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="493"/>
        <source>字符决策</source>
        <translation type="unfinished">Character decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="514"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Flashing decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="535"/>
        <source>使能决策</source>
        <translation type="unfinished">Enable decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="563"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="598"/>
        <source>数据库：</source>
        <translation type="unfinished">DB:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="581"/>
        <source>应用：</source>
        <translation type="unfinished">App:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="639"/>
        <source>链接路径：</source>
        <translation type="unfinished">Link path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="653"/>
        <source>条件：</source>
        <translation type="unfinished">Condition:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="667"/>
        <source>对象ID：</source>
        <translation type="unfinished">Object ID:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="621"/>
        <source>清除</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="628"/>
        <source>检索</source>
        <translation type="unfinished">Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="677"/>
        <source>对象域：</source>
        <translation type="unfinished">Object field:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="694"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.ui" line="714"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.cpp" line="50"/>
        <source>中对齐</source>
        <translation type="unfinished">Center align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.cpp" line="51"/>
        <source>左对齐</source>
        <translation type="unfinished">Left align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.cpp" line="52"/>
        <source>右对齐</source>
        <translation type="unfinished">Right align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.cpp" line="53"/>
        <source>上对齐</source>
        <translation type="unfinished">Top align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_value_set.cpp" line="54"/>
        <source>下对齐</source>
        <translation type="unfinished">Bottom align</translation>
    </message>
</context>
<context>
    <name>MCurveChart</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_curve_chart.cpp" line="119"/>
        <source>ellipse</source>
        <translation type="unfinished">ellipse</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_curve_chart.cpp" line="1007"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_curve_chart.cpp" line="1023"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_curve_chart.cpp" line="1066"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
</context>
<context>
    <name>SymbolContent</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_symbol.cpp" line="591"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_symbol.cpp" line="600"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_symbol.cpp" line="616"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_symbol.cpp" line="625"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_symbol.cpp" line="774"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_symbol.cpp" line="854"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_symbol.cpp" line="872"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_symbol.cpp" line="880"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_symbol.cpp" line="591"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_symbol.cpp" line="854"/>
        <source>图元文件【%1】不存在!</source>
        <translation type="unfinished">The icon file [%1] does not exist!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_symbol.cpp" line="600"/>
        <source>图元文件无法打开</source>
        <translation type="unfinished">Icon file cannot be opened</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_symbol.cpp" line="616"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_symbol.cpp" line="625"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_symbol.cpp" line="872"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_symbol.cpp" line="880"/>
        <source>文件格式为非图元格式文件</source>
        <translation type="unfinished">The file format is a non-icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/api_symbol.cpp" line="774"/>
        <source>%1标签属性错误</source>
        <translation type="unfinished">%1 label attr error</translation>
    </message>
</context>
<context>
    <name>dlg_bar</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="14"/>
        <source>柱状图</source>
        <translation type="unfinished">Bar chart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="236"/>
        <source>图表设置</source>
        <translation type="unfinished">Chart settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="244"/>
        <source>标题</source>
        <translation type="unfinished">Title</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="267"/>
        <source>标题字体大小</source>
        <translation type="unfinished">Title font size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="284"/>
        <source>边框</source>
        <translation type="unfinished">Border</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="302"/>
        <source>标题颜色</source>
        <translation type="unfinished">Title color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="312"/>
        <source>坐标轴颜色</source>
        <translation type="unfinished">Axis color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="326"/>
        <source>柱状图竖</source>
        <translation type="unfinished">Vertical bar chart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="339"/>
        <source>柱状图横</source>
        <translation type="unfinished">Horizontal bar chart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="356"/>
        <source>X坐标轴显示</source>
        <translation type="unfinished">X-axis display</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="369"/>
        <source>Y坐标轴显示</source>
        <translation type="unfinished">Y-axis display</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="409"/>
        <source>Y轴坐标值显示</source>
        <translation type="unfinished">Y-coordinate value display</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="391"/>
        <source>Y轴最大值</source>
        <translation type="unfinished">Y-axis maximum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="451"/>
        <source>X轴坐标标签</source>
        <translation type="unfinished">X-coordinate label</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="495"/>
        <source>X轴标签字体大小</source>
        <translation type="unfinished">Font size of X-axis label</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="425"/>
        <source>小数位数：</source>
        <translation type="unfinished">Decimal places:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="471"/>
        <source>Y轴坐标标签</source>
        <translation type="unfinished">Y-coordinate label</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="522"/>
        <source>Y轴标签字体大小</source>
        <translation type="unfinished">Y-axis label font size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="543"/>
        <source>Y轴标签颜色</source>
        <translation type="unfinished">Y-axis label color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="550"/>
        <source>X轴标签颜色</source>
        <translation type="unfinished">X-axis label color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="571"/>
        <source>X坐标轴网格线</source>
        <translation type="unfinished">X-axis grid lines</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="581"/>
        <source>Y坐标轴网格线</source>
        <translation type="unfinished">Y-axis grid lines</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="592"/>
        <source>数据标签:</source>
        <translation type="unfinished">Data label:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="599"/>
        <source>无</source>
        <translation type="unfinished">None</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="612"/>
        <source>外部</source>
        <translation type="unfinished">External</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="622"/>
        <source>内部顶部</source>
        <translation type="unfinished">Internal top</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="632"/>
        <source>内部中间</source>
        <translation type="unfinished">Internal middle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="642"/>
        <source>内部底部</source>
        <translation type="unfinished">Internal bottom</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="20"/>
        <source>点</source>
        <translation type="unfinished">Point</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="28"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="59"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="64"/>
        <source>路径</source>
        <translation type="unfinished">Path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="74"/>
        <source>+</source>
        <translation type="unfinished">+</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="81"/>
        <source>C</source>
        <translation type="unfinished">C</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="88"/>
        <source>-</source>
        <translation type="unfinished">-</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="107"/>
        <source>图例字体大小</source>
        <translation type="unfinished">Legend font size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="124"/>
        <source>图例颜色</source>
        <translation type="unfinished">Legend color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="154"/>
        <source>是否使用函数</source>
        <translation type="unfinished">Use function</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="180"/>
        <source>数据颜色</source>
        <translation type="unfinished">Data color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="220"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.ui" line="227"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.cpp" line="192"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_bar.cpp" line="192"/>
        <source>柱状图：图例名称限制为10个字符，请检查。</source>
        <translation type="unfinished">Bar chart: Legend name is limited to 10 characters. Please check.</translation>
    </message>
</context>
<context>
    <name>dlg_curve</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="14"/>
        <source>dlg_curve</source>
        <translation type="unfinished">dlg_curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="28"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="377"/>
        <source>类型</source>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="35"/>
        <source>日统计</source>
        <translation type="unfinished">Daily statistics</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="45"/>
        <source>月统计</source>
        <translation type="unfinished">Monthly statistics</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="55"/>
        <source>年统计</source>
        <translation type="unfinished">Annual statistics</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="65"/>
        <source>采样值</source>
        <translation type="unfinished">Sample value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="75"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.cpp" line="301"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.cpp" line="302"/>
        <source>实时曲线</source>
        <translation type="unfinished">Real-time Curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="89"/>
        <source>标题</source>
        <translation type="unfinished">Title</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="103"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="155"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="207"/>
        <source>字体大小</source>
        <translation type="unfinished">Font size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="113"/>
        <source>标题颜色</source>
        <translation type="unfinished">Title color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="123"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="175"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="227"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="337"/>
        <source>#FF66CCFF</source>
        <translation type="unfinished">#FF66CCFF</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="130"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="182"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="234"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="347"/>
        <source>C</source>
        <translation type="unfinished">C</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="141"/>
        <source>X轴标题</source>
        <translation type="unfinished">X-axis heading</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="165"/>
        <source>X轴标题颜色</source>
        <translation type="unfinished">X-axis title color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="193"/>
        <source>Y轴标题</source>
        <translation type="unfinished">Y-axis title</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="217"/>
        <source>Y轴标题颜色</source>
        <translation type="unfinished">Y-axis title color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="245"/>
        <source>是否渐变</source>
        <translation type="unfinished">Gradient</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="252"/>
        <source>X轴网格线</source>
        <translation type="unfinished">X-axis grid lines</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="259"/>
        <source>Y轴网格线</source>
        <translation type="unfinished">Y-axis grid lines</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="272"/>
        <source>X轴间隔数</source>
        <translation type="unfinished">X-axis interval number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="298"/>
        <source>Y轴间隔数</source>
        <translation type="unfinished">Y-axis interval number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="327"/>
        <source>坐标轴颜色</source>
        <translation type="unfinished">Axis color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="382"/>
        <source>时间</source>
        <translation type="unfinished">Time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="387"/>
        <source>开始</source>
        <translation type="unfinished">Start</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="392"/>
        <source>结束</source>
        <translation type="unfinished">Finish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="397"/>
        <source>曲线颜色</source>
        <translation type="unfinished">Curve color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="402"/>
        <source>曲线线宽</source>
        <translation type="unfinished">Curve line width</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="407"/>
        <source>数据类型</source>
        <translation type="unfinished">Data type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="412"/>
        <source>比例</source>
        <translation type="unfinished">Proportion</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="417"/>
        <source>路径</source>
        <translation type="unfinished">Path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="433"/>
        <source>+</source>
        <translation type="unfinished">+</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="446"/>
        <source>-</source>
        <translation type="unfinished">-</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="459"/>
        <source>M</source>
        <translation type="unfinished">M</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="485"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.ui" line="492"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.cpp" line="197"/>
        <source>检索器输入实时库指针未初始化</source>
        <translation type="unfinished">Retriever input TDB pointer is not initialized</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.cpp" line="462"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.cpp" line="462"/>
        <source>查询统计模型出错!</source>
        <translation type="unfinished">Error in querying statistical model!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.cpp" line="471"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.cpp" line="485"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.cpp" line="499"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.cpp" line="513"/>
        <source>选择颜色</source>
        <translation type="unfinished">Choose color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve.cpp" line="611"/>
        <source>会清空之前所有线数据!</source>
        <translation type="unfinished">It will clear all previous line data!</translation>
    </message>
</context>
<context>
    <name>dlg_curve_line</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="14"/>
        <source>dlg_curve_line</source>
        <translation type="unfinished">dlg_curve_line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="27"/>
        <source>日期设置</source>
        <translation type="unfinished">Set date</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="39"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="281"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="547"/>
        <source>类型:</source>
        <translation type="unfinished">Type.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="47"/>
        <source>当日</source>
        <translation type="unfinished">On the day</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="52"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="829"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="882"/>
        <source>昨日</source>
        <translation type="unfinished">Yesterday</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="57"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="834"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="887"/>
        <source>前日</source>
        <translation type="unfinished">The day before yesterday</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="62"/>
        <source>上周同日</source>
        <translation type="unfinished">Same day last week</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="67"/>
        <source>上月同日</source>
        <translation type="unfinished">Same day last month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="72"/>
        <source>去年同日</source>
        <translation type="unfinished">Same day last year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="77"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="130"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="849"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="902"/>
        <source>指定日期</source>
        <translation type="unfinished">Specified date</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="91"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="328"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="584"/>
        <source>当前基准</source>
        <translation type="unfinished">Current basis</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="124"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="361"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="617"/>
        <source>自定义设置</source>
        <translation type="unfinished">Custom settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="156"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="400"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="656"/>
        <source>时间段设置</source>
        <translation type="unfinished">Time period setting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="162"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="406"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="662"/>
        <source>时间段</source>
        <translation type="unfinished">Time period</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="169"/>
        <source>开始</source>
        <translation type="unfinished">Start</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="179"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="196"/>
        <source>HH:mm:ss</source>
        <translation type="unfinished">HH:mm:ss</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="186"/>
        <source>结束</source>
        <translation type="unfinished">Finish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="226"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="492"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="748"/>
        <source>数据类型</source>
        <translation type="unfinished">Data type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="232"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="498"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="754"/>
        <source>统计数据类型</source>
        <translation type="unfinished">Type of statistical data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="242"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="508"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="764"/>
        <source>数据比率</source>
        <translation type="unfinished">Data ratio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="269"/>
        <source>月份设置</source>
        <translation type="unfinished">Month settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="289"/>
        <source>当月</source>
        <translation type="unfinished">Current month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="294"/>
        <source>上月</source>
        <translation type="unfinished">Last month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="299"/>
        <source>上上月</source>
        <translation type="unfinished">Last month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="304"/>
        <source>去年同月</source>
        <translation type="unfinished">Same month last year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="309"/>
        <source>前年同月</source>
        <translation type="unfinished">The same month the year before</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="314"/>
        <source>指定月份</source>
        <translation type="unfinished">Specified month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="367"/>
        <source>指定年月</source>
        <translation type="unfinished">Specify year and month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="377"/>
        <source>yyyy/M</source>
        <translation type="unfinished">yyyy/M</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="419"/>
        <source>开始日期</source>
        <translation type="unfinished">Start date</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="429"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="462"/>
        <source>dd</source>
        <translation type="unfinished">dd</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="442"/>
        <source>结束日期</source>
        <translation type="unfinished">End date</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="535"/>
        <source>年份设置</source>
        <translation type="unfinished">Year settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="555"/>
        <source>当年</source>
        <translation type="unfinished">That year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="560"/>
        <source>去年</source>
        <translation type="unfinished">Last year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="565"/>
        <source>前年</source>
        <translation type="unfinished">Two years ago</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="570"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="623"/>
        <source>指定年份</source>
        <translation type="unfinished">Specified year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="633"/>
        <source>yyyy</source>
        <translation type="unfinished">yyyy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="675"/>
        <source>开始月份</source>
        <translation type="unfinished">Start month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="685"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="718"/>
        <source>MM</source>
        <translation type="unfinished">MM</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="698"/>
        <source>结束月份</source>
        <translation type="unfinished">End month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="791"/>
        <source>基准时间</source>
        <translation type="unfinished">Reference time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="797"/>
        <source>当前时间</source>
        <translation type="unfinished">Current time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="817"/>
        <source>起始时间设置</source>
        <translation type="unfinished">Set starttime</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="824"/>
        <source>今日</source>
        <translation type="unfinished">Today</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="839"/>
        <source>上月初</source>
        <translation type="unfinished">Early last month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="844"/>
        <source>去年年初</source>
        <translation type="unfinished">Early last year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="870"/>
        <source>结束时间设置</source>
        <translation type="unfinished">Set endtime</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="877"/>
        <source>当前</source>
        <translation type="unfinished">Current</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="892"/>
        <source>上个月末</source>
        <translation type="unfinished">Late last month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="897"/>
        <source>去年年末</source>
        <translation type="unfinished">Late last year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="938"/>
        <source>曲线设置</source>
        <translation type="unfinished">Curve Settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="949"/>
        <source>是否使用函数</source>
        <translation type="unfinished">Use function</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="967"/>
        <source>显示点</source>
        <translation type="unfinished">Display point</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="974"/>
        <source>点数据标签</source>
        <translation type="unfinished">Point data label</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="984"/>
        <source>点标签字体</source>
        <translation type="unfinished">Point label font</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="1021"/>
        <source>曲线颜色</source>
        <translation type="unfinished">Curve color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="1031"/>
        <source>#FF66CCFF</source>
        <translation type="unfinished">#FF66CCFF</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="1038"/>
        <source>C</source>
        <translation type="unfinished">C</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="1051"/>
        <source>曲线线宽</source>
        <translation type="unfinished">Curve line width</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="1101"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.ui" line="1108"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_curve_line.cpp" line="338"/>
        <source>选择颜色</source>
        <translation type="unfinished">Choose color</translation>
    </message>
</context>
<context>
    <name>dlg_gauge_panel</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="14"/>
        <source>仪表盘配置</source>
        <translation type="unfinished">Panel config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="20"/>
        <source>基础参数</source>
        <translation type="unfinished">Basic params</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="28"/>
        <source>单位：</source>
        <translation type="unfinished">Unit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="42"/>
        <source>单位颜色：</source>
        <translation type="unfinished">Unit:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="78"/>
        <source>仪表盘颜色：</source>
        <translation type="unfinished">Panel:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="110"/>
        <source>刻度颜色：</source>
        <translation type="unfinished">Tick:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="136"/>
        <source>轨道颜色：</source>
        <translation type="unfinished">Track:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="159"/>
        <source>最小刻度：</source>
        <translation type="unfinished">Minimum tick:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="169"/>
        <source>最大刻度：</source>
        <translation type="unfinished">Maximum tick:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="183"/>
        <source>上限值：</source>
        <translation type="unfinished">Upper limit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="197"/>
        <source>数据关联：</source>
        <translation type="unfinished">Data link:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="224"/>
        <source>图例：</source>
        <translation type="unfinished">Legend:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="242"/>
        <source>字体大小：</source>
        <translation type="unfinished">Font size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="263"/>
        <source>图例颜色：</source>
        <translation type="unfinished">Legend:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="151"/>
        <source>数据设置</source>
        <translation type="unfinished">Data settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="211"/>
        <source>关联</source>
        <translation type="unfinished">Link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="252"/>
        <source>加粗</source>
        <translation type="unfinished">Bold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="305"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_gauge_panel.ui" line="312"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>dlg_grid_box_config</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="20"/>
        <source>网格框属性配置</source>
        <translation type="unfinished">Grid box attr config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="29"/>
        <source>网格尺寸</source>
        <translation type="unfinished">Grid size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="41"/>
        <source>行数:</source>
        <translation type="unfinished">Number of rows:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="61"/>
        <source>列数:</source>
        <translation type="unfinished">Number of columns:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="84"/>
        <source>显示选项</source>
        <translation type="unfinished">Display options</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="93"/>
        <source>显示网格线</source>
        <translation type="unfinished">Show Grid Lines</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="103"/>
        <source>显示边框</source>
        <translation type="unfinished">Display border</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="113"/>
        <source>实时预览</source>
        <translation type="unfinished">Live preview</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="139"/>
        <source>标题栏设置</source>
        <translation type="unfinished">Title bar setting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="148"/>
        <source>标题栏高度:</source>
        <translation type="unfinished">Title bar height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="202"/>
        <source>线条属性</source>
        <translation type="unfinished">Line Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="217"/>
        <source>网格:</source>
        <translation type="unfinished">Grid:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="236"/>
        <source>选择网格线颜色</source>
        <translation type="unfinished">Select grid line color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="252"/>
        <source>线条宽度:</source>
        <translation type="unfinished">Line width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="296"/>
        <source>线条样式:</source>
        <translation type="unfinished">Line style:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="335"/>
        <source>边框:</source>
        <translation type="unfinished">Border:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="354"/>
        <source>选择边框颜色</source>
        <translation type="unfinished">Choose border color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="380"/>
        <source>尺寸设置</source>
        <translation type="unfinished">Size setting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="391"/>
        <source>统一尺寸</source>
        <translation type="unfinished">Uniform size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="401"/>
        <source>自定义尺寸</source>
        <translation type="unfinished">Custom Size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="430"/>
        <source>统一列宽:</source>
        <translation type="unfinished">Uniform column width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="450"/>
        <source>统一行高:</source>
        <translation type="unfinished">Uniform row height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="474"/>
        <source>列宽设置</source>
        <translation type="unfinished">Column width setting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="488"/>
        <source>将所有列设置为上方&quot;统一列宽&quot;的数值</source>
        <translation type="unfinished">Set all columns to the value of &apos;uniform column width&apos; above</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="491"/>
        <source>应用统一宽度</source>
        <translation type="unfinished">Apply uniform width</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="498"/>
        <source>重置所有列宽为平均分配的默认值</source>
        <translation type="unfinished">Reset all column widths to the default value of equal distribution</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="501"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="583"/>
        <source>平均分配</source>
        <translation type="unfinished">Equal distribution</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="556"/>
        <source>行高设置</source>
        <translation type="unfinished">Row height setting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="570"/>
        <source>将所有行设置为上方&quot;统一行高&quot;的数值</source>
        <translation type="unfinished">Set all rows to the value of &apos;uniform row height&apos; above</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="573"/>
        <source>应用统一高度</source>
        <translation type="unfinished">Apply uniform height</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="580"/>
        <source>重置所有行高为平均分配的默认值</source>
        <translation type="unfinished">Reset all row heights to the default value of equal distribution</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="667"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="683"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="696"/>
        <source>应用</source>
        <translation type="unfinished">Apply</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_grid_box_config.ui" line="709"/>
        <source>重置</source>
        <translation type="unfinished">Reset</translation>
    </message>
</context>
<context>
    <name>dlg_pie</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="14"/>
        <source>饼图</source>
        <translation type="unfinished">Pie chart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="28"/>
        <source>标题</source>
        <translation type="unfinished">Title</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="63"/>
        <source>图例</source>
        <translation type="unfinished">Legend</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="20"/>
        <source>基础设置</source>
        <translation type="unfinished">Basic settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="45"/>
        <source>边框</source>
        <translation type="unfinished">Border</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="72"/>
        <source>位置</source>
        <translation type="unfinished">Position</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="86"/>
        <source>后缀</source>
        <translation type="unfinished">Suffix</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="106"/>
        <source>饼图显示值</source>
        <translation type="unfinished">Pie chart display value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="113"/>
        <source>小数点位数：</source>
        <translation type="unfinished">Decimal places:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="123"/>
        <source>是否显示百分比</source>
        <translation type="unfinished">Show percentage?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="135"/>
        <source>参数设置</source>
        <translation type="unfinished">Param settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="143"/>
        <source>起始角度</source>
        <translation type="unfinished">Initial angle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="160"/>
        <source>结束角度</source>
        <translation type="unfinished">End angle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="184"/>
        <source>大小</source>
        <translation type="unfinished">Size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="204"/>
        <source>孔大小</source>
        <translation type="unfinished">Hole size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="226"/>
        <source>点</source>
        <translation type="unfinished">Point</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="253"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="372"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="258"/>
        <source>路径</source>
        <translation type="unfinished">Path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="274"/>
        <source>添加</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="277"/>
        <source>+</source>
        <translation type="unfinished">+</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="290"/>
        <source>复制</source>
        <translation type="unfinished">Copy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="293"/>
        <source>C</source>
        <translation type="unfinished">C</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="306"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="309"/>
        <source>-</source>
        <translation type="unfinished">-</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="322"/>
        <source>上移</source>
        <translation type="unfinished">Move up</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="325"/>
        <source>↑</source>
        <translation type="unfinished">↑</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="338"/>
        <source>下移</source>
        <translation type="unfinished">Move down</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="341"/>
        <source>↓</source>
        <translation type="unfinished">↓</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="402"/>
        <source>标签位置</source>
        <translation type="unfinished">label position</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="458"/>
        <source>数据颜色</source>
        <translation type="unfinished">Data color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="428"/>
        <source>标签颜色</source>
        <translation type="unfinished">Label color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="517"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.ui" line="524"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.cpp" line="30"/>
        <source>外部</source>
        <translation type="unfinished">External</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.cpp" line="31"/>
        <source>内部</source>
        <translation type="unfinished">Interior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.cpp" line="34"/>
        <source>右上</source>
        <translation type="unfinished">Top right</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.cpp" line="35"/>
        <source>右下</source>
        <translation type="unfinished">bottom right</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.cpp" line="36"/>
        <source>左下</source>
        <translation type="unfinished">bottom left</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.cpp" line="37"/>
        <source>左上</source>
        <translation type="unfinished">Top left</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.cpp" line="397"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_pie.cpp" line="397"/>
        <source>饼状图：图例名称限制长度为10个字符，请检查。</source>
        <translation type="unfinished">Pie chart: Legend name is limited to 10 characters. Please check.</translation>
    </message>
</context>
<context>
    <name>dlg_progress_bar</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="14"/>
        <source>进度条</source>
        <translation type="unfinished">Progress bar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="22"/>
        <source>标题</source>
        <translation type="unfinished">Title</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="45"/>
        <source>标题位置</source>
        <translation type="unfinished">Title position</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="53"/>
        <source>左</source>
        <translation type="unfinished">Left</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="58"/>
        <source>下</source>
        <translation type="unfinished">Down</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="66"/>
        <source>数据位置</source>
        <translation type="unfinished">Data location</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="74"/>
        <source>右</source>
        <translation type="unfinished">right</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="79"/>
        <source>上</source>
        <translation type="unfinished">Up</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="111"/>
        <source>F</source>
        <translation type="unfinished">F</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="128"/>
        <source>小数点后位数:</source>
        <translation type="unfinished">Decimal places:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="97"/>
        <source>字 体:</source>
        <translation type="unfinished">Font:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="158"/>
        <source>路 径:</source>
        <translation type="unfinished">Path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="172"/>
        <source>M</source>
        <translation type="unfinished">M</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="189"/>
        <source>数据范围:</source>
        <translation type="unfinished">Data range:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="223"/>
        <source>是否使用函数</source>
        <translation type="unfinished">Use function</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="247"/>
        <source>前景色:</source>
        <translation type="unfinished">Foreground color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="257"/>
        <source>#FF66CCFF</source>
        <translation type="unfinished">#FF66CCFF</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="264"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="298"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="335"/>
        <source>C</source>
        <translation type="unfinished">C</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="281"/>
        <source>背景色:</source>
        <translation type="unfinished">BG color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="291"/>
        <source>#FF39C5BB</source>
        <translation type="unfinished">#FF39C5BB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="316"/>
        <source>边框色:</source>
        <translation type="unfinished">Border color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="328"/>
        <source>#FF000000</source>
        <translation type="unfinished">#FF000000</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="360"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.ui" line="367"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.cpp" line="114"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.cpp" line="129"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_progress_bar.cpp" line="144"/>
        <source>选择颜色</source>
        <translation type="unfinished">Choose color</translation>
    </message>
</context>
<context>
    <name>dlg_single_ring</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="14"/>
        <source>环形图</source>
        <translation type="unfinished">Ring chart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="20"/>
        <source>图例设置</source>
        <translation type="unfinished">Legend settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="88"/>
        <source>图例间距</source>
        <translation type="unfinished">Legend spacing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="37"/>
        <source>图例位置</source>
        <translation type="unfinished">Legend location</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="113"/>
        <source>基础参数</source>
        <translation type="unfinished">Basic params</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="123"/>
        <source>环的个数</source>
        <translation type="unfinished">Rings count</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="179"/>
        <source>样式设置</source>
        <translation type="unfinished">Style settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="28"/>
        <source>显示图例</source>
        <translation type="unfinished">Show legend </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="51"/>
        <source>显示值</source>
        <translation type="unfinished">Display value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="58"/>
        <source>后缀</source>
        <translation type="unfinished">Suffix</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="68"/>
        <source>边框</source>
        <translation type="unfinished">Border</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="98"/>
        <source>小数位数：</source>
        <translation type="unfinished">Decimal places:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="137"/>
        <source>起始角度</source>
        <translation type="unfinished">Initial angle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="155"/>
        <source>结束角度</source>
        <translation type="unfinished">End angle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="185"/>
        <source>环上显示值</source>
        <translation type="unfinished">Value displayed on the ring</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="194"/>
        <source>内环半径</source>
        <translation type="unfinished">Inner ring radius</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="208"/>
        <source>环间距</source>
        <translation type="unfinished">Ring spacing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="222"/>
        <source>文字颜色</source>
        <translation type="unfinished">Text color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="240"/>
        <source>字体大小</source>
        <translation type="unfinished">Font size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="273"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.ui" line="280"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="572"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="697"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="1228"/>
        <source>选择颜色</source>
        <translation type="unfinished">Choose color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="219"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="936"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="949"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="1019"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="220"/>
        <source>当前环数下，环间距过大，请减小环间距或减少环数！</source>
        <translation type="unfinished">Under the current number of rings, the ring spacing is too large. Please reduce the ring spacing or the number of rings!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="74"/>
        <source>右上</source>
        <translation type="unfinished">Top right</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="75"/>
        <source>右下</source>
        <translation type="unfinished">bottom right</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="76"/>
        <source>左下</source>
        <translation type="unfinished">bottom left</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="77"/>
        <source>左上</source>
        <translation type="unfinished">Top left</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="236"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="746"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="237"/>
        <source>已自动调整内环半径</source>
        <translation type="unfinished">The inner ring radius has been automatically adjusted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="276"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="276"/>
        <source>路径</source>
        <translation type="unfinished">Path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="276"/>
        <source>颜色</source>
        <translation type="unfinished">Color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="318"/>
        <source>添加</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="319"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="320"/>
        <source>复制</source>
        <translation type="unfinished">Copy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="419"/>
        <source>确认切换</source>
        <translation type="unfinished">Confirm switch</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="420"/>
        <source>切换环数将清空当前所有数据，是否继续</source>
        <translation type="unfinished">Switching the number of loops will clear all current data. Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="481"/>
        <source>环</source>
        <translation type="unfinished">Ring</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="481"/>
        <source>数据表</source>
        <translation type="unfinished">Data table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="746"/>
        <source>请输入图例名称</source>
        <translation type="unfinished">Please enter the legend name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="921"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="921"/>
        <source>环形图：图例名称限制长度为10个字符，请检查。</source>
        <translation type="unfinished">Ring chart: Legend name is limited to 10 characters. Please check.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="936"/>
        <source>请至少添加一条数据！</source>
        <translation type="unfinished">Please add at least one piece of data!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="949"/>
        <source>内环半径与环间距之和不能超过1！</source>
        <translation type="unfinished">The sum of the inner ring radius and the ring spacing cannot exceed 1!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="1019"/>
        <source>结束角度必须大于起始角度！</source>
        <translation type="unfinished">The end angle must be greater than the start angle!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="1078"/>
        <source>确认取消</source>
        <translation type="unfinished">Confirm Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_gui/dialogs/edit/dlg_single_ring.cpp" line="1079"/>
        <source>是否确认取消？已输入的数据将会丢失。</source>
        <translation type="unfinished">Data not saved, whether to cancel</translation>
    </message>
</context>
</TS>
