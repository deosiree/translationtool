<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>DlgVerifyLicense</name>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="40"/>
        <source>请输入机器码</source>
        <translation type="unfinished">Por favor, ingrese el código de máquina</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="78"/>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="85"/>
        <source>注册码验证工具</source>
        <translation type="unfinished">Herramienta de verificación de código de registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="151"/>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="156"/>
        <source>%1</source>
        <translation type="unfinished">%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="181"/>
        <source>永久有效</source>
        <translation type="unfinished">Válido permanentemente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="188"/>
        <source>验证成功</source>
        <translation type="unfinished">Validado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="197"/>
        <source>失败</source>
        <translation type="unfinished">Fallo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="197"/>
        <source>写入文件失败!</source>
        <translation type="unfinished">¡Fallo al escribir el archivo!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="197"/>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="228"/>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="243"/>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="255"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="202"/>
        <source>注册码错误!</source>
        <translation type="unfinished">¡Código de registro incorrecto!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="206"/>
        <source>时间超限!</source>
        <translation type="unfinished">¡Tiempo límite excedido!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="210"/>
        <source>机器码不对应!</source>
        <translation type="unfinished">¡El código de la máquina no coincide!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="214"/>
        <source>程序错误!</source>
        <translation type="unfinished">¡Error en el programa!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="228"/>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="243"/>
        <source>生成失败</source>
        <translation type="unfinished">Error al generar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="228"/>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="243"/>
        <source>注册文件生成失败</source>
        <translation type="unfinished">Error al generar el archivo de registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="247"/>
        <source>注册文件成功保存到%1</source>
        <translation type="unfinished">Archivo de registro guardado en %1 exitosamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="252"/>
        <source>成功</source>
        <translation type="unfinished">Éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="253"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.cpp" line="78"/>
        <source>(节点名:</source>
        <translation type="unfinished">(Nodo:</translation>
    </message>
</context>
<context>
    <name>dlg_verify_license</name>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="40"/>
        <source>验证区</source>
        <translation type="unfinished">Área de verificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="50"/>
        <source>机器码:</source>
        <translation type="unfinished">Código de la máquina:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="60"/>
        <source>注册码：</source>
        <translation type="unfinished">Código de registro:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="80"/>
        <source>生成注册文件</source>
        <translation type="unfinished">Generar archivo de registro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="106"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="119"/>
        <source>验证</source>
        <translation type="unfinished">Verificar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="133"/>
        <source>验证结果</source>
        <translation type="unfinished">Resultados de verificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="213"/>
        <source>验证信息：</source>
        <translation type="unfinished">Información de verificación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="246"/>
        <source>版本号：</source>
        <translation type="unfinished">Número de versión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="260"/>
        <source>过期时间：</source>
        <translation type="unfinished">Tiempo de expiración:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="274"/>
        <source>客户名称：</source>
        <translation type="unfinished">Nombre del cliente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/license/gui_verify_license/src/dlg_verify_license.ui" line="281"/>
        <source>产品名称：</source>
        <translation type="unfinished">Nombre del producto:</translation>
    </message>
</context>
</TS>
