<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>FirewallInfo</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secfirewall/firewall_info.ui" line="14"/>
        <source>FirewallInfo</source>
        <translation type="unfinished">FirewallInfo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secfirewall/firewall_info.ui" line="32"/>
        <source>当前节点防火墙配置</source>
        <translation type="unfinished">Configurar el firewall en el nodo actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secfirewall/firewall_info.ui" line="72"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secfirewall/firewall_info.cpp" line="30"/>
        <source>WINDOWS节点不支持加固功能</source>
        <translation type="unfinished">Los nodos de WINDOWS no admiten endurecimiento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secfirewall/firewall_info.cpp" line="34"/>
        <source>当前节点防火墙配置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Configuración del firewall del nodo actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secfirewall/firewall_info.cpp" line="44"/>
        <source>当前节点未进行加固</source>
        <comment>subTitle</comment>
        <translation type="unfinished">El nodo actual no está reforzado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secfirewall/firewall_info.cpp" line="61"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secfirewall/firewall_info.cpp" line="61"/>
        <source>刷新成功</source>
        <translation type="unfinished">Actualización exitosa</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secfirewall/plugin_sec_firewall.cpp" line="42"/>
        <source>用户登录信息</source>
        <translation type="unfinished">Info de inicio de sesión</translation>
    </message>
</context>
</TS>
