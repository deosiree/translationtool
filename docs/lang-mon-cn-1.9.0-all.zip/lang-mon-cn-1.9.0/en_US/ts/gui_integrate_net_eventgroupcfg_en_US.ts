<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>EventGroup</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.ui" line="14"/>
        <source>EventGroup</source>
        <translation type="unfinished">EventGroup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.ui" line="66"/>
        <source>事件分组表</source>
        <translation type="unfinished">Event grouping table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.ui" line="80"/>
        <source>事件分组名称</source>
        <translation type="unfinished">Event group name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.ui" line="85"/>
        <source>事件分组描述</source>
        <translation type="unfinished">Event group description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.ui" line="139"/>
        <source>分组事件表</source>
        <translation type="unfinished">Grouped event table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.ui" line="150"/>
        <source>子系统名称</source>
        <translation type="unfinished">Subsystem name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.ui" line="155"/>
        <source>功能项名称</source>
        <translation type="unfinished">Function item name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.ui" line="160"/>
        <source>操作项名称</source>
        <translation type="unfinished">Operation item name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.ui" line="165"/>
        <source>事件号</source>
        <translation type="unfinished">Event ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="192"/>
        <source>行名称和描述不能为空</source>
        <translation type="unfinished">The row name and description cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="193"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="219"/>
        <source>更新失败，错误码：</source>
        <translation type="unfinished">Update failed, error code:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="221"/>
        <source>更新失败</source>
        <translation type="unfinished">Update failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="225"/>
        <source>分组更新成功</source>
        <translation type="unfinished">Group update successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="226"/>
        <source>更新成功</source>
        <translation type="unfinished">Update successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="244"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="606"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="644"/>
        <source>插入失败，错误码：</source>
        <translation type="unfinished">Insert failed, error code:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="246"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="608"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="616"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="646"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="654"/>
        <source>插入失败</source>
        <translation type="unfinished">Insertion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="250"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="251"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="627"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="665"/>
        <source>插入成功</source>
        <translation type="unfinished">Inserted successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="280"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="302"/>
        <source>与第%1行分组名称重复</source>
        <translation type="unfinished">Same as row %1 group name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="281"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="303"/>
        <source>修改失败</source>
        <translation type="unfinished">Modification failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="372"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="377"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="536"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="541"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="631"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="372"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="536"/>
        <source>未选中任何行</source>
        <translation type="unfinished">No rows selected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="377"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="541"/>
        <source>删除后无法恢复，是否继续？</source>
        <translation type="unfinished">Deletion cannot be recovered. Whether to continue?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="409"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="565"/>
        <source>删除失败，错误码：</source>
        <translation type="unfinished">Deletion failed; error code:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="411"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="567"/>
        <source>删除失败</source>
        <translation type="unfinished">Deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="415"/>
        <source>分组删除成功</source>
        <translation type="unfinished">Group deleted successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="428"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="589"/>
        <source>删除成功</source>
        <translation type="unfinished">Delete successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="437"/>
        <source>未关联</source>
        <translation type="unfinished">Not linked</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="449"/>
        <source>oid错误</source>
        <translation type="unfinished">Wrong Oid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="614"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="652"/>
        <source>单项引用事件失败，错误码：</source>
        <translation type="unfinished">Failed to reference a single event, error code:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="627"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="665"/>
        <source>事件插入成功</source>
        <translation type="unfinished">Event insert successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventgroup.cpp" line="631"/>
        <source>未选中任何事件</source>
        <translation type="unfinished">No event is selected</translation>
    </message>
</context>
<context>
    <name>NewEventGroup</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/neweventgroup.ui" line="14"/>
        <source>新增分组事件表</source>
        <translation type="unfinished">Added the group event table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/neweventgroup.ui" line="71"/>
        <source>子系统：</source>
        <translation type="unfinished">Subsystems:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/neweventgroup.ui" line="92"/>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/neweventgroup.ui" line="203"/>
        <source>请输入关键词查询</source>
        <translation type="unfinished">Please enter a keyword query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/neweventgroup.ui" line="164"/>
        <source>子集信息：</source>
        <translation type="unfinished">Subset info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/neweventgroup.ui" line="222"/>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/neweventgroup.cpp" line="41"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/neweventgroup.cpp" line="42"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>eventMenu</name>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventMenu.cpp" line="11"/>
        <source>新增</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventMenu.cpp" line="40"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/net/gui_integrate_net_eventgroupcfg/eventMenu.cpp" line="41"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
</context>
</TS>
