<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>ApiSelectHandler</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1824"/>
        <source>状态前景图元：%1 %2</source>
        <translation type="unfinished">State foreground icon:%1 %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1833"/>
        <source>状态前景</source>
        <translation type="unfinished">State foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1833"/>
        <source>合成光字牌</source>
        <translation type="unfinished">Composite annunciator</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1838"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1884"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1933"/>
        <source>属性配置：%1</source>
        <translation type="unfinished">Attr Config: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1872"/>
        <source>字符前景图元：%1 %2</source>
        <translation type="unfinished">Character foreground icon:%1 %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1880"/>
        <source>字符前景</source>
        <translation type="unfinished">Character foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1920"/>
        <source>数值前景图元：%1 %2</source>
        <translation type="unfinished">Number foreground icon: %1 %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="1928"/>
        <source>数值前景</source>
        <translation type="unfinished">Value foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_select_handler.cpp" line="2550"/>
        <source>图片原始信息:宽 %1，高 %2  (单位:像素)</source>
        <translation type="unfinished">Original picture info: width %1, height %2 (Unit: pixel)</translation>
    </message>
</context>
<context>
    <name>ApiTermHandler</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_term_handler.cpp" line="55"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/api_term_handler.cpp" line="55"/>
        <source>非图元默认态不能进行端点的插入!</source>
        <translation type="unfinished">Unless it is the icon default state, endpoints cannot be inserted!</translation>
    </message>
</context>
<context>
    <name>DlgAddApp</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.ui" line="14"/>
        <source>添加应用</source>
        <translation type="unfinished">Add app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.ui" line="22"/>
        <source>应用名</source>
        <translation type="unfinished">App name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.ui" line="40"/>
        <source>类型</source>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.ui" line="54"/>
        <source>是否在监视工具中显示</source>
        <translation type="unfinished">Display in monitors</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.ui" line="94"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.ui" line="101"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.cpp" line="85"/>
        <source>异常输入</source>
        <translation type="unfinished">Invalid input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.cpp" line="85"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished">Query data exception; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.cpp" line="91"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_app.cpp" line="91"/>
        <source>名称不可为空</source>
        <translation type="unfinished">Name cannot be empty</translation>
    </message>
</context>
<context>
    <name>DlgAddPicType</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.ui" line="14"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.ui" line="43"/>
        <source>画面类型</source>
        <translation type="unfinished">Graph type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.ui" line="22"/>
        <source>画面类型名</source>
        <translation type="unfinished">Graph type name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.ui" line="67"/>
        <source>画面枚举</source>
        <translation type="unfinished">Graph enumeration</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.ui" line="98"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.ui" line="105"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.cpp" line="52"/>
        <source>异常输入</source>
        <translation type="unfinished">Invalid input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.cpp" line="52"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished">Query data exception; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.cpp" line="58"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_add_pic_type.cpp" line="58"/>
        <source>画面类型名称不可为空</source>
        <translation type="unfinished">Graph type name cannot be empty</translation>
    </message>
</context>
<context>
    <name>DlgChangeIcon</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_change_icon.ui" line="22"/>
        <source>图元名称:</source>
        <translation type="unfinished">Icon name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_change_icon.ui" line="59"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_change_icon.ui" line="66"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_change_icon.cpp" line="32"/>
        <source>图元选择</source>
        <translation type="unfinished">Icon Selection</translation>
    </message>
</context>
<context>
    <name>DlgDecisionInfo</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.ui" line="40"/>
        <source>表达式详情：</source>
        <translation type="unfinished">Expression details:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="42"/>
        <source>决策信息</source>
        <translation type="unfinished">Decision info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="73"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="138"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="79"/>
        <source>决策类型</source>
        <translation type="unfinished">Decision type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="85"/>
        <source>决策集合</source>
        <translation type="unfinished">Decision set</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="91"/>
        <source>决策应用</source>
        <translation type="unfinished">Decision App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="97"/>
        <source>决策模式库</source>
        <translation type="unfinished">Decision mode db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="104"/>
        <source>决策值</source>
        <translation type="unfinished">Decision value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="110"/>
        <source>决策表达式</source>
        <translation type="unfinished">Decision expression</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="116"/>
        <source>决策值2</source>
        <translation type="unfinished">Decision value 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="122"/>
        <source>决策值3</source>
        <translation type="unfinished">Decision value 3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="144"/>
        <source>因子值</source>
        <translation type="unfinished">Factor value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="150"/>
        <source>因子名称</source>
        <translation type="unfinished">Factor name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="156"/>
        <source>因子路径</source>
        <translation type="unfinished">Factor path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="162"/>
        <source>因子类别</source>
        <translation type="unfinished">Factor type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="174"/>
        <source>实时表域</source>
        <translation type="unfinished">Real-time table field</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="186"/>
        <source>历史表域</source>
        <translation type="unfinished">History table field</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="192"/>
        <source>扩展数据源类名</source>
        <translation type="unfinished">Extend the data source class name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="198"/>
        <source>扩展数据源动态库路径</source>
        <translation type="unfinished">Extend the data source dynamic db path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="204"/>
        <source>备用扩展数据源参数</source>
        <translation type="unfinished">Backup extended data source params</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="210"/>
        <source>备用扩展数据源参数2</source>
        <translation type="unfinished">Backup extended data source param 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="435"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="454"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="471"/>
        <source>闪烁</source>
        <translation type="unfinished">Flashing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="439"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="458"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="475"/>
        <source>不闪烁</source>
        <translation type="unfinished">No Flashing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="520"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="539"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="556"/>
        <source>使能</source>
        <translation type="unfinished">Enable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="524"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="543"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/view/dlg_decision_info.cpp" line="560"/>
        <source>不使能</source>
        <translation type="unfinished">No Enable</translation>
    </message>
</context>
<context>
    <name>DlgDynRectTable</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="565"/>
        <source>纵向表头</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Vertical Header</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="771"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="634"/>
        <source>奇数行：</source>
        <translation type="unfinished">Odd rows:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="785"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="635"/>
        <source>偶数行：</source>
        <translation type="unfinished">Even rows:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1384"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1391"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="30"/>
        <source>基本选项</source>
        <translation type="unfinished">Basic Options</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="38"/>
        <source>框架:</source>
        <translation type="unfinished">Framework:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="89"/>
        <source>效果：</source>
        <translation type="unfinished">Effect:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="237"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="517"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="604"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="746"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1238"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1331"/>
        <source>背景色：</source>
        <translation type="unfinished">Background color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="478"/>
        <source>横向表头</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Horizontal Header</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="486"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="573"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1198"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1291"/>
        <source>文字字体：</source>
        <translation type="unfinished">Text font:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="263"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="548"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="635"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1211"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1304"/>
        <source>字体设置</source>
        <translation type="unfinished">Font settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="202"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="531"/>
        <source>高度：</source>
        <translation type="unfinished">Height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="216"/>
        <source>分页按钮：</source>
        <translation type="unfinished">Pagination buttons:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="75"/>
        <source>垂直网格线：</source>
        <translation type="unfinished">Vertical grid lines:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="310"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="507"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="594"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1218"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1311"/>
        <source>文字颜色：</source>
        <translation type="unfinished">Text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="195"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="618"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1096"/>
        <source>宽度：</source>
        <translation type="unfinished">Width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="120"/>
        <source>水平网格线：</source>
        <translation type="unfinished">Horizontal grid lines:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="399"/>
        <source>间隔：</source>
        <translation type="unfinished">Interval:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="303"/>
        <source>边框色：</source>
        <translation type="unfinished">Border color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="96"/>
        <source>单页行数：</source>
        <translation type="unfinished">Rows per page:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="366"/>
        <source>分栏：</source>
        <translation type="unfinished">Col-split:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="113"/>
        <source>分页</source>
        <translation type="unfinished">Pagination</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="134"/>
        <source>外框：</source>
        <translation type="unfinished">Outer border:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="230"/>
        <source>首/尾页</source>
        <translation type="unfinished">First/last page</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="209"/>
        <source>支持跳转</source>
        <translation type="unfinished">Support jump</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="223"/>
        <source>显示翻页</source>
        <translation type="unfinished">Display Pagination</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="440"/>
        <source>表头：</source>
        <translation type="unfinished">Header:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="524"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="611"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1258"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1351"/>
        <source>边框：</source>
        <translation type="unfinished">Border:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="721"/>
        <source>单元格：</source>
        <translation type="unfinished">Cell:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="755"/>
        <source>单色</source>
        <translation type="unfinished">Monochrome</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="762"/>
        <source>间隔色</source>
        <translation type="unfinished">Interval color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="808"/>
        <source>颜色效果预览：</source>
        <translation type="unfinished">Color effect preview:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="903"/>
        <source>跳转</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Jump</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="920"/>
        <source>数据关联</source>
        <translation type="unfinished">Data Link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="940"/>
        <source>条件列表：</source>
        <translation type="unfinished">List of conditions:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="957"/>
        <source>清空</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="950"/>
        <source>检索</source>
        <translation type="unfinished">Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="14"/>
        <source>动态表格配置</source>
        <translation type="unfinished">Dynamic table config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="175"/>
        <source>文字字体</source>
        <translation type="unfinished">Text font</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="296"/>
        <source>按钮凹凸</source>
        <translation type="unfinished">Toggle Style</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="375"/>
        <source>栏数：</source>
        <translation type="unfinished">Number of columns:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="684"/>
        <source>显示标题</source>
        <translation type="unfinished">Show title</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="691"/>
        <source>标题属性</source>
        <translation type="unfinished">Title attr</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="708"/>
        <source>标题间距：</source>
        <translation type="unfinished">Title spacing:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="850"/>
        <source>&lt;&lt;</source>
        <translation type="unfinished">&lt;&lt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="863"/>
        <source>&lt;</source>
        <translation type="unfinished">&lt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="870"/>
        <source>1/1</source>
        <translation type="unfinished">1/1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="883"/>
        <source>&gt;</source>
        <translation type="unfinished">&gt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="896"/>
        <source>&gt;&gt;</source>
        <translation type="unfinished">&gt;&gt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="930"/>
        <source>表类型：</source>
        <translation type="unfinished">Table type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="964"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="975"/>
        <source>域列表：</source>
        <translation type="unfinished">Filed list:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="982"/>
        <source>列显示</source>
        <translation type="unfinished">Column display</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="989"/>
        <source>行显示</source>
        <translation type="unfinished">Line display</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1009"/>
        <source>上移</source>
        <translation type="unfinished">Move up</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1016"/>
        <source>下移</source>
        <translation type="unfinished">Move down</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1023"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1037"/>
        <source>显示方式：</source>
        <translation type="unfinished">Display mode:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1044"/>
        <source>平铺</source>
        <translation type="unfinished">tiled</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1051"/>
        <source>树结构</source>
        <translation type="unfinished">Tree structure</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1122"/>
        <source>初始顺序：</source>
        <translation type="unfinished">Original order:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="658"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1145"/>
        <source>标题栏：</source>
        <translation type="unfinished">Title bar:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1152"/>
        <source>标题名称：</source>
        <translation type="unfinished">Title:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="698"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1172"/>
        <source>标题高度：</source>
        <translation type="unfinished">Title height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.ui" line="1284"/>
        <source>树状图：</source>
        <translation type="unfinished">Tree diagram</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="1243"/>
        <source>条件检索</source>
        <translation type="unfinished">Search Conditions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="1865"/>
        <source>是否清空所有对象</source>
        <translation type="unfinished">Whether to clear all objects</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2005"/>
        <source>配置新名称</source>
        <translation type="unfinished">Config name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="623"/>
        <source>奇数列：</source>
        <translation type="unfinished">Odd columns:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="244"/>
        <source>列名1</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Col2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="244"/>
        <source>列名2</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Col4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="244"/>
        <source>列名3</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Col6</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="254"/>
        <source>行 %1</source>
        <translation type="unfinished">Line %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="624"/>
        <source>偶数列：</source>
        <translation type="unfinished">Even columns:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="890"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2218"/>
        <source>&lt;双击编辑&gt;</source>
        <translation type="unfinished">&lt;Double-click editing&gt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="1866"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="1965"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="1965"/>
        <source>检索路径不为空</source>
        <translation type="unfinished">The retrieval path is not empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2015"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2016"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2026"/>
        <source>配置模板名称选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">Select Template Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2046"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2062"/>
        <source>信息</source>
        <translation type="unfinished">Message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2046"/>
        <source>名称不能为空</source>
        <translation type="unfinished">Name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2062"/>
        <source>保存至%1</source>
        <translation type="unfinished">Save to %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2075"/>
        <source>表名</source>
        <translation type="unfinished">Table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2075"/>
        <source>域名</source>
        <translation type="unfinished">Field name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2075"/>
        <source>表ID</source>
        <translation type="unfinished">Table ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2075"/>
        <source>域ID</source>
        <translation type="unfinished">Field ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2075"/>
        <source>列名</source>
        <translation type="unfinished">Column name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2075"/>
        <source>前景类型</source>
        <translation type="unfinished">Foreground type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2075"/>
        <source>操作</source>
        <translation type="unfinished">Operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2075"/>
        <source>域类型</source>
        <translation type="unfinished">Field type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2076"/>
        <source>高度</source>
        <translation type="unfinished">Height</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2076"/>
        <source>宽度</source>
        <translation type="unfinished">Width</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2076"/>
        <source>隐藏</source>
        <translation type="unfinished">Hide</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2076"/>
        <source>合并到上一层</source>
        <translation type="unfinished">Merge to previous layer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2076"/>
        <source>隐藏表</source>
        <translation type="unfinished">Hide table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2077"/>
        <source>合并表</source>
        <translation type="unfinished">Merge table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="3247"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="3247"/>
        <source>表格对象或标题属性为空</source>
        <translation type="unfinished">The table object or title attribute is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="3255"/>
        <source>标题设置</source>
        <translation type="unfinished">Title setting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2076"/>
        <source>行间距</source>
        <translation type="unfinished">Line spacing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2076"/>
        <source>列间距</source>
        <translation type="unfinished">Column spacing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_dynamics_rect_table.cpp" line="2683"/>
        <source>名称重复，是否替换</source>
        <translation type="unfinished">Duplicate name, whether to replace it</translation>
    </message>
</context>
<context>
    <name>DlgEquipmentTempalte</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="24"/>
        <source>数据配置</source>
        <translation type="unfinished">Data Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="54"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="284"/>
        <source>数据路径：</source>
        <translation type="unfinished">Data path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="64"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="270"/>
        <source>清除</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="74"/>
        <source>属性定义</source>
        <translation type="unfinished">Define Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="80"/>
        <source>基本属性：</source>
        <translation type="unfinished">Basic attrs:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="101"/>
        <source>宽度：</source>
        <translation type="unfinished">Width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="114"/>
        <source>X坐标：</source>
        <translation type="unfinished">X-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="121"/>
        <source>高度：</source>
        <translation type="unfinished">Height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="128"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Y-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="147"/>
        <source>线宽</source>
        <translation type="unfinished">Line width</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="158"/>
        <source>X坐标</source>
        <translation type="unfinished">X-coordinate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="163"/>
        <source>Y坐标</source>
        <translation type="unfinished">Y-coordinate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="177"/>
        <source>设备属性：</source>
        <translation type="unfinished">Device Attrs:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="185"/>
        <source>图元类型：</source>
        <translation type="unfinished">Icon type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="199"/>
        <source>图元决策：</source>
        <translation type="unfinished">Icon Decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="305"/>
        <source>条件：    </source>
        <translation type="unfinished">Condition:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="333"/>
        <source>电压等级：</source>
        <translation type="unfinished">Voltage level:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="357"/>
        <source>数据标识 ：</source>
        <translation type="unfinished">Data identification:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="371"/>
        <source>标签</source>
        <translation type="unfinished">Tag</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="216"/>
        <source>是否直接使用数据库关联</source>
        <translation type="unfinished">Whether to use db link directly</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="219"/>
        <source>是否取库</source>
        <translation type="unfinished">Retrieve db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="251"/>
        <source>数据库链接</source>
        <translation type="unfinished">DB link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="254"/>
        <source>数据库连接</source>
        <translation type="unfinished">DB connection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="267"/>
        <source>清除链接</source>
        <translation type="unfinished">Clear links</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="324"/>
        <source>无电压等级</source>
        <translation type="unfinished">No voltage level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="354"/>
        <source>数据库OID</source>
        <translation type="unfinished">DB OID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="401"/>
        <source>更换图元</source>
        <translation type="unfinished">Replace icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="419"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="439"/>
        <source>确定并退出</source>
        <translation type="unfinished">Confirm and Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.ui" line="446"/>
        <source>添加</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="178"/>
        <source>退出</source>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="187"/>
        <source>确认并退出</source>
        <translation type="unfinished">Confirm and Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="335"/>
        <source>请链接数据库</source>
        <translation type="unfinished">Please connect to the db</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="335"/>
        <source>数据库未连接</source>
        <translation type="unfinished">DB is not connected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="590"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="727"/>
        <source>字符串</source>
        <translation type="unfinished">String</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="604"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="741"/>
        <source>电压等级</source>
        <translation type="unfinished">Voltage level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2061"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2232"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2505"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2650"/>
        <source>函数决策：</source>
        <translation type="unfinished">Function decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2066"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2237"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2509"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2655"/>
        <source>颜色决策：</source>
        <translation type="unfinished">Color decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2071"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2242"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2513"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2660"/>
        <source>使能决策：</source>
        <translation type="unfinished">Enable decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2076"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2247"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2517"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2665"/>
        <source>闪烁决策：</source>
        <translation type="unfinished">Flashing decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2081"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2252"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2521"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2670"/>
        <source>符号决策：</source>
        <translation type="unfinished">Symbol decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2086"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2257"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2525"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2675"/>
        <source>字符决策：</source>
        <translation type="unfinished">Character decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2587"/>
        <source>选择图元</source>
        <comment>toolName</comment>
        <translation type="unfinished">Select Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2601"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2606"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2601"/>
        <source>重新选择相同类型的图元</source>
        <translation type="unfinished">Reselect icon with the same type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2606"/>
        <source>重新选择相同区域的图元</source>
        <translation type="unfinished">Reselect icon with the same area</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2617"/>
        <source>属性配置：%1 %2</source>
        <translation type="unfinished">Attr Config: %1 %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_equipment_template_set.cpp" line="2622"/>
        <source>属性配置：%1</source>
        <translation type="unfinished">Attr Config: %1</translation>
    </message>
</context>
<context>
    <name>DlgModifyPicAttr</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="14"/>
        <source>画面属性</source>
        <translation type="unfinished">Graph attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="29"/>
        <source>应用使用扩展属性</source>
        <translation type="unfinished">App uses extended attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="36"/>
        <source>基本属性</source>
        <translation type="unfinished">Basic attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="47"/>
        <source>责任区名：</source>
        <translation type="unfinished">AOR name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="54"/>
        <source>4444</source>
        <translation type="unfinished">4444</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="65"/>
        <source>画面名称：</source>
        <translation type="unfinished">Graph name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="97"/>
        <source>刷新周期:</source>
        <translation type="unfinished">Refresh cycle:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="104"/>
        <source>画面类型</source>
        <translation type="unfinished">Graph type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="138"/>
        <source>其他功能：</source>
        <translation type="unfinished">Other fuction:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="147"/>
        <source>G文件导出</source>
        <translation type="unfinished">G-file export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="157"/>
        <source>隐藏替换失败元素</source>
        <translation type="unfinished">Hide the failed replacement element</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="177"/>
        <source>画面填库</source>
        <translation type="unfinished">Graph fill</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="192"/>
        <source>背景属性</source>
        <translation type="unfinished">Background attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="206"/>
        <source>画面高度:</source>
        <translation type="unfinished">Graph height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="218"/>
        <source>画面宽度：</source>
        <translation type="unfinished">Graph width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="228"/>
        <source>保持比例</source>
        <translation type="unfinished">Keep proportion</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="235"/>
        <source>特殊宽高</source>
        <translation type="unfinished">Special width and height</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="270"/>
        <source>颜色</source>
        <translation type="unfinished">Color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="283"/>
        <source>背景颜色</source>
        <translation type="unfinished">BG color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="290"/>
        <source>背景色是否延展</source>
        <translation type="unfinished">Background color extended</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="83"/>
        <source>厂站名称：</source>
        <translation type="unfinished">Station name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="124"/>
        <source>应用图类型：</source>
        <translation type="unfinished">App diagram type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="167"/>
        <source>画面映射</source>
        <translation type="unfinished">Graph mapping</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="258"/>
        <source>背景设置:</source>
        <translation type="unfinished">Background setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="303"/>
        <source>使用模板</source>
        <translation type="unfinished">Use templates</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="313"/>
        <source>更新模板</source>
        <translation type="unfinished">Update template</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="332"/>
        <source>图片</source>
        <translation type="unfinished">Picture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="349"/>
        <source>选择图片</source>
        <translation type="unfinished">Select picture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="364"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="437"/>
        <source>应用属性</source>
        <translation type="unfinished">App attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="370"/>
        <source>应用属性定义</source>
        <translation type="unfinished">App attrs definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="377"/>
        <source>是否启用</source>
        <translation type="unfinished">Enabled</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="382"/>
        <source>模板应用</source>
        <translation type="unfinished">Template app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="387"/>
        <source>模板库名</source>
        <translation type="unfinished">Template db name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="399"/>
        <source>应用扩展属性</source>
        <translation type="unfinished">App extended attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="420"/>
        <source>增加</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="427"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="442"/>
        <source>属性值</source>
        <translation type="unfinished">Attrs value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="472"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.ui" line="479"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="121"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="939"/>
        <source>静态模板路径选择</source>
        <translation type="unfinished">Static template path selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="577"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="590"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="597"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="612"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="577"/>
        <source>当前应用扩展属性行不匹配</source>
        <translation type="unfinished">This App extended attr row does not match</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="590"/>
        <source>当前应用属性有空值项</source>
        <translation type="unfinished">This App attr has a null value item</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="597"/>
        <source>当前应用属性[%1]重复</source>
        <translation type="unfinished">App attr [%1] is duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="612"/>
        <source>当前属性值有空值项</source>
        <translation type="unfinished">This app value has a null value item</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="626"/>
        <source>异常输入</source>
        <translation type="unfinished">Invalid input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="626"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished">Query data exception; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="636"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="641"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="647"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="662"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="636"/>
        <source>画面名称不可使用内部路径名</source>
        <translation type="unfinished">Graph name cannot use internal path name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="641"/>
        <source>画面名称不可为空</source>
        <translation type="unfinished">Graph name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="647"/>
        <source>层或应用不可为空</source>
        <translation type="unfinished">Layer or application cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="662"/>
        <source>画面名称已存在，请重新输入</source>
        <translation type="unfinished">The graph name already exists, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="925"/>
        <source>选择模板</source>
        <comment>toolName</comment>
        <translation type="unfinished">Select template</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_modify_pic_attr.cpp" line="1036"/>
        <source>打开图片</source>
        <translation type="unfinished">Open picture</translation>
    </message>
</context>
<context>
    <name>DlgPokeSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="14"/>
        <source>光敏点</source>
        <translation type="unfinished">Photosensitive point</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="22"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="29"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="55"/>
        <source>基本选项</source>
        <translation type="unfinished">Basic Options</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="61"/>
        <source>基础设置:</source>
        <translation type="unfinished">Basic setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="81"/>
        <source>边框</source>
        <translation type="unfinished">Border</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="89"/>
        <source>是否凹凸</source>
        <translation type="unfinished">Concave or convex</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="99"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1281"/>
        <source>是否边框</source>
        <translation type="unfinished">Border</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="113"/>
        <source>线型：</source>
        <translation type="unfinished">Line type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="123"/>
        <source>线宽：</source>
        <translation type="unfinished">Line width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="147"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="265"/>
        <source>颜色：</source>
        <translation type="unfinished">Color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="154"/>
        <source>效果：</source>
        <translation type="unfinished">Effect:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="164"/>
        <source>填充</source>
        <translation type="unfinished">Fill In</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="173"/>
        <source>是否填充</source>
        <translation type="unfinished">Fill</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="183"/>
        <source>渐变</source>
        <translation type="unfinished">Gradation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="196"/>
        <source>纯色</source>
        <translation type="unfinished">Solid color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="209"/>
        <source>图片</source>
        <translation type="unfinished">Picture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="237"/>
        <source>透明度：</source>
        <translation type="unfinished">Transparency:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="276"/>
        <source>渐变：</source>
        <translation type="unfinished">Gradient:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="297"/>
        <source>方向：</source>
        <translation type="unfinished">Direction:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="311"/>
        <source>路径：</source>
        <translation type="unfinished">Path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="325"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1389"/>
        <source>选择文件</source>
        <translation type="unfinished">Select file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="332"/>
        <source>保持比例</source>
        <translation type="unfinished">Keep proportion</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="345"/>
        <source>特性</source>
        <translation type="unfinished">Character</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="351"/>
        <source>角型：</source>
        <translation type="unfinished">Angle type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="358"/>
        <source>直角</source>
        <translation type="unfinished">Right angle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="371"/>
        <source>弧角</source>
        <translation type="unfinished">Arc angle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="381"/>
        <source>圆角</source>
        <translation type="unfinished">Rounded corner</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="397"/>
        <source>X坐标：</source>
        <translation type="unfinished">X-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="407"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Y-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="446"/>
        <source>相关状态：</source>
        <translation type="unfinished">Related status:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="474"/>
        <source>状态前景</source>
        <translation type="unfinished">State foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="464"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="484"/>
        <source>配置</source>
        <translation type="unfinished">Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="256"/>
        <source>%</source>
        <translation type="unfinished">％</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="421"/>
        <source>宽度：</source>
        <translation type="unfinished">Width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="431"/>
        <source>高度：</source>
        <translation type="unfinished">Height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="491"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="784"/>
        <source>数据关联</source>
        <translation type="unfinished">Data Link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="503"/>
        <source>显示：</source>
        <translation type="unfinished">Display:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="521"/>
        <source>数据库</source>
        <translation type="unfinished">DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="531"/>
        <source>数据库链接</source>
        <translation type="unfinished">DB link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="545"/>
        <source>按钮文本：</source>
        <translation type="unfinished">Button text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="559"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="742"/>
        <source>文本设置</source>
        <translation type="unfinished">Text settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="566"/>
        <source>文本颜色：</source>
        <translation type="unfinished">Text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="588"/>
        <source>功能：</source>
        <translation type="unfinished">Function:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="607"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1086"/>
        <source>调用命令</source>
        <translation type="unfinished">Call command</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="617"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1167"/>
        <source>发送消息</source>
        <translation type="unfinished">Send Message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="624"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="839"/>
        <source>调用模板</source>
        <translation type="unfinished">Call template</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="634"/>
        <source>高级脚本</source>
        <translation type="unfinished">Advanced script</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="641"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="689"/>
        <source>调用画面</source>
        <translation type="unfinished">Call Graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="654"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1228"/>
        <source>下拉菜单</source>
        <translation type="unfinished">Drop-down menu</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="661"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1052"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1060"/>
        <source>调用功能</source>
        <translation type="unfinished">Call function</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="671"/>
        <source>退出窗口</source>
        <translation type="unfinished">Exit window</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="678"/>
        <source>响应替换</source>
        <translation type="unfinished">Response replace</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="697"/>
        <source>应用名：</source>
        <translation type="unfinished">App name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="709"/>
        <source>应用共享</source>
        <translation type="unfinished">App sharing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="725"/>
        <source>相对路径</source>
        <translation type="unfinished">Relative path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="728"/>
        <source>画面路径：</source>
        <translation type="unfinished">Graph path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="739"/>
        <source>方式选择：</source>
        <translation type="unfinished">Mode Selection:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="748"/>
        <source>替换</source>
        <translation type="unfinished">Replace</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="761"/>
        <source>新窗口</source>
        <translation type="unfinished">New window</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="774"/>
        <source>分图</source>
        <translation type="unfinished">Sub-graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="787"/>
        <source>非模式</source>
        <translation type="unfinished">Non-schema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="800"/>
        <source>浮动窗口</source>
        <translation type="unfinished">Floating window</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="826"/>
        <source>调用方式：</source>
        <translation type="unfinished">Calling method:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="847"/>
        <source>模板路径：</source>
        <translation type="unfinished">Template path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="884"/>
        <source>解析模板替换规则</source>
        <translation type="unfinished">Parsing template replacement rules</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="891"/>
        <source>模板匹配规则：</source>
        <translation type="unfinished">Template matching rules:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="904"/>
        <source>通配符替换配置</source>
        <translation type="unfinished">Wildcard replacement config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="911"/>
        <source>通配符</source>
        <translation type="unfinished">Wildcard</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="916"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1029"/>
        <source>描述</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="921"/>
        <source>替换值</source>
        <translation type="unfinished">Replace value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="926"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1039"/>
        <source>域</source>
        <translation type="unfinished">Area</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="935"/>
        <source>应用库实例替换配置</source>
        <translation type="unfinished">Config App db instance replacement</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="942"/>
        <source>源集合</source>
        <translation type="unfinished">Source set</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="947"/>
        <source>源应用</source>
        <translation type="unfinished">Source app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="952"/>
        <source>源库名</source>
        <translation type="unfinished">Source db name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="957"/>
        <source>源实例</source>
        <translation type="unfinished">Source instance</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="962"/>
        <source>目标应用</source>
        <translation type="unfinished">Dest app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="967"/>
        <source>目标库名</source>
        <translation type="unfinished">Destination DB name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="972"/>
        <source>目标实例</source>
        <translation type="unfinished">Destination instance</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="981"/>
        <source>字符串静态替换</source>
        <translation type="unfinished">Static string replacement</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1002"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1249"/>
        <source>添加</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1009"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1256"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1019"/>
        <source>源字符串值</source>
        <translation type="unfinished">Source string value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1024"/>
        <source>目标字符值</source>
        <translation type="unfinished">Dest character value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1034"/>
        <source>是否替换光敏点</source>
        <translation type="unfinished">Replace the photosensitive point</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1101"/>
        <source>参数：</source>
        <translation type="unfinished">Params:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1112"/>
        <source>名称：</source>
        <translation type="unfinished">Name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1126"/>
        <source>选择程序</source>
        <translation type="unfinished">Select programs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1137"/>
        <source>提示信息</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1175"/>
        <source>消息类型：</source>
        <translation type="unfinished">Message type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1189"/>
        <source>函数名：</source>
        <translation type="unfinished">Function name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1201"/>
        <source>参数定义</source>
        <translation type="unfinished">Params definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1209"/>
        <source>参数名</source>
        <translation type="unfinished">Param name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1214"/>
        <source>参数类型</source>
        <translation type="unfinished">Params type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1219"/>
        <source>参数值</source>
        <translation type="unfinished">Params value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1266"/>
        <source>菜单名称</source>
        <translation type="unfinished">Menu name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1271"/>
        <source>菜单图标</source>
        <translation type="unfinished">Menu icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.ui" line="1276"/>
        <source>跳转画面</source>
        <translation type="unfinished">Jump graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="51"/>
        <source>顺控操作</source>
        <translation type="unfinished">Sequential</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="88"/>
        <source>文件选择</source>
        <translation type="unfinished">File Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="100"/>
        <source>动态模板选择</source>
        <translation type="unfinished">Dynamic template selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="126"/>
        <source>中对齐</source>
        <translation type="unfinished">Center align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="127"/>
        <source>左对齐</source>
        <translation type="unfinished">Left align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="128"/>
        <source>右对齐</source>
        <translation type="unfinished">Right align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="129"/>
        <source>上对齐</source>
        <translation type="unfinished">Top align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="130"/>
        <source>下对齐</source>
        <translation type="unfinished">Bottom align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="233"/>
        <source>水平</source>
        <translation type="unfinished">Horizontal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="237"/>
        <source>垂直</source>
        <translation type="unfinished">Vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="241"/>
        <source>左斜</source>
        <translation type="unfinished">Left Slant</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="245"/>
        <source>右斜</source>
        <translation type="unfinished">Right Slant</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="482"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="484"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="719"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1440"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1573"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1575"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="483"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="484"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1441"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1574"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="791"/>
        <source>字符前景</source>
        <comment>toolName</comment>
        <translation type="unfinished">Character Foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="940"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="940"/>
        <source>模板路径为空</source>
        <translation type="unfinished">Template path is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1221"/>
        <source>调用画面</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Call Graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1243"/>
        <source>调用模板</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Call Template</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1257"/>
        <source>下拉菜单</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Drop-down Menu</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1271"/>
        <source>调用功能</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Call Function</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1304"/>
        <source>调用命令</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Call Command</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1342"/>
        <source>发送消息</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Send Message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1391"/>
        <source>图片文件 %1</source>
        <translation type="unfinished">Picture file %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1413"/>
        <source>选择文件</source>
        <comment>toolName</comment>
        <translation type="unfinished">Select File</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1416"/>
        <source>文件选择</source>
        <comment>subTitle</comment>
        <translation type="unfinished">File Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1601"/>
        <source>打开图片</source>
        <translation type="unfinished">Open picture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1679"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_poke_set.cpp" line="1679"/>
        <source>所选文件没有执行权限!</source>
        <translation type="unfinished">The selected file has no execution permission!</translation>
    </message>
</context>
<context>
    <name>DlgRectTable</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="20"/>
        <source>通用属性</source>
        <translation type="unfinished">Common attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="28"/>
        <source>模式:</source>
        <translation type="unfinished">Mode:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="38"/>
        <source>单页行数:</source>
        <translation type="unfinished">Rows per page:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="58"/>
        <source>分栏:</source>
        <translation type="unfinished">Col-split:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="72"/>
        <source>分栏间隔：</source>
        <translation type="unfinished">Col-split gap:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="92"/>
        <source>分栏行显示</source>
        <translation type="unfinished">Col-split line display</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="106"/>
        <source>列高：</source>
        <translation type="unfinished">Column height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="148"/>
        <source>网格颜色:</source>
        <translation type="unfinished">Grid:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="204"/>
        <source>跳转凹凸</source>
        <translation type="unfinished">Jump bump</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="197"/>
        <source>首/尾页</source>
        <translation type="unfinished">First/last page</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="211"/>
        <source>行显示</source>
        <translation type="unfinished">Line display</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="162"/>
        <source>显示网格线</source>
        <translation type="unfinished">Show Grid Lines</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="183"/>
        <source>显示翻页</source>
        <translation type="unfinished">Display Pagination</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="169"/>
        <source>翻页颜色:</source>
        <translation type="unfinished">Pagination:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="14"/>
        <source>静态表格属性</source>
        <translation type="unfinished">Static table attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="99"/>
        <source>列头属性</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Column header attr</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="120"/>
        <source>列宽：</source>
        <translation type="unfinished">Column width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="134"/>
        <source>宽高自适应：</source>
        <translation type="unfinished">Width and height auto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="190"/>
        <source>支持跳转</source>
        <translation type="unfinished">Support jump</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="218"/>
        <source>显示标题</source>
        <translation type="unfinished">Show title</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="225"/>
        <source>标题属性</source>
        <translation type="unfinished">Title attr</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="232"/>
        <source>标题高度：</source>
        <translation type="unfinished">Title height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="242"/>
        <source>标题间距：</source>
        <translation type="unfinished">Title spacing:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="274"/>
        <source>列属性</source>
        <translation type="unfinished">Column attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="295"/>
        <source>修改</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="302"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="441"/>
        <source>添加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="309"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="455"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="316"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="462"/>
        <source>上移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Move up</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="323"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="469"/>
        <source>下移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Move down</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="330"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="476"/>
        <source>移动至</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Move to</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="375"/>
        <source>清除条件</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Clear conditions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="382"/>
        <source>检索</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Retrieve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="389"/>
        <source>检查条件</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Check conditions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="396"/>
        <source>添加对象</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="420"/>
        <source>清空对象</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Clear obj</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="434"/>
        <source>复制对象</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Copy obj</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="448"/>
        <source>修改</source>
        <translation type="unfinished">Edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="507"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="514"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="343"/>
        <source>行属性</source>
        <translation type="unfinished">Row attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="351"/>
        <source>应用:</source>
        <translation type="unfinished">App:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.ui" line="361"/>
        <source>条件:</source>
        <translation type="unfinished">Condition:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="929"/>
        <source>列名</source>
        <translation type="unfinished">Column name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="929"/>
        <source>前景类型</source>
        <translation type="unfinished">Foreground type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="929"/>
        <source>颜色决策</source>
        <translation type="unfinished">Color decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="929"/>
        <source>符号决策</source>
        <translation type="unfinished">Symbol decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="929"/>
        <source>光敏字符表ID</source>
        <translation type="unfinished">Photosensitive character table ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="929"/>
        <source>光敏字符域ID</source>
        <translation type="unfinished">Photosensitive character field ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="930"/>
        <source>文本决策</source>
        <translation type="unfinished">Text decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="930"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Flashing decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="930"/>
        <source>使能决策</source>
        <translation type="unfinished">Enable decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="930"/>
        <source>元素宽度</source>
        <translation type="unfinished">Element width</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="930"/>
        <source>元素高度</source>
        <translation type="unfinished">Element height</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="930"/>
        <source>行间距</source>
        <translation type="unfinished">Line spacing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="930"/>
        <source>列间距</source>
        <translation type="unfinished">Column spacing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="930"/>
        <source>图元名</source>
        <translation type="unfinished">Icon name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="931"/>
        <source>因子路径</source>
        <translation type="unfinished">Factor path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="931"/>
        <source>属性设置</source>
        <translation type="unfinished">Attrs settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="931"/>
        <source>属性表ID</source>
        <translation type="unfinished">Attr list ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="931"/>
        <source>属性域ID</source>
        <translation type="unfinished">Attr field ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="931"/>
        <source>起始序号</source>
        <translation type="unfinished">Initial No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="931"/>
        <source>序号通配符</source>
        <translation type="unfinished">No. wildcard</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="932"/>
        <source>序号有效位</source>
        <translation type="unfinished">No. valid digit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="932"/>
        <source>应用名</source>
        <translation type="unfinished">App name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="932"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1009"/>
        <source>库名</source>
        <translation type="unfinished">DB name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1003"/>
        <source>清除</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1008"/>
        <source>对象路径</source>
        <translation type="unfinished">Object path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1008"/>
        <source>数据库类型</source>
        <translation type="unfinished">DB type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1008"/>
        <source>全应用名称</source>
        <translation type="unfinished">Full app name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1008"/>
        <source>对象条件</source>
        <translation type="unfinished">Object conditions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1009"/>
        <source>应用名称</source>
        <translation type="unfinished">App name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1009"/>
        <source>实例ID</source>
        <translation type="unfinished">Instance ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1009"/>
        <source>对象OID</source>
        <translation type="unfinished">Object OID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1043"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2369"/>
        <source>对象选择</source>
        <translation type="unfinished">Object Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1047"/>
        <source>不自适应</source>
        <translation type="unfinished">Not auto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1048"/>
        <source>分栏间距</source>
        <translation type="unfinished">Col-split spacing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1049"/>
        <source>行列间距</source>
        <translation type="unfinished">Column and row spacing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1050"/>
        <source>元素宽高</source>
        <translation type="unfinished">Element width and height</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1178"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3968"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3979"/>
        <source>单页行数</source>
        <translation type="unfinished">Rows per page</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1181"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3986"/>
        <source>单行个数</source>
        <translation type="unfinished">Items per line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1307"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2812"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3139"/>
        <source>图元名称：</source>
        <translation type="unfinished">Icon name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1319"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2874"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3185"/>
        <source>颜色决策：</source>
        <translation type="unfinished">Color decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1324"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2879"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3181"/>
        <source>符号决策：</source>
        <translation type="unfinished">Symbol decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1329"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2884"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3189"/>
        <source>闪烁决策：</source>
        <translation type="unfinished">Flashing decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1334"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2889"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3193"/>
        <source>使能决策：</source>
        <translation type="unfinished">Enable decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1503"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1513"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1522"/>
        <source>表格宽度小于上下页按钮预留宽度</source>
        <translation type="unfinished">Table width is less than the reserved width for Previous/Next page buttons.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1503"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1513"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1522"/>
        <source>是否继续</source>
        <translation type="unfinished">Continued</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1771"/>
        <source>是否创建当前元素</source>
        <translation type="unfinished">Whether to create the current element</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1897"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2290"/>
        <source>是否删除当前选中行</source>
        <translation type="unfinished">Whether to delete the selected row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1966"/>
        <source>重复对象提示</source>
        <translation type="unfinished">Duplicate object tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1968"/>
        <source>发现 %1 个重复的测点对象：</source>
        <translation type="unfinished">Found %1 duplicate measuring point objects:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1973"/>
        <source>路径: %1</source>
        <translation type="unfinished">Path: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1977"/>
        <source>... 还有 %1 个重复对象</source>
        <translation type="unfinished">... %1 duplicate objects left</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1980"/>
        <source>请选择处理方式：</source>
        <translation type="unfinished">Please choose a processing method:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1984"/>
        <source>合并(跳过重复)</source>
        <translation type="unfinished">Merge (skip duplicates)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1985"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1986"/>
        <source>重新选择</source>
        <translation type="unfinished">Re-select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2468"/>
        <source>请仅选择一行进行修改</source>
        <translation type="unfinished">Please select only one line for modification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2528"/>
        <source>数据库连接失败</source>
        <translation type="unfinished">DB connection failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2550"/>
        <source>选择的对象与现有对象重复，不允许修改</source>
        <translation type="unfinished">The selected object is a duplicate of an existing object, and modification is not allowed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2750"/>
        <source>字符前景</source>
        <translation type="unfinished">Character foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3271"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Please select the data to be operated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3366"/>
        <source>检索结果%1条</source>
        <translation type="unfinished">Search result items: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3572"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3793"/>
        <source>移动至</source>
        <comment>toolName</comment>
        <translation type="unfinished">Move To</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3572"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3793"/>
        <source>目标行:</source>
        <translation type="unfinished">Target line:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="4000"/>
        <source>双击单元格进行属性设置编辑</source>
        <translation type="unfinished">Double-click the cell to edit attr settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="4016"/>
        <source>双击此处编辑属性设置</source>
        <translation type="unfinished">Double-click here to edit attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="4017"/>
        <source>&lt;双击编辑&gt;</source>
        <translation type="unfinished">&lt;Double-click editing&gt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="4029"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="4029"/>
        <source>表格对象或标题属性为空</source>
        <translation type="unfinished">The table object or title attr is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="4037"/>
        <source>标题设置</source>
        <translation type="unfinished">Title setting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2374"/>
        <source>条件检索</source>
        <translation type="unfinished">Search Conditions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="854"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="860"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="868"/>
        <source>普通字符</source>
        <translation type="unfinished">General characters</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="913"/>
        <source>光字牌配置</source>
        <translation type="unfinished">Annunciator Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2587"/>
        <source>是否清空所有对象</source>
        <translation type="unfinished">Whether to clear all objects</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1496"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1770"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="1896"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2289"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2468"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2528"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2550"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="2586"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3271"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3354"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3361"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3366"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="812"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="818"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="826"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="910"/>
        <source>静态表格配置</source>
        <translation type="unfinished">Static table config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3354"/>
        <source>检索失败</source>
        <translation type="unfinished">Retrieval failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_rect_table.cpp" line="3361"/>
        <source>检索结果大于10000条,请检查条件</source>
        <translation type="unfinished">The search results are greater than 10,000, please check the conditions</translation>
    </message>
</context>
<context>
    <name>DlgSignalSlotConfig</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="26"/>
        <source>发送方对象：</source>
        <translation type="unfinished">Sender object:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="40"/>
        <source>发送方信号列表：</source>
        <translation type="unfinished">Sender signal list:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="54"/>
        <source>信号签名：</source>
        <translation type="unfinished">Signal signature:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="76"/>
        <source>接收方对象：</source>
        <translation type="unfinished">Receiver object:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="90"/>
        <source>接收方响应列表：</source>
        <translation type="unfinished">Receiver response list:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="104"/>
        <source>响应函数签名：</source>
        <translation type="unfinished">Response function signature:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="139"/>
        <source>添加</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="146"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="186"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.ui" line="193"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="69"/>
        <source>信号配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Signal Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="123"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="129"/>
        <source>发送方名称</source>
        <translation type="unfinished">Sender name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="135"/>
        <source>发送方信号描述</source>
        <translation type="unfinished">Sender signal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="141"/>
        <source>接收方名称</source>
        <translation type="unfinished">Recipient name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="147"/>
        <source>接收方信号描述</source>
        <translation type="unfinished">Receiver signal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="339"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="344"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="349"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="354"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="366"/>
        <source>添加失败</source>
        <translation type="unfinished">Add failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="339"/>
        <source>无可用的发送方对象</source>
        <translation type="unfinished">No sender objects are available</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="344"/>
        <source>无可用的接收方对象</source>
        <translation type="unfinished">No recipient objects are available</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="349"/>
        <source>无可用的发送方信号</source>
        <translation type="unfinished">No sender signal available</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="354"/>
        <source>无可用的接收方响应</source>
        <translation type="unfinished">No receiver response available</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_signal_slot_config.cpp" line="366"/>
        <source>链接已存在</source>
        <translation type="unfinished">Link already exists</translation>
    </message>
</context>
<context>
    <name>DlgStateSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="20"/>
        <source>状态前景</source>
        <translation type="unfinished">State foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="32"/>
        <source>基本设置：</source>
        <translation type="unfinished">Basic setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="62"/>
        <source>文本：</source>
        <translation type="unfinished">Text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="69"/>
        <source>显示文本</source>
        <translation type="unfinished">Display Text</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="80"/>
        <source>文字颜色：</source>
        <translation type="unfinished">Text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="87"/>
        <source>文字颜色</source>
        <translation type="unfinished">Text color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="98"/>
        <source>前景颜色：</source>
        <translation type="unfinished">Foreground:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="105"/>
        <source>填充色</source>
        <translation type="unfinished">Fill color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="112"/>
        <source>填充颜色</source>
        <translation type="unfinished">Fill color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="128"/>
        <source>对齐：</source>
        <translation type="unfinished">Align:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="138"/>
        <source>竖排</source>
        <translation type="unfinished">Vertical row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="146"/>
        <source>枚举</source>
        <translation type="unfinished">Enum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="154"/>
        <source>边框色</source>
        <translation type="unfinished">Border color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="161"/>
        <source>边框颜色</source>
        <translation type="unfinished">Border color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="177"/>
        <source>函数取值</source>
        <translation type="unfinished">Function value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="188"/>
        <source>X坐标：</source>
        <translation type="unfinished">X-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="198"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Y-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="212"/>
        <source>宽度：</source>
        <translation type="unfinished">Width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="222"/>
        <source>高度：</source>
        <translation type="unfinished">Height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="581"/>
        <source>条件：</source>
        <translation type="unfinished">Condition:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="595"/>
        <source>对象ID：</source>
        <translation type="unfinished">Object ID:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="243"/>
        <source>符号图元选择：</source>
        <translation type="unfinished">Symbol Icon Selection:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="252"/>
        <source>图元名称：</source>
        <translation type="unfinished">Icon name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="287"/>
        <source>字体设置：</source>
        <translation type="unfinished">Font setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="310"/>
        <source>字体：</source>
        <translation type="unfinished">Font:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="324"/>
        <source>字体大小：</source>
        <translation type="unfinished">Font size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="340"/>
        <source>效果：</source>
        <translation type="unfinished">Effect:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="347"/>
        <source>粗体</source>
        <translation type="unfinished">Bold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="354"/>
        <source>斜体</source>
        <translation type="unfinished">Italic</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="361"/>
        <source>删除线</source>
        <translation type="unfinished">Strikeout Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="368"/>
        <source>下划线</source>
        <translation type="unfinished">Base Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="386"/>
        <source>决策：</source>
        <translation type="unfinished">Decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="404"/>
        <source>颜色决策</source>
        <translation type="unfinished">Color decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="414"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="435"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="456"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="477"/>
        <source>更多</source>
        <translation type="unfinished">More</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="425"/>
        <source>符号决策</source>
        <translation type="unfinished">Symbol decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="446"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Flashing decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="467"/>
        <source>使能决策</source>
        <translation type="unfinished">Enable decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="495"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="526"/>
        <source>数据库：</source>
        <translation type="unfinished">DB:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="262"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="549"/>
        <source>清除</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="513"/>
        <source>应用：</source>
        <translation type="unfinished">App:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="556"/>
        <source>检索</source>
        <translation type="unfinished">Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="567"/>
        <source>链接路径：</source>
        <translation type="unfinished">Link path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="605"/>
        <source>对象域：</source>
        <translation type="unfinished">Object field:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="635"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.ui" line="642"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.cpp" line="54"/>
        <source>图元选择</source>
        <translation type="unfinished">Icon Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.cpp" line="66"/>
        <source>中对齐</source>
        <translation type="unfinished">Center align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.cpp" line="67"/>
        <source>左对齐</source>
        <translation type="unfinished">Left align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.cpp" line="68"/>
        <source>右对齐</source>
        <translation type="unfinished">Right align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.cpp" line="69"/>
        <source>上对齐</source>
        <translation type="unfinished">Top align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_set.cpp" line="70"/>
        <source>下对齐</source>
        <translation type="unfinished">Bottom align</translation>
    </message>
</context>
<context>
    <name>DlgStateTemplateSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="20"/>
        <source>状态前景</source>
        <translation type="unfinished">State foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="30"/>
        <source>数据配置</source>
        <translation type="unfinished">Data Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="41"/>
        <source>数据路径：</source>
        <translation type="unfinished">Data path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="51"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="386"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="683"/>
        <source>清除</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="61"/>
        <source>条件配置</source>
        <translation type="unfinished">Config Conditions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="84"/>
        <source>应用：</source>
        <translation type="unfinished">App:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="94"/>
        <source>库名：</source>
        <translation type="unfinished">DB name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="104"/>
        <source>实例号：</source>
        <translation type="unfinished">Instance No.:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="114"/>
        <source>条件：</source>
        <translation type="unfinished">Condition:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="127"/>
        <source>属性定义</source>
        <translation type="unfinished">Define Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="139"/>
        <source>基本设置：</source>
        <translation type="unfinished">Basic setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="159"/>
        <source>文本：</source>
        <translation type="unfinished">Text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="179"/>
        <source>高级配置</source>
        <translation type="unfinished">Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="218"/>
        <source>文字颜色：</source>
        <translation type="unfinished">Text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="225"/>
        <source>文字颜色</source>
        <translation type="unfinished">Text color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="245"/>
        <source>前景颜色：</source>
        <translation type="unfinished">Foreground:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="252"/>
        <source>填充色</source>
        <translation type="unfinished">Fill color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="261"/>
        <source>填充颜色</source>
        <translation type="unfinished">Fill color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="329"/>
        <source>宽度： </source>
        <translation type="unfinished">Width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="339"/>
        <source>高度： </source>
        <translation type="unfinished">Height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="644"/>
        <source>应用：    </source>
        <translation type="unfinished">App:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="715"/>
        <source>条件：    </source>
        <translation type="unfinished">Condition:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="729"/>
        <source>对象ID：  </source>
        <translation type="unfinished">Object ID:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="197"/>
        <source>对齐：</source>
        <translation type="unfinished">Align:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="207"/>
        <source>竖排</source>
        <translation type="unfinished">Vertical row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="234"/>
        <source>枚举</source>
        <translation type="unfinished">Enum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="279"/>
        <source>边框色</source>
        <translation type="unfinished">Border color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="272"/>
        <source>边框颜色</source>
        <translation type="unfinished">Border color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="186"/>
        <source>显示文本</source>
        <translation type="unfinished">Display Text</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="294"/>
        <source>函数取值</source>
        <translation type="unfinished">Function value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="305"/>
        <source>X坐标：</source>
        <translation type="unfinished">X-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="315"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Y-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="360"/>
        <source>符号图元选择：</source>
        <translation type="unfinished">Symbol Icon Selection:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="372"/>
        <source>延展</source>
        <translation type="unfinished">extension</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="379"/>
        <source>图元名称：</source>
        <translation type="unfinished">Icon name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="393"/>
        <source>等比缩放</source>
        <translation type="unfinished">scale proportionally</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="418"/>
        <source>字体设置：</source>
        <translation type="unfinished">Font setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="441"/>
        <source>字体：</source>
        <translation type="unfinished">Font:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="455"/>
        <source>字体大小：</source>
        <translation type="unfinished">Font size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="471"/>
        <source>效果：</source>
        <translation type="unfinished">Effect:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="478"/>
        <source>粗体</source>
        <translation type="unfinished">Bold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="485"/>
        <source>斜体</source>
        <translation type="unfinished">Italic</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="492"/>
        <source>删除线</source>
        <translation type="unfinished">Strikeout Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="499"/>
        <source>下划线</source>
        <translation type="unfinished">Base Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="517"/>
        <source>决策：</source>
        <translation type="unfinished">Decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="535"/>
        <source>颜色决策</source>
        <translation type="unfinished">Color decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="545"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="566"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="587"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="608"/>
        <source>更多</source>
        <translation type="unfinished">More</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="556"/>
        <source>符号决策</source>
        <translation type="unfinished">Symbol decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="577"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Flashing decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="598"/>
        <source>使能决策</source>
        <translation type="unfinished">Enable decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="626"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="657"/>
        <source>数据库：</source>
        <translation type="unfinished">DB:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="690"/>
        <source>检索</source>
        <translation type="unfinished">Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="701"/>
        <source>链接路径：</source>
        <translation type="unfinished">Link path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="739"/>
        <source>对象域：</source>
        <translation type="unfinished">Object field:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="780"/>
        <source>确定并退出</source>
        <translation type="unfinished">Confirm and Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="787"/>
        <source>添加</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.ui" line="760"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="137"/>
        <source>图元选择</source>
        <translation type="unfinished">Icon Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="149"/>
        <source>中对齐</source>
        <translation type="unfinished">Center align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="150"/>
        <source>左对齐</source>
        <translation type="unfinished">Left align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="151"/>
        <source>右对齐</source>
        <translation type="unfinished">Right align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="152"/>
        <source>上对齐</source>
        <translation type="unfinished">Top align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="153"/>
        <source>下对齐</source>
        <translation type="unfinished">Bottom align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="223"/>
        <source>退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="235"/>
        <source>确认并退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm and exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="289"/>
        <source>应用全名:</source>
        <translation type="unfinished">App full name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="315"/>
        <source>搜索画面...</source>
        <translation type="unfinished">Search graph...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="317"/>
        <source>全选</source>
        <translation type="unfinished">Select all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="318"/>
        <source>清空</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="320"/>
        <source>画面选择:</source>
        <translation type="unfinished">Graph Selection:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="338"/>
        <source>已选画面:</source>
        <translation type="unfinished">Selected graph:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="339"/>
        <source>(0个)</source>
        <translation type="unfinished">(0 items)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="347"/>
        <source>双击可移除选中的画面</source>
        <translation type="unfinished">Double-click to remove the selected graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="362"/>
        <source>画面配置</source>
        <translation type="unfinished">Graph config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="463"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="491"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="706"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="734"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1105"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1133"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1941"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="464"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="707"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1106"/>
        <source>勾选填充色则符号图元不生效，是否清除符号图元</source>
        <translation type="unfinished">If the fill color is checked, the symbol icon will not take effect. Whether to clear the symbol icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="492"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="735"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1134"/>
        <source>勾选边框色则符号图元不生效，是否清除符号图元</source>
        <translation type="unfinished">If the border color is checked, the symbol icon will not take effect. Whether to clear the symbol icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="677"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="3607"/>
        <source>双击移除</source>
        <translation type="unfinished">Double-click to remove</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="685"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="3615"/>
        <source>(%1个)</source>
        <translation type="unfinished">(%1 items)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1188"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1395"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1188"/>
        <source>请选择至少一个画面</source>
        <translation type="unfinished">Please select at least one graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1395"/>
        <source>修改后的前景配置在二维表中已存在，请修改为不同的配置。</source>
        <translation type="unfinished">The modified foreground config already exists in the 2D table, please modify it to a different config.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="1942"/>
        <source>选择符号图元则填充色和边框色不生效，是否清除填充色和边框色勾选</source>
        <translation type="unfinished">If the symbol icon is checked, the fill color and border color will not take effect. Whether to clear the check boxes for fill color and border color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="2295"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="2295"/>
        <source>条件配置为空是否保存?</source>
        <translation type="unfinished">If the condition is empty, whether to save?</translation>
    </message>
</context>
<context>
    <name>DlgStateTextTemplateSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="14"/>
        <source>字符前景</source>
        <translation type="unfinished">Character foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="24"/>
        <source>数据配置</source>
        <translation type="unfinished">Data Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="42"/>
        <source>数据路径：</source>
        <translation type="unfinished">Data path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="52"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="561"/>
        <source>清除</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="62"/>
        <source>属性定义</source>
        <translation type="unfinished">Define Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="74"/>
        <source>基本设置：</source>
        <translation type="unfinished">Basic setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="94"/>
        <source>文本：</source>
        <translation type="unfinished">Text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="108"/>
        <source>显示文本</source>
        <translation type="unfinished">Display Text</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="119"/>
        <source>对齐：</source>
        <translation type="unfinished">Align:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="129"/>
        <source>竖排</source>
        <translation type="unfinished">Vertical row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="136"/>
        <source>启用延展</source>
        <translation type="unfinished">Enable extension</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="150"/>
        <source>文字颜色：</source>
        <translation type="unfinished">Text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="157"/>
        <source>文字颜色</source>
        <translation type="unfinished">Text color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="166"/>
        <source>枚举</source>
        <translation type="unfinished">Enum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="177"/>
        <source>前景颜色：</source>
        <translation type="unfinished">Foreground:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="184"/>
        <source>填充色</source>
        <translation type="unfinished">Fill color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="193"/>
        <source>填充颜色</source>
        <translation type="unfinished">Fill color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="204"/>
        <source>边框色</source>
        <translation type="unfinished">Border color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="211"/>
        <source>边框颜色</source>
        <translation type="unfinished">Border color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="226"/>
        <source>函数取值</source>
        <translation type="unfinished">Function value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="237"/>
        <source>X坐标：</source>
        <translation type="unfinished">X-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="247"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Y-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="261"/>
        <source>宽度：</source>
        <translation type="unfinished">Width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="271"/>
        <source>高度：</source>
        <translation type="unfinished">Height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="579"/>
        <source>链接路径：</source>
        <translation type="unfinished">Link path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="292"/>
        <source>字体设置：</source>
        <translation type="unfinished">Font setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="315"/>
        <source>字体：</source>
        <translation type="unfinished">Font:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="329"/>
        <source>字体大小：</source>
        <translation type="unfinished">Font size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="345"/>
        <source>效果：</source>
        <translation type="unfinished">Effect:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="352"/>
        <source>粗体</source>
        <translation type="unfinished">Bold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="359"/>
        <source>斜体</source>
        <translation type="unfinished">Italic</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="366"/>
        <source>删除线</source>
        <translation type="unfinished">Strikeout Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="373"/>
        <source>下划线</source>
        <translation type="unfinished">Base Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="391"/>
        <source>决策：</source>
        <translation type="unfinished">Decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="409"/>
        <source>颜色决策</source>
        <translation type="unfinished">Color decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="419"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="440"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="461"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="482"/>
        <source>更多</source>
        <translation type="unfinished">More</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="430"/>
        <source>字符决策</source>
        <translation type="unfinished">Character decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="451"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Flashing decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="472"/>
        <source>使能决策</source>
        <translation type="unfinished">Enable decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="500"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="535"/>
        <source>数据库：</source>
        <translation type="unfinished">DB:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="518"/>
        <source>应用：    </source>
        <translation type="unfinished">App:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="568"/>
        <source>检索</source>
        <translation type="unfinished">Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="593"/>
        <source>条件：    </source>
        <translation type="unfinished">Condition:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="607"/>
        <source>对象ID：  </source>
        <translation type="unfinished">Object ID:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="617"/>
        <source>对象域：</source>
        <translation type="unfinished">Object field:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="638"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="658"/>
        <source>确定并退出</source>
        <translation type="unfinished">Confirm and Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.ui" line="665"/>
        <source>添加</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.cpp" line="121"/>
        <source>中对齐</source>
        <translation type="unfinished">Center align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.cpp" line="122"/>
        <source>左对齐</source>
        <translation type="unfinished">Left align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.cpp" line="123"/>
        <source>右对齐</source>
        <translation type="unfinished">Right align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.cpp" line="124"/>
        <source>上对齐</source>
        <translation type="unfinished">Top align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.cpp" line="125"/>
        <source>下对齐</source>
        <translation type="unfinished">Bottom align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.cpp" line="129"/>
        <source>向右延展</source>
        <translation type="unfinished">Extend to the right</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.cpp" line="181"/>
        <source>退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_statetext_template_set.cpp" line="193"/>
        <source>确认并退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm and exit</translation>
    </message>
</context>
<context>
    <name>DlgTextAdvancedConfig</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="39"/>
        <source>文本高级配置</source>
        <translation type="unfinished">Text Advanced Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="57"/>
        <source>前缀文本：</source>
        <translation type="unfinished">Prefix Text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="60"/>
        <source>在主文本前显示的内容</source>
        <translation type="unfinished">Content displayed before the main text</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="66"/>
        <source>后缀文本：</source>
        <translation type="unfinished">Suffix Text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="69"/>
        <source>在主文本后显示的内容</source>
        <translation type="unfinished">Content displayed after the main text</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="75"/>
        <source>过滤文本：</source>
        <translation type="unfinished">Filter text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="78"/>
        <source>用于过滤的文本条件</source>
        <translation type="unfinished">Text conditions used for filtering</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="84"/>
        <source>自动刷新文本：</source>
        <translation type="unfinished">Auto-refresh text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="89"/>
        <source>启用</source>
        <translation type="unfinished">Enable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="92"/>
        <source>点击按钮选择刷新字段</source>
        <translation type="unfinished">Click button to select refresh fields</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="93"/>
        <source>选择字段</source>
        <translation type="unfinished">Select fields</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="108"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_text_advanced_config.cpp" line="110"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>DlgValueTemplateSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="14"/>
        <source>数值前景</source>
        <translation type="unfinished">Value foreground</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="24"/>
        <source>数据配置</source>
        <translation type="unfinished">Data Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="42"/>
        <source>数据路径：</source>
        <translation type="unfinished">Data path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="52"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="679"/>
        <source>清除</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="62"/>
        <source>属性定义</source>
        <translation type="unfinished">Define Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="74"/>
        <source>基本设置：</source>
        <translation type="unfinished">Basic setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="94"/>
        <source>文本：</source>
        <translation type="unfinished">Text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="108"/>
        <source>显示文本</source>
        <translation type="unfinished">Display Text</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="119"/>
        <source>对齐：</source>
        <translation type="unfinished">Align:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="129"/>
        <source>竖排</source>
        <translation type="unfinished">Vertical row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="140"/>
        <source>文字颜色：</source>
        <translation type="unfinished">Text:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="147"/>
        <source>文字颜色</source>
        <translation type="unfinished">Text color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="156"/>
        <source>枚举</source>
        <translation type="unfinished">Enum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="167"/>
        <source>前景颜色：</source>
        <translation type="unfinished">Foreground:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="174"/>
        <source>填充色</source>
        <translation type="unfinished">Fill color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="183"/>
        <source>填充颜色</source>
        <translation type="unfinished">Fill color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="194"/>
        <source>边框色</source>
        <translation type="unfinished">Border color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="201"/>
        <source>边框颜色</source>
        <translation type="unfinished">Border color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="216"/>
        <source>函数取值</source>
        <translation type="unfinished">Function value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="227"/>
        <source>X坐标：</source>
        <translation type="unfinished">X-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="237"/>
        <source>Y坐标：</source>
        <translation type="unfinished">Y-coordinate:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="251"/>
        <source>宽度：</source>
        <translation type="unfinished">Width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="261"/>
        <source>高度：</source>
        <translation type="unfinished">Height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="282"/>
        <source>字体设置：</source>
        <translation type="unfinished">Font setting:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="305"/>
        <source>字体：</source>
        <translation type="unfinished">Font:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="319"/>
        <source>字体大小：</source>
        <translation type="unfinished">Font size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="335"/>
        <source>效果：</source>
        <translation type="unfinished">Effect:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="342"/>
        <source>粗体</source>
        <translation type="unfinished">Bold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="349"/>
        <source>斜体</source>
        <translation type="unfinished">Italic</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="356"/>
        <source>删除线</source>
        <translation type="unfinished">Strikeout Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="363"/>
        <source>下划线</source>
        <translation type="unfinished">Base Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="381"/>
        <source>显示：</source>
        <translation type="unfinished">Display:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="402"/>
        <source>显示格式：</source>
        <translation type="unfinished">Display format:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="459"/>
        <source>显示前缀：</source>
        <translation type="unfinished">Display prefix:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="441"/>
        <source>显示后缀：</source>
        <translation type="unfinished">Display suffix:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="420"/>
        <source>小数点位数：</source>
        <translation type="unfinished">Decimal places:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="432"/>
        <source>LCD显示</source>
        <translation type="unfinished">LCD display</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="477"/>
        <source>是否延展</source>
        <translation type="unfinished">Extended</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="489"/>
        <source>允许修改</source>
        <translation type="unfinished">Allow modification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="505"/>
        <source>决策：</source>
        <translation type="unfinished">Decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="523"/>
        <source>颜色决策</source>
        <translation type="unfinished">Color decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="533"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="554"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="575"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="596"/>
        <source>更多</source>
        <translation type="unfinished">More</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="544"/>
        <source>字符决策</source>
        <translation type="unfinished">Character decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="565"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Flashing decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="586"/>
        <source>使能决策</source>
        <translation type="unfinished">Enable decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="614"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="649"/>
        <source>数据库：</source>
        <translation type="unfinished">DB:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="697"/>
        <source>链接路径：</source>
        <translation type="unfinished">Link path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="686"/>
        <source>检索</source>
        <translation type="unfinished">Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="632"/>
        <source>应用：    </source>
        <translation type="unfinished">App:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="711"/>
        <source>条件：    </source>
        <translation type="unfinished">Condition:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="725"/>
        <source>对象ID：  </source>
        <translation type="unfinished">Object ID:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="735"/>
        <source>对象域：</source>
        <translation type="unfinished">Object field:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="756"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="776"/>
        <source>确定并退出</source>
        <translation type="unfinished">Confirm and Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.ui" line="783"/>
        <source>添加</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.cpp" line="119"/>
        <source>中对齐</source>
        <translation type="unfinished">Center align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.cpp" line="120"/>
        <source>左对齐</source>
        <translation type="unfinished">Left align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.cpp" line="121"/>
        <source>右对齐</source>
        <translation type="unfinished">Right align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.cpp" line="122"/>
        <source>上对齐</source>
        <translation type="unfinished">Top align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.cpp" line="123"/>
        <source>下对齐</source>
        <translation type="unfinished">Bottom align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.cpp" line="127"/>
        <source>向右延展</source>
        <translation type="unfinished">Extend to the right</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.cpp" line="195"/>
        <source>退出</source>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_value_template_set.cpp" line="204"/>
        <source>确认并退出</source>
        <translation type="unfinished">Confirm and Exit</translation>
    </message>
</context>
<context>
    <name>DrawView</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="1189"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="4292"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="4656"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="4761"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7584"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="10183"/>
        <source>场景指针为空,无法进行刷新操作</source>
        <translation type="unfinished">The scene pointer is empty and cannot be refreshed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="2313"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="2800"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="3257"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="19171"/>
        <source>场景指针为空,无法进行获取操作</source>
        <translation type="unfinished">The scenario pointer is empty and cannot be retrieved</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="2972"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="3062"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="3192"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="19327"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="19423"/>
        <source>跳转</source>
        <translation type="unfinished">Jump</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5173"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5253"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5384"/>
        <source>颜色决策[%1]未找到</source>
        <translation type="unfinished">Color decision [%1] not found</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5184"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5273"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5395"/>
        <source>使能决策[%1]未找到</source>
        <translation type="unfinished">Enable decision [%1] was not found</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5195"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5293"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5406"/>
        <source>字符决策[%1]未找到</source>
        <translation type="unfinished">Character decision [%1] was not found</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5206"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5313"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5417"/>
        <source>符号决策[%1]未找到</source>
        <translation type="unfinished">Symbol decision [%1] not found</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5217"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5333"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5428"/>
        <source>闪烁决策[%1]未找到</source>
        <translation type="unfinished">Flashing decision [%1] was not found</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5228"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5353"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5439"/>
        <source>函数决策[%1]未找到</source>
        <translation type="unfinished">Function decision [%1] was not found</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5261"/>
        <source>颜色决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished">Color decision [%1] application [%2] is inconsistent with the graph application</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5281"/>
        <source>使能决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished">Enable decision [%1] application [%2] inconsistent with graph application</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5301"/>
        <source>字符决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished">Character decision [%1] application [%2] is inconsistent with graph application</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5321"/>
        <source>符号决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished">Symbol decision [%1] application [%2] inconsistent with graph application</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5341"/>
        <source>闪烁决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished">Flashing decision [%1] Application [%2] inconsistent with graph application</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5361"/>
        <source>函数决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished">Function decision [%1] application [%2] is inconsistent with graph application</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5467"/>
        <source>当前画面背景资源文件[%1]无效</source>
        <translation type="unfinished">The current background resource file [%1] is invalid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5500"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5507"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5539"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5546"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5619"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5626"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5658"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5665"/>
        <source>%1资源文件[%2]不在iasp目录下</source>
        <translation type="unfinished">The resource file of %1, [%2] is not located in the iasp dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5516"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5555"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5635"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5674"/>
        <source>%1资源文件[%2]不存在</source>
        <translation type="unfinished"> The resource file of %1, [%2] does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5837"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5858"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5879"/>
        <source>当前场景中的元素[%1]所处位置已经完全超出画布范围</source>
        <translation type="unfinished">The position of element [%1] in the current scene is completely beyond the canvas range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="5987"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6016"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6084"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6102"/>
        <source>当前场景中的元素[%1]所处位置部分超出画布范围</source>
        <translation type="unfinished">The position of element [%1] in the current scene is partially beyond the canvas range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6443"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6448"/>
        <source>%1数据未关联</source>
        <translation type="unfinished">%1 data not linked</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6472"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6477"/>
        <source>%1数据未生效:获取目标对象oid失败</source>
        <translation type="unfinished">%1 data not in effect: Failed to retrieve destination object OID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6494"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6499"/>
        <source>%1数据未生效:目标对象oid[%2]与当前保存oid[%3]不一致</source>
        <translation type="unfinished">%1 data not in effect: The destination object oid [%2] is inconsistent with the currently saved oid [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6585"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6603"/>
        <source>%1不存在</source>
        <translation type="unfinished">%1 does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6610"/>
        <source>%1存在空挂</source>
        <translation type="unfinished">%1 dangling</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7103"/>
        <source>当前前景图元超过了一个元素</source>
        <translation type="unfinished">Current foreground Icon contains multiple elements.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7136"/>
        <source>当前前景图元没有元素</source>
        <translation type="unfinished">Current foreground Icon has no elements</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7594"/>
        <source>文件[%1]已存在，是否覆盖并将词条重新写入该文件</source>
        <translation type="unfinished">The file [%1] already exists. Whether to overwrite it and rewrite the entry into the file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7599"/>
        <source>文件[%1]已存在，词条导出失败</source>
        <translation type="unfinished">File [%1] already exists, entry export failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7651"/>
        <source>文件[%1]打开失败，词条导出失败</source>
        <translation type="unfinished">File [%1] failed to open, entry export failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7764"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8217"/>
        <source>默认值</source>
        <translation type="unfinished">Default value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8826"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8898"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9224"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9281"/>
        <source>打开文件</source>
        <translation type="unfinished">Open file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8889"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8911"/>
        <source>填库失败</source>
        <translation type="unfinished">Failed to fill DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8890"/>
        <source>当前画面属性未勾选填库，无法进行填库操作！</source>
        <translation type="unfinished">The current graph attr is not checked for DB filling, so the DB filling operation cannot be performed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8912"/>
        <source>当前应用程序接口插件不可用，无法进行填库操作！</source>
        <translation type="unfinished">The current application programming interface plugin is unavailable, unable to perform DB filling operations!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8914"/>
        <source>填库结束</source>
        <translation type="unfinished">Filling DB completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8964"/>
        <source>映射设备信息</source>
        <comment>toolName</comment>
        <translation type="unfinished">Map Device Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9297"/>
        <source>映射结束</source>
        <translation type="unfinished">Mapping completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9301"/>
        <source>映射失败</source>
        <translation type="unfinished">Mapping failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9302"/>
        <source>当前应用程序接口插件不可用，无法进行映射操作！</source>
        <translation type="unfinished">App programming interface plugin is unavailable, unable to perform mapping operations!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9388"/>
        <source>已经缩放最大到最小比例32倍</source>
        <translation type="unfinished">Has been scaled up to 32 times the maximum to minimum scale</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9430"/>
        <source>已经缩放到最小比例0.05倍</source>
        <translation type="unfinished">Has been scaled to 0.05 times the smallest scale</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9457"/>
        <source>drawing%1.icoxml</source>
        <translation type="unfinished">drawing%1.icoxml</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9461"/>
        <source>drawing%1.xml</source>
        <translation type="unfinished">drawing%1.xml</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9706"/>
        <source>下载文件{}失败，返回值为{}</source>
        <translation type="unfinished">Failed to download file {}; return value: {}</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9735"/>
        <source>G文件错误,请修改</source>
        <translation type="unfinished">G-file error, please modify it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="10057"/>
        <source>删除图元提示</source>
        <translation type="unfinished">Delete icon prompt</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11663"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11982"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13920"/>
        <source>警告</source>
        <comment>toolName</comment>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11664"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11983"/>
        <source>图元态存在异常项，是否自动处理并保存?</source>
        <translation type="unfinished">Abnormal items found in icon state. Auto-process and save?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11667"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11986"/>
        <source>处理并保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11668"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11987"/>
        <source>终止操作</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Stop operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13921"/>
        <source>&apos;%1&apos; 已经被修改,是否保存</source>
        <translation type="unfinished">‘%1&apos; has been modified, whether to save it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13924"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13925"/>
        <source>放弃</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Abort</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13926"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13977"/>
        <source>(草稿)</source>
        <translation type="unfinished">(Draft)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="19618"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="19618"/>
        <source>自动刷新连接数据库失败</source>
        <translation type="unfinished">Auto-refresh: DB connection failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11545"/>
        <source>Save As</source>
        <translation type="unfinished">Save as</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11591"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11907"/>
        <source>%1至少有一个%2元素</source>
        <translation type="unfinished">%1 has at least one %2 element</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11604"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11625"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11920"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11941"/>
        <source>%1只能有一个%2元素</source>
        <translation type="unfinished">%1 can only have one %2 element</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15210"/>
        <source>%1不在清除范围内</source>
        <translation type="unfinished">%1 is not within the clear range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15218"/>
        <source>%1不在清除范围内，其余项清除完成</source>
        <translation type="unfinished">%1 is not within the clear range; other items have been cleared</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7593"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11590"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11603"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11624"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11820"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11824"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11906"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11919"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11940"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12139"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12143"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12193"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12491"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13885"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15243"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="17086"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="18837"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="19000"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8826"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9224"/>
        <source>无法写入文件 %1</source>
        <translation type="unfinished">Unable to write to file %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="8898"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="9281"/>
        <source>无法打开文件 %1:%2.</source>
        <translation type="unfinished">Unable to open file %1: %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="10058"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="10063"/>
        <source>以下图元已被删除：</source>
        <translation type="unfinished">The following icons have been deleted:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="10923"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="18673"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="18846"/>
        <source>寻找连接关系对象</source>
        <comment>toolName</comment>
        <translation type="unfinished">Find the Relation Object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11086"/>
        <source>创建连接关系</source>
        <comment>toolName</comment>
        <translation type="unfinished">Create Relationship</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11820"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12139"/>
        <source>图元文件保存成功！但文件大小超过500KB，请检查！</source>
        <translation type="unfinished">Icon file saved successfully! But the file size is more than 500KB, please check!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11824"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12143"/>
        <source>图元文件保存成功！</source>
        <translation type="unfinished">Icon file saved successfully!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12193"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12491"/>
        <source>画面应用信息或层信息为空，无法保存，请打开配置！</source>
        <translation type="unfinished">Graph application info or layer info is empty, can not save, please open the config!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13369"/>
        <source>拖拽模式下不支持滚轮缩放</source>
        <translation type="unfinished">Scroll scaling is not supported in drag mode</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="13885"/>
        <source>当前用户没有操作权限,不保存直接退出</source>
        <translation type="unfinished">The current user has no operation permission, exit without saving</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="14003"/>
        <source>(草稿版本)</source>
        <translation type="unfinished">(Draft version)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="14007"/>
        <source>(最新版本)</source>
        <translation type="unfinished">(Latest version)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="14011"/>
        <source>(版本</source>
        <translation type="unfinished">(Version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15001"/>
        <source>二维表</source>
        <translation type="unfinished">2D Table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15006"/>
        <source>柱状图</source>
        <translation type="unfinished">Bar chart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15011"/>
        <source>饼图</source>
        <translation type="unfinished">Pie chart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15016"/>
        <source>进度条</source>
        <translation type="unfinished">Progress bar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15021"/>
        <source>环形图</source>
        <translation type="unfinished">Ring chart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15026"/>
        <source>电池</source>
        <translation type="unfinished">Battery</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15031"/>
        <source>仪表盘</source>
        <translation type="unfinished">Panel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15038"/>
        <source>二维表中的子项</source>
        <translation type="unfinished">Subitems in 2D table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15161"/>
        <source>是否清除所选元素的数据库连接，请确认</source>
        <translation type="unfinished">Please confirm whether to clear the db connection for the selected element</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15165"/>
        <source>是否清除该画面所有元素的数据库连接，请确认</source>
        <translation type="unfinished">Please confirm whether to clear the db connections for all elements in this graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15170"/>
        <source>当前画面没有需要被清除数据库连接的元素</source>
        <translation type="unfinished">Current graph: no elements to clear DB connection.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15175"/>
        <source>清除数据库连接</source>
        <translation type="unfinished">Clear db connection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15223"/>
        <source>清除完成</source>
        <translation type="unfinished">Clear completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15243"/>
        <source>请先选择图元后再生成标签。</source>
        <translation type="unfinished">Please select the icon first before generating the label.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="17086"/>
        <source>路径更新完成</source>
        <translation type="unfinished">Path update completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="18837"/>
        <source>获取路径完成!</source>
        <translation type="unfinished">Get path complete!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="19000"/>
        <source>获取OID完成!</source>
        <translation type="unfinished">Getting OID is complete!</translation>
    </message>
</context>
<context>
    <name>IconNodeList</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="33"/>
        <source>图元列表</source>
        <translation type="unfinished">Icon list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="33"/>
        <source>对象源名称</source>
        <translation type="unfinished">Object source name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="175"/>
        <source>添加图元类型</source>
        <translation type="unfinished">Add icon type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="178"/>
        <source>刷新图元字典</source>
        <translation type="unfinished">Refresh icon dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="181"/>
        <source>添加图元</source>
        <translation type="unfinished">Add Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="187"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="190"/>
        <source>删除图元类型</source>
        <translation type="unfinished">Delete type of icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="199"/>
        <source>删除图元</source>
        <translation type="unfinished">Delete Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="205"/>
        <source>删除草稿</source>
        <translation type="unfinished">Delete drafts</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="208"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="402"/>
        <source>显示待发布</source>
        <translation type="unfinished">Display &apos;to be published&apos;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="395"/>
        <source>显示全部</source>
        <translation type="unfinished">Show all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="723"/>
        <source>删除图元时指针为空</source>
        <translation type="unfinished">When deleting an icon, the pointer is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="791"/>
        <source>图元[%1]删除失败</source>
        <translation type="unfinished">Icon [%1] deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="801"/>
        <source>删除图元类型时指针为空</source>
        <translation type="unfinished">When deleting an icon type, the pointer is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="808"/>
        <source>图元类型[%1]下存在未删除的图元，图元类型删除失败</source>
        <translation type="unfinished">Icon type [%1]: undeleted icons. Deletion failed.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="840"/>
        <source>图元类型[%1]删除失败</source>
        <translation type="unfinished">Icon type [%1] deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="854"/>
        <source>提示</source>
        <comment>toolName</comment>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="855"/>
        <source>请确认是否删除当前图元类型以及该图元类型下的所有图元</source>
        <translation type="unfinished">Please confirm whether to delete the current icon type and all icons under that icon type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="902"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="906"/>
        <source>信息</source>
        <translation type="unfinished">Message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="906"/>
        <source>图元类型以及图元类型下的图元全部删除成功</source>
        <translation type="unfinished">This icon type and all icons under that icon type have been successfully deleted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="911"/>
        <source>该图元节点不存在</source>
        <translation type="unfinished">The icon node does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="184"/>
        <source>修改图元类型</source>
        <translation type="unfinished">Edit icon type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="196"/>
        <source>修改图元</source>
        <translation type="unfinished">Modify icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="193"/>
        <source>发布图元</source>
        <translation type="unfinished">Publish icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="202"/>
        <source>另存为</source>
        <translation type="unfinished">Save as</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="497"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="911"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/icon_node_list.cpp" line="498"/>
        <source>图元已在节点：%1,进程号：%2,注册名：%3 中打开</source>
        <translation type="unfinished">Icon has been opened in node: %1, PID: %2, RegName: %3</translation>
    </message>
</context>
<context>
    <name>PicNodeList</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="313"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="318"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="373"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="378"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="416"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="518"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="523"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="686"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="691"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="926"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="313"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="373"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="416"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="926"/>
        <source>目录名称已存在，请重新输入！</source>
        <translation type="unfinished">DIR name already exists, please re-enter!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="318"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="378"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="523"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="691"/>
        <source>添加失败！</source>
        <translation type="unfinished">Failed to add!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="495"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="663"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="876"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1824"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1872"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1886"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1896"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1936"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1978"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2009"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2038"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2067"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2103"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2145"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2174"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2453"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2476"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2481"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2497"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2589"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="495"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="663"/>
        <source>请在库中先配置应用图类型</source>
        <translation type="unfinished">Please configure the App graph type in the DB first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="518"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="686"/>
        <source>画面名称重复，请重新输入！</source>
        <translation type="unfinished">Graph name duplicate, please re-enter!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="550"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="710"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2794"/>
        <source>草稿版本</source>
        <translation type="unfinished">Draft version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="791"/>
        <source>请确认是否删除当前应用</source>
        <translation type="unfinished">Please confirm whether to delete the current application</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="43"/>
        <source>画面列表</source>
        <translation type="unfinished">Graph list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="43"/>
        <source>对象源名称</source>
        <translation type="unfinished">Object source name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="152"/>
        <source>添加应用</source>
        <translation type="unfinished">Add app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="172"/>
        <source>发布画面类型</source>
        <translation type="unfinished">Publish graph type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="180"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="188"/>
        <source>删除应用</source>
        <translation type="unfinished">Delete app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="184"/>
        <source>修改应用</source>
        <translation type="unfinished">Modify App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="160"/>
        <source>添加画面类型</source>
        <translation type="unfinished">Add graph type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="164"/>
        <source>修改画面类型</source>
        <translation type="unfinished">Edit graph type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="168"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="176"/>
        <source>删除画面类型</source>
        <translation type="unfinished">Delete graph type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="148"/>
        <source>添加画面</source>
        <translation type="unfinished">Add graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="200"/>
        <source>删除画面</source>
        <translation type="unfinished">Delete graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="196"/>
        <source>修改画面</source>
        <translation type="unfinished">Edit graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="156"/>
        <source>刷新列表</source>
        <translation type="unfinished">Refresh list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="192"/>
        <source>发布画面</source>
        <translation type="unfinished">Publish graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="204"/>
        <source>另存为</source>
        <translation type="unfinished">Save as</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="208"/>
        <source>清空历史版本</source>
        <translation type="unfinished">Clear history version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="790"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1484"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1568"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1674"/>
        <source>提示</source>
        <comment>toolName</comment>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="876"/>
        <source>删除的应用目录不为空，请检查报表和画面应用子对象数量，先将子对象全部删除</source>
        <translation type="unfinished">The deleted application dir is not empty. Please check the number of sub objects in the report and graph applications, and delete all subobjects first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="884"/>
        <source>修改应用</source>
        <comment>toolName</comment>
        <translation type="unfinished">Modify App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1070"/>
        <source>删除画面失败，指针为空</source>
        <translation type="unfinished">Failed to delete graph, pointer is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1123"/>
        <source>画面[%1]已在节点：%2,进程号：%3,注册名：%4 中打开</source>
        <translation type="unfinished">Graph [%1] has been opened in node: %2, Process ID: %3, reg name: %4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1184"/>
        <source>画面[%1]删除失败</source>
        <translation type="unfinished">Graph [%1] deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1203"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1289"/>
        <source>删除画面目录失败，指针为空</source>
        <translation type="unfinished">Failed to delete graph dir, pointer is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1273"/>
        <source>画面目录[%1]删除失败</source>
        <translation type="unfinished">Graph dir [%1] deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1280"/>
        <source>删除的画面目录[%1]不为空，删除失败</source>
        <translation type="unfinished">The deleted graph dir [%1] is not empty, deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1364"/>
        <source>应用目录[%1]删除失败</source>
        <translation type="unfinished">Application dir [%1] deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1371"/>
        <source>删除的应用目录[%1]不为空，请检查报表和画面应用子对象数量，先将子对象全部删除</source>
        <translation type="unfinished">The deleted application dir [%1] is not empty. Please check the number of sub-objects in the report and graph, and delete all sub-objects first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1384"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1440"/>
        <source>画面指针为空</source>
        <translation type="unfinished">The graph pointer is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1392"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1448"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1503"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1595"/>
        <source>获取待删除列表失败，当前最多支持创建10层画面类型,请检查</source>
        <translation type="unfinished">Failed to retrieve the list to be deleted; up to 10 layers of graph types can be created; please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1569"/>
        <source>请确认是否删除当前应用以及应用下所有的画面目录和画面</source>
        <translation type="unfinished">Please confirm whether to delete the current application and all the graph dirs and graphs under the application</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1503"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1541"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1551"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1556"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1595"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1634"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1644"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1649"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1693"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1709"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1485"/>
        <source>请确认是否删除当前画面类型以及画面类型下所有的画面目录和画面</source>
        <translation type="unfinished">Please confirm whether to delete the current graph type and all the graph directories and graphs under the graph type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1541"/>
        <source>该画面类型以及所有子项全部删除成功</source>
        <translation type="unfinished">The graph type and all sub-items have been successfully deleted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1556"/>
        <source>画面类型节点不存在</source>
        <translation type="unfinished">The graph type node does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1634"/>
        <source>该画面应用以及所有子项全部删除成功</source>
        <translation type="unfinished">The application and all sub-items on this graph have been successfully deleted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1649"/>
        <source>画面应用节点不存在</source>
        <translation type="unfinished">The graph application node does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1675"/>
        <source>当前操作会发布画面类型下所有的画面，请确认是否继续？</source>
        <translation type="unfinished">The current operation will publish all graphs under this graph type. Please confirm whether to continue?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1693"/>
        <source>获取待发布列表失败，当前最多支持创建10层画面类型,请检查</source>
        <translation type="unfinished">Failed to retrieve the list to be published. Currently, a maximum of 10 layers of graph types can be created. Please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1709"/>
        <source>当前画面目录下没有需要发布的画面</source>
        <translation type="unfinished">Current graph dir: no graphs to publish.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1719"/>
        <source>信息</source>
        <translation type="unfinished">Message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1824"/>
        <source>未查询到历史版本，无需清理！</source>
        <translation type="unfinished">No historical versions found, no need to clean up!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1873"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2590"/>
        <source>画面已在节点：%1,进程号：%2,注册名：%3 中打开</source>
        <translation type="unfinished">The graph is already open in node: %1, PID: %2, RegName: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1887"/>
        <source>是</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1888"/>
        <source>否</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1897"/>
        <source>归零</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Reset to zero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1898"/>
        <source>不归零</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Skip reset to zero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1899"/>
        <source>取消操作</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1936"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2009"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2038"/>
        <source>版本归零成功！</source>
        <translation type="unfinished">Version reset to zero succeeded!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1978"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2067"/>
        <source>版本归零失败！</source>
        <translation type="unfinished">Version reset to zero failed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2103"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2174"/>
        <source>清空历史版本成功！</source>
        <translation type="unfinished">Clear history versions successfully!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2145"/>
        <source>清空历史版本失败！</source>
        <translation type="unfinished">Failed to clear history versions!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2207"/>
        <source>隐藏历史版本</source>
        <comment>menuName</comment>
        <translation type="unfinished">Hide history version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2211"/>
        <source>显示历史版本</source>
        <comment>menuName</comment>
        <translation type="unfinished">History version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="145"/>
        <source>显示历史版本</source>
        <translation type="unfinished">History version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1886"/>
        <source>此操作将删除所有历史版本，是否继续</source>
        <translation type="unfinished">This operation will delete all historical versions; whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="1896"/>
        <source>是否版本归零</source>
        <translation type="unfinished">Whether to reset version to zero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2453"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2476"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2481"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="2497"/>
        <source>未找到有效版本！</source>
        <translation type="unfinished">No valid version found!</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="3226"/>
        <source>草稿版本</source>
        <comment>PictureItem::displayChildren</comment>
        <translation type="unfinished">Draft version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="3235"/>
        <source>最新版本</source>
        <comment>PictureItem::displayChildren</comment>
        <translation type="unfinished">Latest version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="3258"/>
        <source>历史版本</source>
        <comment>PictureItem::displayChildren</comment>
        <translation type="unfinished">History version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/pic_node_list.cpp" line="3312"/>
        <source>版本%1</source>
        <comment>HistoryItem::displayChildren</comment>
        <translation type="unfinished">Version %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6659"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6666"/>
        <source>图元信息获取失败</source>
        <translation type="unfinished">Failed to retrieve icon information</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6719"/>
        <source>图元态信息中的图元态名为空的图元态信息删除完成</source>
        <translation type="unfinished">The deletion of the icon state information with an empty icon state name has been completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6738"/>
        <source>图元态名称为空的图元态删除完成</source>
        <translation type="unfinished">The deletion of the icon state with an empty icon state name is complete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6746"/>
        <source>图元态名称为空,无法删除获取不到图元态信息的图元态名称</source>
        <translation type="unfinished">Icon state name is empty; cannot delete names with unretrievable icon state information</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6789"/>
        <source>根据图元名称[%1]获取不到图元信息的图元态名删除完成</source>
        <translation type="unfinished">The deletion of the icon state information is complete, as the icon name cannot be retrieved based on this icon state information [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6797"/>
        <source>图元态名称为空,无法删除获取不到图元态名称的图元态信息</source>
        <translation type="unfinished">The icon state name is empty. Unable to delete icon state information without obtaining the icon state name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6818"/>
        <source>根据图元态[%1]信息获取到了图元态名称，无需删除图元态[%1]信息</source>
        <translation type="unfinished">The icon state name has been obtained based on the icon state [%1] information, so there is no need to delete the icon state [%1] information</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6767"/>
        <source>根据图元态[%1]名称获取到了图元态信息，无需删除图元态名称</source>
        <translation type="unfinished">No need to delete the icon state name, as the icon state information has been retrieved based on the icon state [%1] name </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6870"/>
        <source>根据图元态信息[%1]获取不到图元名称的图元态信息删除完成</source>
        <translation type="unfinished">The deletion of the icon state information is complete, as the icon name cannot be retrieved based on this icon state information [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6878"/>
        <source>图元态名称为空,无法删除重复的图元态名称</source>
        <translation type="unfinished">The icon state name is empty. Duplicate icon state names cannot be deleted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6899"/>
        <source>根据图元态[%1]名称获取不到图元态信息，请重新进行正确性检查</source>
        <translation type="unfinished">Icon state information cannot be retrieved by icon state [%1] name; please recheck for correctness</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6929"/>
        <source>图元态[%1]名称重复处理完成</source>
        <translation type="unfinished">Icon state [%1] name duplication processed successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6937"/>
        <source>图元态名称为空,无法删除重复的图元态信息</source>
        <translation type="unfinished">The name of the icon state is empty, and duplicate icon state information cannot be deleted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="6958"/>
        <source>根据图元态[%1]信息获取不到图元态名称，请重新进行正确性检查</source>
        <translation type="unfinished">The icon state name cannot be obtained based on the icon state [%1] information. Please perform a correctness check again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="7048"/>
        <source>图元态[%1]信息重复处理完成</source>
        <translation type="unfinished">The repeated processing of the icon state [%1] information has been completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="11695"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="12014"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15171"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15210"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15218"/>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/draw_view.cpp" line="15223"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
</context>
<context>
    <name>SimplePictureTreeWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="3365"/>
        <source>画面选择</source>
        <translation type="unfinished">Graph Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_msg_handler/dialogs/edit/dlg_state_template_set.cpp" line="3365"/>
        <source>原始名称</source>
        <translation type="unfinished">Original name</translation>
    </message>
</context>
</TS>
