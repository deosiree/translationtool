<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>GeneralEditorWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="816"/>
        <source>图形设计工具-图元模式：</source>
        <translation type="unfinished">Graphic Designer-Icon mode: </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="441"/>
        <source>非闭合图形：</source>
        <translation type="unfinished">Non-closed Graphic</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="448"/>
        <source>对直线、弧线、折线等非闭合图形进行样式配置</source>
        <translation type="unfinished">Style config of non-closed graphics such as straight lines, arcs, broken lines, etc</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="148"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="459"/>
        <source>线型：</source>
        <translation type="unfinished">Line type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="178"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="495"/>
        <source>线宽：</source>
        <translation type="unfinished">Line width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="208"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="306"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="531"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1265"/>
        <source>颜色：</source>
        <translation type="unfinished">Color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="117"/>
        <source>闭合图形：</source>
        <translation type="unfinished">Closed Graphic</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="47"/>
        <source>图形界面</source>
        <translation type="unfinished">Graphic Interface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="124"/>
        <source>对矩形、圆形、多边形等闭合图形进行样式配置</source>
        <translation type="unfinished">Style config of rectangles, circles, polygons and other closed graphics</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="136"/>
        <source>边框：</source>
        <translation type="unfinished">Border:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="243"/>
        <source>填充:</source>
        <translation type="unfinished">Fill:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="253"/>
        <source>纯色</source>
        <translation type="unfinished">Solid color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="266"/>
        <source>渐变</source>
        <translation type="unfinished">Gradation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="279"/>
        <source>图片</source>
        <translation type="unfinished">Picture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="658"/>
        <source>无字边框</source>
        <translation type="unfinished">Borderless without text</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="724"/>
        <source>翻译</source>
        <translation type="unfinished">Translation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="851"/>
        <source>图元个数：</source>
        <translation type="unfinished">Number of icons:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="925"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1017"/>
        <source>场景颜色：</source>
        <translation type="unfinished">Scene:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="951"/>
        <source>画面模式：</source>
        <translation type="unfinished">Graph mode:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1069"/>
        <source>光字牌预览色：</source>
        <translation type="unfinished">Preview color of annunciator:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1123"/>
        <source>是否显示挂牌连接线</source>
        <translation type="unfinished">Display the hanging connection line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1144"/>
        <source>画布高度：</source>
        <translation type="unfinished">Canvas height:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1130"/>
        <source>画布宽度：</source>
        <translation type="unfinished">Canvas width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="345"/>
        <source>透明度：</source>
        <translation type="unfinished">Transparency:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="370"/>
        <source>%</source>
        <translation type="unfinished">％</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="613"/>
        <source>字体类型：</source>
        <translation type="unfinished">Font family:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1158"/>
        <source>撤销步数：</source>
        <translation type="unfinished">Undo steps:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1175"/>
        <source>画面个数：</source>
        <translation type="unfinished">Number of graphs:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1192"/>
        <source>连接元素个数：</source>
        <translation type="unfinished">Number of connected elements:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1258"/>
        <source>连接点：</source>
        <translation type="unfinished">Connect point:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1291"/>
        <source>大小：</source>
        <translation type="unfinished">Size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1357"/>
        <source>其他</source>
        <translation type="unfinished">Other</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1380"/>
        <source>启动拓扑</source>
        <translation type="unfinished">Start topo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1402"/>
        <source>多节点操作提示框</source>
        <translation type="unfinished">Multi node operation prompt</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1415"/>
        <source>图形操作</source>
        <translation type="unfinished">Graphic Operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1464"/>
        <source>鼠标移动像素：</source>
        <translation type="unfinished">Mouse movement pixels:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1474"/>
        <source>复制偏移量：</source>
        <translation type="unfinished">Copy offset:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1484"/>
        <source>保存是否检查</source>
        <translation type="unfinished">Save checked</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1542"/>
        <source>应用名：</source>
        <translation type="unfinished">App name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1552"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1562"/>
        <source>库名：</source>
        <translation type="unfinished">DB name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1615"/>
        <source>取消应用</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1608"/>
        <source>应用发布</source>
        <comment>buttonName</comment>
        <translation type="unfinished">App publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="674"/>
        <source>字体大小：</source>
        <translation type="unfinished">Font size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="691"/>
        <source>对齐方式：</source>
        <translation type="unfinished">Alignment:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="710"/>
        <source>加粗</source>
        <translation type="unfinished">Bold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="717"/>
        <source>竖排</source>
        <translation type="unfinished">Vertical row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="630"/>
        <source>字体颜色：</source>
        <translation type="unfinished">Font:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="585"/>
        <source>图形</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Graphic</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1006"/>
        <source>图形设计工具-作图模式：</source>
        <translation type="unfinished">Graphic Designer-Drawing mode: </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1095"/>
        <source>刷新周期：</source>
        <translation type="unfinished">Refresh cycle:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1114"/>
        <source>秒</source>
        <translation type="unfinished">sec</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1224"/>
        <source>背景</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Background</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="825"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="1043"/>
        <source>画布颜色：</source>
        <translation type="unfinished">Canvas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.ui" line="914"/>
        <source>图形监视工具：</source>
        <translation type="unfinished">Graphic Monitor:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="51"/>
        <source>图形设计基础配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Basic Config Of Graphic Designer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="54"/>
        <source>静态%1文本</source>
        <translation type="unfinished">Static%1text</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="61"/>
        <source>无</source>
        <translation type="unfinished">None</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="62"/>
        <source>实线</source>
        <translation type="unfinished">Solid Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="63"/>
        <source>虚线</source>
        <translation type="unfinished">Dashed Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="64"/>
        <source>点线</source>
        <translation type="unfinished">Dotted Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="65"/>
        <source>点划线</source>
        <translation type="unfinished">Dot-dash Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="66"/>
        <source>点点划线</source>
        <translation type="unfinished">Two-dot-dash Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="93"/>
        <source>中对齐</source>
        <translation type="unfinished">Center align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="94"/>
        <source>左对齐</source>
        <translation type="unfinished">Left align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="95"/>
        <source>右对齐</source>
        <translation type="unfinished">Right align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="96"/>
        <source>上对齐</source>
        <translation type="unfinished">Top align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="97"/>
        <source>下对齐</source>
        <translation type="unfinished">Bottom align</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="100"/>
        <source>默认</source>
        <translation type="unfinished">Default</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="101"/>
        <source>满屏</source>
        <translation type="unfinished">Fit screen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="289"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="298"/>
        <source>信息</source>
        <translation type="unfinished">Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="289"/>
        <source>上传失败</source>
        <translation type="unfinished">Upload failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="299"/>
        <source>保存并成功上传至%1%2%3</source>
        <translation type="unfinished">Save and successfully upload to %1%2%3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="299"/>
        <source>图形设计(监视)工具需重启生效</source>
        <translation type="unfinished">Graphic Designer/Graphic Monitor needs to be restarted to take effect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="310"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="554"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="310"/>
        <source>是否重置</source>
        <translation type="unfinished">Whether to reset it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_basic_plug/graphic_general_basic_widget.cpp" line="555"/>
        <source>数据发生变化，是否保存</source>
        <translation type="unfinished">Data has been modified, whether to save the changes</translation>
    </message>
</context>
</TS>
