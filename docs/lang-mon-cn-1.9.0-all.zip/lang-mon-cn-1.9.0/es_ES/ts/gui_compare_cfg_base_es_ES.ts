<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="82"/>
        <source>源文件：</source>
        <translation type="unfinished">Archivo de origen:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="84"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="92"/>
        <source>请选择比对对象</source>
        <translation type="unfinished">Seleccione el objeto de comparación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="89"/>
        <source>目标文件：</source>
        <translation type="unfinished">Archivo de destino:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="97"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="102"/>
        <source>选择文件</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="193"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="475"/>
        <source>选择文件</source>
        <translation type="unfinished">Seleccionar Archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="144"/>
        <source>比对</source>
        <translation type="unfinished">Comparar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="159"/>
        <source>重新加载</source>
        <translation type="unfinished">Recargar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="234"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="249"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="514"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="521"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1244"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1248"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1653"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1657"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="249"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="521"/>
        <source>相同文件，请重新选择</source>
        <translation type="unfinished">Mismo archivo, por favor seleccione de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="514"/>
        <source>不是同配置名，请重新选择</source>
        <translation type="unfinished">No es el mismo nombre de configuración, por favor seleccione de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="295"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="545"/>
        <source>模型</source>
        <translation type="unfinished">Modelo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="149"/>
        <source>展示全部</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="154"/>
        <source>仅看差异项</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="234"/>
        <source>需清空目标配置，是否继续</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="306"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="557"/>
        <source>自定义类型</source>
        <translation type="unfinished">Tipos personalizados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="348"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="597"/>
        <source>配置项</source>
        <translation type="unfinished">Elementos de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="374"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="623"/>
        <source>数据</source>
        <translation type="unfinished">Datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1244"/>
        <source>有差异</source>
        <translation type="unfinished">Hay diferencias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1248"/>
        <source>无差异</source>
        <translation type="unfinished">Sin diferencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1657"/>
        <source>配置文件加载失败</source>
        <translation type="unfinished">Error al cargar el archivo de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1653"/>
        <source>加载完成</source>
        <translation type="unfinished">Carga completada</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1677"/>
        <source>配置文件比对工具</source>
        <comment>toolName</comment>
        <translation type="unfinished">Herramienta de Comparación de Archivos de Configuración</translation>
    </message>
</context>
</TS>
