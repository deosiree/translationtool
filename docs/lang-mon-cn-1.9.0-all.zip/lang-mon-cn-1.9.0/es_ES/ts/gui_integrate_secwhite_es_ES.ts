<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CSecWhitelistWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="74"/>
        <source>刷新</source>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="77"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="58"/>
        <source>IP地址</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Dirección IP</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="75"/>
        <source>新增</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="76"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="110"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="199"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="205"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="110"/>
        <source>请先选中要删除的记录</source>
        <translation type="unfinished">Por favor, seleccione el registro que desea eliminar primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="116"/>
        <source>是否删除</source>
        <translation type="unfinished">¿Eliminar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="116"/>
        <source>记录</source>
        <translation type="unfinished">Registros</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="117"/>
        <source>询问</source>
        <translation type="unfinished">Solicitar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="199"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="205"/>
        <source>刷新成功</source>
        <translation type="unfinished">Actualización exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.ui" line="35"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.ui" line="42"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/pluginsecwhite.cpp" line="45"/>
        <source>白名单配置</source>
        <translation type="unfinished">Lista blanca de configuración</translation>
    </message>
</context>
</TS>
