<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CSecWhitelistWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="74"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="77"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="58"/>
        <source>IP地址</source>
        <comment>subTitle</comment>
        <translation type="unfinished">IP address</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="75"/>
        <source>新增</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="76"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="110"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="199"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="205"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="110"/>
        <source>请先选中要删除的记录</source>
        <translation type="unfinished">Please select the record you want to delete first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="116"/>
        <source>记录</source>
        <translation type="unfinished">Records</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="116"/>
        <source>是否删除</source>
        <translation type="unfinished">Whether to delete it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="117"/>
        <source>询问</source>
        <translation type="unfinished">Ask</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="199"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.cpp" line="205"/>
        <source>刷新成功</source>
        <translation type="unfinished">Refresh successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.ui" line="35"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/secwhitelistwidget.ui" line="42"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secwhite/pluginsecwhite.cpp" line="45"/>
        <source>白名单配置</source>
        <translation type="unfinished">Config Whitelist</translation>
    </message>
</context>
</TS>
