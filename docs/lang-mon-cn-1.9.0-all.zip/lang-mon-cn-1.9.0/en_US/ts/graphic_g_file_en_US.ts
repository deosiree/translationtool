<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CIMEFile</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="39"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="215"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="224"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="231"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="248"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="39"/>
        <source>当前画面为空</source>
        <translation type="unfinished">The current graph is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="215"/>
        <source>获取画面文件名失败</source>
        <translation type="unfinished">Failed to retrieve the graph file name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="224"/>
        <source>创建CIME文件失败</source>
        <translation type="unfinished">Failed to create CIME file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="231"/>
        <source>上传文件管理失败</source>
        <translation type="unfinished">Upload file management failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_cime_file.cpp" line="248"/>
        <source>CIME文件导出成功</source>
        <translation type="unfinished">CIME file export successful</translation>
    </message>
</context>
<context>
    <name>ClearHistoryDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_clear_dlg.cpp" line="10"/>
        <source>清除历史G文件</source>
        <comment>toolName</comment>
        <translation type="unfinished">Clear Historical G-files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_clear_dlg.cpp" line="19"/>
        <source>清除历史G文件将清除历史版本</source>
        <translation type="unfinished">Clearing historical G-files will clear historical versions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_clear_dlg.cpp" line="30"/>
        <source>不清除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Not clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_clear_dlg.cpp" line="31"/>
        <source>清除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Clear</translation>
    </message>
</context>
<context>
    <name>ExportGFileDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_choose_dlg.cpp" line="11"/>
        <source>全选</source>
        <translation type="unfinished">Select all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_choose_dlg.cpp" line="12"/>
        <source>导出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_choose_dlg.cpp" line="13"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_choose_dlg.cpp" line="15"/>
        <source>选择要导出的G文件</source>
        <comment>toolName</comment>
        <translation type="unfinished">Select G-file To Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_choose_dlg.cpp" line="23"/>
        <source>检索：</source>
        <translation type="unfinished">Search:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_choose_dlg.cpp" line="80"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_choose_dlg.cpp" line="80"/>
        <source>请选择要导出的G文件</source>
        <translation type="unfinished">Please select the G-file to export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_choose_dlg.cpp" line="143"/>
        <source>选中 %1 / %2 项</source>
        <translation type="unfinished">Select the %1 / %2 items</translation>
    </message>
</context>
<context>
    <name>GFile</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="77"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="135"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="374"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="1096"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="1258"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4798"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4807"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4818"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4832"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4989"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6185"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6194"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6202"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6227"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6247"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6272"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6359"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="77"/>
        <source>获取当前应用接口插件失败</source>
        <translation type="unfinished">Failed to retrieve the current application interface plug-in</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="135"/>
        <source>创建%1目录失败</source>
        <translation type="unfinished">Failed to create %1 dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="262"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="317"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="333"/>
        <source>此操作将改变目录 %1 下的G文件</source>
        <translation type="unfinished">This operation will change the G-file in dir %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="344"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="432"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="456"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="487"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="498"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6167"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="374"/>
        <source>导出%1失败</source>
        <translation type="unfinished">Export %1 failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="426"/>
        <source>%1.%2 失败原因:%3</source>
        <translation type="unfinished">%1. %2 Reason for failure: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="402"/>
        <source>图片</source>
        <translation type="unfinished">Picture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="409"/>
        <source>图元</source>
        <translation type="unfinished">Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="432"/>
        <source>使用的图片异常，是否继续</source>
        <translation type="unfinished">The used picture is abnormal. Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="456"/>
        <source>使用的图元导出失败，是否继续</source>
        <translation type="unfinished">Failed to export the used icons. Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="562"/>
        <source>导出成功的画面：</source>
        <translation type="unfinished">Graph export successful:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="574"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="594"/>
        <source>无</source>
        <translation type="unfinished">None</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="578"/>
        <source>导出失败的画面：</source>
        <translation type="unfinished">Export failed graph:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="587"/>
        <source>%1. %2 失败原因：%3</source>
        <translation type="unfinished">%1. %2 Reason for failure:%3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="601"/>
        <source>导出%1个G文件到目录 %2</source>
        <translation type="unfinished">Export %1 G-files to dir %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="605"/>
        <source>导出%1个G文件到目录 %2, 失败%3个</source>
        <translation type="unfinished">Exported %1 G-files to dir %2, failed %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="1404"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="2562"/>
        <source>%1 (大小: %2 字节)</source>
        <translation type="unfinished">%1 (Size: %2 bytes)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4807"/>
        <source>上传PROJ失败，%1</source>
        <translation type="unfinished">Upload PROJ failed,%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="1096"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="1258"/>
        <source>获取应用接口插件失败</source>
        <translation type="unfinished">Failed to retrieve App interface plugin</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="203"/>
        <source>标识错误:标识(-1)</source>
        <translation type="unfinished">Identification error: Identification (-1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="210"/>
        <source>标识重复:标识(%1)</source>
        <translation type="unfinished">Duplicate identifier: identifier (%1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="487"/>
        <source>以下画面数据异常(详情请对该画面执行正确性检查)，是否继续</source>
        <translation type="unfinished">The following graph data is abnormal (please execute a correctness check on the graph for details). Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="498"/>
        <source>以下图片资源缺失，是否继续</source>
        <translation type="unfinished">The following picture resources are missing. Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="508"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6346"/>
        <source>正在上传文件...</source>
        <translation type="unfinished">Uploading file...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="514"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6371"/>
        <source>导出完成</source>
        <translation type="unfinished">Export completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="556"/>
        <source>导出总结</source>
        <comment>toolName</comment>
        <translation type="unfinished">Export Summary</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="612"/>
        <source>关闭</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="996"/>
        <source>正在复制图片 %1...</source>
        <translation type="unfinished">Copying picture %1...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="1197"/>
        <source>正在生成图元 %1...</source>
        <translation type="unfinished">Generating icon %1...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="1306"/>
        <source>正在解析画面 %1...</source>
        <translation type="unfinished">Parsing graph %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="1380"/>
        <source>正在生成G文件 %1...</source>
        <translation type="unfinished">Generating G-file %1...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4798"/>
        <source>压缩graph文件夹失败</source>
        <translation type="unfinished">Failed to compress the graph folder</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4863"/>
        <source>G文件上传文件服务失败的节点：</source>
        <translation type="unfinished">Node where the G-file upload file service failed:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4948"/>
        <source>继续</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4949"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="4989"/>
        <source>删除本地graph文件夹失败</source>
        <translation type="unfinished">Deletion of local graph folder failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5042"/>
        <source>应用接口返回为空</source>
        <translation type="unfinished">App interface returns null</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5044"/>
        <source>写xml文件失败</source>
        <translation type="unfinished">Failed to write the xml file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5046"/>
        <source>拷贝文件失败</source>
        <translation type="unfinished">Copy file failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5048"/>
        <source>mmi库OID错误</source>
        <translation type="unfinished">The mmi DB OID was incorrect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5050"/>
        <source>mmi库图元类型错误</source>
        <translation type="unfinished">mmi DB Icon type is incorrect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5052"/>
        <source>解析文件失败</source>
        <translation type="unfinished">Parse file failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5054"/>
        <source>mmi库图版本为0</source>
        <translation type="unfinished">The mmi DB version is 0</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5056"/>
        <source>文件大小超过</source>
        <translation type="unfinished">File size exceeds</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5056"/>
        <source>字节</source>
        <translation type="unfinished">Byte</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="5058"/>
        <source>未知</source>
        <translation type="unfinished">Unknown</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6087"/>
        <source>正在转换画面 %1...</source>
        <translation type="unfinished">Converting graph %1...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6185"/>
        <source>删除graph目录失败</source>
        <translation type="unfinished">Failed to delete graph dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6194"/>
        <source>创建graph目录失败</source>
        <translation type="unfinished">Failed to create Graph dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6202"/>
        <source>创建image目录失败</source>
        <translation type="unfinished">Failed to create image dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6215"/>
        <source>正在准备2016规范导出...</source>
        <translation type="unfinished">Preparing to export the 2016 standard...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6227"/>
        <source>加载图元映射配置失败</source>
        <translation type="unfinished">Failed to load icon mapping config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6235"/>
        <source>正在收集图元定义...</source>
        <translation type="unfinished">Collecting icon definition...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6247"/>
        <source>收集图元定义失败</source>
        <translation type="unfinished">Failed to collect icon definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6255"/>
        <source>正在准备图元定义...</source>
        <translation type="unfinished">Preparing icon definitions...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6272"/>
        <source>画面转换失败</source>
        <translation type="unfinished">Graph conversion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6280"/>
        <source>正在写入2016模板文件...</source>
        <translation type="unfinished">Writing 2016 template file ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6331"/>
        <source>正在复制图片资源...</source>
        <translation type="unfinished">Copying picture resources...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6359"/>
        <source>G文件上传文件服务失败（2016规范）</source>
        <translation type="unfinished">G-file upload file service failed (2016 standard)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6412"/>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file.cpp" line="6472"/>
        <source>此操作将覆盖目录 %1 下的G文件（2016规范），是否继续？</source>
        <translation type="unfinished">This operation will overwrite G-files in dir %1 (2016 standard), whether to continue?</translation>
    </message>
</context>
<context>
    <name>GFileProgressDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_progress_dialog.cpp" line="11"/>
        <source>G文件导出</source>
        <translation type="unfinished">G-file export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_g_file/graphic_g_file_progress_dialog.cpp" line="22"/>
        <source>正在准备导出...</source>
        <translation type="unfinished">Preparing to export...</translation>
    </message>
</context>
</TS>
