<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>ChoiceDialog</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/conflict_dialog.cpp" line="12"/>
        <source>通知</source>
        <comment>subTitle</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ComDbInfo</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.ui" line="121"/>
        <source>应用：      </source>
        <comment>subTitile</comment>
        <translation type="unfinished">Aplicación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.ui" line="169"/>
        <source>实时库：</source>
        <comment>subTitile</comment>
        <translation type="unfinished">TDB:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.ui" line="220"/>
        <source>模式：</source>
        <comment>subTitile</comment>
        <translation type="unfinished">Modo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.ui" line="248"/>
        <source>表：</source>
        <comment>subTitile</comment>
        <translation type="unfinished">Tabla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.ui" line="298"/>
        <source>目标表：</source>
        <comment>subTitile</comment>
        <translation type="unfinished">Tabla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.ui" line="335"/>
        <source>所有表</source>
        <comment>subTitile</comment>
        <translation type="unfinished">Todas las tablas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.ui" line="372"/>
        <source>路径：</source>
        <comment>subTitile</comment>
        <translation type="unfinished">Ruta:</translation>
    </message>
</context>
<context>
    <name>ComList</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_list.ui" line="118"/>
        <source>条件过滤</source>
        <comment>subTitile</comment>
        <translation type="unfinished">Condición</translation>
    </message>
</context>
<context>
    <name>ComTree</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_tree.ui" line="74"/>
        <source>对象路径导航</source>
        <comment>subTitile</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="275"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="1622"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="275"/>
        <source>连接%1数据库失败</source>
        <translation type="unfinished">Fallo al conectar con la base de datos %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="849"/>
        <source>  表：   {}（{}）{}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="852"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="1715"/>
        <source>维护库</source>
        <translation type="unfinished">MTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="1623"/>
        <source>连接%1应用下%2的%3库失败</source>
        <translation type="unfinished">Descargar el archivo %1 %2 del Servicio de archivos al archivo local %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="1626"/>
        <source>运行</source>
        <translation type="unfinished">Ejecutar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="1626"/>
        <source>维护</source>
        <translation type="unfinished">Mantenimiento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="1649"/>
        <source>已关联</source>
        <comment>subTitle</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="1654"/>
        <source>未关联</source>
        <comment>subTitle</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="851"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="1714"/>
        <source>运行库</source>
        <translation type="unfinished">RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_filter.cpp" line="110"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_list.cpp" line="464"/>
        <source>筛选</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Filtro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_list.cpp" line="463"/>
        <source>对象枚举过滤器</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Filtro de enumeración de objetos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_list.cpp" line="468"/>
        <source>全选</source>
        <translation type="unfinished">Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_list.cpp" line="469"/>
        <source>反选</source>
        <translation type="unfinished">Invertir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_list.cpp" line="470"/>
        <source>取消选择</source>
        <translation type="unfinished">Cancelar selección</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_lineedit.cpp" line="110"/>
        <source>区分大小写</source>
        <translation type="unfinished">Distingue mayúsculas y minúsculas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_lineedit.cpp" line="122"/>
        <source>全字匹配</source>
        <translation type="unfinished">Coincidir palabra completa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_lineedit.cpp" line="133"/>
        <source>搜索</source>
        <translation type="unfinished">Buscar</translation>
    </message>
</context>
<context>
    <name>iasp::dbms::ComComBox</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_combox.cpp" line="74"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_combox.cpp" line="74"/>
        <source>异常输入，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>iasp::dbms::ComDbInfo</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="900"/>
        <source>条件【%1】无效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="905"/>
        <source>%1%2oid【%3】无效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="911"/>
        <source>清空信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="911"/>
        <source>取消回显</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="956"/>
        <source>条件【%1】和oid【%2】不匹配，请选择处理方案：%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="960"/>
        <source>%1&lt;方案一&gt;：以oid【%2】刷条件为【%3】%4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="965"/>
        <source>%1&lt;方案二&gt;：以条件【%2】刷oid为【%3】</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="970"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="1030"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="1082"/>
        <source>方案一</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="971"/>
        <source>方案二</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="972"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="1031"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="1083"/>
        <source>取消回显</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="1024"/>
        <source>条件【%1】无效，请选择处理方案：%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="1025"/>
        <source>%1&lt;方案一&gt;：以oid【%2】刷条件为【%3】</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="1076"/>
        <source>oid【%1】无效，请选择处理方案：%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_db_info.cpp" line="1077"/>
        <source>%1&lt;方案一&gt;：以条件【%2】刷oid为【%3】</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>iasp::dbms::ComFilter</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_filter.cpp" line="131"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_filter.cpp" line="146"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_filter.cpp" line="131"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_filter.cpp" line="147"/>
        <source>异常输入，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>iasp::dbms::ComList</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_list.cpp" line="429"/>
        <source>显示字段</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_list.cpp" line="429"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_selector_comp/com_list.cpp" line="455"/>
        <source>隐藏字段</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
