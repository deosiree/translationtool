<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CUserInfoWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="30"/>
        <source>个人信息配置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Personal info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="61"/>
        <source>邮箱：        </source>
        <translation type="unfinished">Email:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="71"/>
        <source>密码到期时间：</source>
        <translation type="unfinished">Password expiration time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="78"/>
        <source>新密码：      </source>
        <translation type="unfinished">New password:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="88"/>
        <source>确认新密码：  </source>
        <translation type="unfinished">Confirm new password:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="98"/>
        <source>电话：        </source>
        <translation type="unfinished">Phone:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="105"/>
        <source>密码修改时间：</source>
        <translation type="unfinished">Password change time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="118"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="144"/>
        <source>修改密码</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Change password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="154"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="134"/>
        <source>密码：        </source>
        <translation type="unfinished">Password:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="79"/>
        <source>修改密码</source>
        <translation type="unfinished">Change Password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="161"/>
        <source>用户名称：    </source>
        <translation type="unfinished">Username:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.ui" line="168"/>
        <source>角色：        </source>
        <translation type="unfinished">Characters:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="63"/>
        <source>操作员</source>
        <translation type="unfinished">Operator</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="155"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="161"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="166"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="175"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="193"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="218"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="229"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="240"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="258"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="298"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="307"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="315"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="337"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="371"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="392"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="406"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="458"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="155"/>
        <source>原密码错误</source>
        <translation type="unfinished">Old password error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="161"/>
        <source>两次输入密码不一致</source>
        <translation type="unfinished">The passwords you entered twice do not match</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="166"/>
        <source>新旧密码相同</source>
        <translation type="unfinished">The old and new passwords are the same</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="193"/>
        <source>密码已使用</source>
        <translation type="unfinished">Password used</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="218"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="229"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="240"/>
        <source>密码修改失败</source>
        <translation type="unfinished">Password modification failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="258"/>
        <source>输入包含非法字符，请检查</source>
        <translation type="unfinished">The input contains illegal characters; please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="271"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="278"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="336"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="354"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="370"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="388"/>
        <source>用户信息配置</source>
        <translation type="unfinished">User Info Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="298"/>
        <source>修改密码成功</source>
        <translation type="unfinished">Password changed successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="307"/>
        <source>请检查电话是否设置正确</source>
        <translation type="unfinished">Please check if the phone is set up correctly</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="315"/>
        <source>请检查邮箱是否设置正确</source>
        <translation type="unfinished">Please check whether the mailbox is set correctly</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="337"/>
        <source>修改失败</source>
        <translation type="unfinished">Modification failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="371"/>
        <source>用户信息修改失败</source>
        <translation type="unfinished">User info modification failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="392"/>
        <source>修改成功</source>
        <translation type="unfinished">Modified successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="406"/>
        <source>刷新失败</source>
        <translation type="unfinished">Refresh failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/userinfowidget.cpp" line="458"/>
        <source>刷新成功</source>
        <translation type="unfinished">Refresh successfully</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserinfo/pluginsecuserinfo.cpp" line="45"/>
        <source>个人信息</source>
        <translation type="unfinished">Personal Info</translation>
    </message>
</context>
</TS>
