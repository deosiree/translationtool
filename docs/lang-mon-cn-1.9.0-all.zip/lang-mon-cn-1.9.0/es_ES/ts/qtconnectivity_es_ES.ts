<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QBluetoothDeviceDiscoveryAgent</name>
    <message>
        <source>Device is powered off</source>
        <translation>El dispositivo está apagado</translation>
    </message>
    <message>
        <source>Cannot find valid Bluetooth adapter.</source>
        <translation>No se puede encontrar un adaptador Bluetooth válido.</translation>
    </message>
    <message>
        <source>Input Output Error</source>
        <translation>Error de Entrada/Salida</translation>
    </message>
    <message>
        <source>Bluetooth LE is not supported</source>
        <translation>Bluetooth LE no es compatible</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
    <message>
        <source>Missing permission</source>
        <translation>Permiso faltante</translation>
    </message>
    <message>
        <source>Cannot start device inquiry</source>
        <translation>No se puede iniciar la consulta de dispositivo</translation>
    </message>
    <message>
        <source>Cannot start low energy device inquiry</source>
        <translation>No se puede iniciar la consulta de dispositivo de baja energía</translation>
    </message>
    <message>
        <source>Discovery cannot be stopped</source>
        <translation>No se puede detener el descubrimiento</translation>
    </message>
    <message>
        <source>Invalid Bluetooth adapter address</source>
        <translation>Dirección de adaptador Bluetooth inválida</translation>
    </message>
    <message>
        <source>One or more device discovery methods are not supported on this platform</source>
        <translation>Uno o más métodos de descubrimiento de dispositivos no son compatibles en esta plataforma</translation>
    </message>
    <message>
        <source>Device does not support Bluetooth</source>
        <translation>El dispositivo no soporta Bluetooth</translation>
    </message>
    <message>
        <source>Passed address is not a local device.</source>
        <translation>La dirección pasada no es un dispositivo local.</translation>
    </message>
    <message>
        <source>Missing Location permission. Search is not possible.</source>
        <translation type="vanished">Permiso de Ubicación faltante. La búsqueda no es posible.</translation>
    </message>
    <message>
        <source>Location service turned off. Search is not possible.</source>
        <translation>Servicio de ubicación apagado. La búsqueda no es posible.</translation>
    </message>
    <message>
        <source>Failed to start device discovery due to missing permissions.</source>
        <translation>No se pudo iniciar el descubrimiento de dispositivos debido a permisos faltantes.</translation>
    </message>
    <message>
        <source>Classic Discovery cannot be started</source>
        <translation>No se puede iniciar el Descubrimiento Clásico</translation>
    </message>
    <message>
        <source>Low Energy Discovery not supported</source>
        <translation type="vanished">Descubrimiento de Baja Energía no compatible</translation>
    </message>
    <message>
        <source>Discovery cannot be started</source>
        <translation type="vanished">No se puede iniciar el descubrimiento</translation>
    </message>
    <message>
        <source>Bluetooth adapter error</source>
        <translation>Error del adaptador Bluetooth</translation>
    </message>
    <message>
        <source>Device discovery not supported on this platform</source>
        <translation>El descubrimiento de dispositivos no es compatible en esta plataforma</translation>
    </message>
    <message>
        <source>Cannot access adapter during service discovery</source>
        <translation>No se puede acceder al adaptador durante el descubrimiento de servicios</translation>
    </message>
    <message>
        <source>Bluetooth adapter powered off.</source>
        <translation>Adaptador Bluetooth apagado.</translation>
    </message>
</context>
<context>
    <name>QBluetoothServiceDiscoveryAgent</name>
    <message>
        <source>Local device is powered off</source>
        <translation>El dispositivo local está apagado</translation>
    </message>
    <message>
        <source>Minimal service discovery failed</source>
        <translation>Fallo en el Descubrimiento de Servicio Mínimo</translation>
    </message>
    <message>
        <source>Invalid Bluetooth adapter address</source>
        <translation>Dirección de adaptador Bluetooth inválida</translation>
    </message>
    <message>
        <source>Platform does not support Bluetooth</source>
        <translation>La plataforma no soporta Bluetooth</translation>
    </message>
    <message>
        <source>Android API below v15 does not support SDP discovery</source>
        <translation type="vanished">La API de Android por debajo de v15 no soporta el descubrimiento SDP</translation>
    </message>
    <message>
        <source>Failed to start service discovery due to missing permissions.</source>
        <translation>No se pudo iniciar el descubrimiento de servicios debido a permisos faltantes.</translation>
    </message>
    <message>
        <source>Cannot create Android BluetoothDevice</source>
        <translation>No se puede crear el dispositivo Bluetooth de Android</translation>
    </message>
    <message>
        <source>Cannot obtain service uuids</source>
        <translation>No se pueden obtener los UUID de servicio</translation>
    </message>
    <message>
        <source>Serial Port Profile</source>
        <translation>Perfil de Puerto Serial</translation>
    </message>
    <message>
        <source>Device is powered off</source>
        <translation>El dispositivo está apagado</translation>
    </message>
    <message>
        <source>Unable to find appointed local adapter</source>
        <translation type="vanished">No se pudo encontrar el adaptador local designado</translation>
    </message>
    <message>
        <source>Cannot find local Bluetooth adapter</source>
        <translation>No se puede encontrar el adaptador Bluetooth local</translation>
    </message>
    <message>
        <source>Unable to find sdpscanner</source>
        <translation>No se puede encontrar el escáner sdp</translation>
    </message>
    <message>
        <source>Unable to perform SDP scan</source>
        <translation>No se puede realizar el escaneo SDP</translation>
    </message>
    <message>
        <source>Unable to access device</source>
        <translation type="vanished">No se puede acceder al dispositivo</translation>
    </message>
    <message>
        <source>Custom Service</source>
        <translation>Servicio Personalizado</translation>
    </message>
    <message>
        <source>Service Discovery</source>
        <translation>Descubrimiento de Servicios</translation>
    </message>
    <message>
        <source>Browse Group Descriptor</source>
        <translation>Descriptor del Grupo de Exploración</translation>
    </message>
    <message>
        <source>Public Browse Group</source>
        <translation>Grupo de Navegación Pública</translation>
    </message>
    <message>
        <source>LAN Access Profile</source>
        <translation>Perfil de acceso LAN</translation>
    </message>
    <message>
        <source>Dial-Up Networking</source>
        <translation>Red de acceso telefónico</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation>Sincronización</translation>
    </message>
    <message>
        <source>Object Push</source>
        <translation>Transferencia de Objetos</translation>
    </message>
    <message>
        <source>File Transfer</source>
        <translation>Transferencia de archivos</translation>
    </message>
    <message>
        <source>Synchronization Command</source>
        <translation>Comando de sincronización</translation>
    </message>
    <message>
        <source>Headset</source>
        <translation>Auriculares</translation>
    </message>
    <message>
        <source>Audio Source</source>
        <translation>Fuente de Audio</translation>
    </message>
    <message>
        <source>Audio Sink</source>
        <translation>Receptor de Audio</translation>
    </message>
    <message>
        <source>Audio/Video Remote Control Target</source>
        <translation>Objetivo de control remoto de audio/vídeo</translation>
    </message>
    <message>
        <source>Advanced Audio Distribution</source>
        <translation>Distribución Avanzada de Audio</translation>
    </message>
    <message>
        <source>Audio/Video Remote Control</source>
        <translation>Control remoto de audio/vídeo</translation>
    </message>
    <message>
        <source>Audio/Video Remote Control Controller</source>
        <translation>Controlador remoto de audio/vídeo</translation>
    </message>
    <message>
        <source>Headset AG</source>
        <translation>Auricular AG</translation>
    </message>
    <message>
        <source>Personal Area Networking (PANU)</source>
        <translation>Red de área personal (PANU)</translation>
    </message>
    <message>
        <source>Personal Area Networking (NAP)</source>
        <translation>Red de Área Personal (NAP)</translation>
    </message>
    <message>
        <source>Personal Area Networking (GN)</source>
        <translation>Red de Área Personal (GN)</translation>
    </message>
    <message>
        <source>Basic Direct Printing (BPP)</source>
        <translation>Impresión Directa Básica (BPP)</translation>
    </message>
    <message>
        <source>Basic Reference Printing (BPP)</source>
        <translation>Impresión de referencia básica (BPP)</translation>
    </message>
    <message>
        <source>Basic Imaging Profile</source>
        <translation>Perfil de Imagen Básica</translation>
    </message>
    <message>
        <source>Basic Imaging Responder</source>
        <translation>Respondedor de Imágenes Básico</translation>
    </message>
    <message>
        <source>Basic Imaging Archive</source>
        <translation>Archivo de Imágenes Básico</translation>
    </message>
    <message>
        <source>Basic Imaging Ref Objects</source>
        <translation>Objetos de Referencia de Imagen Básica</translation>
    </message>
    <message>
        <source>Hands-Free</source>
        <translation>Manos libres</translation>
    </message>
    <message>
        <source>Hands-Free AG</source>
        <translation>Manos Libres AG</translation>
    </message>
    <message>
        <source>Basic Printing RefObject Service</source>
        <translation>Servicio de objeto de referencia de impresión básica</translation>
    </message>
    <message>
        <source>Basic Printing Reflected UI</source>
        <translation>Interfaz de Usuario Reflejada de Impresión Básica</translation>
    </message>
    <message>
        <source>Basic Printing</source>
        <translation>Impresión básica</translation>
    </message>
    <message>
        <source>Basic Printing Status</source>
        <translation>Estado de impresión básica</translation>
    </message>
    <message>
        <source>Human Interface Device</source>
        <translation>Dispositivo de Interfaz Humana</translation>
    </message>
    <message>
        <source>Hardcopy Cable Replacement</source>
        <translation>Reemplazo de Cable de Copia Dura</translation>
    </message>
    <message>
        <source>Hardcopy Cable Replacement Print</source>
        <translation>Impresión de Reemplazo de Cable de Copia Dura</translation>
    </message>
    <message>
        <source>Hardcopy Cable Replacement Scan</source>
        <translation>Escaneo de Reemplazo de Cable de Copia Dura</translation>
    </message>
    <message>
        <source>SIM Access Server</source>
        <translation>Servidor de Acceso a SIM</translation>
    </message>
    <message>
        <source>Phonebook Access PCE</source>
        <translation>Acceso a la Agenda Telefónica PCE</translation>
    </message>
    <message>
        <source>Phonebook Access PSE</source>
        <translation>Acceso a la Libreta de Teléfonos PSE</translation>
    </message>
    <message>
        <source>Phonebook Access</source>
        <translation>Acceso a la agenda telefónica</translation>
    </message>
    <message>
        <source>Headset HS</source>
        <translation>Auricular HS</translation>
    </message>
    <message>
        <source>Message Access Server</source>
        <translation>Servidor de Acceso a Mensajes</translation>
    </message>
    <message>
        <source>Message Notification Server</source>
        <translation>Servidor de notificación de mensajes</translation>
    </message>
    <message>
        <source>Message Access</source>
        <translation>Acceso a mensajes</translation>
    </message>
    <message>
        <source>Global Navigation Satellite System</source>
        <translation>Sistema Global de Navegación por Satélite</translation>
    </message>
    <message>
        <source>Global Navigation Satellite System Server</source>
        <translation>Servidor de Sistema Global de Navegación por Satélite</translation>
    </message>
    <message>
        <source>3D Synchronization Display</source>
        <translation>Pantalla de Sincronización 3D</translation>
    </message>
    <message>
        <source>3D Synchronization Glasses</source>
        <translation>Gafas de sincronización 3D</translation>
    </message>
    <message>
        <source>3D Synchronization</source>
        <translation>Sincronización 3D</translation>
    </message>
    <message>
        <source>Multi-Profile Specification (Profile)</source>
        <translation>Especificación Multiprofile (Perfil)</translation>
    </message>
    <message>
        <source>Multi-Profile Specification</source>
        <translation>Especificación multiperfil</translation>
    </message>
    <message>
        <source>Device Identification</source>
        <translation>Identificación del Dispositivo</translation>
    </message>
    <message>
        <source>Generic Networking</source>
        <translation>Redes Genéricas</translation>
    </message>
    <message>
        <source>Generic File Transfer</source>
        <translation>Transferencia de Archivos Genérica</translation>
    </message>
    <message>
        <source>Generic Audio</source>
        <translation>Audio Genérico</translation>
    </message>
    <message>
        <source>Generic Telephony</source>
        <translation>Telefonía genérica</translation>
    </message>
    <message>
        <source>Video Source</source>
        <translation>Fuente de Video</translation>
    </message>
    <message>
        <source>Video Sink</source>
        <translation>Receptor de Video</translation>
    </message>
    <message>
        <source>Video Distribution</source>
        <translation>Distribución de Video</translation>
    </message>
    <message>
        <source>Health Device</source>
        <translation>Dispositivo de salud</translation>
    </message>
    <message>
        <source>Health Device Source</source>
        <translation>Fuente de dispositivo de salud</translation>
    </message>
    <message>
        <source>Health Device Sink</source>
        <translation>Receptor de Dispositivo de Salud</translation>
    </message>
    <message>
        <source>Generic Access</source>
        <translation>Acceso genérico</translation>
    </message>
    <message>
        <source>Generic Attribute</source>
        <translation>Atributo Genérico</translation>
    </message>
    <message>
        <source>Immediate Alert</source>
        <translation>Alerta inmediata</translation>
    </message>
    <message>
        <source>Link Loss</source>
        <translation>Pérdida de enlace</translation>
    </message>
    <message>
        <source>Tx Power</source>
        <translation>Potencia de Transmisión</translation>
    </message>
    <message>
        <source>Current Time Service</source>
        <translation>Servicio de Hora Actual</translation>
    </message>
    <message>
        <source>Reference Time Update Service</source>
        <translation>Servicio de Actualización de Hora de Referencia</translation>
    </message>
    <message>
        <source>Next DST Change Service</source>
        <translation>Servicio de cambio de horario de verano</translation>
    </message>
    <message>
        <source>Glucose</source>
        <translation>Glucosa</translation>
    </message>
    <message>
        <source>Health Thermometer</source>
        <translation>Termómetro de Salud</translation>
    </message>
    <message>
        <source>Device Information</source>
        <translation>Información del Dispositivo</translation>
    </message>
    <message>
        <source>Heart Rate</source>
        <translation>Frecuencia Cardíaca</translation>
    </message>
    <message>
        <source>Phone Alert Status Service</source>
        <translation>Servicio de Estado de Alerta del Teléfono</translation>
    </message>
    <message>
        <source>Battery Service</source>
        <translation>Servicio de Batería</translation>
    </message>
    <message>
        <source>Blood Pressure</source>
        <translation>Presión Arterial</translation>
    </message>
    <message>
        <source>Alert Notification Service</source>
        <translation>Servicio de Notificación de Alertas</translation>
    </message>
    <message>
        <source>Scan Parameters</source>
        <translation>Parámetros de escaneo</translation>
    </message>
    <message>
        <source>Running Speed and Cadence</source>
        <translation>Velocidad y Cadencia de Carrera</translation>
    </message>
    <message>
        <source>Cycling Speed and Cadence</source>
        <translation>Velocidad y Cadencia de Ciclismo</translation>
    </message>
    <message>
        <source>Cycling Power</source>
        <translation>Potencia de Ciclismo</translation>
    </message>
    <message>
        <source>Location and Navigation</source>
        <translation>Ubicación y navegación</translation>
    </message>
    <message>
        <source>Environmental Sensing</source>
        <translation>Sensado Ambiental</translation>
    </message>
    <message>
        <source>Body Composition</source>
        <translation>Composición Corporal</translation>
    </message>
    <message>
        <source>User Data</source>
        <translation>Datos del usuario</translation>
    </message>
    <message>
        <source>Weight Scale</source>
        <translation>Báscula de Peso</translation>
    </message>
    <message>
        <source>Bond Management</source>
        <extracomment>Connection management (Bluetooth)</extracomment>
        <translation>Gestión de Vínculos</translation>
    </message>
    <message>
        <source>Continuous Glucose Monitoring</source>
        <translation>Monitoreo continuo de glucosa</translation>
    </message>
    <message>
        <source>Service Discovery Protocol</source>
        <translation>Protocolo de descubrimiento de servicios</translation>
    </message>
    <message>
        <source>User Datagram Protocol</source>
        <translation>Protocolo de Datagramas de Usuario</translation>
    </message>
    <message>
        <source>Radio Frequency Communication</source>
        <translation>Comunicación por radiofrecuencia</translation>
    </message>
    <message>
        <source>Transmission Control Protocol</source>
        <translation>Protocolo de control de transmisión</translation>
    </message>
    <message>
        <source>Telephony Control Specification - Binary</source>
        <translation>Especificación de Control de Telefonía - Binario</translation>
    </message>
    <message>
        <source>Telephony Control Specification - AT</source>
        <translation>Especificación de Control de Telefonía - AT</translation>
    </message>
    <message>
        <source>Attribute Protocol</source>
        <translation>Protocolo de atributos</translation>
    </message>
    <message>
        <source>Object Exchange Protocol</source>
        <translation>Protocolo de Intercambio de Objetos</translation>
    </message>
    <message>
        <source>Internet Protocol</source>
        <translation>Protocolo de Internet</translation>
    </message>
    <message>
        <source>File Transfer Protocol</source>
        <translation>Protocolo de Transferencia de Archivos</translation>
    </message>
    <message>
        <source>Hypertext Transfer Protocol</source>
        <translation>Protocolo de Transferencia de Hipertexto</translation>
    </message>
    <message>
        <source>Wireless Short Packet Protocol</source>
        <translation>Protocolo de paquete corto inalámbrico</translation>
    </message>
    <message>
        <source>Bluetooth Network Encapsulation Protocol</source>
        <translation>Protocolo de Encapsulación de Red Bluetooth</translation>
    </message>
    <message>
        <source>Extended Service Discovery Protocol</source>
        <translation>Protocolo de Descubrimiento de Servicios Extendidos</translation>
    </message>
    <message>
        <source>Human Interface Device Protocol</source>
        <translation>Protocolo de dispositivo de interfaz humana</translation>
    </message>
    <message>
        <source>Hardcopy Control Channel</source>
        <translation>Canal de Control de Copia Dura</translation>
    </message>
    <message>
        <source>Hardcopy Data Channel</source>
        <translation>Canal de datos de copia impresa</translation>
    </message>
    <message>
        <source>Hardcopy Notification</source>
        <translation>Notificación de Copia Impresa</translation>
    </message>
    <message>
        <source>Audio/Video Control Transport Protocol</source>
        <translation>Protocolo de Transporte de Control de Audio/Video</translation>
    </message>
    <message>
        <source>Audio/Video Distribution Transport Protocol</source>
        <translation>Protocolo de Transporte de Distribución de Audio/Video</translation>
    </message>
    <message>
        <source>Common ISDN Access Protocol</source>
        <translation>Protocolo de Acceso ISDN Común</translation>
    </message>
    <message>
        <source>UdiCPlain</source>
        <translation>UdiCPlain</translation>
    </message>
    <message>
        <source>Multi-Channel Adaptation Protocol - Control</source>
        <translation>Protocolo de Adaptación Multicanal - Control</translation>
    </message>
    <message>
        <source>Multi-Channel Adaptation Protocol - Data</source>
        <translation>Protocolo de Adaptación Multicanal - Datos</translation>
    </message>
    <message>
        <source>Layer 2 Control Protocol</source>
        <translation>Protocolo de Control de Capa 2</translation>
    </message>
    <message>
        <source>GAP Device Name</source>
        <extracomment>GAP: Generic Access Profile (Bluetooth)</extracomment>
        <translation>Nombre del dispositivo GAP</translation>
    </message>
    <message>
        <source>GAP Appearance</source>
        <extracomment>GAP: Generic Access Profile (Bluetooth)</extracomment>
        <translation>Apariencia GAP</translation>
    </message>
    <message>
        <source>GAP Peripheral Privacy Flag</source>
        <extracomment>GAP: Generic Access Profile (Bluetooth)</extracomment>
        <translation>Bandera de privacidad periférica GAP</translation>
    </message>
    <message>
        <source>GAP Reconnection Address</source>
        <extracomment>GAP: Generic Access Profile (Bluetooth)</extracomment>
        <translation>Dirección de Reconexión GAP</translation>
    </message>
    <message>
        <source>GAP Peripheral Preferred Connection Parameters</source>
        <translation>Parámetros Preferidos de Conexión del Periférico GAP</translation>
    </message>
    <message>
        <source>GATT Service Changed</source>
        <extracomment>GATT: _G_eneric _Att_ribute Profile (Bluetooth)</extracomment>
        <translation>Servicio GATT Cambiado</translation>
    </message>
    <message>
        <source>Alert Level</source>
        <translation>Nivel de Alerta</translation>
    </message>
    <message>
        <source>TX Power</source>
        <translation>Potencia de transmisión</translation>
    </message>
    <message>
        <source>Date Time</source>
        <translation>Fecha y hora</translation>
    </message>
    <message>
        <source>Day Of Week</source>
        <translation>Día de la semana</translation>
    </message>
    <message>
        <source>Day Date Time</source>
        <translation>Fecha y hora del día</translation>
    </message>
    <message>
        <source>Exact Time 256</source>
        <translation>Tiempo Exacto 256</translation>
    </message>
    <message>
        <source>DST Offset</source>
        <translation>Desfase de DST</translation>
    </message>
    <message>
        <source>Time Zone</source>
        <translation>Zona Horaria</translation>
    </message>
    <message>
        <source>Local Time Information</source>
        <translation>Información de Hora Local</translation>
    </message>
    <message>
        <source>Time With DST</source>
        <translation>Hora con DST</translation>
    </message>
    <message>
        <source>Time Accuracy</source>
        <translation>Precisión de la Hora</translation>
    </message>
    <message>
        <source>Time Source</source>
        <translation>Fuente de Tiempo</translation>
    </message>
    <message>
        <source>Reference Time Information</source>
        <translation>Información de Tiempo de Referencia</translation>
    </message>
    <message>
        <source>Time Update Control Point</source>
        <translation>Punto de Control de Actualización de Hora</translation>
    </message>
    <message>
        <source>Time Update State</source>
        <translation>Estado de Actualización de Tiempo</translation>
    </message>
    <message>
        <source>Glucose Measurement</source>
        <translation>Medición de glucosa</translation>
    </message>
    <message>
        <source>Battery Level</source>
        <translation>Nivel de Batería</translation>
    </message>
    <message>
        <source>Temperature Measurement</source>
        <translation>Medición de Temperatura</translation>
    </message>
    <message>
        <source>Temperature Type</source>
        <translation>Tipo de Temperatura</translation>
    </message>
    <message>
        <source>Intermediate Temperature</source>
        <translation>Temperatura Intermedia</translation>
    </message>
    <message>
        <source>Measurement Interval</source>
        <translation>Intervalo de Medición</translation>
    </message>
    <message>
        <source>Boot Keyboard Input Report</source>
        <translation>Informe de Entrada del Teclado de Arranque</translation>
    </message>
    <message>
        <source>System ID</source>
        <translation>ID del Sistema</translation>
    </message>
    <message>
        <source>Model Number String</source>
        <translation>Cadena de número de modelo</translation>
    </message>
    <message>
        <source>Serial Number String</source>
        <translation>Cadena de número de serie</translation>
    </message>
    <message>
        <source>Firmware Revision String</source>
        <translation>Cadena de Revisión de Firmware</translation>
    </message>
    <message>
        <source>Hardware Revision String</source>
        <translation>Cadena de Revisión de Hardware</translation>
    </message>
    <message>
        <source>Software Revision String</source>
        <translation>Cadena de Revisión de Software</translation>
    </message>
    <message>
        <source>Manufacturer Name String</source>
        <translation>Cadena de Nombre del Fabricante</translation>
    </message>
    <message>
        <source>IEEE 11073 20601 Regulatory Certification Data List</source>
        <translation>Lista de datos de certificación regulatoria IEEE 11073 20601</translation>
    </message>
    <message>
        <source>Current Time</source>
        <translation>Hora actual</translation>
    </message>
    <message>
        <source>Scan Refresh</source>
        <translation>Actualización de escaneo</translation>
    </message>
    <message>
        <source>Boot Keyboard Output Report</source>
        <translation>Informe de salida del teclado de arranque</translation>
    </message>
    <message>
        <source>Boot Mouse Input Report</source>
        <translation>Informe de entrada del ratón de arranque</translation>
    </message>
    <message>
        <source>Glucose Measurement Context</source>
        <translation>Contexto de medición de glucosa</translation>
    </message>
    <message>
        <source>Blood Pressure Measurement</source>
        <translation>Medición de Presión Arterial</translation>
    </message>
    <message>
        <source>Intermediate Cuff Pressure</source>
        <translation>Presión del Manguito Intermedia</translation>
    </message>
    <message>
        <source>Heart Rate Measurement</source>
        <translation>Medición de Frecuencia Cardíaca</translation>
    </message>
    <message>
        <source>Body Sensor Location</source>
        <translation>Ubicación del Sensor Corporal</translation>
    </message>
    <message>
        <source>Heart Rate Control Point</source>
        <translation>Punto de control de frecuencia cardíaca</translation>
    </message>
    <message>
        <source>Alert Status</source>
        <translation>Estado de Alerta</translation>
    </message>
    <message>
        <source>Ringer Control Point</source>
        <translation>Punto de Control del Timbre</translation>
    </message>
    <message>
        <source>Ringer Setting</source>
        <translation>Configuración del timbre</translation>
    </message>
    <message>
        <source>Alert Category ID Bit Mask</source>
        <translation>Máscara de bits de ID de categoría de alerta</translation>
    </message>
    <message>
        <source>Alert Category ID</source>
        <translation>ID de categoría de alerta</translation>
    </message>
    <message>
        <source>Alert Notification Control Point</source>
        <translation>Punto de Control de Notificación de Alertas</translation>
    </message>
    <message>
        <source>Unread Alert Status</source>
        <translation>Estado de Alerta No Leída</translation>
    </message>
    <message>
        <source>New Alert</source>
        <translation>Nueva Alerta</translation>
    </message>
    <message>
        <source>Supported New Alert Category</source>
        <translation>Categoría de nueva alerta soportada</translation>
    </message>
    <message>
        <source>Supported Unread Alert Category</source>
        <translation>Categoría de alerta no leída soportada</translation>
    </message>
    <message>
        <source>Blood Pressure Feature</source>
        <translation>Función de Presión Arterial</translation>
    </message>
    <message>
        <source>HID Information</source>
        <extracomment>HID: Human Interface Device Profile (Bluetooth)</extracomment>
        <translation>Información HID</translation>
    </message>
    <message>
        <source>Report Map</source>
        <translation>Mapa de informes</translation>
    </message>
    <message>
        <source>HID Control Point</source>
        <extracomment>HID: Human Interface Device Profile (Bluetooth)</extracomment>
        <translation>Punto de Control HID</translation>
    </message>
    <message>
        <source>Report</source>
        <translation>Informe</translation>
    </message>
    <message>
        <source>Protocol Mode</source>
        <translation>Modo de protocolo</translation>
    </message>
    <message>
        <source>Scan Interval Window</source>
        <translation>Intervalo de Escaneo de Ventana</translation>
    </message>
    <message>
        <source>PnP ID</source>
        <translation>ID de PnP</translation>
    </message>
    <message>
        <source>Glucose Feature</source>
        <translation>Función de Glucosa</translation>
    </message>
    <message>
        <source>Record Access Control Point</source>
        <extracomment>Glucose Sensor patient record database.</extracomment>
        <translation>Punto de Control de Acceso a Registros</translation>
    </message>
    <message>
        <source>RSC Measurement</source>
        <extracomment>RSC: Running Speed and Cadence</extracomment>
        <translation>Medición RSC</translation>
    </message>
    <message>
        <source>RSC Feature</source>
        <extracomment>RSC: Running Speed and Cadence</extracomment>
        <translation>Función RSC</translation>
    </message>
    <message>
        <source>SC Control Point</source>
        <translation>Punto de Control SC</translation>
    </message>
    <message>
        <source>CSC Measurement</source>
        <extracomment>CSC: Cycling Speed and Cadence</extracomment>
        <translation>Medición CSC</translation>
    </message>
    <message>
        <source>CSC Feature</source>
        <extracomment>CSC: Cycling Speed and Cadence</extracomment>
        <translation>Característica CSC</translation>
    </message>
    <message>
        <source>Sensor Location</source>
        <translation>Ubicación del Sensor</translation>
    </message>
    <message>
        <source>Cycling Power Measurement</source>
        <translation>Medición de potencia de ciclismo</translation>
    </message>
    <message>
        <source>Cycling Power Vector</source>
        <translation>Vector de potencia de ciclismo</translation>
    </message>
    <message>
        <source>Cycling Power Feature</source>
        <translation>Función de Potencia de Ciclismo</translation>
    </message>
    <message>
        <source>Cycling Power Control Point</source>
        <translation>Punto de Control de Potencia de Ciclismo</translation>
    </message>
    <message>
        <source>Location And Speed</source>
        <translation>Ubicación y velocidad</translation>
    </message>
    <message>
        <source>Navigation</source>
        <translation>Navegación</translation>
    </message>
    <message>
        <source>Position Quality</source>
        <translation>Calidad de Posición</translation>
    </message>
    <message>
        <source>LN Feature</source>
        <translation>Característica LN</translation>
    </message>
    <message>
        <source>LN Control Point</source>
        <translation>Punto de Control LN</translation>
    </message>
    <message>
        <source>Magnetic Declination</source>
        <extracomment>Angle between geographic and magnetic north</extracomment>
        <translation>Declinación magnética</translation>
    </message>
    <message>
        <source>Elevation</source>
        <extracomment>Above/below sea level</extracomment>
        <translation>Elevación</translation>
    </message>
    <message>
        <source>Pressure</source>
        <translation>Presión</translation>
    </message>
    <message>
        <source>Temperature</source>
        <translation>Temperatura</translation>
    </message>
    <message>
        <source>Humidity</source>
        <translation>Humedad</translation>
    </message>
    <message>
        <source>True Wind Speed</source>
        <extracomment>Wind speed while standing</extracomment>
        <translation>Velocidad del viento real</translation>
    </message>
    <message>
        <source>True Wind Direction</source>
        <translation>Dirección del viento verdadero</translation>
    </message>
    <message>
        <source>Apparent Wind Speed</source>
        <extracomment>Wind speed while observer is moving</extracomment>
        <translation>Velocidad del viento aparente</translation>
    </message>
    <message>
        <source>Apparent Wind Direction</source>
        <translation>Dirección Aparente del Viento</translation>
    </message>
    <message>
        <source>Gust Factor</source>
        <extracomment>Factor by which wind gust is stronger than average wind</extracomment>
        <translation>Factor de Ráfaga</translation>
    </message>
    <message>
        <source>Pollen Concentration</source>
        <translation>Concentración de Polen</translation>
    </message>
    <message>
        <source>UV Index</source>
        <translation>Índice UV</translation>
    </message>
    <message>
        <source>Irradiance</source>
        <translation>Irradiancia</translation>
    </message>
    <message>
        <source>Rainfall</source>
        <translation>Precipitación</translation>
    </message>
    <message>
        <source>Wind Chill</source>
        <translation>Sensación Térmica</translation>
    </message>
    <message>
        <source>Heat Index</source>
        <translation>Índice de Calor</translation>
    </message>
    <message>
        <source>Dew Point</source>
        <translation>Punto de rocío</translation>
    </message>
    <message>
        <source>Descriptor Value Changed</source>
        <extracomment>Environmental sensing related</extracomment>
        <translation>Valor del descriptor cambiado</translation>
    </message>
    <message>
        <source>Aerobic Heart Rate Lower Limit</source>
        <translation>Límite Inferior de Frecuencia Cardíaca Aeróbica</translation>
    </message>
    <message>
        <source>Aerobic Heart Rate Upper Limit</source>
        <translation>Límite Superior de Frecuencia Cardíaca Aeróbica</translation>
    </message>
    <message>
        <source>Aerobic Threshold</source>
        <translation>Umbral Aeróbico</translation>
    </message>
    <message>
        <source>Age</source>
        <extracomment>Age of person</extracomment>
        <translation>Edad</translation>
    </message>
    <message>
        <source>Anaerobic Heart Rate Lower Limit</source>
        <translation>Límite Inferior de Frecuencia Cardíaca Anaeróbica</translation>
    </message>
    <message>
        <source>Anaerobic Heart Rate Upper Limit</source>
        <translation>Límite Superior de Frecuencia Cardíaca Anaeróbica</translation>
    </message>
    <message>
        <source>Anaerobic Threshold</source>
        <translation>Umbral anaeróbico</translation>
    </message>
    <message>
        <source>Date Of Birth</source>
        <translation>Fecha de nacimiento</translation>
    </message>
    <message>
        <source>Date Of Threshold Assessment</source>
        <translation>Fecha de evaluación del umbral</translation>
    </message>
    <message>
        <source>Email Address</source>
        <translation>Dirección de Correo Electrónico</translation>
    </message>
    <message>
        <source>Fat Burn Heart Rate Lower Limit</source>
        <translation>Límite Inferior de Frecuencia Cardíaca para Quemar Grasa</translation>
    </message>
    <message>
        <source>Fat Burn Heart Rate Upper Limit</source>
        <translation>Límite Superior de Frecuencia Cardíaca para Quemar Grasa</translation>
    </message>
    <message>
        <source>First Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>5-Zone Heart Rate Limits</source>
        <translation>Límites de Frecuencia Cardíaca de 5 Zonas</translation>
    </message>
    <message>
        <source>Gender</source>
        <translation>Género</translation>
    </message>
    <message>
        <source>Heart Rate Maximum</source>
        <translation>Frecuencia cardíaca máxima</translation>
    </message>
    <message>
        <source>Height</source>
        <extracomment>Height of a person</extracomment>
        <translation>Altura</translation>
    </message>
    <message>
        <source>Hip Circumference</source>
        <translation>Circunferencia de cadera</translation>
    </message>
    <message>
        <source>Last Name</source>
        <translation>Apellido</translation>
    </message>
    <message>
        <source>Maximum Recommended Heart Rate</source>
        <translation>Frecuencia Cardíaca Máxima Recomendada</translation>
    </message>
    <message>
        <source>Resting Heart Rate</source>
        <translation>Frecuencia Cardíaca en Reposo</translation>
    </message>
    <message>
        <source>Sport Type For Aerobic/Anaerobic Thresholds</source>
        <translation>Tipo de Deporte para Umbrales Aeróbicos/Anaeróbicos</translation>
    </message>
    <message>
        <source>3-Zone Heart Rate Limits</source>
        <translation>Límites de Frecuencia Cardíaca de 3 Zonas</translation>
    </message>
    <message>
        <source>2-Zone Heart Rate Limits</source>
        <translation>Límites de Frecuencia Cardíaca de 2 Zonas</translation>
    </message>
    <message>
        <source>Oxygen Uptake</source>
        <translation>Consumo de Oxígeno</translation>
    </message>
    <message>
        <source>Waist Circumference</source>
        <translation>Circunferencia de la cintura</translation>
    </message>
    <message>
        <source>Weight</source>
        <translation>Peso</translation>
    </message>
    <message>
        <source>Database Change Increment</source>
        <extracomment>Environmental sensing related</extracomment>
        <translation>Incremento de Cambio de Base de Datos</translation>
    </message>
    <message>
        <source>User Index</source>
        <translation>Índice de Usuario</translation>
    </message>
    <message>
        <source>Body Composition Feature</source>
        <translation>Característica de composición corporal</translation>
    </message>
    <message>
        <source>Body Composition Measurement</source>
        <translation>Medición de Composición Corporal</translation>
    </message>
    <message>
        <source>Weight Measurement</source>
        <translation>Medición de Peso</translation>
    </message>
    <message>
        <source>Weight Scale Feature</source>
        <translation>Función de Báscula de Peso</translation>
    </message>
    <message>
        <source>User Control Point</source>
        <translation>Punto de Control del Usuario</translation>
    </message>
    <message>
        <source>Magnetic Flux Density 2D</source>
        <translation>Densidad de flujo magnético 2D</translation>
    </message>
    <message>
        <source>Magnetic Flux Density 3D</source>
        <translation>Densidad de flujo magnético 3D</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <source>Barometric Pressure Trend</source>
        <translation>Tendencia de presión barométrica</translation>
    </message>
    <message>
        <source>Characteristic Extended Properties</source>
        <translation>Propiedades Extendidas de la Característica</translation>
    </message>
    <message>
        <source>Characteristic User Description</source>
        <translation>Descripción de Usuario de Característica</translation>
    </message>
    <message>
        <source>Client Characteristic Configuration</source>
        <translation>Configuración de Característica del Cliente</translation>
    </message>
    <message>
        <source>Server Characteristic Configuration</source>
        <translation>Configuración de Característica del Servidor</translation>
    </message>
    <message>
        <source>Characteristic Presentation Format</source>
        <translation>Formato de Presentación de Características</translation>
    </message>
    <message>
        <source>Characteristic Aggregate Format</source>
        <translation>Formato agregado de características</translation>
    </message>
    <message>
        <source>Valid Range</source>
        <translation>Rango Válido</translation>
    </message>
    <message>
        <source>External Report Reference</source>
        <translation>Referencia de informe externo</translation>
    </message>
    <message>
        <source>Report Reference</source>
        <translation>Referencia de Informe</translation>
    </message>
    <message>
        <source>Environmental Sensing Configuration</source>
        <translation>Configuración de detección ambiental</translation>
    </message>
    <message>
        <source>Environmental Sensing Measurement</source>
        <translation>Medición de Sensores Ambientales</translation>
    </message>
    <message>
        <source>Environmental Sensing Trigger Setting</source>
        <translation>Configuración de Disparador de Sensores Ambientales</translation>
    </message>
    <message>
        <source>Unknown Service</source>
        <translation>Servicio desconocido</translation>
    </message>
</context>
<context>
    <name>QBluetoothSocket</name>
    <message>
        <source>Network Error</source>
        <translation>Error de red</translation>
    </message>
    <message>
        <source>Cannot write while not connected</source>
        <translation>No se puede escribir mientras no está conectado</translation>
    </message>
    <message>
        <source>Trying to connect while connection is in progress</source>
        <translation>Intentando conectar mientras la conexión está en progreso</translation>
    </message>
    <message>
        <source>Service cannot be found</source>
        <translation>No se puede encontrar el servicio</translation>
    </message>
    <message>
        <source>Invalid data/data size</source>
        <translation>Datos/datos de tamaño inválido</translation>
    </message>
    <message>
        <source>Cannot read while not connected</source>
        <translation>No se puede leer mientras no está conectado</translation>
    </message>
    <message>
        <source>Socket type not supported</source>
        <translation>Tipo de socket no soportado</translation>
    </message>
    <message>
        <source>Unknown socket error</source>
        <translation>Error de socket desconocido</translation>
    </message>
    <message>
        <source>Network Error: %1</source>
        <translation>Error de red: %1</translation>
    </message>
    <message>
        <source>Connecting to port is not supported</source>
        <translation type="vanished">No se admite la conexión al puerto</translation>
    </message>
    <message>
        <source>Cannot connect to %1</source>
        <comment>%1 = uuid</comment>
        <translation>No se puede conectar a %1</translation>
    </message>
    <message>
        <source>Bluetooth socket connect failed due to missing permissions.</source>
        <translation>Conexión de socket Bluetooth fallida debido a permisos faltantes.</translation>
    </message>
    <message>
        <source>Device does not support Bluetooth</source>
        <translation>El dispositivo no soporta Bluetooth</translation>
    </message>
    <message>
        <source>Device is powered off</source>
        <translation>El dispositivo está apagado</translation>
    </message>
    <message>
        <source>Cannot access address %1</source>
        <comment>%1 = Bt address e.g. 11:22:33:44:55:66</comment>
        <translation>No se puede acceder a la dirección %1</translation>
    </message>
    <message>
        <source>Cannot connect to %1 on %2</source>
        <comment>%1 = uuid, %2 = Bt address</comment>
        <translation>No se puede conectar a %1 en %2</translation>
    </message>
    <message>
        <source>Obtaining streams for service failed</source>
        <translation>Fallo al obtener flujos para el servicio</translation>
    </message>
    <message>
        <source>Input stream thread cannot be started</source>
        <translation>No se puede iniciar el hilo del flujo de entrada</translation>
    </message>
    <message>
        <source>Connection to service failed</source>
        <translation>La conexión al servicio falló</translation>
    </message>
    <message>
        <source>Error during write on socket.</source>
        <translation>Error durante la escritura en el socket.</translation>
    </message>
    <message>
        <source>Network error during read</source>
        <translation>Error de red durante la lectura</translation>
    </message>
    <message>
        <source>Cannot set connection security level</source>
        <translation>No se puede establecer el nivel de seguridad de la conexión</translation>
    </message>
    <message>
        <source>Cannot export profile on DBus</source>
        <translation>No se puede exportar el perfil en DBus</translation>
    </message>
    <message>
        <source>Cannot register profile on DBus</source>
        <translation>No se puede registrar el perfil en DBus</translation>
    </message>
    <message>
        <source>Cannot find remote device</source>
        <translation>No se puede encontrar el dispositivo remoto</translation>
    </message>
    <message>
        <source>Cannot connect to remote profile</source>
        <translation>No se puede conectar al perfil remoto</translation>
    </message>
    <message>
        <source>Missing serviceUuid or Serial Port service class uuid</source>
        <translation>Falta serviceUuid o uuid de clase de servicio de puerto serie</translation>
    </message>
    <message>
        <source>Invalid Bluetooth address passed to connectToService()</source>
        <translation>Dirección Bluetooth inválida pasada a connectToService()</translation>
    </message>
    <message>
        <source>Unsupported protocol. Win32 only supports RFCOMM sockets</source>
        <translation type="vanished">Protocolo no soportado. Win32 solo soporta sockets RFCOMM</translation>
    </message>
    <message>
        <source>Failed to create socket</source>
        <translation type="vanished">Error al crear el socket</translation>
    </message>
    <message>
        <source>Socket type not handled: %1</source>
        <translation type="vanished">Tipo de socket no manejado: %1</translation>
    </message>
    <message>
        <source>Logic error: more bytes sent than passed to ::send</source>
        <translation type="vanished">Error lógico: se enviaron más bytes de los pasados a ::send</translation>
    </message>
    <message>
        <source>Network error</source>
        <translation>Error de red</translation>
    </message>
    <message>
        <source>Remote host closed connection</source>
        <translation>El host remoto cerró la conexión</translation>
    </message>
    <message>
        <source>Connection timed out</source>
        <translation>Conexión agotada</translation>
    </message>
    <message>
        <source>Host not reachable</source>
        <translation>Host no alcanzable</translation>
    </message>
    <message>
        <source>Host refused connection</source>
        <translation>El host rechazó la conexión</translation>
    </message>
</context>
<context>
    <name>QBluetoothSocketPrivateAndroid</name>
    <message>
        <source>Connecting to port is not supported</source>
        <translation>No se admite la conexión al puerto</translation>
    </message>
</context>
<context>
    <name>QBluetoothSocketPrivateBluezDBus</name>
    <message>
        <source>Connecting to port is not supported via Bluez DBus</source>
        <translation>No se admite la conexión al puerto a través de Bluez DBus</translation>
    </message>
</context>
<context>
    <name>QBluetoothTransferReply</name>
    <message>
        <source>Invalid target address</source>
        <translation>Dirección de destino inválida</translation>
    </message>
    <message>
        <source>Push session cannot be started</source>
        <translation>No se puede iniciar la sesión de envío</translation>
    </message>
    <message>
        <source>Push session cannot connect</source>
        <translation>La sesión de notificaciones no puede conectarse</translation>
    </message>
    <message>
        <source>Source file does not exist</source>
        <translation>El archivo de origen no existe</translation>
    </message>
    <message>
        <source>QIODevice cannot be read. Make sure it is open for reading.</source>
        <translation>No se puede leer QIODevice. Asegúrese de que esté abierto para lectura.</translation>
    </message>
    <message>
        <source>Push session failed</source>
        <translation>La sesión de notificaciones falló</translation>
    </message>
    <message>
        <source>Invalid input device (null)</source>
        <translation>Dispositivo de entrada inválido (nulo)</translation>
    </message>
    <message>
        <source>Operation canceled</source>
        <translation>Operación cancelada</translation>
    </message>
    <message>
        <source>Transfer already started</source>
        <translation>La transferencia ya ha comenzado</translation>
    </message>
    <message>
        <source>Push service not found</source>
        <translation>Servicio de notificaciones no encontrado</translation>
    </message>
</context>
<context>
    <name>QBluetoothTransferReplyBluez</name>
    <message>
        <source>Unknown Error</source>
        <translation type="vanished">Error desconocido</translation>
    </message>
    <message>
        <source>Could not open file for sending</source>
        <translation type="vanished">No se pudo abrir el archivo para enviar</translation>
    </message>
    <message>
        <source>The transfer was canceled</source>
        <translation type="vanished">La transferencia fue cancelada</translation>
    </message>
    <message>
        <source>Operation canceled</source>
        <translation type="vanished">Operación cancelada</translation>
    </message>
</context>
<context>
    <name>QLowEnergyController</name>
    <message>
        <source>Remote device cannot be found</source>
        <translation>No se puede encontrar el dispositivo remoto</translation>
    </message>
    <message>
        <source>Cannot find local adapter</source>
        <translation>No se puede encontrar el adaptador local</translation>
    </message>
    <message>
        <source>Error occurred during connection I/O</source>
        <translation>Ocurrió un error durante la E/S de conexión</translation>
    </message>
    <message>
        <source>Unknown Error</source>
        <translation>Error desconocido</translation>
    </message>
    <message>
        <source>Missing permission</source>
        <translation>Permiso faltante</translation>
    </message>
    <message>
        <source>Error occurred trying to connect to remote device.</source>
        <translation>Ocurrió un error al intentar conectarse al dispositivo remoto.</translation>
    </message>
    <message>
        <source>Remote device closed the connection</source>
        <translation>El dispositivo remoto cerró la conexión</translation>
    </message>
    <message>
        <source>Failed to authorize on the remote device</source>
        <translation>Fallo al autorizar en el dispositivo remoto</translation>
    </message>
    <message>
        <source>Missing permissions error</source>
        <translation>Error de permisos faltantes</translation>
    </message>
    <message>
        <source>Error reading RSSI value</source>
        <translation>Error al leer el valor RSSI</translation>
    </message>
    <message>
        <source>Advertisement data is larger than 31 bytes</source>
        <translation>Los datos del anuncio son mayores de 31 bytes</translation>
    </message>
    <message>
        <source>Advertisement feature not supported on the platform</source>
        <translation>La función de anuncio no es compatible en la plataforma</translation>
    </message>
    <message>
        <source>Error occurred trying to start advertising</source>
        <translation>Ocurrió un error al intentar iniciar el anuncio</translation>
    </message>
    <message>
        <source>Failed due to too many advertisers</source>
        <translation>Fallo debido a demasiados anunciantes</translation>
    </message>
    <message>
        <source>Unknown advertisement error</source>
        <translation>Error de anuncio desconocido</translation>
    </message>
</context>
</TS>
