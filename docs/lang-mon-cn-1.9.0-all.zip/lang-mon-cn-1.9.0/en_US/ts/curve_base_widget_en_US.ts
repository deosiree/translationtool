<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CMyBasicPlot</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_plot.cpp" line="289"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_plot.cpp" line="300"/>
        <source>年</source>
        <translation type="unfinished">Year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_plot.cpp" line="300"/>
        <source>周</source>
        <translation type="unfinished">Week</translation>
    </message>
</context>
<context>
    <name>CMyCanvasArea</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2308"/>
        <source>保存曲线数据</source>
        <translation type="unfinished">Save curve data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2329"/>
        <source>%1-x轴(时间), </source>
        <translation type="unfinished">%1-X-axis (Time),</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2329"/>
        <source>%1-y轴(值)</source>
        <translation type="unfinished">%1-Y-axis (value)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2368"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2424"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2368"/>
        <source>曲线数据已成功导出!</source>
        <translation type="unfinished">Curve data has been successfully exported!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2373"/>
        <source>导入曲线数据</source>
        <translation type="unfinished">Import curve data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2380"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2380"/>
        <source>无法打开文件 %1</source>
        <translation type="unfinished">Unable to open file %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2424"/>
        <source>数据导入成功</source>
        <translation type="unfinished">Data import succeeded</translation>
    </message>
</context>
<context>
    <name>CMyCurveDefinition</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="142"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="143"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="169"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="173"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="815"/>
        <source>当前区间</source>
        <translation type="unfinished">Current range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="147"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="148"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="807"/>
        <source>本月</source>
        <translation type="unfinished">This month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="152"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="153"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="811"/>
        <source>本年</source>
        <translation type="unfinished">This year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="157"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="158"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="803"/>
        <source>本日</source>
        <translation type="unfinished">Today</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="188"/>
        <source>基本属性</source>
        <translation type="unfinished">Basic attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1292"/>
        <source>曲线名称：</source>
        <translation type="unfinished">Curve name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1295"/>
        <source>请输入曲线名称</source>
        <translation type="unfinished">Please enter a curve name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1314"/>
        <source>线色：</source>
        <translation type="unfinished">Line color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1298"/>
        <source>小数点精度：</source>
        <translation type="unfinished">Decimal point precision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1309"/>
        <source>线宽：</source>
        <translation type="unfinished">Line width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1324"/>
        <source>对象检索：</source>
        <translation type="unfinished">Object retrieval:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1328"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1441"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1446"/>
        <source>检索</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Retrieve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1347"/>
        <source>设置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1427"/>
        <source>配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1249"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1251"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1253"/>
        <source>上移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Move up</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1255"/>
        <source>下移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Move down</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1257"/>
        <source>复制</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Copy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="528"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="294"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="752"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="294"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="752"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="529"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="841"/>
        <source>请选择需要操作的曲线</source>
        <translation type="unfinished">Please select the curve to be operated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1330"/>
        <source>计划值曲线</source>
        <translation type="unfinished">Planned value curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1343"/>
        <source>起始时间：</source>
        <translation type="unfinished">Start time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1365"/>
        <source>数据点形状：</source>
        <translation type="unfinished">Data point shape:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1369"/>
        <source>空心圆</source>
        <translation type="unfinished">Hollow circle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1369"/>
        <source>实心圆</source>
        <translation type="unfinished">Solid circle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1369"/>
        <source>正方形</source>
        <translation type="unfinished">Square</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1369"/>
        <source>三角形</source>
        <translation type="unfinished">Triangle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="243"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1380"/>
        <source>显示数据点</source>
        <translation type="unfinished">Show data points</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1419"/>
        <source>计算曲线</source>
        <translation type="unfinished">Calculation curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1438"/>
        <source>X轴数据源:</source>
        <translation type="unfinished">X-axis data source:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1443"/>
        <source>Y轴数据源:</source>
        <translation type="unfinished">Y-axis data source:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1387"/>
        <source>单位:</source>
        <translation type="unfinished">Unit:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1389"/>
        <source>请输入单位</source>
        <translation type="unfinished">Please enter the unit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1393"/>
        <source>Y轴配置:</source>
        <translation type="unfinished">Y-axis config:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="243"/>
        <source>曲线名称</source>
        <translation type="unfinished">Curve name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="243"/>
        <source>线色</source>
        <translation type="unfinished">Line color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="243"/>
        <source>线宽</source>
        <translation type="unfinished">Line width</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="243"/>
        <source>基本点形状</source>
        <translation type="unfinished">Basic point shape</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="243"/>
        <source>对象检索</source>
        <translation type="unfinished">Retrieval Obj</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="493"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="595"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="841"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="493"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="595"/>
        <source>曲线数量超过限制</source>
        <translation type="unfinished">The number of curves exceeds the limit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="498"/>
        <source>线</source>
        <translation type="unfinished">Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="523"/>
        <source>删除</source>
        <comment>toolName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="525"/>
        <source>删除不可恢复，是否继续</source>
        <translation type="unfinished">Deletion is unrecoverable. Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="617"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="628"/>
        <source>-副本(%1)</source>
        <translation type="unfinished">-Copy (%1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="621"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="623"/>
        <source>-副本</source>
        <translation type="unfinished">-Copy</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupAttribute</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="105"/>
        <source>曲线组名称：</source>
        <translation type="unfinished">Curve group name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="107"/>
        <source>请输入</source>
        <translation type="unfinished">Please enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="117"/>
        <source>曲线组类型:</source>
        <translation type="unfinished">Curve group type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="121"/>
        <source>日曲线</source>
        <translation type="unfinished">Daily curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="121"/>
        <source>月曲线</source>
        <translation type="unfinished">Monthly Curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="121"/>
        <source>年曲线</source>
        <translation type="unfinished">Yearly Curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="121"/>
        <source>实时曲线</source>
        <translation type="unfinished">Real-time Curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="150"/>
        <source>展示形式:</source>
        <translation type="unfinished">Display format:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="154"/>
        <source>点</source>
        <translation type="unfinished">Point</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="154"/>
        <source>线</source>
        <translation type="unfinished">Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="154"/>
        <source>向下填充</source>
        <translation type="unfinished">Fill down</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="177"/>
        <source>左边距:</source>
        <translation type="unfinished">Left margin:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="180"/>
        <source>下边距:</source>
        <translation type="unfinished">Bottom margin:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="195"/>
        <source>背景颜色:</source>
        <translation type="unfinished">Background:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="202"/>
        <source>阈值颜色:</source>
        <translation type="unfinished">Threshold:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="216"/>
        <source>阈值上限:</source>
        <translation type="unfinished">Upper threshold:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="227"/>
        <source>阈值下限:</source>
        <translation type="unfinished">Lower threshold:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="247"/>
        <source>刷新周期%1</source>
        <translation type="unfinished">Refresh cycle %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="265"/>
        <source>区间配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="330"/>
        <source>标题栏</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Title Bar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="331"/>
        <source>网格</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Grid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="332"/>
        <source>图例</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Legend</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="333"/>
        <source>游标</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Cursor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="334"/>
        <source>坐标轴</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Coordinate Axis</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="339"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="467"/>
        <source>多Y轴</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Multiple y-axis</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="279"/>
        <source>背景透明</source>
        <translation type="unfinished">Background transparent</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="282"/>
        <source>平滑曲线</source>
        <translation type="unfinished">Smooth curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="285"/>
        <source>曲线详情</source>
        <translation type="unfinished">Curve details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="288"/>
        <source>显示阈值</source>
        <translation type="unfinished">Display threshold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="291"/>
        <source>漏点断开</source>
        <translation type="unfinished">Leak break</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="295"/>
        <source>绝对值曲线</source>
        <translation type="unfinished">Absolute value curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="450"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="455"/>
        <source>至</source>
        <translation type="unfinished">to</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="493"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="549"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="494"/>
        <source>切换曲线类型,需要清空曲线，是否确定?</source>
        <translation type="unfinished">Switch the curve type. You need to clear the curve. Are you sure?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="549"/>
        <source>暂不支持该类型曲线</source>
        <translation type="unfinished">This type of curve is not currently supported</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupAxis</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="99"/>
        <source>坐标轴自适应</source>
        <translation type="unfinished">Axis auto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="103"/>
        <source>多Y轴</source>
        <translation type="unfinished">Multiple y-axis</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="115"/>
        <source>是否固定轴</source>
        <translation type="unfinished">Fix axis</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="144"/>
        <source>X轴主刻度:</source>
        <translation type="unfinished">X-axis major tick:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="149"/>
        <source>Y轴主刻度:</source>
        <translation type="unfinished">Y-axis major tick:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="168"/>
        <source>X轴字体:</source>
        <translation type="unfinished">X-axis font:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="171"/>
        <source>Y轴字体:</source>
        <translation type="unfinished">Y-axis font:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="185"/>
        <source>坐标轴线宽:</source>
        <translation type="unfinished">Axis line width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="191"/>
        <source>坐标轴颜色:</source>
        <translation type="unfinished">Axis:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="206"/>
        <source>y轴最小值:</source>
        <translation type="unfinished">Y-axis minimum:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="212"/>
        <source>y轴最大值:</source>
        <translation type="unfinished">Y-axis maximum:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="231"/>
        <source>曲线轴区间:</source>
        <translation type="unfinished">Curve axis range:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="235"/>
        <source>设置实时曲线的轴范围</source>
        <translation type="unfinished">Set the axis range of the real-time curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="237"/>
        <source>显示历史</source>
        <translation type="unfinished">Display History</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupCursor</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="38"/>
        <source>显示游标</source>
        <translation type="unfinished">Show cursor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="41"/>
        <source>显示日期</source>
        <translation type="unfinished">Display date</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="44"/>
        <source>背景透明</source>
        <translation type="unfinished">Background transparent</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="63"/>
        <source>背景颜色：</source>
        <translation type="unfinished">Background:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="64"/>
        <source>字体大小：</source>
        <translation type="unfinished">Font size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="82"/>
        <source>游标线宽：</source>
        <translation type="unfinished">Cursor line width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="83"/>
        <source>游标颜色：</source>
        <translation type="unfinished">Cursor:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="96"/>
        <source>实线</source>
        <translation type="unfinished">Solid Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="96"/>
        <source>虚线</source>
        <translation type="unfinished">Dashed Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="96"/>
        <source>点线</source>
        <translation type="unfinished">Dotted Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="96"/>
        <source>点划线</source>
        <translation type="unfinished">Dot-dash Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="99"/>
        <source>游标线型：</source>
        <translation type="unfinished">Cursor line type:</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupGrid</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_grid.cpp" line="56"/>
        <source>不显示</source>
        <translation type="unfinished">Hide</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_grid.cpp" line="57"/>
        <source>多列</source>
        <translation type="unfinished">Multiple columns</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_grid.cpp" line="58"/>
        <source>少列</source>
        <translation type="unfinished">Less columns</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_grid.cpp" line="69"/>
        <source>网格线颜色:</source>
        <translation type="unfinished">Grid Line:</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupLegend</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="70"/>
        <source>隐藏图例</source>
        <translation type="unfinished">Hide legend</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="74"/>
        <source>图例间距：</source>
        <translation type="unfinished">Legend spacing:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="78"/>
        <source>图例方向：</source>
        <translation type="unfinished">Legend direction:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>上左</source>
        <translation type="unfinished">Top left</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>上中</source>
        <translation type="unfinished">Upper middle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>上右</source>
        <translation type="unfinished">Top right</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>中左</source>
        <translation type="unfinished">Center left</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>正中</source>
        <translation type="unfinished">Middle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>中右</source>
        <translation type="unfinished">Center right</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>下左</source>
        <translation type="unfinished">Bottom left</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>下中</source>
        <translation type="unfinished">Lower middle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="82"/>
        <source>下右</source>
        <translation type="unfinished">Bottom right</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="95"/>
        <source>排列方式:</source>
        <translation type="unfinished">Arrangement:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="98"/>
        <source>水平</source>
        <translation type="unfinished">Horizontal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="98"/>
        <source>垂直</source>
        <translation type="unfinished">Vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="102"/>
        <source>换行:</source>
        <translation type="unfinished">Line feed:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="106"/>
        <source>设置图例自动换行，0表示不换行</source>
        <translation type="unfinished">Set the legend to wrap automatically, 0 means no wrap</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="120"/>
        <source>图例字体:</source>
        <translation type="unfinished">Legend font:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="124"/>
        <source>图例颜色:</source>
        <translation type="unfinished">Legend:</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupTitleBar</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="39"/>
        <source>显示标题栏</source>
        <translation type="unfinished">Show title bar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="42"/>
        <source>背景透明</source>
        <translation type="unfinished">Background transparent</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="46"/>
        <source>显示按钮</source>
        <translation type="unfinished">Display button</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="56"/>
        <source>背景颜色:</source>
        <translation type="unfinished">Background:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="57"/>
        <source>字体颜色:</source>
        <translation type="unfinished">Font:</translation>
    </message>
</context>
<context>
    <name>CMyCurveNewCreate</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="56"/>
        <source>曲线组属性</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Curve Group Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="57"/>
        <source>曲线定义</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Curve Definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="60"/>
        <source>设置曲线属性</source>
        <translation type="unfinished">Set Curve Attrs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="152"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="160"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="165"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="171"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="177"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="182"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="198"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="152"/>
        <source>对象检索为空,请关联曲线数据</source>
        <translation type="unfinished">The object retrieval is empty, please link the curve data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="160"/>
        <source>曲线名称不可为空</source>
        <translation type="unfinished">The curve name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="165"/>
        <source>曲线重复</source>
        <translation type="unfinished">The curve duplicates</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="171"/>
        <source>曲线名称不可重复</source>
        <translation type="unfinished">Curve names cannot be duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="177"/>
        <source>y轴最小值大于y轴最大值</source>
        <translation type="unfinished">The minimum y-axis is greater than the maximum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="182"/>
        <source>阈值下限大于阈值上限</source>
        <translation type="unfinished">The lower threshold is greater than the upper</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="198"/>
        <source>y轴最大值需大于y轴最小值</source>
        <translation type="unfinished">Y-axis maximum must be greater than the minimum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="205"/>
        <source>曲线组名称不能为空!</source>
        <translation type="unfinished">Curve group name cannot be empty!</translation>
    </message>
</context>
<context>
    <name>CMyMultipleYAxis</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="40"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="42"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>编号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>Y轴名称</source>
        <translation type="unfinished">Y-axis name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>Y轴颜色</source>
        <translation type="unfinished">Y-axis color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>最大值</source>
        <translation type="unfinished">Maximum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>最小值</source>
        <translation type="unfinished">Mininum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>是否显示</source>
        <translation type="unfinished">Display</translation>
    </message>
</context>
<context>
    <name>CmyStatisticalTable</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>最小值</source>
        <translation type="unfinished">Mininum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>最大值</source>
        <translation type="unfinished">Maximum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>曲线名</source>
        <translation type="unfinished">Curve name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>模拟量</source>
        <translation type="unfinished">Analog</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>平均值</source>
        <translation type="unfinished">AVG</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>最大值时刻</source>
        <translation type="unfinished">Maximum value moment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>最小值时刻</source>
        <translation type="unfinished">Minimum value moment</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>起始时间</source>
        <translation type="unfinished">Start time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="284"/>
        <source>终止时间</source>
        <translation type="unfinished">End time</translation>
    </message>
</context>
<context>
    <name>ContextMenu</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="28"/>
        <source>编辑画面</source>
        <translation type="unfinished">Edit graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="32"/>
        <source>另存为</source>
        <translation type="unfinished">Save as</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="33"/>
        <source>打开</source>
        <translation type="unfinished">Open</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="38"/>
        <source>曲线详情</source>
        <translation type="unfinished">Curve details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="47"/>
        <source>平滑曲线</source>
        <translation type="unfinished">Smooth curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="56"/>
        <source>绝对值曲线</source>
        <translation type="unfinished">Absolute value curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="66"/>
        <source>开启实时刷新</source>
        <translation type="unfinished">Enable real-time refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="74"/>
        <source>导出数据</source>
        <translation type="unfinished">Export data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="75"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="76"/>
        <source>重置</source>
        <translation type="unfinished">Reset</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="78"/>
        <source>查询</source>
        <translation type="unfinished">Query</translation>
    </message>
</context>
<context>
    <name>DlgIntervalTime</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="37"/>
        <source>设置日期</source>
        <comment>toolName</comment>
        <translation type="unfinished">Set Date</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="65"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="78"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="65"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="78"/>
        <source>日期选择错误，请重新选择</source>
        <translation type="unfinished">Date selection error, please select again</translation>
    </message>
</context>
<context>
    <name>DlgQuery</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_query.cpp" line="23"/>
        <source>查询</source>
        <comment>toolName</comment>
        <translation type="unfinished">Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_query.cpp" line="47"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_query.cpp" line="48"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Query</translation>
    </message>
</context>
<context>
    <name>DlgRelativeTime</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="69"/>
        <source>本日</source>
        <translation type="unfinished">Today</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="70"/>
        <source>昨日</source>
        <translation type="unfinished">Yesterday</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="71"/>
        <source>明日</source>
        <translation type="unfinished">Tomorrow</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="72"/>
        <source>上周今日</source>
        <translation type="unfinished">This day last week</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="73"/>
        <source>上月今日</source>
        <translation type="unfinished">This day last month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="74"/>
        <source>去年今日</source>
        <translation type="unfinished">This day last year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="80"/>
        <source>本月</source>
        <translation type="unfinished">This month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="81"/>
        <source>上月</source>
        <translation type="unfinished">Last month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="82"/>
        <source>下月</source>
        <translation type="unfinished">Next month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="83"/>
        <source>去年该月</source>
        <translation type="unfinished">Last year, this month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="86"/>
        <source>月前</source>
        <translation type="unfinished">months ago</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="91"/>
        <source>本年</source>
        <translation type="unfinished">This year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="92"/>
        <source>去年</source>
        <translation type="unfinished">Last year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="93"/>
        <source>下年</source>
        <translation type="unfinished">Next year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="94"/>
        <source>去年该年</source>
        <translation type="unfinished">Last year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="98"/>
        <source>年前</source>
        <translation type="unfinished">years ago</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="68"/>
        <source>日曲线时间配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Daily Curve Time Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="79"/>
        <source>月曲线时间配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Monthly Curve Time Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="90"/>
        <source>年曲线时间配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Yearly Curve Time Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="102"/>
        <source>区间曲线时间配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Interval Curve Time Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="103"/>
        <source>当前区间</source>
        <translation type="unfinished">Current range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="104"/>
        <source>昨天该区间</source>
        <translation type="unfinished">Yesterday, this range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="105"/>
        <source>明天该区间</source>
        <translation type="unfinished">Tomorrow interval</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="106"/>
        <source>上周该区间</source>
        <translation type="unfinished">Last week, this range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="107"/>
        <source>上月该区间</source>
        <translation type="unfinished">Last month, this range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="108"/>
        <source>去年该区间</source>
        <translation type="unfinished">Last year, this range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="128"/>
        <source>请输入数字（范围1～365）</source>
        <translation type="unfinished">Please enter a number (range 1~365)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="149"/>
        <source>请输入数字（范围1～99）</source>
        <translation type="unfinished">Please enter a number (range 1~99)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="170"/>
        <source>请输入数字（范围1～9）</source>
        <translation type="unfinished">Please enter a number (range 1~9)</translation>
    </message>
</context>
<context>
    <name>PrinterHandle</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/printer_handle.cpp" line="73"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/printer_handle.cpp" line="77"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/printer_handle.cpp" line="73"/>
        <source>曲线打印失败</source>
        <translation type="unfinished">Curve printing failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/printer_handle.cpp" line="77"/>
        <source>曲线打印成功</source>
        <translation type="unfinished">Curve printing successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/printer_handle.cpp" line="83"/>
        <source>打印错误</source>
        <translation type="unfinished">Print error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/printer_handle.cpp" line="83"/>
        <source>无法找到打印机</source>
        <translation type="unfinished">Unable to find printer</translation>
    </message>
</context>
<context>
    <name>XMLFileHandle</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="22"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="22"/>
        <source>文件打开或创建失败</source>
        <translation type="unfinished">File open or create failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="25"/>
        <source>文件保存中</source>
        <translation type="unfinished">File saving</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="96"/>
        <source>通知</source>
        <translation type="unfinished">Notification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="96"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="665"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="670"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="676"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="684"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="708"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="665"/>
        <source>文件不存在</source>
        <translation type="unfinished">File not found</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="670"/>
        <source>文件打开失败</source>
        <translation type="unfinished">File open failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="676"/>
        <source>操作的文件不是XML格式</source>
        <translation type="unfinished">The file for the operation is not in XML format</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="684"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="708"/>
        <source>曲线文件格式无效</source>
        <translation type="unfinished">Invalid curve file format</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="713"/>
        <source>曲线文件读取中</source>
        <translation type="unfinished">Curve file reading</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="713"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>dlg_interval_time</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.ui" line="22"/>
        <source>开始时间：</source>
        <translation type="unfinished">Start time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.ui" line="36"/>
        <source>结束时间：</source>
        <translation type="unfinished">End time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.ui" line="63"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.ui" line="70"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>dlg_relative_time</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="22"/>
        <source>今天</source>
        <translation type="unfinished">Today</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="29"/>
        <source>昨天</source>
        <translation type="unfinished">Yesterday</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="36"/>
        <source>明天</source>
        <translation type="unfinished">tomorrow</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="47"/>
        <source>上周今天</source>
        <translation type="unfinished">Last week, today</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="54"/>
        <source>上月今天</source>
        <translation type="unfinished">Toady of last month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="61"/>
        <source>去年今天</source>
        <translation type="unfinished">Toady of last year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="72"/>
        <source>自定义</source>
        <translation type="unfinished">Custom</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="82"/>
        <source>天前</source>
        <translation type="unfinished">days ago</translation>
    </message>
</context>
</TS>
