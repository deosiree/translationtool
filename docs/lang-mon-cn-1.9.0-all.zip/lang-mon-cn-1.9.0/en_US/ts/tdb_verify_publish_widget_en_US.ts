<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>PublisRecordsDialog</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="12"/>
        <source>装库记录查询</source>
        <translation type="unfinished">Load Record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="108"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="108"/>
        <source>开始时间不能晚于结束时间</source>
        <translation type="unfinished">The start time cannot be later than the end time</translation>
    </message>
</context>
<context>
    <name>PublishWorker</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="96"/>
        <source>步骤一：发送装库准备报文失败</source>
        <translation type="unfinished">Step 1: Failed to send Load DB Preparation message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="114"/>
        <source>步骤一：发送装库准备报文成功</source>
        <translation type="unfinished">Step 1: Send Load DB Preparation message successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="126"/>
        <source>准备失败</source>
        <translation type="unfinished">Preparation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="140"/>
        <source>准备中止！</source>
        <translation type="unfinished">Prepare abort!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="179"/>
        <source>查询发布报文订阅者失败</source>
        <translation type="unfinished">Failed to query the subscribers of published messages</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="205"/>
        <source>步骤二：发送装库执行报文失败</source>
        <translation type="unfinished">Step 2: Send Load DB Execution message failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="223"/>
        <source>步骤二：发送装库执行报文成功</source>
        <translation type="unfinished">Step 2: Send Load DB Execution message successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="238"/>
        <source>装库失败</source>
        <translation type="unfinished">Failed to Load DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="282"/>
        <source>发送装库取消报文失败</source>
        <translation type="unfinished">Failed to send Load DB Cancellation message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="298"/>
        <source>发送装库取消报文成功</source>
        <translation type="unfinished">Send Load DB Cancellation message successfully.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="439"/>
        <source>装库超时</source>
        <translation type="unfinished">Load DB Timeout</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="33"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="109"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="144"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="152"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="159"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="194"/>
        <source>查询</source>
        <translation type="unfinished">Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="60"/>
        <source>开始时间：</source>
        <translation type="unfinished">Start time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="62"/>
        <source>结束时间：</source>
        <translation type="unfinished">End time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="88"/>
        <source>正在查询</source>
        <translation type="unfinished">Is querying</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="143"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="151"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="143"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2941"/>
        <source>时序库连接失败</source>
        <translation type="unfinished">Failed to connect STDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="151"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2966"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2977"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2988"/>
        <source>查询失败</source>
        <translation type="unfinished">Query failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="158"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publish_records_dlg.cpp" line="158"/>
        <source>查询结果为空</source>
        <translation type="unfinished">The query result is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="94"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="112"/>
        <source>发送装库准备</source>
        <translation type="unfinished">Send Load DB Preparation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="126"/>
        <source>准备失败</source>
        <translation type="unfinished">Preparation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="140"/>
        <source>装库取消</source>
        <translation type="unfinished">Load DB Cancellation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="179"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="203"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="221"/>
        <source>发送装库执行</source>
        <translation type="unfinished">Send load DB execution</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="238"/>
        <source>装库失败</source>
        <translation type="unfinished">Failed to Load DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="280"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="298"/>
        <source>发送装库取消</source>
        <translation type="unfinished">Send Load DB Cancellation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/publishworker.cpp" line="393"/>
        <source>{}节点{}进程超时</source>
        <translation type="unfinished">{} node {} process timed out</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="334"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1071"/>
        <source>应用：</source>
        <translation type="unfinished">App:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1493"/>
        <source>输出</source>
        <translation type="unfinished">Output</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1494"/>
        <source>验证异常信息</source>
        <translation type="unfinished">Exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1495"/>
        <source>校验异常信息</source>
        <translation type="unfinished">Abnormal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1993"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/verifyworker.cpp" line="119"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1995"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/verifyworker.cpp" line="121"/>
        <source>失败</source>
        <translation type="unfinished">Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1999"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/verifyworker.cpp" line="125"/>
        <source>中间过程</source>
        <translation type="unfinished">Intermediate process</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2007"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/verifyworker.cpp" line="133"/>
        <source>未知</source>
        <translation type="unfinished">Unknown</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2016"/>
        <source>装库验证返回</source>
        <translation type="unfinished">Return of Load DB Validation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2020"/>
        <source>装库准备返回</source>
        <translation type="unfinished">Return of Load DB Preparation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2031"/>
        <source>%1 %2 超时节点：%3 超时进程：%4 状态：%5 消息：%6</source>
        <translation type="unfinished">%1 %2 Timeout Node: %3 Timeout process: %4 Status: %5 Message: %6</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2043"/>
        <source>装库执行返回</source>
        <translation type="unfinished">Return of Load DB Execution</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2048"/>
        <source>%1 %2 状态：%3 消息：%4</source>
        <translation type="unfinished">%1 %2 Status: %3 Message: %4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2056"/>
        <source>%1 %2 节点：%3 进程：%4 状态：%5 消息：%6</source>
        <translation type="unfinished">%1 %2 Node: %3 Process: %4 Status: %5 Message: %6</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2255"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="3063"/>
        <source>   执行状态   </source>
        <translation type="unfinished">Execution status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2368"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2442"/>
        <source>   装库取消   </source>
        <translation type="unfinished">Load DB Cancellation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2609"/>
        <source>申请锁超时失败</source>
        <translation type="unfinished">Request lock timeout</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2885"/>
        <source>文件:</source>
        <translation type="unfinished">File:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2893"/>
        <source>无校验错误</source>
        <translation type="unfinished">No verification error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2992"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="3031"/>
        <source>近一年无装库成功记录</source>
        <translation type="unfinished">No record of successful Load DB in the last year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/verifyworker.cpp" line="135"/>
        <source>{} {} 状态：{} 消息：{}</source>
        <translation type="unfinished">{} {} Status: {} Message: {}</translation>
    </message>
</context>
<context>
    <name>TdbVerifyPublishWidget</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget.ui" line="42"/>
        <source>   任务列表   </source>
        <translation type="unfinished">   Task list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget.ui" line="73"/>
        <source>上次装库成功时间：</source>
        <translation type="unfinished">Last time of Load DB succeed:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget.ui" line="124"/>
        <source>装库记录查询</source>
        <translation type="unfinished">Load Record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget.ui" line="157"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget.ui" line="190"/>
        <source>验证</source>
        <translation type="unfinished">Verify</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget.ui" line="222"/>
        <source>验证装库</source>
        <translation type="unfinished">Verify load</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget.ui" line="256"/>
        <source>   执行状态   </source>
        <translation type="unfinished">Execution status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget.ui" line="293"/>
        <source>详情</source>
        <translation type="unfinished">Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget.ui" line="309"/>
        <source>Tab 1</source>
        <translation type="unfinished">Tab 1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget.ui" line="314"/>
        <source>Tab 2</source>
        <translation type="unfinished">Tab 2</translation>
    </message>
</context>
<context>
    <name>VerifyWorker</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/verifyworker.cpp" line="77"/>
        <source>%1 发送开始验证 状态：失败 消息：步骤一：发送开始验证请求报文失败</source>
        <translation type="unfinished">%1 Send start verification, Status: Failed, Message: Step 1: Failed to send start verification request message</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/verifyworker.cpp" line="96"/>
        <source>%1 发送开始验证 状态：成功 消息：步骤一：发送开始验证请求报文成功</source>
        <translation type="unfinished">%1 Send start verification, Status: Success, Message: Step 1: Send start verification request message successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/verifyworker.cpp" line="135"/>
        <source>验证报文返回</source>
        <translation type="unfinished">Verification message returned</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/verifyworker.cpp" line="206"/>
        <source>验证超时</source>
        <translation type="unfinished">Validation timeout</translation>
    </message>
</context>
<context>
    <name>iasp::dbms::AppsDlg</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="14"/>
        <source>添加串行应用</source>
        <translation type="unfinished">Add serial app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="18"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="106"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="19"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="33"/>
        <source>任务名称</source>
        <translation type="unfinished">Task name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="38"/>
        <source>任务次序</source>
        <translation type="unfinished">Task order</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="61"/>
        <source>新增应用</source>
        <translation type="unfinished">Add app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="96"/>
        <source>添加应用</source>
        <translation type="unfinished">Add app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="102"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="133"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="185"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="191"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="199"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="209"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="220"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="228"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="102"/>
        <source>没有存在可用维护库的应用</source>
        <translation type="unfinished">No apps with available MTDB.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="133"/>
        <source>应用已存在</source>
        <translation type="unfinished">Application already exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="144"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="185"/>
        <source>请输入任务名称</source>
        <translation type="unfinished">Please enter a task name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="191"/>
        <source>请输入任务次序</source>
        <translation type="unfinished">Please enter the task order</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="199"/>
        <source>任务次序必须为整数</source>
        <translation type="unfinished">Task order must be an integer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="209"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="220"/>
        <source>任务名称已存在</source>
        <translation type="unfinished">Task name already exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/add_task_dlg.cpp" line="228"/>
        <source>请添加至少一个应用</source>
        <translation type="unfinished">Please add at least one application</translation>
    </message>
</context>
<context>
    <name>iasp::dbms::TdbVerifyPublishWidgetImpl</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="99"/>
        <source>   执行状态   </source>
        <translation type="unfinished">Execution status</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="142"/>
        <source>应用名: </source>
        <translation type="unfinished">App name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="146"/>
        <source>未记录应用名</source>
        <translation type="unfinished">App name not recorded</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="150"/>
        <source>库名: </source>
        <translation type="unfinished">DB name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="154"/>
        <source>表名: </source>
        <translation type="unfinished">Table name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="158"/>
        <source>域名: </source>
        <translation type="unfinished">Field name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="162"/>
        <source>域别名: </source>
        <translation type="unfinished">Field alias:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="166"/>
        <source>对象OID: </source>
        <translation type="unfinished">Object OID:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="170"/>
        <source>对象别名: </source>
        <translation type="unfinished">Object alias:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="174"/>
        <source>对象路径: </source>
        <translation type="unfinished">Object path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="178"/>
        <source>错误类型: ERR</source>
        <translation type="unfinished">Error type: ERR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="182"/>
        <source>错误类型: WARN</source>
        <translation type="unfinished">Error type: WARN</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="186"/>
        <source>错误内容: </source>
        <translation type="unfinished">Error content:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="223"/>
        <source>解除占用失败</source>
        <translation type="unfinished">Unlock failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="227"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="467"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="480"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="516"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="694"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1170"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1183"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1223"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1252"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1271"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1338"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1353"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1418"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2334"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2408"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="277"/>
        <source>   验证成功   </source>
        <translation type="unfinished">Verificated successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="288"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="308"/>
        <source>验证完成</source>
        <translation type="unfinished">Verification completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="288"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1806"/>
        <source>验证成功</source>
        <translation type="unfinished">Validated successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="297"/>
        <source>   验证失败   </source>
        <translation type="unfinished">Verification failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="316"/>
        <source>   装库成功   </source>
        <translation type="unfinished">Load DB succeed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="353"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="369"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="385"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="402"/>
        <source>装库完成</source>
        <translation type="unfinished">Load DB completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="353"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1856"/>
        <source>装库成功</source>
        <translation type="unfinished">Load DB succeed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="358"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="374"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="390"/>
        <source>   装库失败   </source>
        <translation type="unfinished">Load DB Failure</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="464"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="467"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1167"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1170"/>
        <source>权限校验参数未设置</source>
        <translation type="unfinished">Permission verification params are not set</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="477"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="480"/>
        <source>%1用户没有验证权限</source>
        <translation type="unfinished">%1 does not have authentication permission</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="491"/>
        <source>   正在验证   </source>
        <translation type="unfinished">Verifying</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="691"/>
        <source>装库失败 多线程指针为空</source>
        <translation type="unfinished">DB loading failed. Multithreading pointer is empty.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="694"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="771"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1861"/>
        <source>装库失败</source>
        <translation type="unfinished">Failed to Load DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="856"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1837"/>
        <source>准备失败</source>
        <translation type="unfinished">Preparation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1180"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1183"/>
        <source>%1用户没有装库权限</source>
        <translation type="unfinished">%1 does not have Load DB Permission</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1199"/>
        <source>   正在装库   </source>
        <translation type="unfinished">Executing Load DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1249"/>
        <source>请勾选至少一个任务</source>
        <translation type="unfinished">Please check at least one task</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1252"/>
        <source>请勾选至少一个勾选应用的任务</source>
        <translation type="unfinished">Please check at least one task</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1267"/>
        <source>存在多个 %1</source>
        <translation type="unfinished">Multiple %1.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1333"/>
        <source>未部署维护库</source>
        <translation type="unfinished">MTDB not deployed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1349"/>
        <source>任务名重复</source>
        <translation type="unfinished">Duplicate task name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1413"/>
        <source>维护服务不存活</source>
        <translation type="unfinished">Maintenance service is not available</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1698"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1812"/>
        <source>验证失败</source>
        <translation type="unfinished">Verification failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1739"/>
        <source>正在验证</source>
        <translation type="unfinished">Verifying</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1832"/>
        <source>准备成功</source>
        <translation type="unfinished">Prepare successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="1878"/>
        <source>开始装库</source>
        <translation type="unfinished">Start loading DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2156"/>
        <source>装库准备</source>
        <translation type="unfinished">Load DB Preparation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2267"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="3074"/>
        <source>未验证   </source>
        <translation type="unfinished">Unverified</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2319"/>
        <source>解锁失败</source>
        <translation type="unfinished">Unlock failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2333"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2407"/>
        <source>正在取消，请稍候...</source>
        <translation type="unfinished">Cancelling, please wait...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2333"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2403"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2407"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2380"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2454"/>
        <source>取消成功</source>
        <translation type="unfinished">Cancel successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2380"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2454"/>
        <source>取消失败</source>
        <translation type="unfinished">Cancel failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2381"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2455"/>
        <source>装库取消</source>
        <translation type="unfinished">Load DB Cancellation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2403"/>
        <source>是否取消装库</source>
        <translation type="unfinished">Whether to cancel Load DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2703"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2708"/>
        <source>从维护节点获取%1验证错误文件失败</source>
        <translation type="unfinished">Failed to retrieve %1 verification error file from maintenance node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/tdb_verify_publish_widget_impl.cpp" line="2707"/>
        <source>获取验证错误文件失败</source>
        <translation type="unfinished">Failed to retrieve verification error file</translation>
    </message>
</context>
<context>
    <name>iasp::dbms::VerifyTaskTableWidget</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="36"/>
        <source>选择</source>
        <translation type="unfinished">Select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="36"/>
        <source>任务次序</source>
        <translation type="unfinished">Task order</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="36"/>
        <source>任务名称</source>
        <translation type="unfinished">Task name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="36"/>
        <source>应用名称</source>
        <translation type="unfinished">App name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="37"/>
        <source>执行状态及进度</source>
        <translation type="unfinished">Execution status and progress</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="162"/>
        <source>未验证</source>
        <translation type="unfinished">Unverified</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="214"/>
        <source>打开配置</source>
        <translation type="unfinished">Open config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="217"/>
        <source>新增任务</source>
        <translation type="unfinished">Add task</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="228"/>
        <source>编辑任务</source>
        <translation type="unfinished">Edit task</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="231"/>
        <source>删除任务</source>
        <translation type="unfinished">Delete task</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="234"/>
        <source>保存配置</source>
        <translation type="unfinished">Save config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="237"/>
        <source>全选/全取消</source>
        <translation type="unfinished">Select all/Cancel all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="255"/>
        <source>打印测试</source>
        <translation type="unfinished">Print test</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="321"/>
        <source>保存配置文件</source>
        <translation type="unfinished">Save config file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="322"/>
        <source>请输入文件名（将保存到 %1）：</source>
        <translation type="unfinished">Please enter a file name (will save to %1):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="352"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="360"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="392"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="452"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="462"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="485"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="352"/>
        <source>配置文件保存成功，但上传文件管理失败</source>
        <translation type="unfinished">The config file was saved successfully, but failed to upload to the file management</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="356"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="458"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="504"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="544"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="553"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="356"/>
        <source>保存并上传配置文件成功</source>
        <translation type="unfinished">The config file was saved and uploaded successfully.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="360"/>
        <source>保存配置文件失败</source>
        <translation type="unfinished">Failed to save config file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="370"/>
        <source>打开配置文件</source>
        <translation type="unfinished">Open config file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="372"/>
        <source>JSON files (*.json)</source>
        <translation type="unfinished">JSON files (*.json)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="392"/>
        <source>读取配置文件失败</source>
        <translation type="unfinished">Failed to read config file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="452"/>
        <source>配置文件格式错误</source>
        <translation type="unfinished">Config file format error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="458"/>
        <source>读取配置文件成功</source>
        <translation type="unfinished">Read the config file successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="462"/>
        <source>打开配置文件失败</source>
        <translation type="unfinished">Failure to open config file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="485"/>
        <source>删除后无法恢复，是否继续？</source>
        <translation type="unfinished">Deletion cannot be recovered. Whether to continue?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="504"/>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="544"/>
        <source>没有勾选任何任务</source>
        <translation type="unfinished">No tasks are checked</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/tdb_verify_publish_widget/src/VerifyTaskTableWidget.cpp" line="553"/>
        <source>只能勾选一个任务进行编辑</source>
        <translation type="unfinished">Only one task can be checked for editing</translation>
    </message>
</context>
</TS>
