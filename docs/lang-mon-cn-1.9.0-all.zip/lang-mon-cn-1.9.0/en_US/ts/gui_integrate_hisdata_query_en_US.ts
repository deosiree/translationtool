<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>HisdataQueryTool</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="77"/>
        <source>查询条件</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Query condition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="124"/>
        <source>当前应用：</source>
        <translation type="unfinished">Current app:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="150"/>
        <source>历史存储表：</source>
        <translation type="unfinished">Table:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="176"/>
        <source>查询时段：</source>
        <translation type="unfinished">Query period:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="286"/>
        <source>条件字符：</source>
        <translation type="unfinished">Cond Chars:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="310"/>
        <source>请输入查询条件...</source>
        <translation type="unfinished">Please enter query condition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="323"/>
        <source>查询对象：</source>
        <translation type="unfinished">Query object:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="399"/>
        <source>选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="426"/>
        <source>清除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="460"/>
        <source>查看SQL</source>
        <comment>buttonName</comment>
        <translation type="unfinished">View sql</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="488"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="516"/>
        <source>查询结果</source>
        <translation type="unfinished">Query results</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.ui" line="672"/>
        <source>/1</source>
        <translation type="unfinished">/1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/include/copy_sql_dlg.h" line="18"/>
        <source>sql语句</source>
        <translation type="unfinished">SQL statement</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/include/copy_sql_dlg.h" line="25"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/include/copy_sql_dlg.h" line="29"/>
        <source>复制</source>
        <translation type="unfinished">Copy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="131"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="160"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="164"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="170"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="179"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="193"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="201"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="228"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="234"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="250"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="307"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="322"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="353"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="356"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="400"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="404"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="436"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="502"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="605"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="620"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="699"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="717"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="729"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="745"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="764"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="768"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="786"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="813"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="950"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="131"/>
        <source>历史数据访问对象创建失败</source>
        <translation type="unfinished">Historical data access object creation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="160"/>
        <source>请选择应用</source>
        <translation type="unfinished">Please select an app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="164"/>
        <source>请选择表</source>
        <translation type="unfinished">Please select a table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="170"/>
        <source>开始时间不能晚于结束时间</source>
        <translation type="unfinished">The start time cannot be later than the end time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="179"/>
        <source>采样表查询时间范围不能超过1年</source>
        <translation type="unfinished">The query time range for the sampling table cannot exceed 1 year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="193"/>
        <source>查询结果模型创建失败</source>
        <translation type="unfinished">Query result model creation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="200"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="785"/>
        <source>正在查询，请稍候...</source>
        <translation type="unfinished">Querying, please wait...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="200"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="785"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="228"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="813"/>
        <source>查询失败</source>
        <translation type="unfinished">Query failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="234"/>
        <source>查询结果为空</source>
        <translation type="unfinished">The query result is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="250"/>
        <source>查询成功，共%1条数据</source>
        <translation type="unfinished">Query successful, total %1 items</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="307"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="404"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="717"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="768"/>
        <source>请选择历史存储表</source>
        <translation type="unfinished">Please select the history storage table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="322"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="502"/>
        <source>切换的应用名称不符合规则</source>
        <translation type="unfinished">The name of the switched application does not conform to the rules</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="353"/>
        <source>未选择查询对象</source>
        <translation type="unfinished">No query object selected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="356"/>
        <source>只能选择最多10个查询对象</source>
        <translation type="unfinished">You can only select up to 10 query objects</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="400"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="764"/>
        <source>开始时间不能大于结束时间</source>
        <translation type="unfinished">The start time cannot be greater than the end time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="436"/>
        <source>sql语句生成失败</source>
        <translation type="unfinished">Failed to gen sql statement</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="605"/>
        <source>获取历史数据库连接失败</source>
        <translation type="unfinished">Failed to retrieve HDB connection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="620"/>
        <source>获取历史数据库表信息失败</source>
        <translation type="unfinished">Failed to retrieve HDB table info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="699"/>
        <source>已经是第一页</source>
        <translation type="unfinished">Already the first page</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="729"/>
        <source>已经是最后一页</source>
        <translation type="unfinished">Already the last page</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="745"/>
        <source>页数不合法</source>
        <translation type="unfinished">Invalid number of pages</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="934"/>
        <source>实例%1</source>
        <translation type="unfinished">Instance %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/hisdataquerytool.cpp" line="949"/>
        <source>检测到装库事件(%1)，稍后手动刷新</source>
        <translation type="unfinished">Detected loading db event (%1), manually refresh later</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_query_tool/src/query_result_model.cpp" line="104"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
</context>
</TS>
