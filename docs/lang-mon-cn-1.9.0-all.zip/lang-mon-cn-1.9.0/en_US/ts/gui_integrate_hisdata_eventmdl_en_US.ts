<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>EventModelMain</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.ui" line="35"/>
        <source>当前应用</source>
        <translation type="unfinished">Current app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.ui" line="48"/>
        <source>事件存储表</source>
        <translation type="unfinished">Event storage table</translation>
    </message>
</context>
<context>
    <name>HisEventTableEditor</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_editor.ui" line="26"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_editor.ui" line="40"/>
        <source>别名</source>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_editor.ui" line="54"/>
        <source>是否起效</source>
        <translation type="unfinished">Effective</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_editor.ui" line="62"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_editor.ui" line="67"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_editor.ui" line="79"/>
        <source>时间单位</source>
        <translation type="unfinished">Time unit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_editor.ui" line="121"/>
        <source>重置</source>
        <translation type="unfinished">Reset</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_editor.ui" line="128"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="554"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="584"/>
        <source>打开 %1 库失败</source>
        <translation type="unfinished">Failed to open DB %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="555"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="585"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_coloumn_model.cpp" line="122"/>
        <source>获取枚举失败</source>
        <translation type="unfinished">Failed to retrieve enumeration</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::EventModelMain</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="130"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="548"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="578"/>
        <source>事件存储表</source>
        <translation type="unfinished">Event storage table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="155"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="190"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="249"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="253"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="418"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="529"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="155"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="190"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="418"/>
        <source>查询的应用不符合格式要求</source>
        <translation type="unfinished">The application you are looking for does not meet the required format</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="249"/>
        <source>更新记录成功</source>
        <translation type="unfinished">Update record successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="253"/>
        <source>更新记录失败</source>
        <translation type="unfinished">Failed to update record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/event_model_main.cpp" line="529"/>
        <source>切换的应用名称不符合规则</source>
        <translation type="unfinished">The name of the switched application does not conform to the rules</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::HisEventColoumnModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_coloumn_model.cpp" line="133"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_coloumn_model.cpp" line="151"/>
        <source>未配置</source>
        <translation type="unfinished">No Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_coloumn_model.cpp" line="140"/>
        <source>获取枚举失败</source>
        <translation type="unfinished">Failed to retrieve enumeration</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_coloumn_model.cpp" line="351"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_coloumn_model.cpp" line="383"/>
        <source>唯一标识</source>
        <translation type="unfinished">OnlyNo</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::HisEventTableModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="130"/>
        <source>不清理</source>
        <translation type="unfinished">Not cleaning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="134"/>
        <source>历史库磁盘清理</source>
        <translation type="unfinished">HDB disk cleanup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="150"/>
        <source>年</source>
        <translation type="unfinished">year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="156"/>
        <source>月</source>
        <translation type="unfinished">month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="162"/>
        <source>天</source>
        <translation type="unfinished">Day</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="168"/>
        <source>小时</source>
        <translation type="unfinished">Hour</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="173"/>
        <source>秒</source>
        <translation type="unfinished">sec</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="421"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/his_event_table_model.cpp" line="454"/>
        <source>唯一标识</source>
        <translation type="unfinished">OnlyNo</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::TableColoumnModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="47"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="49"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="51"/>
        <source>描述</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="53"/>
        <source>主键列</source>
        <translation type="unfinished">Primary key column</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="55"/>
        <source>是否存历史</source>
        <translation type="unfinished">Save history</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="87"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="95"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="89"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_eventmdlcfg/src/table_coloumn_model.cpp" line="99"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
</context>
</TS>
