<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>HisObjectMain</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.ui" line="56"/>
        <source>当前应用</source>
        <translation type="unfinished">Aplicación actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.ui" line="91"/>
        <source>对象表</source>
        <translation type="unfinished">Tabla de objetos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.ui" line="140"/>
        <source>导入所有点</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.ui" line="147"/>
        <source>检索器挑点</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Recuperador de puntos de consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.ui" line="154"/>
        <source>修改参数</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Editar parámetros</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.ui" line="161"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.ui" line="168"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
</context>
<context>
    <name>HisSampleObjectEditor</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_object_editor.ui" line="32"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/ui_his_sample_object_editor.h" line="141"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_object_editor.ui" line="49"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/ui_his_sample_object_editor.h" line="142"/>
        <source>存储周期（分钟）</source>
        <translation type="unfinished">Ciclo de almacenamiento (min)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_object_editor.ui" line="60"/>
        <source>是否起效</source>
        <translation type="unfinished">Eficaz</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_object_editor.ui" line="68"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_object_editor.ui" line="73"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/ui_his_sample_object_editor.h" line="144"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/ui_his_sample_object_editor.h" line="145"/>
        <source>是</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_object_editor.ui" line="113"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/ui_his_sample_object_editor.h" line="147"/>
        <source>重置</source>
        <translation type="unfinished">Restablecer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_object_editor.ui" line="120"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/ui_his_sample_object_editor.h" line="148"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/ui_his_sample_object_editor.h" line="140"/>
        <source>HisSampleObjectEditor</source>
        <translation type="unfinished">HisSampleObjectEditor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/ui_his_sample_object_editor.h" line="143"/>
        <source>是否验证</source>
        <translation type="unfinished">Verificar</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1095"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1128"/>
        <source>打开 %1 库失败</source>
        <translation type="unfinished">No se pudo abrir la biblioteca %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1099"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1131"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1830"/>
        <source>获取历史应用失败</source>
        <translation type="unfinished">Fallo al obtener la aplicación histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1836"/>
        <source>历史应用为空</source>
        <translation type="unfinished">La aplicación histórica está vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1896"/>
        <source>%1-%2 节点运行库不正常</source>
        <translation type="unfinished">%1-%2 Nodo RTDB es anormal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1924"/>
        <source>%1 维护库不正常</source>
        <translation type="unfinished">%1 MTDB es anormal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1932"/>
        <source>没有部署历史应用</source>
        <translation type="unfinished">No hay aplicaciones históricas desplegadas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1942"/>
        <source>历史参数库不正常</source>
        <translation type="unfinished">La base de datos de parámetros históricos está anómala</translation>
    </message>
</context>
<context>
    <name>batch_cfg_dialog</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/batch_cfg_dialog.ui" line="14"/>
        <source>批量设置</source>
        <translation type="unfinished">Configuración por lotes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/batch_cfg_dialog.ui" line="24"/>
        <source>是否统计</source>
        <translation type="unfinished">Estadística habilitada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/batch_cfg_dialog.ui" line="31"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/batch_cfg_dialog.ui" line="38"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/batch_cfg_dialog.ui" line="49"/>
        <source>采样周期</source>
        <translation type="unfinished">Ciclo de muestreo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/batch_cfg_dialog.cpp" line="19"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/batch_cfg_dialog.cpp" line="20"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/batch_cfg_dialog.cpp" line="25"/>
        <source>秒</source>
        <translation type="unfinished">seg</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/batch_cfg_dialog.cpp" line="26"/>
        <source>分钟</source>
        <translation type="unfinished">min</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/batch_cfg_dialog.cpp" line="27"/>
        <source>小时</source>
        <translation type="unfinished">h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/batch_cfg_dialog.cpp" line="146"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/batch_cfg_dialog.cpp" line="146"/>
        <source>秒级采样采样周期需要小于60秒</source>
        <translation type="unfinished">El intervalo de muestreo para el muestreo de segundo nivel debe ser inferior a 60 segundos</translation>
    </message>
</context>
<context>
    <name>dbsearch_cfg_dialog</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/dbsearch_cfg_dialog.ui" line="14"/>
        <source>检索器挑点配置</source>
        <translation type="unfinished">Configuración de punto de recogida del recuperador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/dbsearch_cfg_dialog.ui" line="24"/>
        <source>采样周期时间（秒）</source>
        <translation type="unfinished">Ciclo de muestreo (segundos)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/dbsearch_cfg_dialog.ui" line="47"/>
        <source>是否统计</source>
        <translation type="unfinished">Estadística habilitada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/dbsearch_cfg_dialog.ui" line="54"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/dbsearch_cfg_dialog.ui" line="61"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/dbsearch_cfg_dialog.cpp" line="80"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/dbsearch_cfg_dialog.cpp" line="118"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/dbsearch_cfg_dialog.cpp" line="124"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/dbsearch_cfg_dialog.cpp" line="80"/>
        <source>至少勾选一个测点</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/dbsearch_cfg_dialog.cpp" line="118"/>
        <source>采样周期不能为空</source>
        <translation type="unfinished">El período de muestreo no puede ser nulo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/dbsearch_cfg_dialog.cpp" line="124"/>
        <source>秒级采样采样周期需要小于60秒</source>
        <translation type="unfinished">El intervalo de muestreo para el muestreo de segundo nivel debe ser inferior a 60 segundos</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::AddObjectDialog</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="13"/>
        <source>对象选择器</source>
        <translation type="unfinished">Selector de objetos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="19"/>
        <source>应用名</source>
        <translation type="unfinished">Nombre de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="23"/>
        <source>库名</source>
        <translation type="unfinished">Nombre de la base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="38"/>
        <source>表名</source>
        <translation type="unfinished">Nombre de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="42"/>
        <source>采样周期</source>
        <translation type="unfinished">Ciclo de muestreo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="44"/>
        <source>秒</source>
        <translation type="unfinished">seg</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="45"/>
        <source>分钟</source>
        <translation type="unfinished">min</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="46"/>
        <source>小时</source>
        <translation type="unfinished">h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="81"/>
        <source>帮助</source>
        <translation type="unfinished">Ayuda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="87"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="93"/>
        <source>退出</source>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="99"/>
        <source>正在保存，请稍后...</source>
        <translation type="unfinished">Guardando, por favor espere...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="106"/>
        <source>保存进度</source>
        <translation type="unfinished">Progreso de guardado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="206"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="354"/>
        <source>连接 %1 应用的 %2 运行库失败</source>
        <translation type="unfinished">Error de conexión de la aplicación %1 a la RTDB %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="333"/>
        <source>连接 %1 应用的 %2 维护库失败</source>
        <translation type="unfinished">Error de conexión de la aplicación %1 a la MTDB %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="207"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="334"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="355"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="618"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="213"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="458"/>
        <source>(运行库)</source>
        <translation type="unfinished">(RTDB)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="220"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="449"/>
        <source>(维护库)</source>
        <translation type="unfinished">(MTDB)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="508"/>
        <source>获取数据</source>
        <translation type="unfinished">Consulta de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="509"/>
        <source>正在获取数据，请稍后...</source>
        <translation type="unfinished">Obteniendo datos ahora, por favor espere...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="541"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="611"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="692"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="881"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="541"/>
        <source>正在获取数据，请稍后再尝试保存。</source>
        <translation type="unfinished">Recuperando datos, por favor intente guardar nuevamente más tarde.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="584"/>
        <source>保存数据</source>
        <translation type="unfinished">Guardar datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="585"/>
        <source>正在保存数据，请稍后...</source>
        <translation type="unfinished">Guardando datos, por favor espere...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="611"/>
        <source>保存失败</source>
        <translation type="unfinished">Fallo al guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="618"/>
        <source>保存成功!</source>
        <translation type="unfinished">¡Guardado exitosamente!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="692"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="881"/>
        <source>正在获取数据，请稍后再尝试关闭窗口。</source>
        <translation type="unfinished">Los datos están siendo adquiridos, por favor intente cerrar la ventana nuevamente más tarde.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="796"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_object_dialog.cpp" line="796"/>
        <source>切换的应用名称不符合规则</source>
        <translation type="unfinished">El nombre de la aplicación cambiada no cumple con las reglas</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::AddTableDialog</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="36"/>
        <source>采样存储列选择器</source>
        <translation type="unfinished">Selector de columnas de almacenamiento de muestras</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="50"/>
        <source>应用名</source>
        <translation type="unfinished">Nombre de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="57"/>
        <source>库名</source>
        <translation type="unfinished">Nombre de la base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="64"/>
        <source>表名</source>
        <translation type="unfinished">Nombre de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="79"/>
        <source>存储类型</source>
        <translation type="unfinished">Tipo de almacenamiento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="83"/>
        <source>不存历史</source>
        <translation type="unfinished">Sin historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="83"/>
        <source>采样存储</source>
        <translation type="unfinished">Muestreo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="83"/>
        <source>事件存储</source>
        <translation type="unfinished">Eventos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="83"/>
        <source>统计存储</source>
        <translation type="unfinished">Estadísticas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="95"/>
        <source>最大存储时间</source>
        <translation type="unfinished">Tiempo máximo de almacenamiento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="161"/>
        <source>帮助</source>
        <translation type="unfinished">Ayuda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="167"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="173"/>
        <source>退出</source>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="375"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="580"/>
        <source>连接 %1 应用的 %2 运行库失败</source>
        <translation type="unfinished">Error de conexión de la aplicación %1 a la RTDB %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="559"/>
        <source>连接 %1 应用的 %2 维护库失败</source>
        <translation type="unfinished">Error de conexión de la aplicación %1 a la MTDB %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="21"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="32"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="376"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="560"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="581"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="782"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="808"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="825"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="829"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="15"/>
        <source>小时</source>
        <translation type="unfinished">Hora</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="15"/>
        <source>天</source>
        <translation type="unfinished">Día</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="15"/>
        <source>月</source>
        <translation type="unfinished">mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="15"/>
        <source>年</source>
        <translation type="unfinished">año</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="21"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="32"/>
        <source>历史参数获取失败</source>
        <translation type="unfinished">No se pudieron recuperar los parámetros históricos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="382"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="687"/>
        <source>(运行库)</source>
        <translation type="unfinished">(RTDB)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="394"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="677"/>
        <source>(维护库)</source>
        <translation type="unfinished">(MTDB)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="782"/>
        <source>请选择表!</source>
        <translation type="unfinished">¡Por favor, seleccione una tabla!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="808"/>
        <source>请选择列!</source>
        <translation type="unfinished">¡Por favor, seleccione una columna!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="825"/>
        <source>保存成功!</source>
        <translation type="unfinished">¡Guardado exitosamente!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/add_table_dialog.cpp" line="829"/>
        <source>保存失败!</source>
        <translation type="unfinished">¡Fallo al guardar!</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::HisAddDialog</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_add_dialog.cpp" line="10"/>
        <source>对象选择器</source>
        <translation type="unfinished">Selector de objetos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_add_dialog.cpp" line="16"/>
        <source>应用名</source>
        <translation type="unfinished">Nombre de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_add_dialog.cpp" line="21"/>
        <source>库名</source>
        <translation type="unfinished">Nombre de la base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_add_dialog.cpp" line="37"/>
        <source>表名</source>
        <translation type="unfinished">Nombre de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_add_dialog.cpp" line="41"/>
        <source>统计周期(分钟)</source>
        <translation type="unfinished">Período estadístico (min)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_add_dialog.cpp" line="67"/>
        <source>帮助</source>
        <translation type="unfinished">Ayuda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_add_dialog.cpp" line="73"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_add_dialog.cpp" line="79"/>
        <source>退出</source>
        <translation type="unfinished">Salir</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::HisDictionaryModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_dictionary_model.cpp" line="158"/>
        <source>不存历史</source>
        <translation type="unfinished">Sin historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_dictionary_model.cpp" line="160"/>
        <source>采样存储</source>
        <translation type="unfinished">Muestreo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_dictionary_model.cpp" line="162"/>
        <source>事件存储</source>
        <translation type="unfinished">Eventos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_dictionary_model.cpp" line="164"/>
        <source>统计存储</source>
        <translation type="unfinished">Estadísticas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_dictionary_model.cpp" line="166"/>
        <source>采样+事件存储</source>
        <translation type="unfinished">Almacenamiento de muestreo + evento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_dictionary_model.cpp" line="168"/>
        <source>未配置</source>
        <translation type="unfinished">No configurado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_dictionary_model.cpp" line="358"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_dictionary_model.cpp" line="392"/>
        <source>唯一标识</source>
        <translation type="unfinished">ID único</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::HisObjectMain</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="41"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="45"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="211"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="312"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="420"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="449"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="458"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="473"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="480"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="511"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="526"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="682"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="732"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="743"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="776"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="795"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="915"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1063"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1260"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1291"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1312"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1341"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1356"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1465"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1469"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1589"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1671"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1691"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1698"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1718"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1743"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1747"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="41"/>
        <source>历史服务状态检查出错</source>
        <translation type="unfinished">Error en la verificación del estado del servicio histórico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="211"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="682"/>
        <source>请先选择需要配置的行</source>
        <translation type="unfinished">Por favor, seleccione la línea que desea configurar primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="286"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1081"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1121"/>
        <source>历史存储表</source>
        <translation type="unfinished">Tablas de almacenamiento histórico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="312"/>
        <source>查询的应用不符合格式要求</source>
        <translation type="unfinished">La aplicación que está buscando no cumple con el formato requerido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="369"/>
        <source>配置历史存储表</source>
        <translation type="unfinished">Configurar tabla de almacenamiento histórico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="399"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="399"/>
        <source>平台应用表不允许修改</source>
        <translation type="unfinished">La tabla de aplicaciones de la plataforma no permite modificaciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="411"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="712"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="420"/>
        <source>请右击一行删除</source>
        <translation type="unfinished">Por favor, haga clic derecho sobre una línea para eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="450"/>
        <source>可以连接运行库，不可直接删除字典，请通过配置历史存储表不统计历史</source>
        <translation type="unfinished">Puede conectarse al RTDB, no puede eliminar directamente el diccionario, configure la tabla de almacenamiento histórico sin contar el historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="459"/>
        <source>可以连接维护库，不可直接删除字典，请通过配置历史存储表不统计历史</source>
        <translation type="unfinished">Puede conectarse al repositorio de mantenimiento, no puede eliminar directamente el diccionario, configure la tabla de almacenamiento histórico sin contar el historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="473"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1671"/>
        <source>部署的维护库连接失败</source>
        <translation type="unfinished">MTDB desplegado 
Fallo de conexión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="479"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="914"/>
        <source>正在获取存储点，请稍候...</source>
        <translation type="unfinished">Recuperando puntos de almacenamiento, por favor espere...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="479"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="742"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="914"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1259"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1588"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="511"/>
        <source>获取存储点成功</source>
        <translation type="unfinished">Obteniendo punto de almacenamiento con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="526"/>
        <source>获取存储点失败</source>
        <translation type="unfinished">Fallo al obtener el punto de almacenamiento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="645"/>
        <source>导入所有点</source>
        <translation type="unfinished">Importar todos los puntos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="658"/>
        <source>检索器挑点</source>
        <translation type="unfinished">Punto de selección del motor de búsqueda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="671"/>
        <source>修改参数</source>
        <translation type="unfinished">Modificar parámetros</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="699"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="732"/>
        <source>请先选择需要删除的行</source>
        <translation type="unfinished">¡Por favor, seleccione primero las filas que desea eliminar!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="742"/>
        <source>正在删除存储点，请稍候...</source>
        <translation type="unfinished">Eliminando puntos de memoria, por favor espere...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="776"/>
        <source>删除存储点成功</source>
        <translation type="unfinished">Eliminación de punto de memoria exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="795"/>
        <source>删除存储点失败</source>
        <translation type="unfinished">¡Fallo al eliminar el punto de memoria!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1063"/>
        <source>切换的应用名称不符合规则</source>
        <translation type="unfinished">El nombre de la aplicación cambiada no cumple con las reglas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1192"/>
        <source>历史应用%1</source>
        <translation type="unfinished">App de historial %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1356"/>
        <source>秒级采样标签下不能保存大于等于60秒的采样周期</source>
        <translation type="unfinished">Los intervalos de muestreo de 60 segundos o más no se pueden guardar bajo la etiqueta de muestreo de segundo nivel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1994"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="2028"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1995"/>
        <source>秒级采样点数量(%1)超过限制(%2)，请调整后重试</source>
        <translation type="unfinished">Núm. de puntos de muestreo seg. (%1) excede (%2)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="2029"/>
        <source>分钟级采样点数量(%1)超过限制(%2)，请调整后重试</source>
        <translation type="unfinished">El número de puntos de muestreo a nivel de minuto (%1) excede el límite (%2), por favor ajuste e intente de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1259"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1588"/>
        <source>正在保存配置，请稍候...</source>
        <translation type="unfinished">Guardando configuración, por favor espere...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="168"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="624"/>
        <source>全部</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="169"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="625"/>
        <source>秒级采样</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Segundo_Muestreo de Nivel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="520"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="619"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="789"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="969"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1306"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1459"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1627"/>
        <source>全部(%1)</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Todo (%1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="521"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="620"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="790"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="970"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1307"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1460"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1628"/>
        <source>秒级采样(%1)</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Segundo Nivel (%1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1291"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1691"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1743"/>
        <source>配置成功</source>
        <translation type="unfinished">Configuración exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1312"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1698"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1747"/>
        <source>配置失败</source>
        <translation type="unfinished">Fallo de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1341"/>
        <source>没有需要保存的数据</source>
        <translation type="unfinished">No hay datos para guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1465"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1469"/>
        <source>保存失败</source>
        <translation type="unfinished">Fallo al guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_object_main.cpp" line="1718"/>
        <source>连接运行库失败</source>
        <translation type="unfinished">Fallo al conectarse a RTDB</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::HisSampleObjectModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_object_model.cpp" line="604"/>
        <source>checkbox</source>
        <translation type="unfinished">casilla de verificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_object_model.cpp" line="605"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_object_model.cpp" line="635"/>
        <source>唯一标识</source>
        <translation type="unfinished">ID único</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_object_model.cpp" line="641"/>
        <source>采样周期(秒)</source>
        <translation type="unfinished">Período de muestreo (seg)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_object_model.cpp" line="654"/>
        <source>路径</source>
        <translation type="unfinished">Ruta</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::HisSampleTableModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_table_model.cpp" line="52"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_table_model.cpp" line="54"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_table_model.cpp" line="56"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_table_model.cpp" line="58"/>
        <source>是否起效</source>
        <translation type="unfinished">Eficaz</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/his_sample_table_model.cpp" line="60"/>
        <source>时间单位</source>
        <translation type="unfinished">Unidad de tiempo</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::ObjectTableModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/object_table_model.cpp" line="62"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/object_table_model.cpp" line="64"/>
        <source>唯一标识</source>
        <translation type="unfinished">ID único</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/object_table_model.cpp" line="66"/>
        <source>路径</source>
        <translation type="unfinished">Ruta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/object_table_model.cpp" line="68"/>
        <source>采样周期</source>
        <translation type="unfinished">Ciclo de muestreo</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::TableColoumnModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/table_coloumn_model.cpp" line="39"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/table_coloumn_model.cpp" line="41"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/table_coloumn_model.cpp" line="43"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/table_coloumn_model.cpp" line="45"/>
        <source>主键列</source>
        <translation type="unfinished">Columna clave primaria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/table_coloumn_model.cpp" line="47"/>
        <source>当前是否存历史</source>
        <translation type="unfinished">Guardar como historial</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/table_coloumn_model.cpp" line="68"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/table_coloumn_model.cpp" line="73"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/table_coloumn_model.cpp" line="70"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_objectcfg/src/table_coloumn_model.cpp" line="75"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
</context>
</TS>
