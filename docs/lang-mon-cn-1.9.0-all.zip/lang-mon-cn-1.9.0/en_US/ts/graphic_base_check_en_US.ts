<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>BaseCheckWiget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="89"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="89"/>
        <source>错误等级</source>
        <translation type="unfinished">Error level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="89"/>
        <source>检查类型</source>
        <translation type="unfinished">Exam type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="89"/>
        <source>详情描述</source>
        <translation type="unfinished">Detailed description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="119"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="209"/>
        <source>显示所有标记</source>
        <translation type="unfinished">Display all tags</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="126"/>
        <source>清除定位标记</source>
        <translation type="unfinished">Clear pos mark</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="134"/>
        <source>重新绘制唯一标识</source>
        <translation type="unfinished">Redraw onlyNo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="140"/>
        <source>删除部分超出画布外元素</source>
        <translation type="unfinished">Del partially beyond</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="148"/>
        <source>删除完全超出画布外元素</source>
        <translation type="unfinished">Del completely beyond</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="154"/>
        <source>处理异常的图元态</source>
        <translation type="unfinished">Handle error icon states</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="199"/>
        <source>隐藏所有标记</source>
        <translation type="unfinished">Hide all tags</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="222"/>
        <source>该操作将自动处理所有的图元态异常且不可恢复，详情请见图元正确性检查异常列表，是否继续？</source>
        <translation type="unfinished">This operation will automatically handle all icon state anomalies and is irreversible. For details, please refer to the list of icon correctness check anomalies. Whether to continue?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="268"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="303"/>
        <source>处理完成，若使本次操作生效,请保存并发布该图元</source>
        <translation type="unfinished">Process completed. Please save and publish this icon, for the operation to take effect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="278"/>
        <source>图元信息获取失败，该操作终止</source>
        <translation type="unfinished">Failed to obtain the icon information. The operation is terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="283"/>
        <source>非图元正确性检查操作，当前不做处理</source>
        <translation type="unfinished">For non-icon correctness checking operations, no processing is currently performed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="297"/>
        <source>若使本次重绘操作生效,请保存并发布该画面</source>
        <translation type="unfinished">If you want this redraw operation to take effect, please save and publish the graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="221"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="311"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="568"/>
        <source>警告</source>
        <comment>toolName</comment>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="312"/>
        <source>该操作将删除所有全部超出画布外元素，且不可恢复，是否继续？</source>
        <translation type="unfinished">This operation will delete all elements completely beyond the canvas and cannot be recovered. Whether to continue?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="225"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="315"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="572"/>
        <source>继续</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="226"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="316"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="573"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="428"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="437"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="723"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="732"/>
        <source>删除失败</source>
        <translation type="unfinished">Deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="429"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="724"/>
        <source>不能同时删除表格子元素和其他元素，请先选择对应的表格或分别删除。</source>
        <translation type="unfinished">You cannot delete table sub-elements and other elements simultaneously; please select the corresponding table first or delete them separately.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="437"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="732"/>
        <source>不能单独删除表格子元素，请选择对应的表格进行删除。</source>
        <translation type="unfinished">Cannot delete table sub-elements separately, please select the corresponding table for deletion.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="524"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="819"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="525"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="820"/>
        <source>已跳过%1个无法单独删除的表格子元素。</source>
        <translation type="unfinished">%1 table sub-elements that cannot be deleted individually have been skipped.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="561"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="856"/>
        <source>删除成功</source>
        <translation type="unfinished">Deleted successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="569"/>
        <source>该操作将删除所有部分超出画布外元素，且不可恢复，是否继续？</source>
        <translation type="unfinished">This operation will delete all elements partially beyond the canvas and cannot be recovered. Whether to continue?</translation>
    </message>
</context>
<context>
    <name>CheckPictureTree</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="27"/>
        <source>画面列表</source>
        <translation type="unfinished">Graph list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="27"/>
        <source>对象源名称</source>
        <translation type="unfinished">Object source name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="239"/>
        <source>最新版本</source>
        <translation type="unfinished">Latest version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="243"/>
        <source>草稿版本</source>
        <translation type="unfinished">Draft version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="247"/>
        <source>历史版本%1</source>
        <translation type="unfinished">Historical version %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="301"/>
        <source>正在加载画面列表</source>
        <translation type="unfinished">Loading graph list</translation>
    </message>
</context>
<context>
    <name>IconCheckBase</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/icon_check_base.cpp" line="49"/>
        <source>隐藏所有标记</source>
        <translation type="unfinished">Hide all tags</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/icon_check_base.cpp" line="74"/>
        <source>正在加载正确性检查项...</source>
        <translation type="unfinished">Loading correctness check items...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/icon_check_base.cpp" line="260"/>
        <source>当前图元自检完成!异常项(%1)</source>
        <translation type="unfinished">The current icon self check is completed! Exception item (%1)</translation>
    </message>
</context>
<context>
    <name>PictureCheckBase</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/picture_check_base.cpp" line="60"/>
        <source>隐藏所有标记</source>
        <translation type="unfinished">Hide all tags</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/picture_check_base.cpp" line="81"/>
        <source>正在加载正确性检查项...</source>
        <translation type="unfinished">Loading correctness check items...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/picture_check_base.cpp" line="255"/>
        <source>当前画面自检完成!异常项(%1)</source>
        <translation type="unfinished">Current graph self-test is completed! Exception item (%1)</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="268"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="273"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="278"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="283"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="297"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="303"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="561"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="856"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="551"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="647"/>
        <source>草稿版本</source>
        <comment>PictureItem::displayChildren</comment>
        <translation type="unfinished">Draft version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="590"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="663"/>
        <source>最新版本</source>
        <comment>PictureItem::displayChildren</comment>
        <translation type="unfinished">Latest version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="691"/>
        <source>历史版本</source>
        <comment>PictureItem::displayChildren</comment>
        <translation type="unfinished">History Version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="773"/>
        <source>版本%1</source>
        <comment>HistoryItem::displayChildren</comment>
        <translation type="unfinished">Version %1</translation>
    </message>
</context>
</TS>
