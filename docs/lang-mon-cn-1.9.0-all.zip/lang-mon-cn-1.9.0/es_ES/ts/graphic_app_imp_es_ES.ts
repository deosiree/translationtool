<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>GraphicAppImp</name>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="69"/>
        <source>接地</source>
        <translation type="unfinished">Conexión a tierra</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="70"/>
        <source>无效</source>
        <translation type="unfinished">Inválido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="849"/>
        <source>传入画面信息为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="870"/>
        <source>传入的所有画面光字信息均为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="878"/>
        <source>传入的画面[%1]光字信息为空</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="41"/>
        <source>测试应用通用接口插件集合</source>
        <translation type="unfinished">Colección de complementos de la interfaz común de la aplicación de prueba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="232"/>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="239"/>
        <source>牌的相对坐标 x=%1,y=%2,width=%3,height=%4</source>
        <translation type="unfinished">Coordenadas relativas de las tarjetas x=%1, y=%2, ancho=%3, altura=%4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="238"/>
        <source>牌信息</source>
        <translation type="unfinished">Información de la tarjeta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="250"/>
        <source>类型</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="251"/>
        <source>厂站名</source>
        <translation type="unfinished">Nombre de la estación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="322"/>
        <source>测试设备对象</source>
        <translation type="unfinished">Objeto de equipo de prueba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="326"/>
        <source>测试数值前景对象</source>
        <translation type="unfinished">Objeto de Primer Plano del Número de Prueba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="330"/>
        <source>测试状态前景对象</source>
        <translation type="unfinished">Objeto de primer plano del estado de prueba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="334"/>
        <source>测试字符前景对象</source>
        <translation type="unfinished">Objeto de primer plano del carácter de prueba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="338"/>
        <source>测试光敏点前景对象</source>
        <translation type="unfinished">Objeto de primer plano del punto fotosensible de prueba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_app_imp/graphic_app_imp.cpp" line="342"/>
        <source>测试未定义类型对象</source>
        <translation type="unfinished">Pruebas para objetos de tipo indefinido</translation>
    </message>
</context>
</TS>
