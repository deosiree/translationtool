<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CloseButton</name>
    <message>
        <source>Close Tab</source>
        <translation>Cerrar pestaña</translation>
    </message>
</context>
<context>
    <name>MAC_APPLICATION_MENU</name>
    <message>
        <source>Services</source>
        <translation>Servicios</translation>
    </message>
    <message>
        <source>Hide %1</source>
        <translation>Ocultar %1</translation>
    </message>
    <message>
        <source>Hide Others</source>
        <translation>Ocultar otros</translation>
    </message>
    <message>
        <source>Show All</source>
        <translation>Mostrar todo</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>Preferencias…</translation>
    </message>
    <message>
        <source>Quit %1</source>
        <translation>Salir de %1</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation>Acerca de %1</translation>
    </message>
</context>
<context>
    <name>QAbstractSocket</name>
    <message>
        <source>Socket operation timed out</source>
        <translation>Operación socket expirada</translation>
    </message>
    <message>
        <source>Operation on socket is not supported</source>
        <translation>La operación no está soportada por el socket</translation>
    </message>
    <message>
        <source>Host not found</source>
        <translation>Equipo no encontrado</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>Conexión rechazada</translation>
    </message>
    <message>
        <source>Connection timed out</source>
        <translation>Tiempo de espera por la conexión expirado</translation>
    </message>
    <message>
        <source>Trying to connect while connection is in progress</source>
        <translation>Intentando conectar mientras la conexión está en progreso</translation>
    </message>
    <message>
        <source>Socket is not connected</source>
        <translation>El socket no está conectado</translation>
    </message>
    <message>
        <source>Network unreachable</source>
        <translation>Red no disponible</translation>
    </message>
</context>
<context>
    <name>QAbstractSpinBox</name>
    <message>
        <source>&amp;Select All</source>
        <translation>&amp;Seleccionar todo</translation>
    </message>
    <message>
        <source>&amp;Step up</source>
        <translation>&amp;Aumentar</translation>
    </message>
    <message>
        <source>Step &amp;down</source>
        <translation>Re&amp;ducir</translation>
    </message>
</context>
<context>
    <name>QAccessibleActionInterface</name>
    <message>
        <source>Press</source>
        <translation>Pulsar</translation>
    </message>
    <message>
        <source>Increase</source>
        <translation>Incrementar</translation>
    </message>
    <message>
        <source>Decrease</source>
        <translation>Decrementar</translation>
    </message>
    <message>
        <source>ShowMenu</source>
        <translation>MostrarMenú</translation>
    </message>
    <message>
        <source>SetFocus</source>
        <translation>PonerFoco</translation>
    </message>
    <message>
        <source>Toggle</source>
        <translation>Conmutar</translation>
    </message>
    <message>
        <source>Scroll Left</source>
        <translation>Desplazar hacia la izquierda</translation>
    </message>
    <message>
        <source>Scroll Right</source>
        <translation>Desplazar hacia la derecha</translation>
    </message>
    <message>
        <source>Scroll Up</source>
        <translation>Desplazar hacia arriba</translation>
    </message>
    <message>
        <source>Scroll Down</source>
        <translation>Desplazar hacia abajo</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation>Página anterior</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation>Página siguiente</translation>
    </message>
    <message>
        <source>Triggers the action</source>
        <translation>Desencadena la acción</translation>
    </message>
    <message>
        <source>Increase the value</source>
        <translation>Incrementa el valor</translation>
    </message>
    <message>
        <source>Decrease the value</source>
        <translation>Decrementa el valor</translation>
    </message>
    <message>
        <source>Shows the menu</source>
        <translation>Muestra el menú</translation>
    </message>
    <message>
        <source>Sets the focus</source>
        <translation>Pone el foco</translation>
    </message>
    <message>
        <source>Toggles the state</source>
        <translation>Conmuta el estado</translation>
    </message>
    <message>
        <source>Scrolls to the left</source>
        <translation>Desplazar hacia la izquierda</translation>
    </message>
    <message>
        <source>Scrolls to the right</source>
        <translation>Desplazar hacia la derecha</translation>
    </message>
    <message>
        <source>Scrolls up</source>
        <translation>Desplazar hacia arriba</translation>
    </message>
    <message>
        <source>Scrolls down</source>
        <translation>Desplazar hacia abajo</translation>
    </message>
    <message>
        <source>Goes back a page</source>
        <translation>Retrocede una página</translation>
    </message>
    <message>
        <source>Goes to the next page</source>
        <translation>Va a la página siguiente</translation>
    </message>
</context>
<context>
    <name>QAndroidPlatformTheme</name>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>Yes to All</source>
        <translation>Sí a todo</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>No to All</source>
        <translation>No a todo</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <source>Application &quot;%1&quot; requires Qt %2, found Qt %3.</source>
        <translation>La aplicación &quot;%1&quot; requiere Qt %2, se encontró Qt %3.</translation>
    </message>
    <message>
        <source>Incompatible Qt Library Error</source>
        <translation>Error: Biblioteca Qt incompatible</translation>
    </message>
</context>
<context>
    <name>QCocoaMenuItem</name>
    <message>
        <source>About Qt</source>
        <translation>Acerca de Qt</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <source>Config</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <source>Preference</source>
        <translation>Preferencia</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <source>Setting</source>
        <translation>Ajuste</translation>
    </message>
    <message>
        <source>Setup</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Pegar</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Seleccionar todo</translation>
    </message>
</context>
<context>
    <name>QCocoaTheme</name>
    <message>
        <source>Don&apos;t Save</source>
        <translation>No guardar</translation>
    </message>
</context>
<context>
    <name>QColorDialog</name>
    <message>
        <source>Hu&amp;e:</source>
        <translation>&amp;Tono:</translation>
    </message>
    <message>
        <source>&amp;Sat:</source>
        <translation>&amp;Saturación:</translation>
    </message>
    <message>
        <source>&amp;Val:</source>
        <translation>&amp;Valor:</translation>
    </message>
    <message>
        <source>&amp;Red:</source>
        <translation>&amp;Rojo:</translation>
    </message>
    <message>
        <source>&amp;Green:</source>
        <translation>&amp;Verde:</translation>
    </message>
    <message>
        <source>Bl&amp;ue:</source>
        <translation>Az&amp;ul:</translation>
    </message>
    <message>
        <source>A&amp;lpha channel:</source>
        <translation>Canal a&amp;lfa:</translation>
    </message>
    <message>
        <source>&amp;HTML:</source>
        <translation>&amp;HTML:</translation>
    </message>
    <message>
        <source>Cursor at %1, %2
Press ESC to cancel</source>
        <translation>Cursor en %1, %2
Presiona ESC para cancelar</translation>
    </message>
    <message>
        <source>Select Color</source>
        <translation>Selecciona color</translation>
    </message>
    <message>
        <source>&amp;Basic colors</source>
        <translation>Colores &amp;básicos</translation>
    </message>
    <message>
        <source>&amp;Custom colors</source>
        <translation>&amp;Colores personalizados</translation>
    </message>
    <message>
        <source>&amp;Add to Custom Colors</source>
        <translation>&amp;Añadir a los colores personalizados</translation>
    </message>
    <message>
        <source>&amp;Pick Screen Color</source>
        <translation>Tomar un color de la &amp;pantalla</translation>
    </message>
</context>
<context>
    <name>QComboBox</name>
    <message>
        <source>Open the combo box selection popup</source>
        <translation>Abrir el menú desplegable del combo box</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Falso</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Verdadero</translation>
    </message>
</context>
<context>
    <name>QCommandLineParser</name>
    <message>
        <source>Displays version information.</source>
        <translation>Muestra la información de versión.</translation>
    </message>
    <message>
        <source>Displays help on commandline options.</source>
        <translation>Muestra ayuda sobre las opciones de Cmd.</translation>
    </message>
    <message>
        <source>Displays help, including generic Qt options.</source>
        <translation>Muestra ayuda, incluidas las opciones genéricas de Qt.</translation>
    </message>
    <message>
        <source>Unknown option &apos;%1&apos;.</source>
        <translation>Opción desconocida «%1».</translation>
    </message>
    <message>
        <source>Unknown options: %1.</source>
        <translation>Opciones desconocidas: %1.</translation>
    </message>
    <message>
        <source>Missing value after &apos;%1&apos;.</source>
        <translation>Falta valor tras «%1».</translation>
    </message>
    <message>
        <source>Unexpected value after &apos;%1&apos;.</source>
        <translation>Valor inesperado tras «%1».</translation>
    </message>
    <message>
        <source>[options]</source>
        <translation>[opciones]</translation>
    </message>
    <message>
        <source>Usage: %1</source>
        <translation>Uso: %1</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Opciones:</translation>
    </message>
    <message>
        <source>Arguments:</source>
        <translation>Argumentos:</translation>
    </message>
</context>
<context>
    <name>QCupsJobWidget</name>
    <message>
        <source>Job</source>
        <translation>Trabajo</translation>
    </message>
    <message>
        <source>Job Control</source>
        <translation>Control de Trabajos</translation>
    </message>
    <message>
        <source>Scheduled printing:</source>
        <translation>Impresión programada:</translation>
    </message>
    <message>
        <source>Billing information:</source>
        <translation>Información de facturación:</translation>
    </message>
    <message>
        <source>Job priority:</source>
        <translation>Prioridad del trabajo:</translation>
    </message>
    <message>
        <source>Banner Pages</source>
        <translation>Páginas de cabecera</translation>
    </message>
    <message>
        <source>End:</source>
        <comment>Banner page at end</comment>
        <translation>Final:</translation>
    </message>
    <message>
        <source>Start:</source>
        <comment>Banner page at start</comment>
        <translation>Inicial:</translation>
    </message>
    <message>
        <source>Print Immediately</source>
        <translation>Imprimir inmediatamente</translation>
    </message>
    <message>
        <source>Hold Indefinitely</source>
        <translation>Mantener indefinidamente</translation>
    </message>
    <message>
        <source>Day (06:00 to 17:59)</source>
        <translation>Día (06:00 a 17:59)</translation>
    </message>
    <message>
        <source>Night (18:00 to 05:59)</source>
        <translation>Noche (18:00 a 05:59)</translation>
    </message>
    <message>
        <source>Second Shift (16:00 to 23:59)</source>
        <translation>Segundo cambio (16:00 a 23:59)</translation>
    </message>
    <message>
        <source>Third Shift (00:00 to 07:59)</source>
        <translation>Tercer cambio (00:00 a 07:59)</translation>
    </message>
    <message>
        <source>Weekend (Saturday to Sunday)</source>
        <translation>Fin de semana (Sábado a Domingo)</translation>
    </message>
    <message>
        <source>Specific Time</source>
        <translation>Hora específica</translation>
    </message>
    <message>
        <source>None</source>
        <comment>CUPS Banner page</comment>
        <translation>Ninguna</translation>
    </message>
    <message>
        <source>Standard</source>
        <comment>CUPS Banner page</comment>
        <translation>Estándar</translation>
    </message>
    <message>
        <source>Unclassified</source>
        <comment>CUPS Banner page</comment>
        <translation>Sin clasificar</translation>
    </message>
    <message>
        <source>Confidential</source>
        <comment>CUPS Banner page</comment>
        <translation>Confidencial</translation>
    </message>
    <message>
        <source>Classified</source>
        <comment>CUPS Banner page</comment>
        <translation>Clasificado</translation>
    </message>
    <message>
        <source>Secret</source>
        <comment>CUPS Banner page</comment>
        <translation>Secreto</translation>
    </message>
    <message>
        <source>Top Secret</source>
        <comment>CUPS Banner page</comment>
        <translation>Alto secreto</translation>
    </message>
</context>
<context>
    <name>QDB2Driver</name>
    <message>
        <source>Unable to connect</source>
        <translation>Imposible establecer una conexión</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Incapaz de enviar la transacción</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Incapaz de anular la transacción</translation>
    </message>
    <message>
        <source>Unable to set autocommit</source>
        <translation>Incapaz de activar el envío automático</translation>
    </message>
</context>
<context>
    <name>QDB2Result</name>
    <message>
        <source>Unable to execute statement</source>
        <translation>Imposible ejecutar la instrucción</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>Imposible preparar la instrucción</translation>
    </message>
    <message>
        <source>Unable to bind variable</source>
        <translation>No es posible ligar la variable</translation>
    </message>
    <message>
        <source>Unable to fetch record %1</source>
        <translation>Imposible obtener el registro %1</translation>
    </message>
    <message>
        <source>Unable to fetch next</source>
        <translation>Imposible recuperar el siguiente</translation>
    </message>
    <message>
        <source>Unable to fetch first</source>
        <translation>Imposible recuperar el primero</translation>
    </message>
</context>
<context>
    <name>QDBusTrayIcon</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>QDialog</name>
    <message>
        <source>What&apos;s This?</source>
        <translation>¿Qué es esto?</translation>
    </message>
</context>
<context>
    <name>QDialogButtonBox</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>QDnsLookup</name>
    <message>
        <source>Operation cancelled</source>
        <translation>Operación cancelada</translation>
    </message>
    <message>
        <source>Invalid domain name</source>
        <translation>Nombre de dominio inválido</translation>
    </message>
    <message>
        <source>SSL/TLS support not present</source>
        <translation>Soporte SSL/TLS no presente</translation>
    </message>
    <message>
        <source>Request timed out</source>
        <translation>Tiempo de espera de la solicitud agotado</translation>
    </message>
    <message>
        <source>Server could not process query</source>
        <translation>El servidor no pudo procesar la consulta</translation>
    </message>
    <message>
        <source>Server failure</source>
        <translation>Fallo del servidor</translation>
    </message>
    <message>
        <source>Non existent domain</source>
        <translation>Dominio inexistente</translation>
    </message>
    <message>
        <source>Server refused to answer</source>
        <translation>El servidor se negó a responder</translation>
    </message>
    <message>
        <source>Invalid reply received (rcode %1)</source>
        <translation>Respuesta inválida recibida (rcode %1)</translation>
    </message>
    <message>
        <source>Invalid reply received</source>
        <translation>Respuesta inválida recibida</translation>
    </message>
    <message>
        <source>Invalid reply received (%1)</source>
        <translation>Respuesta inválida recibida (%1)</translation>
    </message>
    <message>
        <source>IPv6 nameservers are currently not supported on this OS</source>
        <translation>Los servidores de nombres IPv6 actualmente no son compatibles con este sistema operativo</translation>
    </message>
    <message>
        <source>Reply was too large</source>
        <translation>La respuesta era demasiado grande</translation>
    </message>
    <message>
        <source>Could not expand domain name</source>
        <translation>No se pudo expandir el nombre de dominio</translation>
    </message>
    <message>
        <source>Invalid IPv4 address record</source>
        <translation>Registro de dirección IPv4 inválido</translation>
    </message>
    <message>
        <source>Invalid IPv6 address record</source>
        <translation>Registro de dirección IPv6 inválido</translation>
    </message>
    <message>
        <source>Invalid canonical name record</source>
        <translation>Registro de nombre canónico inválido</translation>
    </message>
    <message>
        <source>Invalid name server record</source>
        <translation>Registro de servidor de nombres inválido</translation>
    </message>
    <message>
        <source>Invalid pointer record</source>
        <translation>Registro de puntero inválido</translation>
    </message>
    <message>
        <source>Invalid mail exchange record</source>
        <translation>Registro de intercambio de correo inválido</translation>
    </message>
    <message>
        <source>Invalid service record</source>
        <translation>Registro de servicio inválido</translation>
    </message>
    <message>
        <source>Invalid TLS association record</source>
        <translation>Registro de asociación TLS inválido</translation>
    </message>
    <message>
        <source>Invalid text record</source>
        <translation>Registro de texto inválido</translation>
    </message>
</context>
<context>
    <name>QDnsLookupRunnable</name>
    <message>
        <source>Not yet supported on this OS</source>
        <translation>Aún no es compatible con este sistema operativo</translation>
    </message>
</context>
<context>
    <name>QDockWidget</name>
    <message>
        <source>Float</source>
        <extracomment>Accessible name for button undocking a dock widget (floating state)</extracomment>
        <translation>Flotante</translation>
    </message>
    <message>
        <source>Undocks and re-attaches the dock widget</source>
        <translation>Desacopla y vuelve a adjuntar el widget acoplable</translation>
    </message>
    <message>
        <source>Close</source>
        <extracomment>Accessible name for button closing a dock widget</extracomment>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Closes the dock widget</source>
        <translation>Cierra el widget acoplable</translation>
    </message>
</context>
<context>
    <name>QErrorMessage</name>
    <message>
        <source>An error occurred</source>
        <translation>Ocurrió un error</translation>
    </message>
    <message>
        <source>Debug Message:</source>
        <translation>Mensaje de depuración:</translation>
    </message>
    <message>
        <source>Warning:</source>
        <translation>Aviso:</translation>
    </message>
    <message>
        <source>Critical Error:</source>
        <translation>Error crítico:</translation>
    </message>
    <message>
        <source>Fatal Error:</source>
        <translation>Error fatal:</translation>
    </message>
    <message>
        <source>Information:</source>
        <translation>Información:</translation>
    </message>
    <message>
        <source>&amp;Show this message again</source>
        <translation>Mo&amp;strar este mensaje de nuevo</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
</context>
<context>
    <name>QFile</name>
    <message>
        <source>Destination file is the same file.</source>
        <translation>El fichero de destino es el mismo.</translation>
    </message>
    <message>
        <source>Source file does not exist.</source>
        <translation>El archivo de origen no existe.</translation>
    </message>
    <message>
        <source>Destination file exists</source>
        <translation>El archivo de destino ya existe</translation>
    </message>
    <message>
        <source>Error while renaming: %1</source>
        <translation>Error al renombrar: %1</translation>
    </message>
    <message>
        <source>Unable to restore from %1: %2</source>
        <translation>No fue posible restaurar desde %1: %2</translation>
    </message>
    <message>
        <source>Will not rename sequential file using block copy</source>
        <translation>No será renombrado el archivo secuencial usando copia por bloques</translation>
    </message>
    <message>
        <source>Cannot remove source file</source>
        <translation>No se puede eliminar el archivo de origen</translation>
    </message>
    <message>
        <source>Cannot open destination file: %1</source>
        <translation>No se puede abrir el archivo de destino: %1</translation>
    </message>
    <message>
        <source>Cannot open %1 for input</source>
        <translation>No se puede abrir %1 para escritura</translation>
    </message>
    <message>
        <source>Cannot open for output: %1</source>
        <translation>No se puede abrir para salida: %1</translation>
    </message>
    <message>
        <source>Failure to write block: %1</source>
        <translation>Fallo al escribir bloque: %1</translation>
    </message>
    <message>
        <source>Cannot create %1 for output: %2</source>
        <translation>No se puede crear %1 para salida: %2</translation>
    </message>
</context>
<context>
    <name>QFileDevice</name>
    <message>
        <source>No file engine available or engine does not support UnMapExtension</source>
        <translation>No hay un motor de archivos disponible o el motor no soporta UnMapExtension</translation>
    </message>
    <message>
        <source>No file engine available</source>
        <translation>No hay motor de archivos disponible</translation>
    </message>
</context>
<context>
    <name>QFileDialog</name>
    <message>
        <source>Look in:</source>
        <translation>Ver en:</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Atrás</translation>
    </message>
    <message>
        <source>Go back</source>
        <translation>Ir atrás</translation>
    </message>
    <message>
        <source>Alt+Left</source>
        <translation>Alt+Izquierda</translation>
    </message>
    <message>
        <source>Forward</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <source>Go forward</source>
        <translation>Ir hacia delante</translation>
    </message>
    <message>
        <source>Alt+Right</source>
        <translation>Alt+Derecha</translation>
    </message>
    <message>
        <source>Parent Directory</source>
        <translation>Directorio superior</translation>
    </message>
    <message>
        <source>Go to the parent directory</source>
        <translation>r al directorio superior</translation>
    </message>
    <message>
        <source>Alt+Up</source>
        <translation>Alt+Arriba</translation>
    </message>
    <message>
        <source>Create New Folder</source>
        <translation>Crear nueva carpeta</translation>
    </message>
    <message>
        <source>Create a New Folder</source>
        <translation>Crear una nueva carpeta</translation>
    </message>
    <message>
        <source>List View</source>
        <translation>Vista de lista</translation>
    </message>
    <message>
        <source>Change to list view mode</source>
        <translation>Cambiar el modo de vista de la lista</translation>
    </message>
    <message>
        <source>Detail View</source>
        <translation>Vista detallada</translation>
    </message>
    <message>
        <source>Change to detail view mode</source>
        <translation>Cambiar a modo de vista detallada</translation>
    </message>
    <message>
        <source>Sidebar</source>
        <translation>Barra lateral</translation>
    </message>
    <message>
        <source>List of places and bookmarks</source>
        <translation>Lista de lugares y marcadores</translation>
    </message>
    <message>
        <source>Files</source>
        <translation>Archivos</translation>
    </message>
    <message>
        <source>Files of type:</source>
        <translation>Ficheros de tipo:</translation>
    </message>
    <message>
        <source>Find Directory</source>
        <translation>Buscar directorio</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>Save As</source>
        <translation>Guardar como</translation>
    </message>
    <message>
        <source>Directory:</source>
        <translation>Directorio:</translation>
    </message>
    <message>
        <source>File &amp;name:</source>
        <translation>&amp;Nombre de fichero:</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Abrir</translation>
    </message>
    <message>
        <source>&amp;Choose</source>
        <translation>&amp;Seleccionar</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Guardar</translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation>Todos los ficheros (*)</translation>
    </message>
    <message>
        <source>Show </source>
        <translation>Mostrar </translation>
    </message>
    <message>
        <source>&amp;Rename</source>
        <translation>Cambia&amp;r de nombre</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Borrar</translation>
    </message>
    <message>
        <source>Show &amp;hidden files</source>
        <translation>Mostrar los fic&amp;heros ocultos</translation>
    </message>
    <message>
        <source>&amp;New Folder</source>
        <translation>&amp;Nueva carpeta</translation>
    </message>
    <message>
        <source>All files (*)</source>
        <translation>Todos los archivos (*)</translation>
    </message>
    <message>
        <source>Directories</source>
        <translation>Directorios</translation>
    </message>
    <message>
        <source>%1
Directory not found.
Please verify the correct directory name was given.</source>
        <translation>%1
Directorio no encontrado.
Verifique que el nombre del directorio es correcto.</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>El fichero %1 ya existe.
¿Desea reemplazarlo?</translation>
    </message>
    <message>
        <source>%1
File not found.
Please verify the correct file name was given.</source>
        <translation>%1
Fichero no encontrado.
Verifique que el nombre del fichero es correcto.</translation>
    </message>
    <message>
        <source>New Folder</source>
        <translation>Nueva carpeta</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is write protected.
Do you want to delete it anyway?</source>
        <translation>«%1» está protegido contra escritura.
¿Desea borrarlo de todas formas?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete &apos;%1&apos;?</source>
        <translation>¿Está seguro de que quiere borrar «%1»?</translation>
    </message>
    <message>
        <source>Could not delete directory.</source>
        <translation>No fue posible borrar el directorio.</translation>
    </message>
    <message>
        <source>Recent Places</source>
        <translation>Lugares recientes</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
</context>
<context>
    <name>QFileSystemModel</name>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <source>Kind</source>
        <comment>Match OS X Finder</comment>
        <translation>Clase</translation>
    </message>
    <message>
        <source>Type</source>
        <comment>All other platforms</comment>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Date Modified</source>
        <translation>Última modificación</translation>
    </message>
    <message>
        <source>My Computer</source>
        <translation>Mi Equipo</translation>
    </message>
    <message>
        <source>Computer</source>
        <translation>Equipo</translation>
    </message>
</context>
<context>
    <name>QFontDatabase</name>
    <message>
        <source>Normal</source>
        <comment>The Normal or Regular font weight</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation>Negrita</translation>
    </message>
    <message>
        <source>Demi Bold</source>
        <translation>Seminegrita</translation>
    </message>
    <message>
        <source>Medium</source>
        <comment>The Medium font weight</comment>
        <translation>Mediana</translation>
    </message>
    <message>
        <source>Black</source>
        <translation>Negra</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Ligera</translation>
    </message>
    <message>
        <source>Thin</source>
        <translation>Delgada</translation>
    </message>
    <message>
        <source>Extra Light</source>
        <translation>ExtraDelgada</translation>
    </message>
    <message>
        <source>Extra Bold</source>
        <translation>ExtraNegrita</translation>
    </message>
    <message>
        <source>Extra</source>
        <extracomment>The word for &quot;Extra&quot; as in &quot;Extra Bold, Extra Thin&quot; used as a pattern for string searches</extracomment>
        <translation>Extra</translation>
    </message>
    <message>
        <source>Demi</source>
        <extracomment>The word for &quot;Demi&quot; as in &quot;Demi Bold&quot; used as a pattern for string searches</extracomment>
        <translation>Semi</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation>Cursiva</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>Oblǐcua</translation>
    </message>
    <message>
        <source>Any</source>
        <translation>Cualquiera</translation>
    </message>
    <message>
        <source>Latin</source>
        <translation>Latín</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Griego</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Cirílico</translation>
    </message>
    <message>
        <source>Armenian</source>
        <translation>Armenio</translation>
    </message>
    <message>
        <source>Hebrew</source>
        <translation>Hebreo</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Árabe</translation>
    </message>
    <message>
        <source>Syriac</source>
        <translation>Siríaco</translation>
    </message>
    <message>
        <source>Thaana</source>
        <translation>Thaana</translation>
    </message>
    <message>
        <source>Devanagari</source>
        <translation>Devanagari</translation>
    </message>
    <message>
        <source>Bengali</source>
        <translation>Bengali</translation>
    </message>
    <message>
        <source>Gurmukhi</source>
        <translation>Gurmukhi</translation>
    </message>
    <message>
        <source>Gujarati</source>
        <translation>Gujarati</translation>
    </message>
    <message>
        <source>Oriya</source>
        <translation>Oriya</translation>
    </message>
    <message>
        <source>Tamil</source>
        <translation>Tamil</translation>
    </message>
    <message>
        <source>Telugu</source>
        <translation>Telugu</translation>
    </message>
    <message>
        <source>Kannada</source>
        <translation>Canarés</translation>
    </message>
    <message>
        <source>Malayalam</source>
        <translation>Malabar</translation>
    </message>
    <message>
        <source>Sinhala</source>
        <translation>Cingalés</translation>
    </message>
    <message>
        <source>Thai</source>
        <translation>Tailandés</translation>
    </message>
    <message>
        <source>Lao</source>
        <translation>Lao</translation>
    </message>
    <message>
        <source>Tibetan</source>
        <translation>Tibetano</translation>
    </message>
    <message>
        <source>Myanmar</source>
        <translation>Birmano</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Georgiano</translation>
    </message>
    <message>
        <source>Khmer</source>
        <translation>Jemer</translation>
    </message>
    <message>
        <source>Simplified Chinese</source>
        <translation>Chino Simplificado</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Chino Tradicional</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonés</translation>
    </message>
    <message>
        <source>Korean</source>
        <translation>Coreano</translation>
    </message>
    <message>
        <source>Vietnamese</source>
        <translation>Vietnamita</translation>
    </message>
    <message>
        <source>Symbol</source>
        <translation>Símbolo</translation>
    </message>
    <message>
        <source>Ogham</source>
        <translation>Ogam</translation>
    </message>
    <message>
        <source>Runic</source>
        <translation>Rúnico</translation>
    </message>
    <message>
        <source>N&apos;Ko</source>
        <translation>N&apos;Ko</translation>
    </message>
</context>
<context>
    <name>QFontDialog</name>
    <message>
        <source>Select Font</source>
        <translation>Seleccionar un tipo de letra</translation>
    </message>
    <message>
        <source>&amp;Font</source>
        <translation>&amp;Tipo de letra</translation>
    </message>
    <message>
        <source>Font st&amp;yle</source>
        <translation>&amp;Estilo del tipo de letra</translation>
    </message>
    <message>
        <source>&amp;Size</source>
        <translation>&amp;Tamaño</translation>
    </message>
    <message>
        <source>Effects</source>
        <translation>Efectos</translation>
    </message>
    <message>
        <source>Stri&amp;keout</source>
        <translation>&amp;Tachado</translation>
    </message>
    <message>
        <source>&amp;Underline</source>
        <translation>S&amp;ubrayado</translation>
    </message>
    <message>
        <source>Sample</source>
        <translation>Muestra</translation>
    </message>
    <message>
        <source>Wr&amp;iting System</source>
        <translation>Sistema de escr&amp;itura</translation>
    </message>
</context>
<context>
    <name>QGnomeTheme</name>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Guardar</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <source>Close without Saving</source>
        <translation>Cerrar sin guardar</translation>
    </message>
</context>
<context>
    <name>QGuiApplication</name>
    <message>
        <source>QT_LAYOUT_DIRECTION</source>
        <comment>Translate this string to the string &apos;LTR&apos; in left-to-right languages or to &apos;RTL&apos; in right-to-left languages (such as Hebrew and Arabic) to get proper widget layout.</comment>
        <translation>LTR</translation>
    </message>
    <message>
        <source>QPA plugin. See QGuiApplication documentation for available options for each plugin.</source>
        <translation>Plugin QPA. Consulte la documentación de QGuiApplication para las opciones disponibles para cada plugin.</translation>
    </message>
    <message>
        <source>Path to the platform plugins.</source>
        <translation>Ruta a los complementos de la plataforma.</translation>
    </message>
    <message>
        <source>Platform theme.</source>
        <translation>Tema de la plataforma.</translation>
    </message>
    <message>
        <source>Additional plugins to load, can be specified multiple times.</source>
        <translation>Complementos adicionales para cargar, se pueden especificar múltiples veces.</translation>
    </message>
    <message>
        <source>Window geometry for the main window, using the X11-syntax, like 100x100+50+50.</source>
        <translation>Geometría de la ventana para la ventana principal, usando la sintaxis X11, como 100x100+50+50.</translation>
    </message>
    <message>
        <source>Default window icon.</source>
        <translation>Icono de ventana predeterminado.</translation>
    </message>
    <message>
        <source>Title of the first window.</source>
        <translation>Título de la primera ventana.</translation>
    </message>
    <message>
        <source>Sets the application&apos;s layout direction to Qt::RightToLeft (debugging helper).</source>
        <translation>Establece la dirección de diseño de la aplicación a Qt::RightToLeft (ayuda para depuración).</translation>
    </message>
    <message>
        <source>Restores the application from an earlier session.</source>
        <translation>Restaura la aplicación desde una sesión anterior.</translation>
    </message>
    <message>
        <source>Display name, overrides $DISPLAY.</source>
        <translation>Nombre de pantalla, sobrescribe $DISPLAY.</translation>
    </message>
    <message>
        <source>Instance name according to ICCCM 4.1.2.5.</source>
        <translation>Nombre de instancia según ICCCM 4.1.2.5.</translation>
    </message>
    <message>
        <source>Disable mouse grabbing (useful in debuggers).</source>
        <translation>Desactivar captura del ratón (útil en depuradores).</translation>
    </message>
    <message>
        <source>Force mouse grabbing (even when running in a debugger).</source>
        <translation>Forzar captura del ratón (incluso cuando se ejecuta en un depurador).</translation>
    </message>
    <message>
        <source>ID of the X11 Visual to use.</source>
        <translation>ID del Visual X11 a usar.</translation>
    </message>
    <message>
        <source>Alias for --qwindowgeometry.</source>
        <translation>Alias para --qwindowgeometry.</translation>
    </message>
    <message>
        <source>Alias for --qwindowicon.</source>
        <translation>Alias para --qwindowicon.</translation>
    </message>
    <message>
        <source>Alias for --qwindowtitle.</source>
        <translation>Alias para --qwindowtitle.</translation>
    </message>
</context>
<context>
    <name>QHostInfo</name>
    <message>
        <source>No host name given</source>
        <translation>No se dio nombre de equipo</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
</context>
<context>
    <name>QHostInfoAgent</name>
    <message>
        <source>No host name given</source>
        <translation>No se dio nombre de equipo</translation>
    </message>
    <message>
        <source>Invalid hostname</source>
        <translation>Nombre de equipo inválido</translation>
    </message>
    <message>
        <source>Unknown address type</source>
        <translation>Dirección de tipo desconocido</translation>
    </message>
    <message>
        <source>Host not found</source>
        <translation>Equipo no encontrado</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <source>Host %1 not found</source>
        <translation>Equipo %1 no encontrado</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>Conexión rechazada</translation>
    </message>
    <message>
        <source>Connection closed</source>
        <translation>Conexión cerrada</translation>
    </message>
    <message>
        <source>Proxy requires authentication</source>
        <translation>El proxy requiere autenticación</translation>
    </message>
    <message>
        <source>Host requires authentication</source>
        <translation>El servidor requiere autenticación</translation>
    </message>
    <message>
        <source>Data corrupted</source>
        <translation>Datos corruptos</translation>
    </message>
    <message>
        <source>Unknown protocol specified</source>
        <translation>Protocolo especificado desconocido</translation>
    </message>
    <message>
        <source>SSL handshake failed</source>
        <translation>Falló el handshake SSL</translation>
    </message>
    <message>
        <source>Too many redirects</source>
        <translation>Demasiadas redirecciones</translation>
    </message>
    <message>
        <source>Insecure redirect</source>
        <translation>Redirección insegura</translation>
    </message>
    <message>
        <source>Unsupported content encoding: %1</source>
        <translation>Codificación de contenido no soportada: %1</translation>
    </message>
    <message>
        <source>Failed to initialize the compression decoder.</source>
        <translation>Error al inicializar el decodificador de compresión.</translation>
    </message>
    <message>
        <source>The decompressed output exceeds the limits specified by QNetworkRequest::decompressedSafetyCheckThreshold()</source>
        <translation>La salida descomprimida excede los límites especificados por QNetworkRequest::decompressedSafetyCheckThreshold()</translation>
    </message>
    <message>
        <source>Decompression failed: %1</source>
        <translation>Descompresión fallida: %1</translation>
    </message>
    <message>
        <source>Data downloaded is too large to store</source>
        <translation>Los datos descargados son demasiado grandes para almacenar</translation>
    </message>
    <message>
        <source>Failed to initialize decompression: %1</source>
        <translation>Fallo al inicializar la descompresión: %1</translation>
    </message>
</context>
<context>
    <name>QHttpSocketEngine</name>
    <message>
        <source>Did not receive HTTP response from proxy</source>
        <translation>Respuesta HTTP no recibida del proxy</translation>
    </message>
    <message>
        <source>Error parsing authentication request from proxy</source>
        <translation>Error durante el análisis sintáctico de la petición de autenticación del proxy</translation>
    </message>
    <message>
        <source>Authentication required</source>
        <translation>Se precisa autenticación</translation>
    </message>
    <message>
        <source>Proxy denied connection</source>
        <translation>El proxy denegó la conexión</translation>
    </message>
    <message>
        <source>Error communicating with HTTP proxy</source>
        <translation>Error comunicando con el proxy HTTP</translation>
    </message>
    <message>
        <source>Proxy server not found</source>
        <translation>Servidor proxy no encontrado</translation>
    </message>
    <message>
        <source>Proxy connection refused</source>
        <translation>Conexión con proxy rechazada</translation>
    </message>
    <message>
        <source>Proxy server connection timed out</source>
        <translation>El tiempo de conexión con el servidor proxy ha expirado</translation>
    </message>
    <message>
        <source>Proxy connection closed prematurely</source>
        <translation>La conexión con el proxy se cerró prematuramente</translation>
    </message>
</context>
<context>
    <name>QIBaseDriver</name>
    <message>
        <source>Error opening database</source>
        <translation>Error al abrir la base de datos</translation>
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation>No fue posible iniciar la transacción</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Incapaz de enviar la transacción</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Incapaz de anular la transacción</translation>
    </message>
    <message>
        <source>Could not subscribe to event notifications for %1.</source>
        <translation>No se pudo suscribir a las notificaciones de eventos para %1.</translation>
    </message>
    <message>
        <source>Could not unsubscribe from event notifications for %1.</source>
        <translation>No se pudo cancelar la suscripción a las notificaciones de eventos para %1.</translation>
    </message>
</context>
<context>
    <name>QIBaseResult</name>
    <message>
        <source>Unable to create BLOB</source>
        <translation>Imposible crear un BLOB</translation>
    </message>
    <message>
        <source>Unable to write BLOB</source>
        <translation>Imposible escribir el BLOB</translation>
    </message>
    <message>
        <source>Unable to open BLOB</source>
        <translation>Imposible abrir el BLOB</translation>
    </message>
    <message>
        <source>Unable to read BLOB</source>
        <translation>Imposible leer el BLOB</translation>
    </message>
    <message>
        <source>Could not find array</source>
        <translation>No fue posible encontrar la tabla</translation>
    </message>
    <message>
        <source>Could not get array data</source>
        <translation>No fue posible obtener los datos de la tabla</translation>
    </message>
    <message>
        <source>Array size mismatch. Field name: %3, expected size: %1. Supplied size: %2</source>
        <translation>Incompatibilidad de tamaño del arreglo. Nombre del campo: %3, tamaño esperado: %1. Tamaño suministrado: %2</translation>
    </message>
    <message>
        <source>Array dimensions mismatch. Field name: %1</source>
        <translation>Incompatibilidad de dimensiones del arreglo. Nombre del campo: %1</translation>
    </message>
    <message>
        <source>Array size mismatch: size of %1 is %2, size of provided list is %3</source>
        <translation>Incompatibilidad de tamaño del arreglo: el tamaño de %1 es %2, el tamaño de la lista proporcionada es %3</translation>
    </message>
    <message>
        <source>Could not get query info</source>
        <translation>No fue posible obtener información sobre la consulta</translation>
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation>No fue posible iniciar la transacción</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Incapaz de enviar la transacción</translation>
    </message>
    <message>
        <source>Could not allocate statement</source>
        <translation>No fue posible asignar la instrucción</translation>
    </message>
    <message>
        <source>Could not prepare statement</source>
        <translation>No fue posible preparar la instrucción</translation>
    </message>
    <message>
        <source>Could not describe input statement</source>
        <translation>No fue posible describir la instrucción de entrada</translation>
    </message>
    <message>
        <source>Could not describe statement</source>
        <translation>No fue posible describir la instrucción</translation>
    </message>
    <message>
        <source>Unable to close statement</source>
        <translation>No fue posible cerrar la instrucción</translation>
    </message>
    <message>
        <source>Unable to execute query</source>
        <translation>No fue posible ejecutar la consulta</translation>
    </message>
    <message>
        <source>Could not fetch next item</source>
        <translation>No fue posible obtener el elemento siguiente</translation>
    </message>
    <message>
        <source>Could not get statement info</source>
        <translation>No fue posible obtener información sobre la instrucción</translation>
    </message>
</context>
<context>
    <name>QIODevice</name>
    <message>
        <source>Permission denied</source>
        <translation>Permiso denegado</translation>
    </message>
    <message>
        <source>Too many open files</source>
        <translation>Demasiados ficheros abiertos simultáneamente</translation>
    </message>
    <message>
        <source>No such file or directory</source>
        <translation>No hay ningún fichero o directorio con ese nombre</translation>
    </message>
    <message>
        <source>No space left on device</source>
        <translation>No queda espacio en el dispositivo</translation>
    </message>
    <message>
        <source>file to open is a directory</source>
        <translation>el archivo a abrir es un directorio</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
</context>
<context>
    <name>QImageReader</name>
    <message>
        <source>Invalid device</source>
        <translation>Dispositivo inválido</translation>
    </message>
    <message>
        <source>File not found</source>
        <translation>Archivo no encontrado</translation>
    </message>
    <message>
        <source>Unsupported image format</source>
        <translation>Formato de imagen no soportado</translation>
    </message>
    <message>
        <source>Unable to read image data</source>
        <translation>No se puede leer los datos de la imagen</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
</context>
<context>
    <name>QImageWriter</name>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
    <message>
        <source>Device is not set</source>
        <translation>El dispositivo no está listo</translation>
    </message>
    <message>
        <source>Cannot open device for writing: %1</source>
        <translation>No se puede abrir el dispositivo para escritura: %1</translation>
    </message>
    <message>
        <source>Device not writable</source>
        <translation>Dispositivo no escribible</translation>
    </message>
    <message>
        <source>Unsupported image format</source>
        <translation>Formato de imagen no soportado</translation>
    </message>
    <message>
        <source>Image is empty</source>
        <translation>La imagen está vacía</translation>
    </message>
</context>
<context>
    <name>QInputDialog</name>
    <message>
        <source>Enter a value:</source>
        <translation>Introduzca un valor:</translation>
    </message>
</context>
<context>
    <name>QJsonParseError</name>
    <message>
        <source>no error occurred</source>
        <translation>no se ha producido ningún error</translation>
    </message>
    <message>
        <source>unterminated object</source>
        <translation>objeto no terminado</translation>
    </message>
    <message>
        <source>missing name separator</source>
        <translation>falta separador de nombre</translation>
    </message>
    <message>
        <source>unterminated array</source>
        <translation>array no terminado</translation>
    </message>
    <message>
        <source>missing value separator</source>
        <translation>falta separador de valores</translation>
    </message>
    <message>
        <source>illegal value</source>
        <translation>valor ilegal</translation>
    </message>
    <message>
        <source>invalid termination by number</source>
        <translation>terminación inválida por número</translation>
    </message>
    <message>
        <source>illegal number</source>
        <translation>número ilegal</translation>
    </message>
    <message>
        <source>invalid escape sequence</source>
        <translation>secuencia de escape inválida</translation>
    </message>
    <message>
        <source>invalid UTF8 string</source>
        <translation>cadena de texto UTF8 inválida</translation>
    </message>
    <message>
        <source>unterminated string</source>
        <translation>cadena de texto no terminada</translation>
    </message>
    <message>
        <source>object is missing after a comma</source>
        <translation>falta el objeto tras la coma</translation>
    </message>
    <message>
        <source>too deeply nested document</source>
        <translation>documento con demasiados elementos anidados</translation>
    </message>
    <message>
        <source>too large document</source>
        <translation>documento demasiado grande</translation>
    </message>
    <message>
        <source>garbage at the end of the document</source>
        <translation>basura al final del documento</translation>
    </message>
</context>
<context>
    <name>QKeySequenceEdit</name>
    <message>
        <source>Press shortcut</source>
        <translation>Presione el atajo de teclado</translation>
    </message>
    <message>
        <source>%1, ...</source>
        <extracomment>This text is an &quot;unfinished&quot; shortcut, expands like &quot;Ctrl+A, ...&quot;</extracomment>
        <translation>%1, ...</translation>
    </message>
</context>
<context>
    <name>QLibrary</name>
    <message>
        <source>Failed to extract plugin meta data from &apos;%1&apos;: %2</source>
        <translation>No se pudo extraer los metadatos del complemento de &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <source>The shared library was not found.</source>
        <translation>No se ha encontrado la biblioteca compartida.</translation>
    </message>
    <message>
        <source>Could not resolve &apos;qt_plugin_instance&apos; function</source>
        <translation>No se pudo resolver la función &apos;qt_plugin_instance&apos;</translation>
    </message>
    <message>
        <source>metadata too small</source>
        <translation>metadatos demasiado pequeños</translation>
    </message>
    <message>
        <source>entrypoint to query the plugin meta data not found</source>
        <translation>punto de entrada para consultar los metadatos del plugin no encontrado</translation>
    </message>
    <message>
        <source>The file &apos;%1&apos; is not a valid Qt plugin.</source>
        <translation>El fichero «%1» no es un complemento de Qt válido.</translation>
    </message>
    <message>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. (%2.%3.%4) [%5]</source>
        <translation>El complemento «%1» usa una biblioteca Qt incompatible. (%2.%3.%4) [%5]</translation>
    </message>
    <message>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. (Cannot mix debug and release libraries.)</source>
        <translation>El complemento «%1» usa una biblioteca Qt incompatible. (No se pueden mezclar las bibliotecas de «depuración» y de «distribución».)</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
    <message>
        <source>Cannot load library %1: %2</source>
        <translation>No se puede cargar la biblioteca %1: %2</translation>
    </message>
    <message>
        <source>Cannot unload library %1: %2</source>
        <translation>No se puede descargar la biblioteca %1: %2</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid Mach-O binary (%2)</source>
        <translation>«%1» es un binario Mach-O inválido (%2)</translation>
    </message>
    <message>
        <source>file is corrupt</source>
        <translation>el archivo está corrupto</translation>
    </message>
    <message>
        <source>file is for the wrong endianness</source>
        <translation>el archivo es para un endianness incorrecto</translation>
    </message>
    <message>
        <source>file has an unknown ELF version</source>
        <translation>el archivo tiene una versión ELF desconocida</translation>
    </message>
    <message>
        <source>file has an unexpected ABI</source>
        <translation>el archivo tiene un ABI inesperado</translation>
    </message>
    <message>
        <source>file is not a shared object</source>
        <translation>el archivo no es un objeto compartido</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid ELF object (%2)</source>
        <translation>&apos;%1&apos; no es un objeto ELF válido (%2)</translation>
    </message>
    <message>
        <source>unimplemented: PN_XNUM program headers</source>
        <translation>no implementado: encabezados de programa PN_XNUM</translation>
    </message>
    <message>
        <source>program header table extends past the end of the file</source>
        <translation>la tabla de encabezados de programa se extiende más allá del final del archivo</translation>
    </message>
    <message>
        <source>a program header entry extends past the end of the file</source>
        <translation>una entrada del encabezado del programa se extiende más allá del final del archivo</translation>
    </message>
    <message>
        <source>a note segment start is not properly aligned (offset 0x%1, alignment %2)</source>
        <translation>el inicio de un segmento de nota no está alineado correctamente (desplazamiento 0x%1, alineación %2)</translation>
    </message>
    <message>
        <source>section table extends past the end of the file</source>
        <translation>la tabla de secciones se extiende más allá del final del archivo</translation>
    </message>
    <message>
        <source>section header string table extends past the end of the file</source>
        <translation>la tabla de cadenas del encabezado de sección se extiende más allá del final del archivo</translation>
    </message>
    <message>
        <source>a section name extends past the end of the file</source>
        <translation>un nombre de sección se extiende más allá del final del archivo</translation>
    </message>
    <message>
        <source>file too small</source>
        <translation>archivo demasiado pequeño</translation>
    </message>
    <message>
        <source>unexpected program header entry size (%1)</source>
        <translation>tamaño inesperado de entrada del encabezado del programa (%1)</translation>
    </message>
    <message>
        <source>unexpected section entry size (%1)</source>
        <translation>tamaño inesperado de entrada de sección (%1)</translation>
    </message>
    <message>
        <source>e_shstrndx greater than the number of sections e_shnum (%1 &gt;= %2)</source>
        <translation>e_Shstrndx mayor que el número de secciones e_Shnum (%1 &gt;= %2)</translation>
    </message>
    <message>
        <source>no suitable architecture in fat binary</source>
        <translation>no hay una arquitectura válida en el fat binary</translation>
    </message>
    <message>
        <source>invalid magic %1</source>
        <translation>Magic inválido %1</translation>
    </message>
    <message>
        <source>wrong architecture</source>
        <translation>arquitectura incorrecta</translation>
    </message>
    <message>
        <source>not a dynamic library</source>
        <translation>no es una biblioteca dinámica</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a Qt plugin</source>
        <translation>«%1» no es un plugin de Qt</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid Windows DLL (%2)</source>
        <translation>&apos;%1&apos; no es una DLL de Windows válida (%2)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is too small</source>
        <translation>&apos;%1&apos; es demasiado pequeño</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a Qt plugin (%2)</source>
        <translation>&apos;%1&apos; no es un complemento Qt (%2)</translation>
    </message>
    <message>
        <source>metadata not found</source>
        <translation>metadatos no encontrados</translation>
    </message>
    <message>
        <source>invalid signature</source>
        <translation>firma inválida</translation>
    </message>
    <message>
        <source>file is for a different processor</source>
        <translation>el archivo es para un procesador diferente</translation>
    </message>
    <message>
        <source>file has no sections</source>
        <translation>el archivo no tiene secciones</translation>
    </message>
    <message>
        <source>wrong characteristics</source>
        <translation>características incorrectas</translation>
    </message>
    <message>
        <source>file is for a different word size</source>
        <translation>el archivo es para un tamaño de palabra diferente</translation>
    </message>
    <message>
        <source>file has no code</source>
        <translation>el archivo no tiene código</translation>
    </message>
    <message>
        <source>a section name is empty or extends past the end of the file</source>
        <translation>un nombre de sección está vacío o se extiende más allá del final del archivo</translation>
    </message>
    <message>
        <source>section contents extend past the end of the file</source>
        <translation>el contenido de la sección se extiende más allá del final del archivo</translation>
    </message>
    <message>
        <source>.qtmetadata section is too small</source>
        <translation>La sección .qtmetadata es demasiado pequeña</translation>
    </message>
    <message>
        <source>.qtmetadata section has incorrect magic</source>
        <translation>La sección .qtmetadata tiene una magia incorrecta</translation>
    </message>
    <message>
        <source>.qtmetadata section is writable</source>
        <translation>La sección .qtmetadata es escribible</translation>
    </message>
    <message>
        <source>.qtmetadata section is executable</source>
        <translation>La sección .qtmetadata es ejecutable</translation>
    </message>
</context>
<context>
    <name>QLineEdit</name>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Deshacer</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Rehacer</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>Cor&amp;tar</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Pegar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Seleccionar todo</translation>
    </message>
</context>
<context>
    <name>QLocalServer</name>
    <message>
        <source>%1: Name error</source>
        <translation>%1: Error de nombre</translation>
    </message>
    <message>
        <source>%1: Permission denied</source>
        <translation>%1: Permiso denegado</translation>
    </message>
    <message>
        <source>%1: Address in use</source>
        <translation>%1: Dirección en uso</translation>
    </message>
    <message>
        <source>%1: Unknown error %2</source>
        <translation>%1: Error desconocido %2</translation>
    </message>
</context>
<context>
    <name>QLocalSocket</name>
    <message>
        <source>%1: Connection refused</source>
        <translation>%1: Conexión rechazada</translation>
    </message>
    <message>
        <source>%1: Remote closed</source>
        <translation>%1: Conexión cerrada</translation>
    </message>
    <message>
        <source>%1: Invalid name</source>
        <translation>%1: Nombre inválido</translation>
    </message>
    <message>
        <source>%1: Socket access error</source>
        <translation>%1: Error de acceso al socket</translation>
    </message>
    <message>
        <source>%1: Socket resource error</source>
        <translation>%1: Error en el recurso del socket</translation>
    </message>
    <message>
        <source>%1: Socket operation timed out</source>
        <translation>%1: El tiempo de espera en la operación con el socket ha expirado</translation>
    </message>
    <message>
        <source>%1: Datagram too large</source>
        <translation>%1: Datagrama demasiado grande</translation>
    </message>
    <message>
        <source>%1: Connection error</source>
        <translation>%1: Error de conexión</translation>
    </message>
    <message>
        <source>%1: The socket operation is not supported</source>
        <translation>%1: La operación con el socket no está soportada</translation>
    </message>
    <message>
        <source>%1: Operation not permitted when socket is in this state</source>
        <translation>%1: Operación no permitida cuando el socket se encuentra en este estado</translation>
    </message>
    <message>
        <source>%1: Unknown error</source>
        <translation>%1: Error desconocido</translation>
    </message>
    <message>
        <source>Trying to connect while connection is in progress</source>
        <translation>Intentando conectar mientras la conexión está en progreso</translation>
    </message>
    <message>
        <source>%1: Unknown error %2</source>
        <translation>%1: Error desconocido %2</translation>
    </message>
    <message>
        <source>%1: Access denied</source>
        <translation>%1: Acceso denegado</translation>
    </message>
    <message>
        <source>Socket is not connected</source>
        <translation>El socket no está conectado</translation>
    </message>
    <message>
        <source>Remote closed</source>
        <translation>Cerrado por remoto</translation>
    </message>
</context>
<context>
    <name>QMYSQLDriver</name>
    <message>
        <source>Unable to allocate a MYSQL object</source>
        <translation>No ha sido posible reservar un objeto MYSQL</translation>
    </message>
    <message>
        <source>Unable to open database &apos;%1&apos;</source>
        <translation>No se puede abrir la base de datos «%1»</translation>
    </message>
    <message>
        <source>Unable to connect</source>
        <translation>No es posible establecer una conexión</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>No es posible iniciar la transacción</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No es posible enviar la transacción</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No es posible anular la transacción</translation>
    </message>
</context>
<context>
    <name>QMYSQLResult</name>
    <message>
        <source>Unable to fetch data</source>
        <translation>No es posible obtener los datos</translation>
    </message>
    <message>
        <source>Unable to execute query</source>
        <translation>No es posible ejecutar la consulta</translation>
    </message>
    <message>
        <source>Unable to store result</source>
        <translation>No es posible almacenar el resultado</translation>
    </message>
    <message>
        <source>Unable to execute next query</source>
        <translation>No se puede ejecutar la siguiente consulta</translation>
    </message>
    <message>
        <source>Unable to store next result</source>
        <translation>No se puede almacenar el siguiente resultado</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>No es posible preparar la instrucción</translation>
    </message>
    <message>
        <source>Unable to reset statement</source>
        <translation>No es posible reinicializar la instrucción</translation>
    </message>
    <message>
        <source>Unable to bind value</source>
        <translation>No es posible ligar el valor</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>No es posible ejecutar la instrucción</translation>
    </message>
    <message>
        <source>Unable to bind outvalues</source>
        <translation>No es posible ligar los valores de salida</translation>
    </message>
    <message>
        <source>Unable to store statement results</source>
        <translation>No es posible almacenar los resultados de la instrucción</translation>
    </message>
</context>
<context>
    <name>QMdiArea</name>
    <message>
        <source>(Untitled)</source>
        <translation>(Sin título)</translation>
    </message>
</context>
<context>
    <name>QMdiSubWindow</name>
    <message>
        <source>- [%1]</source>
        <translation>- [%1]</translation>
    </message>
    <message>
        <source>%1 - [%2]</source>
        <translation>%1 - [%2]</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Minimizar</translation>
    </message>
    <message>
        <source>Maximize</source>
        <translation>Maximizar</translation>
    </message>
    <message>
        <source>Unshade</source>
        <translation>Des-colapsar</translation>
    </message>
    <message>
        <source>Shade</source>
        <translation>Colapsar</translation>
    </message>
    <message>
        <source>Restore Down</source>
        <translation>Restaurar abajo</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Restaurar</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>Menú</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Restaurar</translation>
    </message>
    <message>
        <source>&amp;Move</source>
        <translation>&amp;Mover</translation>
    </message>
    <message>
        <source>&amp;Size</source>
        <translation>Redimen&amp;sionar</translation>
    </message>
    <message>
        <source>Mi&amp;nimize</source>
        <translation>Mi&amp;nimizar</translation>
    </message>
    <message>
        <source>Ma&amp;ximize</source>
        <translation>Ma&amp;ximizar</translation>
    </message>
    <message>
        <source>Stay on &amp;Top</source>
        <translation>Permanecer en &amp;primer plano</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Show Details...</source>
        <translation>Mostrar los detalles...</translation>
    </message>
    <message>
        <source>Hide Details...</source>
        <translation>Ocultar los detalles...</translation>
    </message>
    <message>
        <source>&lt;h3&gt;About Qt&lt;/h3&gt;&lt;p&gt;This program uses Qt version %1.&lt;/p&gt;</source>
        <translation>&lt;h3&gt;Acerca de Qt&lt;/h3&gt;&lt;p&gt;Este programa usa Qt versión %1.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across all major desktop operating systems. It is also available for embedded Linux and other embedded and mobile operating systems.&lt;/p&gt;&lt;p&gt;Qt is available under multiple licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of GNU (L)GPL.&lt;/p&gt;&lt;p&gt;Qt licensed under GNU (L)GPL is appropriate for the development of Qt&amp;nbsp;applications provided you can comply with the terms and conditions of the respective licenses.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;https://%2/&quot;&gt;%2&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) The Qt Company Ltd. and other contributors.&lt;/p&gt;&lt;p&gt;Qt and the Qt logo are trademarks of The Qt Company Ltd.&lt;/p&gt;&lt;p&gt;Qt is The Qt Company Ltd. product developed as an open source project. See &lt;a href=&quot;https://%3/&quot;&gt;%3&lt;/a&gt; for more information.&lt;/p&gt;</source>
        <extracomment>Leave this text untranslated or include a verbatim copy of it below and note that it is the authoritative version in case of doubt.</extracomment>
        <translation></translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Acerca de Qt</translation>
    </message>
</context>
<context>
    <name>QNativeSocketEngine</name>
    <message>
        <source>Unable to initialize non-blocking socket</source>
        <translation>Imposible inicializar el socket no bloqueante</translation>
    </message>
    <message>
        <source>Unable to initialize broadcast socket</source>
        <translation>Imposible inicializar el socket de difusión</translation>
    </message>
    <message>
        <source>Attempt to use IPv6 socket on a platform with no IPv6 support</source>
        <translation>Intento de usar un socket IPv6 sobre una plataforma que no contempla IPv6</translation>
    </message>
    <message>
        <source>The remote host closed the connection</source>
        <translation>El equipo remoto ha cerrado la conexión</translation>
    </message>
    <message>
        <source>Network operation timed out</source>
        <translation>La operación de red ha expirado</translation>
    </message>
    <message>
        <source>Out of resources</source>
        <translation>Insuficientes recursos</translation>
    </message>
    <message>
        <source>Unsupported socket operation</source>
        <translation>Operación socket no admitida</translation>
    </message>
    <message>
        <source>Protocol type not supported</source>
        <translation>Tipo de protocolo no admitido</translation>
    </message>
    <message>
        <source>Invalid socket descriptor</source>
        <translation>Descriptor de socket no válido</translation>
    </message>
    <message>
        <source>Host unreachable</source>
        <translation>Equipo inaccesible</translation>
    </message>
    <message>
        <source>Network unreachable</source>
        <translation>Red inalcanzable</translation>
    </message>
    <message>
        <source>Permission denied</source>
        <translation>Permiso denegado</translation>
    </message>
    <message>
        <source>Connection timed out</source>
        <translation>Conexión expirada</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>Conexión rechazada</translation>
    </message>
    <message>
        <source>The bound address is already in use</source>
        <translation>La dirección enlazada ya está en uso</translation>
    </message>
    <message>
        <source>The address is not available</source>
        <translation>La dirección no está disponible</translation>
    </message>
    <message>
        <source>The address is protected</source>
        <translation>La dirección está protegida</translation>
    </message>
    <message>
        <source>Datagram was too large to send</source>
        <translation>El datagrama era demasiado grande para poder ser enviado</translation>
    </message>
    <message>
        <source>Unable to send a message</source>
        <translation>Imposible enviar un mensaje</translation>
    </message>
    <message>
        <source>Unable to receive a message</source>
        <translation>Imposible recibir un mensaje</translation>
    </message>
    <message>
        <source>Unable to write</source>
        <translation>Imposible escribir</translation>
    </message>
    <message>
        <source>Network error</source>
        <translation>Error de red</translation>
    </message>
    <message>
        <source>Another socket is already listening on the same port</source>
        <translation>Ya hay otro socket escuchando por el mismo puerto</translation>
    </message>
    <message>
        <source>Operation on non-socket</source>
        <translation>Operación sobre un no-socket</translation>
    </message>
    <message>
        <source>The proxy type is invalid for this operation</source>
        <translation>El tipo de proxy es inváildo para esta operación</translation>
    </message>
    <message>
        <source>Temporary error</source>
        <translation>Error temporal</translation>
    </message>
    <message>
        <source>Network dropped connection on reset</source>
        <translation>La red cerró la conexión al resetear</translation>
    </message>
    <message>
        <source>Connection reset by peer</source>
        <translation>Conexión reiniciada</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessCacheBackend</name>
    <message>
        <source>Error opening %1</source>
        <translation>Error abriendo %1</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessDataBackend</name>
    <message>
        <source>Invalid URI: %1</source>
        <translation>URI inválida: %1</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessDebugPipeBackend</name>
    <message>
        <source>Write error writing to %1: %2</source>
        <translation>Error de escritura escribiendo en %1: %2</translation>
    </message>
    <message>
        <source>Socket error on %1: %2</source>
        <translation>Error de socket en %1: %2</translation>
    </message>
    <message>
        <source>Remote host closed the connection prematurely on %1</source>
        <translation>El equipo remoto cerró la conexión prematuramente en %1</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessFileBackend</name>
    <message>
        <source>Request for opening non-local file %1</source>
        <translation>Petición para abrir el archivo no local %1</translation>
    </message>
    <message>
        <source>Error opening %1: %2</source>
        <translation>Error abriendo %1: %2</translation>
    </message>
    <message>
        <source>Write error writing to %1: %2</source>
        <translation>Error de escritura al escribir en %1: %2</translation>
    </message>
    <message>
        <source>Cannot open %1: Path is a directory</source>
        <translation>No se puede abrir %1: La ruta es un directorio</translation>
    </message>
    <message>
        <source>Read error reading from %1: %2</source>
        <translation>Error de lectura leyendo de %1: %2</translation>
    </message>
</context>
<context>
    <name>QNetworkReply</name>
    <message>
        <source>Error transferring %1 - server replied: %2</source>
        <translation>Error transfiriendo %1- el servidor respondió: %2</translation>
    </message>
    <message>
        <source>backend start error.</source>
        <translation>error de iniciación de backend.</translation>
    </message>
    <message>
        <source>Protocol &quot;%1&quot; is unknown</source>
        <translation>Protocolo %1 desconocido</translation>
    </message>
</context>
<context>
    <name>QNetworkReplyHttpImpl</name>
    <message>
        <source>Operation canceled</source>
        <translation>Operación cancelada</translation>
    </message>
    <message>
        <source>No suitable proxy found</source>
        <translation>No se encontró un proxy válido</translation>
    </message>
</context>
<context>
    <name>QNetworkReplyImpl</name>
    <message>
        <source>Operation canceled</source>
        <translation>Operación cancelada</translation>
    </message>
</context>
<context>
    <name>QOCIDriver</name>
    <message>
        <source>Unable to initialize</source>
        <comment>QOCIDriver</comment>
        <translation>La inicialización ha fallado</translation>
    </message>
    <message>
        <source>Unable to logon</source>
        <translation>No es posible abrir sesión</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>No es posible iniciar la transacción</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No es posible enviar la transacción</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No se puede revertir la transacción</translation>
    </message>
</context>
<context>
    <name>QOCIResult</name>
    <message>
        <source>Unable to bind column for batch execute</source>
        <translation>No es posible ligar la columna para una ejecución por lotes</translation>
    </message>
    <message>
        <source>Unable to execute batch statement</source>
        <translation>No es posible ejecutar la instrucción por lotes</translation>
    </message>
    <message>
        <source>Unable to goto next</source>
        <translation>No es posible pasar al siguiente</translation>
    </message>
    <message>
        <source>Unable to alloc statement</source>
        <translation>No es posible asignar la instrucción</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>No es posible preparar la instrucción</translation>
    </message>
    <message>
        <source>Unable to get statement type</source>
        <translation>No se ha podido obtener el tipo de instrucción</translation>
    </message>
    <message>
        <source>Unable to bind value</source>
        <translation>No es posible ligar el valor</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>No es posible ejecutar la instrucción</translation>
    </message>
</context>
<context>
    <name>QODBCDriver</name>
    <message>
        <source>Unable to connect</source>
        <translation>No es posible establecer una conexión</translation>
    </message>
    <message>
        <source>Unable to connect - Driver doesn&apos;t support all functionality required</source>
        <translation>No se puede conectar - El driver no soporta toda la funcionalidad requerida</translation>
    </message>
    <message>
        <source>Unable to disable autocommit</source>
        <translation>No es posible inhabilitar el envío automático</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No es posible enviar la transacción</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No es posible anular la transacción</translation>
    </message>
    <message>
        <source>Unable to enable autocommit</source>
        <translation>No es posible habilitar el envío automático</translation>
    </message>
</context>
<context>
    <name>QODBCResult</name>
    <message>
        <source>Unable to fetch last</source>
        <translation>No se ha podido recuperar el último</translation>
    </message>
    <message>
        <source>QODBCResult::reset: Unable to set &apos;SQL_CURSOR_STATIC&apos; as statement attribute. Please check your ODBC driver configuration</source>
        <translation>QODBCResult::reset: No es posible establecer «SQL_CURSOR_STATIC» como atributo de instrucción. Compruebe la configuración de su controlador ODBC</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>No es posible ejecutar la instrucción</translation>
    </message>
    <message>
        <source>QODBCResult::reset: Unable to set &apos;SQL_ATTR_CURSOR_TYPE&apos; as statement attribute. Please check your ODBC driver configuration</source>
        <translation>QODBCResult::reset: No se puede establecer &apos;SQL_ATTR_CURSOR_TYPE&apos; como atributo de la declaración. Por favor, verifique la configuración de su controlador ODBC</translation>
    </message>
    <message>
        <source>Unable to fetch</source>
        <translation>No se ha podido recuperar</translation>
    </message>
    <message>
        <source>Unable to fetch next</source>
        <translation>No es posible obtener el siguiente</translation>
    </message>
    <message>
        <source>Unable to fetch first</source>
        <translation>No se ha podido recuperar el primero</translation>
    </message>
    <message>
        <source>Unable to fetch previous</source>
        <translation>No se ha podido recuperar el previo</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>No es posible preparar la instrucción</translation>
    </message>
    <message>
        <source>Unable to bind variable</source>
        <translation>No es posible ligar la variable</translation>
    </message>
</context>
<context>
    <name>QPSQLDriver</name>
    <message>
        <source>Unable to connect</source>
        <translation>No es posible establecer conexión</translation>
    </message>
    <message>
        <source>Unable to set client encoding to &apos;UNICODE&apos;</source>
        <translation>No se puede establecer la codificación del cliente a &apos;UNICODE&apos;</translation>
    </message>
    <message>
        <source>Could not begin transaction</source>
        <translation>No fue posible iniciar la transacción</translation>
    </message>
    <message>
        <source>Could not commit transaction</source>
        <translation>No fue posible enviar la transacción</translation>
    </message>
    <message>
        <source>Could not rollback transaction</source>
        <translation>No fue posible anular la transacción</translation>
    </message>
    <message>
        <source>Unable to subscribe</source>
        <translation>No se ha podido dar de subscribir</translation>
    </message>
    <message>
        <source>Unable to unsubscribe</source>
        <translation>No se ha podido de-subscribir</translation>
    </message>
</context>
<context>
    <name>QPSQLResult</name>
    <message>
        <source>Query results lost - probably discarded on executing another SQL query.</source>
        <translation>Resultados de la consulta perdidos - probablemente descartados al ejecutar otra consulta SQL.</translation>
    </message>
    <message>
        <source>Unable to create query</source>
        <translation>No es posible crear la consulta</translation>
    </message>
    <message>
        <source>Unable to get result</source>
        <translation>No se puede obtener el resultado</translation>
    </message>
    <message>
        <source>Unable to send query</source>
        <translation>No se puede enviar la consulta</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>No se ha podido preparar la instrucción</translation>
    </message>
</context>
<context>
    <name>QPageSetupWidget</name>
    <message>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <source>Paper</source>
        <translation>Papel</translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation>Tamaño de página:</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Ancho:</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Alto:</translation>
    </message>
    <message>
        <source>Paper source:</source>
        <translation>Fuente del papel:</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation>Orientación</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Vertical</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Apaisado</translation>
    </message>
    <message>
        <source>Reverse landscape</source>
        <translation>Apaisado invertido</translation>
    </message>
    <message>
        <source>Reverse portrait</source>
        <translation>Vertical invertido</translation>
    </message>
    <message>
        <source>Margins</source>
        <translation>Márgenes</translation>
    </message>
    <message>
        <source>top margin</source>
        <translation>Margen superior</translation>
    </message>
    <message>
        <source>left margin</source>
        <translation>Margen izquierdo</translation>
    </message>
    <message>
        <source>right margin</source>
        <translation>Margen derecho</translation>
    </message>
    <message>
        <source>bottom margin</source>
        <translation>Margen inferior</translation>
    </message>
    <message>
        <source>Page Layout</source>
        <translation>Diseño de página</translation>
    </message>
    <message>
        <source>Page order:</source>
        <translation>Orden de páginas:</translation>
    </message>
    <message>
        <source>Pages per sheet:</source>
        <translation>Páginas por hoja:</translation>
    </message>
    <message>
        <source>Millimeters (mm)</source>
        <translation>Milímetros (mm)</translation>
    </message>
    <message>
        <source>Inches (in)</source>
        <translation>Pulgadas (in)</translation>
    </message>
    <message>
        <source>Points (pt)</source>
        <translation>Puntos (pt)</translation>
    </message>
    <message>
        <source>Pica (P̸)</source>
        <translation>Picas (P̸)</translation>
    </message>
    <message>
        <source>Didot (DD)</source>
        <translation>Didot (DD)</translation>
    </message>
    <message>
        <source>Cicero (CC)</source>
        <translation>Cicero (CC)</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Personalizado</translation>
    </message>
    <message>
        <source>mm</source>
        <extracomment>Unit &apos;Millimeter&apos;</extracomment>
        <translation>mm</translation>
    </message>
    <message>
        <source>pt</source>
        <extracomment>Unit &apos;Points&apos;</extracomment>
        <translation>pt</translation>
    </message>
    <message>
        <source>in</source>
        <extracomment>Unit &apos;Inch&apos;</extracomment>
        <translation>in</translation>
    </message>
    <message>
        <source>P̸</source>
        <extracomment>Unit &apos;Pica&apos;</extracomment>
        <translation>P̸</translation>
    </message>
    <message>
        <source>DD</source>
        <extracomment>Unit &apos;Didot&apos;</extracomment>
        <translation>DD</translation>
    </message>
    <message>
        <source>CC</source>
        <extracomment>Unit &apos;Cicero&apos;</extracomment>
        <translation>CC</translation>
    </message>
</context>
<context>
    <name>QPageSize</name>
    <message>
        <source>Custom (%1mm x %2mm)</source>
        <extracomment>Custom size name in millimeters</extracomment>
        <translation>Personalizado (%1mm x %2mm)</translation>
    </message>
    <message>
        <source>Custom (%1pt x %2pt)</source>
        <extracomment>Custom size name in points</extracomment>
        <translation>Personalizado (%1pt x %2pt)</translation>
    </message>
    <message>
        <source>Custom (%1in x %2in)</source>
        <extracomment>Custom size name in inches</extracomment>
        <translation>Personalizado (%1mm x %2mm)</translation>
    </message>
    <message>
        <source>Custom (%1pc x %2pc)</source>
        <extracomment>Custom size name in picas</extracomment>
        <translation>Personalizado (%1pc x %2pc)</translation>
    </message>
    <message>
        <source>Custom (%1DD x %2DD)</source>
        <extracomment>Custom size name in didots</extracomment>
        <translation>Personalizado (%1DD x %2DD)</translation>
    </message>
    <message>
        <source>Custom (%1CC x %2CC)</source>
        <extracomment>Custom size name in ciceros</extracomment>
        <translation>Personalizado (%1CC x %2CC)</translation>
    </message>
    <message>
        <source>%1 x %2 in</source>
        <extracomment>Page size in &apos;Inch&apos;.</extracomment>
        <translation>%1 x %2 in</translation>
    </message>
    <message>
        <source>A0</source>
        <translation>A0</translation>
    </message>
    <message>
        <source>A1</source>
        <translation>A1</translation>
    </message>
    <message>
        <source>A2</source>
        <translation>A2</translation>
    </message>
    <message>
        <source>A3</source>
        <translation>A3</translation>
    </message>
    <message>
        <source>A4</source>
        <translation>A4</translation>
    </message>
    <message>
        <source>A5</source>
        <translation>A5</translation>
    </message>
    <message>
        <source>A6</source>
        <translation>A6</translation>
    </message>
    <message>
        <source>A7</source>
        <translation>A7</translation>
    </message>
    <message>
        <source>A8</source>
        <translation>A8</translation>
    </message>
    <message>
        <source>A9</source>
        <translation>A9</translation>
    </message>
    <message>
        <source>A10</source>
        <translation>A10</translation>
    </message>
    <message>
        <source>B0</source>
        <translation>B0</translation>
    </message>
    <message>
        <source>B1</source>
        <translation>B1</translation>
    </message>
    <message>
        <source>B2</source>
        <translation>B2</translation>
    </message>
    <message>
        <source>B3</source>
        <translation>B3</translation>
    </message>
    <message>
        <source>B4</source>
        <translation>B4</translation>
    </message>
    <message>
        <source>B5</source>
        <translation>B5</translation>
    </message>
    <message>
        <source>B6</source>
        <translation>B6</translation>
    </message>
    <message>
        <source>B7</source>
        <translation>B7</translation>
    </message>
    <message>
        <source>B8</source>
        <translation>B8</translation>
    </message>
    <message>
        <source>B9</source>
        <translation>B9</translation>
    </message>
    <message>
        <source>B10</source>
        <translation>B10</translation>
    </message>
    <message>
        <source>Executive (7.5 x 10 in)</source>
        <translation>Ejecutivo (7.5 x 10 in)</translation>
    </message>
    <message>
        <source>Executive (7.25 x 10.5 in)</source>
        <translation>Ejecutivo (7.25 x 10.5 in)</translation>
    </message>
    <message>
        <source>Folio (8.27 x 13 in)</source>
        <translation>Folio (8.27 x 13 in)</translation>
    </message>
    <message>
        <source>Legal</source>
        <translation>Legal</translation>
    </message>
    <message>
        <source>Letter / ANSI A</source>
        <translation>Carta / ANSI A</translation>
    </message>
    <message>
        <source>Tabloid / ANSI B</source>
        <translation>Tabloide / ANSI B</translation>
    </message>
    <message>
        <source>Ledger / ANSI B</source>
        <translation>Libro mayor / ANSI B</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Personalizado</translation>
    </message>
    <message>
        <source>A3 Extra</source>
        <translation>A3 Extra</translation>
    </message>
    <message>
        <source>A4 Extra</source>
        <translation>A4 Extra</translation>
    </message>
    <message>
        <source>A4 Plus</source>
        <translation>A4 Plus</translation>
    </message>
    <message>
        <source>A4 Small</source>
        <translation>A4 Pequeño</translation>
    </message>
    <message>
        <source>A5 Extra</source>
        <translation>A5 Extra</translation>
    </message>
    <message>
        <source>B5 Extra</source>
        <translation>B5 Extra</translation>
    </message>
    <message>
        <source>JIS B0</source>
        <translation>JIS B0</translation>
    </message>
    <message>
        <source>JIS B1</source>
        <translation>JIS B1</translation>
    </message>
    <message>
        <source>JIS B2</source>
        <translation>JIS B2</translation>
    </message>
    <message>
        <source>JIS B3</source>
        <translation>JIS B3</translation>
    </message>
    <message>
        <source>JIS B4</source>
        <translation>JIS B4</translation>
    </message>
    <message>
        <source>JIS B5</source>
        <translation>JIS B5</translation>
    </message>
    <message>
        <source>JIS B6</source>
        <translation>JIS B6</translation>
    </message>
    <message>
        <source>JIS B7</source>
        <translation>JIS B7</translation>
    </message>
    <message>
        <source>JIS B8</source>
        <translation>JIS B8</translation>
    </message>
    <message>
        <source>JIS B9</source>
        <translation>JIS B9</translation>
    </message>
    <message>
        <source>JIS B10</source>
        <translation>JIS B10</translation>
    </message>
    <message>
        <source>ANSI C</source>
        <translation>ANSI C</translation>
    </message>
    <message>
        <source>ANSI D</source>
        <translation>ANSI D</translation>
    </message>
    <message>
        <source>ANSI E</source>
        <translation>ANSI E</translation>
    </message>
    <message>
        <source>Legal Extra</source>
        <translation>Legal extra</translation>
    </message>
    <message>
        <source>Letter Extra</source>
        <translation>Carta extra</translation>
    </message>
    <message>
        <source>Letter Plus</source>
        <translation>Carta plus</translation>
    </message>
    <message>
        <source>Letter Small</source>
        <translation>Carta pequeña</translation>
    </message>
    <message>
        <source>Tabloid Extra</source>
        <translation>Tabloide extra</translation>
    </message>
    <message>
        <source>Architect A</source>
        <translation>Arquitecto A</translation>
    </message>
    <message>
        <source>Architect B</source>
        <translation>Arquitecto B</translation>
    </message>
    <message>
        <source>Architect C</source>
        <translation>Arquitecto C</translation>
    </message>
    <message>
        <source>Architect D</source>
        <translation>Arquitecto C</translation>
    </message>
    <message>
        <source>Architect E</source>
        <translation>Arquitecto E</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Nota</translation>
    </message>
    <message>
        <source>Quarto</source>
        <translation>Quarto</translation>
    </message>
    <message>
        <source>Statement</source>
        <translation>Declaración</translation>
    </message>
    <message>
        <source>Super A</source>
        <translation>Super A</translation>
    </message>
    <message>
        <source>Super B</source>
        <translation>Super B</translation>
    </message>
    <message>
        <source>Postcard</source>
        <translation>Tarjeta postal</translation>
    </message>
    <message>
        <source>Double Postcard</source>
        <translation>Tarjeta postal doble</translation>
    </message>
    <message>
        <source>PRC 16K</source>
        <translation>PRC 16K</translation>
    </message>
    <message>
        <source>PRC 32K</source>
        <translation>PRC 32K</translation>
    </message>
    <message>
        <source>PRC 32K Big</source>
        <translation>PRC 32K grande</translation>
    </message>
    <message>
        <source>Fan-fold US (14.875 x 11 in)</source>
        <translation>Pliegue de ventilador EEUU (14.875 x 11 in)</translation>
    </message>
    <message>
        <source>Fan-fold German (8.5 x 12 in)</source>
        <translation>Pliegue de ventilador Alemán (8.5 x 12 in)</translation>
    </message>
    <message>
        <source>Fan-fold German Legal (8.5 x 13 in)</source>
        <translation>Pliegue de ventilador Alemán Legal (8.5 x 13 in)</translation>
    </message>
    <message>
        <source>Envelope B4</source>
        <translation>Sobre B4</translation>
    </message>
    <message>
        <source>Envelope B5</source>
        <translation>Sobre B5</translation>
    </message>
    <message>
        <source>Envelope B6</source>
        <translation>Sobre B6</translation>
    </message>
    <message>
        <source>Envelope C0</source>
        <translation>Sobre C0</translation>
    </message>
    <message>
        <source>Envelope C1</source>
        <translation>Sobre C1</translation>
    </message>
    <message>
        <source>Envelope C2</source>
        <translation>Sobre C2</translation>
    </message>
    <message>
        <source>Envelope C3</source>
        <translation>Sobre C3</translation>
    </message>
    <message>
        <source>Envelope C4</source>
        <translation>Sobre C4</translation>
    </message>
    <message>
        <source>Envelope C5</source>
        <translation>Sobre C5</translation>
    </message>
    <message>
        <source>Envelope C6</source>
        <translation>Sobre C6</translation>
    </message>
    <message>
        <source>Envelope C65</source>
        <translation>Sobre C65</translation>
    </message>
    <message>
        <source>Envelope C7</source>
        <translation>Sobre C7</translation>
    </message>
    <message>
        <source>Envelope DL</source>
        <translation>Sobre DL</translation>
    </message>
    <message>
        <source>Envelope US 9</source>
        <translation>Sobre EEUU 9</translation>
    </message>
    <message>
        <source>Envelope US 10</source>
        <translation>Sobre EEUU 10</translation>
    </message>
    <message>
        <source>Envelope US 11</source>
        <translation>Sobre EEUU 11</translation>
    </message>
    <message>
        <source>Envelope US 12</source>
        <translation>Sobre EEUU 12</translation>
    </message>
    <message>
        <source>Envelope US 14</source>
        <translation>Sobre EEUU 14</translation>
    </message>
    <message>
        <source>Envelope Monarch</source>
        <translation>Sobre Monarca</translation>
    </message>
    <message>
        <source>Envelope Personal</source>
        <translation>Sobre Personal</translation>
    </message>
    <message>
        <source>Envelope Chou 3</source>
        <translation>Sobre Cho 3</translation>
    </message>
    <message>
        <source>Envelope Chou 4</source>
        <translation>Sobre Cho 4</translation>
    </message>
    <message>
        <source>Envelope Invite</source>
        <translation>Sobre invitación</translation>
    </message>
    <message>
        <source>Envelope Italian</source>
        <translation>Sobre Italiano</translation>
    </message>
    <message>
        <source>Envelope Kaku 2</source>
        <translation>Sobre Kaku 2</translation>
    </message>
    <message>
        <source>Envelope Kaku 3</source>
        <translation>Sobre Kaku 3</translation>
    </message>
    <message>
        <source>Envelope PRC 1</source>
        <translation>Sobre PRC 1</translation>
    </message>
    <message>
        <source>Envelope PRC 2</source>
        <translation>Sobre PRC 2</translation>
    </message>
    <message>
        <source>Envelope PRC 3</source>
        <translation>Sobre PRC 3</translation>
    </message>
    <message>
        <source>Envelope PRC 4</source>
        <translation>Sobre PRC 4</translation>
    </message>
    <message>
        <source>Envelope PRC 5</source>
        <translation>Sobre PRC 5</translation>
    </message>
    <message>
        <source>Envelope PRC 6</source>
        <translation>Sobre PRC 6</translation>
    </message>
    <message>
        <source>Envelope PRC 7</source>
        <translation>Sobre PRC 7</translation>
    </message>
    <message>
        <source>Envelope PRC 8</source>
        <translation>Sobre PRC 8</translation>
    </message>
    <message>
        <source>Envelope PRC 9</source>
        <translation>Sobre PRC 9</translation>
    </message>
    <message>
        <source>Envelope PRC 10</source>
        <translation>Sobre PRC 10</translation>
    </message>
    <message>
        <source>Envelope You 4</source>
        <translation>Sobre You 4</translation>
    </message>
</context>
<context>
    <name>QPlatformTheme</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>Save All</source>
        <translation>Guardar todo</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Sí</translation>
    </message>
    <message>
        <source>Yes to &amp;All</source>
        <translation>Sí a &amp;todo</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <source>N&amp;o to All</source>
        <translation>N&amp;o a todo</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Interrumpir</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Reintentar</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Ignorar</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reinicializar</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation>Restaurar los valores predeterminados</translation>
    </message>
</context>
<context>
    <name>QPluginLoader</name>
    <message>
        <source>The plugin was not loaded.</source>
        <translation>El complemento no fue cargado.</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
</context>
<context>
    <name>QPrintDialog</name>
    <message>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>Left to Right, Top to Bottom</source>
        <translation>Izquierda a derecha, arriba a abajo</translation>
    </message>
    <message>
        <source>Left to Right, Bottom to Top</source>
        <translation>Izquierda a derecha, abajo a arriba</translation>
    </message>
    <message>
        <source>Right to Left, Bottom to Top</source>
        <translation>Derecha a izquierda, abajo a arriba</translation>
    </message>
    <message>
        <source>Right to Left, Top to Bottom</source>
        <translation>Derecha A izquierda, arriba a abajo</translation>
    </message>
    <message>
        <source>Bottom to Top, Left to Right</source>
        <translation>Abajo a arriba, izquierda a derecha</translation>
    </message>
    <message>
        <source>Bottom to Top, Right to Left</source>
        <translation>Abajo a arriba, derecha a izquierda</translation>
    </message>
    <message>
        <source>Top to Bottom, Left to Right</source>
        <translation>Arriba a abajo, izquierda a derecha</translation>
    </message>
    <message>
        <source>Top to Bottom, Right to Left</source>
        <translation>Arriba a abajo, derecha a izquierda</translation>
    </message>
    <message>
        <source>1 (1x1)</source>
        <translation>1 (1x1)</translation>
    </message>
    <message>
        <source>2 (2x1)</source>
        <translation>2 (2x1)</translation>
    </message>
    <message>
        <source>4 (2x2)</source>
        <translation>4 (2x2)</translation>
    </message>
    <message>
        <source>6 (2x3)</source>
        <translation>6 (2x3)</translation>
    </message>
    <message>
        <source>9 (3x3)</source>
        <translation>9 (3x3)</translation>
    </message>
    <message>
        <source>16 (4x4)</source>
        <translation>16 (4x4)</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Todas las páginas</translation>
    </message>
    <message>
        <source>Odd Pages</source>
        <translation>Páginas impares</translation>
    </message>
    <message>
        <source>Even Pages</source>
        <translation>Páginas pares</translation>
    </message>
    <message>
        <source>&amp;Options &gt;&gt;</source>
        <translation>&amp;Opciones &gt;&gt;</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation>Im&amp;primir</translation>
    </message>
    <message>
        <source>&amp;Options &lt;&lt;</source>
        <translation>&amp;Opciones &lt;&lt;</translation>
    </message>
    <message>
        <source>Invalid Pages Definition</source>
        <translation>Definición de páginas no válida</translation>
    </message>
    <message>
        <source>%1 does not follow the correct syntax. Please use &apos;,&apos; to separate ranges and pages, &apos;-&apos; to define ranges and make sure ranges do not intersect with each other.</source>
        <translation>%1 no sigue la sintaxis correcta. Por favor, use &apos;,&apos; para separar rangos y páginas, &apos;-&apos; para definir rangos y asegúrese de que los rangos no se crucen entre sí.</translation>
    </message>
    <message>
        <source>Duplex Settings Conflicts</source>
        <translation>Conflictos de configuración de dúplex</translation>
    </message>
    <message>
        <source>There are conflicts in duplex settings. Do you want to fix them?</source>
        <translation>Hay conflictos en la configuración de dúplex. ¿Desea corregirlos?</translation>
    </message>
    <message>
        <source>Print to File (PDF)</source>
        <translation>Imprimir a archivo (PDF)</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>Archivo local</translation>
    </message>
    <message>
        <source>Write PDF file</source>
        <translation>Escribir archivo PDF</translation>
    </message>
    <message>
        <source>Print To File ...</source>
        <translation>Imprimir a fichero...</translation>
    </message>
    <message>
        <source>%1 is a directory.
Please choose a different file name.</source>
        <translation>%1 es un directorio.
Elija un nombre de fichero diferente.</translation>
    </message>
    <message>
        <source>File %1 is not writable.
Please choose a different file name.</source>
        <translation>No se puede escribir en el fichero %1.
Elija un nombre de fichero diferente.</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to overwrite it?</source>
        <translation>%1 ya existe.
¿Desea sobrescribirlo?</translation>
    </message>
    <message>
        <source>Options &apos;Pages Per Sheet&apos; and &apos;Page Set&apos; cannot be used together.
Please turn one of those options off.</source>
        <translation>Opciones «Páginas por Hoja» y «Set de Páginas» No pueden ser usadas a la vez.
Por favor desactiva una de las opciones.</translation>
    </message>
    <message>
        <source>The &apos;From&apos; value cannot be greater than the &apos;To&apos; value.</source>
        <translation>El campo «De» no puede ser mayor que el valor del campo «A».</translation>
    </message>
</context>
<context>
    <name>QPrintPreviewDialog</name>
    <message>
        <source>Page Setup</source>
        <translation>Configuración de página</translation>
    </message>
    <message>
        <source>%1%</source>
        <translation>%1%</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation>Previsualizar impresión</translation>
    </message>
    <message>
        <source>Next page</source>
        <translation>Página siguiente</translation>
    </message>
    <message>
        <source>Previous page</source>
        <translation>Página anterior</translation>
    </message>
    <message>
        <source>First page</source>
        <translation>Primera página</translation>
    </message>
    <message>
        <source>Last page</source>
        <translation>Última página</translation>
    </message>
    <message>
        <source>Fit width</source>
        <translation>Ajustar ancho</translation>
    </message>
    <message>
        <source>Fit page</source>
        <translation>Ajustar página</translation>
    </message>
    <message>
        <source>Zoom in</source>
        <translation>Acercar</translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation>Alejar</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Vertical</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Apaisado</translation>
    </message>
    <message>
        <source>Show single page</source>
        <translation>Mostrar página única</translation>
    </message>
    <message>
        <source>Show facing pages</source>
        <translation>Mostrar páginas enfrentadas</translation>
    </message>
    <message>
        <source>Show overview of all pages</source>
        <translation>Mostrar una vista de todas las páginas</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>Page setup</source>
        <translation>Configuración de página</translation>
    </message>
    <message>
        <source>Export to PDF</source>
        <translation>Exportar a PDF</translation>
    </message>
</context>
<context>
    <name>QPrintPropertiesDialog</name>
    <message>
        <source>Printer Properties</source>
        <translation>Propiedades de impresora</translation>
    </message>
    <message>
        <source>Job Options</source>
        <translation>Opciones de trabajo</translation>
    </message>
    <message>
        <source>Page Setup Conflicts</source>
        <translation>Conflictos de configuración de página</translation>
    </message>
    <message>
        <source>There are conflicts in page setup options. Do you want to fix them?</source>
        <translation>Hay conflictos en las opciones de configuración de página. ¿Desea corregirlos?</translation>
    </message>
    <message>
        <source>Advanced Option Conflicts</source>
        <translation>Conflictos de opciones avanzadas</translation>
    </message>
    <message>
        <source>There are conflicts in some advanced options. Do you want to fix them?</source>
        <translation>Hay conflictos en algunas opciones avanzadas. ¿Desea corregirlos?</translation>
    </message>
</context>
<context>
    <name>QPrintPropertiesWidget</name>
    <message>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <source>There are conflicts in some options. Please fix them.</source>
        <translation>Hay conflictos en algunas opciones. Por favor, corríjalos.</translation>
    </message>
</context>
<context>
    <name>QPrintSettingsOutput</name>
    <message>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <source>Copies</source>
        <translation>Copias</translation>
    </message>
    <message>
        <source>Print range</source>
        <translation>Imprimir el intervalo</translation>
    </message>
    <message>
        <source>Print all</source>
        <translation>Imprimir todo</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Páginas desde</translation>
    </message>
    <message>
        <source>to</source>
        <translation>a</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Página Actual</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Selección</translation>
    </message>
    <message>
        <source>Page Set:</source>
        <translation>Set de páginas:</translation>
    </message>
    <message>
        <source>Output Settings</source>
        <translation>Configuración de salida</translation>
    </message>
    <message>
        <source>Copies:</source>
        <translation>Copias:</translation>
    </message>
    <message>
        <source>Collate</source>
        <translation>Recopilar</translation>
    </message>
    <message>
        <source>Reverse</source>
        <translation>Inverso</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <source>Color Mode</source>
        <translation>Modo de color</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <source>Grayscale</source>
        <translation>Escala de grises</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <source>Specify pages or ranges separated by commas. Ranges are specified by two numbers separated by a hyphen. E.g: 3,5-7,9 prints pages 3, 5, 6, 7 and 9.</source>
        <translation>Especifique páginas o rangos separados por comas. Los rangos se especifican con dos números separados por un guion. Ej.: 3,5-7,9 imprime las páginas 3, 5, 6, 7 y 9.</translation>
    </message>
    <message>
        <source>Double Sided Printing</source>
        <translation>Impresión a doble cara</translation>
    </message>
    <message>
        <source>Off</source>
        <translation>Apagado</translation>
    </message>
    <message>
        <source>Long side binding</source>
        <translation>Encuadernación por el lado largo</translation>
    </message>
    <message>
        <source>Short side binding</source>
        <translation>Encuadernación por el lado corto</translation>
    </message>
</context>
<context>
    <name>QPrintWidget</name>
    <message>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <source>Printer</source>
        <translation>Impresora</translation>
    </message>
    <message>
        <source>&amp;Name:</source>
        <translation>&amp;Nombre:</translation>
    </message>
    <message>
        <source>P&amp;roperties</source>
        <translation>P&amp;ropiedades</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Ubicación:</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Previsualización</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <source>Output &amp;file:</source>
        <translation>&amp;Fichero de salida:</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>QProcess</name>
    <message>
        <source>Process failed to start</source>
        <translation>El proceso no se ha podido iniciar</translation>
    </message>
    <message>
        <source>Process crashed</source>
        <translation>Fallo en el proceso</translation>
    </message>
    <message>
        <source>Process operation timed out</source>
        <translation>Tiempo de espera para la operación con el proceso ha expirado</translation>
    </message>
    <message>
        <source>Error reading from process</source>
        <translation>Error leyendo del proceso</translation>
    </message>
    <message>
        <source>Error writing to process</source>
        <translation>Error escribiendo al proceso</translation>
    </message>
    <message>
        <source>No program defined</source>
        <translation>No se ha definido un proceso</translation>
    </message>
    <message>
        <source>Could not open input redirection for reading</source>
        <translation>No se puede abrir la redirección de entrada para lectura</translation>
    </message>
    <message>
        <source>Resource error (fork failure): %1</source>
        <translation>Error de recurso (fallo al bifurcar el proceso): %1</translation>
    </message>
    <message>
        <source>Child process modifier threw an exception: %1</source>
        <translation>El modificador del proceso hijo lanzó una excepción: %1</translation>
    </message>
    <message>
        <source>Child process modifier reported error: %1</source>
        <translation>El modificador del proceso hijo reportó un error: %1</translation>
    </message>
    <message>
        <source>Child process modifier reported error: %1: %2</source>
        <translation>El modificador del proceso hijo reportó un error: %1: %2</translation>
    </message>
    <message>
        <source>Child process set up failed: %1: %2</source>
        <translation>La configuración del proceso hijo falló: %1: %2</translation>
    </message>
    <message>
        <source>Could not open output redirection for writing</source>
        <translation>No se puede abrir la redirección de salida para escritura</translation>
    </message>
    <message>
        <source>Process failed to start: %1</source>
        <translation>El proceso no se ha podido iniciar: %1</translation>
    </message>
</context>
<context>
    <name>QProgressDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>QRegularExpression</name>
    <message>
        <source>no error</source>
        <translation>no hay errores</translation>
    </message>
    <message>
        <source>\ at end of pattern</source>
        <translation>\ al final del patrón</translation>
    </message>
    <message>
        <source>\c at end of pattern</source>
        <translation>\c al final del patrón</translation>
    </message>
    <message>
        <source>unrecognized character follows \</source>
        <translation>carácter no reconocido tras \</translation>
    </message>
    <message>
        <source>numbers out of order in {} quantifier</source>
        <translation>números no ordenados en el cuantificador {}</translation>
    </message>
    <message>
        <source>number too big in {} quantifier</source>
        <translation>número demasiado grande en el cuantificador {}</translation>
    </message>
    <message>
        <source>missing terminating ] for character class</source>
        <translation>falta el terminador ] para la clase carácter</translation>
    </message>
    <message>
        <source>range out of order in character class</source>
        <translation>rango fuera de servicio in clase carácter</translation>
    </message>
    <message>
        <source>internal error: unexpected repeat</source>
        <translation>error interno: repetición inesperada</translation>
    </message>
    <message>
        <source>unrecognized character after (? or (?-</source>
        <translation>carácter no reconocido tras (? o (?-</translation>
    </message>
    <message>
        <source>POSIX named classes are supported only within a class</source>
        <translation>nombre POSIX de clases sólo están soportados dentro de una clase</translation>
    </message>
    <message>
        <source>reference to non-existent subpattern</source>
        <translation>referencia a un subpatrón inexistente</translation>
    </message>
    <message>
        <source>regular expression is too large</source>
        <translation>la expresión regular es muy grande</translation>
    </message>
    <message>
        <source>internal error: code overflow</source>
        <translation>error interno: código desbordado</translation>
    </message>
    <message>
        <source>lookbehind assertion is not fixed length</source>
        <translation>la aserción lookbehind no tiene tamaño fijo</translation>
    </message>
    <message>
        <source>unknown POSIX class name</source>
        <translation>nombre de clase POSIX desconocido</translation>
    </message>
    <message>
        <source>POSIX collating elements are not supported</source>
        <translation>elementos de clasificación POSIX no están soportados</translation>
    </message>
    <message>
        <source>unrecognized character after (?P</source>
        <translation>carácter nor reconocido tras (?P</translation>
    </message>
    <message>
        <source>malformed \P or \p sequence</source>
        <translation>secuencia \P o \p mal formada</translation>
    </message>
    <message>
        <source>unknown property name after \P or \p</source>
        <translation>nombre de propiedad desconocido tras \P o \p</translation>
    </message>
    <message>
        <source>too many named subpatterns (maximum 10000)</source>
        <translation>demasiados subpatrones con nombre (el máximo es 10000)</translation>
    </message>
    <message>
        <source>internal error: overran compiling workspace</source>
        <translation>error interno: espacio de trabajo rebasado durante compilación</translation>
    </message>
    <message>
        <source>internal error: previously-checked referenced subpattern not found</source>
        <translation>error interno: subpatrón previamente referenciado no encontrado</translation>
    </message>
    <message>
        <source>\g is not followed by a braced, angle-bracketed, or quoted name/number or by a plain number</source>
        <translation>\g no está seguido por un nombre/número entre llaves, entre símbolos de ángulo o entre comillas o un número simple</translation>
    </message>
    <message>
        <source>subpattern name expected</source>
        <translation>se esperaba un nombre de subpatrón</translation>
    </message>
    <message>
        <source>different names for subpatterns of the same number are not allowed</source>
        <translation>no están permitidos los nombres diferentes para subpatrones del mismo número</translation>
    </message>
    <message>
        <source>(*MARK) must have an argument</source>
        <translation>(*MARK) debe tener un argumento</translation>
    </message>
    <message>
        <source>\k is not followed by a braced, angle-bracketed, or quoted name</source>
        <translation>\k no está seguido de unas llaves, mayor-que/menor-que o un nombre entre comillas</translation>
    </message>
    <message>
        <source>\N is not supported in a class</source>
        <translation>\N no está soportado en una clase</translation>
    </message>
    <message>
        <source>disallowed Unicode code point (&gt;= 0xd800 &amp;&amp; &lt;= 0xdfff)</source>
        <translation>código Unicode no permitido (&gt;= 0xd800 &amp;&amp; &lt;= 0xdfff)</translation>
    </message>
    <message>
        <source>name is too long in (*MARK), (*PRUNE), (*SKIP), or (*THEN)</source>
        <translation>nombre demasiado grande en (*MARK), (*PRUNE), (*SKIP) o (*THEN)</translation>
    </message>
    <message>
        <source>non-hex character in \x{} (closing brace missing?)</source>
        <translation>carácter no hexadecimal en \x{} (¿es posible que se haya olvidado el carácter «}»?)</translation>
    </message>
    <message>
        <source>non-octal character in \o{} (closing brace missing?)</source>
        <translation>carácter no octal en \o{} (¿es posible que se haya olvidado el carácter «}»?)</translation>
    </message>
    <message>
        <source>escape sequence is invalid in character class</source>
        <translation>la seq de escape es inválida en la clase de caracteres</translation>
    </message>
    <message>
        <source>quantifier does not follow a repeatable item</source>
        <translation>el cuantificador no sigue a un elemento repetible</translation>
    </message>
    <message>
        <source>missing closing parenthesis</source>
        <translation>falta un paréntesis de cierre</translation>
    </message>
    <message>
        <source>pattern passed as NULL</source>
        <translation>patrón pasado como NULL</translation>
    </message>
    <message>
        <source>unrecognised compile-time option bit(s)</source>
        <translation>bit(s) de opción de tiempo de compilación no reconocido(s)</translation>
    </message>
    <message>
        <source>missing ) after (?# comment</source>
        <translation>falta ) después del comentario (?#</translation>
    </message>
    <message>
        <source>failed to allocate heap memory</source>
        <translation>no se pudo asignar memoria en el heap</translation>
    </message>
    <message>
        <source>unmatched closing parenthesis</source>
        <translation>paréntesis de cierre no coincidente</translation>
    </message>
    <message>
        <source>missing closing parenthesis for condition</source>
        <translation>falta el paréntesis de cierre para la condición</translation>
    </message>
    <message>
        <source>a relative value of zero is not allowed</source>
        <translation>no se permite un valor relativo de cero</translation>
    </message>
    <message>
        <source>conditional subpattern contains more than two branches</source>
        <translation>el subpatrón condicional contiene más de dos ramas</translation>
    </message>
    <message>
        <source>assertion expected after (?( or (?(?C)</source>
        <translation>se esperaba una afirmación después de (?( o (?(?C)</translation>
    </message>
    <message>
        <source>digit expected after (?+ or (?-</source>
        <translation>se esperaba un dígito después de (?+ o (?-</translation>
    </message>
    <message>
        <source>internal error in pcre2_study(): should not occur</source>
        <translation>error interno en pcre2_study(): no debería ocurrir</translation>
    </message>
    <message>
        <source>this version of PCRE2 does not have Unicode support</source>
        <translation>esta versión de PCRE2 no tiene soporte Unicode</translation>
    </message>
    <message>
        <source>character code point value in \x{} or \o{} is too large</source>
        <translation>el valor del punto de código de carácter en \x{} o \o{} es demasiado grande</translation>
    </message>
    <message>
        <source>lookbehind is too complicated</source>
        <translation>el retroceso es demasiado complicado</translation>
    </message>
    <message>
        <source>\C is not allowed in a lookbehind assertion in UTF-16 mode</source>
        <translation>\C no está permitido en una afirmación de retroceso en modo UTF-16</translation>
    </message>
    <message>
        <source>PCRE2 does not support \F, \L, \l, \N{name}, \U, or \u</source>
        <translation>PCRE2 no admite \F, \L, \l, \N{name}, \U, o \u</translation>
    </message>
    <message>
        <source>number after (?C is greater than 255</source>
        <translation>el número después de (?C es mayor que 255</translation>
    </message>
    <message>
        <source>closing parenthesis for (?C expected</source>
        <translation>se esperaba un paréntesis de cierre para (?C</translation>
    </message>
    <message>
        <source>invalid escape sequence in (*VERB) name</source>
        <translation>Seq de escape inválida en el nombre (*VERB)</translation>
    </message>
    <message>
        <source>syntax error in subpattern name (missing terminator?)</source>
        <translation>error de sintaxis en el nombre del subpatrón (¿falta el terminador?)</translation>
    </message>
    <message>
        <source>two named subpatterns have the same name (PCRE2_DUPNAMES not set)</source>
        <translation>dos subpatrones con nombre tienen el mismo nombre (PCRE2_DUPNAMES no está configurado)</translation>
    </message>
    <message>
        <source>subpattern name must start with a non-digit</source>
        <translation>el nombre del subpatrón debe comenzar con un no dígito</translation>
    </message>
    <message>
        <source>this version of PCRE2 does not have support for \P, \p, or \X</source>
        <translation>esta versión de PCRE2 no tiene soporte para \P, \p, o \X</translation>
    </message>
    <message>
        <source>subpattern name is too long (maximum 32 code units)</source>
        <translation>el nombre del subpatrón es demasiado largo (máximo 32 unidades de código)</translation>
    </message>
    <message>
        <source>octal value is greater than \377 in 8-bit non-UTF-8 mode</source>
        <translation>el valor octal es mayor que \377 en modo de 8 bits no UTF-8</translation>
    </message>
    <message>
        <source>DEFINE subpattern contains more than one branch</source>
        <translation>el subpatrón DEFINE contiene más de una rama</translation>
    </message>
    <message>
        <source>missing opening brace after \o</source>
        <translation>falta una llave tras \o</translation>
    </message>
    <message>
        <source>internal error: unknown newline setting</source>
        <translation>error interno: configuración de nueva línea desconocida</translation>
    </message>
    <message>
        <source>(?R (recursive pattern call) must be followed by a closing parenthesis</source>
        <translation>(?R (llamada recursiva de patrón) debe ser seguida por un paréntesis de cierre</translation>
    </message>
    <message>
        <source>obsolete error (should not occur)</source>
        <translation>error obsoleto (no debería ocurrir)</translation>
    </message>
    <message>
        <source>(*VERB) not recognized or malformed</source>
        <translation>(*VERB) no reconocido o mal formado</translation>
    </message>
    <message>
        <source>subpattern number is too big</source>
        <translation>el número de subpatrón es demasiado grande</translation>
    </message>
    <message>
        <source>internal error: parsed pattern overflow</source>
        <translation>error interno: desbordamiento de patrón analizado</translation>
    </message>
    <message>
        <source>\c must be followed by a printable ASCII character</source>
        <translation>\c debe ir seguido de un carácter ASCII imprimible</translation>
    </message>
    <message>
        <source>\c must be followed by a letter or one of [\]^_?</source>
        <translation>\c debe ser seguido por una letra o uno de [\]^_?</translation>
    </message>
    <message>
        <source>internal error: unknown meta code in check_lookbehinds()</source>
        <translation>error interno: código meta desconocido en check_Miradores atrás()</translation>
    </message>
    <message>
        <source>callout string is too long</source>
        <translation>la cadena de llamada es demasiado larga</translation>
    </message>
    <message>
        <source>using UTF is disabled by the application</source>
        <translation>el uso de UTF está deshabilitado por la aplicación</translation>
    </message>
    <message>
        <source>using UCP is disabled by the application</source>
        <translation>el uso de UCP está deshabilitado por la aplicación</translation>
    </message>
    <message>
        <source>character code point value in \u.... sequence is too large</source>
        <translation>el valor del punto de código del carácter en la seq \u.... es demasiado grande</translation>
    </message>
    <message>
        <source>digits missing in \x{} or \o{} or \N{U+}</source>
        <translation>faltan dígitos en \x{} o \o{} o \N{U+}</translation>
    </message>
    <message>
        <source>syntax error or number too big in (?(VERSION condition</source>
        <translation>error de sintaxis o número demasiado grande en la condición (?(VERSION</translation>
    </message>
    <message>
        <source>internal error: unknown opcode in auto_possessify()</source>
        <translation>error interno: código de operación desconocido en auto_Poseer()</translation>
    </message>
    <message>
        <source>missing terminating delimiter for callout with string argument</source>
        <translation>falta el delimitador de terminación para el callout con argumento de cadena</translation>
    </message>
    <message>
        <source>unrecognized string delimiter follows (?C</source>
        <translation>delimitador de cadena no reconocido sigue a (?C</translation>
    </message>
    <message>
        <source>using \C is disabled by the application</source>
        <translation>el uso de \C está deshabilitado por la aplicación</translation>
    </message>
    <message>
        <source>(?| and/or (?J: or (?x: parentheses are too deeply nested</source>
        <translation>(?| y/o (?J: o (?x: los paréntesis están demasiado anidados</translation>
    </message>
    <message>
        <source>using \C is disabled in this PCRE2 library</source>
        <translation>el uso de \C está deshabilitado en esta biblioteca PCRE2</translation>
    </message>
    <message>
        <source>regular expression is too complicated</source>
        <translation>la expresión regular es demasiado complicada</translation>
    </message>
    <message>
        <source>lookbehind assertion is too long</source>
        <translation>la afirmación de retroceso es demasiado larga</translation>
    </message>
    <message>
        <source>pattern string is longer than the limit set by the application</source>
        <translation>la cadena de patrón es más larga que el límite establecido por la aplicación</translation>
    </message>
    <message>
        <source>internal error: unknown code in parsed pattern</source>
        <translation>error interno: código desconocido en el patrón analizado</translation>
    </message>
    <message>
        <source>internal error: bad code value in parsed_skip()</source>
        <translation>error interno: valor de código incorrecto en parsed_Saltar()</translation>
    </message>
    <message>
        <source>PCRE2_EXTRA_ALLOW_SURROGATE_ESCAPES is not allowed in UTF-16 mode</source>
        <translation>PCRE2_EXTRA_ALLOW_SURROGATE_ESCAPES no está permitido en modo UTF-16</translation>
    </message>
    <message>
        <source>invalid option bits with PCRE2_LITERAL</source>
        <translation>bits de opción no válidos con PCRE2_LITERAL</translation>
    </message>
    <message>
        <source>\N{U+dddd} is supported only in Unicode (UTF) mode</source>
        <translation>\N{U+dddd} solo es compatible en modo Unicode (UTF)</translation>
    </message>
    <message>
        <source>invalid hyphen in option setting</source>
        <translation>guion inválido en la configuración de opciones</translation>
    </message>
    <message>
        <source>(*alpha_assertion) not recognized</source>
        <translation>(*alpha_Assertion) no reconocido</translation>
    </message>
    <message>
        <source>script runs require Unicode support, which this version of PCRE2 does not have</source>
        <translation>las ejecuciones de script requieren soporte Unicode, que esta versión de PCRE2 no tiene</translation>
    </message>
    <message>
        <source>too many capturing groups (maximum 65535)</source>
        <translation>demasiados grupos de captura (máximo 65535)</translation>
    </message>
    <message>
        <source>atomic assertion expected after (?( or (?(?C)</source>
        <translation>se esperaba una afirmación atómica después de (?( o (?(?C)</translation>
    </message>
    <message>
        <source>no match</source>
        <translation>sin coincidencia</translation>
    </message>
    <message>
        <source>partial match</source>
        <translation>coincidencia parcial</translation>
    </message>
    <message>
        <source>UTF-8 error: 1 byte missing at end</source>
        <translation>Error UTF-8: falta 1 byte al final</translation>
    </message>
    <message>
        <source>UTF-8 error: 2 bytes missing at end</source>
        <translation>Error UTF-8: Faltan 2 bytes al final</translation>
    </message>
    <message>
        <source>UTF-8 error: 3 bytes missing at end</source>
        <translation>Error UTF-8: Faltan 3 bytes al final</translation>
    </message>
    <message>
        <source>UTF-8 error: 4 bytes missing at end</source>
        <translation>Error UTF-8: Faltan 4 bytes al final</translation>
    </message>
    <message>
        <source>UTF-8 error: 5 bytes missing at end</source>
        <translation>Error UTF-8: Faltan 5 bytes al final</translation>
    </message>
    <message>
        <source>UTF-8 error: byte 2 top bits not 0x80</source>
        <translation>Error UTF-8: los bits superiores del byte 2 no son 0x80</translation>
    </message>
    <message>
        <source>UTF-8 error: byte 3 top bits not 0x80</source>
        <translation>Error UTF-8: los bits superiores del byte 3 no son 0x80</translation>
    </message>
    <message>
        <source>UTF-8 error: byte 4 top bits not 0x80</source>
        <translation>Error UTF-8: los bits superiores del byte 4 no son 0x80</translation>
    </message>
    <message>
        <source>UTF-8 error: byte 5 top bits not 0x80</source>
        <translation>Error UTF-8: los bits superiores del byte 5 no son 0x80</translation>
    </message>
    <message>
        <source>UTF-8 error: byte 6 top bits not 0x80</source>
        <translation>Error de UTF-8: los bits superiores del byte 6 no son 0x80</translation>
    </message>
    <message>
        <source>UTF-8 error: 5-byte character is not allowed (RFC 3629)</source>
        <translation>Error UTF-8: No se permite un carácter de 5 bytes (RFC 3629)</translation>
    </message>
    <message>
        <source>UTF-8 error: 6-byte character is not allowed (RFC 3629)</source>
        <translation>Error UTF-8: Carácter de 6 bytes no permitido (RFC 3629)</translation>
    </message>
    <message>
        <source>UTF-8 error: code points greater than 0x10ffff are not defined</source>
        <translation>Error UTF-8: los puntos de código mayores que 0x10ffff no están definidos</translation>
    </message>
    <message>
        <source>UTF-8 error: code points 0xd800-0xdfff are not defined</source>
        <translation>Error UTF-8: los puntos de código 0xd800-0xdfff no están definidos</translation>
    </message>
    <message>
        <source>UTF-8 error: overlong 2-byte sequence</source>
        <translation>Error UTF-8: seq de 2 bytes demasiado larga</translation>
    </message>
    <message>
        <source>UTF-8 error: overlong 3-byte sequence</source>
        <translation>Error de UTF-8: seq de 3 bytes demasiado larga</translation>
    </message>
    <message>
        <source>UTF-8 error: overlong 4-byte sequence</source>
        <translation>Error UTF-8: seq de 4 bytes demasiado larga</translation>
    </message>
    <message>
        <source>UTF-8 error: overlong 5-byte sequence</source>
        <translation>Error de UTF-8: seq de 5 bytes demasiado larga</translation>
    </message>
    <message>
        <source>UTF-8 error: overlong 6-byte sequence</source>
        <translation>Error de UTF-8: seq de 6 bytes demasiado larga</translation>
    </message>
    <message>
        <source>UTF-8 error: isolated byte with 0x80 bit set</source>
        <translation>Error UTF-8: byte aislado con bit 0x80 establecido</translation>
    </message>
    <message>
        <source>UTF-8 error: illegal byte (0xfe or 0xff)</source>
        <translation>Error de UTF-8: byte ilegal (0xfe o 0xff)</translation>
    </message>
    <message>
        <source>UTF-16 error: missing low surrogate at end</source>
        <translation>Error de UTF-16: falta un sustituto bajo al final</translation>
    </message>
    <message>
        <source>UTF-16 error: invalid low surrogate</source>
        <translation>Error UTF-16: sustituto bajo no válido</translation>
    </message>
    <message>
        <source>UTF-16 error: isolated low surrogate</source>
        <translation>Error de UTF-16: sustituto bajo aislado</translation>
    </message>
    <message>
        <source>UTF-32 error: code points 0xd800-0xdfff are not defined</source>
        <translation>Error de UTF-32: los puntos de código 0xd800-0xdfff no están definidos</translation>
    </message>
    <message>
        <source>UTF-32 error: code points greater than 0x10ffff are not defined</source>
        <translation>Error UTF-32: los puntos de código mayores que 0x10ffff no están definidos</translation>
    </message>
    <message>
        <source>bad data value</source>
        <translation>valor de datos incorrecto</translation>
    </message>
    <message>
        <source>patterns do not all use the same character tables</source>
        <translation>los patrones no usan todas las mismas tablas de caracteres</translation>
    </message>
    <message>
        <source>magic number missing</source>
        <translation>falta el número mágico</translation>
    </message>
    <message>
        <source>pattern compiled in wrong mode: 8/16/32-bit error</source>
        <translation>patrón compilado en modo incorrecto: Error de 8/16/32 bits</translation>
    </message>
    <message>
        <source>bad offset value</source>
        <translation>valor de desplazamiento incorrecto</translation>
    </message>
    <message>
        <source>bad option value</source>
        <translation>valor de opción incorrecto</translation>
    </message>
    <message>
        <source>invalid replacement string</source>
        <translation>cadena de reemplazo no válida</translation>
    </message>
    <message>
        <source>bad offset into UTF string</source>
        <translation>desplazamiento incorrecto en la cadena UTF</translation>
    </message>
    <message>
        <source>callout error code</source>
        <translation>código de error de callout</translation>
    </message>
    <message>
        <source>invalid data in workspace for DFA restart</source>
        <translation>datos no válidos en el espacio de trabajo para reinicio de DFA</translation>
    </message>
    <message>
        <source>too much recursion for DFA matching</source>
        <translation>demasiada recursión para la coincidencia DFA</translation>
    </message>
    <message>
        <source>backreference condition or recursion test is not supported for DFA matching</source>
        <translation>la condición de retroreferencia o la prueba de recursión no son compatibles con la coincidencia DFA</translation>
    </message>
    <message>
        <source>function is not supported for DFA matching</source>
        <translation>la función no es compatible con la coincidencia DFA</translation>
    </message>
    <message>
        <source>pattern contains an item that is not supported for DFA matching</source>
        <translation>el patrón contiene un elemento que no es compatible con la coincidencia DFA</translation>
    </message>
    <message>
        <source>workspace size exceeded in DFA matching</source>
        <translation>tamaño del espacio de trabajo excedido en la coincidencia DFA</translation>
    </message>
    <message>
        <source>internal error - pattern overwritten?</source>
        <translation>error interno - ¿patrón sobrescrito?</translation>
    </message>
    <message>
        <source>bad JIT option</source>
        <translation>opción JIT incorrecta</translation>
    </message>
    <message>
        <source>JIT stack limit reached</source>
        <translation>límite de pila JIT alcanzado</translation>
    </message>
    <message>
        <source>match limit exceeded</source>
        <translation>límite de coincidencia excedido</translation>
    </message>
    <message>
        <source>no more memory</source>
        <translation>no hay más memoria</translation>
    </message>
    <message>
        <source>unknown substring</source>
        <translation>subcadena desconocida</translation>
    </message>
    <message>
        <source>non-unique substring name</source>
        <translation>nombre de subcadena no único</translation>
    </message>
    <message>
        <source>NULL argument passed</source>
        <translation>Argumento NULL pasado</translation>
    </message>
    <message>
        <source>nested recursion at the same subject position</source>
        <translation>recursión anidada en la misma posición del sujeto</translation>
    </message>
    <message>
        <source>matching depth limit exceeded</source>
        <translation>límite de profundidad de coincidencia excedido</translation>
    </message>
    <message>
        <source>requested value is not available</source>
        <translation>el valor solicitado no está disponible</translation>
    </message>
    <message>
        <source>requested value is not set</source>
        <translation>el valor solicitado no está establecido</translation>
    </message>
    <message>
        <source>offset limit set without PCRE2_USE_OFFSET_LIMIT</source>
        <translation>límite de desplazamiento establecido sin PCRE2_USE_OFFSET_LIMIT</translation>
    </message>
    <message>
        <source>bad escape sequence in replacement string</source>
        <translation>Seq de escape incorrecta en la cadena de reemplazo</translation>
    </message>
    <message>
        <source>expected closing curly bracket in replacement string</source>
        <translation>se esperaba una llave de cierre en la cadena de reemplazo</translation>
    </message>
    <message>
        <source>bad substitution in replacement string</source>
        <translation>sustitución incorrecta en cadena de reemplazo</translation>
    </message>
    <message>
        <source>match with end before start or start moved backwards is not supported</source>
        <translation>la coincidencia con el final antes del inicio o el inicio movido hacia atrás no es compatible</translation>
    </message>
    <message>
        <source>too many replacements (more than INT_MAX)</source>
        <translation>demasiados reemplazos (más de INT_MAX)</translation>
    </message>
    <message>
        <source>bad serialized data</source>
        <translation>datos serializados incorrectos</translation>
    </message>
    <message>
        <source>heap limit exceeded</source>
        <translation>límite de heap excedido</translation>
    </message>
    <message>
        <source>invalid syntax</source>
        <translation>sintaxis no válida</translation>
    </message>
    <message>
        <source>internal error - duplicate substitution match</source>
        <translation>error interno - coincidencia de sustitución duplicada</translation>
    </message>
    <message>
        <source>PCRE2_MATCH_INVALID_UTF is not supported for DFA matching</source>
        <translation>PCRE2_MATCH_INVALID_UTF no es compatible con la coincidencia DFA</translation>
    </message>
    <message>
        <source>INTERNAL ERROR: invalid substring offset</source>
        <translation>ERROR INTERNO: desplazamiento de subcadena no válido</translation>
    </message>
    <message>
        <source>parentheses are too deeply nested</source>
        <translation>paréntesis tiene demasiados elementos anidados</translation>
    </message>
    <message>
        <source>invalid range in character class</source>
        <translation>rango inválido en la clase carácter</translation>
    </message>
    <message>
        <source>parentheses are too deeply nested (stack check)</source>
        <translation>demasiados paréntesis han sido anidados (chequeo de pila)</translation>
    </message>
</context>
<context>
    <name>QSQLiteDriver</name>
    <message>
        <source>Error opening database</source>
        <translation>Error al abrir la base de datos</translation>
    </message>
    <message>
        <source>Error closing database</source>
        <translation>Error al cerrar la base de datos</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>No es posible iniciar la transacción</translation>
    </message>
    <message>
        <source>Unable to commit transaction</source>
        <translation>No es posible enviar la transacción</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>No se ha podido revertir la transacción</translation>
    </message>
</context>
<context>
    <name>QSQLiteResult</name>
    <message>
        <source>Unable to fetch row</source>
        <translation>No es posible obtener la fila</translation>
    </message>
    <message>
        <source>No query</source>
        <translation>Consulta vacía</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>No es posible ejecutar la instrucción</translation>
    </message>
    <message>
        <source>Unable to execute multiple statements at a time</source>
        <translation>No es posible ejecutar múltiples instrucciones al mismo tiempo</translation>
    </message>
    <message>
        <source>Unable to reset statement</source>
        <translation>No es posible reinicializar la instrucción</translation>
    </message>
    <message>
        <source>Unable to bind parameters</source>
        <translation>No es posible ligar los parámetros</translation>
    </message>
    <message>
        <source>Parameter count mismatch</source>
        <translation>Número de parámetros incorrecto</translation>
    </message>
</context>
<context>
    <name>QSaveFile</name>
    <message>
        <source>Existing file %1 is not writable</source>
        <translation>El archivo existente %1 no es grabable</translation>
    </message>
    <message>
        <source>Filename refers to a directory</source>
        <translation>El nombre de archivo se refiere a un directorio</translation>
    </message>
    <message>
        <source>QSaveFile cannot open &apos;%1&apos; without direct write fallback enabled.</source>
        <translation>QSaveFile no puede abrir &apos;%1&apos; sin la opción de escritura directa habilitada.</translation>
    </message>
    <message>
        <source>Writing canceled by application</source>
        <translation>Escritura cancelada por la aplicación</translation>
    </message>
</context>
<context>
    <name>QScrollBar</name>
    <message>
        <source>Scroll here</source>
        <translation>Desplazar hasta aquí</translation>
    </message>
    <message>
        <source>Left edge</source>
        <translation>Borde izquierdo</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Parte superior</translation>
    </message>
    <message>
        <source>Right edge</source>
        <translation>Borde derecho</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Parte inferior</translation>
    </message>
    <message>
        <source>Page left</source>
        <translation>Una página a la izquierda</translation>
    </message>
    <message>
        <source>Page up</source>
        <translation>Una página hacia arriba</translation>
    </message>
    <message>
        <source>Page right</source>
        <translation>Una página a la derecha</translation>
    </message>
    <message>
        <source>Page down</source>
        <translation>Una página hacia abajo</translation>
    </message>
    <message>
        <source>Scroll left</source>
        <translation>Desplazar hacia la izquierda</translation>
    </message>
    <message>
        <source>Scroll up</source>
        <translation>Desplazar hacia arriba</translation>
    </message>
    <message>
        <source>Scroll right</source>
        <translation>Desplazar hacia la derecha</translation>
    </message>
    <message>
        <source>Scroll down</source>
        <translation>Desplazar hacia abajo</translation>
    </message>
</context>
<context>
    <name>QSharedMemory</name>
    <message>
        <source>%1: create size is less then 0</source>
        <translation>%1: el tamaño de creación is menor que 0</translation>
    </message>
    <message>
        <source>%1: unable to lock</source>
        <translation>%1: no se ha podido bloquear</translation>
    </message>
    <message>
        <source>%1: unable to unlock</source>
        <translation>%1: no se ha podido desbloquear</translation>
    </message>
    <message>
        <source>%1: key is empty</source>
        <translation>%1: la clave está vacía</translation>
    </message>
    <message>
        <source>%1: bad name</source>
        <translation>%1: nombre inválido</translation>
    </message>
    <message>
        <source>%1: unable to make key</source>
        <translation>%1: imposible crear clave</translation>
    </message>
    <message>
        <source>%1: system-imposed size restrictions</source>
        <translation>%1: el sistema ha impuesto restricciones de tamaño</translation>
    </message>
    <message>
        <source>%1: not attached</source>
        <translation>%1: no adjuntado</translation>
    </message>
    <message>
        <source>%1: unsupported key type</source>
        <translation>%1: tipo de clave no compatible</translation>
    </message>
    <message>
        <source>%1: unable to set key on lock (%2)</source>
        <translation>%1: no se puede establecer la clave en el bloqueo (%2)</translation>
    </message>
    <message>
        <source>%1: permission denied</source>
        <translation>%1: permiso denegado</translation>
    </message>
    <message>
        <source>%1: already exists</source>
        <translation>%1: ya existe</translation>
    </message>
    <message>
        <source>%1: doesn&apos;t exist</source>
        <translation>%1: no existe</translation>
    </message>
    <message>
        <source>%1: out of resources</source>
        <translation>%1: falta de recursos</translation>
    </message>
    <message>
        <source>%1: unknown error: %2</source>
        <translation>%1: error desconocido: %2</translation>
    </message>
    <message>
        <source>%1: invalid size</source>
        <translation>%1: tamaño inválido</translation>
    </message>
    <message>
        <source>%1: key error</source>
        <translation>%1: error de clave</translation>
    </message>
    <message>
        <source>%1: size query failed</source>
        <translation>%1: la consulta del tamaño falló</translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <source>Space</source>
        <extracomment>This and all following &quot;incomprehensible&quot; strings in QShortcut context are key names. Please use the localized names appearing on actual keyboards or whatever is commonly used.</extracomment>
        <translation>Espacio</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Escape</translation>
    </message>
    <message>
        <source>Tab</source>
        <translation>Tabulador</translation>
    </message>
    <message>
        <source>Backtab</source>
        <translation>Tabulador hacia atrás</translation>
    </message>
    <message>
        <source>Backspace</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>Return</source>
        <translation>Retorno</translation>
    </message>
    <message>
        <source>Enter</source>
        <translation>Intro</translation>
    </message>
    <message>
        <source>Ins</source>
        <translation>Insertar</translation>
    </message>
    <message>
        <source>Del</source>
        <translation>Suprimir</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pausa</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimir pantalla</translation>
    </message>
    <message>
        <source>SysReq</source>
        <translation>PetSis</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Inicio</translation>
    </message>
    <message>
        <source>End</source>
        <translation>Fin</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Izquierda</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Arriba</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Derecha</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Abajo</translation>
    </message>
    <message>
        <source>PgUp</source>
        <translation>Re Pág</translation>
    </message>
    <message>
        <source>PgDown</source>
        <translation>Av Pág</translation>
    </message>
    <message>
        <source>CapsLock</source>
        <translation>Bloq Mayús</translation>
    </message>
    <message>
        <source>NumLock</source>
        <translation>Bloqueo Numérico</translation>
    </message>
    <message>
        <source>ScrollLock</source>
        <translation>Bloqueo Desplazamiento</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>Menú</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Anterior</translation>
    </message>
    <message>
        <source>Forward</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Detener</translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <source>Volume Down</source>
        <translation>Bajar el volumen</translation>
    </message>
    <message>
        <source>Volume Mute</source>
        <translation>Silenciar</translation>
    </message>
    <message>
        <source>Volume Up</source>
        <translation>Subir el volumen</translation>
    </message>
    <message>
        <source>Bass Boost</source>
        <translation>Potenciar los graves</translation>
    </message>
    <message>
        <source>Bass Up</source>
        <translation>Subir los graves</translation>
    </message>
    <message>
        <source>Bass Down</source>
        <translation>Bajar los graves</translation>
    </message>
    <message>
        <source>Treble Up</source>
        <translation>Subir los agudos</translation>
    </message>
    <message>
        <source>Treble Down</source>
        <translation>Bajar los agudos</translation>
    </message>
    <message>
        <source>Media Play</source>
        <translation>Reproducir el medio</translation>
    </message>
    <message>
        <source>Media Stop</source>
        <translation>Detener el medio</translation>
    </message>
    <message>
        <source>Media Previous</source>
        <translation>Medio anterior</translation>
    </message>
    <message>
        <source>Media Next</source>
        <translation>Siguiente medio</translation>
    </message>
    <message>
        <source>Media Record</source>
        <translation>Grabar medio</translation>
    </message>
    <message>
        <source>Media Pause</source>
        <extracomment>Media player pause button</extracomment>
        <translation>Pausar Medio</translation>
    </message>
    <message>
        <source>Toggle Media Play/Pause</source>
        <extracomment>Media player button to toggle between playing and paused</extracomment>
        <translation>Reproducir/Pausar Medio</translation>
    </message>
    <message>
        <source>Home Page</source>
        <translation>Página de inicio</translation>
    </message>
    <message>
        <source>Favorites</source>
        <translation>Favoritos</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Búsqueda</translation>
    </message>
    <message>
        <source>Standby</source>
        <translation>Reposo</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation>Abrir URL</translation>
    </message>
    <message>
        <source>Launch Mail</source>
        <translation>Lanzar correo</translation>
    </message>
    <message>
        <source>Launch Media</source>
        <translation>Lanzar medio</translation>
    </message>
    <message>
        <source>Launch (0)</source>
        <translation>Lanzar (0)</translation>
    </message>
    <message>
        <source>Launch (1)</source>
        <translation>Lanzar (1)</translation>
    </message>
    <message>
        <source>Launch (2)</source>
        <translation>Lanzar (2)</translation>
    </message>
    <message>
        <source>Launch (3)</source>
        <translation>Lanzar (3)</translation>
    </message>
    <message>
        <source>Launch (4)</source>
        <translation>Lanzar (4)</translation>
    </message>
    <message>
        <source>Launch (5)</source>
        <translation>Lanzar (5)</translation>
    </message>
    <message>
        <source>Launch (6)</source>
        <translation>Lanzar (6)</translation>
    </message>
    <message>
        <source>Launch (7)</source>
        <translation>Lanzar (7)</translation>
    </message>
    <message>
        <source>Launch (8)</source>
        <translation>Lanzar (8)</translation>
    </message>
    <message>
        <source>Launch (9)</source>
        <translation>Lanzar (9)</translation>
    </message>
    <message>
        <source>Launch (A)</source>
        <translation>Lanzar (A)</translation>
    </message>
    <message>
        <source>Launch (B)</source>
        <translation>Lanzar (B)</translation>
    </message>
    <message>
        <source>Launch (C)</source>
        <translation>Lanzar (C)</translation>
    </message>
    <message>
        <source>Launch (D)</source>
        <translation>Lanzar (D)</translation>
    </message>
    <message>
        <source>Launch (E)</source>
        <translation>Lanzar (E)</translation>
    </message>
    <message>
        <source>Launch (F)</source>
        <translation>Lanzar (F)</translation>
    </message>
    <message>
        <source>Launch (G)</source>
        <translation>Lanzar (G)</translation>
    </message>
    <message>
        <source>Launch (H)</source>
        <translation>Lanzar (H)</translation>
    </message>
    <message>
        <source>Monitor Brightness Up</source>
        <translation>Subir brillo del monitor</translation>
    </message>
    <message>
        <source>Monitor Brightness Down</source>
        <translation>Bajar brillo del monitor</translation>
    </message>
    <message>
        <source>Keyboard Light On/Off</source>
        <translation>Luces del teclado encendidas/apagadas</translation>
    </message>
    <message>
        <source>Keyboard Brightness Up</source>
        <translation>Subir brillo del teclado</translation>
    </message>
    <message>
        <source>Keyboard Brightness Down</source>
        <translation>Bajar brillo del teclado</translation>
    </message>
    <message>
        <source>Power Off</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <source>Wake Up</source>
        <translation>Despertar</translation>
    </message>
    <message>
        <source>Eject</source>
        <translation>Expulsar</translation>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Salvapantallas</translation>
    </message>
    <message>
        <source>WWW</source>
        <translation>WWW</translation>
    </message>
    <message>
        <source>Sleep</source>
        <translation>Dormir</translation>
    </message>
    <message>
        <source>LightBulb</source>
        <translation>Bombilla</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Tienda</translation>
    </message>
    <message>
        <source>History</source>
        <translation>Historial</translation>
    </message>
    <message>
        <source>Add Favorite</source>
        <translation>Añadir favorito</translation>
    </message>
    <message>
        <source>Hot Links</source>
        <translation>Enlaces directos</translation>
    </message>
    <message>
        <source>Adjust Brightness</source>
        <translation>Ajustar brillo</translation>
    </message>
    <message>
        <source>Finance</source>
        <translation>Finanzas</translation>
    </message>
    <message>
        <source>Community</source>
        <translation>Comunidad</translation>
    </message>
    <message>
        <source>Media Rewind</source>
        <translation>Rebobinar medio</translation>
    </message>
    <message>
        <source>Back Forward</source>
        <translation>De vuelta atrás</translation>
    </message>
    <message>
        <source>Application Left</source>
        <translation>Aplicación izquierda</translation>
    </message>
    <message>
        <source>Application Right</source>
        <translation>Aplicación derecha</translation>
    </message>
    <message>
        <source>Book</source>
        <translation>Libro</translation>
    </message>
    <message>
        <source>CD</source>
        <translation>CD</translation>
    </message>
    <message>
        <source>Calculator</source>
        <translation>Calculadora</translation>
    </message>
    <message>
        <source>Calendar</source>
        <translation>Calendario</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Limpiar</translation>
    </message>
    <message>
        <source>Clear Grab</source>
        <translation>Eliminar Bloqueo</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <source>Adjust contrast</source>
        <translation>Ajustar contraste</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <source>Display</source>
        <translation>Monitor</translation>
    </message>
    <message>
        <source>DOS</source>
        <translation>DOS</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>Documentos</translation>
    </message>
    <message>
        <source>Spreadsheet</source>
        <translation>Hoja de Cálculo</translation>
    </message>
    <message>
        <source>Browser</source>
        <translation>Navegador</translation>
    </message>
    <message>
        <source>Game</source>
        <translation>Juego</translation>
    </message>
    <message>
        <source>Go</source>
        <translation>Ir</translation>
    </message>
    <message>
        <source>iTouch</source>
        <translation>iTouch</translation>
    </message>
    <message>
        <source>Logoff</source>
        <translation>Cerrar sesión</translation>
    </message>
    <message>
        <source>Market</source>
        <translation>Mercado</translation>
    </message>
    <message>
        <source>Meeting</source>
        <translation>Reunión</translation>
    </message>
    <message>
        <source>Memo</source>
        <translation>Memo</translation>
    </message>
    <message>
        <source>Keyboard Menu</source>
        <translation>Menú de teclado</translation>
    </message>
    <message>
        <source>Menu PB</source>
        <translation>Menú PB</translation>
    </message>
    <message>
        <source>My Sites</source>
        <translation>Mis Sitios</translation>
    </message>
    <message>
        <source>News</source>
        <translation>Noticias</translation>
    </message>
    <message>
        <source>Home Office</source>
        <translation>Oficina en casa</translation>
    </message>
    <message>
        <source>Option</source>
        <translation>Opción</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Pegar</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>Teléfono</translation>
    </message>
    <message>
        <source>Reply</source>
        <translation>Responder</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Recargar</translation>
    </message>
    <message>
        <source>Rotate Windows</source>
        <translation>Rotar ventanas</translation>
    </message>
    <message>
        <source>Rotation PB</source>
        <translation>Rotar PB</translation>
    </message>
    <message>
        <source>Rotation KB</source>
        <translation>Rotar KB</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Enviar</translation>
    </message>
    <message>
        <source>Spellchecker</source>
        <translation>Corrector ortográfico</translation>
    </message>
    <message>
        <source>Split Screen</source>
        <translation>Pantalla partida</translation>
    </message>
    <message>
        <source>Support</source>
        <translation>Soporte</translation>
    </message>
    <message>
        <source>Task Panel</source>
        <translation>Panel de tareas</translation>
    </message>
    <message>
        <source>Terminal</source>
        <translation>Terminal</translation>
    </message>
    <message>
        <source>To-do list</source>
        <translation>Lista de tareas</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Herramientas</translation>
    </message>
    <message>
        <source>Travel</source>
        <translation>Viajar</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <source>Word Processor</source>
        <translation>Procesador de textos</translation>
    </message>
    <message>
        <source>XFer</source>
        <translation>XFer</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>Acercar</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>Alejar</translation>
    </message>
    <message>
        <source>Away</source>
        <translation>Ausente</translation>
    </message>
    <message>
        <source>Messenger</source>
        <translation>Mensajero</translation>
    </message>
    <message>
        <source>WebCam</source>
        <translation>Cámara web</translation>
    </message>
    <message>
        <source>Mail Forward</source>
        <translation>Reenviar correo</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Fotos</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <source>Battery</source>
        <translation>Batería</translation>
    </message>
    <message>
        <source>Bluetooth</source>
        <translation>Bluetooth</translation>
    </message>
    <message>
        <source>Wireless</source>
        <translation>Conexión inalámbrica</translation>
    </message>
    <message>
        <source>Ultra Wide Band</source>
        <translation>Ultra banda ancha</translation>
    </message>
    <message>
        <source>Media Fast Forward</source>
        <translation>Avance rápido el medio</translation>
    </message>
    <message>
        <source>Audio Repeat</source>
        <translation>Repetición de audio</translation>
    </message>
    <message>
        <source>Audio Random Play</source>
        <translation>Reproducción aleatoria de audio</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Subtítulos</translation>
    </message>
    <message>
        <source>Audio Cycle Track</source>
        <translation>Repetir pistas de audio</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Hora</translation>
    </message>
    <message>
        <source>Hibernate</source>
        <translation>Hibernar</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Vista</translation>
    </message>
    <message>
        <source>Top Menu</source>
        <translation>Menú Superior</translation>
    </message>
    <message>
        <source>Power Down</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <source>Suspend</source>
        <translation>Suspender</translation>
    </message>
    <message>
        <source>Microphone Mute</source>
        <translation>Silenciar micrófono</translation>
    </message>
    <message>
        <source>Red</source>
        <translation>Rojo</translation>
    </message>
    <message>
        <source>Green</source>
        <translation>Verde</translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation>Amarillo</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>Azul</translation>
    </message>
    <message>
        <source>Channel Up</source>
        <translation>Canal arriba</translation>
    </message>
    <message>
        <source>Channel Down</source>
        <translation>Canal abajo</translation>
    </message>
    <message>
        <source>Guide</source>
        <translation>Guía</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Información</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Ajustes</translation>
    </message>
    <message>
        <source>Microphone Volume Up</source>
        <translation>Subir volumen del micrófono</translation>
    </message>
    <message>
        <source>Microphone Volume Down</source>
        <translation>Bajar volumen del micrófono</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Deshacer</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>Rehacer</translation>
    </message>
    <message>
        <source>Print Screen</source>
        <translation>Imprimir pantalla</translation>
    </message>
    <message>
        <source>Page Up</source>
        <translation>Retroceder página</translation>
    </message>
    <message>
        <source>Page Down</source>
        <translation>Avanzar página</translation>
    </message>
    <message>
        <source>Caps Lock</source>
        <translation>Bloqueo de mayúsculas</translation>
    </message>
    <message>
        <source>Num Lock</source>
        <translation>Bloqueo numérico</translation>
    </message>
    <message>
        <source>Number Lock</source>
        <translation>Bloqueo numérico</translation>
    </message>
    <message>
        <source>Scroll Lock</source>
        <translation>Bloqueo del desplazamiento</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Insertar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>Escape</source>
        <translation>Escape</translation>
    </message>
    <message>
        <source>System Request</source>
        <translation>Petición del sistema</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Seleccionar</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Context1</source>
        <translation>Contexto1</translation>
    </message>
    <message>
        <source>Context2</source>
        <translation>Contexto2</translation>
    </message>
    <message>
        <source>Context3</source>
        <translation>Contexto3</translation>
    </message>
    <message>
        <source>Context4</source>
        <translation>Contexto4</translation>
    </message>
    <message>
        <source>Call</source>
        <extracomment>Button to start a call (note: a separate button is used to end the call)</extracomment>
        <translation>Llamar</translation>
    </message>
    <message>
        <source>Hangup</source>
        <extracomment>Button to end a call (note: a separate button is used to start the call)</extracomment>
        <translation>Descolgar</translation>
    </message>
    <message>
        <source>Toggle Call/Hangup</source>
        <extracomment>Button that will hang up if we&apos;re in call, or make a call if we&apos;re not.</extracomment>
        <translation>Alternar llamar/colgar</translation>
    </message>
    <message>
        <source>Flip</source>
        <translation>Voltear</translation>
    </message>
    <message>
        <source>Voice Dial</source>
        <extracomment>Button to trigger voice dialing</extracomment>
        <translation>Marcación por voz</translation>
    </message>
    <message>
        <source>Last Number Redial</source>
        <extracomment>Button to redial the last number called</extracomment>
        <translation>Re-llamar último número</translation>
    </message>
    <message>
        <source>Camera Shutter</source>
        <extracomment>Button to trigger the camera shutter (take a picture)</extracomment>
        <translation>Obturador de cámara</translation>
    </message>
    <message>
        <source>Camera Focus</source>
        <extracomment>Button to focus the camera</extracomment>
        <translation>Enfoque de cámara</translation>
    </message>
    <message>
        <source>Kanji</source>
        <translation>Kanji</translation>
    </message>
    <message>
        <source>Muhenkan</source>
        <translation>Muhenkan</translation>
    </message>
    <message>
        <source>Henkan</source>
        <translation>Henkan</translation>
    </message>
    <message>
        <source>Romaji</source>
        <translation>Romaji</translation>
    </message>
    <message>
        <source>Hiragana</source>
        <translation>Hiragana</translation>
    </message>
    <message>
        <source>Katakana</source>
        <translation>Katakana</translation>
    </message>
    <message>
        <source>Hiragana Katakana</source>
        <translation>Hiragana Katakana</translation>
    </message>
    <message>
        <source>Zenkaku</source>
        <translation>Zenkaku</translation>
    </message>
    <message>
        <source>Hankaku</source>
        <translation>Hankaku</translation>
    </message>
    <message>
        <source>Zenkaku Hankaku</source>
        <translation>Zenkaku Hankaku</translation>
    </message>
    <message>
        <source>Touroku</source>
        <translation>Touroku</translation>
    </message>
    <message>
        <source>Massyo</source>
        <translation>Massyo</translation>
    </message>
    <message>
        <source>Kana Lock</source>
        <translation>Bloqueo Kana</translation>
    </message>
    <message>
        <source>Kana Shift</source>
        <translation>Cambio Kana</translation>
    </message>
    <message>
        <source>Eisu Shift</source>
        <translation>Cambio Eisu</translation>
    </message>
    <message>
        <source>Eisu toggle</source>
        <translation>Alternar Eisu</translation>
    </message>
    <message>
        <source>Code input</source>
        <translation>Introducción de Código</translation>
    </message>
    <message>
        <source>Multiple Candidate</source>
        <translation>Candidatos Múltiples</translation>
    </message>
    <message>
        <source>Previous Candidate</source>
        <translation>Candidato Anterior</translation>
    </message>
    <message>
        <source>Hangul</source>
        <translation>Hangul</translation>
    </message>
    <message>
        <source>Hangul Start</source>
        <translation>Inicio Hangul</translation>
    </message>
    <message>
        <source>Hangul End</source>
        <translation>Final Hangul</translation>
    </message>
    <message>
        <source>Hangul Hanja</source>
        <translation>Hangul Hanga</translation>
    </message>
    <message>
        <source>Hangul Jamo</source>
        <translation>Hangul Jamo</translation>
    </message>
    <message>
        <source>Hangul Romaja</source>
        <translation>Hangul Romaja</translation>
    </message>
    <message>
        <source>Hangul Jeonja</source>
        <translation>Hangul Jeonja</translation>
    </message>
    <message>
        <source>Hangul Banja</source>
        <translation>Hangul Banja</translation>
    </message>
    <message>
        <source>Hangul PreHanja</source>
        <translation>Hangul PreHanja</translation>
    </message>
    <message>
        <source>Hangul PostHanja</source>
        <translation>Hangul PostHanja</translation>
    </message>
    <message>
        <source>Hangul Special</source>
        <translation>Hangul Especial</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Printer</source>
        <translation>Impresora</translation>
    </message>
    <message>
        <source>Execute</source>
        <translation>Ejecutar</translation>
    </message>
    <message>
        <source>Play</source>
        <translation>Reproducir</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Acercar</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <source>Touchpad Toggle</source>
        <translation>Alternar teclado táctil</translation>
    </message>
    <message>
        <source>Touchpad On</source>
        <translation>Encender teclado táctil</translation>
    </message>
    <message>
        <source>Touchpad Off</source>
        <translation>Apagar teclado táctil</translation>
    </message>
    <message>
        <source>Control</source>
        <translation>Control</translation>
    </message>
    <message>
        <source>Ctrl</source>
        <translation>Control</translation>
    </message>
    <message>
        <source>Shift</source>
        <translation>Mayúsculas</translation>
    </message>
    <message>
        <source>Alt</source>
        <translation>Alt</translation>
    </message>
    <message>
        <source>Meta</source>
        <translation>Meta</translation>
    </message>
    <message>
        <source>Num</source>
        <translation>Núm</translation>
    </message>
    <message>
        <source>+</source>
        <extracomment>Key separator in shortcut string</extracomment>
        <translation>+</translation>
    </message>
    <message>
        <source>F%1</source>
        <translation>F%1</translation>
    </message>
</context>
<context>
    <name>QSocks5SocketEngine</name>
    <message>
        <source>Connection to proxy refused</source>
        <translation>Conexión al proxy rechazada</translation>
    </message>
    <message>
        <source>Connection to proxy closed prematurely</source>
        <translation>La conexión con el proxy se cerró prematuramente</translation>
    </message>
    <message>
        <source>Proxy host not found</source>
        <translation>El servidor no se ha encontrado</translation>
    </message>
    <message>
        <source>Connection to proxy timed out</source>
        <translation>El tiempo de conexión al proxy expiró</translation>
    </message>
    <message>
        <source>Proxy authentication failed</source>
        <translation>La autenticación del proxy falló</translation>
    </message>
    <message>
        <source>Proxy authentication failed: %1</source>
        <translation>La autenticación del proxy falló: %1</translation>
    </message>
    <message>
        <source>SOCKS version 5 protocol error</source>
        <translation>SOCK versión 5 error de protocolo</translation>
    </message>
    <message>
        <source>General SOCKSv5 server failure</source>
        <translation>Fallo general del servidor SOCKSv5</translation>
    </message>
    <message>
        <source>Connection not allowed by SOCKSv5 server</source>
        <translation>Conexión no permitida por el servidor SOCKSv5</translation>
    </message>
    <message>
        <source>TTL expired</source>
        <translation>TTL expirado</translation>
    </message>
    <message>
        <source>SOCKSv5 command not supported</source>
        <translation>Comando no soportado por SOCKSv5</translation>
    </message>
    <message>
        <source>Address type not supported</source>
        <translation>Tipo de dirección no soportada</translation>
    </message>
    <message>
        <source>Unknown SOCKSv5 proxy error code 0x%1</source>
        <translation>Código de error de SOCKSv5 proxy desconocido 0x%1</translation>
    </message>
    <message>
        <source>Network operation timed out</source>
        <translation>El tiempo de espera por la operación de red ha expirado</translation>
    </message>
</context>
<context>
    <name>QSpiAccessibleBridge</name>
    <message>
        <source>invalid role</source>
        <extracomment>Role of an accessible object - the object is in an invalid state or could not be constructed</extracomment>
        <translation>rol inválido</translation>
    </message>
    <message>
        <source>title bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>barra de título</translation>
    </message>
    <message>
        <source>menu bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>barra de menú</translation>
    </message>
    <message>
        <source>scroll bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>barra de desplazamiento</translation>
    </message>
    <message>
        <source>grip</source>
        <extracomment>Role of an accessible object - the grip is usually used for resizing another object</extracomment>
        <translation>control</translation>
    </message>
    <message>
        <source>sound</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>sonido</translation>
    </message>
    <message>
        <source>cursor</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>cursor</translation>
    </message>
    <message>
        <source>text caret</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>símbolo de intercalación de texto</translation>
    </message>
    <message>
        <source>alert message</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>mensaje de alerta</translation>
    </message>
    <message>
        <source>frame</source>
        <extracomment>Role of an accessible object: a window with frame and title
----------
Role of an accessible object</extracomment>
        <translation>marco</translation>
    </message>
    <message>
        <source>filler</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>relleno</translation>
    </message>
    <message>
        <source>popup menu</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>menú contextual</translation>
    </message>
    <message>
        <source>menu item</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>elemento de menú</translation>
    </message>
    <message>
        <source>tool tip</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>información contextual</translation>
    </message>
    <message>
        <source>application</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>aplicación</translation>
    </message>
    <message>
        <source>document</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>documento</translation>
    </message>
    <message>
        <source>panel</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>panel</translation>
    </message>
    <message>
        <source>chart</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>gráfico</translation>
    </message>
    <message>
        <source>dialog</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>diálogo</translation>
    </message>
    <message>
        <source>separator</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>separador</translation>
    </message>
    <message>
        <source>tool bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>barra de herramientas</translation>
    </message>
    <message>
        <source>status bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>barra de estado</translation>
    </message>
    <message>
        <source>table</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>tabla</translation>
    </message>
    <message>
        <source>column header</source>
        <extracomment>Role of an accessible object - part of a table</extracomment>
        <translation>encabezado de columna</translation>
    </message>
    <message>
        <source>row header</source>
        <extracomment>Role of an accessible object - part of a table</extracomment>
        <translation>encabezado de fila</translation>
    </message>
    <message>
        <source>column</source>
        <extracomment>Role of an accessible object - part of a table</extracomment>
        <translation>columna</translation>
    </message>
    <message>
        <source>row</source>
        <extracomment>Role of an accessible object - part of a table</extracomment>
        <translation>fila</translation>
    </message>
    <message>
        <source>cell</source>
        <extracomment>Role of an accessible object - part of a table</extracomment>
        <translation>celda</translation>
    </message>
    <message>
        <source>link</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>enlace</translation>
    </message>
    <message>
        <source>help balloon</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>globo de ayuda</translation>
    </message>
    <message>
        <source>assistant</source>
        <extracomment>Role of an accessible object - a helper dialog</extracomment>
        <translation>asistente</translation>
    </message>
    <message>
        <source>list</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>lista</translation>
    </message>
    <message>
        <source>list item</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>elementos de lista</translation>
    </message>
    <message>
        <source>tree</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>árbol</translation>
    </message>
    <message>
        <source>tree item</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>elemento de árbol</translation>
    </message>
    <message>
        <source>page tab</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>pestaña</translation>
    </message>
    <message>
        <source>property page</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>página de propiedades</translation>
    </message>
    <message>
        <source>indicator</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>indicador</translation>
    </message>
    <message>
        <source>graphic</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>gráfico</translation>
    </message>
    <message>
        <source>label</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>etiqueta</translation>
    </message>
    <message>
        <source>text</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>texto</translation>
    </message>
    <message>
        <source>push button</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>botón pulsable</translation>
    </message>
    <message>
        <source>check box</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>casilla de verificación</translation>
    </message>
    <message>
        <source>radio button</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>botón de radio</translation>
    </message>
    <message>
        <source>combo box</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>caja combinada</translation>
    </message>
    <message>
        <source>progress bar</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>barra de progreso</translation>
    </message>
    <message>
        <source>dial</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>marcador</translation>
    </message>
    <message>
        <source>hotkey field</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>campo de acceso rápido</translation>
    </message>
    <message>
        <source>slider</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>deslizador</translation>
    </message>
    <message>
        <source>spin box</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>cuadro de giro</translation>
    </message>
    <message>
        <source>canvas</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>lienzo</translation>
    </message>
    <message>
        <source>animation</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>animación</translation>
    </message>
    <message>
        <source>equation</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>ecuación</translation>
    </message>
    <message>
        <source>button with drop down</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>botón con desplegable</translation>
    </message>
    <message>
        <source>button menu</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>botón de menú</translation>
    </message>
    <message>
        <source>button with drop down grid</source>
        <extracomment>Role of an accessible object - a button that expands a grid.</extracomment>
        <translation>botón con cuadrícula desplegable</translation>
    </message>
    <message>
        <source>space</source>
        <extracomment>Role of an accessible object - blank space between other objects.</extracomment>
        <translation>espacio</translation>
    </message>
    <message>
        <source>page tab list</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>lista de pestañas</translation>
    </message>
    <message>
        <source>clock</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>reloj</translation>
    </message>
    <message>
        <source>splitter</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>delimitador</translation>
    </message>
    <message>
        <source>layered pane</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>panel de capas</translation>
    </message>
    <message>
        <source>web document</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>documento web</translation>
    </message>
    <message>
        <source>paragraph</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>párrafo</translation>
    </message>
    <message>
        <source>section</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>sección</translation>
    </message>
    <message>
        <source>color chooser</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>selector de color</translation>
    </message>
    <message>
        <source>footer</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>pie de página</translation>
    </message>
    <message>
        <source>form</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>formulario</translation>
    </message>
    <message>
        <source>heading</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>encabezado</translation>
    </message>
    <message>
        <source>note</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>nota</translation>
    </message>
    <message>
        <source>complementary content</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>contenido complementario</translation>
    </message>
    <message>
        <source>terminal</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>terminal</translation>
    </message>
    <message>
        <source>desktop</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>escritorio</translation>
    </message>
    <message>
        <source>notification</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>notificación</translation>
    </message>
    <message>
        <source>unknown</source>
        <extracomment>Role of an accessible object</extracomment>
        <translation>desconocido</translation>
    </message>
</context>
<context>
    <name>QSslSocket</name>
    <message>
        <source>Error when setting the OpenSSL configuration (%1)</source>
        <translation>Error al configurar la configuración de OpenSSL (%1)</translation>
    </message>
    <message>
        <source>Error when setting the elliptic curves (%1)</source>
        <translation>Error estableciendo curvas elípticas (%1)</translation>
    </message>
    <message>
        <source>Error creating SSL context (%1)</source>
        <translation>Error al crear el contexto SSL (%1)</translation>
    </message>
    <message>
        <source>unsupported protocol</source>
        <translation>protocolo no soportado</translation>
    </message>
    <message>
        <source>Error while setting the minimal protocol version</source>
        <translation>Error al establecer la versión mínima del protocolo</translation>
    </message>
    <message>
        <source>Error while setting the maximum protocol version</source>
        <translation>Error al establecer la versión máxima del protocolo</translation>
    </message>
    <message>
        <source>Invalid or empty cipher list (%1)</source>
        <translation>Lista de cifras vacía o no válida (%1)</translation>
    </message>
    <message>
        <source>Cannot provide a certificate with no key</source>
        <translation>No se puede proporcionar un certificado sin clave</translation>
    </message>
    <message>
        <source>Diffie-Hellman parameters are not valid</source>
        <translation>Los parámetros de Diffie-Hellman no son válidos</translation>
    </message>
    <message>
        <source>OpenSSL version with disabled elliptic curves</source>
        <translation>Versión de OpenSSL con curvas elípticas deshabilitadas</translation>
    </message>
    <message>
        <source>Expecting QByteArray for %1</source>
        <translation>Se espera QByteArray para %1</translation>
    </message>
    <message>
        <source>An error occurred attempting to set %1 to %2</source>
        <translation>Ocurrió un error al intentar configurar %1 a %2</translation>
    </message>
    <message>
        <source>Wrong value for %1 (%2)</source>
        <translation>Valor incorrecto para %1 (%2)</translation>
    </message>
    <message>
        <source>Unrecognized command %1 = %2</source>
        <translation>Comando no reconocido %1 = %2</translation>
    </message>
    <message>
        <source>SSL_CONF_finish() failed</source>
        <translation>SSL_CONF_finish() falló</translation>
    </message>
    <message>
        <source>SSL_CONF_CTX_new() failed</source>
        <translation>SSL_CONF_CTX_new() falló</translation>
    </message>
    <message>
        <source>Error loading local certificate, %1</source>
        <translation>Error al cargar el certificado local, %1</translation>
    </message>
    <message>
        <source>Error loading private key, %1</source>
        <translation>Error al cargar la clave privada, %1</translation>
    </message>
    <message>
        <source>Private key does not certify public key, %1</source>
        <translation>La clave privada no certifica la clave pública, %1</translation>
    </message>
    <message>
        <source>No error</source>
        <translation>No hay errores</translation>
    </message>
    <message>
        <source>The issuer certificate could not be found</source>
        <translation>El certificado del emisor no puede ser encontrado</translation>
    </message>
    <message>
        <source>The certificate signature could not be decrypted</source>
        <translation>La firma del certificado no puede ser descifrada</translation>
    </message>
    <message>
        <source>The public key in the certificate could not be read</source>
        <translation>La clave pública del certificado no puede ser leída</translation>
    </message>
    <message>
        <source>The signature of the certificate is invalid</source>
        <translation>La firma del certificado es inválida</translation>
    </message>
    <message>
        <source>The certificate is not yet valid</source>
        <translation>El certificado no es todavía válido</translation>
    </message>
    <message>
        <source>The certificate has expired</source>
        <translation>El certificado ha caducado</translation>
    </message>
    <message>
        <source>The certificate&apos;s notBefore field contains an invalid time</source>
        <translation>El campo notBefore del certificado contiene una hora no válida</translation>
    </message>
    <message>
        <source>The certificate&apos;s notAfter field contains an invalid time</source>
        <translation>El campo notAfter del certificado contiene una hora inválida</translation>
    </message>
    <message>
        <source>The certificate is self-signed, and untrusted</source>
        <translation>El certificado está autofirmado, y es no confiable</translation>
    </message>
    <message>
        <source>The root certificate of the certificate chain is self-signed, and untrusted</source>
        <translation>El certificado raíz de la cadena de certificado está autofirmado, y no es confiable</translation>
    </message>
    <message>
        <source>The issuer certificate of a locally looked up certificate could not be found</source>
        <translation>El emisor del certificado de un certificado encontrado localmente no ha podido ser hallado</translation>
    </message>
    <message>
        <source>No certificates could be verified</source>
        <translation>Ningún certificado pudo ser verificado</translation>
    </message>
    <message>
        <source>One of the CA certificates is invalid</source>
        <translation>Uno de los certificados CA es inválido</translation>
    </message>
    <message>
        <source>The basicConstraints path length parameter has been exceeded</source>
        <translation>El tamaño del parámetro de ruta basicConstraints ha sido excedido</translation>
    </message>
    <message>
        <source>The supplied certificate is unsuitable for this purpose</source>
        <translation>El certificado suministrado no es adecuado para este propósito</translation>
    </message>
    <message>
        <source>The root CA certificate is not trusted for this purpose</source>
        <translation>La raíz del certificado CA no es confiable para este propósito</translation>
    </message>
    <message>
        <source>The root CA certificate is marked to reject the specified purpose</source>
        <translation>La raíz del certificado CA está marcado para rechazar el propósito especificado</translation>
    </message>
    <message>
        <source>The current candidate issuer certificate was rejected because its subject name did not match the issuer name of the current certificate</source>
        <translation>El emisor del candidato actual ha sido rechazado porque el nombre del tema no coincide con el nombre del emisor del actual certificado</translation>
    </message>
    <message>
        <source>The current candidate issuer certificate was rejected because its issuer name and serial number was present and did not match the authority key identifier of the current certificate</source>
        <translation>El emisor del candidato actual ha sido rechazado porque el nombre del emisor y su número de serie no está presente y no coincide con la clave de la autoridad identificadora del actual certificado</translation>
    </message>
    <message>
        <source>The peer did not present any certificate</source>
        <translation>El punto no está presente en ningún certificado</translation>
    </message>
    <message>
        <source>The host name did not match any of the valid hosts for this certificate</source>
        <translation>El nombre de equipo no coincidió con ninguno de los equipos válidos para este certificado</translation>
    </message>
    <message>
        <source>The peer certificate is blacklisted</source>
        <translation>El certificado del punto está en la lista negra</translation>
    </message>
    <message>
        <source>No OCSP status response found</source>
        <translation>No se encontró respuesta de estado OCSP</translation>
    </message>
    <message>
        <source>The OCSP status request had invalid syntax</source>
        <translation>La solicitud de estado OCSP tenía una sintaxis inválida</translation>
    </message>
    <message>
        <source>OCSP response contains an unexpected number of SingleResponse structures</source>
        <translation>La respuesta OCSP contiene un número inesperado de estructuras SingleResponse</translation>
    </message>
    <message>
        <source>OCSP responder reached an inconsistent internal state</source>
        <translation>El respondedor OCSP alcanzó un estado interno inconsistente</translation>
    </message>
    <message>
        <source>OCSP responder was unable to return a status for the requested certificate</source>
        <translation>El respondedor OCSP no pudo devolver un estado para el certificado solicitado</translation>
    </message>
    <message>
        <source>The server requires the client to sign the OCSP request in order to construct a response</source>
        <translation>El servidor requiere que el cliente firme la solicitud OCSP para poder construir una respuesta</translation>
    </message>
    <message>
        <source>The client is not authorized to request OCSP status from this server</source>
        <translation>El cliente no está autorizado para solicitar el estado OCSP de este servidor</translation>
    </message>
    <message>
        <source>OCSP responder&apos;s identity cannot be verified</source>
        <translation>No se puede verificar la identidad del respondedor OCSP</translation>
    </message>
    <message>
        <source>The identity of a certificate in an OCSP response cannot be established</source>
        <translation>No se puede establecer la identidad de un certificado en una respuesta OCSP</translation>
    </message>
    <message>
        <source>The certificate status response has expired</source>
        <translation>La respuesta de estado del certificado ha expirado</translation>
    </message>
    <message>
        <source>The certificate&apos;s status is unknown</source>
        <translation>El estado del certificado es desconocido</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Error desconocido</translation>
    </message>
    <message>
        <source>The TLS/SSL connection has been closed</source>
        <translation>La conexión TLS/SSL ha sido cerrada</translation>
    </message>
    <message>
        <source>Error creating SSL session, %1</source>
        <translation>Error al crear la sesión SSL, %1</translation>
    </message>
    <message>
        <source>Error creating SSL session: %1</source>
        <translation>Error al crear la sesión SSL: %1</translation>
    </message>
    <message>
        <source>Unable to init SSL Context: %1</source>
        <translation>Ha sido imposible iniciar el contexto SSL: %1</translation>
    </message>
    <message>
        <source>Unable to write data: %1</source>
        <translation>No es posible escribir los datos: %1</translation>
    </message>
    <message>
        <source>Unable to decrypt data: %1</source>
        <translation>No ha sido posible descifrar los datos: %1</translation>
    </message>
    <message>
        <source>TLS certificate unexpectedly changed during renegotiation!</source>
        <translation>¡El certificado TLS cambió inesperadamente durante la renegociación!</translation>
    </message>
    <message>
        <source>Error while reading: %1</source>
        <translation>Error al leer: %1</translation>
    </message>
    <message>
        <source>Server-side QSslSocket does not support OCSP stapling</source>
        <translation>El QSslSocket del lado del servidor no soporta OCSP stapling</translation>
    </message>
    <message>
        <source>Failed to enable OCSP stapling</source>
        <translation>No se pudo habilitar el OCSP stapling</translation>
    </message>
    <message>
        <source>Client-side sockets do not send OCSP responses</source>
        <translation>Los sockets del lado del cliente no envían respuestas OCSP</translation>
    </message>
    <message>
        <source>Failed to decode OCSP response</source>
        <translation>No se pudo decodificar la respuesta OCSP</translation>
    </message>
    <message>
        <source>Failed to extract basic OCSP response</source>
        <translation>No se pudo extraer la respuesta OCSP básica</translation>
    </message>
    <message>
        <source>No certificate verification store, cannot verify OCSP response</source>
        <translation>No hay almacén de verificación de certificados, no se puede verificar la respuesta OCSP</translation>
    </message>
    <message>
        <source>Failed to decode a SingleResponse from OCSP status response</source>
        <translation>No se pudo decodificar una SingleResponse de la respuesta de estado OCSP</translation>
    </message>
    <message>
        <source>Failed to extract &apos;this update time&apos; from the SingleResponse</source>
        <translation>No se pudo extraer &apos;este tiempo de actualización&apos; de la Respuesta Única</translation>
    </message>
    <message>
        <source>Error during SSL handshake: %1</source>
        <translation>Error durante el handshake SSL: %1</translation>
    </message>
    <message>
        <source>TLS initialization failed</source>
        <translation>La inicialización de TLS falló</translation>
    </message>
    <message>
        <source>Attempted to use an unsupported protocol.</source>
        <translation>Se intentó usar un protocolo no compatible.</translation>
    </message>
    <message>
        <source>Insufficient memory</source>
        <translation>Memoria insuficiente</translation>
    </message>
    <message>
        <source>Internal error</source>
        <translation>Error interno</translation>
    </message>
    <message>
        <source>An internal handle was invalid</source>
        <translation>Un identificador interno era inválido</translation>
    </message>
    <message>
        <source>An internal token was invalid</source>
        <translation>Un token interno era inválido</translation>
    </message>
    <message>
        <source>Access denied</source>
        <translation>Acceso denegado</translation>
    </message>
    <message>
        <source>No authority could be contacted for authorization</source>
        <translation>No se pudo contactar a ninguna autoridad para la autorización</translation>
    </message>
    <message>
        <source>No credentials</source>
        <translation>Sin credenciales</translation>
    </message>
    <message>
        <source>The target is unknown or unreachable</source>
        <translation>El objetivo es desconocido o inalcanzable</translation>
    </message>
    <message>
        <source>An unsupported function was requested</source>
        <translation>Se solicitó una función no compatible</translation>
    </message>
    <message>
        <source>The hostname provided does not match the one received from the peer</source>
        <translation>El nombre de host proporcionado no coincide con el recibido del par</translation>
    </message>
    <message>
        <source>No common protocol exists between the client and the server</source>
        <translation>No existe un protocolo común entre el cliente y el servidor</translation>
    </message>
    <message>
        <source>Unexpected or badly-formatted message received</source>
        <translation>Mensaje inesperado o mal formateado recibido</translation>
    </message>
    <message>
        <source>The data could not be encrypted</source>
        <translation>No se pudieron cifrar los datos</translation>
    </message>
    <message>
        <source>No cipher suites in common</source>
        <translation>No hay suites de cifrado en común</translation>
    </message>
    <message>
        <source>The credentials were not recognized / Invalid argument</source>
        <translation>Las credenciales no fueron reconocidas / Argumento inválido</translation>
    </message>
    <message>
        <source>The message was tampered with, damaged or out of sequence.</source>
        <translation>El mensaje fue alterado, dañado o fuera de seq.</translation>
    </message>
    <message>
        <source>A message was received out of sequence.</source>
        <translation>Se recibió un mensaje fuera de Seq.</translation>
    </message>
    <message>
        <source>Unknown error occurred: %1</source>
        <translation>Ocurrió un error desconocido: %1</translation>
    </message>
    <message>
        <source>Invalid protocol chosen</source>
        <translation>Protocolo inválido elegido</translation>
    </message>
    <message>
        <source>The certificate provided cannot be used for a client.</source>
        <translation>El certificado proporcionado no puede ser utilizado para un cliente.</translation>
    </message>
    <message>
        <source>The certificate provided cannot be used for a server.</source>
        <translation>El certificado proporcionado no puede ser utilizado para un servidor.</translation>
    </message>
    <message>
        <source>Server did not accept any certificate we could present.</source>
        <translation>El servidor no aceptó ningún certificado que pudiéramos presentar.</translation>
    </message>
    <message>
        <source>Algorithm mismatch</source>
        <translation>Desajuste de algoritmo</translation>
    </message>
    <message>
        <source>Handshake failed: %1</source>
        <translation>Fallo en el apretón de manos: %1</translation>
    </message>
    <message>
        <source>Failed to query the TLS context: %1</source>
        <translation>Error al consultar el contexto TLS: %1</translation>
    </message>
    <message>
        <source>Did not get the required attributes for the connection.</source>
        <translation>No se obtuvieron los atributos requeridos para la conexión.</translation>
    </message>
    <message>
        <source>Unwanted protocol was negotiated</source>
        <translation>Se negoció un protocolo no deseado</translation>
    </message>
    <message>
        <source>Renegotiation was unsuccessful: %1</source>
        <translation>La renegociación no fue exitosa: %1</translation>
    </message>
    <message>
        <source>Schannel failed to encrypt data: %1</source>
        <translation>Schannel no pudo cifrar los datos: %1</translation>
    </message>
</context>
<context>
    <name>QStandardPaths</name>
    <message>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>Documentos</translation>
    </message>
    <message>
        <source>Fonts</source>
        <translation>Fuentes</translation>
    </message>
    <message>
        <source>Applications</source>
        <translation>Aplicaciones</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Películas</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Fotos</translation>
    </message>
    <message>
        <source>Temporary Directory</source>
        <translation>Directorio temporal</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Inicio</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Caché</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Shared Data</source>
        <translation>Datos compartidos</translation>
    </message>
    <message>
        <source>Runtime</source>
        <translation>Tiempo de ejecución</translation>
    </message>
    <message>
        <source>Configuration</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <source>Shared Configuration</source>
        <translation>Configuración compartida</translation>
    </message>
    <message>
        <source>Shared Cache</source>
        <translation>Caché compartida</translation>
    </message>
    <message>
        <source>Shared State</source>
        <translation>Estado Compartido</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <source>Public</source>
        <translation>Público</translation>
    </message>
    <message>
        <source>Templates</source>
        <translation>Plantillas</translation>
    </message>
    <message>
        <source>Application Data</source>
        <translation>Datos de aplicación</translation>
    </message>
    <message>
        <source>Application Configuration</source>
        <translation>Configuración de aplicación</translation>
    </message>
    <message>
        <source>Temporary Items</source>
        <extracomment>macOS: Temporary directory</extracomment>
        <translation>Elementos Temporales</translation>
    </message>
</context>
<context>
    <name>QSystemSemaphore</name>
    <message>
        <source>%1: unsupported key type</source>
        <translation>%1: tipo de clave no compatible</translation>
    </message>
    <message>
        <source>%1: permission denied</source>
        <translation>%1: permiso denegado</translation>
    </message>
    <message>
        <source>%1: already exists</source>
        <translation>%1: ya existe</translation>
    </message>
    <message>
        <source>%1: does not exist</source>
        <translation>%1: no existe</translation>
    </message>
    <message>
        <source>%1: out of resources</source>
        <translation>%1: falta de recursos</translation>
    </message>
    <message>
        <source>%1: key too long</source>
        <translation>%1: clave demasiado larga</translation>
    </message>
    <message>
        <source>%1: unknown error: %2</source>
        <translation>%1: error desconocido: %2</translation>
    </message>
    <message>
        <source>%1: key is empty</source>
        <translation>%1: la clave está vacía</translation>
    </message>
    <message>
        <source>%1: System V semaphores are not available for sandboxed applications. Please build Qt with -feature-ipc_posix</source>
        <translation>%1: Los semáforos System V no están disponibles para aplicaciones en entorno aislado. Por favor, compile Qt con -feature-ipc_posix</translation>
    </message>
    <message>
        <source>%1: unable to make key</source>
        <translation>%1: no se puede crear la clave</translation>
    </message>
    <message>
        <source>%1: ftok failed</source>
        <translation>%1: ftok falló</translation>
    </message>
</context>
<context>
    <name>QTabBar</name>
    <message>
        <source>Scroll Left</source>
        <translation>Desplazar hacia la izquierda</translation>
    </message>
    <message>
        <source>Scroll Right</source>
        <translation>Desplazar hacia la derecha</translation>
    </message>
</context>
<context>
    <name>QTcpServer</name>
    <message>
        <source>Operation on socket is not supported</source>
        <translation>Operación en el socket no soportada</translation>
    </message>
</context>
<context>
    <name>QTgaFile</name>
    <message>
        <source>Could not read image data</source>
        <translation>No se pueden leer los datos de la imagen</translation>
    </message>
    <message>
        <source>Sequential device (eg socket) for image read not supported</source>
        <translation>Los dispositivos secuenciales (por ejemplo socket) no están soportados para lectura de imagen</translation>
    </message>
    <message>
        <source>Seek file/device for image read failed</source>
        <translation>Falló el acceso aleatorio para lectura imágenes en archivo/dispositivo</translation>
    </message>
    <message>
        <source>Image header read failed</source>
        <translation>La lectura de la cabecera de imagen falló</translation>
    </message>
    <message>
        <source>Image type not supported</source>
        <translation>El tipo de imagen no está soportado</translation>
    </message>
    <message>
        <source>Image depth not valid</source>
        <translation>Profundidad de imagen no válida</translation>
    </message>
    <message>
        <source>Image size exceeds limit</source>
        <translation>El tamaño de la imagen excede el límite</translation>
    </message>
    <message>
        <source>Could not seek to image read footer</source>
        <translation>No se puede acceder al pie de página de la imagen</translation>
    </message>
    <message>
        <source>Could not read footer</source>
        <translation>No se puede leer el pie de página</translation>
    </message>
    <message>
        <source>Image type (non-TrueVision 2.0) not supported</source>
        <translation>El tipo de imagen (no TrueVision 2.0) no está soportado</translation>
    </message>
    <message>
        <source>Could not reset to read data</source>
        <translation>No se puede reiniciar la lectura de datos</translation>
    </message>
    <message>
        <source>Invalid color map depth (%1)</source>
        <translation>Profundidad del mapa de color inválida (%1)</translation>
    </message>
</context>
<context>
    <name>QUndoGroup</name>
    <message>
        <source>Undo %1</source>
        <translation>Deshacer %1</translation>
    </message>
    <message>
        <source>Undo</source>
        <comment>Default text for undo action</comment>
        <translation>Deshacer</translation>
    </message>
    <message>
        <source>Redo %1</source>
        <translation>Rehacer %1</translation>
    </message>
    <message>
        <source>Redo</source>
        <comment>Default text for redo action</comment>
        <translation>Rehacer</translation>
    </message>
</context>
<context>
    <name>QUndoModel</name>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;vacío&gt;</translation>
    </message>
</context>
<context>
    <name>QUndoStack</name>
    <message>
        <source>Undo %1</source>
        <translation>Deshacer %1</translation>
    </message>
    <message>
        <source>Undo</source>
        <comment>Default text for undo action</comment>
        <translation>Deshacer</translation>
    </message>
    <message>
        <source>Redo %1</source>
        <translation>Rehacer %1</translation>
    </message>
    <message>
        <source>Redo</source>
        <comment>Default text for redo action</comment>
        <translation>Rehacer</translation>
    </message>
</context>
<context>
    <name>QUnicodeControlCharacterMenu</name>
    <message>
        <source>LRM Left-to-right mark</source>
        <translation>LRM Marca de-izquierda-a-derecha</translation>
    </message>
    <message>
        <source>RLM Right-to-left mark</source>
        <translation>RLM Marca de-derecha-a-izquierda</translation>
    </message>
    <message>
        <source>ZWJ Zero width joiner</source>
        <translation>ZWJ Zero width joiner</translation>
    </message>
    <message>
        <source>ZWNJ Zero width non-joiner</source>
        <translation>ZWNJ Zero width non-joiner</translation>
    </message>
    <message>
        <source>ZWSP Zero width space</source>
        <translation>ZWSP Zero width space</translation>
    </message>
    <message>
        <source>LRE Start of left-to-right embedding</source>
        <translation>LRE Start of left-to-right embedding</translation>
    </message>
    <message>
        <source>RLE Start of right-to-left embedding</source>
        <translation>RLE Start of right-to-left embedding</translation>
    </message>
    <message>
        <source>LRO Start of left-to-right override</source>
        <translation>LRO Start of left-to-right override</translation>
    </message>
    <message>
        <source>RLO Start of right-to-left override</source>
        <translation>RLO Start of right-to-left override</translation>
    </message>
    <message>
        <source>PDF Pop directional formatting</source>
        <translation>PDF Pop directional formatting</translation>
    </message>
    <message>
        <source>LRI Left-to-right isolate</source>
        <translation>LRI Left-to-right isolate</translation>
    </message>
    <message>
        <source>RLI Right-to-left isolate</source>
        <translation>RLI Right-to-left isolate</translation>
    </message>
    <message>
        <source>FSI First strong isolate</source>
        <translation>FSI First strong isolate</translation>
    </message>
    <message>
        <source>PDI Pop directional isolate</source>
        <translation>PDI Pop directional isolate</translation>
    </message>
    <message>
        <source>Insert Unicode control character</source>
        <translation>Insertar carácter de control Unicode</translation>
    </message>
</context>
<context>
    <name>QWhatsThisAction</name>
    <message>
        <source>What&apos;s This?</source>
        <translation>¿Qué es esto?</translation>
    </message>
</context>
<context>
    <name>QWidget</name>
    <message>
        <source>*</source>
        <translation>*</translation>
    </message>
</context>
<context>
    <name>QWidgetTextControl</name>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Deshacer</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Rehacer</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>Cor&amp;tar</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <source>Copy &amp;Link Location</source>
        <translation>Copiar la ubicación del en&amp;lace</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Pegar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Seleccionar todo</translation>
    </message>
</context>
<context>
    <name>QWindowsDirect2DIntegration</name>
    <message>
        <source>Qt cannot load the direct2d platform plugin because the Direct2D version on this system is too old. The minimum system requirement for this platform plugin is Windows 7 SP1 with Platform Update.

The minimum Direct2D version required is %1. The Direct2D version on this system is %2.</source>
        <translation>Qt no puede cargar el complemento de plataforma direct2d porque la versión de Direct2D en este sistema es demasiado antigua. El requisito mínimo del sistema para este complemento de plataforma es Windows 7 SP1 con la Actualización de Plataforma.

La versión mínima de Direct2D requerida es %1. La versión de Direct2D en este sistema es %2.</translation>
    </message>
    <message>
        <source>Cannot load direct2d platform plugin</source>
        <translation>No se puede cargar el plugin de plataforma direct2d</translation>
    </message>
</context>
<context>
    <name>QWizard</name>
    <message>
        <source>Go Back</source>
        <translation>Ir atrás</translation>
    </message>
    <message>
        <source>&lt; &amp;Back</source>
        <translation>&lt; &amp;Atrás</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Continuar</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>Siguie&amp;nte</translation>
    </message>
    <message>
        <source>&amp;Next &gt;</source>
        <translation>Siguie&amp;nte &gt;</translation>
    </message>
    <message>
        <source>Commit</source>
        <translation>Enviar</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Hecho</translation>
    </message>
    <message>
        <source>&amp;Finish</source>
        <translation>&amp;Finalizar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ayuda</translation>
    </message>
</context>
<context>
    <name>QXmlStream</name>
    <message>
        <source>Extra content at end of document.</source>
        <translation>Contenido extra al final del documento.</translation>
    </message>
    <message>
        <source>Invalid entity value.</source>
        <translation>Valor de la entidad no válido.</translation>
    </message>
    <message>
        <source>Invalid XML character.</source>
        <translation>Carácter XML no válido.</translation>
    </message>
    <message>
        <source>Sequence &apos;]]&gt;&apos; not allowed in content.</source>
        <translation>Secuencia «]]&gt;» no permitida en el contenido.</translation>
    </message>
    <message>
        <source>Encountered incorrectly encoded content.</source>
        <translation>Contenido codificado incorrectamente encontrado.</translation>
    </message>
    <message>
        <source>Namespace prefix &apos;%1&apos; not declared</source>
        <translation>Prefijo de espacio de nombres «%1» no declarado</translation>
    </message>
    <message>
        <source>Illegal namespace declaration.</source>
        <translation>Declaración de espacio de nombres ilegal.</translation>
    </message>
    <message>
        <source>Attribute &apos;%1&apos; redefined.</source>
        <translation>El atributo «%1» está redefinido.</translation>
    </message>
    <message>
        <source>Unexpected character &apos;%1&apos; in public id literal.</source>
        <translation>Carácter «%1» inesperado en un literal de identificación público.</translation>
    </message>
    <message>
        <source>Invalid XML version string.</source>
        <translation>Cadena de versión XML no válida.</translation>
    </message>
    <message>
        <source>Unsupported XML version.</source>
        <translation>Versión XML no soportada.</translation>
    </message>
    <message>
        <source>The standalone pseudo attribute must appear after the encoding.</source>
        <translation>El pseudoatributo «standalone» debe aparece después de la codificación.</translation>
    </message>
    <message>
        <source>%1 is an invalid encoding name.</source>
        <translation>%1 es un nombre de codificación no válido.</translation>
    </message>
    <message>
        <source>Encoding %1 is unsupported</source>
        <translation>No se admite la codificación %1</translation>
    </message>
    <message>
        <source>Standalone accepts only yes or no.</source>
        <translation>«Standalone» sólo acepta «sí» o «no».</translation>
    </message>
    <message>
        <source>Invalid attribute in XML declaration: %1 = %2</source>
        <translation>Atributo inválido en la declaración XML: %1 = %2</translation>
    </message>
    <message>
        <source>Length of XML attribute name exceeds implementation limits (4KiB characters).</source>
        <translation>La longitud del nombre del atributo XML excede los límites de implementación (4KiB caracteres).</translation>
    </message>
    <message>
        <source>&apos;%1&apos;</source>
        <comment>expected</comment>
        <extracomment>&apos;&lt;first option&gt;&apos;</extracomment>
        <translation>&apos;%1&apos;</translation>
    </message>
    <message>
        <source>%1 or &apos;%2&apos;</source>
        <comment>expected</comment>
        <extracomment>&lt;first option&gt;, &apos;&lt;second option&gt;&apos;</extracomment>
        <translation>%1 o &apos;%2&apos;</translation>
    </message>
    <message>
        <source>%1, &apos;%2&apos;</source>
        <comment>expected</comment>
        <extracomment>&lt;options so far&gt;, &apos;&lt;next option&gt;&apos;</extracomment>
        <translation>%1, &apos;%2&apos;</translation>
    </message>
    <message>
        <source>%1, or &apos;%2&apos;</source>
        <comment>expected</comment>
        <extracomment>&lt;options so far&gt;, or &apos;&lt;final option&gt;&apos;</extracomment>
        <translation>%1, o &apos;%2&apos;</translation>
    </message>
    <message>
        <source>Expected %1, but got &apos;%2&apos;.</source>
        <translation>Se esperaba %1, pero se obtuvo &apos;%2&apos;.</translation>
    </message>
    <message>
        <source>Unexpected &apos;%1&apos;.</source>
        <translation>&apos;%1&apos; inesperado.</translation>
    </message>
    <message>
        <source>Unexpected token type %1 in %2.</source>
        <translation>Tipo de token inesperado %1 en %2.</translation>
    </message>
    <message>
        <source>Found second DTD token in %1.</source>
        <translation>Se encontró un segundo token DTD en %1.</translation>
    </message>
    <message>
        <source>Premature end of document.</source>
        <translation>Final prematuro del documento.</translation>
    </message>
    <message>
        <source>Invalid document.</source>
        <translation>Documento no válido.</translation>
    </message>
    <message>
        <source>Expected character data.</source>
        <translation>Se esperaban datos de carácter.</translation>
    </message>
    <message>
        <source>Start tag expected.</source>
        <translation>Se esperaba etiqueta de inicio.</translation>
    </message>
    <message>
        <source>NDATA in parameter entity declaration.</source>
        <translation>NDATA en una declaración de entidad parámetro.</translation>
    </message>
    <message>
        <source>XML declaration not at start of document.</source>
        <translation>La declaración XML no está al principio del documento.</translation>
    </message>
    <message>
        <source>%1 is an invalid processing instruction name.</source>
        <translation>%1 es un nombre de instrucción de procesamiento no válido.</translation>
    </message>
    <message>
        <source>Invalid processing instruction name.</source>
        <translation>Nombre de instrucción de procesamiento no válido.</translation>
    </message>
    <message>
        <source>%1 is an invalid PUBLIC identifier.</source>
        <translation>%1 no es un identificador PUBLIC válido.</translation>
    </message>
    <message>
        <source>Invalid XML name.</source>
        <translation>Nombre XML no válido.</translation>
    </message>
    <message>
        <source>Opening and ending tag mismatch.</source>
        <translation>Las etiquetas de apertura y cierre no coinciden.</translation>
    </message>
    <message>
        <source>Entity &apos;%1&apos; not declared.</source>
        <translation>Entidad «%1» no declarada.</translation>
    </message>
    <message>
        <source>Reference to unparsed entity &apos;%1&apos;.</source>
        <translation>Referencia a una entidad no analizada «%1».</translation>
    </message>
    <message>
        <source>Reference to external entity &apos;%1&apos; in attribute value.</source>
        <translation>Referencia a una entidad externa «%1» en el valor del atributo.</translation>
    </message>
    <message>
        <source>Invalid character reference.</source>
        <translation>Referencia un carácter no válido.</translation>
    </message>
    <message>
        <source>Self-referencing entity detected.</source>
        <translation>Entidad auto-referenciada detectada.</translation>
    </message>
    <message>
        <source>Entity expands to more characters than the entity expansion limit.</source>
        <translation>La entidad se expande a más caracteres que el límite de expansión de entidad.</translation>
    </message>
</context>
<context>
    <name>QAxSelect</name>
    <message>
        <source>Select ActiveX Control</source>
        <translation>Seleccionar Control ActiveX</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Filtro</translation>
    </message>
    <message>
        <source>COM &amp;Object:</source>
        <translation>Objeto &amp; COM:</translation>
    </message>
    <message>
        <source>Sandboxing:</source>
        <translation>Aislamiento:</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <source>In process</source>
        <translation>En proceso</translation>
    </message>
    <message>
        <source>Out of process</source>
        <translation>Fuera de proceso</translation>
    </message>
    <message>
        <source>CLSID:</source>
        <translation>CLSID:</translation>
    </message>
    <message>
        <source>Key:</source>
        <translation>Clave:</translation>
    </message>
    <message>
        <source>Word&amp;nbsp;size:</source>
        <translation>Texto&amp;nbsp;Tamaño:</translation>
    </message>
    <message>
        <source>DLL:</source>
        <translation>DLL:</translation>
    </message>
    <message>
        <source>Binary:</source>
        <translation>Binario:</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation>Versión:</translation>
    </message>
</context>
<context>
    <name>QFactoryLoader</name>
    <message>
        <source>Invalid metadata version</source>
        <translation>Versión de metadatos inválida</translation>
    </message>
    <message>
        <source>Metadata parsing error: %1</source>
        <translation>Error al analizar metadatos: %1</translation>
    </message>
    <message>
        <source>Unexpected metadata contents</source>
        <translation>Contenido de metadatos inesperado</translation>
    </message>
</context>
<context>
    <name>QAbstractFileIconProvider</name>
    <message>
        <source>Drive</source>
        <translation>Unidad</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <source>File Folder</source>
        <comment>Match Windows Explorer</comment>
        <translation>Carpeta de archivos</translation>
    </message>
    <message>
        <source>Folder</source>
        <comment>All other platforms</comment>
        <translation>Carpeta</translation>
    </message>
    <message>
        <source>Alias</source>
        <comment>macOS Finder</comment>
        <translation>Alias</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <comment>All other platforms</comment>
        <translation>Acceso directo</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Desconocido</translation>
    </message>
</context>
<context>
    <name>QSctpSocket</name>
    <message>
        <source>The remote host closed the connection</source>
        <translation>El host remoto cerró la conexión</translation>
    </message>
</context>
<context>
    <name>QUdpSocket</name>
    <message>
        <source>Unable to send a datagram</source>
        <translation>No se puede enviar un datagrama</translation>
    </message>
    <message>
        <source>No datagram available for reading</source>
        <translation>No hay datagramas disponibles para leer</translation>
    </message>
</context>
<context>
    <name>QDtls</name>
    <message>
        <source>Multicast and broadcast addresses are not supported</source>
        <translation>No se admiten direcciones de multidifusión y difusión</translation>
    </message>
    <message>
        <source>Cannot set peer after handshake started</source>
        <translation>No se puede establecer el par después de que el handshake haya comenzado</translation>
    </message>
    <message>
        <source>Invalid address</source>
        <translation>Dirección inválida</translation>
    </message>
    <message>
        <source>Cannot set verification name after handshake started</source>
        <translation>No se puede establecer el nombre de verificación después de que el handshake haya comenzado</translation>
    </message>
    <message>
        <source>Cannot set configuration after handshake started</source>
        <translation>No se puede establecer la configuración después de que el handshake haya comenzado</translation>
    </message>
    <message>
        <source>Cannot start/continue handshake, invalid handshake state</source>
        <translation>No se puede iniciar/continuar el handshake, estado de handshake inválido</translation>
    </message>
    <message>
        <source>Invalid (nullptr) socket</source>
        <translation>Socket inválido (nullptr)</translation>
    </message>
    <message>
        <source>To start a handshake you must set peer&apos;s address and port first</source>
        <translation>Para iniciar un handshake, primero debe establecer la dirección y el puerto del par</translation>
    </message>
    <message>
        <source>To start a handshake, DTLS server requires non-empty datagram (client hello)</source>
        <translation>Para iniciar un handshake, el servidor DTLS requiere un datagrama no vacío (client hello)</translation>
    </message>
    <message>
        <source>Cannot start handshake, already done/in progress</source>
        <translation>No se puede iniciar el handshake, ya realizado/en progreso</translation>
    </message>
    <message>
        <source>A valid QUdpSocket and non-empty datagram are needed to continue the handshake</source>
        <translation>Se necesita un QUdpSocket válido y un datagrama no vacío para continuar con el handshake</translation>
    </message>
    <message>
        <source>Cannot continue handshake, not in InProgress state</source>
        <translation>No se puede continuar el handshake, no está en estado InProgress</translation>
    </message>
    <message>
        <source>Cannot resume, not in VerificationError state</source>
        <translation>No se puede reanudar, no está en estado de VerificationError</translation>
    </message>
    <message>
        <source>No handshake in progress, nothing to abort</source>
        <translation>No hay handshake en progreso, nada que abortar</translation>
    </message>
    <message>
        <source>Cannot send shutdown alert, not encrypted</source>
        <translation>No se puede enviar alerta de cierre, no está cifrado</translation>
    </message>
    <message>
        <source>Cannot write a datagram, not in encrypted state</source>
        <translation>No se puede escribir un datagrama, no está en estado cifrado</translation>
    </message>
    <message>
        <source>Cannot read a datagram, not in encrypted state</source>
        <translation>No se puede leer un datagrama, no está en estado cifrado</translation>
    </message>
    <message>
        <source>%1 failed</source>
        <extracomment>%1: Some function</extracomment>
        <translation>%1 falló</translation>
    </message>
    <message>
        <source>Invalid SslMode, SslServerMode or SslClientMode expected</source>
        <translation>SslMode, SslServerMode o SslClientMode inválido, se esperaba uno válido</translation>
    </message>
    <message>
        <source>Invalid protocol version, DTLS protocol expected</source>
        <translation>Versión de protocolo inválida, se esperaba protocolo DTLS</translation>
    </message>
    <message>
        <source>BIO_ADD_new failed, cannot start handshake</source>
        <translation>BIO_ADD_New falló, no se puede iniciar el handshake</translation>
    </message>
    <message>
        <source>Cannot start the handshake, verified client hello expected</source>
        <translation>No se puede iniciar el handshake, se espera un client hello verificado</translation>
    </message>
    <message>
        <source>Peer verification failed</source>
        <translation>La verificación del par falló</translation>
    </message>
    <message>
        <source>The DTLS connection has been closed</source>
        <translation>La conexión DTLS ha sido cerrada</translation>
    </message>
    <message>
        <source>Error while writing: %1</source>
        <translation>Error al escribir: %1</translation>
    </message>
    <message>
        <source>The DTLS connection has been shutdown</source>
        <translation>La conexión DTLS ha sido cerrada</translation>
    </message>
    <message>
        <source>Error while reading: %1</source>
        <translation>Error al leer: %1</translation>
    </message>
    <message>
        <source>Invalid (empty) secret</source>
        <translation>Secreto inválido (vacío)</translation>
    </message>
</context>
<context>
    <name>QDtlsClientVerifier</name>
    <message>
        <source>A valid UDP socket, non-empty datagram, and valid address/port were expected</source>
        <translation>Se esperaba un socket UDP válido, un datagrama no vacío y una dirección/puerto válidos</translation>
    </message>
    <message>
        <source>BIO_ADDR_new failed, ignoring client hello</source>
        <translation>BIO_ADDR_New falló, ignorando client hello</translation>
    </message>
</context>
<context>
    <name>QSslDiffieHellmanParameter</name>
    <message>
        <source>No error</source>
        <translation>Sin error</translation>
    </message>
    <message>
        <source>Invalid input data</source>
        <translation>Datos de entrada no válidos</translation>
    </message>
    <message>
        <source>The given Diffie-Hellman parameters are deemed unsafe</source>
        <translation>Los parámetros de Diffie-Hellman dados se consideran inseguros</translation>
    </message>
</context>
<context>
    <name>QCocoaMenuBar</name>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
</context>
<context>
    <name>quiaccessibilityelement</name>
    <message>
        <source>checked</source>
        <translation>verificado</translation>
    </message>
    <message>
        <source>unchecked</source>
        <translation>desmarcado</translation>
    </message>
</context>
<context>
    <name>QCupsPrinterSupport</name>
    <message>
        <source>Authentication Needed</source>
        <translation>Se necesita autenticación</translation>
    </message>
    <message>
        <source>Authentication needed to use %1.</source>
        <translation>Se necesita autenticación para usar %1.</translation>
    </message>
    <message>
        <source>Authentication needed to use %1 on %2.</source>
        <translation>Se necesita autenticación para usar %1 en %2.</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Nombre de usuario:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
</context>
<context>
    <name>QMimerSQL</name>
    <message>
        <source>No Mimer SQL error for code %1</source>
        <translation>No hay error de Mimer SQL para el código %1</translation>
    </message>
    <message>
        <source>Generic Mimer SQL error</source>
        <translation>Error genérico de Mimer SQL</translation>
    </message>
</context>
<context>
    <name>QMimerSQLResult</name>
    <message>
        <source>Could not get %1, column %2</source>
        <extracomment>Data type, column</extracomment>
        <translation>No se pudo obtener %1, col %2</translation>
    </message>
    <message>
        <source>Could not set %1, parameter %2</source>
        <extracomment>Data type, parameter</extracomment>
        <translation>No se pudo establecer %1, parámetro %2</translation>
    </message>
    <message>
        <source>Could not close cursor</source>
        <translation>No se pudo cerrar el cursor</translation>
    </message>
    <message>
        <source>Could not close statement</source>
        <translation>No se pudo cerrar la declaración</translation>
    </message>
    <message>
        <source>Fetch did not succeed</source>
        <translation>La obtención no tuvo éxito</translation>
    </message>
    <message>
        <source>Fetch first did not succeed</source>
        <translation>La primera obtención no tuvo éxito</translation>
    </message>
    <message>
        <source>Could not fetch next row</source>
        <translation>No se pudo obtener la siguiente fila</translation>
    </message>
    <message>
        <source>Unknown data type %1</source>
        <translation>Tipo de dato desconocido %1</translation>
    </message>
    <message>
        <source>Could not check null, column %1</source>
        <translation>No se pudo verificar nulo, col %1</translation>
    </message>
    <message>
        <source>Could not prepare/execute statement</source>
        <translation>No se pudo preparar/ejecutar la declaración</translation>
    </message>
    <message>
        <source>Wrong number of parameters</source>
        <translation>Número incorrecto de parámetros</translation>
    </message>
    <message>
        <source>Unknown datatype, parameter %1</source>
        <translation>Tipo de dato desconocido, parámetro %1</translation>
    </message>
    <message>
        <source>Could not execute statement/open cursor</source>
        <translation>No se pudo ejecutar la declaración/abrir el cursor</translation>
    </message>
    <message>
        <source>Only input parameters can be used in batch operations</source>
        <translation>Solo se pueden usar parámetros de entrada en operaciones por lotes</translation>
    </message>
    <message>
        <source>Could not add batch %1</source>
        <extracomment>%1 is the batch number</extracomment>
        <translation>No se pudo agregar el lote %1</translation>
    </message>
    <message>
        <source>Could not execute batch</source>
        <translation>No se pudo ejecutar el lote</translation>
    </message>
</context>
<context>
    <name>QMimerSQLResult:</name>
    <message>
        <source>Fetch last did not succeed</source>
        <translation>La última obtención no tuvo éxito</translation>
    </message>
    <message>
        <source>Column %1 out of range</source>
        <translation>Col %1 fuera de rango</translation>
    </message>
</context>
<context>
    <name>QMimerSQLDriver</name>
    <message>
        <source>Could not connect to database</source>
        <translation>No se pudo conectar a la base de datos</translation>
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation>No se pudo iniciar la transacción</translation>
    </message>
    <message>
        <source>Could not commit transaction</source>
        <translation>No se pudo confirmar la transacción</translation>
    </message>
    <message>
        <source>Could not roll back transaction</source>
        <translation>No se pudo revertir la transacción</translation>
    </message>
</context>
<context>
    <name>Print Device Input Slot</name>
    <message>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
</context>
<context>
    <name>Print Device Output Bin</name>
    <message>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
</context>
<context>
    <name>QDomParser</name>
    <message>
        <source>Error occurred while processing XML declaration</source>
        <translation>Ocurrió un error al procesar la declaración XML</translation>
    </message>
    <message>
        <source>Multiple DTD sections are not allowed</source>
        <translation>No se permiten múltiples secciones DTD</translation>
    </message>
    <message>
        <source>Error occurred while processing document type declaration</source>
        <translation>Ocurrió un error al procesar la declaración del tipo de documento</translation>
    </message>
    <message>
        <source>Error occurred while processing comment</source>
        <translation>Ocurrió un error al procesar el comentario</translation>
    </message>
    <message>
        <source>Error occurred while processing a processing instruction</source>
        <translation>Ocurrió un error al procesar una instrucción de procesamiento</translation>
    </message>
    <message>
        <source>Error occurred while processing a start element</source>
        <translation>Ocurrió un error al procesar un elemento de inicio</translation>
    </message>
    <message>
        <source>Unexpected end element &apos;%1&apos;</source>
        <translation>Elemento final inesperado &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Error occurred while processing an end element</source>
        <translation>Ocurrió un error al procesar un elemento final</translation>
    </message>
    <message>
        <source>Error occurred while processing the element content</source>
        <translation>Ocurrió un error al procesar el contenido del elemento</translation>
    </message>
    <message>
        <source>Error occurred while processing comments</source>
        <translation>Ocurrió un error al procesar los comentarios</translation>
    </message>
    <message>
        <source>Error occurred while processing an entity reference</source>
        <translation>Ocurrió un error al procesar una referencia de entidad</translation>
    </message>
    <message>
        <source>Unexpected token</source>
        <translation>Token inesperado</translation>
    </message>
    <message>
        <source>Tag mismatch</source>
        <translation>Desajuste de etiqueta</translation>
    </message>
    <message>
        <source>Error occurred while processing entity declaration</source>
        <translation>Ocurrió un error al procesar la declaración de entidad</translation>
    </message>
    <message>
        <source>Error occurred while processing notation declaration</source>
        <translation>Ocurrió un error al procesar la declaración de notación</translation>
    </message>
</context>
<context>
    <name>Assets::Downloader::AssetDownloader</name>
    <message>
        <source>Downloading JSON file...</source>
        <translation>Descargando archivo JSON...</translation>
    </message>
    <message>
        <source>Downloading zip file...</source>
        <translation>Descargando archivo zip...</translation>
    </message>
    <message>
        <source>Unzipping...</source>
        <translation>Descomprimiendo...</translation>
    </message>
    <message>
        <source>Downloading assets...</source>
        <translation>Descargando recursos...</translation>
    </message>
    <message>
        <source>Copying assets...</source>
        <translation>Copiando recursos...</translation>
    </message>
</context>
</TS>
