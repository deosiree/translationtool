<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>MFPlayerSession</name>
    <message>
        <source>Invalid stream source.</source>
        <translation>Fuente de flujo no válida.</translation>
    </message>
    <message>
        <source>Attempting to play invalid Qt resource.</source>
        <translation>Intentando reproducir un recurso Qt no válido.</translation>
    </message>
    <message>
        <source>The system cannot find the file specified.</source>
        <translation>El sistema no puede encontrar el archivo especificado.</translation>
    </message>
    <message>
        <source>The specified server could not be found.</source>
        <translation>No se pudo encontrar el servidor especificado.</translation>
    </message>
    <message>
        <source>Unsupported media type.</source>
        <translation>Tipo de medios no compatible.</translation>
    </message>
    <message>
        <source>Unsupported URL scheme.</source>
        <translation>Esquema de URL no compatible.</translation>
    </message>
    <message>
        <source>Connection to server could not be established.</source>
        <translation>No se pudo establecer la conexión con el servidor.</translation>
    </message>
    <message>
        <source>Failed to load source.</source>
        <translation>Error al cargar la fuente.</translation>
    </message>
    <message>
        <source>Cannot create presentation descriptor.</source>
        <translation>No se puede crear descriptor de presentación.</translation>
    </message>
    <message>
        <source>Failed to get stream count.</source>
        <translation>Error al obtener el conteo de flujos.</translation>
    </message>
    <message>
        <source>Failed to create topology.</source>
        <translation>Error al crear la topo.</translation>
    </message>
    <message>
        <source>Unable to play any stream.</source>
        <translation>No se puede reproducir ningún flujo.</translation>
    </message>
    <message>
        <source>Unable to play.</source>
        <translation>No se puede reproducir.</translation>
    </message>
    <message>
        <source>Failed to set topology.</source>
        <translation>Error al establecer la topo.</translation>
    </message>
    <message>
        <source>Unknown stream type.</source>
        <translation>Tipo de flujo desconocido.</translation>
    </message>
    <message>
        <source>Failed to stop.</source>
        <translation>Error al detener.</translation>
    </message>
    <message>
        <source>failed to start playback</source>
        <translation>fallo al iniciar la reproducción</translation>
    </message>
    <message>
        <source>Failed to pause.</source>
        <translation>Error al pausar.</translation>
    </message>
    <message>
        <source>Unable to create mediasession.</source>
        <translation>No se puede crear la sesión de medios.</translation>
    </message>
    <message>
        <source>Unable to pull session events.</source>
        <translation>No se pueden extraer eventos de la sesión.</translation>
    </message>
    <message>
        <source>Failed to seek.</source>
        <translation>Error al buscar.</translation>
    </message>
    <message>
        <source>Media session non-fatal error.</source>
        <translation>Error no fatal de la sesión de medios.</translation>
    </message>
    <message>
        <source>Error reading from the network.</source>
        <translation>Error al leer de la red.</translation>
    </message>
    <message>
        <source>Error writing to the network.</source>
        <translation>Error al escribir en la red.</translation>
    </message>
    <message>
        <source>Network packets might be blocked by a firewall.</source>
        <translation>Los paquetes de red podrían estar bloqueados por un firewall.</translation>
    </message>
    <message>
        <source>Media session state error.</source>
        <translation>Error de estado de la sesión de medios.</translation>
    </message>
    <message>
        <source>Invalid stream data.</source>
        <translation>Datos de flujo no válidos.</translation>
    </message>
    <message>
        <source>Media session serious error.</source>
        <translation>Error grave de la sesión de medios.</translation>
    </message>
    <message>
        <source>Unsupported media, a codec is missing.</source>
        <translation>Medios no compatibles, falta un códec.</translation>
    </message>
</context>
<context>
    <name>QAndroidCameraSession</name>
    <message>
        <source>Failed to capture image</source>
        <translation>Error al capturar imagen</translation>
    </message>
    <message>
        <source>Camera preview failed to start.</source>
        <translation>Error al iniciar la vista previa de la cámara.</translation>
    </message>
    <message>
        <source>File is not available: %1</source>
        <translation>El archivo no está disponible: %1</translation>
    </message>
    <message>
        <source>Could not save to file: %1</source>
        <translation>No se pudo guardar en el archivo: %1</translation>
    </message>
</context>
<context>
    <name>QAudioDecoder</name>
    <message>
        <source>QAudioDecoder not supported.</source>
        <translation>QAudioDecoder no soportado.</translation>
    </message>
</context>
<context>
    <name>QMediaPlayer</name>
    <message>
        <source>Attempting to play invalid Qt resource</source>
        <translation>Intentando reproducir un recurso Qt no válido</translation>
    </message>
    <message>
        <source>Could not open file</source>
        <translation>No se pudo abrir el archivo</translation>
    </message>
    <message>
        <source>Could not find stream information for media file</source>
        <translation>No se pudo encontrar información de flujo para el archivo multimedia</translation>
    </message>
</context>
<context>
    <name>QImageCapture</name>
    <message>
        <source>Could not capture in stopped state</source>
        <translation>No se pudo capturar en estado detenido</translation>
    </message>
    <message>
        <source>Camera is not ready.</source>
        <translation>La cámara no está lista.</translation>
    </message>
    <message>
        <source>No instance of QImageCapture set on QMediaCaptureSession.</source>
        <translation>No se ha establecido una instancia de QImageCapture en QMediaCaptureSession.</translation>
    </message>
</context>
<context>
    <name>QMediaRecorder</name>
    <message>
        <source>Pause not supported</source>
        <translation>Pausa no soportada</translation>
    </message>
    <message>
        <source>Resume not supported</source>
        <translation>Reanudar no soportado</translation>
    </message>
    <message>
        <source>Failed to start recording</source>
        <translation>Error al iniciar la grabación</translation>
    </message>
    <message>
        <source>Output location not writable</source>
        <translation>Ubicación de salida no escribible</translation>
    </message>
    <message>
        <source>No video or audio input</source>
        <translation>No hay entrada de video o audio</translation>
    </message>
    <message>
        <source>Cannot open the output location for writing</source>
        <translation>No se puede abrir la ubicación de salida para escribir</translation>
    </message>
    <message>
        <source>No camera or audio input</source>
        <translation>No hay entrada de cámara o audio</translation>
    </message>
</context>
<context>
    <name>QMediaMetaData</name>
    <message>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Comentario</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Genre</source>
        <translation>Género</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Fecha</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <source>Publisher</source>
        <translation>Editor</translation>
    </message>
    <message>
        <source>Copyright</source>
        <translation>Derechos de autor</translation>
    </message>
    <message>
        <source>Url</source>
        <translation>Url</translation>
    </message>
    <message>
        <source>Duration</source>
        <translation>Duración</translation>
    </message>
    <message>
        <source>Media type</source>
        <translation>Tipo de medio</translation>
    </message>
    <message>
        <source>Container Format</source>
        <translation>Formato del contenedor</translation>
    </message>
    <message>
        <source>Audio bit rate</source>
        <translation>Tasa de bits de audio</translation>
    </message>
    <message>
        <source>Audio codec</source>
        <translation>Códec de audio</translation>
    </message>
    <message>
        <source>Video bit rate</source>
        <translation>Tasa de bits de video</translation>
    </message>
    <message>
        <source>Video codec</source>
        <translation>Códec de video</translation>
    </message>
    <message>
        <source>Video frame rate</source>
        <translation>Tasa de cuadros de video</translation>
    </message>
    <message>
        <source>Album title</source>
        <translation>Título del álbum</translation>
    </message>
    <message>
        <source>Album artist</source>
        <translation>Artista del álbum</translation>
    </message>
    <message>
        <source>Contributing artist</source>
        <translation>Artista colaborador</translation>
    </message>
    <message>
        <source>Track number</source>
        <translation>Número de pista</translation>
    </message>
    <message>
        <source>Composer</source>
        <translation>Compositor</translation>
    </message>
    <message>
        <source>Thumbnail image</source>
        <translation>Imagen en miniatura</translation>
    </message>
    <message>
        <source>Cover art image</source>
        <translation>Imagen de portada</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation>Orientación</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Resolución</translation>
    </message>
    <message>
        <source>Lead performer</source>
        <translation>Intérprete principal</translation>
    </message>
    <message>
        <source>Has HDR content</source>
        <translation>Tiene contenido HDR</translation>
    </message>
</context>
<context>
    <name>Decoder</name>
    <message>
        <source>Cannot set source, invalid mime type for the source provided.</source>
        <translation>No se puede configurar la fuente, tipo MIME inválido para la fuente proporcionada.</translation>
    </message>
    <message>
        <source>Cannot open the file</source>
        <translation>No se puede abrir el archivo</translation>
    </message>
    <message>
        <source>Invalid fileDescriptor for source.</source>
        <translation>fileDescriptor inválido para la fuente.</translation>
    </message>
    <message>
        <source>Setting source for Audio Decoder failed.</source>
        <translation>Falló la configuración de la fuente para el decodificador de audio.</translation>
    </message>
    <message>
        <source>Format not supported by Audio Decoder.</source>
        <translation>Formato no compatible con el decodificador de audio.</translation>
    </message>
    <message>
        <source>Cannot decode, source not set.</source>
        <translation>No se puede decodificar, la fuente no está configurada.</translation>
    </message>
    <message>
        <source>Audio Decoder could not be created.</source>
        <translation>No se pudo crear el decodificador de audio.</translation>
    </message>
    <message>
        <source>Audio Decoder failed configuration.</source>
        <translation>El decodificador de audio falló en la configuración.</translation>
    </message>
    <message>
        <source>Audio Decoder failed to start.</source>
        <translation>El decodificador de audio no pudo iniciarse.</translation>
    </message>
</context>
<context>
    <name>QAndroidAudioDecoder</name>
    <message>
        <source>Error opening temporary file: %1</source>
        <translation>Error al abrir el archivo temporal: %1</translation>
    </message>
    <message>
        <source>Error while writing data to temporary file</source>
        <translation>Error al escribir datos en el archivo temporal</translation>
    </message>
</context>
<context>
    <name>AVFAudioDecoder</name>
    <message>
        <source>Unable to read from specified device</source>
        <translation>No se puede leer desde el dispositivo especificado</translation>
    </message>
    <message>
        <source>Could not load media source&apos;s tracks</source>
        <translation>No se pudieron cargar las pistas de la fuente de medios</translation>
    </message>
    <message>
        <source>No audio tracks found</source>
        <translation>No se encontraron pistas de audio</translation>
    </message>
    <message>
        <source>Unsupported source format</source>
        <translation>Formato de origen no compatible</translation>
    </message>
    <message>
        <source>Failed to add asset reader output</source>
        <translation>No se pudo agregar la salida del lector de activos</translation>
    </message>
    <message>
        <source>Could not start reading</source>
        <translation>No se pudo iniciar la lectura</translation>
    </message>
</context>
<context>
    <name>AVFCameraSession</name>
    <message>
        <source>Runtime camera error</source>
        <translation>Error de cámara en tiempo de ejecución</translation>
    </message>
</context>
<context>
    <name>AVFImageCapture</name>
    <message>
        <source>Could not open destination file:
%1</source>
        <translation>No se pudo abrir el archivo de destino:
%1</translation>
    </message>
</context>
<context>
    <name>AVFMediaEncoder</name>
    <message>
        <source>No inputs specified</source>
        <translation>No se especificaron entradas</translation>
    </message>
    <message>
        <source>Invalid output file URL</source>
        <translation>URL de archivo de salida no válida</translation>
    </message>
    <message>
        <source>Non-writeable file location</source>
        <translation>Ubicación de archivo no escribible</translation>
    </message>
    <message>
        <source>File already exists</source>
        <translation>El archivo ya existe</translation>
    </message>
</context>
<context>
    <name>AVFMediaPlayer</name>
    <message>
        <source>Failed to load media</source>
        <translation>Error al cargar el medio</translation>
    </message>
</context>
<context>
    <name>QFFmpegImageCapture</name>
    <message>
        <source>No camera available.</source>
        <translation>No hay cámara disponible.</translation>
    </message>
</context>
<context>
    <name>QGstreamerAudioDecoder</name>
    <message>
        <source>Cannot play stream of type: &lt;unknown&gt;</source>
        <translation>No se puede reproducir el flujo del tipo:</translation>
    </message>
</context>
<context>
    <name>QGstreamerMediaPlayer</name>
    <message>
        <source>Cannot play stream of type: &lt;unknown&gt;</source>
        <translation>No se puede reproducir el flujo del tipo:</translation>
    </message>
</context>
<context>
    <name>QGstreamerImageCapture</name>
    <message>
        <source>No camera available.</source>
        <translation>No hay cámara disponible.</translation>
    </message>
</context>
<context>
    <name>MFAudioDecoderControl</name>
    <message>
        <source>Unsupported media type</source>
        <translation>Tipo de medios no compatible</translation>
    </message>
    <message>
        <source>Media not found</source>
        <translation>Medios no encontrados</translation>
    </message>
    <message>
        <source>Unable to load specified URL</source>
        <translation>No se puede cargar la URL especificada</translation>
    </message>
    <message>
        <source>Could not instantiate MFDecoderSourceReader</source>
        <translation>No se pudo instanciar MFDecoderSourceReader</translation>
    </message>
    <message>
        <source>Invalid media format</source>
        <translation>Formato de medios no válido</translation>
    </message>
    <message>
        <source>Unable to read from specified device</source>
        <translation>No se puede leer desde el dispositivo especificado</translation>
    </message>
    <message>
        <source>No media source specified</source>
        <translation>No se especificó fuente de medios</translation>
    </message>
    <message>
        <source>Failed processing a sample</source>
        <translation>Error al procesar una muestra</translation>
    </message>
</context>
<context>
    <name>QWindowsMediaEncoder</name>
    <message>
        <source>Failed to pause recording</source>
        <translation>No se pudo pausar la grabación.</translation>
    </message>
    <message>
        <source>Failed to resume recording</source>
        <translation>No se pudo reanudar la grabación.</translation>
    </message>
    <message>
        <source>Camera is no longer present</source>
        <translation>La cámara ya no está presente.</translation>
    </message>
    <message>
        <source>Audio input is no longer present</source>
        <translation>La entrada de audio ya no está presente.</translation>
    </message>
    <message>
        <source>Streaming error</source>
        <translation>Error de transmisión.</translation>
    </message>
    <message>
        <source>Recording error</source>
        <translation>Error de grabación.</translation>
    </message>
</context>
<context>
    <name>QV4L2Camera</name>
    <message>
        <source>Camera is in use.</source>
        <translation type="vanished">La cámara está en uso.</translation>
    </message>
</context>
</TS>
