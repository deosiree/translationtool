<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>IPSelectView</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/ip_select.ui" line="14"/>
        <source>IPSelectView</source>
        <translation type="unfinished">IPSelectView</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/ip_select.ui" line="50"/>
        <source>IP:</source>
        <translation type="unfinished">IP:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/ip_select.ui" line="110"/>
        <source>确定</source>
        <translation type="unfinished">confirm</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.ui" line="20"/>
        <source>MainWindow</source>
        <translation type="unfinished">MainWindow</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.ui" line="33"/>
        <source>工具入口</source>
        <translation type="unfinished">Tool entry</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.ui" line="144"/>
        <source>导入</source>
        <translation type="unfinished">Import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.ui" line="180"/>
        <source>TextLabel</source>
        <translation type="unfinished">TextLabel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.ui" line="121"/>
        <source>版本管理</source>
        <translation type="unfinished">version control</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="87"/>
        <source>版本[%1] 时间[%2]</source>
        <translation type="unfinished">Version [%1] Time [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="481"/>
        <source>删除</source>
        <translation type="unfinished">delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="482"/>
        <source>导出</source>
        <translation type="unfinished">export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="514"/>
        <source>不是一个有效的VBS文件</source>
        <translation type="unfinished">Not a valid VBS file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="534"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="573"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="590"/>
        <source>脚本启动失败</source>
        <translation type="unfinished">Script startup failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="550"/>
        <source>不是一个有效的 SH 文件</source>
        <translation type="unfinished">Not a valid SH file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="604"/>
        <source>脚本执行失败</source>
        <translation type="unfinished">Script execution failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="738"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="764"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="769"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="830"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="834"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="838"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="845"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="874"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="889"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="893"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="913"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="959"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="973"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="981"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="995"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1000"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1033"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1043"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1053"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1072"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1089"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1096"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1108"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1118"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1138"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1149"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1164"/>
        <source>提示</source>
        <translation type="unfinished">prompt</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="738"/>
        <source>是否删除 [%1] 版本包</source>
        <translation type="unfinished">Do you want to delete the [%1] version package</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="744"/>
        <source>正在删除，请稍后......</source>
        <translation type="unfinished">Deleting, please wait...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="764"/>
        <source>删除成功</source>
        <translation type="unfinished">Deleted successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="769"/>
        <source>正在使用，禁止删除</source>
        <translation type="unfinished">In use, deletion is prohibited</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="776"/>
        <source>选择文件或目录</source>
        <translation type="unfinished">Select file or dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="776"/>
        <source>%1 (*.zip *.syzip);;%2 (*)</source>
        <translation type="unfinished">%1 (*.zip *.syzip);;%2 (*)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="777"/>
        <source>支持文件</source>
        <translation type="unfinished">supporting file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="778"/>
        <source>所有文件</source>
        <translation type="unfinished">all documents</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="805"/>
        <source>正在导入，请稍后......</source>
        <translation type="unfinished">Importing, please wait .....</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="830"/>
        <source>版本： 【%1】 添加成功</source>
        <translation type="unfinished">Version: [%1] added successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="834"/>
        <source>版本： 【%1】 已存在</source>
        <translation type="unfinished">Version: [%1] already exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="840"/>
        <source>版本： 【%1】 添加失败,原因：【%2】</source>
        <translation type="unfinished">Version: [%1] failed to add, reason: [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="847"/>
        <source>版本： 【%1】 添加失败,原因：压缩包版本为空</source>
        <translation type="unfinished">Version: [%1] failed to add, reason: compressed file version is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="867"/>
        <source>选择文件夹</source>
        <translation type="unfinished">Select Folder</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="874"/>
        <source>禁止选择放置在导出包所在的目录</source>
        <translation type="unfinished">Prohibit selecting to place in the dir where the exported package is located</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="883"/>
        <source>正在导出，请稍后......</source>
        <translation type="unfinished">Exporting, please wait...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="889"/>
        <source>导出工具包成功,路径：%1</source>
        <translation type="unfinished">Export toolkit successfully, path: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="893"/>
        <source>导出工具包失败</source>
        <translation type="unfinished">Export toolkit failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="913"/>
        <source>请输入IP地址</source>
        <translation type="unfinished">Please enter your IP address</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="923"/>
        <source>正在连接下载工具包，请稍后......</source>
        <translation type="unfinished">Connecting to download toolkit, please wait...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="959"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1053"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1118"/>
        <source>工具集license拷贝到工具包中失败</source>
        <translation type="unfinished">Copy of toolset license to toolkit failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="968"/>
        <source>网关机</source>
        <translation type="unfinished">Gateway machine</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="981"/>
        <source>当前已处于在线模式</source>
        <translation type="unfinished">Currently in online mode</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="995"/>
        <source>当前已处于离线模式</source>
        <translation type="unfinished">Currently in offline mode</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1000"/>
        <source>切换模式将断开网关机连接，是否切换</source>
        <translation type="unfinished">Switching modes will disconnect Gateway connection. Do you want to switch</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1074"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1091"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1140"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1166"/>
        <source>启动[%1]失败：%2</source>
        <translation type="unfinished">Failed to start [%1]: %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1074"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1140"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1166"/>
        <source>配置工具</source>
        <translation type="unfinished">config tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1091"/>
        <source>监视工具</source>
        <translation type="unfinished">Monitor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1096"/>
        <source>不支持的工具</source>
        <translation type="unfinished">Unsupported tools</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1108"/>
        <source>本地未找到版本[%1]的工具</source>
        <translation type="unfinished">Local tool not found for version [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1149"/>
        <source>配置包移动加入项目失败</source>
        <translation type="unfinished">Failed to move the config package to join the project</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="481"/>
        <source>执行成功</source>
        <translation type="unfinished">Execution successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="483"/>
        <source>执行失败</source>
        <translation type="unfinished">Execution failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="485"/>
        <source>网络连接失败</source>
        <translation type="unfinished">Network connection failure</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="487"/>
        <source>获取远程版本失败</source>
        <translation type="unfinished">Failed to obtain remote version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="489"/>
        <source>环境未发现</source>
        <translation type="unfinished">Environment not found</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="491"/>
        <source>解压失败</source>
        <translation type="unfinished">Decompression failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="493"/>
        <source>无效的IP地址</source>
        <translation type="unfinished">Invalid IP address</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="495"/>
        <source>读取数据包成功</source>
        <translation type="unfinished">Read packet successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="497"/>
        <source>读取数据包失败</source>
        <translation type="unfinished">Failed to read data packet</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="499"/>
        <source>数据包迁移失败</source>
        <translation type="unfinished">Data packet migration failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="501"/>
        <source>下载工具包失败</source>
        <translation type="unfinished">Failed to download toolkit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="503"/>
        <source>本地无匹配服务的工具版本</source>
        <translation type="unfinished">Local tool version without matching service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="505"/>
        <source>本地已存在同版本环境</source>
        <translation type="unfinished">The same version environment already exists locally</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="507"/>
        <source>sys_daemon连接失败</source>
        <translation type="unfinished">Sys_daemon connection failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="509"/>
        <source>license验证失败</source>
        <translation type="unfinished">License verification failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="511"/>
        <source>网关机license失效</source>
        <translation type="unfinished">Gateway license expired</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.cpp" line="513"/>
        <source>未知错误</source>
        <translation type="unfinished">Unknown error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.h" line="96"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/func.h" line="97"/>
        <source>未设置</source>
        <translation type="unfinished">Not set</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="100"/>
        <source>本地配置</source>
        <translation type="unfinished">Local config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="101"/>
        <source>连接网关机</source>
        <translation type="unfinished">Connect gateway</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="408"/>
        <source>序号</source>
        <translation type="unfinished">number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="408"/>
        <source>目录</source>
        <translation type="unfinished">Directory</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="408"/>
        <source>应用版本</source>
        <translation type="unfinished">App Version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="408"/>
        <source>平台版本</source>
        <translation type="unfinished">Platform version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="409"/>
        <source>操作</source>
        <translation type="unfinished">operation</translation>
    </message>
</context>
<context>
    <name>ToolBoxMain</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1174"/>
        <source>网关机工具集</source>
        <translation type="unfinished">Gateway Tool Set</translation>
    </message>
</context>
<context>
    <name>ToolListView</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/tool_list.ui" line="14"/>
        <source>ToolListView</source>
        <translation type="unfinished">ToolListView</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/tool_list.ui" line="35"/>
        <source>应用</source>
        <translation type="unfinished">application</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/tool_list.ui" line="47"/>
        <source>运维</source>
        <translation type="unfinished">O&amp;M</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/tool_list.ui" line="74"/>
        <source>打开</source>
        <translation type="unfinished">open</translation>
    </message>
</context>
<context>
    <name>VersionSelectView</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.ui" line="14"/>
        <source>VersionSelectView</source>
        <translation type="unfinished">VersionSelectView</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.ui" line="65"/>
        <source>打开配置工具</source>
        <translation type="unfinished">Open the config tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.ui" line="72"/>
        <source>打开监视工具</source>
        <translation type="unfinished">Open the monitor tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.ui" line="79"/>
        <source>网关机配置工具：</source>
        <translation type="unfinished">Gateway machine config tool:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.ui" line="86"/>
        <source>网关机监视工具：</source>
        <translation type="unfinished">Gateway monitor tool:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.ui" line="93"/>
        <source>打开配置包</source>
        <translation type="unfinished">Open config package</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.ui" line="100"/>
        <source>导入</source>
        <translation type="unfinished">Import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.ui" line="153"/>
        <source>打开工具</source>
        <translation type="unfinished">Open the tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.cpp" line="102"/>
        <source>选择配置包</source>
        <translation type="unfinished">Select config package</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.cpp" line="104"/>
        <source>压缩文件 (*.zip *.syzip)</source>
        <translation type="unfinished">Compressed files (*. zip *. syzip)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.cpp" line="125"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.cpp" line="130"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.cpp" line="140"/>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.cpp" line="168"/>
        <source>提示</source>
        <translation type="unfinished">prompt</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.cpp" line="125"/>
        <source>加载配置包失败,未找到配置包版本信息</source>
        <translation type="unfinished">Loading config package failed, config package version information not found</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.cpp" line="130"/>
        <source>加载配置包成功</source>
        <translation type="unfinished">Successfully loaded config package</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.cpp" line="140"/>
        <source>加载配置包失败</source>
        <translation type="unfinished">Failed to load config package</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/version_select.cpp" line="168"/>
        <source>请导入配置包</source>
        <translation type="unfinished">Please import Config Package</translation>
    </message>
</context>
<context>
    <name>WaitDialog</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1227"/>
        <source>请稍候...</source>
        <translation type="unfinished">please wait a moment. ..</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1236"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1323"/>
        <source>正在取消，请稍候...</source>
        <translation type="unfinished">Cancelling, please wait...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_toolBox/mainwindow.cpp" line="1331"/>
        <source>检测到已取消，自动关闭...</source>
        <translation type="unfinished">Detected cancellation, automatically closing...</translation>
    </message>
</context>
</TS>
