<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CMyBasicPlot</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_plot.cpp" line="291"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_plot.cpp" line="302"/>
        <source>年</source>
        <translation type="unfinished">Year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_plot.cpp" line="302"/>
        <source>周</source>
        <translation type="unfinished">Week</translation>
    </message>
</context>
<context>
    <name>CMyBasicTracer</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_tracer.cpp" line="295"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_tracer.cpp" line="300"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_tracer.cpp" line="320"/>
        <source>时间:%1 %2</source>
        <translation type="unfinished">Time:%1 %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_tracer.cpp" line="305"/>
        <source>日:%1 %2</source>
        <translation type="unfinished">Day:%1 %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_tracer.cpp" line="310"/>
        <source>%1 %2</source>
        <translation type="unfinished">%1 %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_basic_tracer.cpp" line="315"/>
        <source>月:%1 %2</source>
        <translation type="unfinished">Month:%1 %2</translation>
    </message>
</context>
<context>
    <name>CMyCanvasArea</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2190"/>
        <source>保存曲线数据</source>
        <translation type="unfinished">Save curve data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2210"/>
        <source>%1-x轴(时间), </source>
        <translation type="unfinished">%1-x Axis (Time),</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2210"/>
        <source>%1-y轴(值)</source>
        <translation type="unfinished">%1-y axis (value)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2249"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2305"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2249"/>
        <source>曲线数据已成功导出!</source>
        <translation type="unfinished">Curve data has been successfully exported!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2254"/>
        <source>导入曲线数据</source>
        <translation type="unfinished">Import curve data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2261"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2261"/>
        <source>无法打开文件 %1</source>
        <translation type="unfinished">Unable to open file %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_canvas_area.cpp" line="2305"/>
        <source>数据导入成功</source>
        <translation type="unfinished">Data import succeeded</translation>
    </message>
</context>
<context>
    <name>CMyCurveDefinition</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="144"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="145"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="171"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="175"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1151"/>
        <source>当前区间</source>
        <translation type="unfinished">Current range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="149"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="150"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1143"/>
        <source>本月</source>
        <translation type="unfinished">This month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="154"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="155"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1147"/>
        <source>本年</source>
        <translation type="unfinished">This year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="159"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="160"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1139"/>
        <source>本日</source>
        <translation type="unfinished">Today</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="190"/>
        <source>基本属性</source>
        <translation type="unfinished">Basic Attributes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="264"/>
        <source>请输入曲线名称</source>
        <translation type="unfinished">Please enter a curve name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="261"/>
        <source>曲线名称：</source>
        <translation type="unfinished">Curve name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="267"/>
        <source>线色：</source>
        <translation type="unfinished">Line color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="283"/>
        <source>小数点精度：</source>
        <translation type="unfinished">Decimal point precision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="288"/>
        <source>线宽：</source>
        <translation type="unfinished">Line width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="304"/>
        <source>对象检索：</source>
        <translation type="unfinished">Object retrieval:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="307"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="389"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="394"/>
        <source>检索</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="309"/>
        <source>起始时间：</source>
        <translation type="unfinished">Start time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="313"/>
        <source>设置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="340"/>
        <source>数据点形状：</source>
        <translation type="unfinished">Data point shape:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="343"/>
        <source>空心圆</source>
        <translation type="unfinished">Hollow circle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="343"/>
        <source>实心圆</source>
        <translation type="unfinished">Solid circle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="343"/>
        <source>正方形</source>
        <translation type="unfinished">Square</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="343"/>
        <source>三角形</source>
        <translation type="unfinished">Triangle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="353"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="506"/>
        <source>显示数据点</source>
        <translation type="unfinished">Show data points</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="367"/>
        <source>计算曲线</source>
        <translation type="unfinished">Calculation curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="375"/>
        <source>配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="474"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">New</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="476"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="478"/>
        <source>上移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Move Up</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="480"/>
        <source>下移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Move Down</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="482"/>
        <source>复制</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Duplicate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="854"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="855"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="386"/>
        <source>X轴数据源:</source>
        <translation type="unfinished">X-axis data source:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="391"/>
        <source>Y轴数据源:</source>
        <translation type="unfinished">Y-axis data source:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="409"/>
        <source>单位:</source>
        <translation type="unfinished">Unit:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="411"/>
        <source>请输入单位</source>
        <translation type="unfinished">Please enter the unit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="419"/>
        <source>Y轴配置:</source>
        <translation type="unfinished">Y-axis config:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="506"/>
        <source>曲线名称</source>
        <translation type="unfinished">Curve name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="506"/>
        <source>线色</source>
        <translation type="unfinished">Line color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="506"/>
        <source>线宽</source>
        <translation type="unfinished">Line width</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="506"/>
        <source>基本点形状</source>
        <translation type="unfinished">Basic point shape</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="506"/>
        <source>对象检索</source>
        <translation type="unfinished">Retrieval Obj</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="570"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1080"/>
        <source>是</source>
        <translation type="unfinished">True</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="570"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1080"/>
        <source>否</source>
        <translation type="unfinished">False</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="818"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="921"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1171"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="818"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="921"/>
        <source>曲线数量超过限制</source>
        <translation type="unfinished">The number of curves exceeds the limit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="823"/>
        <source>线</source>
        <translation type="unfinished">Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="849"/>
        <source>删除</source>
        <comment>toolName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="851"/>
        <source>删除不可恢复，是否继续</source>
        <translation type="unfinished">Deletion is unrecoverable. Do you want to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="943"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="954"/>
        <source>-副本(%1)</source>
        <translation type="unfinished">-Copy(%1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="947"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="949"/>
        <source>-副本</source>
        <translation type="unfinished">-Copy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_definition.cpp" line="1171"/>
        <source>请选择需要操作的数据</source>
        <translation type="unfinished">Please select the data to be operated</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupAttribute</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="103"/>
        <source>曲线组名称：</source>
        <translation type="unfinished">Curve group name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="105"/>
        <source>请输入</source>
        <translation type="unfinished">Please enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="115"/>
        <source>曲线组类型:</source>
        <translation type="unfinished">Curve group type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="119"/>
        <source>日曲线</source>
        <translation type="unfinished">Daily curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="119"/>
        <source>月曲线</source>
        <translation type="unfinished">Monthly curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="119"/>
        <source>年曲线</source>
        <translation type="unfinished">Yearly curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="119"/>
        <source>区间曲线</source>
        <translation type="unfinished">Interval curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="119"/>
        <source>实时曲线</source>
        <translation type="unfinished">Real-time curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="144"/>
        <source>展示形式:</source>
        <translation type="unfinished">Display format:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="148"/>
        <source>点</source>
        <translation type="unfinished">Point</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="148"/>
        <source>线</source>
        <translation type="unfinished">Line</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="148"/>
        <source>向下填充</source>
        <translation type="unfinished">Fill down</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="171"/>
        <source>左边距:</source>
        <translation type="unfinished">Left margin:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="174"/>
        <source>下边距:</source>
        <translation type="unfinished">Bottom margin:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="189"/>
        <source>背景颜色:</source>
        <translation type="unfinished">Background color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="196"/>
        <source>阈值颜色:</source>
        <translation type="unfinished">Threshold color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="210"/>
        <source>阈值上限:</source>
        <translation type="unfinished">Upper threshold:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="214"/>
        <source>阈值下限:</source>
        <translation type="unfinished">Lower threshold:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="228"/>
        <source>刷新周期%1</source>
        <translation type="unfinished">Refresh cycle %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="246"/>
        <source>区间配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="311"/>
        <source>标题栏</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Title Bar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="312"/>
        <source>网格</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Grid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="313"/>
        <source>图例</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Legend</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="314"/>
        <source>游标</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Cursor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="315"/>
        <source>坐标轴</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Coordinate Axis</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="320"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="444"/>
        <source>多Y轴</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Multiple Y-axis</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="260"/>
        <source>背景透明</source>
        <translation type="unfinished">Background transparent</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="263"/>
        <source>平滑曲线</source>
        <translation type="unfinished">Smooth curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="266"/>
        <source>曲线详情</source>
        <translation type="unfinished">Curve details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="269"/>
        <source>显示阈值</source>
        <translation type="unfinished">Display threshold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="272"/>
        <source>漏点断开</source>
        <translation type="unfinished">Leak break</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="276"/>
        <source>绝对值曲线</source>
        <translation type="unfinished">Absolute value curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="427"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="432"/>
        <source>至</source>
        <translation type="unfinished">to</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="470"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="529"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="471"/>
        <source>切换曲线类型,需要清空曲线，是否确定?</source>
        <translation type="unfinished">Switch the curve type. You need to clear the curve. Are you sure?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_attribute.cpp" line="529"/>
        <source>暂不支持该类型曲线</source>
        <translation type="unfinished">This type of curve is not currently supported</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupAxis</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="96"/>
        <source>坐标轴自适应</source>
        <translation type="unfinished">Axis adaptive</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="100"/>
        <source>多Y轴</source>
        <translation type="unfinished">Multiple Y-axis</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="103"/>
        <source>是否固定轴</source>
        <translation type="unfinished">Fix axis</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="132"/>
        <source>X轴主刻度:</source>
        <translation type="unfinished">X-axis major scale:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="137"/>
        <source>Y轴主刻度:</source>
        <translation type="unfinished">Y-axis major scale:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="156"/>
        <source>X轴字体:</source>
        <translation type="unfinished">X-axis font:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="159"/>
        <source>Y轴字体:</source>
        <translation type="unfinished">Y-axis font:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="173"/>
        <source>坐标轴线宽:</source>
        <translation type="unfinished">Coordinate axis width:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="179"/>
        <source>坐标轴颜色:</source>
        <translation type="unfinished">Axis color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="194"/>
        <source>y轴最小值:</source>
        <translation type="unfinished">Minimum y-axis value:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="199"/>
        <source>y轴最大值:</source>
        <translation type="unfinished">Maximum value of y axis:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="217"/>
        <source>曲线轴区间:</source>
        <translation type="unfinished">Curve axis range:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="221"/>
        <source>设置实时曲线的轴范围</source>
        <translation type="unfinished">Set the axis range of the real-time curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_axis.cpp" line="223"/>
        <source>显示历史</source>
        <translation type="unfinished">Display History</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupCursor</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="36"/>
        <source>显示游标</source>
        <translation type="unfinished">Display cursor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="39"/>
        <source>显示日期</source>
        <translation type="unfinished">Display date</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="42"/>
        <source>背景透明</source>
        <translation type="unfinished">Background transparent</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="60"/>
        <source>背景颜色：</source>
        <translation type="unfinished">Background color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="61"/>
        <source>字体大小：</source>
        <translation type="unfinished">Font size:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_cursor.cpp" line="75"/>
        <source>字体颜色：</source>
        <translation type="unfinished">Font color:</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupGrid</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_grid.cpp" line="56"/>
        <source>不显示</source>
        <translation type="unfinished">Hide</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_grid.cpp" line="57"/>
        <source>多列</source>
        <translation type="unfinished">Multiple columns</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_grid.cpp" line="58"/>
        <source>少列</source>
        <translation type="unfinished">Less columns</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_grid.cpp" line="69"/>
        <source>网格线颜色:</source>
        <translation type="unfinished">Grid line color:</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupLegend</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="70"/>
        <source>隐藏图例</source>
        <translation type="unfinished">Hide legend</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="74"/>
        <source>图例间距：</source>
        <translation type="unfinished">Legend spacing:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="78"/>
        <source>图例方向：</source>
        <translation type="unfinished">Legend direction:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>上左</source>
        <translation type="unfinished">Top left</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>上中</source>
        <translation type="unfinished">Upper middle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>上右</source>
        <translation type="unfinished">Top right</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>中左</source>
        <translation type="unfinished">Center left</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>正中</source>
        <translation type="unfinished">Middle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>中右</source>
        <translation type="unfinished">Center right</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>下左</source>
        <translation type="unfinished">Bottom left</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="81"/>
        <source>下中</source>
        <translation type="unfinished">Lower middle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="82"/>
        <source>下右</source>
        <translation type="unfinished">Bottom right</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="95"/>
        <source>排列方式:</source>
        <translation type="unfinished">Arrangement:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="98"/>
        <source>水平</source>
        <translation type="unfinished">Horizontal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="98"/>
        <source>垂直</source>
        <translation type="unfinished">Vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="102"/>
        <source>换行:</source>
        <translation type="unfinished">Line feed:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="106"/>
        <source>设置图例自动换行，0表示不换行</source>
        <translation type="unfinished">Set the legend to wrap automatically, 0 means no wrap</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="120"/>
        <source>图例字体:</source>
        <translation type="unfinished">Legend font:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_legend.cpp" line="124"/>
        <source>图例颜色:</source>
        <translation type="unfinished">Legend color:</translation>
    </message>
</context>
<context>
    <name>CMyCurveGroupTitleBar</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="37"/>
        <source>显示标题栏</source>
        <translation type="unfinished">Show title bar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="40"/>
        <source>背景透明</source>
        <translation type="unfinished">Background transparent</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="43"/>
        <source>显示按钮</source>
        <translation type="unfinished">Display button</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="52"/>
        <source>背景颜色:</source>
        <translation type="unfinished">Background color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_group_titlebar.cpp" line="53"/>
        <source>字体颜色:</source>
        <translation type="unfinished">Font color:</translation>
    </message>
</context>
<context>
    <name>CMyCurveNewCreate</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="54"/>
        <source>曲线组属性</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Curve Group Attributes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="55"/>
        <source>曲线定义</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Curve Definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="58"/>
        <source>设置曲线属性</source>
        <translation type="unfinished">Set curve attributes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="139"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="147"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="152"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="158"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="164"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="169"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="139"/>
        <source>对象检索为空,请关联曲线数据</source>
        <translation type="unfinished">The object retrieval is empty, please link the curve data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="147"/>
        <source>曲线名称不可为空</source>
        <translation type="unfinished">The curve name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="152"/>
        <source>曲线重复</source>
        <translation type="unfinished">The curve repeats</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="158"/>
        <source>曲线名称不可重复</source>
        <translation type="unfinished">Curve names cannot be repeated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="164"/>
        <source>y轴最小值大于y轴最大值</source>
        <translation type="unfinished">The minimum y-axis value is greater than the maximum y-axis value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="169"/>
        <source>阈值下限大于阈值上限</source>
        <translation type="unfinished">The lower threshold is greater than the upper threshold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_curve_newcreate.cpp" line="175"/>
        <source>曲线组名称不能为空!</source>
        <translation type="unfinished">Curve group name cannot be empty!</translation>
    </message>
</context>
<context>
    <name>CMyMultipleYAxis</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="40"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">New</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="42"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>编号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>Y轴名称</source>
        <translation type="unfinished">Y-axis name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>Y轴颜色</source>
        <translation type="unfinished">Y-axis color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>最大值</source>
        <translation type="unfinished">MAX</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>最小值</source>
        <translation type="unfinished">MIN</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/configwidget/cmy_multiple_yaxis.cpp" line="71"/>
        <source>是否显示</source>
        <translation type="unfinished">Display</translation>
    </message>
</context>
<context>
    <name>CmyStatisticalTable</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="130"/>
        <source>曲线名称</source>
        <translation type="unfinished">Curve name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="130"/>
        <source>线色</source>
        <translation type="unfinished">Line color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="130"/>
        <source>最大值</source>
        <translation type="unfinished">MAX</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="130"/>
        <source>最小值</source>
        <translation type="unfinished">MIN</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/customplotcurve/cmy_statistical_table.cpp" line="130"/>
        <source>对象检索</source>
        <translation type="unfinished">Retrieval Obj</translation>
    </message>
</context>
<context>
    <name>ContextMenu</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="29"/>
        <source>编辑画面</source>
        <translation type="unfinished">Edit graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="33"/>
        <source>另存为</source>
        <translation type="unfinished">Save as</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="34"/>
        <source>打开</source>
        <translation type="unfinished">Open</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="39"/>
        <source>曲线详情</source>
        <translation type="unfinished">Curve details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="48"/>
        <source>平滑曲线</source>
        <translation type="unfinished">Smooth curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="57"/>
        <source>绝对值曲线</source>
        <translation type="unfinished">Absolute value curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="67"/>
        <source>开启实时刷新</source>
        <translation type="unfinished">Enable real-time refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="75"/>
        <source>导出数据</source>
        <translation type="unfinished">Export data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="76"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="77"/>
        <source>重置</source>
        <translation type="unfinished">Reset</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/Contextmenu/context_menu.cpp" line="79"/>
        <source>查询</source>
        <translation type="unfinished">Query</translation>
    </message>
</context>
<context>
    <name>DlgIntervalTime</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="36"/>
        <source>设置日期</source>
        <comment>toolName</comment>
        <translation type="unfinished">Set Date</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="64"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="77"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="64"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.cpp" line="77"/>
        <source>日期选择错误，请重新选择</source>
        <translation type="unfinished">Date selection error, please select again</translation>
    </message>
</context>
<context>
    <name>DlgQuery</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_query.cpp" line="23"/>
        <source>查询</source>
        <comment>toolName</comment>
        <translation type="unfinished">Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_query.cpp" line="47"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_query.cpp" line="48"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Query</translation>
    </message>
</context>
<context>
    <name>DlgRelativeTime</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="69"/>
        <source>本日</source>
        <translation type="unfinished">Today</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="70"/>
        <source>昨日</source>
        <translation type="unfinished">Yesterday</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="71"/>
        <source>明日</source>
        <translation type="unfinished">Tomorrow</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="72"/>
        <source>上周今日</source>
        <translation type="unfinished">Last week today</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="73"/>
        <source>上月今日</source>
        <translation type="unfinished">This day of last month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="74"/>
        <source>去年今日</source>
        <translation type="unfinished">This day of last year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="80"/>
        <source>本月</source>
        <translation type="unfinished">This month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="81"/>
        <source>上月</source>
        <translation type="unfinished">Last month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="82"/>
        <source>下月</source>
        <translation type="unfinished">Next month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="83"/>
        <source>去年该月</source>
        <translation type="unfinished">Last year this month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="86"/>
        <source>月前</source>
        <translation type="unfinished">months ago</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="91"/>
        <source>本年</source>
        <translation type="unfinished">This year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="92"/>
        <source>去年</source>
        <translation type="unfinished">Last year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="93"/>
        <source>下年</source>
        <translation type="unfinished">Next year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="94"/>
        <source>去年该年</source>
        <translation type="unfinished">Last year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="98"/>
        <source>年前</source>
        <translation type="unfinished">years ago</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="68"/>
        <source>日曲线时间配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Daily Curve Time Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="79"/>
        <source>月曲线时间配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Monthly curve time config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="90"/>
        <source>年曲线时间配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Annual Curve Time config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="102"/>
        <source>区间曲线时间配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Interval Curve Time Configuration</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="103"/>
        <source>当前区间</source>
        <translation type="unfinished">Current range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="104"/>
        <source>昨天该区间</source>
        <translation type="unfinished">Yesterday, this range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="105"/>
        <source>明天该区间</source>
        <translation type="unfinished">Tomorrow interval</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="106"/>
        <source>上周该区间</source>
        <translation type="unfinished">Last week, this range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="107"/>
        <source>上月该区间</source>
        <translation type="unfinished">Last month, this range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="108"/>
        <source>去年该区间</source>
        <translation type="unfinished">Last year, this range</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="128"/>
        <source>请输入数字（范围1～365）</source>
        <translation type="unfinished">Please enter a number (range 1~365)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="149"/>
        <source>请输入数字（范围1～99）</source>
        <translation type="unfinished">Please enter a number (range 1~99)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.cpp" line="170"/>
        <source>请输入数字（范围1～9）</source>
        <translation type="unfinished">Please enter a number (range 1-9)</translation>
    </message>
</context>
<context>
    <name>PrinterHandle</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/printer_handle.cpp" line="35"/>
        <source>打印错误</source>
        <translation type="unfinished">Print error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/printer_handle.cpp" line="35"/>
        <source>无法找到打印机</source>
        <translation type="unfinished">Unable to find printer</translation>
    </message>
</context>
<context>
    <name>XMLFileHandle</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="22"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="22"/>
        <source>文件打开或创建失败</source>
        <translation type="unfinished">File open or create failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="25"/>
        <source>文件保存中</source>
        <translation type="unfinished">File saving</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="96"/>
        <source>通知</source>
        <translation type="unfinished">Notification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="96"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="654"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="659"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="665"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="673"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="697"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="654"/>
        <source>文件不存在</source>
        <translation type="unfinished">File not found</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="659"/>
        <source>文件打开失败</source>
        <translation type="unfinished">File open failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="665"/>
        <source>操作的文件不是XML格式</source>
        <translation type="unfinished">The file for the operation is not in XML format</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="673"/>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="697"/>
        <source>曲线文件格式无效</source>
        <translation type="unfinished">Invalid curve file format</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="702"/>
        <source>曲线文件读取中</source>
        <translation type="unfinished">Curve file reading</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/xml_file_handle.cpp" line="702"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>dlg_interval_time</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.ui" line="22"/>
        <source>开始时间：</source>
        <translation type="unfinished">Start time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.ui" line="36"/>
        <source>结束时间：</source>
        <translation type="unfinished">End time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.ui" line="63"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_interval_time.ui" line="70"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>dlg_relative_time</name>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="22"/>
        <source>今天</source>
        <translation type="unfinished">Today</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="29"/>
        <source>昨天</source>
        <translation type="unfinished">Yesterday</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="36"/>
        <source>明天</source>
        <translation type="unfinished">tomorrow</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="47"/>
        <source>上周今天</source>
        <translation type="unfinished">Last week today</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="54"/>
        <source>上月今天</source>
        <translation type="unfinished">Today last month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="61"/>
        <source>去年今天</source>
        <translation type="unfinished">Last year on this day</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="72"/>
        <source>自定义</source>
        <translation type="unfinished">Custom</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/curve_base_api/src/widget/dialogs/dlg_relative_time.ui" line="82"/>
        <source>天前</source>
        <translation type="unfinished">days ago</translation>
    </message>
</context>
</TS>
