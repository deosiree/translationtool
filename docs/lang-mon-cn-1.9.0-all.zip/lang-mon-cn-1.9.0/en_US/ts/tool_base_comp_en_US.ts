<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>DlgAgainLogin</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/dlg_again_login.cpp" line="15"/>
        <source>验证</source>
        <comment>toolName</comment>
        <translation type="unfinished">Verify</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/dlg_again_login.cpp" line="24"/>
        <source>用户名:</source>
        <translation type="unfinished">Username:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/dlg_again_login.cpp" line="33"/>
        <source>密码:</source>
        <translation type="unfinished">Password:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/dlg_again_login.cpp" line="36"/>
        <source>请输入密码</source>
        <translation type="unfinished">Please enter your password</translation>
    </message>
</context>
<context>
    <name>iasp::smg::BaseTableWidget</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="206"/>
        <source>新增</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="208"/>
        <source>单行新增，快捷键为Ctrl + N</source>
        <translation type="unfinished">Single add ,the shortcut key is Ctrl+N</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="209"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="211"/>
        <source>删除，快捷键为Ctrl + D</source>
        <translation type="unfinished">Delete ,the shortcut key is Ctrl+D</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="212"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="214"/>
        <source>执行刷新，快捷键为Ctrl + R</source>
        <translation type="unfinished">Refresh, the shortcut key is Ctrl+R</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="215"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="217"/>
        <source>执行刷新，快捷键为Ctrl + S</source>
        <translation type="unfinished">Refresh , the shortcut key is Ctrl+S</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="221"/>
        <source>批量新增</source>
        <translation type="unfinished">Batch Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_table.cpp" line="223"/>
        <source>批量新增，快捷键为Ctrl + Q</source>
        <translation type="unfinished">Batch Add, the shortcut key is Ctrl+Q</translation>
    </message>
</context>
<context>
    <name>iasp::smg::BaseTree</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_tree.cpp" line="67"/>
        <source>全部展开</source>
        <translation type="unfinished">Full expansion</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_tree.cpp" line="69"/>
        <source>全部折叠</source>
        <translation type="unfinished">Collapse all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/base_tree.cpp" line="71"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
</context>
<context>
    <name>iasp::smg::CommonMethod</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/common_method.cpp" line="113"/>
        <source>选择导出目录</source>
        <translation type="unfinished">Select export dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/common_method.cpp" line="130"/>
        <source>文件已存在</source>
        <translation type="unfinished">File already exists</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/common_method.cpp" line="131"/>
        <source>导出目录中已经存在 %1 文件，是否覆盖</source>
        <translation type="unfinished">%1 file already exists in the export dir. Whether to overwrite it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/common_method.cpp" line="162"/>
        <source>选择导入文件</source>
        <translation type="unfinished">Select import file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/common_method.cpp" line="164"/>
        <source>JSON 文件</source>
        <translation type="unfinished">JSON File</translation>
    </message>
</context>
<context>
    <name>iasp::smg::IntegerLineEdit</name>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/integer_lineedit.cpp" line="18"/>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/integer_lineedit.cpp" line="49"/>
        <source>请输入数字（范围1～10）</source>
        <translation type="unfinished">Please enter a number (range 1-10)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysmgr/plug/tool_base_comp/integer_lineedit.cpp" line="49"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
</context>
</TS>
