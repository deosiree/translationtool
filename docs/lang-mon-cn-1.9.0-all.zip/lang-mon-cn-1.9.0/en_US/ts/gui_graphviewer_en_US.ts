<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>DlgAlarmToGraph</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_alarm_to_graph.cpp" line="33"/>
        <source>告警推画面</source>
        <translation type="unfinished">Alarm Push</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_alarm_to_graph.cpp" line="71"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_alarm_to_graph.cpp" line="77"/>
        <source>画面名</source>
        <translation type="unfinished">Graph name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_alarm_to_graph.cpp" line="83"/>
        <source>厂站名</source>
        <translation type="unfinished">Station name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_alarm_to_graph.cpp" line="89"/>
        <source>告警次数</source>
        <translation type="unfinished">Alarm times</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_alarm_to_graph.cpp" line="95"/>
        <source>操作</source>
        <translation type="unfinished">Operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_alarm_to_graph.ui" line="41"/>
        <source>关闭</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Close</translation>
    </message>
</context>
<context>
    <name>DlgAppChange</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_app_change.cpp" line="32"/>
        <source>应用切换</source>
        <translation type="unfinished">Switch App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_app_change.ui" line="48"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_app_change.ui" line="55"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>DlgCycleSet</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_cycle_set.ui" line="28"/>
        <source>画面名：</source>
        <translation type="unfinished">Graph name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_cycle_set.ui" line="59"/>
        <source>刷新周期：</source>
        <translation type="unfinished">Refresh cycle:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_cycle_set.ui" line="69"/>
        <source>秒</source>
        <translation type="unfinished">sec</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_cycle_set.ui" line="96"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_cycle_set.ui" line="103"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_cycle_set.cpp" line="31"/>
        <source>刷新周期设置</source>
        <translation type="unfinished">Refresh cycle settings</translation>
    </message>
</context>
<context>
    <name>DlgEquipList</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_equip_list.ui" line="29"/>
        <source>开关</source>
        <translation type="unfinished">Switch</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_equip_list.ui" line="34"/>
        <source>母线</source>
        <translation type="unfinished">Bus</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_equip_list.ui" line="39"/>
        <source>变压器</source>
        <translation type="unfinished">Transformer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_equip_list.cpp" line="29"/>
        <source>设备列表</source>
        <translation type="unfinished">Device list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_equip_list.cpp" line="51"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_equip_list.cpp" line="57"/>
        <source>设备名</source>
        <translation type="unfinished">Equipment name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_equip_list.cpp" line="63"/>
        <source>类型</source>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_equip_list.cpp" line="69"/>
        <source>操作</source>
        <translation type="unfinished">Operation</translation>
    </message>
</context>
<context>
    <name>DlgFavorites</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.cpp" line="44"/>
        <source>收藏夹</source>
        <translation type="unfinished">Favorites</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.cpp" line="82"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.cpp" line="88"/>
        <source>画面名</source>
        <translation type="unfinished">Graph name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.cpp" line="94"/>
        <source>操作</source>
        <translation type="unfinished">Operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.cpp" line="167"/>
        <source>添加失败</source>
        <translation type="unfinished">Add failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.cpp" line="167"/>
        <source>该画面已添存在收藏夹列表中</source>
        <translation type="unfinished">This graph has been added to the favourites list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.ui" line="47"/>
        <source>收藏当前画面</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Favorite current graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.ui" line="58"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.ui" line="89"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_favorites.ui" line="96"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>DlgPicShortCut</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.cpp" line="43"/>
        <source>快捷键设置</source>
        <translation type="unfinished">Shortcut settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.cpp" line="73"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.cpp" line="79"/>
        <source>快捷键</source>
        <translation type="unfinished">Shortcut Key</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.cpp" line="85"/>
        <source>画面对象</source>
        <translation type="unfinished">Graph object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.cpp" line="204"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.cpp" line="211"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.cpp" line="204"/>
        <source>画面对象不能为空！</source>
        <translation type="unfinished">The graph object cannot be empty!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.cpp" line="211"/>
        <source>快捷键不能为空！</source>
        <translation type="unfinished">Shortcut keys cannot be empty!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.ui" line="41"/>
        <source>增加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.ui" line="52"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.ui" line="83"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_pic_short_cut.ui" line="90"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>DlgPrint</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.ui" line="28"/>
        <source>打印画面：</source>
        <translation type="unfinished">Print graph:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.ui" line="82"/>
        <source>画面颜色：</source>
        <translation type="unfinished">Graph:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.ui" line="96"/>
        <source>黑白</source>
        <translation type="unfinished">Monochrome</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.ui" line="150"/>
        <source>打印</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Print</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.ui" line="157"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.ui" line="89"/>
        <source>原色</source>
        <translation type="unfinished">Primary color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.ui" line="103"/>
        <source>白底</source>
        <translation type="unfinished">White background</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.ui" line="110"/>
        <source>反色</source>
        <translation type="unfinished">Invert color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.cpp" line="46"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.cpp" line="65"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.cpp" line="155"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.cpp" line="162"/>
        <source>打印</source>
        <translation type="unfinished">Print</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.cpp" line="61"/>
        <source>区域打印</source>
        <translation type="unfinished">Area print</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.cpp" line="155"/>
        <source>打印画面成功！</source>
        <translation type="unfinished">Print graph successfully!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_print.cpp" line="162"/>
        <source>未找到可用打印设备！</source>
        <translation type="unfinished">No available printing device found!</translation>
    </message>
</context>
<context>
    <name>DlgRecentOpen</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_recent_open.cpp" line="37"/>
        <source>最近打开</source>
        <translation type="unfinished">Recent</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_recent_open.cpp" line="70"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_recent_open.cpp" line="76"/>
        <source>画面名</source>
        <translation type="unfinished">Graph name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_recent_open.cpp" line="82"/>
        <source>操作</source>
        <translation type="unfinished">Operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_recent_open.ui" line="47"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_recent_open.ui" line="81"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_recent_open.ui" line="88"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>DlgScreenExchange</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_screen_exchange.ui" line="14"/>
        <source>显示屏幕设置</source>
        <translation type="unfinished">Display Screen Settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_screen_exchange.ui" line="22"/>
        <source>弹出画面显示屏幕选择：</source>
        <translation type="unfinished">Pop-up Graph Display Screen selection:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_screen_exchange.ui" line="50"/>
        <source>主屏幕</source>
        <translation type="unfinished">Main screen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_screen_exchange.ui" line="57"/>
        <source>副屏幕</source>
        <translation type="unfinished">Secondary screen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_screen_exchange.ui" line="82"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_screen_exchange.ui" line="89"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>DlgVoltageColor</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="29"/>
        <source>接地</source>
        <translation type="unfinished">Grounding</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="30"/>
        <source>带电</source>
        <translation type="unfinished">Electrified</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="31"/>
        <source>无效</source>
        <translation type="unfinished">Invalid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="45"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="203"/>
        <source>电压等级设置</source>
        <translation type="unfinished">Voltage level settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="64"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="89"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="70"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="95"/>
        <source>颜色</source>
        <translation type="unfinished">Color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="76"/>
        <source>电压等级</source>
        <translation type="unfinished">Voltage level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="101"/>
        <source>拓扑类型</source>
        <translation type="unfinished">Topo type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.cpp" line="207"/>
        <source>拓扑着色设置</source>
        <translation type="unfinished">Topo Coloring Settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.ui" line="47"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/dialogs/dlg_voltage_color.ui" line="54"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8316"/>
        <source>%1 没有此工具的打开权限</source>
        <translation type="unfinished">%1 does not have open permission for this tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="468"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4369"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4819"/>
        <source>打开字典</source>
        <translation type="unfinished">Open dictionary</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="467"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4368"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4818"/>
        <source>打开字典</source>
        <comment>menuName</comment>
        <translation type="unfinished">Open dictionary</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2269"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4388"/>
        <source>显示状态栏</source>
        <comment>menuName</comment>
        <translation type="unfinished">Show bar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4389"/>
        <source>显示状态栏</source>
        <translation type="unfinished">Show status bar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="568"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="577"/>
        <source>画面字典</source>
        <translation type="unfinished">Graph dict</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2062"/>
        <source>工具栏</source>
        <translation type="unfinished">Toolbar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3236"/>
        <source>区域打印</source>
        <translation type="unfinished">Area print</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3467"/>
        <source>区域放大</source>
        <translation type="unfinished">Area zoom in</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4751"/>
        <source>画面全屏</source>
        <translation type="unfinished">Full Screen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3701"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4910"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4939"/>
        <source>停止刷新</source>
        <translation type="unfinished">Stop refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2223"/>
        <source>重载画面</source>
        <translation type="unfinished">Reload</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4113"/>
        <source>启动拓扑</source>
        <translation type="unfinished">Start topo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4310"/>
        <source>关闭声音</source>
        <translation type="unfinished">Mute</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4361"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4812"/>
        <source>关闭字典</source>
        <translation type="unfinished">Close dictionary</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2305"/>
        <source>添加收藏</source>
        <translation type="unfinished">Add to favorites</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2193"/>
        <source>退出</source>
        <comment>menuName</comment>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2350"/>
        <source>上一页</source>
        <translation type="unfinished">Previous</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2356"/>
        <source>下一页</source>
        <translation type="unfinished">Next</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2374"/>
        <source>当前时间：</source>
        <translation type="unfinished">Current time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2380"/>
        <source>坐标：</source>
        <translation type="unfinished">Coordinates:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2663"/>
        <source>决策查询</source>
        <translation type="unfinished">Decision query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2672"/>
        <source>清空标识</source>
        <translation type="unfinished">Clear ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2690"/>
        <source>画面信息查询</source>
        <translation type="unfinished">Graph info query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3047"/>
        <source>关于 %1</source>
        <translation type="unfinished">About %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3049"/>
        <source>版本  %2</source>
        <translation type="unfinished">Version %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3126"/>
        <source>添加失败</source>
        <translation type="unfinished">Add failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3126"/>
        <source>该画面已添存在收藏夹列表中</source>
        <translation type="unfinished">This graph has been added to the favourites list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3138"/>
        <source>添加成功</source>
        <translation type="unfinished">Add successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3138"/>
        <source>画面已添加至收藏夹中</source>
        <translation type="unfinished">Graph added to favourites</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3218"/>
        <source>打印</source>
        <translation type="unfinished">Print</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3218"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3236"/>
        <source>暂无需要打印的画面</source>
        <translation type="unfinished">No graphs to print.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3335"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3346"/>
        <source>保存SVG文件</source>
        <translation type="unfinished">Save SVG-files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3346"/>
        <source>保存SVG文件:%1 成功!</source>
        <translation type="unfinished">Save SVG file: %1 Successful!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3375"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3390"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3398"/>
        <source>保存图片</source>
        <translation type="unfinished">Save picture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3391"/>
        <source>保存图片:%1 失败!%2 错误信息:%3</source>
        <translation type="unfinished">Save picture: %1 failed! %2 Error message: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3398"/>
        <source>保存图片:%1 成功!</source>
        <translation type="unfinished">Save picture: %1 Successfully!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3467"/>
        <source>暂无需要区域放大的画面</source>
        <translation type="unfinished">No graphs need area zoom now.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3690"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4916"/>
        <source>恢复刷新</source>
        <translation type="unfinished">Recovery refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4103"/>
        <source>关闭拓扑</source>
        <translation type="unfinished">Stop topo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4295"/>
        <source>刷新周期设置</source>
        <translation type="unfinished">Refresh cycle settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4295"/>
        <source>暂无需要设置周期的画面</source>
        <translation type="unfinished">No graphs need cycle set.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4305"/>
        <source>开启声音</source>
        <translation type="unfinished">Unmute</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4322"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4323"/>
        <source>取消保持电压颜色</source>
        <translation type="unfinished">Cancel holding voltage color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4329"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4330"/>
        <source>保持电压颜色</source>
        <translation type="unfinished">Keep voltage color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4381"/>
        <source>隐藏状态栏</source>
        <translation type="unfinished">Hide status bar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4713"/>
        <source>取消全屏</source>
        <translation type="unfinished">Cancel full screen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5167"/>
        <source>是</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5168"/>
        <source>否</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7001"/>
        <source>请先关闭之前打开的窗口</source>
        <translation type="unfinished">Please close the previously opened window first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7280"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7446"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7470"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7633"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7672"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7847"/>
        <source>查找失败</source>
        <translation type="unfinished">Search failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7280"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7470"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7672"/>
        <source>查询条件不能为空</source>
        <translation type="unfinished">The query condition cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7446"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7633"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7847"/>
        <source>未找到符合条件的图形对象</source>
        <translation type="unfinished">No matching graphics object found</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7947"/>
        <source>打开失败</source>
        <translation type="unfinished">Open failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7947"/>
        <source>未找到相关画面：%1</source>
        <translation type="unfinished">Related graph not found: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8176"/>
        <source> 登录时限:</source>
        <translation type="unfinished">Login time limit:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8218"/>
        <source>%1 没有此工具的打开权限! </source>
        <translation type="unfinished">%1 does not have permission to open this tool!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8247"/>
        <source>无操作权限</source>
        <translation type="unfinished">No operation permission</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5166"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8219"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8247"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8317"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="268"/>
        <source>图形监视工具(节点名:%1)</source>
        <comment>toolName</comment>
        <translation type="unfinished">Graphic Monitor (Node: %1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="582"/>
        <source>画面</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="612"/>
        <source>异常输入</source>
        <translation type="unfinished">Abnormal input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="612"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished">Abnormal query data, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="763"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="781"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2681"/>
        <source>调试信息</source>
        <translation type="unfinished">Debug info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="794"/>
        <source>关闭</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1892"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1927"/>
        <source>文件</source>
        <comment>subTitle</comment>
        <translation type="unfinished">File</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1896"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1944"/>
        <source>视图</source>
        <comment>subTitle</comment>
        <translation type="unfinished">View</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1900"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1974"/>
        <source>操作</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1904"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1994"/>
        <source>设置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1908"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2005"/>
        <source>应用</source>
        <comment>subTitle</comment>
        <translation type="unfinished">App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1912"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2014"/>
        <source>窗口</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Window</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="1951"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2088"/>
        <source>缩放</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Scale</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2085"/>
        <source>缩放</source>
        <translation type="unfinished">Scale</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2139"/>
        <source>应用扩展工具栏</source>
        <translation type="unfinished">App extension toolbar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2177"/>
        <source>最近打开</source>
        <comment>menuName</comment>
        <translation type="unfinished">Recent</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2181"/>
        <source>管理收藏</source>
        <comment>menuName</comment>
        <translation type="unfinished">Favorites</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2182"/>
        <source>打印画面</source>
        <comment>menuName</comment>
        <translation type="unfinished">Print graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2184"/>
        <source>区域打印</source>
        <comment>menuName</comment>
        <translation type="unfinished">Area print</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2188"/>
        <source>导出SVG</source>
        <comment>menuName</comment>
        <translation type="unfinished">Export SVG</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2190"/>
        <source>导出图片</source>
        <comment>menuName</comment>
        <translation type="unfinished">Export picture</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2192"/>
        <source>关闭窗口</source>
        <comment>menuName</comment>
        <translation type="unfinished">Close window</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2196"/>
        <source>画面放大</source>
        <comment>menuName</comment>
        <translation type="unfinished">Graph zoom in</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2197"/>
        <source>画面缩小</source>
        <comment>menuName</comment>
        <translation type="unfinished">Graph zoom out</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2200"/>
        <source>比例缩放</source>
        <comment>menuName</comment>
        <translation type="unfinished">Scale</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2202"/>
        <source>区域放大</source>
        <comment>menuName</comment>
        <translation type="unfinished">Area zoom in</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2204"/>
        <source>重置缩放</source>
        <comment>menuName</comment>
        <translation type="unfinished">Reset</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2206"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4750"/>
        <source>画面全屏</source>
        <comment>menuName</comment>
        <translation type="unfinished">Full screen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2207"/>
        <source>画面满屏</source>
        <comment>menuName</comment>
        <translation type="unfinished">Fit screen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2210"/>
        <source>编辑画面</source>
        <comment>menuName</comment>
        <translation type="unfinished">Edit graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2212"/>
        <source>设备查找</source>
        <comment>menuName</comment>
        <translation type="unfinished">Device</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2214"/>
        <source>间隔查找</source>
        <comment>menuName</comment>
        <translation type="unfinished">Interval search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2216"/>
        <source>文本查找</source>
        <comment>menuName</comment>
        <translation type="unfinished">Text search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2218"/>
        <source>告警推画面</source>
        <comment>menuName</comment>
        <translation type="unfinished">Alarm push</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2220"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3700"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4909"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4938"/>
        <source>停止刷新</source>
        <comment>menuName</comment>
        <translation type="unfinished">Stop refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2222"/>
        <source>手动刷新</source>
        <comment>menuName</comment>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2225"/>
        <source>重载所有</source>
        <comment>menuName</comment>
        <translation type="unfinished">Reload all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2227"/>
        <source>设备列表</source>
        <comment>menuName</comment>
        <translation type="unfinished">Device list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2231"/>
        <source>电压等级</source>
        <comment>menuName</comment>
        <translation type="unfinished">Voltage level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2233"/>
        <source>拓扑颜色</source>
        <comment>menuName</comment>
        <translation type="unfinished">Topo color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2234"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4112"/>
        <source>启动拓扑</source>
        <comment>menuName</comment>
        <translation type="unfinished">Start topo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2244"/>
        <source>启动画面</source>
        <comment>menuName</comment>
        <translation type="unfinished">Startup graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2246"/>
        <source>快捷设置</source>
        <comment>menuName</comment>
        <translation type="unfinished">Quick settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2248"/>
        <source>刷新周期</source>
        <comment>menuName</comment>
        <translation type="unfinished">Refresh cycle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2249"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4309"/>
        <source>关闭声音</source>
        <comment>menuName</comment>
        <translation type="unfinished">Mute</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2250"/>
        <source>保持电压等级颜色</source>
        <comment>menuName</comment>
        <translation type="unfinished">Keep voltage color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2259"/>
        <source>应用切换</source>
        <comment>menuName</comment>
        <translation type="unfinished">Switch app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2260"/>
        <source>应用扩展</source>
        <comment>menuName</comment>
        <translation type="unfinished">App extension</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2261"/>
        <source>顺控操作</source>
        <comment>menuName</comment>
        <translation type="unfinished">Sequential</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2267"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4360"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4811"/>
        <source>关闭字典</source>
        <comment>menuName</comment>
        <translation type="unfinished">Close dict</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2271"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4424"/>
        <source>调试模式</source>
        <comment>menuName</comment>
        <translation type="unfinished">Debug mode</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2274"/>
        <source>层叠窗口</source>
        <translation type="unfinished">Cascade windows </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2276"/>
        <source>平铺窗口</source>
        <translation type="unfinished">Tiled windows </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2349"/>
        <source>上一页</source>
        <comment>menuName</comment>
        <translation type="unfinished">Previous</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2355"/>
        <source>下一页</source>
        <comment>menuName</comment>
        <translation type="unfinished">Next</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2368"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4691"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4770"/>
        <source>隐藏菜单栏</source>
        <comment>menuName</comment>
        <translation type="unfinished">Hide menu</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="2369"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4692"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4771"/>
        <source>隐藏菜单栏</source>
        <translation type="unfinished">Hide menu</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3623"/>
        <source>设备查找</source>
        <comment>toolName</comment>
        <translation type="unfinished">Device</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3641"/>
        <source>间隔查找</source>
        <comment>toolName</comment>
        <translation type="unfinished">Interval search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3660"/>
        <source>文本查找</source>
        <comment>toolName</comment>
        <translation type="unfinished">Text Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3689"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4915"/>
        <source>恢复刷新</source>
        <comment>menuName</comment>
        <translation type="unfinished">Recovery refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="3861"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4019"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5631"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5752"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5857"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5984"/>
        <source>图形监视工具(节点名:%1)[画面名：%2]</source>
        <comment>toolName</comment>
        <translation type="unfinished">Graphic Monitor (Node: %1) [Graph: %2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4102"/>
        <source>关闭拓扑</source>
        <comment>menuName</comment>
        <translation type="unfinished">Stop topo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4304"/>
        <source>开启声音</source>
        <comment>menuName</comment>
        <translation type="unfinished">Unmute</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4380"/>
        <source>隐藏状态栏</source>
        <comment>menuName</comment>
        <translation type="unfinished">Hide bar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4401"/>
        <source>关闭调试模式</source>
        <comment>menuName</comment>
        <translation type="unfinished">Turn off</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4402"/>
        <source>关闭调试模式</source>
        <translation type="unfinished">Turn off debugging mode</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4425"/>
        <source>调试模式</source>
        <translation type="unfinished">Debug mode</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4528"/>
        <source>鼠标左键单击需要查看调试信息的元素</source>
        <translation type="unfinished">Click the left mouse button on the element that needs to view debugging info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4699"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4778"/>
        <source>显示菜单栏</source>
        <comment>menuName</comment>
        <translation type="unfinished">Show menu</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4700"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4779"/>
        <source>显示菜单栏</source>
        <translation type="unfinished">Show menu</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="4712"/>
        <source>取消全屏</source>
        <comment>menuName</comment>
        <translation type="unfinished">Cancel full screen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5166"/>
        <source>是否关闭图形监视工具?</source>
        <translation type="unfinished">Whether to close Graphic Monitor?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5548"/>
        <source>(草稿版本)</source>
        <translation type="unfinished">(Draft version)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5549"/>
        <source>(草稿版本)*</source>
        <translation type="unfinished">(Draft version)*</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5556"/>
        <source>(最新版本)</source>
        <translation type="unfinished">(Latest version)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="5557"/>
        <source>(最新版本)*</source>
        <translation type="unfinished">(Latest version)*</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6827"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6834"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6840"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="7000"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6827"/>
        <source>可执行程序路径不能为空!</source>
        <translation type="unfinished">Executable path cannot be empty! 	</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6834"/>
        <source>可执行程序不存在!</source>
        <translation type="unfinished">Executable program does not exist!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6840"/>
        <source>所选文件没有执行权限!</source>
        <translation type="unfinished">The selected file has no execution permission!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6857"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6861"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6893"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6919"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6857"/>
        <source>程序异常退出!</source>
        <translation type="unfinished">Program exited abnormally!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6861"/>
        <source>程序退出码: %1</source>
        <translation type="unfinished">Program exit code: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6875"/>
        <source>程序启动失败</source>
        <translation type="unfinished">Failed to start the program</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6878"/>
        <source>程序崩溃</source>
        <translation type="unfinished">Program crash</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6881"/>
        <source>操作超时</source>
        <translation type="unfinished">Operation timeout</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6884"/>
        <source>写入错误</source>
        <translation type="unfinished">Write error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6887"/>
        <source>读取错误</source>
        <translation type="unfinished">Read error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6890"/>
        <source>未知错误</source>
        <translation type="unfinished">Unknown error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="6919"/>
        <source>启动程序异常: %1</source>
        <translation type="unfinished">Start program abnormal: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8538"/>
        <source>已修改，是否更新？</source>
        <translation type="unfinished">Modified, would you like to update?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/mainwindow.cpp" line="8542"/>
        <source>操作确认</source>
        <translation type="unfinished">Operation confirm</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/main.cpp" line="283"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/main.cpp" line="679"/>
        <source>%1 没有此工具的打开权限</source>
        <comment>gui_graphviewer::main</comment>
        <translation type="unfinished">%1 does not have open permission for this tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/main.cpp" line="284"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/main.cpp" line="323"/>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/main.cpp" line="680"/>
        <source>提示</source>
        <comment>gui_graphviewer::main</comment>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_graphviewer/main.cpp" line="324"/>
        <source>注册失败</source>
        <comment>gui_graphviewer::main</comment>
        <translation type="unfinished">Reg failed</translation>
    </message>
</context>
</TS>
