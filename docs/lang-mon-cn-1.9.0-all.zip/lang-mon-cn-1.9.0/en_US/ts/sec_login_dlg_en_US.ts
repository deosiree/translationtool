<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="87"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="116"/>
        <source>设备监视系统</source>
        <translation type="unfinished">Equipment Monitor System</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="87"/>
        <source>网络连接已存在，不可以无系统方式登录</source>
        <translation type="unfinished">The net connection already exists and cannot be logged in without system access</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="271"/>
        <source>已连接</source>
        <translation type="unfinished">Connected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="303"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="304"/>
        <source>用户登出</source>
        <translation type="unfinished">Logout</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="346"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="347"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="389"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="390"/>
        <source>用户校验</source>
        <translation type="unfinished">User Verification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="972"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="1115"/>
        <source>切换用户</source>
        <translation type="unfinished">Switch User</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="974"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="1117"/>
        <source>是否切换</source>
        <translation type="unfinished">Whether to switch</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="975"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="1118"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="976"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="1119"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="1155"/>
        <source>注销用户</source>
        <translation type="unfinished">Logout </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="1156"/>
        <source>是否注销用户</source>
        <translation type="unfinished">Whether to log out of the user</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="26"/>
        <source>修改密码</source>
        <comment>toolName</comment>
        <translation type="unfinished">Change Password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/send_aud_alarm.cpp" line="73"/>
        <source>节点[%1]工具[%2]%3</source>
        <translation type="unfinished">Node [%1] Tool [%2] %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1637"/>
        <source>登录输入用户名[%1]包含异常字符，可能存在篡改、恶意攻击行为</source>
        <translation type="unfinished">Login username [%1] contains abnormal characters; possible tampering/malicious attack detected</translation>
    </message>
</context>
<context>
    <name>change_pwd_dlg</name>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_pwd_dlg.ui" line="29"/>
        <source>当前密码：</source>
        <translation type="unfinished">Current password:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_pwd_dlg.ui" line="51"/>
        <source>新密码：</source>
        <translation type="unfinished">New password:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_pwd_dlg.ui" line="73"/>
        <source>确认密码：</source>
        <translation type="unfinished">Confirm password:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_pwd_dlg.ui" line="99"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
</context>
<context>
    <name>iasp::security::CChangePwdDlgImp</name>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="92"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="96"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="108"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="117"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="125"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="133"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="146"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="160"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="172"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="183"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="212"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="97"/>
        <source>参数错误</source>
        <translation type="unfinished">Param error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="109"/>
        <source>用户不存在</source>
        <translation type="unfinished">User does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="118"/>
        <source>请补全信息</source>
        <translation type="unfinished">Please complete the info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="126"/>
        <source>两次输入的密码不一致</source>
        <translation type="unfinished">Entered passwords differ!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="134"/>
        <source>新旧密码不能相同，请重新填写</source>
        <translation type="unfinished">New and old passwords cannot be the same, please fill in again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="147"/>
        <source>密码输入有误，请重新输入</source>
        <translation type="unfinished">Password input incorrect, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="161"/>
        <source>密码复杂度不满足要求:%1</source>
        <translation type="unfinished">Password complexity does not meet the requirement: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="173"/>
        <source>密码生成失败，请检查</source>
        <translation type="unfinished">Password generation failed, please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="184"/>
        <source>密码已使用，请修改</source>
        <translation type="unfinished">Password has been used, please change it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="199"/>
        <source>密码更新成功</source>
        <translation type="unfinished">Password updated successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="208"/>
        <source>密码更新失败</source>
        <translation type="unfinished">Password update failed</translation>
    </message>
</context>
<context>
    <name>iasp::security::CLoginDlg</name>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="59"/>
        <source>登录管理</source>
        <translation type="unfinished">Login Management</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="143"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="275"/>
        <source>用户登录</source>
        <translation type="unfinished">User Login</translation>
    </message>
</context>
<context>
    <name>iasp::security::CLoginDlgImp</name>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="393"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="401"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="524"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="532"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="642"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="650"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="703"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="708"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="713"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="718"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="723"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="728"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="733"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="754"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="821"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1071"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1080"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1091"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1142"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="755"/>
        <source>用户数据初始化失败，请检查</source>
        <translation type="unfinished">Failed to initialize user data, please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="771"/>
        <source>指纹校验：</source>
        <translation type="unfinished">Fingerprint verification:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="782"/>
        <source>UKey：</source>
        <translation type="unfinished">UKey:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1001"/>
        <source>连接</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Connect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1053"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1368"/>
        <source>连接</source>
        <translation type="unfinished">Connect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1143"/>
        <source>网络注册连接切换失败</source>
        <translation type="unfinished">Net reg connection switching failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1158"/>
        <source>已连接</source>
        <translation type="unfinished">Connected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1345"/>
        <source>IP：</source>
        <translation type="unfinished">IP:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1351"/>
        <source>请输入端口</source>
        <translation type="unfinished">Please enter the port</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1390"/>
        <source>用户名：</source>
        <translation type="unfinished">Username:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1420"/>
        <source>密码：</source>
        <translation type="unfinished">Password:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1425"/>
        <source>请输入密码</source>
        <translation type="unfinished">Please enter your password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1437"/>
        <source>双因子：</source>
        <translation type="unfinished">Two-factor:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1441"/>
        <source>校验通过</source>
        <translation type="unfinished">Verification passed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1455"/>
        <source>验证码：</source>
        <translation type="unfinished">Verification code:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1459"/>
        <source>请输入验证码</source>
        <translation type="unfinished">Please enter the verification code</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="162"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="775"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="786"/>
        <source>点击登录后进行校验</source>
        <translation type="unfinished">Click to log in and perform verification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="176"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="420"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="551"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="695"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="753"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="820"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="955"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="972"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1068"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="177"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="421"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="552"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="894"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="919"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="936"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="956"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="973"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="999"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1327"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="197"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="205"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="211"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="227"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="239"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="255"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="269"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="283"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="291"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="299"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="307"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="315"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="323"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="331"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="339"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="347"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="355"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="363"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="371"/>
        <source>登录失败</source>
        <comment>toolName</comment>
        <translation type="unfinished">Login Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="198"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="438"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="566"/>
        <source>用户名或密码错误</source>
        <translation type="unfinished">Incorrect username or password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="206"/>
        <source>权限校验失败</source>
        <translation type="unfinished">Permission verification failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="212"/>
        <source>服务登录请求认证失败，请检查</source>
        <translation type="unfinished">Service login request auth failed, please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="228"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="454"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="580"/>
        <source>用户已被锁定，剩余锁定时长： %1 分 %2 秒， 预计将于 %3 解锁 </source>
        <translation type="unfinished">The user has been locked. Remaining lock time: %1 min %2 sec. It is estimated to be unlocked at %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="243"/>
        <source>用户已登录，用户 %1 已经于 %2 在 %3 节点登录 %4 。</source>
        <translation type="unfinished">User has logged in. User %1, at %2 on node %3, logged in %4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="256"/>
        <source>用户密码未初始化，是否初始化</source>
        <translation type="unfinished">User password not initialized, whether to initialize the password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="270"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="480"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="602"/>
        <source>用户密码已失效，是否更新</source>
        <translation type="unfinished">Your password has expired. Whether to update it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="284"/>
        <source>用户登录信息生成失败，请检查</source>
        <translation type="unfinished">User login info generation failed, please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="292"/>
        <source>认证失败</source>
        <translation type="unfinished">Auth failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="300"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="494"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="614"/>
        <source>用户双因子校验失败</source>
        <translation type="unfinished">User two-factor authentication failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="308"/>
        <source>APP不可多次登录</source>
        <translation type="unfinished">APP cannot be logged in multiple times</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="316"/>
        <source>用户未录入指纹</source>
        <translation type="unfinished">The user&apos;s fingerprint is not recorded</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="324"/>
        <source>指纹校验失败，请重试</source>
        <translation type="unfinished">Fingerprint verification failed, please try again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="332"/>
        <source>指纹仪加载失败，请检查</source>
        <translation type="unfinished">Fingerprint scanner failed to load, please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="340"/>
        <source>用户信息认证失败，请检查</source>
        <translation type="unfinished">User info auth failed, please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="348"/>
        <source>UKey校验失败，请重试</source>
        <translation type="unfinished">UKey verification failed, please try again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="356"/>
        <source>UKey初始化失败，请检查</source>
        <translation type="unfinished">UKey initialization failed, please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="364"/>
        <source>用户录入UKey与实际UKey不匹配</source>
        <translation type="unfinished">User entered UKey does not match actual UKey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="372"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="502"/>
        <source>密码复杂度较低，是否更新密码</source>
        <translation type="unfinished">Low password complexity, would you like to update password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="394"/>
        <source>用户登录超时，请重试</source>
        <translation type="unfinished">User login timeout, please try again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="402"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="533"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="651"/>
        <source>校验结果获取失败，请检查</source>
        <translation type="unfinished">Verification result acquisition failed, please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="437"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="453"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="465"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="479"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="493"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="501"/>
        <source>登出失败</source>
        <comment>toolName</comment>
        <translation type="unfinished">Logout Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="466"/>
        <source>用户密码未初始化,是否初始化</source>
        <translation type="unfinished">User password not initialized, Whether to initialize the password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="525"/>
        <source>用户退出操作超时，请重试</source>
        <translation type="unfinished">User exit operation timed out, please try again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="565"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="579"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="589"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="601"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="613"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="619"/>
        <source>校验失败</source>
        <comment>toolName</comment>
        <translation type="unfinished">Verification Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="590"/>
        <source>用户未进行初始化设置,是否初始化密码</source>
        <translation type="unfinished">The user has not completed the initial setup. Whether to initialize the password</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="620"/>
        <source>密码复杂度较低，是否更新</source>
        <translation type="unfinished">Low password complexity, would you like to update it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="643"/>
        <source>用户校验超时，请重试</source>
        <translation type="unfinished">User verification timeout, please try again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="704"/>
        <source>用户名不可为空</source>
        <translation type="unfinished">User name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="709"/>
        <source>输入非法，请重新输入</source>
        <translation type="unfinished">Illegal input, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="714"/>
        <source>密码不可为空</source>
        <translation type="unfinished">Password cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="719"/>
        <source>自定义登录时长不可为空</source>
        <translation type="unfinished">Custom login duration cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="724"/>
        <source>验证码不可为空</source>
        <translation type="unfinished">Verification code cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="729"/>
        <source>工作目录不可为空</source>
        <translation type="unfinished">Working dir cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="734"/>
        <source>请检查输入内容是否完整</source>
        <translation type="unfinished">Please check if the input content is complete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1638"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1643"/>
        <source>系统</source>
        <translation type="unfinished">System</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="160"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="773"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="784"/>
        <source>点击确认后进行校验</source>
        <translation type="unfinished">Click Confirm to perform validation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="822"/>
        <source>插件:%1参数错误，请检查数据库配置</source>
        <translation type="unfinished">Plugin: %1 param error, please check DB Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="884"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="909"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1000"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1328"/>
        <source>登录</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Login</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="887"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="912"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="992"/>
        <source>退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="891"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="916"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="996"/>
        <source>注销</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Logout</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="896"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="921"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1004"/>
        <source>用户登录</source>
        <comment>toolName</comment>
        <translation type="unfinished">User Login</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="937"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1329"/>
        <source>登出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Logout</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="942"/>
        <source>用户登出</source>
        <comment>toolName</comment>
        <translation type="unfinished">Logout</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="958"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="975"/>
        <source>用户校验</source>
        <comment>toolName</comment>
        <translation type="unfinished">User Verification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1072"/>
        <source>IP地址不可为空</source>
        <translation type="unfinished">IP address cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1081"/>
        <source>端口号不可为空</source>
        <translation type="unfinished">The port ID cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1092"/>
        <source>IP地址错误</source>
        <translation type="unfinished">IP address error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1313"/>
        <source>欢迎登录</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Welcome</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1460"/>
        <source>发送验证码</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Send code</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1477"/>
        <source>登录有效期：</source>
        <translation type="unfinished">Login expiration:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1484"/>
        <source>30分钟</source>
        <translation type="unfinished">30min</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1488"/>
        <source>60分钟</source>
        <translation type="unfinished">60 min</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1491"/>
        <source>3小时</source>
        <translation type="unfinished">3h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1494"/>
        <source>6小时</source>
        <translation type="unfinished">6h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1497"/>
        <source>12小时</source>
        <translation type="unfinished">12h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1500"/>
        <source>24小时</source>
        <translation type="unfinished">24h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1512"/>
        <source>分钟   </source>
        <translation type="unfinished">min</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1576"/>
        <source>工作目录：</source>
        <translation type="unfinished">Working dir:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1580"/>
        <source>请设置工作路径</source>
        <translation type="unfinished">Please set the working path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1582"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1747"/>
        <source>选择目录</source>
        <translation type="unfinished">Select dir</translation>
    </message>
</context>
<context>
    <name>userAuthFunc</name>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1087"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1104"/>
        <source>未录指纹</source>
        <translation type="unfinished">Unrecorded fingerprint</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1114"/>
        <source>无指纹设备</source>
        <translation type="unfinished">No fingerprint device</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1125"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1132"/>
        <source>指纹仪加载失败</source>
        <translation type="unfinished">The fingerprint meter failed to be loaded</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1136"/>
        <source>请开始指纹校验</source>
        <translation type="unfinished">Please start fingerprint verification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1142"/>
        <source>指纹校验失败，请重试</source>
        <translation type="unfinished">Fingerprint verification failed, please try again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1145"/>
        <source>指纹校验失败</source>
        <translation type="unfinished">Fingerprint verification failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1160"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1198"/>
        <source>用户未制作UKey</source>
        <translation type="unfinished">User did not create a UKey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1178"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1192"/>
        <source>用户未制作个人证书</source>
        <translation type="unfinished">The user did not create a personal certificate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1214"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1222"/>
        <source>UKey证书错误</source>
        <translation type="unfinished">UKey certificate error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1253"/>
        <source>UKey不匹配，加载失败</source>
        <translation type="unfinished">UKey mismatch, loading failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1262"/>
        <source>加载证书失败</source>
        <translation type="unfinished">Failed to load certificate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1272"/>
        <source>UKey校验失败</source>
        <translation type="unfinished">The UKey verification failed</translation>
    </message>
</context>
</TS>
