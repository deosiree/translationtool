<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="en_US">
<context>
    <name>AboutDialog</name>
    <message>
        <source>&amp;Close</source>
        <translation />
    </message>
</context>
<context>
    <name>AboutLabel</name>
    <message>
        <source>Warning</source>
        <translation />
    </message>
    <message>
        <source>Unable to launch external application.</source>
        <translation />
    </message>
</context>
<context>
    <name>Assistant</name>
    <message>
        <source>Error registering documentation file '%1': %2</source>
        <translation />
    </message>
    <message>
        <source>Could not register documentation file
%1

Reason:
%2</source>
        <translation />
    </message>
    <message>
        <source>Documentation successfully registered.</source>
        <translation />
    </message>
    <message>
        <source>Could not unregister documentation file
%1

Reason:
%2</source>
        <translation />
    </message>
    <message>
        <source>Documentation successfully unregistered.</source>
        <translation />
    </message>
    <message>
        <source>Error reading collection file '%1': %2.</source>
        <translation />
    </message>
    <message>
        <source>Error creating collection file '%1': %2.</source>
        <translation />
    </message>
    <message>
        <source>Cannot load sqlite database driver!</source>
        <translation />
    </message>
</context>
<context>
    <name>BookmarkDialog</name>
    <message>
        <source>Add Bookmark</source>
        <translation />
    </message>
    <message>
        <source>Bookmark:</source>
        <translation />
    </message>
    <message>
        <source>Add in Folder:</source>
        <translation />
    </message>
    <message>
        <source>New Folder</source>
        <translation />
    </message>
    <message>
        <source>+</source>
        <translation />
    </message>
    <message>
        <source>Rename Folder</source>
        <translation />
    </message>
</context>
<context>
    <name>BookmarkItem</name>
    <message>
        <source>New Folder</source>
        <translation />
    </message>
    <message>
        <source>Untitled</source>
        <translation />
    </message>
</context>
<context>
    <name>BookmarkManager</name>
    <message>
        <source>Untitled</source>
        <translation />
    </message>
    <message>
        <source>Remove</source>
        <translation />
    </message>
    <message>
        <source>You are going to delete a Folder, this will also&lt;br&gt;remove it's content. Are you sure to continue?</source>
        <translation />
    </message>
    <message>
        <source>Manage Bookmarks...</source>
        <translation />
    </message>
    <message>
        <source>Add Bookmark...</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+D</source>
        <translation />
    </message>
    <message>
        <source>Delete Folder</source>
        <translation />
    </message>
    <message>
        <source>Rename Folder</source>
        <translation />
    </message>
    <message>
        <source>Show Bookmark</source>
        <translation />
    </message>
    <message>
        <source>Show Bookmark in New Tab</source>
        <translation />
    </message>
    <message>
        <source>Delete Bookmark</source>
        <translation />
    </message>
    <message>
        <source>Rename Bookmark</source>
        <translation />
    </message>
</context>
<context>
    <name>BookmarkManagerWidget</name>
    <message>
        <source>Manage Bookmarks</source>
        <translation />
    </message>
    <message>
        <source>Search:</source>
        <translation />
    </message>
    <message>
        <source>Remove</source>
        <translation />
    </message>
    <message>
        <source>Import and Backup</source>
        <translation />
    </message>
    <message>
        <source>OK</source>
        <translation />
    </message>
    <message>
        <source>Import...</source>
        <translation />
    </message>
    <message>
        <source>Export...</source>
        <translation />
    </message>
    <message>
        <source>Open File</source>
        <translation />
    </message>
    <message>
        <source>Files (*.xbel)</source>
        <translation />
    </message>
    <message>
        <source>Save File</source>
        <translation />
    </message>
    <message>
        <source>Qt Assistant</source>
        <translation />
    </message>
    <message>
        <source>Unable to save bookmarks.</source>
        <translation />
    </message>
    <message>
        <source>You are goingto delete a Folder, this will also&lt;br&gt; remove it's content. Are you sure to continue?</source>
        <translation />
    </message>
    <message>
        <source>Delete Folder</source>
        <translation />
    </message>
    <message>
        <source>Rename Folder</source>
        <translation />
    </message>
    <message>
        <source>Show Bookmark</source>
        <translation />
    </message>
    <message>
        <source>Show Bookmark in New Tab</source>
        <translation />
    </message>
    <message>
        <source>Delete Bookmark</source>
        <translation />
    </message>
    <message>
        <source>Rename Bookmark</source>
        <translation />
    </message>
</context>
<context>
    <name>BookmarkModel</name>
    <message>
        <source>Name</source>
        <translation />
    </message>
    <message>
        <source>Address</source>
        <translation />
    </message>
    <message>
        <source>Bookmarks Toolbar</source>
        <translation />
    </message>
    <message>
        <source>Bookmarks Menu</source>
        <translation />
    </message>
</context>
<context>
    <name>BookmarkWidget</name>
    <message>
        <source>Bookmarks</source>
        <translation />
    </message>
    <message>
        <source>Filter:</source>
        <translation />
    </message>
    <message>
        <source>Add</source>
        <translation />
    </message>
    <message>
        <source>Remove</source>
        <translation />
    </message>
</context>
<context>
    <name>CentralWidget</name>
    <message>
        <source>Print Document</source>
        <translation />
    </message>
</context>
<context>
    <name>CmdLineParser</name>
    <message>
        <source>Unknown option: %1</source>
        <translation />
    </message>
    <message>
        <source>Unknown widget: %1</source>
        <translation />
    </message>
    <message>
        <source>The collection file '%1' does not exist.</source>
        <translation />
    </message>
    <message>
        <source>Usage: assistant [Options]

-collectionFile file       Uses the specified collection
                           file instead of the default one
-showUrl url               Shows the document with the
                           url.
-enableRemoteControl       Enables Assistant to be
                           remotely controlled.
-show widget               Shows the specified dockwidget
                           which can be "contents", "index",
                           "bookmarks" or "search".
-activate widget           Activates the specified dockwidget
                           which can be "contents", "index",
                           "bookmarks" or "search".
-hide widget               Hides the specified dockwidget
                           which can be "contents", "index"
                           "bookmarks" or "search".
-register helpFile         Registers the specified help file
                           (.qch) in the given collection
                           file.
-unregister helpFile       Unregisters the specified help file
                           (.qch) from the give collection
                           file.
-setCurrentFilter filter   Set the filter as the active filter.
-remove-search-index       Removes the full text search index.
-rebuild-search-index      Obsolete. Use -remove-search-index instead.
                           Removes the full text search index.
                           It will be rebuilt on next Assistant run.
-quiet                     Does not display any error or
                           status message.
-help                      Displays this help.
</source>
        <translation />
    </message>
    <message>
        <source>Missing collection file.</source>
        <translation />
    </message>
    <message>
        <source>Invalid URL '%1'.</source>
        <translation />
    </message>
    <message>
        <source>Missing URL.</source>
        <translation />
    </message>
    <message>
        <source>Missing widget.</source>
        <translation />
    </message>
    <message>
        <source>The Qt help file '%1' does not exist.</source>
        <translation />
    </message>
    <message>
        <source>Missing help file.</source>
        <translation />
    </message>
    <message>
        <source>Missing filter argument.</source>
        <translation />
    </message>
    <message>
        <source>Error</source>
        <translation />
    </message>
    <message>
        <source>Notice</source>
        <translation />
    </message>
</context>
<context>
    <name>ContentWindow</name>
    <message>
        <source>Open Link</source>
        <translation />
    </message>
    <message>
        <source>Open Link in New Tab</source>
        <translation />
    </message>
</context>
<context>
    <name>FindWidget</name>
    <message>
        <source>Previous</source>
        <translation />
    </message>
    <message>
        <source>Next</source>
        <translation />
    </message>
    <message>
        <source>Case Sensitive</source>
        <translation />
    </message>
    <message>
        <source>&lt;img src=":/qt-project.org/assistant/images/wrap.png"&gt;&amp;nbsp;Search wrapped</source>
        <translation />
    </message>
</context>
<context>
    <name>FontPanel</name>
    <message>
        <source>Font</source>
        <translation />
    </message>
    <message>
        <source>&amp;Writing system</source>
        <translation />
    </message>
    <message>
        <source>&amp;Family</source>
        <translation />
    </message>
    <message>
        <source>&amp;Style</source>
        <translation />
    </message>
    <message>
        <source>&amp;Point size</source>
        <translation />
    </message>
</context>
<context>
    <name>GlobalActions</name>
    <message>
        <source>&amp;Back</source>
        <translation />
    </message>
    <message>
        <source>&amp;Forward</source>
        <translation />
    </message>
    <message>
        <source>&amp;Home</source>
        <translation />
    </message>
    <message>
        <source>ALT+Home</source>
        <translation />
    </message>
    <message>
        <source>Zoom &amp;in</source>
        <translation />
    </message>
    <message>
        <source>Zoom &amp;out</source>
        <translation />
    </message>
    <message>
        <source>&amp;Copy selected Text</source>
        <translation />
    </message>
    <message>
        <source>&amp;Print...</source>
        <translation />
    </message>
    <message>
        <source>&amp;Find in Text...</source>
        <translation />
    </message>
    <message>
        <source>&amp;Find</source>
        <translation />
    </message>
</context>
<context>
    <name>HelpDocSettingsWidget</name>
    <message>
        <source>Form</source>
        <translation />
    </message>
    <message>
        <source>Registered Documentation</source>
        <translation />
    </message>
    <message>
        <source>&lt;Filter&gt;</source>
        <translation />
    </message>
    <message>
        <source>Add...</source>
        <translation />
    </message>
    <message>
        <source>Remove</source>
        <translation />
    </message>
    <message>
        <source>Add Documentation</source>
        <translation />
    </message>
    <message>
        <source>Qt Compressed Help Files (*.qch)</source>
        <translation />
    </message>
</context>
<context>
    <name>HelpViewer</name>
    <message>
        <source>&lt;title&gt;about:blank&lt;/title&gt;</source>
        <translation />
    </message>
    <message>
        <source>&lt;title&gt;Error 404...&lt;/title&gt;&lt;div align="center"&gt;&lt;br&gt;&lt;br&gt;&lt;h1&gt;The page could not be found.&lt;/h1&gt;&lt;br&gt;&lt;h3&gt;'%1'&lt;/h3&gt;&lt;/div&gt;</source>
        <translation />
    </message>
    <message>
        <source>Error 404...</source>
        <translation />
    </message>
    <message>
        <source>The page could not be found</source>
        <translation />
    </message>
    <message>
        <source>Please make sure that you have all documentation sets installed.</source>
        <translation />
    </message>
    <message>
        <source>Error loading: %1</source>
        <translation />
    </message>
</context>
<context>
    <name>IndexWindow</name>
    <message>
        <source>&amp;Look for:</source>
        <translation />
    </message>
    <message>
        <source>Open Link</source>
        <translation />
    </message>
    <message>
        <source>Open Link in New Tab</source>
        <translation />
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Index</source>
        <translation />
    </message>
    <message>
        <source>Contents</source>
        <translation />
    </message>
    <message>
        <source>Bookmarks</source>
        <translation />
    </message>
    <message>
        <source>Search</source>
        <translation />
    </message>
    <message>
        <source>Qt Assistant</source>
        <translation />
    </message>
    <message>
        <source>Page Set&amp;up...</source>
        <translation />
    </message>
    <message>
        <source>Print Preview...</source>
        <translation />
    </message>
    <message>
        <source>New &amp;Tab</source>
        <translation />
    </message>
    <message>
        <source>&amp;Close Tab</source>
        <translation />
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation />
    </message>
    <message>
        <source>CTRL+Q</source>
        <translation />
    </message>
    <message>
        <source>Find &amp;Next</source>
        <translation />
    </message>
    <message>
        <source>Find &amp;Previous</source>
        <translation />
    </message>
    <message>
        <source>Preferences...</source>
        <translation />
    </message>
    <message>
        <source>Normal &amp;Size</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+0</source>
        <translation />
    </message>
    <message>
        <source>ALT+C</source>
        <translation />
    </message>
    <message>
        <source>ALT+I</source>
        <translation />
    </message>
    <message>
        <source>ALT+S</source>
        <translation />
    </message>
    <message>
        <source>Sync with Table of Contents</source>
        <translation />
    </message>
    <message>
        <source>Sync</source>
        <translation />
    </message>
    <message>
        <source>Next Page</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+Alt+Right</source>
        <translation />
    </message>
    <message>
        <source>Previous Page</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+Alt+Left</source>
        <translation />
    </message>
    <message>
        <source>Unfiltered</source>
        <translation />
    </message>
    <message>
        <source>Could not register file '%1': %2</source>
        <translation />
    </message>
    <message>
        <source>About...</source>
        <translation />
    </message>
    <message>
        <source>Open Pages</source>
        <translation />
    </message>
    <message>
        <source>Bookmark Toolbar</source>
        <translation />
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation />
    </message>
    <message>
        <source>ALT+P</source>
        <translation />
    </message>
    <message>
        <source>Navigation Toolbar</source>
        <translation />
    </message>
    <message>
        <source>Toolbars</source>
        <translation />
    </message>
    <message>
        <source>Filter Toolbar</source>
        <translation />
    </message>
    <message>
        <source>Filtered by:</source>
        <translation />
    </message>
    <message>
        <source>Address Toolbar</source>
        <translation />
    </message>
    <message>
        <source>Address:</source>
        <translation />
    </message>
    <message>
        <source>Could not find the associated content item.</source>
        <translation />
    </message>
    <message>
        <source>&lt;center&gt;&lt;h3&gt;%1&lt;/h3&gt;&lt;p&gt;Version %2&lt;/p&gt;&lt;p&gt;Browser: %3&lt;/p&gt;&lt;/center&gt;&lt;p&gt;Copyright (C) The Qt Company Ltd. and other contributors.&lt;/p&gt;</source>
        <translation />
    </message>
    <message>
        <source>About %1</source>
        <translation />
    </message>
    <message>
        <source>Updating search index</source>
        <translation />
    </message>
    <message>
        <source>Looking for Qt Documentation...</source>
        <translation />
    </message>
    <message>
        <source>&amp;Window</source>
        <translation />
    </message>
    <message>
        <source>Minimize</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+M</source>
        <translation />
    </message>
    <message>
        <source>Zoom</source>
        <translation />
    </message>
    <message>
        <source>&amp;File</source>
        <translation />
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation />
    </message>
    <message>
        <source>&amp;View</source>
        <translation />
    </message>
    <message>
        <source>&amp;Go</source>
        <translation />
    </message>
    <message>
        <source>&amp;Bookmarks</source>
        <translation />
    </message>
    <message>
        <source>&amp;Help</source>
        <translation />
    </message>
    <message>
        <source>ALT+O</source>
        <translation />
    </message>
</context>
<context>
    <name>OpenPagesWidget</name>
    <message>
        <source>Close %1</source>
        <translation />
    </message>
    <message>
        <source>Close All Except %1</source>
        <translation />
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>Use custom settings</source>
        <translation />
    </message>
</context>
<context>
    <name>PreferencesDialogClass</name>
    <message>
        <source>Preferences</source>
        <translation />
    </message>
    <message>
        <source>Fonts</source>
        <translation />
    </message>
    <message>
        <source>Font settings:</source>
        <translation />
    </message>
    <message>
        <source>Browser</source>
        <translation />
    </message>
    <message>
        <source>Application</source>
        <translation />
    </message>
    <message>
        <source>Filters</source>
        <translation />
    </message>
    <message>
        <source>Documentation</source>
        <translation />
    </message>
    <message>
        <source>Options</source>
        <translation />
    </message>
    <message>
        <source>Current Page</source>
        <translation />
    </message>
    <message>
        <source>Restore to default</source>
        <translation />
    </message>
    <message>
        <source>Homepage</source>
        <translation />
    </message>
    <message>
        <source>On help start:</source>
        <translation />
    </message>
    <message>
        <source>Show my home page</source>
        <translation />
    </message>
    <message>
        <source>Show a blank page</source>
        <translation />
    </message>
    <message>
        <source>Show my tabs from last session</source>
        <translation />
    </message>
    <message>
        <source>Blank Page</source>
        <translation />
    </message>
    <message>
        <source>Appearance</source>
        <translation />
    </message>
    <message>
        <source>Show tabs for each individual page</source>
        <translation />
    </message>
</context>
<context>
    <name>RemoteControl</name>
    <message>
        <source>Debugging Remote Control</source>
        <translation />
    </message>
    <message>
        <source>Received Command: %1 %2</source>
        <translation />
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <source>&amp;Copy</source>
        <translation />
    </message>
    <message>
        <source>Copy &amp;Link Location</source>
        <translation />
    </message>
    <message>
        <source>Open Link in New Tab</source>
        <translation />
    </message>
    <message>
        <source>Select All</source>
        <translation />
    </message>
</context>
<context>
    <name>TabBar</name>
    <message>
        <source>(Untitled)</source>
        <translation />
    </message>
    <message>
        <source>New &amp;Tab</source>
        <translation />
    </message>
    <message>
        <source>&amp;Close Tab</source>
        <translation />
    </message>
    <message>
        <source>Close Other Tabs</source>
        <translation />
    </message>
    <message>
        <source>Add Bookmark for this Page...</source>
        <translation />
    </message>
</context>
<context>
    <name>TopicChooser</name>
    <message>
        <source>Filter</source>
        <translation />
    </message>
    <message>
        <source>Choose a topic for &lt;b&gt;%1&lt;/b&gt;:</source>
        <translation />
    </message>
    <message>
        <source>Choose Topic</source>
        <translation />
    </message>
    <message>
        <source>&amp;Topics</source>
        <translation />
    </message>
    <message>
        <source>&amp;Display</source>
        <translation />
    </message>
    <message>
        <source>&amp;Close</source>
        <translation />
    </message>
</context>
<context>
    <name>HelpViewerImpl</name>
    <message>
        <source>Open Link</source>
        <translation />
    </message>
    <message>
        <source>Open Link in New Tab	Ctrl+LMB</source>
        <translation />
    </message>
    <message>
        <source>Copy &amp;Link Location</source>
        <translation />
    </message>
    <message>
        <source>Copy</source>
        <translation />
    </message>
    <message>
        <source>Reload</source>
        <translation />
    </message>
    <message>
        <source>Open Link in New Page</source>
        <translation />
    </message>
</context>
</TS>