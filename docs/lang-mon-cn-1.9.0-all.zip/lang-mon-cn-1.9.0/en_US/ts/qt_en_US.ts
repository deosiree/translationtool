<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="en_US">
<context>
    <name>QWidget</name>
    <message>
        <source>*</source>
        <translation />
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <source>+</source>
        <translation />
    </message>
    <message>
        <source>CD</source>
        <translation />
    </message>
    <message>
        <source>Go</source>
        <translation />
    </message>
    <message>
        <source>No</source>
        <translation />
    </message>
    <message>
        <source>Up</source>
        <translation />
    </message>
    <message>
        <source>Alt</source>
        <translation />
    </message>
    <message>
        <source>F%1</source>
        <translation />
    </message>
    <message>
        <source>DOS</source>
        <translation />
    </message>
    <message>
        <source>Del</source>
        <translation />
    </message>
    <message>
        <source>Cut</source>
        <translation />
    </message>
    <message>
        <source>End</source>
        <translation />
    </message>
    <message>
        <source>Esc</source>
        <translation />
    </message>
    <message>
        <source>Ins</source>
        <translation />
    </message>
    <message>
        <source>Tab</source>
        <translation />
    </message>
    <message>
        <source>WWW</source>
        <translation />
    </message>
    <message>
        <source>Yes</source>
        <translation />
    </message>
    <message>
        <source>Back</source>
        <translation />
    </message>
    <message>
        <source>Away</source>
        <translation />
    </message>
    <message>
        <source>Book</source>
        <translation />
    </message>
    <message>
        <source>Call</source>
        <translation />
    </message>
    <message>
        <source>Copy</source>
        <translation />
    </message>
    <message>
        <source>Ctrl</source>
        <translation />
    </message>
    <message>
        <source>Down</source>
        <translation />
    </message>
    <message>
        <source>Flip</source>
        <translation />
    </message>
    <message>
        <source>Game</source>
        <translation />
    </message>
    <message>
        <source>Help</source>
        <translation />
    </message>
    <message>
        <source>Home</source>
        <translation />
    </message>
    <message>
        <source>Left</source>
        <translation />
    </message>
    <message>
        <source>Menu</source>
        <translation />
    </message>
    <message>
        <source>Meta</source>
        <translation />
    </message>
    <message>
        <source>News</source>
        <translation />
    </message>
    <message>
        <source>PgUp</source>
        <translation />
    </message>
    <message>
        <source>Save</source>
        <translation />
    </message>
    <message>
        <source>Send</source>
        <translation />
    </message>
    <message>
        <source>Shop</source>
        <translation />
    </message>
    <message>
        <source>Stop</source>
        <translation />
    </message>
    <message>
        <source>Time</source>
        <translation />
    </message>
    <message>
        <source>View</source>
        <translation />
    </message>
    <message>
        <source>Split Screen</source>
        <translation />
    </message>
    <message>
        <source>Clear</source>
        <translation />
    </message>
    <message>
        <source>Close</source>
        <translation />
    </message>
    <message>
        <source>Eject</source>
        <translation />
    </message>
    <message>
        <source>Enter</source>
        <translation />
    </message>
    <message>
        <source>Kanji</source>
        <translation />
    </message>
    <message>
        <source>Music</source>
        <translation />
    </message>
    <message>
        <source>Paste</source>
        <translation />
    </message>
    <message>
        <source>Pause</source>
        <translation />
    </message>
    <message>
        <source>Phone</source>
        <translation />
    </message>
    <message>
        <source>Print</source>
        <translation />
    </message>
    <message>
        <source>Reply</source>
        <translation />
    </message>
    <message>
        <source>Right</source>
        <translation />
    </message>
    <message>
        <source>Shift</source>
        <translation />
    </message>
    <message>
        <source>Sleep</source>
        <translation />
    </message>
    <message>
        <source>Space</source>
        <translation />
    </message>
    <message>
        <source>Tools</source>
        <translation />
    </message>
    <message>
        <source>Video</source>
        <translation />
    </message>
    <message>
        <source>Hiragana</source>
        <translation />
    </message>
    <message>
        <source>Wireless</source>
        <translation />
    </message>
    <message>
        <source>Media Record</source>
        <translation />
    </message>
    <message>
        <source>Print Screen</source>
        <translation />
    </message>
    <message>
        <source>Audio Rewind</source>
        <translation />
    </message>
    <message>
        <source>Audio Repeat</source>
        <translation />
    </message>
    <message>
        <source>Toggle Call/Hangup</source>
        <translation />
    </message>
    <message>
        <source>Zoom In</source>
        <translation />
    </message>
    <message>
        <source>Treble Down</source>
        <translation />
    </message>
    <message>
        <source>Scroll Lock</source>
        <translation />
    </message>
    <message>
        <source>Media Pause</source>
        <translation />
    </message>
    <message>
        <source>Word Processor</source>
        <translation />
    </message>
    <message>
        <source>Volume Down</source>
        <translation />
    </message>
    <message>
        <source>Volume Mute</source>
        <translation />
    </message>
    <message>
        <source>Media Previous</source>
        <translation />
    </message>
    <message>
        <source>Home Page</source>
        <translation />
    </message>
    <message>
        <source>Meeting</source>
        <translation />
    </message>
    <message>
        <source>Volume Up</source>
        <translation />
    </message>
    <message>
        <source>Keyboard Brightness Up</source>
        <translation />
    </message>
    <message>
        <source>Community</source>
        <translation />
    </message>
    <message>
        <source>Launch (6)</source>
        <translation />
    </message>
    <message>
        <source>Launch (7)</source>
        <translation />
    </message>
    <message>
        <source>Launch (8)</source>
        <translation />
    </message>
    <message>
        <source>Launch (9)</source>
        <translation />
    </message>
    <message>
        <source>Launch (2)</source>
        <translation />
    </message>
    <message>
        <source>Launch (3)</source>
        <translation />
    </message>
    <message>
        <source>Launch (4)</source>
        <translation />
    </message>
    <message>
        <source>Launch (5)</source>
        <translation />
    </message>
    <message>
        <source>Launch (0)</source>
        <translation />
    </message>
    <message>
        <source>Launch (1)</source>
        <translation />
    </message>
    <message>
        <source>Launch (F)</source>
        <translation />
    </message>
    <message>
        <source>Launch (B)</source>
        <translation />
    </message>
    <message>
        <source>Launch (C)</source>
        <translation />
    </message>
    <message>
        <source>Launch (D)</source>
        <translation />
    </message>
    <message>
        <source>Launch (E)</source>
        <translation />
    </message>
    <message>
        <source>Launch (A)</source>
        <translation />
    </message>
    <message>
        <source>Delete</source>
        <translation />
    </message>
    <message>
        <source>Escape</source>
        <translation />
    </message>
    <message>
        <source>Audio Random Play</source>
        <translation />
    </message>
    <message>
        <source>Hangup</source>
        <translation />
    </message>
    <message>
        <source>Insert</source>
        <translation />
    </message>
    <message>
        <source>Home Office</source>
        <translation />
    </message>
    <message>
        <source>Last Number Redial</source>
        <translation />
    </message>
    <message>
        <source>Logoff</source>
        <translation />
    </message>
    <message>
        <source>Market</source>
        <translation />
    </message>
    <message>
        <source>Bass Boost</source>
        <translation />
    </message>
    <message>
        <source>Option</source>
        <translation />
    </message>
    <message>
        <source>PgDown</source>
        <translation />
    </message>
    <message>
        <source>Reload</source>
        <translation />
    </message>
    <message>
        <source>Return</source>
        <translation />
    </message>
    <message>
        <source>Search</source>
        <translation />
    </message>
    <message>
        <source>Select</source>
        <translation />
    </message>
    <message>
        <source>SysReq</source>
        <translation />
    </message>
    <message>
        <source>Travel</source>
        <translation />
    </message>
    <message>
        <source>NumLock</source>
        <translation />
    </message>
    <message>
        <source>Audio Forward</source>
        <translation />
    </message>
    <message>
        <source>WebCam</source>
        <translation />
    </message>
    <message>
        <source>Top Menu</source>
        <translation />
    </message>
    <message>
        <source>ScrollLock</source>
        <translation />
    </message>
    <message>
        <source>Hot Links</source>
        <translation />
    </message>
    <message>
        <source>Context1</source>
        <translation />
    </message>
    <message>
        <source>Context2</source>
        <translation />
    </message>
    <message>
        <source>Context3</source>
        <translation />
    </message>
    <message>
        <source>Context4</source>
        <translation />
    </message>
    <message>
        <source>Zoom Out</source>
        <translation />
    </message>
    <message>
        <source>Page Up</source>
        <translation />
    </message>
    <message>
        <source>Open URL</source>
        <translation />
    </message>
    <message>
        <source>iTouch</source>
        <translation />
    </message>
    <message>
        <source>Toggle Media Play/Pause</source>
        <translation />
    </message>
    <message>
        <source>Caps Lock</source>
        <translation />
    </message>
    <message>
        <source>Code input</source>
        <translation />
    </message>
    <message>
        <source>Camera Focus</source>
        <translation />
    </message>
    <message>
        <source>Adjust Brightness</source>
        <translation />
    </message>
    <message>
        <source>Spreadsheet</source>
        <translation />
    </message>
    <message>
        <source>Keyboard Brightness Down</source>
        <translation />
    </message>
    <message>
        <source>Monitor Brightness Up</source>
        <translation />
    </message>
    <message>
        <source>System Request</source>
        <translation />
    </message>
    <message>
        <source>CapsLock</source>
        <translation />
    </message>
    <message>
        <source>Backtab</source>
        <translation />
    </message>
    <message>
        <source>Bass Up</source>
        <translation />
    </message>
    <message>
        <source>Battery</source>
        <translation />
    </message>
    <message>
        <source>Katakana</source>
        <translation />
    </message>
    <message>
        <source>Refresh</source>
        <translation />
    </message>
    <message>
        <source>Hibernate</source>
        <translation />
    </message>
    <message>
        <source>Application Left</source>
        <translation />
    </message>
    <message>
        <source>Voice Dial</source>
        <translation />
    </message>
    <message>
        <source>Browser</source>
        <translation />
    </message>
    <message>
        <source>Keyboard Menu</source>
        <translation />
    </message>
    <message>
        <source>Back Forward</source>
        <translation />
    </message>
    <message>
        <source>Launch Mail</source>
        <translation />
    </message>
    <message>
        <source>Keyboard Light On/Off</source>
        <translation />
    </message>
    <message>
        <source>Backspace</source>
        <translation />
    </message>
    <message>
        <source>Bass Down</source>
        <translation />
    </message>
    <message>
        <source>Mail Forward</source>
        <translation />
    </message>
    <message>
        <source>Messenger</source>
        <translation />
    </message>
    <message>
        <source>Standby</source>
        <translation />
    </message>
    <message>
        <source>Documents</source>
        <translation />
    </message>
    <message>
        <source>Calculator</source>
        <translation />
    </message>
    <message>
        <source>Support</source>
        <translation />
    </message>
    <message>
        <source>Suspend</source>
        <translation />
    </message>
    <message>
        <source>Display</source>
        <translation />
    </message>
    <message>
        <source>My Sites</source>
        <translation />
    </message>
    <message>
        <source>Rotate Windows</source>
        <translation />
    </message>
    <message>
        <source>Treble Up</source>
        <translation />
    </message>
    <message>
        <source>Subtitle</source>
        <translation />
    </message>
    <message>
        <source>Hangul Jamo</source>
        <translation />
    </message>
    <message>
        <source>Bluetooth</source>
        <translation />
    </message>
    <message>
        <source>Num Lock</source>
        <translation />
    </message>
    <message>
        <source>Screensaver</source>
        <translation />
    </message>
    <message>
        <source>Spellchecker</source>
        <translation />
    </message>
    <message>
        <source>Terminal</source>
        <translation />
    </message>
    <message>
        <source>Add Favorite</source>
        <translation />
    </message>
    <message>
        <source>Finance</source>
        <translation />
    </message>
    <message>
        <source>Task Panel</source>
        <translation />
    </message>
    <message>
        <source>Favorites</source>
        <translation />
    </message>
    <message>
        <source>Forward</source>
        <translation />
    </message>
    <message>
        <source>Page Down</source>
        <translation />
    </message>
    <message>
        <source>Wake Up</source>
        <translation />
    </message>
    <message>
        <source>Power Off</source>
        <translation />
    </message>
    <message>
        <source>LightBulb</source>
        <translation />
    </message>
    <message>
        <source>Monitor Brightness Down</source>
        <translation />
    </message>
    <message>
        <source>History</source>
        <translation />
    </message>
    <message>
        <source>Media Play</source>
        <translation />
    </message>
    <message>
        <source>Media Stop</source>
        <translation />
    </message>
    <message>
        <source>Media Next</source>
        <translation />
    </message>
    <message>
        <source>Launch Media</source>
        <translation />
    </message>
    <message>
        <source>Application Right</source>
        <translation />
    </message>
    <message>
        <source>Pictures</source>
        <translation />
    </message>
</context>
<context>
    <name>QPrintDialog</name>
    <message>
        <source>A0</source>
        <translation />
    </message>
    <message>
        <source>A1</source>
        <translation />
    </message>
    <message>
        <source>A2</source>
        <translation />
    </message>
    <message>
        <source>A3</source>
        <translation />
    </message>
    <message>
        <source>A4</source>
        <translation />
    </message>
    <message>
        <source>A5</source>
        <translation />
    </message>
    <message>
        <source>A6</source>
        <translation />
    </message>
    <message>
        <source>A7</source>
        <translation />
    </message>
    <message>
        <source>A8</source>
        <translation />
    </message>
    <message>
        <source>A9</source>
        <translation />
    </message>
    <message>
        <source>B0</source>
        <translation />
    </message>
    <message>
        <source>B1</source>
        <translation />
    </message>
    <message>
        <source>B2</source>
        <translation />
    </message>
    <message>
        <source>B3</source>
        <translation />
    </message>
    <message>
        <source>B4</source>
        <translation />
    </message>
    <message>
        <source>B5</source>
        <translation />
    </message>
    <message>
        <source>B6</source>
        <translation />
    </message>
    <message>
        <source>B7</source>
        <translation />
    </message>
    <message>
        <source>B8</source>
        <translation />
    </message>
    <message>
        <source>B9</source>
        <translation />
    </message>
    <message>
        <source>OK</source>
        <translation />
    </message>
    <message>
        <source>B10</source>
        <translation />
    </message>
    <message>
        <source>C5E</source>
        <translation />
    </message>
    <message>
        <source>DLE</source>
        <translation />
    </message>
    <message>
        <source>A6 (105 x 148 mm)</source>
        <translation />
    </message>
    <message>
        <source>Legal (8.5 x 14 inches, 216 x 356 mm)</source>
        <translation />
    </message>
    <message>
        <source>Folio</source>
        <translation />
    </message>
    <message>
        <source>Legal</source>
        <translation />
    </message>
    <message>
        <source>Print all</source>
        <translation />
    </message>
    <message>
        <source>Print</source>
        <translation />
    </message>
    <message>
        <source>&amp;Options &lt;&lt;</source>
        <translation />
    </message>
    <message>
        <source>&amp;Options &gt;&gt;</source>
        <translation />
    </message>
    <message>
        <source>B6 (125 x 176 mm)</source>
        <translation />
    </message>
    <message>
        <source>B8 (62 x 88 mm)</source>
        <translation />
    </message>
    <message>
        <source>A8 (52 x 74 mm)</source>
        <translation />
    </message>
    <message>
        <source>B9 (44 x 62 mm)</source>
        <translation />
    </message>
    <message>
        <source>A9 (37 x 52 mm)</source>
        <translation />
    </message>
    <message>
        <source>B0 (1000 x 1414 mm)</source>
        <translation />
    </message>
    <message>
        <source>A5 (148 x 210 mm)</source>
        <translation />
    </message>
    <message>
        <source>Tabloid (279 x 432 mm)</source>
        <translation />
    </message>
    <message>
        <source>B10 (31 x 44 mm)</source>
        <translation />
    </message>
    <message>
        <source>B2 (500 x 707 mm)</source>
        <translation />
    </message>
    <message>
        <source>&amp;Print</source>
        <translation />
    </message>
    <message>
        <source>A3 (297 x 420 mm)</source>
        <translation />
    </message>
    <message>
        <source>Print selection</source>
        <translation />
    </message>
    <message>
        <source>Print to File (Postscript)</source>
        <translation />
    </message>
    <message>
        <source>B4 (250 x 353 mm)</source>
        <translation />
    </message>
    <message>
        <source>%1 already exists.
Do you want to overwrite it?</source>
        <translation />
    </message>
    <message>
        <source>A1 (594 x 841 mm)</source>
        <translation />
    </message>
    <message>
        <source>Custom</source>
        <translation />
    </message>
    <message>
        <source>B1 (707 x 1000 mm)</source>
        <translation />
    </message>
    <message>
        <source>Folio (210 x 330 mm)</source>
        <translation />
    </message>
    <message>
        <source>Ledger</source>
        <translation />
    </message>
    <message>
        <source>Letter</source>
        <translation />
    </message>
    <message>
        <source>DLE (110 x 220 mm)</source>
        <translation />
    </message>
    <message>
        <source>C5E (163 x 229 mm)</source>
        <translation />
    </message>
    <message>
        <source>B5 (176 x 250 mm, 6.93 x 9.84 inches)</source>
        <translation />
    </message>
    <message>
        <source>Print range</source>
        <translation />
    </message>
    <message>
        <source>File exists</source>
        <translation />
    </message>
    <message>
        <source>Write %1 file</source>
        <translation />
    </message>
    <message>
        <source>Print current page</source>
        <translation />
    </message>
    <message>
        <source>A0 (841 x 1189 mm)</source>
        <translation />
    </message>
    <message>
        <source>Local file</source>
        <translation />
    </message>
    <message>
        <source>locally connected</source>
        <translation />
    </message>
    <message>
        <source>Ledger (432 x 279 mm)</source>
        <translation />
    </message>
    <message>
        <source>Aliases: %1</source>
        <translation />
    </message>
    <message>
        <source>Print to File (PDF)</source>
        <translation />
    </message>
    <message>
        <source>Print To File ...</source>
        <translation />
    </message>
    <message>
        <source>US Common #10 Envelope (105 x 241 mm)</source>
        <translation />
    </message>
    <message>
        <source>Tabloid</source>
        <translation />
    </message>
    <message>
        <source>A4 (210 x 297 mm, 8.26 x 11.7 inches)</source>
        <translation />
    </message>
    <message>
        <source>Executive</source>
        <translation />
    </message>
    <message>
        <source>unknown</source>
        <translation />
    </message>
    <message>
        <source>&lt;qt&gt;Do you want to overwrite it?&lt;/qt&gt;</source>
        <translation />
    </message>
    <message>
        <source>Executive (7.5 x 10 inches, 191 x 254 mm)</source>
        <translation />
    </message>
    <message>
        <source>Letter (8.5 x 11 inches, 216 x 279 mm)</source>
        <translation />
    </message>
    <message>
        <source>The 'From' value cannot be greater than the 'To' value.</source>
        <translation />
    </message>
    <message>
        <source>US Common #10 Envelope</source>
        <translation />
    </message>
    <message>
        <source>%1 is a directory.
Please choose a different file name.</source>
        <translation />
    </message>
    <message>
        <source>File %1 is not writable.
Please choose a different file name.</source>
        <translation />
    </message>
    <message>
        <source>B3 (353 x 500 mm)</source>
        <translation />
    </message>
    <message>
        <source>A7 (74 x 105 mm)</source>
        <translation />
    </message>
    <message>
        <source>A2 (420 x 594 mm)</source>
        <translation />
    </message>
    <message>
        <source>B7 (88 x 125 mm)</source>
        <translation />
    </message>
</context>
<context>
    <name>QDateTimeEdit</name>
    <message>
        <source>AM</source>
        <translation />
    </message>
    <message>
        <source>PM</source>
        <translation />
    </message>
    <message>
        <source>am</source>
        <translation />
    </message>
    <message>
        <source>pm</source>
        <translation />
    </message>
</context>
<context>
    <name>QScriptDebugger</name>
    <message>
        <source>F3</source>
        <translation />
    </message>
    <message>
        <source>F5</source>
        <translation />
    </message>
    <message>
        <source>F9</source>
        <translation />
    </message>
    <message>
        <source>F10</source>
        <translation />
    </message>
    <message>
        <source>F11</source>
        <translation />
    </message>
    <message>
        <source>Debug</source>
        <translation />
    </message>
    <message>
        <source>Line:</source>
        <translation />
    </message>
    <message>
        <source>Clear Console</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+F</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+G</source>
        <translation />
    </message>
    <message>
        <source>Clear Error Log</source>
        <translation />
    </message>
    <message>
        <source>Clear Debug Output</source>
        <translation />
    </message>
    <message>
        <source>Toggle Breakpoint</source>
        <translation />
    </message>
    <message>
        <source>Find &amp;Next</source>
        <translation />
    </message>
    <message>
        <source>Continue</source>
        <translation />
    </message>
    <message>
        <source>Find &amp;Previous</source>
        <translation />
    </message>
    <message>
        <source>Step Out</source>
        <translation />
    </message>
    <message>
        <source>Interrupt</source>
        <translation />
    </message>
    <message>
        <source>Go to Line</source>
        <translation />
    </message>
    <message>
        <source>Ctrl+F10</source>
        <translation />
    </message>
    <message>
        <source>Step Into</source>
        <translation />
    </message>
    <message>
        <source>Step Over</source>
        <translation />
    </message>
    <message>
        <source>&amp;Find in Script...</source>
        <translation />
    </message>
    <message>
        <source>Run to Cursor</source>
        <translation />
    </message>
    <message>
        <source>Run to New Script</source>
        <translation />
    </message>
    <message>
        <source>Shift+F3</source>
        <translation />
    </message>
    <message>
        <source>Shift+F5</source>
        <translation />
    </message>
    <message>
        <source>Shift+F11</source>
        <translation />
    </message>
</context>
<context>
    <name>QScriptBreakpointsModel</name>
    <message>
        <source>ID</source>
        <translation />
    </message>
    <message>
        <source>Single-shot</source>
        <translation />
    </message>
    <message>
        <source>Condition</source>
        <translation />
    </message>
    <message>
        <source>Ignore-count</source>
        <translation />
    </message>
    <message>
        <source>Location</source>
        <translation />
    </message>
    <message>
        <source>Hit-count</source>
        <translation />
    </message>
</context>
<context>
    <name>Q3TabDialog</name>
    <message>
        <source>OK</source>
        <translation />
    </message>
    <message>
        <source>Help</source>
        <translation />
    </message>
    <message>
        <source>Apply</source>
        <translation />
    </message>
    <message>
        <source>Cancel</source>
        <translation />
    </message>
    <message>
        <source>Defaults</source>
        <translation />
    </message>
</context>
<context>
    <name>QAxSelect</name>
    <message>
        <source>OK</source>
        <translation />
    </message>
    <message>
        <source>COM &amp;Object:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation />
    </message>
    <message>
        <source>Select ActiveX Control</source>
        <translation />
    </message>
</context>
<context>
    <name>QDialogButtonBox</name>
    <message>
        <source>OK</source>
        <translation />
    </message>
    <message>
        <source>&amp;OK</source>
        <translation />
    </message>
    <message>
        <source>&amp;No</source>
        <translation />
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation />
    </message>
    <message>
        <source>Help</source>
        <translation />
    </message>
    <message>
        <source>Open</source>
        <translation />
    </message>
    <message>
        <source>Save</source>
        <translation />
    </message>
    <message>
        <source>&amp;Save</source>
        <translation />
    </message>
    <message>
        <source>Abort</source>
        <translation />
    </message>
    <message>
        <source>Apply</source>
        <translation />
    </message>
    <message>
        <source>Close</source>
        <translation />
    </message>
    <message>
        <source>Reset</source>
        <translation />
    </message>
    <message>
        <source>Retry</source>
        <translation />
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation />
    </message>
    <message>
        <source>&amp;Close</source>
        <translation />
    </message>
    <message>
        <source>Cancel</source>
        <translation />
    </message>
    <message>
        <source>Ignore</source>
        <translation />
    </message>
    <message>
        <source>Close without Saving</source>
        <translation />
    </message>
    <message>
        <source>N&amp;o to All</source>
        <translation />
    </message>
    <message>
        <source>Save All</source>
        <translation />
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation />
    </message>
    <message>
        <source>Discard</source>
        <translation />
    </message>
    <message>
        <source>Yes to &amp;All</source>
        <translation />
    </message>
    <message>
        <source>Don't Save</source>
        <translation />
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>OK</source>
        <translation />
    </message>
    <message>
        <source>Help</source>
        <translation />
    </message>
    <message>
        <source>Show Details...</source>
        <translation />
    </message>
    <message>
        <source>About Qt</source>
        <translation />
    </message>
    <message>
        <source>&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across MS&amp;nbsp;Windows, Mac&amp;nbsp;OS&amp;nbsp;X, Linux, and all major commercial Unix variants. Qt is also available for embedded devices as Qt for Embedded Linux and Qt for Windows CE.&lt;/p&gt;&lt;p&gt;Qt is available under three different licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of the GNU LGPL version 2.1 or GNU GPL version 3.0.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU LGPL version 2.1 is appropriate for the development of Qt applications (proprietary or open source) provided you can comply with the terms and conditions of the GNU LGPL version 2.1.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU General Public License version 3.0 is appropriate for the development of Qt applications where you wish to use such applications in combination with software subject to the terms of the GNU GPL version 3.0 or where you are otherwise willing to comply with the terms of the GNU GPL version 3.0.&lt;/p&gt;&lt;p&gt;Please see &lt;a href="http://qt.nokia.com/products/licensing"&gt;qt.nokia.com/products/licensing&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) 2012 Nokia Corporation and/or its subsidiary(-ies).&lt;/p&gt;&lt;p&gt;Qt is a Nokia product. See &lt;a href="http://qt.nokia.com/"&gt;qt.nokia.com&lt;/a&gt; for more information.&lt;/p&gt;</source>
        <translation />
    </message>
    <message>
        <source>Hide Details...</source>
        <translation />
    </message>
    <message>
        <source>&lt;h3&gt;About Qt&lt;/h3&gt;&lt;p&gt;This program uses Qt version %1.&lt;/p&gt;</source>
        <translation />
    </message>
</context>
<context>
    <name>QSql</name>
    <message>
        <source>No</source>
        <translation />
    </message>
    <message>
        <source>Yes</source>
        <translation />
    </message>
    <message>
        <source>Cancel</source>
        <translation />
    </message>
    <message>
        <source>Delete</source>
        <translation />
    </message>
    <message>
        <source>Insert</source>
        <translation />
    </message>
    <message>
        <source>Update</source>
        <translation />
    </message>
    <message>
        <source>Delete this record?</source>
        <translation />
    </message>
    <message>
        <source>Save edits?</source>
        <translation />
    </message>
    <message>
        <source>Confirm</source>
        <translation />
    </message>
    <message>
        <source>Cancel your edits?</source>
        <translation />
    </message>
</context>
<context>
    <name>QSoftKeyManager</name>
    <message>
        <source>Ok</source>
        <translation />
    </message>
    <message>
        <source>Done</source>
        <translation />
    </message>
    <message>
        <source>Exit</source>
        <translation />
    </message>
    <message>
        <source>Cancel</source>
        <translation />
    </message>
    <message>
        <source>Select</source>
        <translation />
    </message>
    <message>
        <source>Options</source>
        <translation />
    </message>
</context>
<context>
    <name>QPrintSettingsOutput</name>
    <message>
        <source>to</source>
        <translation />
    </message>
    <message>
        <source>Form</source>
        <translation />
    </message>
    <message>
        <source>None</source>
        <translation />
    </message>
    <message>
        <source>Color</source>
        <translation />
    </message>
    <message>
        <source>Print all</source>
        <translation />
    </message>
    <message>
        <source>Current Page</source>
        <translation />
    </message>
    <message>
        <source>Selection</source>
        <translation />
    </message>
    <message>
        <source>Long side</source>
        <translation />
    </message>
    <message>
        <source>Copies</source>
        <translation />
    </message>
    <message>
        <source>Print range</source>
        <translation />
    </message>
    <message>
        <source>Color Mode</source>
        <translation />
    </message>
    <message>
        <source>Options</source>
        <translation />
    </message>
    <message>
        <source>Output Settings</source>
        <translation />
    </message>
    <message>
        <source>Reverse</source>
        <translation />
    </message>
    <message>
        <source>Grayscale</source>
        <translation />
    </message>
    <message>
        <source>Short side</source>
        <translation />
    </message>
    <message>
        <source>Collate</source>
        <translation />
    </message>
    <message>
        <source>Copies:</source>
        <translation />
    </message>
    <message>
        <source>Pages from</source>
        <translation />
    </message>
    <message>
        <source>Duplex Printing</source>
        <translation />
    </message>
</context>
<context>
    <name>QPrintPreviewDialog</name>
    <message>
        <source>%1%</source>
        <translation />
    </message>
    <message>
        <source>Print Preview</source>
        <translation />
    </message>
    <message>
        <source>Close</source>
        <translation />
    </message>
    <message>
        <source>Print</source>
        <translation />
    </message>
    <message>
        <source>Fit page</source>
        <translation />
    </message>
    <message>
        <source>Zoom in</source>
        <translation />
    </message>
    <message>
        <source>Landscape</source>
        <translation />
    </message>
    <message>
        <source>Zoom out</source>
        <translation />
    </message>
    <message>
        <source>Fit width</source>
        <translation />
    </message>
    <message>
        <source>Portrait</source>
        <translation />
    </message>
    <message>
        <source>Page Setup</source>
        <translation />
    </message>
    <message>
        <source>Page setup</source>
        <translation />
    </message>
    <message>
        <source>Show overview of all pages</source>
        <translation />
    </message>
    <message>
        <source>First page</source>
        <translation />
    </message>
    <message>
        <source>Last page</source>
        <translation />
    </message>
    <message>
        <source>Show single page</source>
        <translation />
    </message>
    <message>
        <source>Export to PDF</source>
        <translation />
    </message>
    <message>
        <source>Previous page</source>
        <translation />
    </message>
    <message>
        <source>Next page</source>
        <translation />
    </message>
    <message>
        <source>Show facing pages</source>
        <translation />
    </message>
    <message>
        <source>Export to PostScript</source>
        <translation />
    </message>
</context>
<context>
    <name>Q3FileDialog</name>
    <message>
        <source>&amp;OK</source>
        <translation />
    </message>
    <message>
        <source>&amp;No</source>
        <translation />
    </message>
    <message>
        <source>Dir</source>
        <translation />
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation />
    </message>
    <message>
        <source>Back</source>
        <translation />
    </message>
    <message>
        <source>Date</source>
        <translation />
    </message>
    <message>
        <source>File</source>
        <translation />
    </message>
    <message>
        <source>Name</source>
        <translation />
    </message>
    <message>
        <source>Open</source>
        <translation />
    </message>
    <message>
        <source>Size</source>
        <translation />
    </message>
    <message>
        <source>Sort</source>
        <translation />
    </message>
    <message>
        <source>Type</source>
        <translation />
    </message>
    <message>
        <source>&amp;Open</source>
        <translation />
    </message>
    <message>
        <source>&amp;Save</source>
        <translation />
    </message>
    <message>
        <source>Error</source>
        <translation />
    </message>
    <message>
        <source>Open </source>
        <translation />
    </message>
    <message>
        <source>Write: %1</source>
        <translation />
    </message>
    <message>
        <source>Sort by &amp;Size</source>
        <translation />
    </message>
    <message>
        <source>Sort by &amp;Date</source>
        <translation />
    </message>
    <message>
        <source>Sort by &amp;Name</source>
        <translation />
    </message>
    <message>
        <source>New Folder 1</source>
        <translation />
    </message>
    <message>
        <source>the directory</source>
        <translation />
    </message>
    <message>
        <source>File &amp;type:</source>
        <translation />
    </message>
    <message>
        <source>File &amp;name:</source>
        <translation />
    </message>
    <message>
        <source>Delete %1</source>
        <translation />
    </message>
    <message>
        <source>Cancel</source>
        <translation />
    </message>
    <message>
        <source>R&amp;eload</source>
        <translation />
    </message>
    <message>
        <source>New Folder</source>
        <translation />
    </message>
    <message>
        <source>&amp;Unsorted</source>
        <translation />
    </message>
    <message>
        <source>Look &amp;in:</source>
        <translation />
    </message>
    <message>
        <source>Preview File Contents</source>
        <translation />
    </message>
    <message>
        <source>New Folder %1</source>
        <translation />
    </message>
    <message>
        <source>Read-write</source>
        <translation />
    </message>
    <message>
        <source>Read-only</source>
        <translation />
    </message>
    <message>
        <source>Copy or Move a File</source>
        <translation />
    </message>
    <message>
        <source>&lt;qt&gt;Are you sure you wish to delete %1 "%2"?&lt;/qt&gt;</source>
        <translation />
    </message>
    <message>
        <source>Find Directory</source>
        <translation />
    </message>
    <message>
        <source>Attributes</source>
        <translation />
    </message>
    <message>
        <source>Show &amp;hidden files</source>
        <translation />
    </message>
    <message>
        <source>Save As</source>
        <translation />
    </message>
    <message>
        <source>Inaccessible</source>
        <translation />
    </message>
    <message>
        <source>%1
File not found.
Check path and filename.</source>
        <translation />
    </message>
    <message>
        <source>List View</source>
        <translation />
    </message>
    <message>
        <source>Special</source>
        <translation />
    </message>
    <message>
        <source>Write-only</source>
        <translation />
    </message>
    <message>
        <source>the symlink</source>
        <translation />
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation />
    </message>
    <message>
        <source>All Files (*)</source>
        <translation />
    </message>
    <message>
        <source>Directories</source>
        <translation />
    </message>
    <message>
        <source>Symlink to Special</source>
        <translation />
    </message>
    <message>
        <source>Select a Directory</source>
        <translation />
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation />
    </message>
    <message>
        <source>Read: %1</source>
        <translation />
    </message>
    <message>
        <source>&amp;Rename</source>
        <translation />
    </message>
    <message>
        <source>Directory:</source>
        <translation />
    </message>
    <message>
        <source>One directory up</source>
        <translation />
    </message>
    <message>
        <source>Preview File Info</source>
        <translation />
    </message>
    <message>
        <source>the file</source>
        <translation />
    </message>
    <message>
        <source>Create New Folder</source>
        <translation />
    </message>
    <message>
        <source>Symlink to File</source>
        <translation />
    </message>
    <message>
        <source>Symlink to Directory</source>
        <translation />
    </message>
    <message>
        <source>Detail View</source>
        <translation />
    </message>
</context>
<context>
    <name>QErrorMessage</name>
    <message>
        <source>&amp;OK</source>
        <translation />
    </message>
    <message>
        <source>Fatal Error:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Show this message again</source>
        <translation />
    </message>
    <message>
        <source>Debug Message:</source>
        <translation />
    </message>
    <message>
        <source>Warning:</source>
        <translation />
    </message>
</context>
<context>
    <name>QPrintWidget</name>
    <message>
        <source>...</source>
        <translation />
    </message>
    <message>
        <source>Form</source>
        <translation />
    </message>
    <message>
        <source>Type:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Name:</source>
        <translation />
    </message>
    <message>
        <source>Output &amp;file:</source>
        <translation />
    </message>
    <message>
        <source>P&amp;roperties</source>
        <translation />
    </message>
    <message>
        <source>Preview</source>
        <translation />
    </message>
    <message>
        <source>Printer</source>
        <translation />
    </message>
    <message>
        <source>Location:</source>
        <translation />
    </message>
</context>
<context>
    <name>QFontDatabase</name>
    <message>
        <source>Any</source>
        <translation />
    </message>
    <message>
        <source>Lao</source>
        <translation />
    </message>
    <message>
        <source>Bold</source>
        <translation />
    </message>
    <message>
        <source>N'Ko</source>
        <translation />
    </message>
    <message>
        <source>Thai</source>
        <translation />
    </message>
    <message>
        <source>Black</source>
        <translation />
    </message>
    <message>
        <source>Greek</source>
        <translation />
    </message>
    <message>
        <source>Khmer</source>
        <translation />
    </message>
    <message>
        <source>Latin</source>
        <translation />
    </message>
    <message>
        <source>Light</source>
        <translation />
    </message>
    <message>
        <source>Ogham</source>
        <translation />
    </message>
    <message>
        <source>Oriya</source>
        <translation />
    </message>
    <message>
        <source>Runic</source>
        <translation />
    </message>
    <message>
        <source>Tamil</source>
        <translation />
    </message>
    <message>
        <source>Cyrillic</source>
        <translation />
    </message>
    <message>
        <source>Kannada</source>
        <translation />
    </message>
    <message>
        <source>Malayalam</source>
        <translation />
    </message>
    <message>
        <source>Simplified Chinese</source>
        <translation />
    </message>
    <message>
        <source>Arabic</source>
        <translation />
    </message>
    <message>
        <source>Hebrew</source>
        <translation />
    </message>
    <message>
        <source>Myanmar</source>
        <translation />
    </message>
    <message>
        <source>Italic</source>
        <translation />
    </message>
    <message>
        <source>Korean</source>
        <translation />
    </message>
    <message>
        <source>Normal</source>
        <translation />
    </message>
    <message>
        <source>Oblique</source>
        <translation />
    </message>
    <message>
        <source>Telugu</source>
        <translation />
    </message>
    <message>
        <source>Thaana</source>
        <translation />
    </message>
    <message>
        <source>Symbol</source>
        <translation />
    </message>
    <message>
        <source>Syriac</source>
        <translation />
    </message>
    <message>
        <source>Devanagari</source>
        <translation />
    </message>
    <message>
        <source>Japanese</source>
        <translation />
    </message>
    <message>
        <source>Bengali</source>
        <translation />
    </message>
    <message>
        <source>Armenian</source>
        <translation />
    </message>
    <message>
        <source>Sinhala</source>
        <translation />
    </message>
    <message>
        <source>Tibetan</source>
        <translation />
    </message>
    <message>
        <source>Vietnamese</source>
        <translation />
    </message>
    <message>
        <source>Gujarati</source>
        <translation />
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation />
    </message>
    <message>
        <source>Georgian</source>
        <translation />
    </message>
    <message>
        <source>Gurmukhi</source>
        <translation />
    </message>
</context>
<context>
    <name>QInputContext</name>
    <message>
        <source>FEP</source>
        <translation />
    </message>
    <message>
        <source>XIM</source>
        <translation />
    </message>
    <message>
        <source>Windows input method</source>
        <translation />
    </message>
    <message>
        <source>XIM input method</source>
        <translation />
    </message>
    <message>
        <source>Mac OS X input method</source>
        <translation />
    </message>
    <message>
        <source>S60 FEP input method</source>
        <translation />
    </message>
</context>
<context>
    <name>QWebPage</name>
    <message>
        <source>Cut</source>
        <translation />
    </message>
    <message>
        <source>Top</source>
        <translation />
    </message>
    <message>
        <source>Bold</source>
        <translation />
    </message>
    <message>
        <source>Copy</source>
        <translation />
    </message>
    <message>
        <source>Stop</source>
        <translation />
    </message>
    <message>
        <source>Align Right</source>
        <translation />
    </message>
    <message>
        <source>Insert a new paragraph</source>
        <translation />
    </message>
    <message>
        <source>Strikethrough</source>
        <translation />
    </message>
    <message>
        <source>Open Frame</source>
        <translation />
    </message>
    <message>
        <source>Open Image</source>
        <translation />
    </message>
    <message>
        <source>Fonts</source>
        <translation />
    </message>
    <message>
        <source>Movie time scrubber thumb</source>
        <translation />
    </message>
    <message>
        <source>Paste</source>
        <translation />
    </message>
    <message>
        <source>Reset</source>
        <translation />
    </message>
    <message>
        <source>Inspect</source>
        <translation />
    </message>
    <message>
        <source>Select to the start of the block</source>
        <translation />
    </message>
    <message>
        <source>Indefinite time</source>
        <translation />
    </message>
    <message>
        <source>Move the cursor to the end of the block</source>
        <translation />
    </message>
    <message>
        <source>Select to the start of the line</source>
        <translation />
    </message>
    <message>
        <source>Look Up In Dictionary</source>
        <translation />
    </message>
    <message>
        <source>Mute audio tracks</source>
        <translation />
    </message>
    <message>
        <source>Search The Web</source>
        <translation />
    </message>
    <message>
        <source>Status Display</source>
        <translation />
    </message>
    <message>
        <source>Check Spelling While Typing</source>
        <translation />
    </message>
    <message>
        <source>Add To Dictionary</source>
        <translation />
    </message>
    <message>
        <source>Justify</source>
        <translation />
    </message>
    <message>
        <source>Pause Button</source>
        <translation />
    </message>
    <message>
        <source>Slider Thumb</source>
        <translation />
    </message>
    <message>
        <source>Delete to the start of the word</source>
        <translation />
    </message>
    <message>
        <source>Recent searches</source>
        <translation />
    </message>
    <message>
        <source>Move the cursor to the next word</source>
        <translation />
    </message>
    <message>
        <source>Move the cursor to the next line</source>
        <translation />
    </message>
    <message>
        <source>JavaScript Alert - %1</source>
        <translation />
    </message>
    <message>
        <source>%1 minutes %2 seconds</source>
        <translation />
    </message>
    <message>
        <source>Scroll down</source>
        <translation />
    </message>
    <message>
        <source>Scroll here</source>
        <translation />
    </message>
    <message>
        <source>Scroll left</source>
        <translation />
    </message>
    <message>
        <source>Left to Right</source>
        <translation />
    </message>
    <message>
        <source>Move the cursor to the start of the block</source>
        <translation />
    </message>
    <message>
        <source>Right to Left</source>
        <translation />
    </message>
    <message>
        <source>Rewind movie</source>
        <translation />
    </message>
    <message>
        <source>Movie time scrubber</source>
        <translation />
    </message>
    <message>
        <source>Text Direction</source>
        <translation />
    </message>
    <message>
        <source>Play movie in full-screen mode</source>
        <translation />
    </message>
    <message>
        <source>Seek quickly back</source>
        <translation />
    </message>
    <message>
        <source>Audio Element</source>
        <translation />
    </message>
    <message>
        <source>Bottom</source>
        <translation />
    </message>
    <message>
        <source>Center</source>
        <translation />
    </message>
    <message>
        <source>Mute Button</source>
        <translation />
    </message>
    <message>
        <source>Play Button</source>
        <translation />
    </message>
    <message>
        <source>Ignore</source>
        <translation />
    </message>
    <message>
        <source>Indent</source>
        <translation />
    </message>
    <message>
        <source>Italic</source>
        <translation />
    </message>
    <message>
        <source>Move the cursor to the end of the line</source>
        <translation />
    </message>
    <message>
        <source>Move the cursor to the start of the line</source>
        <translation />
    </message>
    <message>
        <source>Return streaming movie to real-time</source>
        <translation />
    </message>
    <message>
        <source>The script on this page appears to have a problem. Do you want to stop the script?</source>
        <translation />
    </message>
    <message>
        <source>Reload</source>
        <translation />
    </message>
    <message>
        <source>JavaScript Confirm - %1</source>
        <translation />
    </message>
    <message>
        <source>Insert a new line</source>
        <translation />
    </message>
    <message>
        <source>Slider</source>
        <translation />
    </message>
    <message>
        <source>Submit</source>
        <translation />
    </message>
    <message>
        <source>Live Broadcast</source>
        <translation />
    </message>
    <message>
        <source>Web Inspector - %2</source>
        <translation />
    </message>
    <message>
        <source>Page up</source>
        <translation />
    </message>
    <message>
        <source>Paste and Match Style</source>
        <translation />
    </message>
    <message>
        <source>Spelling</source>
        <translation />
    </message>
    <message>
        <source>Outdent</source>
        <translation />
    </message>
    <message>
        <source>Outline</source>
        <translation />
    </message>
    <message>
        <source>Check Grammar With Spelling</source>
        <translation />
    </message>
    <message>
        <source>No file selected</source>
        <translation />
    </message>
    <message>
        <source>Ignore</source>
        <comment>Ignore Grammar context menu item</comment>
        <translation />
    </message>
    <message>
        <source>Save Image</source>
        <translation />
    </message>
    <message>
        <source>Insert Bulleted List</source>
        <translation />
    </message>
    <message>
        <source>JavaScript Problem - %1</source>
        <translation />
    </message>
    <message>
        <source>Save Link...</source>
        <translation />
    </message>
    <message>
        <source>No recent searches</source>
        <translation />
    </message>
    <message>
        <source>Page right</source>
        <translation />
    </message>
    <message>
        <source>Move the cursor to the start of the document</source>
        <translation />
    </message>
    <message>
        <source>Move the cursor to the next character</source>
        <translation />
    </message>
    <message>
        <source>JavaScript Prompt - %1</source>
        <translation />
    </message>
    <message>
        <source>Copy Link</source>
        <translation />
    </message>
    <message>
        <source>Remaining movie time</source>
        <translation />
    </message>
    <message>
        <source>Select to the previous line</source>
        <translation />
    </message>
    <message>
        <source>Select to the previous word</source>
        <translation />
    </message>
    <message>
        <source>Check Spelling</source>
        <translation />
    </message>
    <message>
        <source>Redirection limit reached</source>
        <translation />
    </message>
    <message>
        <source>Select to the next character</source>
        <translation />
    </message>
    <message>
        <source>Remaining Time</source>
        <translation />
    </message>
    <message>
        <source>Show Spelling and Grammar</source>
        <translation />
    </message>
    <message>
        <source>Delete to the end of the word</source>
        <translation />
    </message>
    <message>
        <source>Direction</source>
        <translation />
    </message>
    <message>
        <source>Select to the end of the line</source>
        <translation />
    </message>
    <message>
        <source>Submit</source>
        <comment>Submit (input element) alt text for &lt;input&gt; elements with no alt, title, or value</comment>
        <translation />
    </message>
    <message>
        <source>Unmute Button</source>
        <translation />
    </message>
    <message>
        <source>Video Element</source>
        <translation />
    </message>
    <message>
        <source>Choose File</source>
        <translation />
    </message>
    <message>
        <source>Seek quickly forward</source>
        <translation />
    </message>
    <message>
        <source>Scroll up</source>
        <translation />
    </message>
    <message>
        <source>Begin playback</source>
        <translation />
    </message>
    <message>
        <source>Subscript</source>
        <translation />
    </message>
    <message>
        <source>%1 days %2 hours %3 minutes %4 seconds</source>
        <translation />
    </message>
    <message>
        <source>%1 seconds</source>
        <translation />
    </message>
    <message>
        <source>Superscript</source>
        <translation />
    </message>
    <message>
        <source>Clear recent searches</source>
        <translation />
    </message>
    <message>
        <source>Seek Back Button</source>
        <translation />
    </message>
    <message>
        <source>Pause playback</source>
        <translation />
    </message>
    <message>
        <source>Select to the start of the document</source>
        <translation />
    </message>
    <message>
        <source>Default</source>
        <translation />
    </message>
    <message>
        <source>Underline</source>
        <translation />
    </message>
    <message>
        <source>Loading...</source>
        <translation />
    </message>
    <message>
        <source>Move the cursor to the previous character</source>
        <translation />
    </message>
    <message>
        <source>Copy Image</source>
        <translation />
    </message>
    <message>
        <source>Insert Numbered List</source>
        <translation />
    </message>
    <message>
        <source>Audio element playback controls and status display</source>
        <translation />
    </message>
    <message>
        <source>Select to the end of the document</source>
        <translation />
    </message>
    <message>
        <source>Select to the end of the block</source>
        <translation />
    </message>
    <message>
        <source>Select all</source>
        <translation />
    </message>
    <message>
        <source>Seek Forward Button</source>
        <translation />
    </message>
    <message>
        <source>Scroll right</source>
        <translation />
    </message>
    <message>
        <source>No Guesses Found</source>
        <translation />
    </message>
    <message>
        <source>Open Link</source>
        <translation />
    </message>
    <message>
        <source>Current movie status</source>
        <translation />
    </message>
    <message>
        <source>Bad HTTP request</source>
        <translation />
    </message>
    <message>
        <source>Unknown</source>
        <translation />
    </message>
    <message>
        <source>Rewind Button</source>
        <translation />
    </message>
    <message>
        <source>%1 hours %2 minutes %3 seconds</source>
        <translation />
    </message>
    <message>
        <source>Move the cursor to the previous word</source>
        <translation />
    </message>
    <message>
        <source>Move the cursor to the previous line</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>%n file(s)</source>
        <translation><numerusform>%n datoteka</numerusform>
            <numerusform>%n datoteki</numerusform>
            <numerusform>%n datoteke</numerusform>
            <numerusform>%n datotek</numerusform>
        </translation>
    </message>
    <message>
        <source>Left edge</source>
        <translation />
    </message>
    <message>
        <source>Unmute audio tracks</source>
        <translation />
    </message>
    <message>
        <source>Go Forward</source>
        <translation />
    </message>
    <message>
        <source>Page down</source>
        <translation />
    </message>
    <message>
        <source>Page left</source>
        <translation />
    </message>
    <message>
        <source>Fullscreen Button</source>
        <translation />
    </message>
    <message>
        <source>Missing Plug-in</source>
        <translation />
    </message>
    <message>
        <source>This is a searchable index. Enter search keywords: </source>
        <translation />
    </message>
    <message>
        <source>Align Left</source>
        <translation />
    </message>
    <message>
        <source>Select to the previous character</source>
        <translation />
    </message>
    <message>
        <source>Go Back</source>
        <translation />
    </message>
    <message>
        <source>Return to Real-time Button</source>
        <translation />
    </message>
    <message>
        <source>Current movie time</source>
        <translation />
    </message>
    <message>
        <source>Open in New Window</source>
        <translation />
    </message>
    <message>
        <source>Right edge</source>
        <translation />
    </message>
    <message>
        <source>Move the cursor to the end of the document</source>
        <translation />
    </message>
    <message>
        <source>Video element playback controls and status display</source>
        <translation />
    </message>
    <message>
        <source>Remove formatting</source>
        <translation />
    </message>
    <message>
        <source>Elapsed Time</source>
        <translation />
    </message>
    <message>
        <source>Hide Spelling and Grammar</source>
        <translation />
    </message>
    <message>
        <source>%1 (%2x%3 pixels)</source>
        <translation />
    </message>
    <message>
        <source>Select to the next word</source>
        <translation />
    </message>
    <message>
        <source>Select to the next line</source>
        <translation />
    </message>
</context>
<context>
    <name>QScriptBreakpointsWidget</name>
    <message>
        <source>New</source>
        <translation />
    </message>
    <message>
        <source>Delete</source>
        <translation />
    </message>
</context>
<context>
    <name>QScrollBar</name>
    <message>
        <source>Top</source>
        <translation />
    </message>
    <message>
        <source>Scroll down</source>
        <translation />
    </message>
    <message>
        <source>Scroll here</source>
        <translation />
    </message>
    <message>
        <source>Scroll left</source>
        <translation />
    </message>
    <message>
        <source>Line up</source>
        <translation />
    </message>
    <message>
        <source>Line down</source>
        <translation />
    </message>
    <message>
        <source>Bottom</source>
        <translation />
    </message>
    <message>
        <source>Page up</source>
        <translation />
    </message>
    <message>
        <source>Position</source>
        <translation />
    </message>
    <message>
        <source>Page right</source>
        <translation />
    </message>
    <message>
        <source>Scroll up</source>
        <translation />
    </message>
    <message>
        <source>Scroll right</source>
        <translation />
    </message>
    <message>
        <source>Left edge</source>
        <translation />
    </message>
    <message>
        <source>Page down</source>
        <translation />
    </message>
    <message>
        <source>Page left</source>
        <translation />
    </message>
    <message>
        <source>Right edge</source>
        <translation />
    </message>
</context>
<context>
    <name>QFile</name>
    <message>
        <source>Cannot remove source file</source>
        <translation />
    </message>
    <message>
        <source>Cannot create %1 for output</source>
        <translation />
    </message>
    <message>
        <source>Failure to write block</source>
        <translation />
    </message>
    <message>
        <source>Cannot open %1 for input</source>
        <translation />
    </message>
    <message>
        <source>Destination file exists</source>
        <translation />
    </message>
    <message>
        <source>Cannot open for output</source>
        <translation />
    </message>
    <message>
        <source>Will not rename sequential file using block copy</source>
        <translation />
    </message>
</context>
<context>
    <name>QFileDialog</name>
    <message>
        <source>Back</source>
        <translation />
    </message>
    <message>
        <source>File</source>
        <translation />
    </message>
    <message>
        <source>Open</source>
        <translation />
    </message>
    <message>
        <source>&amp;Open</source>
        <translation />
    </message>
    <message>
        <source>&amp;Save</source>
        <translation />
    </message>
    <message>
        <source>Alias</source>
        <translation />
    </message>
    <message>
        <source>Drive</source>
        <translation />
    </message>
    <message>
        <source>Show </source>
        <translation />
    </message>
    <message>
        <source>'%1' is write protected.
Do you want to delete it anyway?</source>
        <translation />
    </message>
    <message>
        <source>File &amp;name:</source>
        <translation />
    </message>
    <message>
        <source>File Folder</source>
        <translation />
    </message>
    <message>
        <source>New Folder</source>
        <translation />
    </message>
    <message>
        <source>Folder</source>
        <translation />
    </message>
    <message>
        <source>Parent Directory</source>
        <translation />
    </message>
    <message>
        <source>&amp;New Folder</source>
        <translation />
    </message>
    <message>
        <source>Remove</source>
        <translation />
    </message>
    <message>
        <source>My Computer</source>
        <translation />
    </message>
    <message>
        <source>Look in:</source>
        <translation />
    </message>
    <message>
        <source>Create a New Folder</source>
        <translation />
    </message>
    <message>
        <source>Files of type:</source>
        <translation />
    </message>
    <message>
        <source>Find Directory</source>
        <translation />
    </message>
    <message>
        <source>Show &amp;hidden files</source>
        <translation />
    </message>
    <message>
        <source>Are sure you want to delete '%1'?</source>
        <translation />
    </message>
    <message>
        <source>Save As</source>
        <translation />
    </message>
    <message>
        <source>%1
Directory not found.
Please verify the correct directory name was given.</source>
        <translation />
    </message>
    <message>
        <source>List View</source>
        <translation />
    </message>
    <message>
        <source>&amp;Choose</source>
        <translation />
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation />
    </message>
    <message>
        <source>All Files (*)</source>
        <translation />
    </message>
    <message>
        <source>Directories</source>
        <translation />
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation />
    </message>
    <message>
        <source>&amp;Rename</source>
        <translation />
    </message>
    <message>
        <source>Could not delete directory.</source>
        <translation />
    </message>
    <message>
        <source>Directory:</source>
        <translation />
    </message>
    <message>
        <source>Unknown</source>
        <translation />
    </message>
    <message>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation />
    </message>
    <message>
        <source>Forward</source>
        <translation />
    </message>
    <message>
        <source>Go forward</source>
        <translation />
    </message>
    <message>
        <source>Go to the parent directory</source>
        <translation />
    </message>
    <message>
        <source>Recent Places</source>
        <translation />
    </message>
    <message>
        <source>Go back</source>
        <translation />
    </message>
    <message>
        <source>Change to detail view mode</source>
        <translation />
    </message>
    <message>
        <source>Create New Folder</source>
        <translation />
    </message>
    <message>
        <source>Shortcut</source>
        <translation />
    </message>
    <message>
        <source>Detail View</source>
        <translation />
    </message>
    <message>
        <source>%1
File not found.
Please verify the correct file name was given.</source>
        <translation />
    </message>
    <message>
        <source>Change to list view mode</source>
        <translation />
    </message>
</context>
<context>
    <name>Q3TextEdit</name>
    <message>
        <source>Cu&amp;t</source>
        <translation />
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation />
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation />
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation />
    </message>
    <message>
        <source>Clear</source>
        <translation />
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation />
    </message>
    <message>
        <source>Select All</source>
        <translation />
    </message>
</context>
<context>
    <name>QLineEdit</name>
    <message>
        <source>Cu&amp;t</source>
        <translation />
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation />
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation />
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation />
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation />
    </message>
    <message>
        <source>Delete</source>
        <translation />
    </message>
    <message>
        <source>Select All</source>
        <translation />
    </message>
</context>
<context>
    <name>QTextControl</name>
    <message>
        <source>Cu&amp;t</source>
        <translation />
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation />
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation />
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation />
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation />
    </message>
    <message>
        <source>Delete</source>
        <translation />
    </message>
    <message>
        <source>Select All</source>
        <translation />
    </message>
    <message>
        <source>Copy &amp;Link Location</source>
        <translation />
    </message>
</context>
<context>
    <name>QDockWidget</name>
    <message>
        <source>Dock</source>
        <translation />
    </message>
    <message>
        <source>Close</source>
        <translation />
    </message>
    <message>
        <source>Float</source>
        <translation />
    </message>
</context>
<context>
    <name>QDialog</name>
    <message>
        <source>Done</source>
        <translation />
    </message>
    <message>
        <source>What's This?</source>
        <translation />
    </message>
</context>
<context>
    <name>QWizard</name>
    <message>
        <source>Done</source>
        <translation />
    </message>
    <message>
        <source>Help</source>
        <translation />
    </message>
    <message>
        <source>&amp;Help</source>
        <translation />
    </message>
    <message>
        <source>&amp;Next</source>
        <translation />
    </message>
    <message>
        <source>Cancel</source>
        <translation />
    </message>
    <message>
        <source>Commit</source>
        <translation />
    </message>
    <message>
        <source>Continue</source>
        <translation />
    </message>
    <message>
        <source>&amp;Finish</source>
        <translation />
    </message>
    <message>
        <source>&amp;Next &gt;</source>
        <translation />
    </message>
    <message>
        <source>Go Back</source>
        <translation />
    </message>
    <message>
        <source>&lt; &amp;Back</source>
        <translation />
    </message>
</context>
<context>
    <name>QPageSetupWidget</name>
    <message>
        <source>Form</source>
        <translation />
    </message>
    <message>
        <source>bottom margin</source>
        <translation />
    </message>
    <message>
        <source>Paper</source>
        <translation />
    </message>
    <message>
        <source>Paper source:</source>
        <translation />
    </message>
    <message>
        <source>Centimeters (cm)</source>
        <translation />
    </message>
    <message>
        <source>right margin</source>
        <translation />
    </message>
    <message>
        <source>Margins</source>
        <translation />
    </message>
    <message>
        <source>Landscape</source>
        <translation />
    </message>
    <message>
        <source>Width:</source>
        <translation />
    </message>
    <message>
        <source>Orientation</source>
        <translation />
    </message>
    <message>
        <source>Portrait</source>
        <translation />
    </message>
    <message>
        <source>top margin</source>
        <translation />
    </message>
    <message>
        <source>left margin</source>
        <translation />
    </message>
    <message>
        <source>Page size:</source>
        <translation />
    </message>
    <message>
        <source>Reverse portrait</source>
        <translation />
    </message>
    <message>
        <source>Millimeters (mm)</source>
        <translation />
    </message>
    <message>
        <source>Points (pt)</source>
        <translation />
    </message>
    <message>
        <source>Inches (in)</source>
        <translation />
    </message>
    <message>
        <source>Reverse landscape</source>
        <translation />
    </message>
    <message>
        <source>Height:</source>
        <translation />
    </message>
</context>
<context>
    <name>QPrintPropertiesWidget</name>
    <message>
        <source>Form</source>
        <translation />
    </message>
    <message>
        <source>Page</source>
        <translation />
    </message>
    <message>
        <source>Advanced</source>
        <translation />
    </message>
</context>
<context>
    <name>QMdiSubWindow</name>
    <message>
        <source>Help</source>
        <translation />
    </message>
    <message>
        <source>Menu</source>
        <translation />
    </message>
    <message>
        <source>&amp;Move</source>
        <translation />
    </message>
    <message>
        <source>&amp;Size</source>
        <translation />
    </message>
    <message>
        <source>Close</source>
        <translation />
    </message>
    <message>
        <source>Minimize</source>
        <translation />
    </message>
    <message>
        <source>Shade</source>
        <translation />
    </message>
    <message>
        <source>Stay on &amp;Top</source>
        <translation />
    </message>
    <message>
        <source>&amp;Close</source>
        <translation />
    </message>
    <message>
        <source>- [%1]</source>
        <translation />
    </message>
    <message>
        <source>%1 - [%2]</source>
        <translation />
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation />
    </message>
    <message>
        <source>Restore</source>
        <translation />
    </message>
    <message>
        <source>Maximize</source>
        <translation />
    </message>
    <message>
        <source>Unshade</source>
        <translation />
    </message>
    <message>
        <source>Mi&amp;nimize</source>
        <translation />
    </message>
    <message>
        <source>Ma&amp;ximize</source>
        <translation />
    </message>
    <message>
        <source>Restore Down</source>
        <translation />
    </message>
</context>
<context>
    <name>QDirModel</name>
    <message>
        <source>Kind</source>
        <translation />
    </message>
    <message>
        <source>Name</source>
        <translation />
    </message>
    <message>
        <source>Size</source>
        <translation />
    </message>
    <message>
        <source>Type</source>
        <translation />
    </message>
    <message>
        <source>Date Modified</source>
        <translation />
    </message>
</context>
<context>
    <name>QFileSystemModel</name>
    <message>
        <source>Kind</source>
        <translation />
    </message>
    <message>
        <source>Name</source>
        <translation />
    </message>
    <message>
        <source>Size</source>
        <translation />
    </message>
    <message>
        <source>Type</source>
        <translation />
    </message>
    <message>
        <source>%1 GB</source>
        <translation />
    </message>
    <message>
        <source>%1 KB</source>
        <translation />
    </message>
    <message>
        <source>%1 MB</source>
        <translation />
    </message>
    <message>
        <source>%1 TB</source>
        <translation />
    </message>
    <message>
        <source>&lt;b&gt;The name "%1" can not be used.&lt;/b&gt;&lt;p&gt;Try using another name, with fewer characters or no punctuations marks.</source>
        <translation />
    </message>
    <message>
        <source>%1 bytes</source>
        <translation />
    </message>
    <message>
        <source>My Computer</source>
        <translation />
    </message>
    <message>
        <source>Computer</source>
        <translation />
    </message>
    <message>
        <source>Invalid filename</source>
        <translation />
    </message>
    <message>
        <source>%1 byte(s)</source>
        <translation />
    </message>
    <message>
        <source>Date Modified</source>
        <translation />
    </message>
</context>
<context>
    <name>QDoubleSpinBox</name>
    <message>
        <source>Less</source>
        <translation />
    </message>
    <message>
        <source>More</source>
        <translation />
    </message>
</context>
<context>
    <name>QSpinBox</name>
    <message>
        <source>Less</source>
        <translation />
    </message>
    <message>
        <source>More</source>
        <translation />
    </message>
</context>
<context>
    <name>QPPDOptionsModel</name>
    <message>
        <source>Name</source>
        <translation />
    </message>
    <message>
        <source>Value</source>
        <translation />
    </message>
</context>
<context>
    <name>QScriptDebuggerLocalsModel</name>
    <message>
        <source>Name</source>
        <translation />
    </message>
    <message>
        <source>Value</source>
        <translation />
    </message>
</context>
<context>
    <name>QScriptDebuggerStackModel</name>
    <message>
        <source>Name</source>
        <translation />
    </message>
    <message>
        <source>Level</source>
        <translation />
    </message>
    <message>
        <source>Location</source>
        <translation />
    </message>
</context>
<context>
    <name>QScriptDebuggerCodeFinderWidget</name>
    <message>
        <source>Next</source>
        <translation />
    </message>
    <message>
        <source>Close</source>
        <translation />
    </message>
    <message>
        <source>Whole words</source>
        <translation />
    </message>
    <message>
        <source>Previous</source>
        <translation />
    </message>
    <message>
        <source>&lt;img src=":/qt/scripttools/debugging/images/wrap.png"&gt;&amp;nbsp;Search wrapped</source>
        <translation />
    </message>
    <message>
        <source>Case Sensitive</source>
        <translation />
    </message>
</context>
<context>
    <name>QComboBox</name>
    <message>
        <source>Open</source>
        <translation />
    </message>
    <message>
        <source>True</source>
        <translation />
    </message>
    <message>
        <source>Close</source>
        <translation />
    </message>
    <message>
        <source>False</source>
        <translation />
    </message>
</context>
<context>
    <name>QMenu</name>
    <message>
        <source>Open</source>
        <translation />
    </message>
    <message>
        <source>Close</source>
        <translation />
    </message>
    <message>
        <source>Execute</source>
        <translation />
    </message>
</context>
<context>
    <name>QPushButton</name>
    <message>
        <source>Open</source>
        <translation />
    </message>
</context>
<context>
    <name>QToolButton</name>
    <message>
        <source>Open</source>
        <translation />
    </message>
    <message>
        <source>Press</source>
        <translation />
    </message>
</context>
<context>
    <name>QUndoGroup</name>
    <message>
        <source>Redo</source>
        <translation />
    </message>
    <message>
        <source>Undo</source>
        <translation />
    </message>
</context>
<context>
    <name>QUndoStack</name>
    <message>
        <source>Redo</source>
        <translation />
    </message>
    <message>
        <source>Undo</source>
        <translation />
    </message>
</context>
<context>
    <name>Q3DataTable</name>
    <message>
        <source>True</source>
        <translation />
    </message>
    <message>
        <source>False</source>
        <translation />
    </message>
    <message>
        <source>Delete</source>
        <translation />
    </message>
    <message>
        <source>Insert</source>
        <translation />
    </message>
    <message>
        <source>Update</source>
        <translation />
    </message>
</context>
<context>
    <name>QScriptEngineDebugger</name>
    <message>
        <source>View</source>
        <translation />
    </message>
    <message>
        <source>Stack</source>
        <translation />
    </message>
    <message>
        <source>Debug Output</source>
        <translation />
    </message>
    <message>
        <source>Breakpoints</source>
        <translation />
    </message>
    <message>
        <source>Qt Script Debugger</source>
        <translation />
    </message>
    <message>
        <source>Locals</source>
        <translation />
    </message>
    <message>
        <source>Search</source>
        <translation />
    </message>
    <message>
        <source>Error Log</source>
        <translation />
    </message>
    <message>
        <source>Console</source>
        <translation />
    </message>
    <message>
        <source>Loaded Scripts</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeCompiler</name>
    <message>
        <source>Attached properties cannot be used here</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: rect expected</source>
        <translation />
    </message>
    <message>
        <source>Invalid attached object assignment</source>
        <translation />
    </message>
    <message>
        <source>Component elements may not contain properties other than id</source>
        <translation />
    </message>
    <message>
        <source>Invalid grouped property access</source>
        <translation />
    </message>
    <message>
        <source>Invalid property type</source>
        <translation />
    </message>
    <message>
        <source>Cannot override FINAL property</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: size expected</source>
        <translation />
    </message>
    <message>
        <source>Cannot assign object to list</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: string expected</source>
        <translation />
    </message>
    <message>
        <source>Cannot assign a value to a signal (expecting a script to be run)</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: unknown enumeration</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: unsupported type "%1"</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: datetime expected</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: 3D vector expected</source>
        <translation />
    </message>
    <message>
        <source>Cannot assign multiple values to a script property</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: date expected</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: time expected</source>
        <translation />
    </message>
    <message>
        <source>Property assignment expected</source>
        <translation />
    </message>
    <message>
        <source>Cannot create empty component specification</source>
        <translation />
    </message>
    <message>
        <source>"%1" cannot operate on "%2"</source>
        <translation />
    </message>
    <message>
        <source>Invalid use of id property</source>
        <translation />
    </message>
    <message>
        <source>Method names cannot begin with an upper case letter</source>
        <translation />
    </message>
    <message>
        <source>Empty signal assignment</source>
        <translation />
    </message>
    <message>
        <source>Duplicate property name</source>
        <translation />
    </message>
    <message>
        <source>Not an attached property name</source>
        <translation />
    </message>
    <message>
        <source>Component objects cannot declare new functions.</source>
        <translation />
    </message>
    <message>
        <source>Incorrectly specified signal assignment</source>
        <translation />
    </message>
    <message>
        <source>Element is not creatable.</source>
        <translation />
    </message>
    <message>
        <source>Component objects cannot declare new properties.</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: color expected</source>
        <translation />
    </message>
    <message>
        <source>Duplicate method name</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: boolean expected</source>
        <translation />
    </message>
    <message>
        <source>Cannot assign to non-existent default property</source>
        <translation />
    </message>
    <message>
        <source>Invalid alias reference. An alias reference must be specified as &lt;id&gt; or &lt;id&gt;.&lt;property&gt;</source>
        <translation />
    </message>
    <message>
        <source>Non-existent attached object</source>
        <translation />
    </message>
    <message>
        <source>IDs cannot start with an uppercase letter</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: point expected</source>
        <translation />
    </message>
    <message>
        <source>Can only assign one binding to lists</source>
        <translation />
    </message>
    <message>
        <source>Duplicate default property</source>
        <translation />
    </message>
    <message>
        <source>Duplicate signal name</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: unsigned int expected</source>
        <translation />
    </message>
    <message>
        <source>id is not unique</source>
        <translation />
    </message>
    <message>
        <source>Invalid property nesting</source>
        <translation />
    </message>
    <message>
        <source>Property names cannot begin with an upper case letter</source>
        <translation />
    </message>
    <message>
        <source>Invalid alias reference. Unable to find id "%1"</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: "%1" is a read-only property</source>
        <translation />
    </message>
    <message>
        <source>Property value set multiple times</source>
        <translation />
    </message>
    <message>
        <source>Illegal signal name</source>
        <translation />
    </message>
    <message>
        <source>Cannot assign primitives to lists</source>
        <translation />
    </message>
    <message>
        <source>Cannot assign object to property</source>
        <translation />
    </message>
    <message>
        <source>No property alias location</source>
        <translation />
    </message>
    <message>
        <source>Property has already been assigned a value</source>
        <translation />
    </message>
    <message>
        <source>Illegal method name</source>
        <translation />
    </message>
    <message>
        <source>Invalid property use</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: number expected</source>
        <translation />
    </message>
    <message>
        <source>Cannot assign a value directly to a grouped property</source>
        <translation />
    </message>
    <message>
        <source>IDs must start with a letter or underscore</source>
        <translation />
    </message>
    <message>
        <source>Invalid empty ID</source>
        <translation />
    </message>
    <message>
        <source>Unexpected object assignment</source>
        <translation />
    </message>
    <message>
        <source>Cannot assign to non-existent property "%1"</source>
        <translation />
    </message>
    <message>
        <source>ID illegally masks global JavaScript property</source>
        <translation />
    </message>
    <message>
        <source>Invalid component body specification</source>
        <translation />
    </message>
    <message>
        <source>Component objects cannot declare new signals.</source>
        <translation />
    </message>
    <message>
        <source>IDs must contain only letters, numbers, and underscores</source>
        <translation />
    </message>
    <message>
        <source>Invalid use of namespace</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: int expected</source>
        <translation />
    </message>
    <message>
        <source>Invalid component id specification</source>
        <translation />
    </message>
    <message>
        <source>Illegal property name</source>
        <translation />
    </message>
    <message>
        <source>Invalid alias location</source>
        <translation />
    </message>
    <message>
        <source>Single property assignment expected</source>
        <translation />
    </message>
    <message>
        <source>Empty property assignment</source>
        <translation />
    </message>
    <message>
        <source>Signal names cannot begin with an upper case letter</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: url expected</source>
        <translation />
    </message>
    <message>
        <source>Invalid property assignment: script expected</source>
        <translation />
    </message>
</context>
<context>
    <name>QSslSocket</name>
    <message>
        <source>Error creating SSL session: %1</source>
        <translation />
    </message>
    <message>
        <source>Error creating SSL session, %1</source>
        <translation />
    </message>
    <message>
        <source>The certificate's notAfter field contains an invalid time</source>
        <translation />
    </message>
    <message>
        <source>No error</source>
        <translation />
    </message>
    <message>
        <source>Cannot provide a certificate with no key, %1</source>
        <translation />
    </message>
    <message>
        <source>Unable to write data: %1</source>
        <translation />
    </message>
    <message>
        <source>The certificate has expired</source>
        <translation />
    </message>
    <message>
        <source>Error during SSL handshake: %1</source>
        <translation />
    </message>
    <message>
        <source>Error loading local certificate, %1</source>
        <translation />
    </message>
    <message>
        <source>The certificate is self-signed, and untrusted</source>
        <translation />
    </message>
    <message>
        <source>The peer did not present any certificate</source>
        <translation />
    </message>
    <message>
        <source>The root CA certificate is marked to reject the specified purpose</source>
        <translation />
    </message>
    <message>
        <source>Invalid or empty cipher list (%1)</source>
        <translation />
    </message>
    <message>
        <source>No certificates could be verified</source>
        <translation />
    </message>
    <message>
        <source>The root CA certificate is not trusted for this purpose</source>
        <translation />
    </message>
    <message>
        <source>The host name did not match any of the valid hosts for this certificate</source>
        <translation />
    </message>
    <message>
        <source>The root certificate of the certificate chain is self-signed, and untrusted</source>
        <translation />
    </message>
    <message>
        <source>The certificate signature could not be decrypted</source>
        <translation />
    </message>
    <message>
        <source>The supplied certificate is unsuitable for this purpose</source>
        <translation />
    </message>
    <message>
        <source>Private key does not certify public key, %1</source>
        <translation />
    </message>
    <message>
        <source>Error creating SSL context (%1)</source>
        <translation />
    </message>
    <message>
        <source>The issuer certificate could not be found</source>
        <translation />
    </message>
    <message>
        <source>Unknown error</source>
        <translation />
    </message>
    <message>
        <source>Error while reading: %1</source>
        <translation />
    </message>
    <message>
        <source>The certificate's notBefore field contains an invalid time</source>
        <translation />
    </message>
    <message>
        <source>Error loading private key, %1</source>
        <translation />
    </message>
    <message>
        <source>The certificate is not yet valid</source>
        <translation />
    </message>
    <message>
        <source>The public key in the certificate could not be read</source>
        <translation />
    </message>
    <message>
        <source>One of the CA certificates is invalid</source>
        <translation />
    </message>
    <message>
        <source>The signature of the certificate is invalid</source>
        <translation />
    </message>
    <message>
        <source>The issuer certificate of a locally looked up certificate could not be found</source>
        <translation />
    </message>
    <message>
        <source>Unable to decrypt data: %1</source>
        <translation />
    </message>
</context>
<context>
    <name>QLocalSocket</name>
    <message>
        <source>%1: Connection error</source>
        <translation />
    </message>
    <message>
        <source>%1: Connection refused</source>
        <translation />
    </message>
    <message>
        <source>%1: Unknown error %2</source>
        <translation />
    </message>
    <message>
        <source>%1: Socket access error</source>
        <translation />
    </message>
    <message>
        <source>%1: Socket resource error</source>
        <translation />
    </message>
    <message>
        <source>%1: The socket operation is not supported</source>
        <translation />
    </message>
    <message>
        <source>%1: Invalid name</source>
        <translation />
    </message>
    <message>
        <source>%1: Unknown error</source>
        <translation />
    </message>
    <message>
        <source>%1: Socket operation timed out</source>
        <translation />
    </message>
    <message>
        <source>%1: Datagram too large</source>
        <translation />
    </message>
    <message>
        <source>%1: Remote closed</source>
        <translation />
    </message>
</context>
<context>
    <name>QOCIResult</name>
    <message>
        <source>Unable to get statement type</source>
        <translation />
    </message>
    <message>
        <source>Unable to alloc statement</source>
        <translation />
    </message>
    <message>
        <source>Unable to goto next</source>
        <translation />
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation />
    </message>
    <message>
        <source>Unable to bind column for batch execute</source>
        <translation />
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation />
    </message>
    <message>
        <source>Unable to execute batch statement</source>
        <translation />
    </message>
    <message>
        <source>Unable to bind value</source>
        <translation />
    </message>
</context>
<context>
    <name>QtXmlPatterns</name>
    <message>
        <source>A comment cannot contain %1</source>
        <translation />
    </message>
    <message>
        <source>Version %1 is not supported. The supported XQuery version is 1.0.</source>
        <translation />
    </message>
    <message>
        <source>'%1' attribute contains invalid QName content: %2.</source>
        <translation />
    </message>
    <message>
        <source>Notation %1 already defined.</source>
        <translation />
    </message>
    <message>
        <source>Declaration for element %1 does not exist.</source>
        <translation />
    </message>
    <message>
        <source>The parameter %1 is required, but no corresponding %2 is supplied.</source>
        <translation />
    </message>
    <message>
        <source>Namespace declarations must occur before function, variable, and option declarations.</source>
        <translation />
    </message>
    <message>
        <source>empty</source>
        <translation />
    </message>
    <message>
        <source>Specifying use='prohibited' inside an attribute group has no effect.</source>
        <translation />
    </message>
    <message>
        <source>Attribute group %1 contains attribute %2 twice.</source>
        <translation />
    </message>
    <message>
        <source>A comment cannot end with a %1.</source>
        <translation />
    </message>
    <message>
        <source>Derived particle allows content that is not allowed in the base particle.</source>
        <translation />
    </message>
    <message>
        <source>%1 element is not allowed in this scope</source>
        <translation />
    </message>
    <message>
        <source>Element %1 exists twice with different types.</source>
        <translation />
    </message>
    <message>
        <source>Integer division (%1) by zero (%2) is undefined.</source>
        <translation />
    </message>
    <message>
        <source>A library module cannot be evaluated directly. It must be imported from a main module.</source>
        <translation />
    </message>
    <message>
        <source>Time %1:%2:%3.%4 is invalid.</source>
        <translation />
    </message>
    <message>
        <source>A value of type %1 must contain an even number of digits. The value %2 does not.</source>
        <translation />
    </message>
    <message>
        <source>Child element is missing in that scope, possible child elements are: %1.</source>
        <translation />
    </message>
    <message>
        <source>Modulus division (%1) by zero (%2) is undefined.</source>
        <translation />
    </message>
    <message>
        <source>Data of type %1 are not allowed to be empty.</source>
        <translation />
    </message>
    <message>
        <source>No function with signature %1 is available</source>
        <translation />
    </message>
    <message>
        <source>Network timeout.</source>
        <translation />
    </message>
    <message>
        <source>%1 element must not have %2 and %3 attribute together.</source>
        <translation />
    </message>
    <message>
        <source>%1 element requires either %2 or %3 attribute.</source>
        <translation />
    </message>
    <message>
        <source>Content of attribute %1 does not match its type definition: %2.</source>
        <translation />
    </message>
    <message>
        <source>Attribute %1 and %2 are mutually exclusive.</source>
        <translation />
    </message>
    <message>
        <source>Loaded schema file is invalid.</source>
        <translation />
    </message>
    <message>
        <source>Parse error: %1</source>
        <translation />
    </message>
    <message>
        <source>If the first argument is the empty sequence or a zero-length string (no namespace), a prefix cannot be specified. Prefix %1 was specified.</source>
        <translation />
    </message>
    <message>
        <source>At least one component must be present.</source>
        <translation />
    </message>
    <message>
        <source>An attribute by name %1 has already been created.</source>
        <translation />
    </message>
    <message>
        <source>%1 element must have either %2 or %3 attribute.</source>
        <translation />
    </message>
    <message>
        <source>Invalid QName content: %1.</source>
        <translation />
    </message>
    <message>
        <source>Matches are case insensitive</source>
        <translation />
    </message>
    <message>
        <source>The name of an extension expression must be in a namespace.</source>
        <translation />
    </message>
    <message>
        <source>%1 matches newline characters</source>
        <translation />
    </message>
    <message>
        <source>Year %1 is invalid because it begins with %2.</source>
        <translation />
    </message>
    <message>
        <source>Content of attribute %1 does not match defined value constraint.</source>
        <translation />
    </message>
    <message>
        <source>Attribute %1 does not match the attribute wildcard.</source>
        <translation />
    </message>
    <message>
        <source>Complex type %1 contains attribute %2 twice.</source>
        <translation />
    </message>
    <message>
        <source>The second argument to %1 cannot be of type %2. It must be of type %3, %4, or %5.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 cannot have children.</source>
        <translation />
    </message>
    <message>
        <source>The name for a computed attribute cannot have the namespace URI %1 with the local name %2.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 is missing child element.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 can't be serialized because it appears outside the document element.</source>
        <translation />
    </message>
    <message>
        <source>Attribute %1 contains invalid data: %2</source>
        <translation />
    </message>
    <message>
        <source>%1 and %2 match the start and end of a line.</source>
        <translation />
    </message>
    <message>
        <source>%1 cannot be retrieved</source>
        <translation />
    </message>
    <message>
        <source>The value of the XSL-T version attribute must be a value of type %1, which %2 isn't.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 already defined.</source>
        <translation />
    </message>
    <message>
        <source>The prefix %1 cannot be bound.</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>%1 takes at most %n argument(s). %2 is therefore invalid.</source>
        <translation><numerusform>%1 potrebuje največ %n argument. %2 zato ni veljavno.</numerusform>
            <numerusform>%1 potrebuje največ %n argumenta. %2 zato ni veljavno.</numerusform>
            <numerusform>%1 potrebuje največ %n argumente. %2 zato ni veljavno.</numerusform>
            <numerusform>%1 potrebuje največ %n argumentov. %2 zato ni veljavno.</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 attribute of %2 element must contain %3, %4 or a list of URIs.</source>
        <translation />
    </message>
    <message>
        <source>If element %1 has no attribute %2, it cannot have attribute %3 or %4.</source>
        <translation />
    </message>
    <message>
        <source>A function already exists with the signature %1.</source>
        <translation />
    </message>
    <message>
        <source>Complex type %1 is not allowed to be abstract.</source>
        <translation />
    </message>
    <message>
        <source>Content of element %1 does not match defined value constraint.</source>
        <translation />
    </message>
    <message>
        <source>The item %1 did not match the required type %2.</source>
        <translation />
    </message>
    <message>
        <source>Non-unique value found for constraint %1.</source>
        <translation />
    </message>
    <message>
        <source>one or more</source>
        <translation />
    </message>
    <message>
        <source>%1 element has neither %2 attribute nor %3 child element.</source>
        <translation />
    </message>
    <message>
        <source>Duplicated element names %1 in %2 element.</source>
        <translation />
    </message>
    <message>
        <source>The encoding %1 is invalid. It must contain Latin characters only, must not contain whitespace, and must match the regular expression %2.</source>
        <translation />
    </message>
    <message>
        <source>%1 attribute of %2 element contains invalid content: {%3}.</source>
        <translation />
    </message>
    <message numerus="yes">
        <source>%1 requires at least %n argument(s). %2 is therefore invalid.</source>
        <translation><numerusform>%1 potrebuje najmanj %n argument. %2 zato ni veljavno.</numerusform>
            <numerusform>%1 potrebuje najmanj %n argumenta. %2 zato ni veljavno.</numerusform>
            <numerusform>%1 potrebuje najmanj %n argumente. %2 zato ni veljavno.</numerusform>
            <numerusform>%1 potrebuje najmanj %n argumentov. %2 zato ni veljavno.</numerusform>
        </translation>
    </message>
    <message>
        <source>Component with ID %1 has been defined previously.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 contains two attributes of type %2.</source>
        <translation />
    </message>
    <message>
        <source>The focus is undefined.</source>
        <translation />
    </message>
    <message>
        <source>%1 attribute of %2 element must be %3 or %4.</source>
        <translation />
    </message>
    <message>
        <source>%1 is an unknown schema type.</source>
        <translation />
    </message>
    <message>
        <source>The value for attribute %1 on element %2 must either be %3 or %4, not %5.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 contains not allowed text content.</source>
        <translation />
    </message>
    <message>
        <source>The namespace for a user defined function cannot be empty (try the predefined prefix %1 which exists for cases like this)</source>
        <translation />
    </message>
    <message>
        <source>%1 is not a valid value of type %2.</source>
        <translation />
    </message>
    <message>
        <source>Multiplication of a value of type %1 by %2 or %3 (plus or minus infinity) is not allowed.</source>
        <translation />
    </message>
    <message>
        <source>The variable %1 is unused</source>
        <translation />
    </message>
    <message>
        <source>The %1-axis is unsupported in XQuery</source>
        <translation />
    </message>
    <message>
        <source>No definition for element %1 available.</source>
        <translation />
    </message>
    <message>
        <source>Dividing a value of type %1 by %2 or %3 (plus or minus zero) is not allowed.</source>
        <translation />
    </message>
    <message>
        <source>Attribute %1 already defined.</source>
        <translation />
    </message>
    <message>
        <source>%1 attribute of %2 element must have the value %3 because the %4 attribute is set.</source>
        <translation />
    </message>
    <message>
        <source>Attribute %1 cannot have the value %2.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 is not allowed in this scope, possible elements are: %2.</source>
        <translation />
    </message>
    <message>
        <source>%1 attribute of %2 element has larger value than %3 attribute.</source>
        <translation />
    </message>
    <message>
        <source>It will not be possible to retrieve %1.</source>
        <translation />
    </message>
    <message>
        <source>In an XSL-T pattern, function %1 cannot have a third argument.</source>
        <translation />
    </message>
    <message>
        <source>The namespace URI in the name for a computed attribute cannot be %1.</source>
        <translation />
    </message>
    <message>
        <source>Specified type %1 is not known to the schema.</source>
        <translation />
    </message>
    <message>
        <source>Declaration for attribute %1 does not exist.</source>
        <translation />
    </message>
    <message>
        <source>zero or one</source>
        <translation />
    </message>
    <message>
        <source>Two namespace declaration attributes have the same name: %1.</source>
        <translation />
    </message>
    <message>
        <source>Effective Boolean Value cannot be calculated for a sequence containing two or more atomic values.</source>
        <translation />
    </message>
    <message>
        <source>%1 is an invalid %2</source>
        <translation />
    </message>
    <message>
        <source>The first argument to %1 cannot be of type %2. It must be a numeric type, xs:yearMonthDuration or xs:dayTimeDuration.</source>
        <translation />
    </message>
    <message>
        <source>Division (%1) by zero (%2) is undefined.</source>
        <translation />
    </message>
    <message>
        <source>No template by name %1 exists.</source>
        <translation />
    </message>
    <message>
        <source>%1 contains invalid data.</source>
        <translation />
    </message>
    <message>
        <source>The default collection is undefined</source>
        <translation />
    </message>
    <message>
        <source>Only the prefix %1 can be bound to %2 and vice versa.</source>
        <translation />
    </message>
    <message>
        <source>Value %1 of type %2 exceeds maximum (%3).</source>
        <translation />
    </message>
    <message>
        <source>Whitespace characters are removed, except when they appear in character classes</source>
        <translation />
    </message>
    <message>
        <source>Operator %1 cannot be used on type %2.</source>
        <translation />
    </message>
    <message>
        <source>The namespace %1 is reserved; therefore user defined functions may not use it. Try the predefined prefix %2, which exists for these cases.</source>
        <translation />
    </message>
    <message>
        <source>The target namespace of a %1 cannot be empty.</source>
        <translation />
    </message>
    <message>
        <source>Can not process unknown element %1, expected elements are: %2.</source>
        <translation />
    </message>
    <message>
        <source>%1 is an invalid namespace URI.</source>
        <translation />
    </message>
    <message>
        <source>The attribute %1 can only appear on the first %2 element.</source>
        <translation />
    </message>
    <message>
        <source>%1 element is not allowed in this context.</source>
        <translation />
    </message>
    <message>
        <source>Wildcard in derived particle is not a valid subset of wildcard in base particle.</source>
        <translation />
    </message>
    <message>
        <source>%1 attribute of %2 element contains invalid content: {%3} is not a value of type %4.</source>
        <translation />
    </message>
    <message>
        <source>Module imports must occur before function, variable, and option declarations.</source>
        <translation />
    </message>
    <message>
        <source>Complex type of derived element %1 cannot be validly derived from base element.</source>
        <translation />
    </message>
    <message>
        <source>Day %1 is outside the range %2..%3.</source>
        <translation />
    </message>
    <message>
        <source>Text nodes are not allowed at this location.</source>
        <translation />
    </message>
    <message>
        <source>%1 element must have either %2 attribute or %3 or %4 as child element.</source>
        <translation />
    </message>
    <message>
        <source>Attribute group %1 already defined.</source>
        <translation />
    </message>
    <message>
        <source>%1 was called.</source>
        <translation />
    </message>
    <message>
        <source>Identity constraint %1 already defined.</source>
        <translation />
    </message>
    <message>
        <source>%1 attribute of %2 element must either contain %3 or the other values.</source>
        <translation />
    </message>
    <message>
        <source>Element group %1 already defined.</source>
        <translation />
    </message>
    <message>
        <source>Attribute %1 contains invalid content.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 contains not allowed attributes.</source>
        <translation />
    </message>
    <message>
        <source>processContent of wildcard in derived particle is weaker than wildcard in base particle.</source>
        <translation />
    </message>
    <message>
        <source>The namespace of a user defined function in a library module must be equivalent to the module namespace. In other words, it should be %1 instead of %2</source>
        <translation />
    </message>
    <message>
        <source>Day %1 is invalid for month %2.</source>
        <translation />
    </message>
    <message>
        <source>Overflow: Can't represent date %1.</source>
        <translation />
    </message>
    <message>
        <source>Unknown XSL-T attribute %1.</source>
        <translation />
    </message>
    <message>
        <source>It is not possible to redeclare prefix %1.</source>
        <translation />
    </message>
    <message>
        <source>exactly one</source>
        <translation />
    </message>
    <message>
        <source>%1 is not valid according to %2.</source>
        <translation />
    </message>
    <message>
        <source>%1 is an invalid regular expression pattern: %2</source>
        <translation />
    </message>
    <message>
        <source>%1 element with %2 child element must not have a %3 attribute.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 is not allowed at this location.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 contains not allowed child element.</source>
        <translation />
    </message>
    <message>
        <source>Document is not a XML schema.</source>
        <translation />
    </message>
    <message>
        <source>%1 attribute of %2 element must have a value of %3 or %4.</source>
        <translation />
    </message>
    <message>
        <source>Dividing a value of type %1 by %2 (not-a-number) is not allowed.</source>
        <translation />
    </message>
    <message>
        <source>There is one IDREF value with no corresponding ID: %1.</source>
        <translation />
    </message>
    <message>
        <source>Field %1 has no simple type.</source>
        <translation />
    </message>
    <message>
        <source>Key constraint %1 contains absent fields.</source>
        <translation />
    </message>
    <message>
        <source>ID value '%1' is not unique.</source>
        <translation />
    </message>
    <message>
        <source>Type of %1 element must be a simple type, %2 is not.</source>
        <translation />
    </message>
    <message>
        <source>%1 attribute of %2 element must have a value of %3.</source>
        <translation />
    </message>
    <message>
        <source>Ambiguous rule match.</source>
        <translation />
    </message>
    <message>
        <source>Content of element %1 does not match its type definition: %2.</source>
        <translation />
    </message>
    <message>
        <source>Promoting %1 to %2 may cause loss of precision.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 contains unknown attribute %2.</source>
        <translation />
    </message>
    <message>
        <source>A default namespace declaration must occur before function, variable, and option declarations.</source>
        <translation />
    </message>
    <message>
        <source>Operator %1 cannot be used on atomic values of type %2 and %3.</source>
        <translation />
    </message>
    <message>
        <source>The module import feature is not supported</source>
        <translation />
    </message>
    <message>
        <source>The parameter %1 is passed, but no corresponding %2 exists.</source>
        <translation />
    </message>
    <message>
        <source>A value of type %1 cannot have an Effective Boolean Value.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 is missing required attribute %2.</source>
        <translation />
    </message>
    <message>
        <source>The data of a processing instruction cannot contain the string %1</source>
        <translation />
    </message>
    <message>
        <source>Time 24:%1:%2.%3 is invalid. Hour is 24, but minutes, seconds, and milliseconds are not all 0; </source>
        <translation />
    </message>
    <message>
        <source>Text or entity references not allowed inside %1 element</source>
        <translation />
    </message>
    <message>
        <source>Value %1 of type %2 is below minimum (%3).</source>
        <translation />
    </message>
    <message>
        <source>Required type is %1, but %2 was found.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 contains invalid content.</source>
        <translation />
    </message>
    <message>
        <source>%1 is an unsupported encoding.</source>
        <translation />
    </message>
    <message>
        <source>The name of an option must have a prefix. There is no default namespace for options.</source>
        <translation />
    </message>
    <message>
        <source>Type %1 already defined.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 must come last.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 is missing in derived particle.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 contains not allowed child content.</source>
        <translation />
    </message>
    <message>
        <source>The name %1 does not refer to any schema type.</source>
        <translation />
    </message>
    <message>
        <source>Prefix %1 can only be bound to %2 (and it is, in either case, pre-declared).</source>
        <translation />
    </message>
    <message>
        <source>Element %1 is not defined in this scope.</source>
        <translation />
    </message>
    <message>
        <source>The initialization of variable %1 depends on itself</source>
        <translation />
    </message>
    <message>
        <source>Content of %1 attribute of %2 element must not be from namespace %3.</source>
        <translation />
    </message>
    <message>
        <source>Month %1 is outside the range %2..%3.</source>
        <translation />
    </message>
    <message>
        <source>The name of a variable bound in a for-expression must be different from the positional variable. Hence, the two variables named %1 collide.</source>
        <translation />
    </message>
    <message>
        <source>%1 is not valid as a value of type %2.</source>
        <translation />
    </message>
    <message>
        <source>zero or more</source>
        <translation />
    </message>
    <message>
        <source>More than one value found for field %1.</source>
        <translation />
    </message>
    <message>
        <source>At least one time component must appear after the %1-delimiter.</source>
        <translation />
    </message>
    <message>
        <source>Overflow: Date can't be represented.</source>
        <translation />
    </message>
    <message>
        <source>%1 attribute of %2 element must not be %3.</source>
        <translation />
    </message>
    <message>
        <source>Prefix of qualified name %1 is not defined.</source>
        <translation />
    </message>
    <message>
        <source>No schema defined for validation.</source>
        <translation />
    </message>
    <message>
        <source>%1 is not a valid XML 1.0 character.</source>
        <translation />
    </message>
    <message>
        <source>The first argument to %1 cannot be of type %2. It must be of type %3, %4, or %5.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 is declared as abstract.</source>
        <translation />
    </message>
    <message>
        <source>%1 is not a whole number of minutes.</source>
        <translation />
    </message>
    <message>
        <source>%1 element is not allowed inside %2 element if %3 attribute is present.</source>
        <translation />
    </message>
    <message>
        <source>Namespace %1 can only be bound to %2 (and it is, in either case, pre-declared).</source>
        <translation />
    </message>
    <message>
        <source>Simple type of derived element %1 cannot be validly derived from base element.</source>
        <translation />
    </message>
    <message>
        <source>Element %1 must have at least one of the attributes %2 or %3.</source>
        <translation />
    </message>
    <message>
        <source>No external functions are supported. All supported functions can be used directly, without first declaring them as external</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeAnchors</name>
    <message>
        <source>Cannot anchor item to self.</source>
        <translation />
    </message>
    <message>
        <source>Possible anchor loop detected on horizontal anchor.</source>
        <translation />
    </message>
    <message>
        <source>Cannot anchor to a null item.</source>
        <translation />
    </message>
    <message>
        <source>Cannot specify top, bottom, and vcenter anchors.</source>
        <translation />
    </message>
    <message>
        <source>Possible anchor loop detected on centerIn.</source>
        <translation />
    </message>
    <message>
        <source>Baseline anchor cannot be used in conjunction with top, bottom, or vcenter anchors.</source>
        <translation />
    </message>
    <message>
        <source>Cannot specify left, right, and hcenter anchors.</source>
        <translation />
    </message>
    <message>
        <source>Possible anchor loop detected on vertical anchor.</source>
        <translation />
    </message>
    <message>
        <source>Cannot anchor a horizontal edge to a vertical edge.</source>
        <translation />
    </message>
    <message>
        <source>Cannot anchor a vertical edge to a horizontal edge.</source>
        <translation />
    </message>
    <message>
        <source>Cannot anchor to an item that isn't a parent or sibling.</source>
        <translation />
    </message>
    <message>
        <source>Possible anchor loop detected on fill.</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeTypeData</name>
    <message>
        <source>%1 %2</source>
        <translation />
    </message>
    <message>
        <source>Type %1 unavailable</source>
        <translation />
    </message>
    <message>
        <source>Namespace %1 cannot be used as a type</source>
        <translation />
    </message>
    <message>
        <source>Script %1 unavailable</source>
        <translation />
    </message>
</context>
<context>
    <name>Phonon::MMF::AudioEqualizer</name>
    <message>
        <source>%1 Hz</source>
        <translation />
    </message>
</context>
<context>
    <name>QFontDialog</name>
    <message>
        <source>&amp;Font</source>
        <translation />
    </message>
    <message>
        <source>&amp;Size</source>
        <translation />
    </message>
    <message>
        <source>Sample</source>
        <translation />
    </message>
    <message>
        <source>Font st&amp;yle</source>
        <translation />
    </message>
    <message>
        <source>Wr&amp;iting System</source>
        <translation />
    </message>
    <message>
        <source>Select Font</source>
        <translation />
    </message>
    <message>
        <source>&amp;Underline</source>
        <translation />
    </message>
    <message>
        <source>Effects</source>
        <translation />
    </message>
    <message>
        <source>Stri&amp;keout</source>
        <translation />
    </message>
</context>
<context>
    <name>Q3Wizard</name>
    <message>
        <source>&amp;Help</source>
        <translation />
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation />
    </message>
    <message>
        <source>&amp;Finish</source>
        <translation />
    </message>
    <message>
        <source>&amp;Next &gt;</source>
        <translation />
    </message>
    <message>
        <source>&lt; &amp;Back</source>
        <translation />
    </message>
</context>
<context>
    <name>QWorkspace</name>
    <message>
        <source>&amp;Move</source>
        <translation />
    </message>
    <message>
        <source>&amp;Size</source>
        <translation />
    </message>
    <message>
        <source>Close</source>
        <translation />
    </message>
    <message>
        <source>Minimize</source>
        <translation />
    </message>
    <message>
        <source>Stay on &amp;Top</source>
        <translation />
    </message>
    <message>
        <source>&amp;Close</source>
        <translation />
    </message>
    <message>
        <source>%1 - [%2]</source>
        <translation />
    </message>
    <message>
        <source>Sh&amp;ade</source>
        <translation />
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation />
    </message>
    <message>
        <source>&amp;Unshade</source>
        <translation />
    </message>
    <message>
        <source>Mi&amp;nimize</source>
        <translation />
    </message>
    <message>
        <source>Ma&amp;ximize</source>
        <translation />
    </message>
    <message>
        <source>Restore Down</source>
        <translation />
    </message>
</context>
<context>
    <name>QColorDialog</name>
    <message>
        <source>&amp;Red:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Sat:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Val:</source>
        <translation />
    </message>
    <message>
        <source>Hu&amp;e:</source>
        <translation />
    </message>
    <message>
        <source>Select Color</source>
        <translation />
    </message>
    <message>
        <source>&amp;Add to Custom Colors</source>
        <translation />
    </message>
    <message>
        <source>Bl&amp;ue:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Green:</source>
        <translation />
    </message>
    <message>
        <source>&amp;Basic colors</source>
        <translation />
    </message>
    <message>
        <source>&amp;Custom colors</source>
        <translation />
    </message>
    <message>
        <source>A&amp;lpha channel:</source>
        <translation />
    </message>
</context>
<context>
    <name>QNetworkSessionPrivateImpl</name>
    <message>
        <source>Roaming error</source>
        <translation />
    </message>
    <message>
        <source>The session was aborted by the user or system.</source>
        <translation />
    </message>
    <message>
        <source>The requested operation is not supported by the system.</source>
        <translation />
    </message>
    <message>
        <source>Session aborted by user or system</source>
        <translation />
    </message>
    <message>
        <source>Unidentified Error</source>
        <translation />
    </message>
    <message>
        <source>Roaming was aborted or is not possible.</source>
        <translation />
    </message>
    <message>
        <source>The specified configuration cannot be used.</source>
        <translation />
    </message>
    <message>
        <source>Unknown session error.</source>
        <translation />
    </message>
</context>
<context>
    <name>QSharedMemory</name>
    <message>
        <source>%1: system-imposed size restrictions</source>
        <translation />
    </message>
    <message>
        <source>%1: doesn't exists</source>
        <translation />
    </message>
    <message>
        <source>%1: key is empty</source>
        <translation />
    </message>
    <message>
        <source>%1: key error</source>
        <translation />
    </message>
    <message>
        <source>%1: create size is less then 0</source>
        <translation />
    </message>
    <message>
        <source>%1: already exists</source>
        <translation />
    </message>
    <message>
        <source>%1: unknown error %2</source>
        <translation />
    </message>
    <message>
        <source>%1: invalid size</source>
        <translation />
    </message>
    <message>
        <source>%1: unable to make key</source>
        <translation />
    </message>
    <message>
        <source>%1: unable to set key on lock</source>
        <translation />
    </message>
    <message>
        <source>%1: unable to unlock</source>
        <translation />
    </message>
    <message>
        <source>%1: permission denied</source>
        <translation />
    </message>
    <message>
        <source>%1: ftok failed</source>
        <translation />
    </message>
    <message>
        <source>%1: out of resources</source>
        <translation />
    </message>
    <message>
        <source>%1: not attached</source>
        <translation />
    </message>
    <message>
        <source>%1: UNIX key file doesn't exist</source>
        <translation />
    </message>
    <message>
        <source>%1: doesn't exist</source>
        <translation />
    </message>
    <message>
        <source>%1: size query failed</source>
        <translation />
    </message>
    <message>
        <source>%1: unable to lock</source>
        <translation />
    </message>
</context>
<context>
    <name>QXmlStream</name>
    <message>
        <source>Reference to unparsed entity '%1'.</source>
        <translation />
    </message>
    <message>
        <source>Unexpected character '%1' in public id literal.</source>
        <translation />
    </message>
    <message>
        <source>Illegal namespace declaration.</source>
        <translation />
    </message>
    <message>
        <source>Invalid XML character.</source>
        <translation />
    </message>
    <message>
        <source>Expected character data.</source>
        <translation />
    </message>
    <message>
        <source>Standalone accepts only yes or no.</source>
        <translation />
    </message>
    <message>
        <source>Invalid XML version string.</source>
        <translation />
    </message>
    <message>
        <source>Invalid processing instruction name.</source>
        <translation />
    </message>
    <message>
        <source>Namespace prefix '%1' not declared</source>
        <translation />
    </message>
    <message>
        <source>Entity '%1' not declared.</source>
        <translation />
    </message>
    <message>
        <source>%1 is an invalid processing instruction name.</source>
        <translation />
    </message>
    <message>
        <source>The standalone pseudo attribute must appear after the encoding.</source>
        <translation />
    </message>
    <message>
        <source>Sequence ']]&gt;' not allowed in content.</source>
        <translation />
    </message>
    <message>
        <source>%1 is an invalid encoding name.</source>
        <translation />
    </message>
    <message>
        <source>, but got '</source>
        <translation />
    </message>
    <message>
        <source>Start tag expected.</source>
        <translation />
    </message>
    <message>
        <source>Invalid character reference.</source>
        <translation />
    </message>
    <message>
        <source>Reference to external entity '%1' in attribute value.</source>
        <translation />
    </message>
    <message>
        <source>Expected </source>
        <translation />
    </message>
    <message>
        <source>Invalid document.</source>
        <translation />
    </message>
    <message>
        <source>Opening and ending tag mismatch.</source>
        <translation />
    </message>
    <message>
        <source>Encountered incorrectly encoded content.</source>
        <translation />
    </message>
    <message>
        <source>Invalid attribute in XML declaration.</source>
        <translation />
    </message>
    <message>
        <source>Attribute redefined.</source>
        <translation />
    </message>
    <message>
        <source>%1 is an invalid PUBLIC identifier.</source>
        <translation />
    </message>
    <message>
        <source>Extra content at end of document.</source>
        <translation />
    </message>
    <message>
        <source>Invalid XML name.</source>
        <translation />
    </message>
    <message>
        <source>Premature end of document.</source>
        <translation />
    </message>
    <message>
        <source>XML declaration not at start of document.</source>
        <translation />
    </message>
    <message>
        <source>Recursive entity detected.</source>
        <translation />
    </message>
    <message>
        <source>Unsupported XML version.</source>
        <translation />
    </message>
    <message>
        <source>Unexpected '</source>
        <translation />
    </message>
    <message>
        <source>Invalid entity value.</source>
        <translation />
    </message>
    <message>
        <source>Encoding %1 is unsupported</source>
        <translation />
    </message>
    <message>
        <source>NDATA in parameter entity declaration.</source>
        <translation />
    </message>
</context>
<context>
    <name>QProcess</name>
    <message>
        <source>Error writing to process</source>
        <translation />
    </message>
    <message>
        <source>Resource error (fork failure): %1</source>
        <translation />
    </message>
    <message>
        <source>Error reading from process</source>
        <translation />
    </message>
    <message>
        <source>Process failed to start: %1</source>
        <translation />
    </message>
    <message>
        <source>Could not open input redirection for reading</source>
        <translation />
    </message>
    <message>
        <source>No program defined</source>
        <translation />
    </message>
    <message>
        <source>Could not open output redirection for writing</source>
        <translation />
    </message>
    <message>
        <source>Process operation timed out</source>
        <translation />
    </message>
    <message>
        <source>Process crashed</source>
        <translation />
    </message>
</context>
<context>
    <name>QNativeSocketEngine</name>
    <message>
        <source>The proxy type is invalid for this operation</source>
        <translation />
    </message>
    <message>
        <source>Network operation timed out</source>
        <translation />
    </message>
    <message>
        <source>The remote host closed the connection</source>
        <translation />
    </message>
    <message>
        <source>Invalid socket descriptor</source>
        <translation />
    </message>
    <message>
        <source>Host unreachable</source>
        <translation />
    </message>
    <message>
        <source>Protocol type not supported</source>
        <translation />
    </message>
    <message>
        <source>Datagram was too large to send</source>
        <translation />
    </message>
    <message>
        <source>Attempt to use IPv6 socket on a platform with no IPv6 support</source>
        <translation />
    </message>
    <message>
        <source>Unable to receive a message</source>
        <translation />
    </message>
    <message>
        <source>Permission denied</source>
        <translation />
    </message>
    <message>
        <source>Connection refused</source>
        <translation />
    </message>
    <message>
        <source>Unable to write</source>
        <translation />
    </message>
    <message>
        <source>Another socket is already listening on the same port</source>
        <translation />
    </message>
    <message>
        <source>Unable to send a message</source>
        <translation />
    </message>
    <message>
        <source>The bound address is already in use</source>
        <translation />
    </message>
    <message>
        <source>Connection timed out</source>
        <translation />
    </message>
    <message>
        <source>Network error</source>
        <translation />
    </message>
    <message>
        <source>Unsupported socket operation</source>
        <translation />
    </message>
    <message>
        <source>Operation on non-socket</source>
        <translation />
    </message>
    <message>
        <source>Unable to initialize broadcast socket</source>
        <translation />
    </message>
    <message>
        <source>Unknown error</source>
        <translation />
    </message>
    <message>
        <source>Unable to initialize non-blocking socket</source>
        <translation />
    </message>
    <message>
        <source>The address is protected</source>
        <translation />
    </message>
    <message>
        <source>Network unreachable</source>
        <translation />
    </message>
    <message>
        <source>The address is not available</source>
        <translation />
    </message>
    <message>
        <source>Out of resources</source>
        <translation />
    </message>
</context>
<context>
    <name>QNetworkAccessFtpBackend</name>
    <message>
        <source>No suitable proxy found</source>
        <translation />
    </message>
    <message>
        <source>Error while downloading %1: %2</source>
        <translation />
    </message>
    <message>
        <source>Error while uploading %1: %2</source>
        <translation />
    </message>
    <message>
        <source>Cannot open %1: is a directory</source>
        <translation />
    </message>
    <message>
        <source>Logging in to %1 failed: authentication required</source>
        <translation />
    </message>
</context>
<context>
    <name>QNetworkAccessHttpBackend</name>
    <message>
        <source>No suitable proxy found</source>
        <translation />
    </message>
</context>
<context>
    <name>QCheckBox</name>
    <message>
        <source>Check</source>
        <translation />
    </message>
    <message>
        <source>Toggle</source>
        <translation />
    </message>
    <message>
        <source>Uncheck</source>
        <translation />
    </message>
</context>
<context>
    <name>QRadioButton</name>
    <message>
        <source>Check</source>
        <translation />
    </message>
</context>
<context>
    <name>Q3TitleBar</name>
    <message>
        <source>Close</source>
        <translation />
    </message>
    <message>
        <source>Minimize</source>
        <translation />
    </message>
    <message>
        <source>Displays the name of the window and contains controls to manipulate it</source>
        <translation />
    </message>
    <message>
        <source>Makes the window full screen</source>
        <translation />
    </message>
    <message>
        <source>System</source>
        <translation />
    </message>
    <message>
        <source>Maximize</source>
        <translation />
    </message>
    <message>
        <source>Contains commands to manipulate the window</source>
        <translation />
    </message>
    <message>
        <source>Restore up</source>
        <translation />
    </message>
    <message>
        <source>Puts a minimized window back to normal</source>
        <translation />
    </message>
    <message>
        <source>Closes the window</source>
        <translation />
    </message>
    <message>
        <source>Puts a maximized window back to normal</source>
        <translation />
    </message>
    <message>
        <source>Moves the window out of the way</source>
        <translation />
    </message>
    <message>
        <source>Restore down</source>
        <translation />
    </message>
</context>
<context>
    <name>QScriptNewBreakpointWidget</name>
    <message>
        <source>Close</source>
        <translation />
    </message>
</context>
<context>
    <name>Phonon::</name>
    <message>
        <source>Games</source>
        <translation />
    </message>
    <message>
        <source>Music</source>
        <translation />
    </message>
    <message>
        <source>Video</source>
        <translation />
    </message>
    <message>
        <source>Communication</source>
        <translation />
    </message>
    <message>
        <source>Accessibility</source>
        <translation />
    </message>
    <message>
        <source>Notifications</source>
        <translation />
    </message>
</context>
<context>
    <name>Phonon::VolumeSlider</name>
    <message>
        <source>Muted</source>
        <translation />
    </message>
    <message>
        <source>Volume: %1%</source>
        <translation />
    </message>
    <message>
        <source>Use this slider to adjust the volume. The leftmost position is 0%, the rightmost is %1%</source>
        <translation />
    </message>
</context>
<context>
    <name>Q3LocalFs</name>
    <message>
        <source>Could not open
%1</source>
        <translation />
    </message>
    <message>
        <source>Could not remove file or directory
%1</source>
        <translation />
    </message>
    <message>
        <source>Could not create directory
%1</source>
        <translation />
    </message>
    <message>
        <source>Could not read directory
%1</source>
        <translation />
    </message>
    <message>
        <source>Could not rename
%1
to
%2</source>
        <translation />
    </message>
    <message>
        <source>Could not write
%1</source>
        <translation />
    </message>
</context>
<context>
    <name>QDial</name>
    <message>
        <source>QDial</source>
        <translation />
    </message>
    <message>
        <source>SliderHandle</source>
        <translation />
    </message>
    <message>
        <source>SpeedoMeter</source>
        <translation />
    </message>
</context>
<context>
    <name>QAccessibleButton</name>
    <message>
        <source>Press</source>
        <translation />
    </message>
</context>
<context>
    <name>QSocks5SocketEngine</name>
    <message>
        <source>Network operation timed out</source>
        <translation />
    </message>
    <message>
        <source>Connection to proxy closed prematurely</source>
        <translation />
    </message>
    <message>
        <source>Proxy authentication failed: %1</source>
        <translation />
    </message>
    <message>
        <source>Proxy authentication failed</source>
        <translation />
    </message>
    <message>
        <source>General SOCKSv5 server failure</source>
        <translation />
    </message>
    <message>
        <source>Unknown SOCKSv5 proxy error code 0x%1</source>
        <translation />
    </message>
    <message>
        <source>Connection not allowed by SOCKSv5 server</source>
        <translation />
    </message>
    <message>
        <source>SOCKSv5 command not supported</source>
        <translation />
    </message>
    <message>
        <source>Connection to proxy timed out</source>
        <translation />
    </message>
    <message>
        <source>Proxy host not found</source>
        <translation />
    </message>
    <message>
        <source>TTL expired</source>
        <translation />
    </message>
    <message>
        <source>Address type not supported</source>
        <translation />
    </message>
    <message>
        <source>Connection to proxy refused</source>
        <translation />
    </message>
    <message>
        <source>SOCKS version 5 protocol error</source>
        <translation />
    </message>
</context>
<context>
    <name>Phonon::MMF</name>
    <message>
        <source>Could not connect</source>
        <translation />
    </message>
    <message>
        <source>Access denied</source>
        <translation />
    </message>
    <message>
        <source>Invalid protocol</source>
        <translation />
    </message>
    <message>
        <source>No error</source>
        <translation />
    </message>
    <message>
        <source>Audio Output</source>
        <translation />
    </message>
    <message>
        <source>Disconnected</source>
        <translation />
    </message>
    <message>
        <source>Server alert</source>
        <translation />
    </message>
    <message>
        <source>Out of memory</source>
        <translation />
    </message>
    <message>
        <source>Not supported</source>
        <translation />
    </message>
    <message>
        <source>Invalid URL</source>
        <translation />
    </message>
    <message>
        <source>Video output error</source>
        <translation />
    </message>
    <message>
        <source>In use</source>
        <translation />
    </message>
    <message>
        <source>Insufficient bandwidth</source>
        <translation />
    </message>
    <message>
        <source>Already exists</source>
        <translation />
    </message>
    <message>
        <source>Audio output error</source>
        <translation />
    </message>
    <message>
        <source>Multicast error</source>
        <translation />
    </message>
    <message>
        <source>Proxy server not supported</source>
        <translation />
    </message>
    <message>
        <source>Permission denied</source>
        <translation />
    </message>
    <message>
        <source>Not found</source>
        <translation />
    </message>
    <message>
        <source>Not ready</source>
        <translation />
    </message>
    <message>
        <source>Proxy server error</source>
        <translation />
    </message>
    <message>
        <source>The audio output device</source>
        <translation />
    </message>
    <message>
        <source>Streaming not supported</source>
        <translation />
    </message>
    <message>
        <source>Audio or video components could not be played</source>
        <translation />
    </message>
    <message>
        <source>Underflow</source>
        <translation />
    </message>
    <message>
        <source>Network communication error</source>
        <translation />
    </message>
    <message>
        <source>Overflow</source>
        <translation />
    </message>
    <message>
        <source>Network unavailable</source>
        <translation />
    </message>
    <message>
        <source>Path not found</source>
        <translation />
    </message>
    <message>
        <source>Decoder error</source>
        <translation />
    </message>
    <message>
        <source>DRM error</source>
        <translation />
    </message>
    <message>
        <source>Unknown error (%1)</source>
        <translation />
    </message>
</context>
<context>
    <name>QRegExp</name>
    <message>
        <source>invalid category</source>
        <translation />
    </message>
    <message>
        <source>bad lookahead syntax</source>
        <translation />
    </message>
    <message>
        <source>no error occurred</source>
        <translation />
    </message>
    <message>
        <source>missing left delim</source>
        <translation />
    </message>
    <message>
        <source>bad char class syntax</source>
        <translation />
    </message>
    <message>
        <source>disabled feature used</source>
        <translation />
    </message>
    <message>
        <source>invalid octal value</source>
        <translation />
    </message>
    <message>
        <source>bad repetition syntax</source>
        <translation />
    </message>
    <message>
        <source>met internal limit</source>
        <translation />
    </message>
    <message>
        <source>invalid interval</source>
        <translation />
    </message>
    <message>
        <source>unexpected end</source>
        <translation />
    </message>
</context>
<context>
    <name>QWhatsThisAction</name>
    <message>
        <source>What's This?</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeTextInput</name>
    <message>
        <source>Could not instantiate cursor delegate</source>
        <translation />
    </message>
    <message>
        <source>Could not load cursor delegate</source>
        <translation />
    </message>
</context>
<context>
    <name>Q3UrlOperator</name>
    <message>
        <source>The protocol `%1' does not support getting files</source>
        <translation />
    </message>
    <message>
        <source>The protocol `%1' does not support renaming files or directories</source>
        <translation />
    </message>
    <message>
        <source>The protocol `%1' does not support listing directories</source>
        <translation />
    </message>
    <message>
        <source>(unknown)</source>
        <translation />
    </message>
    <message>
        <source>The protocol `%1' does not support removing files or directories</source>
        <translation />
    </message>
    <message>
        <source>The protocol `%1' does not support putting files</source>
        <translation />
    </message>
    <message>
        <source>The protocol `%1' is not supported</source>
        <translation />
    </message>
    <message>
        <source>The protocol `%1' does not support copying or moving files or directories</source>
        <translation />
    </message>
    <message>
        <source>The protocol `%1' does not support creating new directories</source>
        <translation />
    </message>
</context>
<context>
    <name>QFtp</name>
    <message>
        <source>Listing directory failed:
%1</source>
        <translation />
    </message>
    <message>
        <source>Creating directory failed:
%1</source>
        <translation />
    </message>
    <message>
        <source>Not connected</source>
        <translation />
    </message>
    <message>
        <source>Connection refused for data connection</source>
        <translation />
    </message>
    <message>
        <source>Login failed:
%1</source>
        <translation />
    </message>
    <message>
        <source>Downloading file failed:
%1</source>
        <translation />
    </message>
    <message>
        <source>Connected to host</source>
        <translation />
    </message>
    <message>
        <source>Connection timed out to host %1</source>
        <translation />
    </message>
    <message>
        <source>Connected to host %1</source>
        <translation />
    </message>
    <message>
        <source>Connecting to host failed:
%1</source>
        <translation />
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation />
    </message>
    <message>
        <source>Uploading file failed:
%1</source>
        <translation />
    </message>
    <message>
        <source>Changing directory failed:
%1</source>
        <translation />
    </message>
    <message>
        <source>Host found</source>
        <translation />
    </message>
    <message>
        <source>Removing directory failed:
%1</source>
        <translation />
    </message>
    <message>
        <source>Connection refused to host %1</source>
        <translation />
    </message>
    <message>
        <source>Connection to %1 closed</source>
        <translation />
    </message>
    <message>
        <source>Removing file failed:
%1</source>
        <translation />
    </message>
    <message>
        <source>Host %1 found</source>
        <translation />
    </message>
    <message>
        <source>Unknown error</source>
        <translation />
    </message>
    <message>
        <source>Connection closed</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeListModel</name>
    <message>
        <source>set: value is not an object</source>
        <translation />
    </message>
    <message>
        <source>ListElement: cannot use script for property value</source>
        <translation />
    </message>
    <message>
        <source>ListModel: undefined property '%1'</source>
        <translation />
    </message>
    <message>
        <source>ListElement: cannot contain nested elements</source>
        <translation />
    </message>
    <message>
        <source>insert: value is not an object</source>
        <translation />
    </message>
    <message>
        <source>remove: index %1 out of range</source>
        <translation />
    </message>
    <message>
        <source>set: index %1 out of range</source>
        <translation />
    </message>
    <message>
        <source>append: value is not an object</source>
        <translation />
    </message>
    <message>
        <source>move: out of range</source>
        <translation />
    </message>
    <message>
        <source>insert: index %1 out of range</source>
        <translation />
    </message>
    <message>
        <source>ListElement: cannot use reserved "id" property</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeEngine</name>
    <message>
        <source>Version mismatch: expected %1, found %2</source>
        <translation />
    </message>
    <message>
        <source>executeSql called outside transaction()</source>
        <translation />
    </message>
    <message>
        <source>Read-only Transaction</source>
        <translation />
    </message>
    <message>
        <source>SQL transaction failed</source>
        <translation />
    </message>
    <message>
        <source>transaction: missing callback</source>
        <translation />
    </message>
    <message>
        <source>SQL: database version mismatch</source>
        <translation />
    </message>
</context>
<context>
    <name>Phonon::MMF::EnvironmentalReverb</name>
    <message>
        <source>Reverb delay (ms)</source>
        <translation />
    </message>
    <message>
        <source>Density (%)</source>
        <translation />
    </message>
    <message>
        <source>Room HF level</source>
        <translation />
    </message>
    <message>
        <source>Reverb level (mB)</source>
        <translation />
    </message>
    <message>
        <source>Diffusion (%)</source>
        <translation />
    </message>
    <message>
        <source>Decay HF ratio (%)</source>
        <translation />
    </message>
    <message>
        <source>Decay time (ms)</source>
        <translation />
    </message>
    <message>
        <source>Reflections level (mB)</source>
        <translation />
    </message>
    <message>
        <source>Room level (mB)</source>
        <translation />
    </message>
    <message>
        <source>Reflections delay (ms)</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeVME</name>
    <message>
        <source>Cannot assign object to list</source>
        <translation />
    </message>
    <message>
        <source>Cannot assign object type %1 with no default method</source>
        <translation />
    </message>
    <message>
        <source>Cannot connect mismatched signal/slot %1 %vs. %2</source>
        <translation />
    </message>
    <message>
        <source>Cannot assign value %1 to property %2</source>
        <translation />
    </message>
    <message>
        <source>Cannot set properties on %1 as it is null</source>
        <translation />
    </message>
    <message>
        <source>Cannot assign an object to signal property %1</source>
        <translation />
    </message>
    <message>
        <source>Unable to create object of type %1</source>
        <translation />
    </message>
    <message>
        <source>Cannot assign object to interface property</source>
        <translation />
    </message>
    <message>
        <source>Unable to create attached object</source>
        <translation />
    </message>
</context>
<context>
    <name>QDB2Driver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation />
    </message>
    <message>
        <source>Unable to set autocommit</source>
        <translation />
    </message>
    <message>
        <source>Unable to connect</source>
        <translation />
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation />
    </message>
</context>
<context>
    <name>QIBaseDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation />
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation />
    </message>
    <message>
        <source>Error opening database</source>
        <translation />
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation />
    </message>
</context>
<context>
    <name>QIBaseResult</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation />
    </message>
    <message>
        <source>Unable to open BLOB</source>
        <translation />
    </message>
    <message>
        <source>Could not describe statement</source>
        <translation />
    </message>
    <message>
        <source>Could not describe input statement</source>
        <translation />
    </message>
    <message>
        <source>Could not allocate statement</source>
        <translation />
    </message>
    <message>
        <source>Unable to write BLOB</source>
        <translation />
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation />
    </message>
    <message>
        <source>Unable to close statement</source>
        <translation />
    </message>
    <message>
        <source>Could not get query info</source>
        <translation />
    </message>
    <message>
        <source>Could not find array</source>
        <translation />
    </message>
    <message>
        <source>Could not get array data</source>
        <translation />
    </message>
    <message>
        <source>Unable to execute query</source>
        <translation />
    </message>
    <message>
        <source>Could not prepare statement</source>
        <translation />
    </message>
    <message>
        <source>Could not fetch next item</source>
        <translation />
    </message>
    <message>
        <source>Could not get statement info</source>
        <translation />
    </message>
    <message>
        <source>Unable to create BLOB</source>
        <translation />
    </message>
    <message>
        <source>Unable to read BLOB</source>
        <translation />
    </message>
</context>
<context>
    <name>QMYSQLDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation />
    </message>
    <message>
        <source>Unable to open database '</source>
        <translation />
    </message>
    <message>
        <source>Unable to connect</source>
        <translation />
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation />
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation />
    </message>
</context>
<context>
    <name>QOCIDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation />
    </message>
    <message>
        <source>Unable to initialize</source>
        <translation />
    </message>
    <message>
        <source>Unable to logon</source>
        <translation />
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation />
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation />
    </message>
</context>
<context>
    <name>QODBCDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation />
    </message>
    <message>
        <source>Unable to enable autocommit</source>
        <translation />
    </message>
    <message>
        <source>Unable to disable autocommit</source>
        <translation />
    </message>
    <message>
        <source>Unable to connect - Driver doesn't support all functionality required</source>
        <translation />
    </message>
    <message>
        <source>Unable to connect</source>
        <translation />
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation />
    </message>
</context>
<context>
    <name>QSQLite2Driver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation />
    </message>
    <message>
        <source>Error opening database</source>
        <translation />
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation />
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation />
    </message>
</context>
<context>
    <name>QSQLiteDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation />
    </message>
    <message>
        <source>Error closing database</source>
        <translation />
    </message>
    <message>
        <source>Error opening database</source>
        <translation />
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation />
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation />
    </message>
</context>
<context>
    <name>QAbstractSocket</name>
    <message>
        <source>Host not found</source>
        <translation />
    </message>
    <message>
        <source>Connection refused</source>
        <translation />
    </message>
    <message>
        <source>Connection timed out</source>
        <translation />
    </message>
    <message>
        <source>Socket is not connected</source>
        <translation />
    </message>
    <message>
        <source>Socket operation timed out</source>
        <translation />
    </message>
    <message>
        <source>Network unreachable</source>
        <translation />
    </message>
    <message>
        <source>Operation on socket is not supported</source>
        <translation />
    </message>
</context>
<context>
    <name>QHostInfoAgent</name>
    <message>
        <source>Host not found</source>
        <translation />
    </message>
    <message>
        <source>No host name given</source>
        <translation />
    </message>
    <message>
        <source>Unknown address type</source>
        <translation />
    </message>
    <message>
        <source>Unknown error</source>
        <translation />
    </message>
    <message>
        <source>Invalid hostname</source>
        <translation />
    </message>
</context>
<context>
    <name>Phonon::Gstreamer::MediaObject</name>
    <message>
        <source>Could not open media source.</source>
        <translation />
    </message>
    <message>
        <source>Missing codec helper script assistant.</source>
        <translation />
    </message>
    <message>
        <source>Could not decode media source.</source>
        <translation />
    </message>
    <message>
        <source>Invalid source type.</source>
        <translation />
    </message>
    <message>
        <source>Cannot start playback. 

Check your GStreamer installation and make sure you 
have libgstreamer-plugins-base installed.</source>
        <translation />
    </message>
    <message>
        <source>Plugin codec installation failed for codec: %0</source>
        <translation />
    </message>
    <message>
        <source>Could not open audio device. The device is already in use.</source>
        <translation />
    </message>
    <message>
        <source>A required codec is missing. You need to install the following codec(s) to play this content: %0</source>
        <translation />
    </message>
    <message>
        <source>Could not locate media source.</source>
        <translation />
    </message>
</context>
<context>
    <name>QXmlPatternistCLI</name>
    <message>
        <source>Unknown location</source>
        <translation />
    </message>
    <message>
        <source>Error %1 in %2, at line %3, column %4: %5</source>
        <translation />
    </message>
    <message>
        <source>Warning in %1: %2</source>
        <translation />
    </message>
    <message>
        <source>Error %1 in %2: %3</source>
        <translation />
    </message>
    <message>
        <source>Warning in %1, at line %2, column %3: %4</source>
        <translation />
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <source>Connection refused (or timed out)</source>
        <translation />
    </message>
    <message>
        <source>Data corrupted</source>
        <translation />
    </message>
    <message>
        <source>Connected to host</source>
        <translation />
    </message>
    <message>
        <source>Connected to host %1</source>
        <translation />
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation />
    </message>
    <message>
        <source>Unknown authentication method</source>
        <translation />
    </message>
    <message>
        <source>Host requires authentication</source>
        <translation />
    </message>
    <message>
        <source>Error writing response to device</source>
        <translation />
    </message>
    <message>
        <source>HTTPS connection requested but SSL support not compiled in</source>
        <translation />
    </message>
    <message>
        <source>Host found</source>
        <translation />
    </message>
    <message>
        <source>Connection refused</source>
        <translation />
    </message>
    <message>
        <source>Proxy authentication required</source>
        <translation />
    </message>
    <message>
        <source>Unknown protocol specified</source>
        <translation />
    </message>
    <message>
        <source>HTTP request failed</source>
        <translation />
    </message>
    <message>
        <source>Proxy requires authentication</source>
        <translation />
    </message>
    <message>
        <source>Authentication required</source>
        <translation />
    </message>
    <message>
        <source>SSL handshake failed</source>
        <translation />
    </message>
    <message>
        <source>Connection to %1 closed</source>
        <translation />
    </message>
    <message>
        <source>Invalid HTTP chunked body</source>
        <translation />
    </message>
    <message>
        <source>Host %1 found</source>
        <translation />
    </message>
    <message>
        <source>Wrong content length</source>
        <translation />
    </message>
    <message>
        <source>Unknown error</source>
        <translation />
    </message>
    <message>
        <source>Invalid HTTP response header</source>
        <translation />
    </message>
    <message>
        <source>Connection closed</source>
        <translation />
    </message>
    <message>
        <source>No server set to connect to</source>
        <translation />
    </message>
    <message>
        <source>Server closed connection unexpectedly</source>
        <translation />
    </message>
    <message>
        <source>Request aborted</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeImportDatabase</name>
    <message>
        <source>is ambiguous. Found in %1 and in %2</source>
        <translation />
    </message>
    <message>
        <source>local directory</source>
        <translation />
    </message>
    <message>
        <source>import "%1" has no qmldir and no namespace</source>
        <translation />
    </message>
    <message>
        <source>- %1 is not a namespace</source>
        <translation />
    </message>
    <message>
        <source>module "%1" definition "%2" not readable</source>
        <translation />
    </message>
    <message>
        <source>module "%1" plugin "%2" not found</source>
        <translation />
    </message>
    <message>
        <source>is not a type</source>
        <translation />
    </message>
    <message>
        <source>module "%1" is not installed</source>
        <translation />
    </message>
    <message>
        <source>module "%1" version %2.%3 is not installed</source>
        <translation />
    </message>
    <message>
        <source>- nested namespaces not allowed</source>
        <translation />
    </message>
    <message>
        <source>plugin cannot be loaded for module "%1": %2</source>
        <translation />
    </message>
    <message>
        <source>is instantiated recursively</source>
        <translation />
    </message>
    <message>
        <source>is ambiguous. Found in %1 in version %2.%3 and %4.%5</source>
        <translation />
    </message>
    <message>
        <source>"%1": no such directory</source>
        <translation />
    </message>
</context>
<context>
    <name>QXml</name>
    <message>
        <source>unparsed entity reference in wrong context</source>
        <translation />
    </message>
    <message>
        <source>external parsed general entity reference not allowed in DTD</source>
        <translation />
    </message>
    <message>
        <source>wrong value for standalone declaration</source>
        <translation />
    </message>
    <message>
        <source>encoding declaration or standalone declaration expected while reading the XML declaration</source>
        <translation />
    </message>
    <message>
        <source>no error occurred</source>
        <translation />
    </message>
    <message>
        <source>error occurred while parsing reference</source>
        <translation />
    </message>
    <message>
        <source>standalone declaration expected while reading the XML declaration</source>
        <translation />
    </message>
    <message>
        <source>invalid name for processing instruction</source>
        <translation />
    </message>
    <message>
        <source>error triggered by consumer</source>
        <translation />
    </message>
    <message>
        <source>error occurred while parsing element</source>
        <translation />
    </message>
    <message>
        <source>unexpected character</source>
        <translation />
    </message>
    <message>
        <source>tag mismatch</source>
        <translation />
    </message>
    <message>
        <source>error occurred while parsing content</source>
        <translation />
    </message>
    <message>
        <source>error occurred while parsing comment</source>
        <translation />
    </message>
    <message>
        <source>internal general entity reference not allowed in DTD</source>
        <translation />
    </message>
    <message>
        <source>recursive entities</source>
        <translation />
    </message>
    <message>
        <source>more than one document type definition</source>
        <translation />
    </message>
    <message>
        <source>version expected while reading the XML declaration</source>
        <translation />
    </message>
    <message>
        <source>letter is expected</source>
        <translation />
    </message>
    <message>
        <source>unexpected end of file</source>
        <translation />
    </message>
    <message>
        <source>external parsed general entity reference not allowed in attribute value</source>
        <translation />
    </message>
    <message>
        <source>error in the text declaration of an external entity</source>
        <translation />
    </message>
    <message>
        <source>error occurred while parsing document type definition</source>
        <translation />
    </message>
</context>
<context>
    <name>QCoreApplication</name>
    <message>
        <source>%1: does not exist</source>
        <translation />
    </message>
    <message>
        <source>%1: key is empty</source>
        <translation />
    </message>
    <message>
        <source>%1: already exists</source>
        <translation />
    </message>
    <message>
        <source>%1: unknown error %2</source>
        <translation />
    </message>
    <message>
        <source>%1: unable to make key</source>
        <translation />
    </message>
    <message>
        <source>%1: ftok failed</source>
        <translation />
    </message>
    <message>
        <source>%1: out of resources</source>
        <translation />
    </message>
</context>
<context>
    <name>QSystemSemaphore</name>
    <message>
        <source>%1: does not exist</source>
        <translation />
    </message>
    <message>
        <source>%1: already exists</source>
        <translation />
    </message>
    <message>
        <source>%1: unknown error %2</source>
        <translation />
    </message>
    <message>
        <source>%1: permission denied</source>
        <translation />
    </message>
    <message>
        <source>%1: out of resources</source>
        <translation />
    </message>
</context>
<context>
    <name>Phonon::MMF::MediaObject</name>
    <message>
        <source>Error opening source: resource is compressed</source>
        <translation />
    </message>
    <message>
        <source>Error opening source: media type could not be determined</source>
        <translation />
    </message>
    <message>
        <source>Error opening source: resource not valid</source>
        <translation />
    </message>
    <message>
        <source>Error opening source: type not supported</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativePixmap</name>
    <message>
        <source>Error decoding: %1: %2</source>
        <translation />
    </message>
    <message>
        <source>Cannot open: %1</source>
        <translation />
    </message>
    <message>
        <source>Failed to get image from provider: %1</source>
        <translation />
    </message>
</context>
<context>
    <name>QSQLiteResult</name>
    <message>
        <source>Unable to fetch row</source>
        <translation />
    </message>
    <message>
        <source>No query</source>
        <translation />
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation />
    </message>
    <message>
        <source>Unable to bind parameters</source>
        <translation />
    </message>
    <message>
        <source>Unable to reset statement</source>
        <translation />
    </message>
    <message>
        <source>Parameter count mismatch</source>
        <translation />
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <source>Activates the program's main window</source>
        <translation />
    </message>
    <message>
        <source>Activate</source>
        <translation />
    </message>
    <message>
        <source>Executable '%1' requires Qt %2, found Qt %3.</source>
        <translation />
    </message>
    <message>
        <source>Incompatible Qt Library Error</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeBinding</name>
    <message>
        <source>Binding loop detected for property "%1"</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeCompiledBindings</name>
    <message>
        <source>Binding loop detected for property "%1"</source>
        <translation />
    </message>
</context>
<context>
    <name>QUnicodeControlCharacterMenu</name>
    <message>
        <source>RLE Start of right-to-left embedding</source>
        <translation />
    </message>
    <message>
        <source>ZWSP Zero width space</source>
        <translation />
    </message>
    <message>
        <source>Insert Unicode control character</source>
        <translation />
    </message>
    <message>
        <source>LRO Start of left-to-right override</source>
        <translation />
    </message>
    <message>
        <source>LRE Start of left-to-right embedding</source>
        <translation />
    </message>
    <message>
        <source>RLM Right-to-left mark</source>
        <translation />
    </message>
    <message>
        <source>PDF Pop directional formatting</source>
        <translation />
    </message>
    <message>
        <source>ZWNJ Zero width non-joiner</source>
        <translation />
    </message>
    <message>
        <source>RLO Start of right-to-left override</source>
        <translation />
    </message>
    <message>
        <source>ZWJ Zero width joiner</source>
        <translation />
    </message>
    <message>
        <source>LRM Left-to-right mark</source>
        <translation />
    </message>
</context>
<context>
    <name>QWebFrame</name>
    <message>
        <source>Request blocked</source>
        <translation />
    </message>
    <message>
        <source>Frame load interrupted by policy change</source>
        <translation />
    </message>
    <message>
        <source>Request cancelled</source>
        <translation />
    </message>
    <message>
        <source>Cannot show URL</source>
        <translation />
    </message>
    <message>
        <source>File does not exist</source>
        <translation />
    </message>
    <message>
        <source>Cannot show mimetype</source>
        <translation />
    </message>
</context>
<context>
    <name>QHttpSocketEngine</name>
    <message>
        <source>Proxy connection refused</source>
        <translation />
    </message>
    <message>
        <source>Proxy denied connection</source>
        <translation />
    </message>
    <message>
        <source>Proxy server not found</source>
        <translation />
    </message>
    <message>
        <source>Proxy server connection timed out</source>
        <translation />
    </message>
    <message>
        <source>Did not receive HTTP response from proxy</source>
        <translation />
    </message>
    <message>
        <source>Proxy connection closed prematurely</source>
        <translation />
    </message>
    <message>
        <source>Error communicating with HTTP proxy</source>
        <translation />
    </message>
    <message>
        <source>Authentication required</source>
        <translation />
    </message>
    <message>
        <source>Error parsing authentication request from proxy</source>
        <translation />
    </message>
</context>
<context>
    <name>QNetworkAccessManager</name>
    <message>
        <source>Network access is disabled.</source>
        <translation />
    </message>
</context>
<context>
    <name>QNetworkReply</name>
    <message>
        <source>Error downloading %1 - server replied: %2</source>
        <translation />
    </message>
    <message>
        <source>Network session error.</source>
        <translation />
    </message>
    <message>
        <source>Protocol "%1" is unknown</source>
        <translation />
    </message>
    <message>
        <source>Temporary network failure.</source>
        <translation />
    </message>
</context>
<context>
    <name>QAbstractSpinBox</name>
    <message>
        <source>Step &amp;down</source>
        <translation />
    </message>
    <message>
        <source>&amp;Step up</source>
        <translation />
    </message>
    <message>
        <source>&amp;Select All</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeXmlRoleList</name>
    <message>
        <source>An XmlListModel query must start with '/' or "//"</source>
        <translation />
    </message>
</context>
<context>
    <name>QDB2Result</name>
    <message>
        <source>Unable to bind variable</source>
        <translation />
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation />
    </message>
    <message>
        <source>Unable to fetch next</source>
        <translation />
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation />
    </message>
    <message>
        <source>Unable to fetch record %1</source>
        <translation />
    </message>
    <message>
        <source>Unable to fetch first</source>
        <translation />
    </message>
</context>
<context>
    <name>QODBCResult</name>
    <message>
        <source>Unable to bind variable</source>
        <translation />
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation />
    </message>
    <message>
        <source>Unable to fetch next</source>
        <translation />
    </message>
    <message>
        <source>Unable to fetch last</source>
        <translation />
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation />
    </message>
    <message>
        <source>Unable to fetch previous</source>
        <translation />
    </message>
    <message>
        <source>Unable to fetch</source>
        <translation />
    </message>
    <message>
        <source>QODBCResult::reset: Unable to set 'SQL_CURSOR_STATIC' as statement attribute. Please check your ODBC driver configuration</source>
        <translation />
    </message>
    <message>
        <source>Unable to fetch first</source>
        <translation />
    </message>
</context>
<context>
    <name>QPSQLDriver</name>
    <message>
        <source>Unable to subscribe</source>
        <translation />
    </message>
    <message>
        <source>Could not begin transaction</source>
        <translation />
    </message>
    <message>
        <source>Could not rollback transaction</source>
        <translation />
    </message>
    <message>
        <source>Could not commit transaction</source>
        <translation />
    </message>
    <message>
        <source>Unable to connect</source>
        <translation />
    </message>
    <message>
        <source>Unable to unsubscribe</source>
        <translation />
    </message>
</context>
<context>
    <name>QInputDialog</name>
    <message>
        <source>Enter a value:</source>
        <translation />
    </message>
</context>
<context>
    <name>QIODevice</name>
    <message>
        <source>No such file or directory</source>
        <translation />
    </message>
    <message>
        <source>Permission denied</source>
        <translation />
    </message>
    <message>
        <source>No space left on device</source>
        <translation />
    </message>
    <message>
        <source>Unknown error</source>
        <translation />
    </message>
    <message>
        <source>Too many open files</source>
        <translation />
    </message>
</context>
<context>
    <name>FakeReply</name>
    <message>
        <source>Invalid URL</source>
        <translation />
    </message>
    <message>
        <source>Fake error !</source>
        <translation />
    </message>
</context>
<context>
    <name>QMultiInputContext</name>
    <message>
        <source>Select IM</source>
        <translation />
    </message>
</context>
<context>
    <name>QTabBar</name>
    <message>
        <source>Scroll Left</source>
        <translation />
    </message>
    <message>
        <source>Scroll Right</source>
        <translation />
    </message>
</context>
<context>
    <name>QUndoModel</name>
    <message>
        <source>&lt;empty&gt;</source>
        <translation />
    </message>
</context>
<context>
    <name>QNetworkAccessCacheBackend</name>
    <message>
        <source>Error opening %1</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeParser</name>
    <message>
        <source>Script import qualifiers must be unique.</source>
        <translation />
    </message>
    <message>
        <source>Unterminated regular expression class</source>
        <translation />
    </message>
    <message>
        <source>Library import requires a version</source>
        <translation />
    </message>
    <message>
        <source>Invalid regular expression flag '%0'</source>
        <translation />
    </message>
    <message>
        <source>JavaScript declaration outside Script element</source>
        <translation />
    </message>
    <message>
        <source>Illegal character</source>
        <translation />
    </message>
    <message>
        <source>Unclosed comment at end of file</source>
        <translation />
    </message>
    <message>
        <source>Unclosed string at end of line</source>
        <translation />
    </message>
    <message>
        <source>Expected property type</source>
        <translation />
    </message>
    <message>
        <source>Expected type name</source>
        <translation />
    </message>
    <message>
        <source>Illegal escape sequence</source>
        <translation />
    </message>
    <message>
        <source>Readonly not yet supported</source>
        <translation />
    </message>
    <message>
        <source>Unterminated regular expression literal</source>
        <translation />
    </message>
    <message>
        <source>Property value set multiple times</source>
        <translation />
    </message>
    <message>
        <source>Unterminated regular expression backslash sequence</source>
        <translation />
    </message>
    <message>
        <source>Identifier cannot start with numeric literal</source>
        <translation />
    </message>
    <message>
        <source>Script import requires a qualifier</source>
        <translation />
    </message>
    <message>
        <source>Illegal syntax for exponential number</source>
        <translation />
    </message>
    <message>
        <source>Invalid property type modifier</source>
        <translation />
    </message>
    <message>
        <source>Reserved name "Qt" cannot be used as an qualifier</source>
        <translation />
    </message>
    <message>
        <source>Expected token `%1'</source>
        <translation />
    </message>
    <message>
        <source>Unexpected token `%1'</source>
        <translation />
    </message>
    <message>
        <source>Expected parameter type</source>
        <translation />
    </message>
    <message>
        <source>Illegal unicode escape sequence</source>
        <translation />
    </message>
    <message>
        <source>Unexpected property type modifier</source>
        <translation />
    </message>
    <message>
        <source>Invalid import qualifier ID</source>
        <translation />
    </message>
    <message>
        <source>Syntax error</source>
        <translation />
    </message>
</context>
<context>
    <name>QScriptEdit</name>
    <message>
        <source>Disable Breakpoint</source>
        <translation />
    </message>
    <message>
        <source>Breakpoint Condition:</source>
        <translation />
    </message>
    <message>
        <source>Toggle Breakpoint</source>
        <translation />
    </message>
    <message>
        <source>Enable Breakpoint</source>
        <translation />
    </message>
</context>
<context>
    <name>QMYSQLResult</name>
    <message>
        <source>Unable to execute statement</source>
        <translation />
    </message>
    <message>
        <source>Unable to store statement results</source>
        <translation />
    </message>
    <message>
        <source>Unable to execute next query</source>
        <translation />
    </message>
    <message>
        <source>Unable to bind outvalues</source>
        <translation />
    </message>
    <message>
        <source>Unable to store next result</source>
        <translation />
    </message>
    <message>
        <source>Unable to fetch data</source>
        <translation />
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation />
    </message>
    <message>
        <source>Unable to store result</source>
        <translation />
    </message>
    <message>
        <source>Unable to bind value</source>
        <translation />
    </message>
    <message>
        <source>Unable to execute query</source>
        <translation />
    </message>
    <message>
        <source>Unable to reset statement</source>
        <translation />
    </message>
</context>
<context>
    <name>QSQLite2Result</name>
    <message>
        <source>Unable to execute statement</source>
        <translation />
    </message>
    <message>
        <source>Unable to fetch results</source>
        <translation />
    </message>
</context>
<context>
    <name>Phonon::AudioOutput</name>
    <message>
        <source>&lt;html&gt;Switching to the audio playback device &lt;b&gt;%1&lt;/b&gt;&lt;br/&gt;which has higher preference or is specifically configured for this stream.&lt;/html&gt;</source>
        <translation />
    </message>
    <message>
        <source>&lt;html&gt;The audio playback device &lt;b&gt;%1&lt;/b&gt; does not work.&lt;br/&gt;Falling back to &lt;b&gt;%2&lt;/b&gt;.&lt;/html&gt;</source>
        <translation />
    </message>
    <message>
        <source>Revert back to device '%1'</source>
        <translation />
    </message>
    <message>
        <source>&lt;html&gt;Switching to the audio playback device &lt;b&gt;%1&lt;/b&gt;&lt;br/&gt;which just became available and has higher preference.&lt;/html&gt;</source>
        <translation />
    </message>
</context>
<context>
    <name>Q3MainWindow</name>
    <message>
        <source>Line up</source>
        <translation />
    </message>
    <message>
        <source>Customize...</source>
        <translation />
    </message>
</context>
<context>
    <name>QUdpSocket</name>
    <message>
        <source>This platform does not support IPv6</source>
        <translation />
    </message>
</context>
<context>
    <name>Phonon::Gstreamer::Backend</name>
    <message>
        <source>Warning: You do not seem to have the base GStreamer plugins installed.
          All audio and video support has been disabled</source>
        <translation />
    </message>
    <message>
        <source>Warning: You do not seem to have the package gstreamer0.10-plugins-good installed.
          Some video features have been disabled.</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativePropertyChanges</name>
    <message>
        <source>Cannot assign to read-only property "%1"</source>
        <translation />
    </message>
    <message>
        <source>PropertyChanges does not support creating state-specific objects.</source>
        <translation />
    </message>
    <message>
        <source>Cannot assign to non-existent property "%1"</source>
        <translation />
    </message>
</context>
<context>
    <name>QLocalServer</name>
    <message>
        <source>%1: Name error</source>
        <translation />
    </message>
    <message>
        <source>%1: Unknown error %2</source>
        <translation />
    </message>
    <message>
        <source>%1: Permission denied</source>
        <translation />
    </message>
    <message>
        <source>%1: Address in use</source>
        <translation />
    </message>
</context>
<context>
    <name>Phonon::MMF::AbstractVideoPlayer</name>
    <message>
        <source>Pause failed</source>
        <translation />
    </message>
    <message>
        <source>Seek failed</source>
        <translation />
    </message>
    <message>
        <source>Opening clip failed</source>
        <translation />
    </message>
    <message>
        <source>Getting position failed</source>
        <translation />
    </message>
</context>
<context>
    <name>Phonon::MMF::AbstractMediaPlayer</name>
    <message>
        <source>Not ready to play</source>
        <translation />
    </message>
    <message>
        <source>Error opening file</source>
        <translation />
    </message>
    <message>
        <source>Error opening source: resource not opened</source>
        <translation />
    </message>
    <message>
        <source>Error opening URL</source>
        <translation />
    </message>
    <message>
        <source>Loading clip failed</source>
        <translation />
    </message>
    <message>
        <source>Setting volume failed</source>
        <translation />
    </message>
    <message>
        <source>Error opening resource</source>
        <translation />
    </message>
    <message>
        <source>Playback complete</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeAbstractAnimation</name>
    <message>
        <source>Animation is an abstract class</source>
        <translation />
    </message>
    <message>
        <source>Cannot animate non-existent property "%1"</source>
        <translation />
    </message>
    <message>
        <source>Cannot animate read-only property "%1"</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeFlipable</name>
    <message>
        <source>front is a write-once property</source>
        <translation />
    </message>
    <message>
        <source>back is a write-once property</source>
        <translation />
    </message>
</context>
<context>
    <name>Q3ToolBar</name>
    <message>
        <source>More...</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeParentAnimation</name>
    <message>
        <source>Unable to preserve appearance under non-uniform scale</source>
        <translation />
    </message>
    <message>
        <source>Unable to preserve appearance under complex transform</source>
        <translation />
    </message>
    <message>
        <source>Unable to preserve appearance under scale of 0</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeParentChange</name>
    <message>
        <source>Unable to preserve appearance under non-uniform scale</source>
        <translation />
    </message>
    <message>
        <source>Unable to preserve appearance under complex transform</source>
        <translation />
    </message>
    <message>
        <source>Unable to preserve appearance under scale of 0</source>
        <translation />
    </message>
</context>
<context>
    <name>QMultiInputContextPlugin</name>
    <message>
        <source>Multiple input method switcher that uses the context menu of the text widgets</source>
        <translation />
    </message>
    <message>
        <source>Multiple input method switcher</source>
        <translation />
    </message>
</context>
<context>
    <name>QGuiApplication</name>
    <message>
        <source>QT_LAYOUT_DIRECTION</source>
        <translation />
    </message>
</context>
<context>
    <name>Q3ProgressDialog</name>
    <message>
        <source>Cancel</source>
        <translation />
    </message>
</context>
<context>
    <name>QProgressDialog</name>
    <message>
        <source>Cancel</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeComponent</name>
    <message>
        <source>Invalid empty URL</source>
        <translation />
    </message>
</context>
<context>
    <name>MAC_APPLICATION_MENU</name>
    <message>
        <source>Hide Others</source>
        <translation />
    </message>
    <message>
        <source>Quit %1</source>
        <translation />
    </message>
    <message>
        <source>About %1</source>
        <translation />
    </message>
    <message>
        <source>Preferences...</source>
        <translation />
    </message>
    <message>
        <source>Services</source>
        <translation />
    </message>
    <message>
        <source>Hide %1</source>
        <translation />
    </message>
    <message>
        <source>Show All</source>
        <translation />
    </message>
</context>
<context>
    <name>QLibrary</name>
    <message>
        <source>Cannot unload library %1: %2</source>
        <translation />
    </message>
    <message>
        <source>Cannot load library %1: %2</source>
        <translation />
    </message>
    <message>
        <source>The plugin '%1' uses incompatible Qt library. (%2.%3.%4) [%5]</source>
        <translation />
    </message>
    <message>
        <source>Cannot resolve symbol "%1" in %2: %3</source>
        <translation />
    </message>
    <message>
        <source>Plugin verification data mismatch in '%1'</source>
        <translation />
    </message>
    <message>
        <source>The plugin '%1' uses incompatible Qt library. (Cannot mix debug and release libraries.)</source>
        <translation />
    </message>
    <message>
        <source>The file '%1' is not a valid Qt plugin.</source>
        <translation />
    </message>
    <message>
        <source>The shared library was not found.</source>
        <translation />
    </message>
    <message>
        <source>Unknown error</source>
        <translation />
    </message>
    <message>
        <source>The plugin '%1' uses incompatible Qt library. Expected build key "%2", got "%3"</source>
        <translation />
    </message>
</context>
<context>
    <name>QTDSDriver</name>
    <message>
        <source>Unable to open connection</source>
        <translation />
    </message>
    <message>
        <source>Unable to use database</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeVisualDataModel</name>
    <message>
        <source>Delegate component must be Item type.</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeConnections</name>
    <message>
        <source>Connections: script expected</source>
        <translation />
    </message>
    <message>
        <source>Connections: nested objects not allowed</source>
        <translation />
    </message>
    <message>
        <source>Cannot assign to non-existent property "%1"</source>
        <translation />
    </message>
    <message>
        <source>Connections: syntax error</source>
        <translation />
    </message>
</context>
<context>
    <name>QPluginLoader</name>
    <message>
        <source>The plugin was not loaded.</source>
        <translation />
    </message>
    <message>
        <source>Unknown error</source>
        <translation />
    </message>
</context>
<context>
    <name>QSlider</name>
    <message>
        <source>Page up</source>
        <translation />
    </message>
    <message>
        <source>Position</source>
        <translation />
    </message>
    <message>
        <source>Page right</source>
        <translation />
    </message>
    <message>
        <source>Page down</source>
        <translation />
    </message>
    <message>
        <source>Page left</source>
        <translation />
    </message>
</context>
<context>
    <name>CloseButton</name>
    <message>
        <source>Close Tab</source>
        <translation />
    </message>
</context>
<context>
    <name>QPSQLResult</name>
    <message>
        <source>Unable to prepare statement</source>
        <translation />
    </message>
    <message>
        <source>Unable to create query</source>
        <translation />
    </message>
</context>
<context>
    <name>QNetworkSession</name>
    <message>
        <source>Invalid configuration.</source>
        <translation />
    </message>
</context>
<context>
    <name>QNetworkAccessDataBackend</name>
    <message>
        <source>Invalid URI: %1</source>
        <translation />
    </message>
    <message>
        <source>Operation not supported on %1</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeAnimatedImage</name>
    <message>
        <source>Qt was built without support for QMovie</source>
        <translation />
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>"%1" duplicates a previous role name and will be disabled.</source>
        <translation />
    </message>
    <message>
        <source>PulseAudio Sound Server</source>
        <translation />
    </message>
    <message>
        <source>invalid query: "%1"</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeKeysAttached</name>
    <message>
        <source>Keys is only available via attached properties</source>
        <translation />
    </message>
</context>
<context>
    <name>QMenuBar</name>
    <message>
        <source>Actions</source>
        <translation />
    </message>
</context>
<context>
    <name>QNetworkAccessDebugPipeBackend</name>
    <message>
        <source>Socket error on %1: %2</source>
        <translation />
    </message>
    <message>
        <source>Remote host closed the connection prematurely on %1</source>
        <translation />
    </message>
    <message>
        <source>Write error writing to %1: %2</source>
        <translation />
    </message>
</context>
<context>
    <name>QNetworkAccessFileBackend</name>
    <message>
        <source>Request for opening non-local file %1</source>
        <translation />
    </message>
    <message>
        <source>Read error reading from %1: %2</source>
        <translation />
    </message>
    <message>
        <source>Cannot open %1: Path is a directory</source>
        <translation />
    </message>
    <message>
        <source>Error opening %1: %2</source>
        <translation />
    </message>
    <message>
        <source>Write error writing to %1: %2</source>
        <translation />
    </message>
</context>
<context>
    <name>QHostInfo</name>
    <message>
        <source>No host name given</source>
        <translation />
    </message>
    <message>
        <source>Unknown error</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeLoader</name>
    <message>
        <source>Loader does not support loading non-visual elements.</source>
        <translation />
    </message>
</context>
<context>
    <name>QNetworkReplyImpl</name>
    <message>
        <source>Operation canceled</source>
        <translation />
    </message>
</context>
<context>
    <name>Q3NetworkProtocol</name>
    <message>
        <source>Operation stopped by the user</source>
        <translation />
    </message>
</context>
<context>
    <name>QStateMachine</name>
    <message>
        <source>Missing default state in history state '%1'</source>
        <translation />
    </message>
    <message>
        <source>Unknown error</source>
        <translation />
    </message>
    <message>
        <source>Missing initial state in compound state '%1'</source>
        <translation />
    </message>
    <message>
        <source>No common ancestor for targets and source of transition from state '%1'</source>
        <translation />
    </message>
</context>
<context>
    <name>QMdiArea</name>
    <message>
        <source>(Untitled)</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeXmlListModelRole</name>
    <message>
        <source>An XmlRole query must not start with '/'</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeBehavior</name>
    <message>
        <source>Cannot change the animation assigned to a Behavior.</source>
        <translation />
    </message>
</context>
<context>
    <name>Q3Accel</name>
    <message>
        <source>%1, %2 not defined</source>
        <translation />
    </message>
    <message>
        <source>Ambiguous %1 not handled</source>
        <translation />
    </message>
</context>
<context>
    <name>Phonon::MMF::EffectFactory</name>
    <message>
        <source>Enabled</source>
        <translation />
    </message>
</context>
<context>
    <name>Phonon::MMF::DsaVideoPlayer</name>
    <message>
        <source>Video display error</source>
        <translation />
    </message>
</context>
<context>
    <name>Phonon::MMF::SurfaceVideoPlayer</name>
    <message>
        <source>Video display error</source>
        <translation />
    </message>
</context>
<context>
    <name>Phonon::MMF::StereoWidening</name>
    <message>
        <source>Level (%)</source>
        <translation />
    </message>
</context>
<context>
    <name>Phonon::MMF::AudioPlayer</name>
    <message>
        <source>Getting position failed</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeKeyNavigationAttached</name>
    <message>
        <source>KeyNavigation is only available via attached properties</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeAnchorAnimation</name>
    <message>
        <source>Cannot set a duration of &lt; 0</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativePauseAnimation</name>
    <message>
        <source>Cannot set a duration of &lt; 0</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativePropertyAnimation</name>
    <message>
        <source>Cannot set a duration of &lt; 0</source>
        <translation />
    </message>
</context>
<context>
    <name>QTcpServer</name>
    <message>
        <source>Operation on socket is not supported</source>
        <translation />
    </message>
</context>
<context>
    <name>QDeclarativeXmlListModel</name>
    <message>
        <source>Qt was built without support for xmlpatterns</source>
        <translation />
    </message>
</context>
</TS>