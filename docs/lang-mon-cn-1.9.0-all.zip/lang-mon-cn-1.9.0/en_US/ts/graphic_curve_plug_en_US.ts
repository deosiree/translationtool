<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CurveEditorPlugin</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_editor_plugin.cpp" line="38"/>
        <source>曲线插件集合</source>
        <translation type="unfinished">Curve plugin collection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_editor_plugin.cpp" line="46"/>
        <source>曲线插件</source>
        <translation type="unfinished">Curve plugin</translation>
    </message>
</context>
<context>
    <name>CurveMainWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="105"/>
        <source>日期设置</source>
        <translation type="unfinished">Date setting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="345"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="361"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="375"/>
        <source>曲线文件%1</source>
        <translation type="unfinished">Curve file %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="345"/>
        <source>曲线组名称不可为空</source>
        <translation type="unfinished">Curve group name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="361"/>
        <source>暂未实现，敬请期待</source>
        <translation type="unfinished">Not yet realized, please look forward to it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="375"/>
        <source>打开曲线</source>
        <translation type="unfinished">Open curve</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="418"/>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="455"/>
        <source>开启实时刷新</source>
        <translation type="unfinished">Enable real-time refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="667"/>
        <source>至</source>
        <translation type="unfinished">to</translation>
    </message>
</context>
</TS>
