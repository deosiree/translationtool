<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>ComCheckDialog</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/com_check_dialog.ui" line="27"/>
        <source>画面</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/com_check_dialog.ui" line="52"/>
        <source>图元</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/com_check_dialog.ui" line="77"/>
        <source>维护库</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">M-RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/com_check_dialog.ui" line="93"/>
        <source>配置文件</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Config File</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/com_check_dialog.cpp" line="33"/>
        <source>路径</source>
        <translation type="unfinished">path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/com_check_dialog.cpp" line="33"/>
        <source>状态</source>
        <translation type="unfinished">state</translation>
    </message>
</context>
<context>
    <name>ComProgressDlg</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/com_progress_dialog.cpp" line="7"/>
        <source>检查进度</source>
        <comment>toolName</comment>
        <translation type="unfinished">Check Progress</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/com_progress_dialog.cpp" line="12"/>
        <source>正在检查...</source>
        <translation type="unfinished">Checking in progress...</translation>
    </message>
</context>
<context>
    <name>ConfigTableController</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/config_table/ConfigTableController.cpp" line="70"/>
        <source>确认删除</source>
        <translation type="unfinished">Confirm to delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/config_table/ConfigTableController.cpp" line="71"/>
        <source>确定删除选中项？</source>
        <translation type="unfinished">Whether to delete selected items?</translation>
    </message>
</context>
<context>
    <name>ConfigTableModel</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/config_table/ConfigTableModel.cpp" line="89"/>
        <source>选择</source>
        <translation type="unfinished">Select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/config_table/ConfigTableModel.cpp" line="89"/>
        <source>类型</source>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/config_table/ConfigTableModel.cpp" line="89"/>
        <source>文件名</source>
        <translation type="unfinished">File name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/config_table/ConfigTableModel.cpp" line="89"/>
        <source>路径</source>
        <translation type="unfinished">Path</translation>
    </message>
</context>
<context>
    <name>GraphTDBIO</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="45"/>
        <source>导出</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="63"/>
        <source>选择导出内容</source>
        <comment>label</comment>
        <translation type="unfinished">Select export content</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="95"/>
        <source>重新加载</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Reload</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="114"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="556"/>
        <source>画面</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="139"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="581"/>
        <source>图元</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="164"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="606"/>
        <source>维护库</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">M-RTDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="184"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="626"/>
        <source>维护库列表</source>
        <translation type="unfinished">M-RTDB list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="216"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="347"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="658"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="736"/>
        <source>全选</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="235"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="369"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="677"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="743"/>
        <source>取消选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="254"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="696"/>
        <source>配置文件</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Config File</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="274"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="716"/>
        <source>配置文件列表</source>
        <translation type="unfinished">Config files list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="306"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="325"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="397"/>
        <source>导出目录：</source>
        <translation type="unfinished">Export dir:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="422"/>
        <source>请选择导出目录</source>
        <translation type="unfinished">Please select the export dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="441"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="523"/>
        <source>选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="460"/>
        <source>导出校验</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Export check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="470"/>
        <source>导入</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="488"/>
        <source>导入文件：</source>
        <translation type="unfinished">Import file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="504"/>
        <source>请选择导入文件</source>
        <translation type="unfinished">Please select the import file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="539"/>
        <source>选择导入内容</source>
        <translation type="unfinished">Select import content</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.ui" line="789"/>
        <source>导入校验</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Import check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="109"/>
        <source>图模导入导出</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Graph model IO</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="234"/>
        <source>导入检查</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Import inspection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="234"/>
        <source>执行导入</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exec import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="246"/>
        <source>导出检查</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Export check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="246"/>
        <source>执行导出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exec export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="324"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="334"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="419"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="424"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="442"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="457"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="918"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="938"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="958"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="976"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="990"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1150"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1170"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="78"/>
        <source>告警</source>
        <translation type="unfinished">alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="324"/>
        <source>画面导入初始化失败：%1</source>
        <translation type="unfinished">Graph import initialization failed: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="334"/>
        <source>图元导入初始化失败：%1</source>
        <translation type="unfinished">Icon import initialization failed: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="401"/>
        <source>选择文件夹</source>
        <translation type="unfinished">Select folder</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="419"/>
        <source>导出路径为空！</source>
        <translation type="unfinished">Export path is empty!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="424"/>
        <source>文件夹不存在！</source>
        <translation type="unfinished">The folder does not exist!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="442"/>
        <source>当前目录无法（无权限）创建文件！</source>
        <translation type="unfinished">This directory is unable to create files (no permission)!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="453"/>
        <source>（1/4）画面导出校验...</source>
        <translation type="unfinished">(1/4) Graph export check ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="457"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="990"/>
        <source>清理有误！%1</source>
        <translation type="unfinished">Cleaning error! %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="474"/>
        <source>导出校验失败</source>
        <translation type="unfinished">Export check failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="487"/>
        <source>画面导出校验失败：%1</source>
        <translation type="unfinished">Graph export check failed: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="494"/>
        <source>（2/4）图元导出校验...</source>
        <translation type="unfinished">(2/4) Icon export check ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="504"/>
        <source>图元导出校验失败：%1</source>
        <translation type="unfinished">Icon export check failed: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="510"/>
        <source>（3/4）维护库导出校验...</source>
        <translation type="unfinished">(3/4) M-RTDB export check ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="526"/>
        <source>（4/4）配置导出校验...</source>
        <translation type="unfinished">(4/4) Config export check ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="552"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1077"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="297"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="512"/>
        <source>校验通过</source>
        <translation type="unfinished">check passed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="692"/>
        <source>导出包名称</source>
        <translation type="unfinished">Export package name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="692"/>
        <source>请输入导出包名称：</source>
        <translation type="unfinished">Please enter the export package name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="699"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="705"/>
        <source>提示</source>
        <translation type="unfinished">prompt</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="699"/>
        <source>导出包名不能包含路径“/”符号</source>
        <translation type="unfinished">Export package name cannot contain path &apos;/&apos; symbol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="705"/>
        <source>导出包名不能为空</source>
        <translation type="unfinished">Export package name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="723"/>
        <source>（1/4）画面导出...</source>
        <translation type="unfinished">(1/4) Graph export ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="731"/>
        <source>画面导出有误！</source>
        <translation type="unfinished">Error exporting the graph!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="743"/>
        <source>（2/4）图元导出...</source>
        <translation type="unfinished">(2/4) Exporting icons ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="755"/>
        <source>（3/4）数据库导出...</source>
        <translation type="unfinished">(3/4) DB export ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="787"/>
        <source>（4/4）配置文件导出...</source>
        <translation type="unfinished">(4/4) Export config file ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="807"/>
        <source>压缩文件中...</source>
        <translation type="unfinished">Compressing file...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="829"/>
        <source>创建压缩文件失败！</source>
        <translation type="unfinished">Failed to create compressed file!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="851"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="856"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="422"/>
        <source>导出成功</source>
        <translation type="unfinished">Export successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="853"/>
        <source>导出成功！</source>
        <translation type="unfinished">Export successful!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="857"/>
        <source>文件路径为：%1</source>
        <translation type="unfinished">The file path is: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="904"/>
        <source>选择文件</source>
        <translation type="unfinished">Select File</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="906"/>
        <source>系统图模导出文件(*.syzip)</source>
        <translation type="unfinished">System graph model export file (*.syzip)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="918"/>
        <source>导入路径为空！</source>
        <translation type="unfinished">The import path is empty!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="938"/>
        <source>解压导入压缩包失败！</source>
        <translation type="unfinished">Failed to decompress and import compressed file!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="958"/>
        <source>导入文件版本不兼容当前系统版本，请检查版本配置！</source>
        <translation type="unfinished">The imported file version is incompatible with this system version. Please check the version config!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="976"/>
        <source>请选择导入文件！</source>
        <translation type="unfinished">Please select the file to import!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="985"/>
        <source>（1/4）画面导入校验...</source>
        <translation type="unfinished">(1/4) Graph import check ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1008"/>
        <source>导入校验失败</source>
        <translation type="unfinished">Import check failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1018"/>
        <source>画面导入校验失败：%1</source>
        <translation type="unfinished">Graph import check failed: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1024"/>
        <source>（2/4）图元导入校验...</source>
        <translation type="unfinished">(2/4) Icon import check ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1030"/>
        <source>图元导入校验失败：%1</source>
        <translation type="unfinished">Icon import check failed: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1036"/>
        <source>（3/4）维护库导入校验...</source>
        <translation type="unfinished">(3/4) MTDB import check ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1052"/>
        <source>（4/4）配置文件导入校验...</source>
        <translation type="unfinished">(4/4) Config import check ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1089"/>
        <source>导入已完成，确认后将退出工具。</source>
        <translation type="unfinished">Import completed; tool will exit after confirmation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1114"/>
        <source>导入提示</source>
        <translation type="unfinished">Import prompt</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1115"/>
        <source>导入过程中将关闭所有工具，%1请确认相关文件已保存。%2%3是否继续？</source>
        <translation type="unfinished">During the import process, all tools will be closed.%1Please confirm that the relevant files have been saved.%2%3Whether to continue?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1150"/>
        <source>获取所有节点名失败！</source>
        <translation type="unfinished">Failed to retrieve all node names!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1170"/>
        <source>停止节点%1所有工具失败！</source>
        <translation type="unfinished">Failed to stop all tools for node %1!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1182"/>
        <source>（1/4）图元导入...</source>
        <translation type="unfinished">(1/4) Icon import ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1197"/>
        <source>（2/4）画面导入...</source>
        <translation type="unfinished">(2/4) Graph import ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1214"/>
        <source>（3/4）实时库导入...</source>
        <translation type="unfinished">(3/4) TDB import ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1241"/>
        <source>（4/4）配置文件导入...</source>
        <translation type="unfinished">(4/4) Import config file ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1263"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="607"/>
        <source>导入成功</source>
        <translation type="unfinished">Import successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1268"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1275"/>
        <source>导入成功！</source>
        <translation type="unfinished">Import successful!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1089"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1272"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1275"/>
        <source>通知</source>
        <translation type="unfinished">Notification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1273"/>
        <source>导入成功！维护库发生变化，需要执行装库后运行库才生效。</source>
        <translation type="unfinished">Import successful! Maintenance Database (M-RTDB) has been updated. You must load the DB (Load DB) first for Run-time Databases (R-RTDB) to take effect.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io.cpp" line="1372"/>
        <source>错误</source>
        <translation type="unfinished">error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_cfg.cpp" line="28"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_cfg.cpp" line="194"/>
        <source>错误！</source>
        <translation type="unfinished">Error!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_cfg.cpp" line="28"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_cfg.cpp" line="194"/>
        <source>读取配置文件失败！</source>
        <translation type="unfinished">Failed to read config file!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_cfg.cpp" line="45"/>
        <source>配置文件第%1行路径为空！</source>
        <translation type="unfinished">The path on line %1 of the config file is empty!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_cfg.cpp" line="52"/>
        <source>配置文件：%1不存在！</source>
        <translation type="unfinished">Config file: %1 does not exist!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_cfg.cpp" line="121"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="396"/>
        <source>创建目录 %1 失败！</source>
        <translation type="unfinished">Failed to create dir %1!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_cfg.cpp" line="131"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="404"/>
        <source>登录节点 %1 失败！</source>
        <translation type="unfinished">Login to node %1 failed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_cfg.cpp" line="144"/>
        <source>从节点 %1 下载文件 %2 失败！</source>
        <translation type="unfinished">Failed to download file %2 from node %1!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_cfg.cpp" line="228"/>
        <source>登录节点%1失败</source>
        <translation type="unfinished">Login to node %1 failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_cfg.cpp" line="239"/>
        <source>正在导入配置文件：%1</source>
        <translation type="unfinished">Importing config file: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_cfg.cpp" line="249"/>
        <source>上传 %1 到节点 %2 的 %3 失败</source>
        <translation type="unfinished">%3 upload %1 to node %2 failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_cfg.cpp" line="266"/>
        <source>发布配置文件失败</source>
        <translation type="unfinished">Failed to publish config file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="78"/>
        <source>系统管理连接失败！</source>
        <translation type="unfinished">Sysmgr connection failed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="162"/>
        <source>根据维护应用[%1]查询应用定义失败</source>
        <translation type="unfinished">Failed to query application definition based on maintenance application [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="171"/>
        <source>根据应用定义[%1]查询应用定义失败</source>
        <translation type="unfinished">Failed to query application definition based on application definition [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="181"/>
        <source>查询应用[%1]的维护库失败</source>
        <translation type="unfinished">Failed to query M-RTDB of app [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="240"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="456"/>
        <source>获取应用%1信息失败！</source>
        <translation type="unfinished">Failed to retrieve information for app %1!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="485"/>
        <source>%1节点状态不正常！请检查！</source>
        <translation type="unfinished">Node %1 is in an abnormal status! Please check!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="284"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="499"/>
        <source>获取%1状态失败！</source>
        <translation type="unfinished">Failed to retrieve %1 status!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="254"/>
        <source>查询%1维护节点失败！</source>
        <translation type="unfinished">Failed to query %1 maintenance node!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="263"/>
        <source>查询%1节点状态失败！</source>
        <translation type="unfinished">Failed to query the status of %1 node!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="270"/>
        <source>%1%2维护节点状态不正常！请检查！</source>
        <translation type="unfinished">%1%2 status of maintenance node is abnormal! Please check!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="291"/>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="506"/>
        <source>%1状态不正常！请检查！</source>
        <translation type="unfinished">Node %1 is in an abnormal status! Please check!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="370"/>
        <source>应用 %1 的库 %2 连接失败，执行备份失败！</source>
        <translation type="unfinished">Link failure for M-RTDB %2 of app %1, backup execution failed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="380"/>
        <source>应用 %1 的库 %2 执行备份失败！</source>
        <translation type="unfinished">Backup execution failed for mtdb %2 of app %1!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="416"/>
        <source>从节点 %1 下载库 %2 失败！</source>
        <translation type="unfinished">Failed to download mtdb %2 from node %1!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="469"/>
        <source>查询应用%1维护节点失败！</source>
        <translation type="unfinished">Failed to query application %1 maintenance node!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/graph_tdb_io_mtdb.cpp" line="478"/>
        <source>查询节点%1状态失败！</source>
        <translation type="unfinished">Failed to query the status of node %1!</translation>
    </message>
</context>
<context>
    <name>PathButtonDelegate</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/config_table/PathButtonDelegate.cpp" line="9"/>
        <source>选择文件</source>
        <translation type="unfinished">Select File</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/config_table/PathButtonDelegate.cpp" line="20"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/gui_sys_ioer/plug/gui_graphic_tdb_io/config_table/PathButtonDelegate.cpp" line="20"/>
        <source>非平台环境下有效路径，请重新选择！</source>
        <translation type="unfinished">Not Effective path in platform environment, please select again!</translation>
    </message>
</context>
</TS>
