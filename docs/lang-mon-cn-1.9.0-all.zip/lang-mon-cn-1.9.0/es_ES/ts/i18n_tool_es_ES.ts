<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="64"/>
        <source>文件列表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="69"/>
        <source>DIC文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="87"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="88"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="849"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1318"/>
        <source>新增词条</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="94"/>
        <source>删除词条</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="100"/>
        <source>保存</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="124"/>
        <source>输入搜索内容...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="130"/>
        <source>所有列</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="131"/>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="132"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="133"/>
        <source>Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="134"/>
        <source>Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="297"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="302"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="318"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="329"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="335"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="496"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="505"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="708"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="769"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="773"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="787"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="816"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="977"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="980"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="997"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1007"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1074"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1079"/>
        <source>错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="298"/>
        <source>处理文件时发生错误: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="302"/>
        <source>处理文件时发生未知错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="318"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="496"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="997"/>
        <source>无法打开文件：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="329"/>
        <source>JSON解析错误：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="335"/>
        <source>JSON文件格式错误：需要数组格式</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="701"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="701"/>
        <source>没有需要保存的更改</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="708"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="787"/>
        <source>无法保存文件：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="760"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="812"/>
        <source>成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="760"/>
        <source>文件已保存</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="770"/>
        <source>保存文件时发生错误: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="773"/>
        <source>保存文件时发生未知错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="812"/>
        <source>配置文件已保存</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="816"/>
        <source>配置文件保存失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="921"/>
        <source>确认删除</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="922"/>
        <source>确定要删除这个词条吗？</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="977"/>
        <source>加载文件时发生错误: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="980"/>
        <source>加载文件时发生未知错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="505"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1007"/>
        <source>无法解析XML文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1075"/>
        <source>解析文件时发生错误: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1079"/>
        <source>解析文件时发生未知错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1178"/>
        <source>当前选中: Source=&apos;%1&apos; | Context=&apos;%2&apos; | Location=&apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1202"/>
        <source>处理表格点击时发生错误: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1221"/>
        <source>表格操作</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1223"/>
        <source>复制</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1224"/>
        <source>粘贴</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1225"/>
        <source>删除</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1288"/>
        <source>找到 %1 个匹配项</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
