<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>ReportStatisticInterface</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/report_statistic_interface.cpp" line="66"/>
        <source>算法</source>
        <translation type="unfinished">Algoritmo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/report_statistic_interface.cpp" line="67"/>
        <source>统计任务</source>
        <translation type="unfinished">Misiones estadísticas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/report_statistic_interface.cpp" line="71"/>
        <source>任务名称</source>
        <translation type="unfinished">Nombre de la tarea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/report_statistic_interface.cpp" line="77"/>
        <source>测点</source>
        <translation type="unfinished">Punto de medición</translation>
    </message>
</context>
<context>
    <name>StatisticDefineWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="20"/>
        <source>统计配置</source>
        <translation type="unfinished">Configuración de estadísticas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="48"/>
        <source>统计配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Configuración de Estadísticas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="55"/>
        <source>模拟量单点</source>
        <translation type="unfinished">Punto único analógico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="60"/>
        <source>累积量多点</source>
        <translation type="unfinished">Más cantidad acumulada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="65"/>
        <source>遥控多点</source>
        <translation type="unfinished">Telecontrol de múltiples puntos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="79"/>
        <source>统计任务：</source>
        <translation type="unfinished">Misiones estadísticas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="87"/>
        <source>常规日统计</source>
        <translation type="unfinished">Estadísticas diarias regulares</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="92"/>
        <source>越限日统计</source>
        <translation type="unfinished">Estadísticas de días excedidos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="97"/>
        <source>常规月统计</source>
        <translation type="unfinished">Estadísticas mensuales regulares</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="111"/>
        <source>算法：</source>
        <translation type="unfinished">Algoritmo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="125"/>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="293"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="130"/>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="298"/>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="135"/>
        <source>3</source>
        <translation type="unfinished">3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="140"/>
        <source>4</source>
        <translation type="unfinished">4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="145"/>
        <source>名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="150"/>
        <source>别名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="155"/>
        <source>选择</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Seleccionar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="239"/>
        <source>测点配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Configuración de Puntos de Medición</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="245"/>
        <source>上移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Mover arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="252"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="259"/>
        <source>下移</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Mover hacia abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="165"/>
        <source>平均值</source>
        <translation type="unfinished">Promedio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="183"/>
        <source>最大值</source>
        <translation type="unfinished">Máx.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="201"/>
        <source>最小值</source>
        <translation type="unfinished">Mín</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="222"/>
        <source>负荷率</source>
        <translation type="unfinished">Tasa de carga</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="266"/>
        <source>...</source>
        <translation type="unfinished">…</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="303"/>
        <source>测点名称</source>
        <translation type="unfinished">Nombre del punto de medición</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="308"/>
        <source>测点路径</source>
        <translation type="unfinished">Ruta de punto de medición</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/config/statistic_define_widget.ui" line="313"/>
        <source>tag1</source>
        <translation type="unfinished">etiqueta1</translation>
    </message>
</context>
</TS>
