<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CommandManager</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="366"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="591"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="638"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="666"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="692"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="736"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="757"/>
        <source>启动失败</source>
        <comment>toolName</comment>
        <translation type="unfinished">Error de Inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="370"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="595"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="642"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="644"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="670"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="696"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="740"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="761"/>
        <source>启动失败</source>
        <translation type="unfinished">Error de inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="371"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="671"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="697"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="762"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="372"/>
        <source>工具打开失败</source>
        <translation type="unfinished">Error al abrir la herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="373"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="529"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="598"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="625"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="645"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="673"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="699"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="743"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="764"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="522"/>
        <source>打开个数超限</source>
        <comment>toolName</comment>
        <translation type="unfinished">La Cantidad Abierta Excede el Límite</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="526"/>
        <source>打开失败</source>
        <translation type="unfinished">Error al abrir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="527"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="622"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="528"/>
        <source>打开个数超限</source>
        <translation type="unfinished">La cantidad abierta excede el límite</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="596"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="643"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="741"/>
        <source>失败</source>
        <translation type="unfinished">Fallido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="597"/>
        <source>当前工具无打开权限</source>
        <translation type="unfinished">La herramienta actual no tiene permiso para abrir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="618"/>
        <source>提示</source>
        <comment>toolName</comment>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="624"/>
        <source>已启动,请检查!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="623"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="672"/>
        <source>当前节点支持最大启动进程数为%1,无法启动</source>
        <translation type="unfinished">El nodo actual soporta un máximo de %1 procesos de inicio y no puede iniciar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="698"/>
        <source>用户未登录</source>
        <translation type="unfinished">Usuario no conectado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="742"/>
        <source>用户无权限</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/command_manager.cpp" line="763"/>
        <source>工具打开失败!</source>
        <translation type="unfinished">¡Error al abrir la herramienta!</translation>
    </message>
</context>
<context>
    <name>DlgHideConsole</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/dialog/dlg_hide_console.cpp" line="21"/>
        <source>展开</source>
        <translation type="unfinished">Expandir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/dialog/dlg_hide_console.cpp" line="26"/>
        <source>控制台</source>
        <translation type="unfinished">Consola</translation>
    </message>
</context>
<context>
    <name>IconPushbutton</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/basewidget/icon_pushbutton.cpp" line="149"/>
        <source>关闭</source>
        <comment>menuName</comment>
        <translation type="unfinished">Cerrar</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/main.cpp" line="262"/>
        <source>磁盘告警</source>
        <comment>gui_console::main</comment>
        <translation type="unfinished">Alarma de disco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/main.cpp" line="264"/>
        <source>磁盘已使用%1%,请注意!</source>
        <comment>gui_manager::main</comment>
        <translation type="unfinished">El disco ha sido utilizado %1%, ¡por favor tenga en cuenta!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/main.cpp" line="265"/>
        <source>确定</source>
        <comment>gui_manager::main</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/main.cpp" line="289"/>
        <source>参数解析失败</source>
        <comment>gui_console::main</comment>
        <translation type="unfinished">Error al analizar los parámetros</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/main.cpp" line="291"/>
        <source>请检查</source>
        <comment>gui_console::main</comment>
        <translation type="unfinished">Verifique</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/main.cpp" line="292"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/main.cpp" line="421"/>
        <source>确定</source>
        <comment>gui_console::main</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/main.cpp" line="418"/>
        <source>已启动</source>
        <comment>gui_console::main</comment>
        <translation type="unfinished">Iniciado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/main.cpp" line="420"/>
        <source>控制台仅支持单启动</source>
        <comment>gui_console::main</comment>
        <translation type="unfinished">La consola solo admite un único arranque</translation>
    </message>
</context>
<context>
    <name>SearchTool</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/basewidget/search_tool.cpp" line="14"/>
        <source>搜索</source>
        <translation type="unfinished">Buscar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/basewidget/search_tool.cpp" line="15"/>
        <source>点击Enter按键进行查询</source>
        <translation type="unfinished">Presione el botón Entrar para buscar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/basewidget/search_tool.cpp" line="87"/>
        <source>未找到结果</source>
        <comment>menuName</comment>
        <translation type="unfinished">No hay res</translation>
    </message>
</context>
<context>
    <name>ToolsMenu</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/tools_menu.cpp" line="121"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/tools_menu.cpp" line="169"/>
        <source>用户登录</source>
        <translation type="unfinished">Inicio de Sesión de Usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/tools_menu.cpp" line="122"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/tools_menu.cpp" line="125"/>
        <source>退出系统</source>
        <translation type="unfinished">Salir del Sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/tools_menu.cpp" line="126"/>
        <source>重启</source>
        <translation type="unfinished">Reiniciar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/tools_menu.cpp" line="127"/>
        <source>关闭电源</source>
        <translation type="unfinished">Apagar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/tools_menu.cpp" line="128"/>
        <source>退出控制台</source>
        <translation type="unfinished">Salir de la consola</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/tools_menu.cpp" line="137"/>
        <source>显示桌面</source>
        <translation type="unfinished">Mostrar escritorio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/tools_menu.cpp" line="143"/>
        <source>版本信息</source>
        <translation type="unfinished">Versión</translation>
    </message>
</context>
<context>
    <name>iasp::gui::TaskbarWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="351"/>
        <source>控制台</source>
        <translation type="unfinished">Consola</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="586"/>
        <source>开始</source>
        <translation type="unfinished">Iniciar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="645"/>
        <source>消音</source>
        <translation type="unfinished">Silenciar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="652"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="693"/>
        <source>系统名:</source>
        <translation type="unfinished">Nombre del Sistema:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="693"/>
        <source>节点名:</source>
        <translation type="unfinished">Nombre del nodo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="735"/>
        <source>安全运行%1天</source>
        <translation type="unfinished">Operación segura por %1 días</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="921"/>
        <source>收起</source>
        <translation type="unfinished">Colapsar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="976"/>
        <source>系统工具</source>
        <translation type="unfinished">Herramientas del sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="1752"/>
        <source>退出当前会话</source>
        <comment>toolName</comment>
        <translation type="unfinished">Salir de la Sesión Actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="1756"/>
        <source>退出当前会话</source>
        <translation type="unfinished">Salir de la sesión actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="1757"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2270"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2345"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2380"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2408"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2446"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="1758"/>
        <source>长时间内未做任何操作，退出当前会话</source>
        <translation type="unfinished">Saliendo de la sesión actual sin realizar ninguna acción durante mucho tiempo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="1918"/>
        <source>:未配置权限</source>
        <translation type="unfinished">: No hay permisos configurados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="1927"/>
        <source>跟随启动失败</source>
        <translation type="unfinished">Fallo al iniciar el seguimiento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="1928"/>
        <source>失败原因：</source>
        <translation type="unfinished">Razón del fallo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2266"/>
        <source>切换用户</source>
        <comment>toolName</comment>
        <translation type="unfinished">Cambiar Usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2341"/>
        <source>停用系统</source>
        <comment>toolName</comment>
        <translation type="unfinished">Detener Sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2347"/>
        <source>是否停用系统?</source>
        <translation type="unfinished">¿Desea desactivar el sistema?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2376"/>
        <source>退出控制台</source>
        <comment>toolName</comment>
        <translation type="unfinished">Salir de la Consola</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2382"/>
        <source>是否退出控制台?</source>
        <translation type="unfinished">¿Desea salir de la consola?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2404"/>
        <source>重启设备</source>
        <comment>toolName</comment>
        <translation type="unfinished">Reiniciar Dispositivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2410"/>
        <source>是否重启设备？</source>
        <translation type="unfinished">¿Desea reiniciar el dispositivo?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2442"/>
        <source>关闭电源</source>
        <comment>toolName</comment>
        <translation type="unfinished">Apagar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2448"/>
        <source>是否关闭电源?</source>
        <translation type="unfinished">¿Desea apagar el dispositivo?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2547"/>
        <source>分辨率变化</source>
        <comment>toolName</comment>
        <translation type="unfinished">Variación de Resolución</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2552"/>
        <source>询问</source>
        <translation type="unfinished">Preguntar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="1759"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2273"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2348"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2383"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2411"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2449"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2554"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="257"/>
        <source>测试声音</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="259"/>
        <source>显示桌面</source>
        <translation type="unfinished">Mostrar escritorio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="265"/>
        <source>历史升级</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="828"/>
        <source>临时许可</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="837"/>
        <source>授权到期时间：%1</source>
        <translation type="unfinished">Tiempo de expiración de la autorización: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2272"/>
        <source>是否切换用户?</source>
        <translation type="unfinished">¿Desea cambiar de usuario?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2274"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2349"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2384"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2412"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2450"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2551"/>
        <source>退出控制台</source>
        <translation type="unfinished">Salir de la consola</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="264"/>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2477"/>
        <source>版本信息</source>
        <translation type="unfinished">Versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_console/src/widget/taskbar_widget.cpp" line="2553"/>
        <source>检测到正在修改屏幕分辨率，重启生效</source>
        <translation type="unfinished">Se detectó que la resolución de pantalla está siendo modificada, reinicie para que surta efecto</translation>
    </message>
</context>
</TS>
