<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="581"/>
        <source>只有 DB 节点才能关闭</source>
        <translation type="unfinished">Solo los nodos DB pueden ser apagados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="603"/>
        <source>只有 DB 节点才能保存</source>
        <translation type="unfinished">Solo los nodos DB pueden ser guardados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="622"/>
        <source>只有 DB 节点才能请求编辑</source>
        <translation type="unfinished">Solo los nodos DB pueden solicitar ediciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="636"/>
        <source>必需指定数据库</source>
        <translation type="unfinished">Se requiere base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="655"/>
        <source>导出失败</source>
        <translation type="unfinished">Exportación fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="666"/>
        <source>只有 DB 节点才能发布</source>
        <translation type="unfinished">Solo los nodos DB pueden ser publicados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="690"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="769"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="795"/>
        <source>不是有效的节点类型</source>
        <translation type="unfinished">Tipo de nodo no válido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="716"/>
        <source>只有目录节点才能添加枚举文件</source>
        <translation type="unfinished">Solo los nodos de directorio pueden agregar archivos de enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="774"/>
        <source>请先关闭文件</source>
        <translation type="unfinished">Por favor cierre el archivo primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="800"/>
        <source>请先关闭已打开的枚举文件</source>
        <translation type="unfinished">Por favor cierre primero el archivo de enumeración abierto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="821"/>
        <source>只有【数据库】节点才能添加【枚举组】</source>
        <translation type="unfinished">Solo los nodos [Base de Datos] pueden agregar [Grupo de Enumeración]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="842"/>
        <source>只有【数据库】节点才能删除【枚举组】</source>
        <translation type="unfinished">Solo el nodo [Base de Datos] puede eliminar el [Grupo de Enumeración]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="862"/>
        <source>只有【数据库】节点才可以移动【枚举组】</source>
        <translation type="unfinished">Solo los nodos [Base de Datos] pueden mover [Grupo de Enumeración]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="888"/>
        <source>该节点无法添加枚举项</source>
        <translation type="unfinished">El nodo no puede agregar un ítem de enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="909"/>
        <source>只有【枚举组】或【枚举项】节点才能删除【枚举项】</source>
        <translation type="unfinished">Solo los nodos [Grupo de Enumeración] o [Elemento de Enumeración] pueden eliminar [Elemento de Enumeración]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="929"/>
        <source>只有【枚举组】或【枚举项】节点才能移动【枚举项】</source>
        <translation type="unfinished">Solo los nodos [Grupo de Enumeración] o [Elemento de Enumeración] pueden mover [Elemento de Enumeración]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="955"/>
        <source>节点类型错误</source>
        <translation type="unfinished">Tipo de nodo incorrecto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="1196"/>
        <source>初始化属性失败！文件格式可能不正确！</source>
        <translation type="unfinished">Fallo al inicializar atributos! ¡El formato del archivo puede ser incorrecto!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="1253"/>
        <source>无法获取配置ID</source>
        <translation type="unfinished">No se puede obtener el ID de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="1378"/>
        <source>添加【枚举组】失败</source>
        <translation type="unfinished">Fallo al agregar [Grupo de Enumeración]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="1391"/>
        <source>无效的枚举组节点</source>
        <translation type="unfinished">Nodo de grupo de enumeración no válido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="1404"/>
        <source>删除枚举组失败</source>
        <translation type="unfinished">Fallo al eliminar grupo de enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="1417"/>
        <source>无效的【枚举组】节点</source>
        <translation type="unfinished">Nodo [grupo de enumeración] inválido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="1431"/>
        <source>移动【枚举组】失败</source>
        <translation type="unfinished">Fallo al mover [Grupo de Enumeración]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="1450"/>
        <source>枚举项不允许添加二级子节点</source>
        <translation type="unfinished">Los ítems de enumeración no permiten agregar nodos secundarios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="1472"/>
        <source>添加【枚举项】失败</source>
        <translation type="unfinished">Fallo al agregar [Elemento de Enumeración]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="1486"/>
        <source>无效的枚举项节点</source>
        <translation type="unfinished">Nodo de ítem de enumeración no válido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="1507"/>
        <source>删除枚举项失败</source>
        <translation type="unfinished">Fallo al eliminar ítem de enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="1520"/>
        <source>无效的【枚举项】节点</source>
        <translation type="unfinished">Nodo [Elemento de Enumeración] inválido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node.cpp" line="1542"/>
        <source>移动【枚举项】失败</source>
        <translation type="unfinished">Fallo al mover [Elemento de Enumeración]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="34"/>
        <source>权限不足</source>
        <translation type="unfinished">Permisos insuficientes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="34"/>
        <source>无写权限</source>
        <translation type="unfinished">Sin permiso de escritura</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/enumtool_widget.cpp" line="78"/>
        <source>Warning</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/enumtool_widget.cpp" line="78"/>
        <source>请先保存当前编辑的枚举组</source>
        <translation type="unfinished">¡Por favor, guarde el grupo de enumeración editado actualmente primero!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/enumtool_widget.cpp" line="122"/>
        <source>没有读取权限</source>
        <translation type="unfinished">Sin permiso de lectura</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui_enumtool::DlgCreateEnumGroup</name>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_group/dlg_create_enum_group.ui" line="14"/>
        <source>创建枚举组</source>
        <translation type="unfinished">Nuevo grupo de enumeraciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_group/dlg_create_enum_group.ui" line="22"/>
        <source>显示名称</source>
        <translation type="unfinished">Nombre de visualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_group/dlg_create_enum_group.ui" line="29"/>
        <source>若为空，则和代码名称一致</source>
        <translation type="unfinished">Si está vacío, será el mismo que el nombre de código</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_group/dlg_create_enum_group.ui" line="36"/>
        <source>不可重复，仅允许字母数字下划线，且不能以数字开头</source>
        <translation type="unfinished">No puede repetirse, solo se permiten letras, números y guiones bajos, y no puede comenzar con un número</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_group/dlg_create_enum_group.ui" line="43"/>
        <source>关联域</source>
        <translation type="unfinished">Dominios vinculados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_group/dlg_create_enum_group.ui" line="50"/>
        <source>输入以英文逗号分隔的数字</source>
        <translation type="unfinished">Ingrese números separados por comas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_group/dlg_create_enum_group.ui" line="57"/>
        <source>代码名称</source>
        <translation type="unfinished">Nombre de código</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_group/dlg_create_enum_group.cpp" line="53"/>
        <source>代码名称不合法</source>
        <translation type="unfinished">Nombre de código no válido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_group/dlg_create_enum_group.cpp" line="58"/>
        <source>关联域输入不合法</source>
        <translation type="unfinished">La entrada del dominio asociado es ilegal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_group/dlg_create_enum_group.cpp" line="87"/>
        <source>名称重复</source>
        <translation type="unfinished">Nombre duplicado</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui_enumtool::DlgCreateEnumItem</name>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_item/dlg_create_enum_item.ui" line="14"/>
        <source>添加枚举项</source>
        <translation type="unfinished">Agregar elementos de enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_item/dlg_create_enum_item.ui" line="22"/>
        <source>显示名称</source>
        <translation type="unfinished">Nombre de visualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_item/dlg_create_enum_item.ui" line="32"/>
        <source>代码名称</source>
        <translation type="unfinished">Nombre de código</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_item/dlg_create_enum_item.ui" line="42"/>
        <source>枚举值</source>
        <translation type="unfinished">Valores de enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_item/dlg_create_enum_item.ui" line="62"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_item/dlg_create_enum_item.cpp" line="58"/>
        <source>非法输入</source>
        <translation type="unfinished">Entrada inválida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_create_enum_item/dlg_create_enum_item.cpp" line="58"/>
        <source>请检查输入</source>
        <translation type="unfinished">Por favor, revise su entrada</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui_enumtool::DlgNewFile</name>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_new_file/dlg_new_file.ui" line="14"/>
        <source>新建库</source>
        <translation type="unfinished">Nueva base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_new_file/dlg_new_file.ui" line="22"/>
        <source>路径</source>
        <translation type="unfinished">Ruta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_new_file/dlg_new_file.ui" line="29"/>
        <source>显示名称</source>
        <translation type="unfinished">Nombre de visualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_new_file/dlg_new_file.ui" line="36"/>
        <source>若为空，则和上方一致</source>
        <translation type="unfinished">Si está vacío, será el mismo que el anterior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_new_file/dlg_new_file.ui" line="52"/>
        <source>实时库名，不可重复，不可包含 .\\/:*?&quot;&lt;&gt;|</source>
        <translation type="unfinished">Nombre de TDB: debe ser único y no debe contener .\\/:*?&quot;|</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_new_file/dlg_new_file.ui" line="61"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_new_file/dlg_new_file.cpp" line="55"/>
        <source>非法输入</source>
        <translation type="unfinished">Entrada inválida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/dialogs/dlg_new_file/dlg_new_file.cpp" line="55"/>
        <source>URI不能为空或包含非法字符</source>
        <translation type="unfinished">La URI no puede estar vacía ni contener caracteres ilegales.</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui_enumtool::EnumDBModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_db_viewer/enum_db_model.cpp" line="459"/>
        <source>显示名称</source>
        <translation type="unfinished">Nombre de visualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_db_viewer/enum_db_model.cpp" line="463"/>
        <source>代码名称</source>
        <translation type="unfinished">Nombre de código</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_db_viewer/enum_db_model.cpp" line="467"/>
        <source>关联域</source>
        <translation type="unfinished">Dominios vinculados</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui_enumtool::EnumDBViewer</name>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_db_viewer/enum_db_viewer.cpp" line="137"/>
        <source>查看枚举组</source>
        <translation type="unfinished">Ver grupos de enumeraciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_db_viewer/enum_db_viewer.cpp" line="213"/>
        <source>转到信息展示</source>
        <translation type="unfinished">Ir a la visualización de información</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_db_viewer/enum_db_viewer.cpp" line="220"/>
        <source>新增</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_db_viewer/enum_db_viewer.cpp" line="221"/>
        <source>上移</source>
        <translation type="unfinished">Mover arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_db_viewer/enum_db_viewer.cpp" line="222"/>
        <source>下移</source>
        <translation type="unfinished">Mover abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_db_viewer/enum_db_viewer.cpp" line="223"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui_enumtool::EnumGroupModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_group_viewer/enum_group_model.cpp" line="484"/>
        <source>显示名称</source>
        <translation type="unfinished">Nombre de visualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_group_viewer/enum_group_model.cpp" line="486"/>
        <source>代码名称</source>
        <translation type="unfinished">Nombre de código</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_group_viewer/enum_group_model.cpp" line="488"/>
        <source>枚举值</source>
        <translation type="unfinished">Valores de enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_group_viewer/enum_group_model.cpp" line="490"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui_enumtool::EnumGroupViewer</name>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_group_viewer/enum_group_viewer.cpp" line="116"/>
        <source>16进制</source>
        <translation type="unfinished">Hexadecimal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_group_viewer/enum_group_viewer.cpp" line="130"/>
        <source>新增枚举</source>
        <translation type="unfinished">Nueva enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_group_viewer/enum_group_viewer.cpp" line="146"/>
        <source>新增子枚举</source>
        <translation type="unfinished">Nueva subenumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_group_viewer/enum_group_viewer.cpp" line="156"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_group_viewer/enum_group_viewer.cpp" line="276"/>
        <source>上移</source>
        <translation type="unfinished">Mover arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_group_viewer/enum_group_viewer.cpp" line="163"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_group_viewer/enum_group_viewer.cpp" line="277"/>
        <source>下移</source>
        <translation type="unfinished">Mover abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_group_viewer/enum_group_viewer.cpp" line="177"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_group_viewer/enum_group_viewer.cpp" line="183"/>
        <source>重置枚举值</source>
        <translation type="unfinished">Restablecer valor de enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/enum_group_viewer/enum_group_viewer.cpp" line="190"/>
        <source>重置所有枚举值</source>
        <translation type="unfinished">Restablecer todos los valores de enumeración</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui_enumtool::EnumNodeModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="47"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="675"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="687"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="696"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="708"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="722"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="731"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="744"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="755"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="429"/>
        <source>无法获取父节点</source>
        <translation type="unfinished">No se puede obtener el nodo padre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="453"/>
        <source>暂不支持删除目录</source>
        <translation type="unfinished">Aún no se admite la eliminación de directorios</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="553"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="592"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="620"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="649"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="785"/>
        <source>不是有效的节点</source>
        <translation type="unfinished">Nodo inválido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="558"/>
        <source>不允许超过 2 级子枚举</source>
        <translation type="unfinished">No se permiten más de 2 niveles de subenumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/common/enum_node_model.cpp" line="774"/>
        <source>根节点未初始化</source>
        <translation type="unfinished">El nodo raíz no está inicializado</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui_enumtool::EnumTreeModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="329"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="344"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="359"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="380"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="395"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="417"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="431"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="445"/>
        <source>无效的数据源</source>
        <translation type="unfinished">Fuente de datos no válida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="365"/>
        <source>无写权限！</source>
        <translation type="unfinished">¡No tiene permiso de escritura!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="402"/>
        <source>本枚举存在草稿，是否使用草稿生成头文件？</source>
        <translation type="unfinished">Existe un borrador para esta enumeración. ¿Desea utilizar el borrador para generar el archivo de encabezado?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="403"/>
        <source>导出头文件</source>
        <translation type="unfinished">Exportar archivo de encabezado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="452"/>
        <source>存在草稿，是否删除草稿？</source>
        <translation type="unfinished">Existe un borrador. ¿Desea eliminarlo?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="453"/>
        <source>删除源文件</source>
        <translation type="unfinished">Eliminar archivo de origen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="460"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="462"/>
        <source>删除草稿</source>
        <translation type="unfinished">Eliminar borradores</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="462"/>
        <source>草稿已删除</source>
        <translation type="unfinished">Borrador eliminado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="492"/>
        <source>保存失败</source>
        <translation type="unfinished">Fallo al guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="501"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="508"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="514"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="501"/>
        <source>当前有枚举正在编辑中，请先保存后再编辑其他枚举</source>
        <translation type="unfinished">Enumeración en edición, guarde antes de editar otra</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="508"/>
        <source>请选择一个枚举文件</source>
        <translation type="unfinished">Seleccione un archivo de enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="514"/>
        <source>枚举文件未打开</source>
        <translation type="unfinished">Archivo de enumeración no abierto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="521"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_model.cpp" line="607"/>
        <source>未发布</source>
        <translation type="unfinished">No publicado</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui_enumtool::EnumTreeView</name>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="105"/>
        <source>打开枚举配置</source>
        <translation type="unfinished">Abrir configuración de enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="125"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="129"/>
        <source>保存枚举配置</source>
        <translation type="unfinished">Guardar configuración de enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="129"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="142"/>
        <source>请求编辑</source>
        <translation type="unfinished">Solicitar edición</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="158"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="171"/>
        <source>关闭枚举配置</source>
        <translation type="unfinished">Apagar configuración de enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="159"/>
        <source>当前枚举正在编辑，是否保存</source>
        <translation type="unfinished">La enumeración actual está siendo editada, ¿desea guardarla?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="185"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="192"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="199"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="205"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="209"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="478"/>
        <source>导出头文件</source>
        <translation type="unfinished">Exportar archivo de encabezado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="185"/>
        <source>此功能仅允许在 IASP 路径下使用，请联系管理员！</source>
        <translation type="unfinished">¡Esta función solo está permitida en la ruta IASP, por favor contacte al administrador!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="193"/>
        <source>当前枚举正在编辑，导出的头文件可能不是最新的，是否继续？</source>
        <translation type="unfinished">La enumeración actual está siendo editada El archivo de encabezado exportado puede no ser el más reciente. ¿Desea continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="209"/>
        <source>导出成功</source>
        <translation type="unfinished">Exportación exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="269"/>
        <source>删除枚举组</source>
        <translation type="unfinished">Eliminar grupo de enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="270"/>
        <source>确定要删除枚举组 %1 吗？</source>
        <translation type="unfinished">¿Está seguro de eliminar el grupo de enumeración %1?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="299"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="303"/>
        <source>发布枚举配置</source>
        <translation type="unfinished">Publicar configuración de enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="303"/>
        <source>发布成功</source>
        <translation type="unfinished">Publicación exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="322"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="330"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="334"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="484"/>
        <source>清除草稿</source>
        <translation type="unfinished">Borrar borrador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="323"/>
        <source>确定要清除 %1 的草稿吗？</source>
        <translation type="unfinished">¿Está seguro de borrar el borrador de %1?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="334"/>
        <source>清除成功</source>
        <translation type="unfinished">Borrado exitoso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="347"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="351"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="483"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="485"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="351"/>
        <source>删除成功</source>
        <translation type="unfinished">Eliminado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="473"/>
        <source>打开</source>
        <translation type="unfinished">Abrir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="474"/>
        <source>新建</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="475"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="476"/>
        <source>编辑</source>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="477"/>
        <source>关闭</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="479"/>
        <source>发布</source>
        <translation type="unfinished">Publicar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="480"/>
        <source>新建枚举组</source>
        <translation type="unfinished">Nuevo grupo de enumeraciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="481"/>
        <source>上移</source>
        <translation type="unfinished">Mover arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/node_explorer/enum_tree_view.cpp" line="482"/>
        <source>下移</source>
        <translation type="unfinished">Mover abajo</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui_enumtool::FileInfoModel</name>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/file_info_viewer/file_info_model.cpp" line="100"/>
        <source>属性</source>
        <translation type="unfinished">Atributos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/file_info_viewer/file_info_model.cpp" line="104"/>
        <source>值</source>
        <translation type="unfinished">Valor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/file_info_viewer/file_info_model.cpp" line="163"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/file_info_viewer/file_info_model.cpp" line="164"/>
        <source>路径</source>
        <translation type="unfinished">Ruta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/file_info_viewer/file_info_model.cpp" line="165"/>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/file_info_viewer/file_info_model.cpp" line="173"/>
        <source>创建时间</source>
        <translation type="unfinished">Nuevo tiempo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/file_info_viewer/file_info_model.cpp" line="169"/>
        <source>枚举名称</source>
        <translation type="unfinished">Nombre de la enumeración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/file_info_viewer/file_info_model.cpp" line="170"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/file_info_viewer/file_info_model.cpp" line="171"/>
        <source>数据库名</source>
        <translation type="unfinished">Nombre de la base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/file_info_viewer/file_info_model.cpp" line="172"/>
        <source>文件路径</source>
        <translation type="unfinished">Ruta del archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/file_info_viewer/file_info_model.cpp" line="174"/>
        <source>修改时间</source>
        <translation type="unfinished">Tiempo de modificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/file_info_viewer/file_info_model.cpp" line="175"/>
        <source>文件大小</source>
        <translation type="unfinished">Tamaño del archivo</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui_enumtool::FileInfoViewer</name>
    <message>
        <location filename="../../../../src/plat/base/plug/enumtool_widget/components/file_info_viewer/file_info_viewer.cpp" line="77"/>
        <source>转到数据展示</source>
        <translation type="unfinished">Ir a la visualización de datos</translation>
    </message>
</context>
</TS>
