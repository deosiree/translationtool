<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/include/copy_sql_dlg.h" line="18"/>
        <source>sql语句</source>
        <translation type="unfinished">SQL statement</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/include/copy_sql_dlg.h" line="25"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5323"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/include/copy_sql_dlg.h" line="29"/>
        <source>复制</source>
        <translation type="unfinished">Copy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="247"/>
        <source>数据查询</source>
        <translation type="unfinished">Query data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="248"/>
        <source>数据同步</source>
        <translation type="unfinished">Data Sync</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="249"/>
        <source>导入/导出</source>
        <translation type="unfinished">I/E</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="250"/>
        <source>备份/恢复</source>
        <translation type="unfinished">Backup/Recover</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="284"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="293"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="299"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="303"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="307"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="320"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="791"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="890"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="924"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="931"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="973"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2930"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3139"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3143"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3366"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3368"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3663"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3777"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3827"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4148"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4188"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4199"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4214"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4537"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4558"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4593"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4612"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4619"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4642"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4662"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4696"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4715"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4722"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4798"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4902"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5177"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5276"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5351"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5548"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5769"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5960"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="284"/>
        <source>获取节点名失败</source>
        <translation type="unfinished">Failed to retrieve the node name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="293"/>
        <source>访问sysmdl失败</source>
        <translation type="unfinished">Failed to access sysmdl</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="299"/>
        <source>获取历史库应用失败</source>
        <translation type="unfinished">Failed to retrieve HDB application</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="303"/>
        <source>历史库应用不唯一</source>
        <translation type="unfinished">HDB application is not unique</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="307"/>
        <source>历史库应用为空</source>
        <translation type="unfinished">HDB application is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="320"/>
        <source>查找部署指定服务进程的节点名失败</source>
        <translation type="unfinished">Failed to find the node name for deploying the specified service process</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="791"/>
        <source>请先断开当前连接，然后再选择其他节点</source>
        <translation type="unfinished">Please disconnect the current connection before selecting another node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="815"/>
        <source>IP: %1, 端口: %2</source>
        <translation type="unfinished">IP: %1, Port: %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="275"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="826"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="966"/>
        <source>连接</source>
        <translation type="unfinished">Connect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="82"/>
        <source>同步</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Sync</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="890"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4214"/>
        <source>获取%1节点表信息失败</source>
        <translation type="unfinished">Failed to retrieve %1 node table info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="984"/>
        <source>关系库(RDB)</source>
        <translation type="unfinished">RDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="987"/>
        <source>时序库(SDB)</source>
        <translation type="unfinished">SDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="990"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1023"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1030"/>
        <source>未知</source>
        <translation type="unfinished">Unknown</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="924"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="931"/>
        <source>连接%1节点库成功</source>
        <translation type="unfinished">Connected to %1 db successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="700"/>
        <source>开始下载导出文件...</source>
        <translation type="unfinished">Downloading exported file...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="973"/>
        <source>已断开与%1节点库的连接</source>
        <translation type="unfinished">Disconnected from %1 node DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1178"/>
        <source>字段名</source>
        <translation type="unfinished">field name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1180"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1232"/>
        <source>字段类型</source>
        <translation type="unfinished">Field type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1230"/>
        <source>字段名称</source>
        <translation type="unfinished">Field name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1234"/>
        <source>对象内偏移</source>
        <translation type="unfinished">Object internal offset</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1913"/>
        <source>同步中</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Synchronizing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2033"/>
        <source>%1 表 %2 无法同步 , 目标库不存在该表且无法建表</source>
        <translation type="unfinished">%1 table %2 cannot be synchronized. The table does not exist in the destination db and cannot be created.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2050"/>
        <source>%1 开始同步表: %2 (%3/%4)</source>
        <translation type="unfinished">%1 Starting synchronization of table: %2 (%3/%4)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2063"/>
        <source>%1 表 %2 无法同步 , 标签和主键不一致</source>
        <translation type="unfinished">%1 table %2 cannot be synchronized, label and primary key are inconsistent</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2113"/>
        <source>%1 表 %2 无法同步</source>
        <translation type="unfinished">%1 table %2 could not be synchronized</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2145"/>
        <source>%1 表 %2 同步成功</source>
        <translation type="unfinished">%1 table %2 synchronized successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2158"/>
        <source>%1 表 %2 同步失败</source>
        <translation type="unfinished">Synchronization failed for %1 table %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2192"/>
        <source>表%1的分区策略为按3小时分区，采用15分钟分片</source>
        <translation type="unfinished">The partition strategy for table %1 is based on 3-hour intervals, with 15-minute slice</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2197"/>
        <source>表%1的分区策略为按6小时分区，采用30分钟分片</source>
        <translation type="unfinished">The partition strategy for table %1 is based on 6-hour intervals, with 30-minute slice</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2202"/>
        <source>表%1的分区策略为按12小时分区，采用1小时分片</source>
        <translation type="unfinished">The partition strategy for table %1 is based on 12-hour intervals, with 1-hour slice</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2207"/>
        <source>表%1的分区策略为按天分区，采用2小时分片</source>
        <translation type="unfinished">The partition strategy for table %1 is based on days, with 2-hour slice</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2212"/>
        <source>表%1的分区策略为按月分区，采用1天分片</source>
        <translation type="unfinished">The partition strategy for table %1 is based on monthly partitions, with 1-day slice</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2217"/>
        <source>表%1的分区策略为按年分区，不分片</source>
        <translation type="unfinished">The partition strategy for table %1 is based on year, without slice</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2221"/>
        <source>表%1的分区策略未知，不分片</source>
        <translation type="unfinished">The partition strategy of table %1 is unknown, without slice</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2253"/>
        <source>生成 %1 个时间分片</source>
        <translation type="unfinished">Generate %1 time slices</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2257"/>
        <source>不分片，整个时间范围作为一个批次</source>
        <translation type="unfinished">Without slice, the entire time range is treated as one batch</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2930"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3663"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3777"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3827"/>
        <source>获取表信息失败</source>
        <translation type="unfinished">Failed to retrieve table info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3119"/>
        <source>是否删除表</source>
        <translation type="unfinished">Delete table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3120"/>
        <source>是否删除%1表</source>
        <translation type="unfinished">Delete %1 table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3127"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3128"/>
        <source>是否同步删除本现场其他节点</source>
        <translation type="unfinished">Whether to delete other nodes on this site synchronously</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3140"/>
        <source>删除%1表失败</source>
        <translation type="unfinished">Failed to delete table %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3144"/>
        <source>删除%1表成功</source>
        <translation type="unfinished">Deleting the %1 table succeeded</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3354"/>
        <source>是否清除</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3355"/>
        <source>是否清除待同步信息</source>
        <translation type="unfinished">Clear unsynced info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3366"/>
        <source>清除失败</source>
        <translation type="unfinished">Clear failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3368"/>
        <source>清除成功</source>
        <translation type="unfinished">Clear successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3589"/>
        <source>待同步信息</source>
        <translation type="unfinished">Unsynced</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4188"/>
        <source>只有一个历史库节点，无法进行同步</source>
        <translation type="unfinished">Only one HDB node, unable to synchronize</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4198"/>
        <source>%1节点连接失败</source>
        <translation type="unfinished">Node %1 connection failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4213"/>
        <source>%1节点获取表信息失败</source>
        <translation type="unfinished">Node %1 failed to retrieve table info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4379"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4402"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5087"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5119"/>
        <source>数据文件</source>
        <translation type="unfinished">Data file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4593"/>
        <source>请选择要导出的表</source>
        <translation type="unfinished">Select the table you want to export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4612"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4715"/>
        <source>结束时间必须大于开始时间</source>
        <translation type="unfinished">The end time must be longer than the start time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4619"/>
        <source>请选择导出路径</source>
        <translation type="unfinished">Select an export path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4643"/>
        <source>部分数据已导入，后续数据是否取消导入？</source>
        <translation type="unfinished">Some data has been imported. Cancel importing the remaining data?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4696"/>
        <source>请选择要导入的表</source>
        <translation type="unfinished">Select the table you want to import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4722"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6632"/>
        <source>请选择导入文件</source>
        <translation type="unfinished">Please select the import file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4746"/>
        <source>错误：未选择要导出的表</source>
        <translation type="unfinished">Error: No table to export is selected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4857"/>
        <source>错误：未选择要导入的表</source>
        <translation type="unfinished">Error: The table to import is not selected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4989"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6690"/>
        <source>备份将对整个数据库进行全量备份，请选择备份文件保存路径</source>
        <translation type="unfinished">Backup will perform a full backup of the entire db. Please select the backup file save path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4990"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6694"/>
        <source>恢复将覆盖当前数据库中的数据，请谨慎操作</source>
        <translation type="unfinished">Perform this operation with caution because data in the current db will be overwritten</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5067"/>
        <source>选择备份目录</source>
        <translation type="unfinished">Select backup dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5084"/>
        <source>保存备份文件</source>
        <translation type="unfinished">Save backup file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5107"/>
        <source>选择恢复目录</source>
        <translation type="unfinished">Select recovery dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5116"/>
        <source>选择恢复文件</source>
        <translation type="unfinished">Select recovery file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5177"/>
        <source>历史数据清理阈值更新成功</source>
        <translation type="unfinished">The historical data cleaning threshold has been successfully updated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5179"/>
        <source>历史数据清理阈值更新失败</source>
        <translation type="unfinished">Failed to update historical data cleaning threshold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5179"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5288"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5317"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5364"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5393"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5400"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5864"/>
        <source>待计算</source>
        <translation type="unfinished">To be calculated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6215"/>
        <source>选择计算剩余存储时间的时间单位（1小时/1天）</source>
        <translation type="unfinished">Choose the time unit for calculating the remaining storage time (1 hour/1 day)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6221"/>
        <source>1小时</source>
        <translation type="unfinished">1 hour</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6222"/>
        <source>1天</source>
        <translation type="unfinished">1 day</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6245"/>
        <source>磁盘空间超过该值时，会自动清理历史库数据</source>
        <translation type="unfinished">When the disk space exceeds this value, the HDB data will be automatically cleared</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6244"/>
        <source>数据天数超过该值后，会自动清理历史库数据</source>
        <translation type="unfinished">After the number of data days exceeds this value, the HDB data will be automatically cleared</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4632"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4733"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5446"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5829"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4904"/>
        <source>导入已取消</source>
        <translation type="unfinished">Import cancelled</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4653"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4859"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4929"/>
        <source>导入</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4661"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4662"/>
        <source>导入取消失败</source>
        <translation type="unfinished">Import cancellation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4795"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4798"/>
        <source>导出失败</source>
        <translation type="unfinished">Export failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4805"/>
        <source>导出取消完成，已删除导出文件</source>
        <translation type="unfinished">Export cancelled, exported file deleted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4811"/>
        <source>历史数据导出成功，耗时: %1 秒</source>
        <translation type="unfinished">Historical data export successful, time elapsed: %1 seconds</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="7032"/>
        <source>历史数据导出中，已耗时: %1 秒</source>
        <translation type="unfinished">Historical data export in progress, time elapsed: %1 seconds</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4899"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4902"/>
        <source>导入失败</source>
        <translation type="unfinished">Import failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4912"/>
        <source>历史数据导入成功，耗时: %1 秒</source>
        <translation type="unfinished">Historical data import successful, time elapsed: %1 seconds</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="7036"/>
        <source>历史数据导入中，已耗时: %1 秒</source>
        <translation type="unfinished">Historical data import in progress, time elapsed: %1 seconds</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5277"/>
        <source>是否取消备份？</source>
        <translation type="unfinished">Whether to cancel the backup?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5287"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5288"/>
        <source>取消备份失败</source>
        <translation type="unfinished">Failed to cancel the backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5317"/>
        <source>请先选择备份文件保存路径</source>
        <translation type="unfinished">Select a path to save the backup file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5324"/>
        <source>是否开始备份，耗时可能较长，请确认是否继续。</source>
        <translation type="unfinished">Whether to start the backup? It may take a long time, please confirm whether to continue.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5332"/>
        <source>正在准备备份...</source>
        <translation type="unfinished">Preparing a backup...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5361"/>
        <source>恢复任务已取消，等待启动历史应用</source>
        <translation type="unfinished">Recovery task has been canceled, waiting to start the historical application</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5363"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5364"/>
        <source>取消恢复失败</source>
        <translation type="unfinished">Cancel recovery failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5393"/>
        <source>请先选择恢复文件</source>
        <translation type="unfinished">Please select recovery file first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5415"/>
        <source>正在准备恢复...</source>
        <translation type="unfinished">Preparing recovery...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5427"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5664"/>
        <source>错误：未连接数据库</source>
        <translation type="unfinished">Error: The db is not connected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5429"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5527"/>
        <source>备份</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5434"/>
        <source>开始备份...</source>
        <translation type="unfinished">Start backing up...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5435"/>
        <source>备份过程中请勿关闭窗口</source>
        <translation type="unfinished">Do not close the window during backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5546"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5548"/>
        <source>备份失败</source>
        <translation type="unfinished">Backup failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5558"/>
        <source>备份取消完成，已删除备份文件</source>
        <translation type="unfinished">Backup cancellation completed, backup files have been deleted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5563"/>
        <source>历史数据备份成功，耗时: %1 秒</source>
        <translation type="unfinished">Historical data backup succeeded. Time elapsed: %1 second(s).</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="7040"/>
        <source>历史数据备份中，已耗时: %1 秒</source>
        <translation type="unfinished">Historical data backup in progress, time elapsed: %1 seconds</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5666"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5704"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5732"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5786"/>
        <source>恢复</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Recover</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5671"/>
        <source>开始恢复...</source>
        <translation type="unfinished">Start recovering...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5672"/>
        <source>恢复过程中请勿关闭窗口</source>
        <translation type="unfinished">Do not close the window during restoration</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5673"/>
        <source>历史库应用正在切离线...</source>
        <translation type="unfinished">HDB application is being cut offline...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5699"/>
        <source>历史库应用切离线失败</source>
        <translation type="unfinished">Failed to cut HDB application offline</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5707"/>
        <source>历史库应用切离线成功</source>
        <translation type="unfinished">HDB application is successfully cut offline</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5729"/>
        <source>错误：恢复文件路径为空</source>
        <translation type="unfinished">Error: The recovery file path is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5756"/>
        <source>历史库应用启动成功</source>
        <translation type="unfinished">HDB application started successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5759"/>
        <source>历史库应用启动失败</source>
        <translation type="unfinished">Failed to start HDB application</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5771"/>
        <source>恢复已取消</source>
        <translation type="unfinished">Recovery canceled</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5861"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5882"/>
        <source>剩余空间不足，将自动删除旧数据</source>
        <translation type="unfinished">Insufficient remaining space, old data will be automatically deleted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5929"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6136"/>
        <source>历史库容量估计</source>
        <translation type="unfinished">Estimation of HDB capacity</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5930"/>
        <source>历史库容量估计（剩余容量不足）</source>
        <translation type="unfinished">Estimation of HDB capacity (insufficient remaining capacity)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5960"/>
        <source>请先连接数据库</source>
        <translation type="unfinished">Connect to the db first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5876"/>
        <source>%1 年</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5877"/>
        <source>%1 月</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 M</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5878"/>
        <source>%1 天</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 D</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5879"/>
        <source>%1 小时</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 H</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5352"/>
        <source>取消恢复可能导致历史数据库损坏，是否继续？</source>
        <translation type="unfinished">Canceling the recovery may cause damage to the HDB. Whether to continue?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5401"/>
        <source>恢复操作将清空数据库中的现有数据再恢复，且本节点hisdb应用将切离线，是否继续？</source>
        <translation type="unfinished">Recovery operation will clear the existing data in the db before recovery, and the hisdb application on this node will be offline. Whether to continue?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5765"/>
        <source>恢复文件不合法，请检查文件是否正确</source>
        <translation type="unfinished">Restoring files is invalid. Please check if the files are correct</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5767"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5769"/>
        <source>恢复失败</source>
        <translation type="unfinished">Recover failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5777"/>
        <source>历史数据恢复成功，耗时: %1 秒</source>
        <translation type="unfinished">Historical data recovery successful, time elapsed: %1 seconds</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="7044"/>
        <source>历史数据恢复中，已耗时: %1 秒</source>
        <translation type="unfinished">Historical data recovery in progress, time elapsed: %1 seconds</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6021"/>
        <source>历史库基础信息</source>
        <translation type="unfinished">Basic info of HDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2177"/>
        <source>%1 表不存在或获取表信息失败</source>
        <translation type="unfinished">The %1 table does not exist or the attempt to retrieve table information failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2228"/>
        <source>%1 表的时间字段异常</source>
        <translation type="unfinished">The time field of the %1 table is abnormal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2239"/>
        <source>时间范围无效: 开始时间 &gt;= 结束时间</source>
        <translation type="unfinished">Invalid time range: start time &gt;= end time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2270"/>
        <source>开始扫描时间分片数据...</source>
        <translation type="unfinished">Starting to scan time-sliced data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2277"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2351"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2393"/>
        <source>同步已取消</source>
        <translation type="unfinished">Synchronization canceled</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2325"/>
        <source>没有需要同步的数据</source>
        <translation type="unfinished">No data needs to be synchronized</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2330"/>
        <source>扫描完成，总计 %1 个时间分片，%2 条数据</source>
        <translation type="unfinished">Scan completed, total: time slice: %1; data: %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2378"/>
        <source>同步时间片 %1/%2: %3 (%4条数据)</source>
        <translation type="unfinished">Synchronization time slice %1/%2: %3 (%4 pieces of data)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2414"/>
        <source>查询失败: 时间片 %1, 批次 %2</source>
        <translation type="unfinished">Query failed: time slice %1, batch %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2430"/>
        <source>插入失败: 时间片 %1, 批次 %2</source>
        <translation type="unfinished">Insertion failed: time slice %1, batch %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2449"/>
        <source>已处理 %1/%2 条数据</source>
        <translation type="unfinished">Processed data: %1/%2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2466"/>
        <source>时间片 %1 同步完成</source>
        <translation type="unfinished">Time slice %1 synchronization completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2470"/>
        <source>%1 表同步完成，共处理 %2 个时间分片，%3 条数据</source>
        <translation type="unfinished">%1 table synchronization completed, total: time slice: %2; data: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6119"/>
        <source>数据库节点</source>
        <translation type="unfinished">DB node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6120"/>
        <source>数据库型号</source>
        <translation type="unfinished">DB model</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6121"/>
        <source>数据库名称</source>
        <translation type="unfinished">DB name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6122"/>
        <source>数据库版本</source>
        <translation type="unfinished">DB version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6123"/>
        <source>数据库类型</source>
        <translation type="unfinished">DB type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6124"/>
        <source>当前连接时间</source>
        <translation type="unfinished">Conn time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6192"/>
        <source>历史库磁盘完整容量</source>
        <translation type="unfinished">Full capacity of HDB disk</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6193"/>
        <source>历史库磁盘当前使用容量</source>
        <translation type="unfinished">HDB disk current used cap</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6194"/>
        <source>历史库磁盘剩余容量</source>
        <translation type="unfinished">HDB disk rem capacity</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6196"/>
        <source>历史库当前容量</source>
        <translation type="unfinished">Current capacity of HDB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6214"/>
        <source>存储计算时间依据</source>
        <translation type="unfinished">Stor calc time basis</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6235"/>
        <source>计算基准容量</source>
        <translation type="unfinished">Calc bench cap</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6237"/>
        <source>计算基准容量记录时间</source>
        <translation type="unfinished">Calc bench cap rec time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6242"/>
        <source>历史库数据保留天数</source>
        <translation type="unfinished">Number of days to retain HDB data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6242"/>
        <source>历史库磁盘清理阈值</source>
        <translation type="unfinished">HDB disk cleanup thresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6292"/>
        <source>历史库理论剩余容量</source>
        <translation type="unfinished">HDB theo rem cap</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6296"/>
        <source>历史库理论剩余可存时间</source>
        <translation type="unfinished">HDB theo rem stor time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6628"/>
        <source>请选择要导出的表和导出路径</source>
        <translation type="unfinished">Select the table to export and the export path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="871"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="949"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3623"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3732"/>
        <source>总共0条数据</source>
        <translation type="unfinished">Total 0 items</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="896"/>
        <source>断开</source>
        <translation type="unfinished">Disconnect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1131"/>
        <source>查询字段异常</source>
        <translation type="unfinished">Query field exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1133"/>
        <source>查询字段：%1</source>
        <translation type="unfinished">Query field: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1179"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1231"/>
        <source>字段别名</source>
        <translation type="unfinished">Field alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1181"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1233"/>
        <source>字段长度</source>
        <translation type="unfinished">Field length</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2000"/>
        <source>%1 表 %2 转换为实时库表名失败</source>
        <translation type="unfinished">%1 table %2 conversion to TDB table name failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3110"/>
        <source>删除表</source>
        <comment>menuName</comment>
        <translation type="unfinished">Delete table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3600"/>
        <source>待同步数据</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Unsynced Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3601"/>
        <source>待同步表结构</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Unsynced Table Structure</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4148"/>
        <source>请先连接一个库节点</source>
        <translation type="unfinished">Please connect a DB node first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4199"/>
        <source>打开%1节点失败</source>
        <translation type="unfinished">Failed to open the %1 node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4376"/>
        <source>选择导出路径</source>
        <translation type="unfinished">Select export path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4399"/>
        <source>选择导入文件</source>
        <translation type="unfinished">Select import file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4428"/>
        <source>获取文件中的表信息失败，错误码：%1</source>
        <translation type="unfinished">Failed to retrieve table info in file with error code %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4443"/>
        <source>获取文件中的时间范围失败，错误码：%1</source>
        <translation type="unfinished">Failed to retrieve time range in file with error code %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4456"/>
        <source>成功加载文件，包含%1张表，时间范围：%2 ~ %3</source>
        <translation type="unfinished">Successfully loaded file including %1 tables, time range: %2 ~ %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4538"/>
        <source>是否取消导出？</source>
        <translation type="unfinished">Whether to cancel the export?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4548"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4748"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4829"/>
        <source>导出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4557"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="4558"/>
        <source>导出取消失败</source>
        <translation type="unfinished">Export cancellation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/main.cpp" line="38"/>
        <source>历史库管理工具</source>
        <translation type="unfinished">HDB Manage Tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/query_result_model.cpp" line="136"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/query_result_model.cpp" line="557"/>
        <source>不支持的数据类型</source>
        <translation type="unfinished">Unsupported data type</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::ExpireTimeDialog</name>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/expire_time_dialog.cpp" line="20"/>
        <source>修改数据过期时间</source>
        <translation type="unfinished">Modify the expiration time of the data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/expire_time_dialog.cpp" line="33"/>
        <source>自定义时间</source>
        <translation type="unfinished">Custom time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/expire_time_dialog.cpp" line="34"/>
        <source>磁盘空间不足时清理</source>
        <translation type="unfinished">Cleanup on low disk space</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/expire_time_dialog.cpp" line="34"/>
        <source>按数据保留天数清理</source>
        <translation type="unfinished">Clean up by data retention days</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/expire_time_dialog.cpp" line="47"/>
        <source>小时</source>
        <translation type="unfinished">Hour</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/expire_time_dialog.cpp" line="47"/>
        <source>天</source>
        <translation type="unfinished">Day</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/expire_time_dialog.cpp" line="47"/>
        <source>月</source>
        <translation type="unfinished">Month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/expire_time_dialog.cpp" line="47"/>
        <source>年</source>
        <translation type="unfinished">Year</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::sdb_mgr_main</name>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="403"/>
        <source>获取数据类型枚举失败</source>
        <translation type="unfinished">Failed to retrieve data type enumeration</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="77"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1801"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1803"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1907"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2774"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2798"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2869"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2873"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2878"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2912"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2918"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2924"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2947"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2989"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2993"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3173"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3260"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3265"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3284"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3289"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3308"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3313"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3332"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3337"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3348"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3414"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3545"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3551"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3555"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3559"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3577"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3581"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3703"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3822"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3869"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5245"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1400"/>
        <source>数据过期时间:</source>
        <translation type="unfinished">Data expiration time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1402"/>
        <source>修改</source>
        <translation type="unfinished">Edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1907"/>
        <source>请选择要同步的表</source>
        <translation type="unfinished">Please select the table to synchronize</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="77"/>
        <source>同步完成</source>
        <translation type="unfinished">Sync completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="107"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1803"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2912"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3551"/>
        <source>请先连接数据库</source>
        <translation type="unfinished">Connect to the db first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1313"/>
        <source>未找到表信息</source>
        <translation type="unfinished">Table info not found</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2824"/>
        <source>表基本信息</source>
        <translation type="unfinished">Table basic info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1357"/>
        <source>表名:</source>
        <translation type="unfinished">Table name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="112"/>
        <source>操作步骤:</source>
        <translation type="unfinished">Operation steps:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="112"/>
        <source>1. 选择要连接的节点</source>
        <translation type="unfinished">1. Select the node to be connected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="112"/>
        <source>2. 点击&apos;连接&apos;按钮</source>
        <translation type="unfinished">2. Click on the &apos;Connect&apos; button</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="113"/>
        <source>3. 连接成功后即可进行数据查询和管理</source>
        <translation type="unfinished">3. After successful connection, data query and management can be carried out</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1328"/>
        <source>表基本信息</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Table Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1366"/>
        <source>别名:</source>
        <translation type="unfinished">Alias:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1370"/>
        <source>未设置别名</source>
        <translation type="unfinished">No alias set</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1377"/>
        <source>建表方式:</source>
        <translation type="unfinished">Table creation method:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1380"/>
        <source>对象建表</source>
        <translation type="unfinished">Object create table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1380"/>
        <source>列建表</source>
        <translation type="unfinished">Column create table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1394"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1394"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5201"/>
        <source>按数据保留天数清理</source>
        <translation type="unfinished">Clean up by data retention days</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1415"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5204"/>
        <source>磁盘空间不足时清理</source>
        <translation type="unfinished">Cleanup on low disk space</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1389"/>
        <source>oid作时间戳列:</source>
        <translation type="unfinished">OID as timestamp column:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1410"/>
        <source>按保留天数清理</source>
        <translation type="unfinished">Clean up by retention days</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1420"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5207"/>
        <source>永不删除</source>
        <translation type="unfinished">Never delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1469"/>
        <source>时序库参数</source>
        <translation type="unfinished">STDB params</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1520"/>
        <source>标签列表:</source>
        <translation type="unfinished">Tag list:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1545"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1637"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1687"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1759"/>
        <source>无</source>
        <translation type="unfinished">None</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1560"/>
        <source>关系库参数</source>
        <translation type="unfinished">RDB params</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1612"/>
        <source>主键列表:</source>
        <translation type="unfinished">Primary key list:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1643"/>
        <source>索引列表:</source>
        <translation type="unfinished">Index list:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1713"/>
        <source>分区字段:</source>
        <translation type="unfinished">Partition field:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1716"/>
        <source>分区类型:</source>
        <translation type="unfinished">Partition type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1727"/>
        <source>无分区</source>
        <translation type="unfinished">No partition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1730"/>
        <source>按年分区</source>
        <translation type="unfinished">Annual partitioning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1733"/>
        <source>按月分区</source>
        <translation type="unfinished">Divide by month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1736"/>
        <source>按天分区</source>
        <translation type="unfinished">Divide by day</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1748"/>
        <source>未知分区类型</source>
        <translation type="unfinished">Unknown partition type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2542"/>
        <source>列名: %1 的数据类型不匹配!</source>
        <translation type="unfinished">Column name: %1 has data type mismatch!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2543"/>
        <source>源数据类型: %1</source>
        <translation type="unfinished">Source data type: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2544"/>
        <source>目标数据类型: %3</source>
        <translation type="unfinished">Dest data type: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2551"/>
        <source>列名: %1 的数据长度不匹配!</source>
        <translation type="unfinished">Column name: %1 data length does not match!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2552"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2645"/>
        <source>源数据长度: %1</source>
        <translation type="unfinished">Source data length: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2553"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2646"/>
        <source>目标数据长度: %3</source>
        <translation type="unfinished">Dest data length: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2643"/>
        <source>字符串: %1 的源数据长度小于目的数据长度!</source>
        <translation type="unfinished">String: The source data length of %1 is smaller than the destination data length!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2774"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3265"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3313"/>
        <source>已经是第一页</source>
        <translation type="unfinished">Already the first page</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2798"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3289"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3337"/>
        <source>已经是最后一页</source>
        <translation type="unfinished">Already the last page</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5245"/>
        <source>数据过期时间设置成功</source>
        <translation type="unfinished">Data expiration time set successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5266"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5266"/>
        <source>设置数据过期时间失败</source>
        <translation type="unfinished">Failed to set data expiration time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5853"/>
        <source>%1天</source>
        <translation type="unfinished">%1 days</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6271"/>
        <source>历史库自动清理阈值，范围是20-95%</source>
        <translation type="unfinished">The automatic clearing threshold for HDB ranges from 20-95%</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6295"/>
        <source>历史库理论剩余容量，根据当前磁盘使用情况和清理阈值计算</source>
        <translation type="unfinished">HDB theoretical remaining capacity is calculated based on the current disk usage and cleanup threshold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="6298"/>
        <source>历史库理论剩余可存时间，根据历史库理论剩余容量与近期历史库数据增长计算</source>
        <translation type="unfinished">HDB theoretical remaining time is calculated based on HDB theoretical remaining capacity and the growth of recent HDB data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1801"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2918"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3555"/>
        <source>请选择要查询的表</source>
        <translation type="unfinished">Please select the table to query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1435"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5222"/>
        <source>%1 年</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1437"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5224"/>
        <source>%1 月</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 M</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1439"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5226"/>
        <source>%1 天</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 D</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1441"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5228"/>
        <source>%1 小时</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 H</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1443"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5230"/>
        <source>%1 分钟</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 Min</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1445"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="5233"/>
        <source>%1 秒</source>
        <comment>Upper</comment>
        <translation type="unfinished">%1 Sec</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1739"/>
        <source>按3小时分区</source>
        <translation type="unfinished">Divided into 3-hour intervals</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1742"/>
        <source>按6小时分区</source>
        <translation type="unfinished">Divided into 6-hour intervals</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="1745"/>
        <source>按12小时分区</source>
        <translation type="unfinished">Divided into 12-hour time partitions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2809"/>
        <source>表信息查询</source>
        <translation type="unfinished">Table info query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2869"/>
        <source>查询表结构失败</source>
        <translation type="unfinished">Failed to query table structure</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2873"/>
        <source>查询表元数据失败</source>
        <translation type="unfinished">Failed to query table metadata</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2878"/>
        <source>查询表基本信息失败</source>
        <translation type="unfinished">Failed to query basic info of the table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2884"/>
        <source>关闭</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2924"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3559"/>
        <source>开始时间不能大于结束时间</source>
        <translation type="unfinished">The start time cannot be greater than the end time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2944"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3390"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3670"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3784"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3834"/>
        <source>总共%1条数据</source>
        <translation type="unfinished">Total %1 items</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2946"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2947"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2989"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3260"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3284"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3308"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3332"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3388"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3414"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3672"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3703"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3786"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3822"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3836"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3869"/>
        <source>查询失败</source>
        <translation type="unfinished">Query failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2993"/>
        <source>查询成功</source>
        <translation type="unfinished">Query successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3173"/>
        <source>获取表信息失败</source>
        <translation type="unfinished">Failed to retrieve table info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3249"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3273"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3297"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3321"/>
        <source>Page %1 of %2</source>
        <translation type="unfinished">Page %1 of %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3348"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3577"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3582"/>
        <source>没有%1表</source>
        <translation type="unfinished">%1 table does not exist </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3545"/>
        <source>页数不合法</source>
        <translation type="unfinished">Invalid number of pages</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3613"/>
        <source>清除所有数据</source>
        <comment>menuName</comment>
        <translation type="unfinished">Clear all data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3717"/>
        <source>Context Menu</source>
        <translation type="unfinished">Context Menu</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3678"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3792"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3842"/>
        <source>Page 1 of %1</source>
        <translation type="unfinished">Page 1 of %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2839"/>
        <source>列信息（列建表）</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Column Info (Column)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="2853"/>
        <source>列信息（对象建表）</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Column Info (Object)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3680"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3795"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.cpp" line="3844"/>
        <source>Page 1 of 1</source>
        <translation type="unfinished">Page 1 of 1</translation>
    </message>
</context>
<context>
    <name>sdb_mgr_main</name>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="51"/>
        <source>库节点</source>
        <translation type="unfinished">Node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="147"/>
        <source>连接</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Connect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="169"/>
        <source>数据查询</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Query Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="180"/>
        <source>表名</source>
        <translation type="unfinished">Table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="207"/>
        <source>查询时段：      </source>
        <translation type="unfinished">Query period:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="214"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="228"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="473"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="487"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="725"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="739"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="939"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="953"/>
        <source>yyyy/M/d HH:mm:ss</source>
        <translation type="unfinished">yyyy/M/d HH:mm:ss</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="267"/>
        <source>总共0条数据</source>
        <translation type="unfinished">Total 0 items</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="304"/>
        <source>条件字符串：    </source>
        <translation type="unfinished">Condition string:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="340"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="373"/>
        <source>表信息</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Table info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="406"/>
        <source>SQL</source>
        <comment>buttonName</comment>
        <translation type="unfinished">SQL</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="430"/>
        <source>数据同步</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Data Sync</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="533"/>
        <source>同步</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Sync</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="577"/>
        <source>详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="610"/>
        <source>待同步信息</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Unsynced</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="666"/>
        <source>导入/导出</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">I/E</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="676"/>
        <source>导出</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="786"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="887"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1075"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1186"/>
        <source>选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="826"/>
        <source>导出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="843"/>
        <source>导入</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1000"/>
        <source>导入</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1021"/>
        <source>备份/恢复</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Backup/Recover</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1031"/>
        <source>备份</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1125"/>
        <source>备份</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Backup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1142"/>
        <source>恢复</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Recover</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1239"/>
        <source>恢复</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Recover</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1260"/>
        <source>历史库信息</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">HDB Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="438"/>
        <source>节点：</source>
        <translation type="unfinished">Node:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="445"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="459"/>
        <source>未连接库</source>
        <translation type="unfinished">DB not connected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="466"/>
        <source>时段：</source>
        <translation type="unfinished">Time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="246"/>
        <source>查询字段：</source>
        <translation type="unfinished">Query fields:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="621"/>
        <source>源表名</source>
        <translation type="unfinished">Source table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="631"/>
        <source>目的表名</source>
        <translation type="unfinished">Dest table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="641"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="704"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="918"/>
        <source>全选</source>
        <translation type="unfinished">Select all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="684"/>
        <source>选择导出表：</source>
        <translation type="unfinished">Select the export table:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="718"/>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="932"/>
        <source>时间范围：</source>
        <translation type="unfinished">Time range:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="750"/>
        <source>导出路径：</source>
        <translation type="unfinished">Export path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="851"/>
        <source>导入文件：</source>
        <translation type="unfinished">Import file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="898"/>
        <source>选择导入表：</source>
        <translation type="unfinished">Select the import table:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="964"/>
        <source>覆盖现有数据</source>
        <translation type="unfinished">Overwrite current data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1039"/>
        <source>备份文件路径：</source>
        <translation type="unfinished">Backup file path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1084"/>
        <source>备份将对整个数据库进行全量备份，包括所有表和所有时间范围的数据</source>
        <translation type="unfinished">The backup will make a full backup of the entire db, including all tables and data for all time ranges</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1150"/>
        <source>恢复文件：</source>
        <translation type="unfinished">Recover files:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1198"/>
        <source>警告：恢复操作将覆盖数据库中的现有数据，请谨慎操作！</source>
        <translation type="unfinished">Warning: The recovery operation will overwrite the existing data in the db, please exercise caution!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="1284"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/hisdb/gui_hisdb_tool/src/sdb_mgr_main.ui" line="76"/>
        <source>库名称</source>
        <translation type="unfinished">DB name</translation>
    </message>
</context>
</TS>
