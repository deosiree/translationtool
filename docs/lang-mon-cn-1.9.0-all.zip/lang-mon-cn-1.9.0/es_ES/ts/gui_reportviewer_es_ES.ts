<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>DataBlockParaDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_datablock_para.ui" line="14"/>
        <source>数据块配置</source>
        <translation type="unfinished">Configurar bloque de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_datablock_para.ui" line="20"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_datablock_para.ui" line="27"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_datablock_para.cpp" line="49"/>
        <source>数据块(%1)</source>
        <translation type="unfinished">Bloque de datos (%1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_datablock_para.cpp" line="62"/>
        <source>动态库名称：</source>
        <translation type="unfinished">Nombre de biblioteca dinámica:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_datablock_para.cpp" line="71"/>
        <source>方法名称：</source>
        <translation type="unfinished">Nombre de método:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/main.cpp" line="204"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/main.cpp" line="450"/>
        <source>%1 没有此工具的打开权限</source>
        <comment>gui_reportviewer::main</comment>
        <translation type="unfinished">%1 sin permiso para esta herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/main.cpp" line="205"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/main.cpp" line="243"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/main.cpp" line="451"/>
        <source>提示</source>
        <comment>gui_reportviewer::main</comment>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/main.cpp" line="244"/>
        <source>注册失败</source>
        <comment>gui_reportviewer::main</comment>
        <translation type="unfinished">Fallo al registrar</translation>
    </message>
</context>
<context>
    <name>ReportViewer</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="68"/>
        <source>报表浏览工具(节点名：%1)</source>
        <comment>toolName</comment>
        <translation type="unfinished">Visor de Informes (Nodo: %1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="92"/>
        <source>报表列表</source>
        <comment>toolName</comment>
        <translation type="unfinished">Lista de Informes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="121"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="121"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="228"/>
        <source>测点参数</source>
        <comment>toolName</comment>
        <translation type="unfinished">Parámetros del Punto de Medición</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="376"/>
        <source>登录时限：</source>
        <translation type="unfinished">Límite de tiempo de login:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="407"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="472"/>
        <source>%1 暂无此工具的权限</source>
        <translation type="unfinished">%1 sin permiso para esta herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="408"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="473"/>
        <source>提示</source>
        <translation type="unfinished">Consejo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="497"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="702"/>
        <source>报表刷新</source>
        <translation type="unfinished">Actualizar informe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="499"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="706"/>
        <source>开启定时刷新</source>
        <translation type="unfinished">Activar actualización programada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="501"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="710"/>
        <source>设置定时刷新周期</source>
        <translation type="unfinished">Establecer período de actualización del temporizador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="503"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="714"/>
        <source>关闭定时刷新</source>
        <translation type="unfinished">Desactivar actualización programada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="505"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="698"/>
        <source>重置查询时间</source>
        <translation type="unfinished">Restablecer tiempo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="507"/>
        <source>报表导出</source>
        <translation type="unfinished">Exportar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="509"/>
        <source>报表打印</source>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="511"/>
        <source>打印预览</source>
        <translation type="unfinished">Vista previa de impresión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="513"/>
        <source>报表编辑</source>
        <translation type="unfinished">Editar informe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="954"/>
        <source>设置</source>
        <translation type="unfinished">Ajustes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="954"/>
        <source>刷新周期（1-600秒）：</source>
        <translation type="unfinished">Ciclo de actualización (1-600s):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1139"/>
        <source>实时对象</source>
        <translation type="unfinished">Objeto en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1147"/>
        <source>历史对象</source>
        <translation type="unfinished">Objeto histórico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1150"/>
        <source>历史对象选择时间</source>
        <translation type="unfinished">Seleccionar hora del objeto histórico </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1152"/>
        <source>月底</source>
        <translation type="unfinished">Fin de mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1153"/>
        <source>年</source>
        <translation type="unfinished">Año</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1154"/>
        <source>月</source>
        <translation type="unfinished">Mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1155"/>
        <source>周</source>
        <translation type="unfinished">Semana</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1156"/>
        <source>日</source>
        <translation type="unfinished">Día</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1157"/>
        <source>时</source>
        <translation type="unfinished">Hora</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1158"/>
        <source>分</source>
        <translation type="unfinished">Minuto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1159"/>
        <source>本</source>
        <translation type="unfinished">Actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1160"/>
        <source>前</source>
        <translation type="unfinished">Anterior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1161"/>
        <source>后</source>
        <translation type="unfinished">Siguiente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1162"/>
        <source>求和</source>
        <translation type="unfinished">Suma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1163"/>
        <source>首部减去尾部</source>
        <translation type="unfinished">Cabeza menos Cola</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1164"/>
        <source>尾部减去首部</source>
        <translation type="unfinished">Cola menos Cabeza</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1167"/>
        <source>历史对象实际时间</source>
        <translation type="unfinished">Hora real del objeto histórico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1175"/>
        <source>公式</source>
        <translation type="unfinished">Fórmula</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1236"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1236"/>
        <source>该报表中不包含数据块内容</source>
        <translation type="unfinished">Reporte sin contenido de bloque de datos</translation>
    </message>
</context>
<context>
    <name>WildCardConfigaDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="14"/>
        <source>动态模板属性配置</source>
        <translation type="unfinished">Configurar atributos de plantillas dinámicas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="24"/>
        <source>通配符替换配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Reemplazo de Comodín de Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="31"/>
        <source>通配符</source>
        <translation type="unfinished">Comodín</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="36"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="41"/>
        <source>替换值</source>
        <translation type="unfinished">Reemplazar valor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="50"/>
        <source>应用库实例替换配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Config de Reemplazo de Instancia BD de la Aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="57"/>
        <source>源集合</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Conjunto de origen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="62"/>
        <source>源应用</source>
        <comment>subTitle</comment>
        <translation type="unfinished">App de origen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="67"/>
        <source>源库名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de la BD de origen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="72"/>
        <source>源实例</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Instancia de origen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="77"/>
        <source>目标应用</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Aplicación objetivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="82"/>
        <source>目标库名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de la biblioteca objetivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="87"/>
        <source>目标实例</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Instancia objetivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="112"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="119"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
</TS>
