<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="16"/>
        <source>决策无效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="19"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="124"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="135"/>
        <source>决策校验成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="30"/>
        <source>资源文件无效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="33"/>
        <source>资源文件校验成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="45"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="108"/>
        <source>唯一标识无效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="48"/>
        <source>图元数据无效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="51"/>
        <source>前景图元无效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="54"/>
        <source>图元态无效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="57"/>
        <source>图元无效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="60"/>
        <source>图元态名重复</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="63"/>
        <source>图元态信息重复</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="66"/>
        <source>图元态下没有对应的图元态信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="69"/>
        <source>图元态信息没有对应的图元态名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="72"/>
        <source>图元态名称为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="75"/>
        <source>图元信息名称为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="78"/>
        <source>图元库数据无效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="81"/>
        <source>图元层无效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="84"/>
        <source>图元文件无效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="87"/>
        <source>位置完全超出画布</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="90"/>
        <source>位置部分超出画布</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="93"/>
        <source>拓扑结构无效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="96"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="993"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="1018"/>
        <source>图元校验成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="111"/>
        <source>画面数据无效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="114"/>
        <source>画面文件无效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="117"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/picture_data_check.cpp" line="150"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/picture_data_check.cpp" line="175"/>
        <source>画面校验成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="156"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="168"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="159"/>
        <source>告警</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="162"/>
        <source>错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/common/common_data_check.cpp" line="165"/>
        <source>缺陷</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="94"/>
        <source>决策[%1]不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="100"/>
        <source>决策[%1]重复</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="111"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="148"/>
        <source>决策[%1]无法获取</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="118"/>
        <source>决策[%1]数据为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="159"/>
        <source>新决策重名，但与原决策数据一致，校验成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="164"/>
        <source>决策[%1]存在重名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="172"/>
        <source>当前节点下存在重名决策[%1]，无法进行导入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="261"/>
        <source>颜色决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="288"/>
        <source>使能决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="315"/>
        <source>字符决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="342"/>
        <source>符号决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="369"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="396"/>
        <source>闪烁决策[%1]应用[%2]与画面应用不一致</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="425"/>
        <source>画面[%1]文件[%2]读取失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="432"/>
        <source>画面[%1]文件[%2]解析错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="442"/>
        <source>画面[%1]文件[%2]格式错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="568"/>
        <source>获取图元决策类型错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="598"/>
        <source>获取图元文件读取错误，文件路径：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="606"/>
        <source>获取图元文件解析错误，文件路径：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/decision_data_check.cpp" line="616"/>
        <source>获取图元文件格式错误，文件路径：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="60"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="736"/>
        <source>图元[%1]不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="170"/>
        <source>在状态前景图元[%1]里：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="277"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="291"/>
        <source>%1存在空挂</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="310"/>
        <source>%1数据未关联</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="316"/>
        <source>光敏点%1数据未关联</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="343"/>
        <source>%1数据未生效:获取目标对象oid失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="349"/>
        <source>光敏点%1数据未生效:获取目标对象oid失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="365"/>
        <source>%1数据未生效:目标对象oid[%2]与当前保存oid[%3]不一致</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="371"/>
        <source>光敏点%1数据未生效:目标对象oid[%2]与当前保存oid[%3]不一致</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="411"/>
        <source>常规图元不允许有前景场景元素</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="424"/>
        <source>状态前景图元下存在非状态前景的场景元素</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="428"/>
        <source>字符前景图元下存在非字符前景的场景元素</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="432"/>
        <source>数值前景图元下存在非数值前景的场景元素</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="455"/>
        <source>状态前景没有配置关联图元</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="463"/>
        <source>状态前景下关联图元不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="516"/>
        <source>图元存在无效或者重复的唯一标识</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="543"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="576"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="651"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="686"/>
        <source>当前场景中的元素[%1]所处位置已经完全超出画布范围</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="555"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="592"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="667"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="699"/>
        <source>当前场景中的元素[%1]所处位置部分超出画布范围</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="717"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="725"/>
        <source>图元数据信息获取失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="766"/>
        <source>图元态不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="774"/>
        <source>图元层不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="804"/>
        <source>图元[%1]的图元态[%2]名称重复</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="818"/>
        <source>图元[%1]存在图元态名称为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="853"/>
        <source>图元[%1]的图元态[%2]信息重复</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="869"/>
        <source>图元[%1]的图元态[%2]信息无法找到对应的图元态名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="877"/>
        <source>图元[%1]存在图元信息名称为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="890"/>
        <source>图元[%1]图元态[%2]无法获取图元信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="908"/>
        <source>图元第一态[%1]与图元名[%2]不一致</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="927"/>
        <source>图元节点信息获取错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="936"/>
        <source>图元原文件[%1]不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="944"/>
        <source>图元原文件[%1]中无法获取图元名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="952"/>
        <source>图元原文件[%1]中图元名称[%2]与节点名称[%3]不一致</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="987"/>
        <source>节点下不存在该图元[%1]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="999"/>
        <source>图元[%1]在该节点中存在重名图元</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="1011"/>
        <source>图元导入目录[%1]不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="1025"/>
        <source>图元在新节点中已存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/icon_data_check.cpp" line="1032"/>
        <source>当前节点下存在重名图元[%1]，无法加载图元导入包</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/picture_data_check.cpp" line="37"/>
        <source>画面节点指针错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/picture_data_check.cpp" line="47"/>
        <source>画面[%1]不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/picture_data_check.cpp" line="74"/>
        <source>当前画面背景图片[%1]无效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/picture_data_check.cpp" line="98"/>
        <source>画面节点信息获取不到</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/picture_data_check.cpp" line="107"/>
        <source>画面原文件[%1]不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/picture_data_check.cpp" line="144"/>
        <source>节点下不存在该画面[%1]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/picture_data_check.cpp" line="156"/>
        <source>当前节点下存在重名画面[%1]，无法加载画面导入包</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/picture_data_check.cpp" line="168"/>
        <source>画面导入目录[%1]不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/picture_data_check.cpp" line="181"/>
        <source>画面在新节点中已存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/picture_data_check.cpp" line="188"/>
        <source>画面[%1]在新节点中存在重名画面，无法导入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/res_data_check.cpp" line="27"/>
        <source>图片[%1]不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/res_data_check.cpp" line="40"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/res_data_check.cpp" line="49"/>
        <source>图片[%1]不在iasp运行目录下</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/res_data_check.cpp" line="57"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/res_data_check.cpp" line="72"/>
        <source>图片校验成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/res_data_check.cpp" line="67"/>
        <source>待导入目录[%1]图片重复</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/res_data_check.cpp" line="143"/>
        <source>图元文件[%1]读取失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/res_data_check.cpp" line="150"/>
        <source>图元文件[%1]非xml文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_data_check/res_data_check.cpp" line="160"/>
        <source>图元文件[%1]格式错误</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
