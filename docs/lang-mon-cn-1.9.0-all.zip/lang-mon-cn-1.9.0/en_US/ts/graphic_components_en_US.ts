<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CommonTableWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="111"/>
        <source>全部</source>
        <translation type="unfinished">All</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="112"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="807"/>
        <source>颜色决策</source>
        <translation type="unfinished">Color decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="113"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="808"/>
        <source>符号决策</source>
        <translation type="unfinished">Symbol decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="114"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="809"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Flashing decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="115"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="810"/>
        <source>字符决策</source>
        <translation type="unfinished">Character decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="116"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="811"/>
        <source>使能决策</source>
        <translation type="unfinished">Enable decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="120"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="882"/>
        <source>实时因子</source>
        <translation type="unfinished">Real-time factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="121"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="883"/>
        <source>历史因子</source>
        <translation type="unfinished">History factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="122"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="884"/>
        <source>扩展因子</source>
        <translation type="unfinished">Expansion factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="125"/>
        <source>选择路径</source>
        <translation type="unfinished">Select path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="129"/>
        <source>选择动态库路径</source>
        <translation type="unfinished">Select the Dynamic DB path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="133"/>
        <source>选择实时表域</source>
        <translation type="unfinished">Select the real-time table field</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="137"/>
        <source>选择历史表域</source>
        <translation type="unfinished">Select the history table field</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="485"/>
        <source>打开画面</source>
        <translation type="unfinished">Open graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="488"/>
        <source>新窗口打开</source>
        <translation type="unfinished">New window opens</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="640"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="661"/>
        <source>闪烁</source>
        <translation type="unfinished">Flashing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="644"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="662"/>
        <source>不闪烁</source>
        <translation type="unfinished">No Flashing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="699"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="720"/>
        <source>使能</source>
        <translation type="unfinished">Enable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="703"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="721"/>
        <source>不使能</source>
        <translation type="unfinished">No Enable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="771"/>
        <source>定位</source>
        <translation type="unfinished">Position</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="847"/>
        <source>查看子集</source>
        <translation type="unfinished">View subset</translation>
    </message>
</context>
<context>
    <name>DecisionConfigWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="28"/>
        <source>决策类型：</source>
        <translation type="unfinished">Decision type:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="45"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="75"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="142"/>
        <source>增加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="82"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="149"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="182"/>
        <source>退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="189"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="99"/>
        <source>详细信息：</source>
        <translation type="unfinished">Details:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1362"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1432"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1567"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1572"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1362"/>
        <source>决策名已修改，是否替换关联的决策定义</source>
        <translation type="unfinished">The decision name has been modified. Whether to replace the linked decision definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1421"/>
        <source>检查到需要修改的图元：</source>
        <translation type="unfinished">Detected icons that need to be modified:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1429"/>
        <source>检查到需要修改的画面：</source>
        <translation type="unfinished">Detected the graph that needs to be modified:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1431"/>
        <source>是否继续</source>
        <translation type="unfinished">Whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1502"/>
        <source>请重新加载相关画面进行验证</source>
        <translation type="unfinished">Please reload the relevant graph for verification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1572"/>
        <source>未找到需要修改的图元或画面</source>
        <translation type="unfinished">No icon or graph to be modified was found</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1492"/>
        <source>已修改的图元：</source>
        <translation type="unfinished">Modified icons:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="50"/>
        <source>编辑决策集合</source>
        <comment>toolName</comment>
        <translation type="unfinished">Edit Decision Set</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="104"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="105"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="118"/>
        <source>全部</source>
        <translation type="unfinished">All</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="106"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="107"/>
        <source>颜色决策</source>
        <translation type="unfinished">Color decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="108"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="109"/>
        <source>符号决策</source>
        <translation type="unfinished">Symbol decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="110"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="111"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Flashing decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="112"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="113"/>
        <source>字符决策</source>
        <translation type="unfinished">Character decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="114"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="115"/>
        <source>使能决策</source>
        <translation type="unfinished">Enable decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="137"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="178"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="143"/>
        <source>决策集合名称</source>
        <translation type="unfinished">Decision set name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="149"/>
        <source>备注</source>
        <translation type="unfinished">Remark</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="155"/>
        <source>类型</source>
        <translation type="unfinished">Type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="184"/>
        <source>应用名</source>
        <translation type="unfinished">App name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="190"/>
        <source>数据库名</source>
        <translation type="unfinished">DB name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="196"/>
        <source>表名</source>
        <translation type="unfinished">Table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="202"/>
        <source>别名</source>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="208"/>
        <source>操作</source>
        <translation type="unfinished">Operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="522"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1167"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1172"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1267"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1272"/>
        <source>异常输入</source>
        <translation type="unfinished">Invalid input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="522"/>
        <source>名称数据异常，请重新输入</source>
        <translation type="unfinished">Invalid name data; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="891"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1178"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1218"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1278"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1283"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1327"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="891"/>
        <source>查看日志了解详细错误</source>
        <translation type="unfinished">View logs for detailed errors</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="896"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="896"/>
        <source>所有修改已保存</source>
        <translation type="unfinished">All modifications saved</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1084"/>
        <source>跳转失败</source>
        <translation type="unfinished">Jump failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1084"/>
        <source>检测到未保存的更改</source>
        <translation type="unfinished">Unsaved changes detected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1167"/>
        <source>决策集合名称数据异常，请重新输入</source>
        <translation type="unfinished">Invalid decision set name; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1172"/>
        <source>决策集合名称[%1] 长度超过[%2]，请重新输入</source>
        <translation type="unfinished">Decision set name [%1] exceeds length limit [%2]; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1178"/>
        <source>决策集合名称不可为空</source>
        <translation type="unfinished">Decision set name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1218"/>
        <source>决策集合名称: %1 重复</source>
        <translation type="unfinished">Decision set name: %1 duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1267"/>
        <source>决策应用表名称数据异常，请重新输入</source>
        <translation type="unfinished">Invalid decision application table name; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1272"/>
        <source>决策集合名称[%1] 决策应用[%2][%3] 表名称长度超过[%4]，请重新输入</source>
        <translation type="unfinished">Decision set name [%1] in application [%2][%3] exceeds table name length limit [%4]; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1327"/>
        <source>决策应用名称: %1 重复</source>
        <translation type="unfinished">Decision App name: %1 duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1278"/>
        <source>决策应用名称不可为空</source>
        <translation type="unfinished">Decision application name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1283"/>
        <source>决策库名称不可为空</source>
        <translation type="unfinished">Decision base name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1363"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1433"/>
        <source>是</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1364"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1434"/>
        <source>否</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1500"/>
        <source>已修改的画面：</source>
        <translation type="unfinished">Modified graph:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1547"/>
        <source>图元错误信息：</source>
        <translation type="unfinished">Icon error message:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1555"/>
        <source>画面错误信息：</source>
        <translation type="unfinished">Graph error message:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1580"/>
        <source>操作成功</source>
        <translation type="unfinished">Operation successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1580"/>
        <source>未检测到需要保存的更改</source>
        <translation type="unfinished">No changes were detected that need to be saved</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1593"/>
        <source>退出决策编辑</source>
        <comment>toolName</comment>
        <translation type="unfinished">Exit Decision Edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1598"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1599"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1595"/>
        <source>检测到未保存的更改，是否退出</source>
        <translation type="unfinished">Unsaved changes detected; whether to exit</translation>
    </message>
</context>
<context>
    <name>DictMoveToFileMgrWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="24"/>
        <source>画面列表</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Graph list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="39"/>
        <source>全部选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="46"/>
        <source>全部取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="53"/>
        <source> 迁移画面</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Migrate graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="97"/>
        <source>报表列表</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Report List</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="112"/>
        <source>全部选择</source>
        <translation type="unfinished">Select All</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="119"/>
        <source>全部取消</source>
        <translation type="unfinished">Cancel all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="71"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="144"/>
        <source>  迁移信息：</source>
        <translation type="unfinished">Migration info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="126"/>
        <source> 迁移报表</source>
        <translation type="unfinished">Migration report</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="131"/>
        <source>开始迁移所选画面：</source>
        <translation type="unfinished">Start migrating the selected graphs:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="145"/>
        <source>开始迁移画面：%1</source>
        <translation type="unfinished">Start migrating graph: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="156"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="346"/>
        <source>开始删除旧文件路径，远程路径：%1</source>
        <translation type="unfinished">Start deleting old file path, remote path:%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="164"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="354"/>
        <source>开始删除目标文件，远程路径：%1</source>
        <translation type="unfinished">Start to delete the destination file, remote path: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="180"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="370"/>
        <source>开始备份当前版本：</source>
        <translation type="unfinished">Start backing up the current version:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="199"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="389"/>
        <source>开始迁移版本：%1</source>
        <translation type="unfinished">Start migrating version: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="218"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="408"/>
        <source>开始上传托管版本，相对路径：%1，文件名：%2，版本文件名：%3，文件描述：%4 备注信息：%5</source>
        <translation type="unfinished">Start upload the managed version, relative path: %1, file name: %2, version file name: %3, file description: %4 remark info: %5</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="238"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="428"/>
        <source>上传文件到文件服务失败,错误原因：%1 </source>
        <translation type="unfinished">Failed to upload file to file service, error reason:%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="245"/>
        <source>开始更新画面最新版本号：%1</source>
        <translation type="unfinished">Start updating the latest version of the graph: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="250"/>
        <source>更新画面版本号失败 </source>
        <translation type="unfinished">Failed to update the graph version number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="255"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="445"/>
        <source>开始删除旧版本文件：%1</source>
        <translation type="unfinished">Start deleting old version files:%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="259"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="449"/>
        <source>迁移版本：%1成功</source>
        <translation type="unfinished">Migrate version: %1 successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="278"/>
        <source>迁移画面：%1成功</source>
        <translation type="unfinished">Migrate graph: %1 successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="283"/>
        <source>迁移画面：%1失败</source>
        <translation type="unfinished">Migrate graph: %1 failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="321"/>
        <source>开始迁移所选报表：</source>
        <translation type="unfinished">To start migrating the selected report:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="335"/>
        <source>开始迁移报表：%1</source>
        <translation type="unfinished">Start migrating report: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="435"/>
        <source>开始更新报表最新版本号：%1</source>
        <translation type="unfinished">Start updating the report with the latest version number: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="440"/>
        <source>更新报表版本号失败 </source>
        <translation type="unfinished">Failed to update report version number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="468"/>
        <source>迁移报表：%1成功</source>
        <translation type="unfinished">Migrate report: %1 successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="473"/>
        <source>迁移报表：%1失败</source>
        <translation type="unfinished">Migration report: %1 failed</translation>
    </message>
</context>
<context>
    <name>DlgApDbInstSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_db_inst_set.ui" line="14"/>
        <source>应用库实例号展示</source>
        <translation type="unfinished">Application db instance number display</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_db_inst_set.ui" line="21"/>
        <source>源合集</source>
        <translation type="unfinished">Source set</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_db_inst_set.ui" line="26"/>
        <source>源应用</source>
        <translation type="unfinished">Source app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_db_inst_set.ui" line="31"/>
        <source>新库名</source>
        <translation type="unfinished">New db name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_db_inst_set.ui" line="36"/>
        <source>源实例</source>
        <translation type="unfinished">Source instance</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_db_inst_set.ui" line="57"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_db_inst_set.ui" line="64"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>DlgAppAndDbDefine</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="14"/>
        <source>应用定义</source>
        <translation type="unfinished">App Definition</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="35"/>
        <source>添加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="42"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="52"/>
        <source>菜单描述</source>
        <translation type="unfinished">Menu description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="57"/>
        <source>应用名</source>
        <translation type="unfinished">App name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="62"/>
        <source>库名</source>
        <translation type="unfinished">DB name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="67"/>
        <source>所属模板应用</source>
        <translation type="unfinished">Assigned template applications</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="72"/>
        <source>所属模板库</source>
        <translation type="unfinished">Assigned Template DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="77"/>
        <source>层列表</source>
        <translation type="unfinished">Layer list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="100"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="107"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>DlgDecisionConfig</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_decision_config.cpp" line="29"/>
        <source>编辑决策集合</source>
        <comment>toolName</comment>
        <translation type="unfinished">Edit Decision Set</translation>
    </message>
</context>
<context>
    <name>DlgDefaultPic</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.ui" line="28"/>
        <source>画面选择：</source>
        <translation type="unfinished">Graph Selection:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.ui" line="67"/>
        <source>已选画面:</source>
        <translation type="unfinished">Selected graph:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.ui" line="99"/>
        <source>打开工具时默认打开该画面</source>
        <translation type="unfinished">This graph opens by default when you open the tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.ui" line="165"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.ui" line="172"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.cpp" line="135"/>
        <source>启动画面设置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Startup Graph Settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.cpp" line="141"/>
        <source>画面选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">Graph Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.cpp" line="161"/>
        <source>画面列表</source>
        <translation type="unfinished">Graph list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.cpp" line="161"/>
        <source>对象源名称</source>
        <translation type="unfinished">Object source name</translation>
    </message>
</context>
<context>
    <name>DlgDictMoveToFileMgr</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_dict_moveto_filemgr.cpp" line="28"/>
        <source>迁移画面/报表版本到文件管理</source>
        <comment>toolName</comment>
        <translation type="unfinished">Migrate Graph/Report To File Management</translation>
    </message>
</context>
<context>
    <name>DlgElementStateList</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_element_state_list.cpp" line="61"/>
        <source>图元态列表</source>
        <comment>toolName</comment>
        <translation type="unfinished">Icon State List</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_element_state_list.cpp" line="95"/>
        <source>异常输入</source>
        <translation type="unfinished">Invalid input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_element_state_list.cpp" line="95"/>
        <source>名称数据异常，请重新输入</source>
        <translation type="unfinished">Invalid name data; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_element_state_list.cpp" line="129"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_element_state_list.cpp" line="129"/>
        <source>未选择图元态</source>
        <translation type="unfinished">Unselected icon state</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_element_state_list.ui" line="54"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_element_state_list.ui" line="61"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>DlgExpressionEdit</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="28"/>
        <source>基本属性：</source>
        <translation type="unfinished">Basic attrs:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="38"/>
        <source>填充颜色说明：用于设备，填充色影响图元态绘制颜色；用于状态前景，使用图元时影响图元态绘制颜色，不使用图元时影响矩形区域填充色；用于数值/字符前景，影响矩形区域填充色</source>
        <translation type="unfinished">Fill Color Guide: Devices: Affects icon state rendering color. State foreground: Use icon→affects icon state color; no icon→affects rect area fill color. Value foreground/Character foreground: Affects rect area fill color.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="71"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="148"/>
        <source>增加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="78"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="155"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="188"/>
        <source>退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="195"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="95"/>
        <source>表达式详情：</source>
        <translation type="unfinished">Expression details:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="105"/>
        <source>可在【因子路径、实时表域、历史表域】列做右键选择</source>
        <translation type="unfinished">You can right-click in the [Factor Path, Real-time Table Field, History Table Field]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="43"/>
        <source>子集详情[%1_%2应用_%3数据库]</source>
        <translation type="unfinished">Subset Details [%1_%2 Application_%3 db]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="113"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="199"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="119"/>
        <source>决策名</source>
        <translation type="unfinished">Decision name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="125"/>
        <source>决策表达式</source>
        <translation type="unfinished">Decision expression</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="131"/>
        <source>字符颜色</source>
        <translation type="unfinished">Character color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="136"/>
        <source>决策值</source>
        <translation type="unfinished">Decision value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="145"/>
        <source>填充颜色</source>
        <translation type="unfinished">Fill color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="150"/>
        <source>决策值2</source>
        <translation type="unfinished">Decision value 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="159"/>
        <source>边框颜色</source>
        <translation type="unfinished">Border color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="164"/>
        <source>决策值3</source>
        <translation type="unfinished">Decision value 3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="205"/>
        <source>因子名称</source>
        <translation type="unfinished">Factor name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="211"/>
        <source>因子路径</source>
        <translation type="unfinished">Factor path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="217"/>
        <source>因子类别</source>
        <translation type="unfinished">Factor type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="229"/>
        <source>实时表域</source>
        <translation type="unfinished">Real-time table field</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="241"/>
        <source>历史表域</source>
        <translation type="unfinished">History table field</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="247"/>
        <source>扩展数据源类名</source>
        <translation type="unfinished">Extend the data source class name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="253"/>
        <source>扩展数据源动态库路径</source>
        <translation type="unfinished">Extend the data source dynamic db path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="259"/>
        <source>备用扩展数据源参数</source>
        <translation type="unfinished">Backup extended data source params</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="265"/>
        <source>备用扩展数据源参数2</source>
        <translation type="unfinished">Backup extended data source param 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="780"/>
        <source>解析表达式有误</source>
        <translation type="unfinished">Failed to parse expression</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="824"/>
        <source>存在未定义的因子</source>
        <translation type="unfinished">Undefined factors.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="855"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="862"/>
        <source>表达式名称：</source>
        <translation type="unfinished">Expression name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="855"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="862"/>
        <source>错误信息：</source>
        <translation type="unfinished">Error message:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="868"/>
        <source>检查到表达式内容有误：</source>
        <translation type="unfinished">Invalid expression content detected:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="868"/>
        <source>请检查并修改后再保存</source>
        <translation type="unfinished">Please check and modify before saving</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="869"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1248"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1617"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1657"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1779"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1819"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1847"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1855"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1248"/>
        <source>查看日志了解详细错误</source>
        <translation type="unfinished">View logs for detailed errors</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1253"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1364"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1382"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1387"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1392"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1397"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1418"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1426"/>
        <source>格式解析错误</source>
        <translation type="unfinished">Format parsing error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1364"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1392"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1418"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1426"/>
        <source>输入内容格式：表名.域名</source>
        <translation type="unfinished">Format of input content: table name.field name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1382"/>
        <source>域id获取失败</source>
        <translation type="unfinished">Failed to retrieve field ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1387"/>
        <source>表id获取失败</source>
        <translation type="unfinished">Failed to retrieve table ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1397"/>
        <source>数据库链接获取失败</source>
        <translation type="unfinished">Failed to retrieve db link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1580"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1585"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1592"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1597"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1605"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1610"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1691"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1696"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1702"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1707"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1713"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1718"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1724"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1729"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1735"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1740"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1746"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1751"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1757"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1762"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1768"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1773"/>
        <source>异常输入</source>
        <translation type="unfinished">Invalid input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1580"/>
        <source>决策表达式名称数据异常，请重新输入</source>
        <translation type="unfinished">Invalid decision expression name; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1585"/>
        <source>决策表达式名称[%1] 长度超过[%2]，请重新输入</source>
        <translation type="unfinished">Decision expression name [%1] exceeds length limit [%2]; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1592"/>
        <source>决策表达式数据异常，请重新输入</source>
        <translation type="unfinished">Invalid decision expression data; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1597"/>
        <source>决策表达式名称[%1] 表达式长度超过[%2]，请重新输入</source>
        <translation type="unfinished">Decision expression name [%1] expression length exceeds limit [%2]; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1605"/>
        <source>决策值数据异常，请重新输入</source>
        <translation type="unfinished">Invalid decision value data; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1610"/>
        <source>决策表达式名称[%1] 决策值长度超过[%2]，请重新输入</source>
        <translation type="unfinished">Decision expression name [%1] decision value length exceeds limit [%2]; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1617"/>
        <source>决策表达式名称不可为空</source>
        <translation type="unfinished">Decision expression name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1691"/>
        <source>决策因子名称数据异常，请重新输入</source>
        <translation type="unfinished">Invalid decision factor name; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1696"/>
        <source>决策表达式名称[%1] 因子名称[%2] 长度超过[%3]，请重新输入</source>
        <translation type="unfinished">Decision expression name [%1] factor name [%2] exceeds length limit [%3]; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1702"/>
        <source>决策因子路径数据异常，请重新输入</source>
        <translation type="unfinished">Invalid decision factor path; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1707"/>
        <source>决策表达式名称[%1] 因子名称[%2] 因子路径长度超过[%3]，请重新输入</source>
        <translation type="unfinished">Decision expression name [%1] factor name [%2] factor path exceeds the length limit [%3]; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1713"/>
        <source>决策因子历史表名数据异常，请重新输入</source>
        <translation type="unfinished">Invalid decision factor historical table name; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1718"/>
        <source>决策表达式名称[%1] 因子名称[%2] 历史表名长度超过[%3]，请重新输入</source>
        <translation type="unfinished">Decision expression name [%1] factor historical table name [%2] exceeds length limit [%3]; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1724"/>
        <source>决策因子历史域名数据异常，请重新输入</source>
        <translation type="unfinished">Invalid decision factor historical domain name; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1729"/>
        <source>决策表达式名称[%1] 因子名称[%2] 历史域名长度超过[%3]，请重新输入</source>
        <translation type="unfinished">Decision expression name [%1] factor historical domain name [%2] exceeds length limit [%3]; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1735"/>
        <source>决策因子扩展数据源动态库路径数据异常，请重新输入</source>
        <translation type="unfinished">Invalid decision factor extended data source Dynamic DB path; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1740"/>
        <source>决策表达式名称[%1] 因子名称[%2] 扩展数据源动态库路径长度超过[%3]，请重新输入</source>
        <translation type="unfinished">Decision expression name [%1] factor extended data source dynamic DB path [%2] exceeds length limit [%3]; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1746"/>
        <source>决策因子扩展数据源类名称数据异常，请重新输入</source>
        <translation type="unfinished">Invalid decision factor extended data source class name; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1751"/>
        <source>决策表达式名称[%1] 因子名称[%2] 扩展数据源类名称长度超过[%3]，请重新输入</source>
        <translation type="unfinished">Decision expression name [%1] factor extended data source class name [%2] exceeds length limit [%3]; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1757"/>
        <source>决策因子备用扩展数据源参数数据异常，请重新输入</source>
        <translation type="unfinished">Invalid decision factor backup extended data source param; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1762"/>
        <source>决策表达式名称[%1] 因子名称[%2] 备用扩展数据源参数长度超过[%3]，请重新输入</source>
        <translation type="unfinished">Decision expression name [%1] factor backup extended data source param [%2] exceeds length limit [%3]; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1768"/>
        <source>决策因子备用扩展数据源参数2数据异常，请重新输入</source>
        <translation type="unfinished">Invalid decision factor backup extended data source param 2; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1773"/>
        <source>决策表达式名称[%1] 因子名称[%2] 备用扩展数据源参数2长度超过[%3]，请重新输入</source>
        <translation type="unfinished">Decision expression name [%1] factor backup extended data source param 2 [%2] exceeds length limit [%3]; please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1779"/>
        <source>决策因子名称不可为空</source>
        <translation type="unfinished">Decision factor name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1830"/>
        <source>保存父对象</source>
        <comment>toolName</comment>
        <translation type="unfinished">Save Parent Obj</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1835"/>
        <source>是</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1836"/>
        <source>否</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1897"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1898"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1832"/>
        <source>检测到未保存的更改，是否保存</source>
        <translation type="unfinished">Unsaved changes detected; whether to save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1657"/>
        <source>决策表达式名称: %1 重复</source>
        <translation type="unfinished">Decision expression name: %1 duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1819"/>
        <source>决策因子名称: %1 重复</source>
        <translation type="unfinished">Decision factor name: %1 duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1847"/>
        <source>添加父决策集合失败</source>
        <translation type="unfinished">Failed to add parent decision set</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1855"/>
        <source>添加父决策应用失败</source>
        <translation type="unfinished">Failed to add parent decision application</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1879"/>
        <source>操作成功</source>
        <translation type="unfinished">Operation successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1879"/>
        <source>未检测到需要保存的更改</source>
        <translation type="unfinished">No changes were detected that need to be saved</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1892"/>
        <source>退出子集编辑</source>
        <translation type="unfinished">Exit subset editing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1894"/>
        <source>检测到未保存的更改，是否退出</source>
        <translation type="unfinished">Unsaved changes detected; whether to exit</translation>
    </message>
</context>
<context>
    <name>DlgPlaneDefine</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_plane_define.ui" line="14"/>
        <source>层定义</source>
        <translation type="unfinished">Define layer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_plane_define.ui" line="35"/>
        <source>添加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_plane_define.ui" line="42"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_plane_define.ui" line="66"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_plane_define.ui" line="73"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_plane_define.ui" line="83"/>
        <source>层名</source>
        <translation type="unfinished">Layer name</translation>
    </message>
</context>
<context>
    <name>DlgQuickSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.ui" line="14"/>
        <source>快速配置</source>
        <translation type="unfinished">Quick Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.ui" line="38"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.ui" line="45"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.cpp" line="50"/>
        <source>路径</source>
        <translation type="unfinished">Path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.cpp" line="54"/>
        <source>描述</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.cpp" line="55"/>
        <source>前缀</source>
        <translation type="unfinished">Prefix</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.cpp" line="56"/>
        <source>通配符</source>
        <translation type="unfinished">Wildcard</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.cpp" line="57"/>
        <source>后缀</source>
        <translation type="unfinished">Suffix</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.cpp" line="59"/>
        <source>唯一标识</source>
        <translation type="unfinished">OnlyNo</translation>
    </message>
</context>
<context>
    <name>DlgTemplateProperty</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="14"/>
        <source>动态属性编辑</source>
        <translation type="unfinished">Dynamic attrs edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="22"/>
        <source>多条件语句的统一配置,建议优先使用该配置</source>
        <translation type="unfinished">Unified config of multi conditional statements, it is recommended to prioritize using this config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="25"/>
        <source>快速配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Quick config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="32"/>
        <source>复制列值</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Copy col value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="39"/>
        <source>定义动态模板中需要替换的通配字符建议格式：数字%</source>
        <translation type="unfinished">Suggested format for defining generic characters that need to be replaced in dynamic template: number%</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="42"/>
        <source>通配符定义</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Define wildcard</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="62"/>
        <source>静态文本替换定义</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Replacement define</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="113"/>
        <source>将当前界面的配置内容清空</source>
        <translation type="unfinished">Clear the config content of the current interface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="116"/>
        <source>清空配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Clear config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="123"/>
        <source>重新获取文件里的数据链接并且将旧的配置内容全部清除(清空并重新获取链接功能)</source>
        <translation type="unfinished">Retrieve data links from the file and clear all old config content (function of clear and retrieve links)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="126"/>
        <source>重置数据</source>
        <translation type="unfinished">Reset data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="76"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="83"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="90"/>
        <source>将当前界面内容还原至画面中存储的原始状态</source>
        <translation type="unfinished">Restore the current interface content to the original state stored in the graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="93"/>
        <source>重载配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Reload config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.cpp" line="68"/>
        <source>路径</source>
        <translation type="unfinished">Path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.cpp" line="72"/>
        <source>描述</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.cpp" line="73"/>
        <source>前缀</source>
        <translation type="unfinished">Prefix</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.cpp" line="74"/>
        <source>通配符</source>
        <translation type="unfinished">Wildcard</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.cpp" line="75"/>
        <source>后缀</source>
        <translation type="unfinished">Suffix</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.cpp" line="77"/>
        <source>唯一标识</source>
        <translation type="unfinished">OnlyNo</translation>
    </message>
</context>
<context>
    <name>DlgWildcardDefine</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.ui" line="14"/>
        <source>通配符定义</source>
        <translation type="unfinished">Define wildcard</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.ui" line="27"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.ui" line="51"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.ui" line="58"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.ui" line="65"/>
        <source>修改</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.ui" line="94"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.ui" line="101"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.cpp" line="47"/>
        <source>标识</source>
        <translation type="unfinished">ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.cpp" line="51"/>
        <source>通配符名称</source>
        <translation type="unfinished">Wildcard name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.cpp" line="55"/>
        <source>源字符串值</source>
        <translation type="unfinished">Source string value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.cpp" line="58"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.cpp" line="141"/>
        <source>描述</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.cpp" line="62"/>
        <source>默认值</source>
        <translation type="unfinished">Default value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.cpp" line="66"/>
        <source>目标字符值</source>
        <translation type="unfinished">Dest character value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.cpp" line="137"/>
        <source>通配符</source>
        <translation type="unfinished">Wildcard</translation>
    </message>
</context>
</TS>
