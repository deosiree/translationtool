<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>GeneralAdvWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="65"/>
        <source>光敏点</source>
        <comment>tabBarTitle </comment>
        <translation type="unfinished">Punto Fotosensible</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="83"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2041"/>
        <source>基础设置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Configuración básica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="111"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="851"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1393"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2100"/>
        <source>边框：</source>
        <translation type="unfinished">Borde:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="123"/>
        <source>线型：</source>
        <translation type="unfinished">Tipo de línea:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="140"/>
        <source>线宽：</source>
        <translation type="unfinished">Ancho de línea:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="157"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="370"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3504"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3583"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4682"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4747"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4807"/>
        <source>颜色：</source>
        <translation type="unfinished">Color:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="190"/>
        <source>填充：</source>
        <translation type="unfinished">Relleno:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="200"/>
        <source>纯色</source>
        <translation type="unfinished">Color sólido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="213"/>
        <source>渐变</source>
        <translation type="unfinished">Gradación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="226"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4189"/>
        <source>图片</source>
        <translation type="unfinished">Imagen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="270"/>
        <source>透明度：</source>
        <translation type="unfinished">Transparencia:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="293"/>
        <source>%</source>
        <translation type="unfinished">%</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="342"/>
        <source>方向：</source>
        <translation type="unfinished">Dirección:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="377"/>
        <source>渐变：</source>
        <translation type="unfinished">Gradiente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="411"/>
        <source>路径：</source>
        <translation type="unfinished">Ruta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="421"/>
        <source>选择文件</source>
        <translation type="unfinished">Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="428"/>
        <source>保持比例</source>
        <translation type="unfinished">Mantener proporción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="444"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="912"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1454"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2161"/>
        <source>宽度：</source>
        <translation type="unfinished">Ancho:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="461"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="926"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1468"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2175"/>
        <source>高度：</source>
        <translation type="unfinished">Altura:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="495"/>
        <source>角型：</source>
        <translation type="unfinished">Tipo de ángulo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="502"/>
        <source>直角</source>
        <translation type="unfinished">Ángulo recto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="512"/>
        <source>弧角</source>
        <translation type="unfinished">Ángulo curvo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="519"/>
        <source>圆角</source>
        <translation type="unfinished">Esquina redondeada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="543"/>
        <source>凹凸效果：</source>
        <translation type="unfinished">Efecto cóncavo y convexo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="577"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="968"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1510"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1980"/>
        <source>字体设置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Configuración de fuente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="805"/>
        <source>数值前景</source>
        <comment>tabBarTitle </comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="823"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1365"/>
        <source>前景设置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Configuración de primer plano</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1190"/>
        <source>显示设置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Configuración de pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1280"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2072"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2287"/>
        <source>批量设置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Configuración por lotes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1303"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2003"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2310"/>
        <source>布局方向：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="39"/>
        <source>取消应用</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1238"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2223"/>
        <source>新旧前景显示：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1245"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2230"/>
        <source>向右拓展（升级兼容）</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1347"/>
        <source>状态前景</source>
        <comment>tabBarTitle </comment>
        <translation type="unfinished">Estado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1738"/>
        <source>字符/状态前景</source>
        <comment>tabBarTitle </comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1759"/>
        <source>字符前景</source>
        <translation type="unfinished">Carácter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2055"/>
        <source>显示设置</source>
        <translation type="unfinished">Configuración de pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2271"/>
        <source>状态前景</source>
        <translation type="unfinished">Estado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2357"/>
        <source>柱状图</source>
        <translation type="unfinished">Barras</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2381"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4872"/>
        <source>标题</source>
        <translation type="unfinished">Título</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2408"/>
        <source>标题颜色：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2418"/>
        <source>边框色</source>
        <translation type="unfinished">Color de borde</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2451"/>
        <source>垂直柱状</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2458"/>
        <source>水平柱状</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2465"/>
        <source>XY轴颜色：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2482"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4631"/>
        <source>小数位数：</source>
        <translation type="unfinished">Lugares decimales:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2496"/>
        <source>X坐标显示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2503"/>
        <source>X轴标签：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2513"/>
        <source>X轴标签颜色：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2530"/>
        <source>X轴字体大小：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2540"/>
        <source>X轴网格线</source>
        <translation type="unfinished">Líneas de cuadrícula eje X</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2547"/>
        <source>Y坐标显示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2554"/>
        <source>Y轴标签</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2564"/>
        <source>Y轴标签颜色：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2581"/>
        <source>Y轴字体大小：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2591"/>
        <source>Y轴网格线</source>
        <translation type="unfinished">Líneas de cuadrícula eje Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2598"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3410"/>
        <source>Y轴最大值：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2624"/>
        <source>数据标签：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2638"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4065"/>
        <source>外部</source>
        <translation type="unfinished">Externo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2645"/>
        <source>内部顶部</source>
        <translation type="unfinished">Superior interno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2652"/>
        <source>内部中间</source>
        <translation type="unfinished">Medio interno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2659"/>
        <source>内部底部</source>
        <translation type="unfinished">Fondo interno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2669"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="705"/>
        <source>点</source>
        <translation type="unfinished">Punto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2675"/>
        <source>图例字体大小：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2685"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3112"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4519"/>
        <source>图例颜色：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2695"/>
        <source>数据颜色：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2724"/>
        <source>曲线</source>
        <translation type="unfinished">Curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2750"/>
        <source>曲线组名称：</source>
        <translation type="unfinished">Nombre de grupo de curva:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2760"/>
        <source>曲线组类型：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2770"/>
        <source>展示形式：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2784"/>
        <source>左边距：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2798"/>
        <source>下边距：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2812"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2983"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3215"/>
        <source>背景颜色：</source>
        <translation type="unfinished">Color de fondo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2829"/>
        <source>阈值颜色：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2849"/>
        <source>阈值上限：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2866"/>
        <source>阈值下限：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2883"/>
        <source>刷新周期(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2904"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2965"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3204"/>
        <source>背景透明</source>
        <translation type="unfinished">Fondo transparente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2911"/>
        <source>平滑曲线</source>
        <translation type="unfinished">Curva suave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2918"/>
        <source>曲线详情</source>
        <translation type="unfinished">Detalles de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2925"/>
        <source>显示阈值</source>
        <translation type="unfinished">Mostrar umbral</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2932"/>
        <source>绝对值曲线</source>
        <translation type="unfinished">Curva de valor absoluto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2950"/>
        <source>标题栏</source>
        <translation type="unfinished">Barra de título</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2958"/>
        <source>显示标题栏</source>
        <translation type="unfinished">Mostrar barra de título</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2972"/>
        <source>显示按钮</source>
        <translation type="unfinished">Mostrar botón</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3019"/>
        <source>网格</source>
        <translation type="unfinished">Cuadrícula</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3027"/>
        <source>网格线颜色：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3041"/>
        <source>不显示</source>
        <translation type="unfinished">No mostrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3048"/>
        <source>多列</source>
        <translation type="unfinished">Múltiples columnas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3055"/>
        <source>少列</source>
        <translation type="unfinished">Menos columnas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3078"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4955"/>
        <source>图例</source>
        <translation type="unfinished">Leyenda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3086"/>
        <source>隐藏图例</source>
        <translation type="unfinished">Ocultar leyenda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3095"/>
        <source>图例字体：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3122"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4604"/>
        <source>图例间距：</source>
        <translation type="unfinished">Espaciado de leyenda:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3132"/>
        <source>图例方向：</source>
        <translation type="unfinished">Dirección de leyenda:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3142"/>
        <source>排列方式：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3152"/>
        <source>换行：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3180"/>
        <source>游标</source>
        <translation type="unfinished">Cursor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3190"/>
        <source>显示游标</source>
        <translation type="unfinished">Mostrar cursor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3197"/>
        <source>显示日期</source>
        <translation type="unfinished">Mostrar fecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3260"/>
        <source>坐标轴</source>
        <translation type="unfinished">Eje de coordenadas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3270"/>
        <source>坐标轴自适应</source>
        <translation type="unfinished">Ejes autoajustables</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3277"/>
        <source>显示历史</source>
        <translation type="unfinished">Mostrar la historia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3284"/>
        <source>多Y轴</source>
        <translation type="unfinished">Múltiples ejes Y</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3295"/>
        <source>X轴主刻度：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3312"/>
        <source>Y轴主刻度：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3329"/>
        <source>X轴字体：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3346"/>
        <source>Y轴字体：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3363"/>
        <source>坐标轴线宽：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3383"/>
        <source>坐标轴颜色：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3393"/>
        <source>Y轴最小值：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3424"/>
        <source>曲线轴区间：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3458"/>
        <source>表格</source>
        <translation type="unfinished">Hoja</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3480"/>
        <source>静态二维表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3488"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3567"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4255"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4740"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4800"/>
        <source>边框</source>
        <translation type="unfinished">Borde</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3517"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3596"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3745"/>
        <source>选择网格线颜色</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3559"/>
        <source>动态二维表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3638"/>
        <source>网格表格</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3648"/>
        <source>行数:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3668"/>
        <source>列数:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3692"/>
        <source>显示网格线</source>
        <translation type="unfinished">Mostrar líneas de cuadrícula</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3702"/>
        <source>显示边框</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3712"/>
        <source>实时预览</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3732"/>
        <source>网格:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3761"/>
        <source>线条宽度:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3805"/>
        <source>线条样式:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3828"/>
        <source>边框:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3841"/>
        <source>选择边框颜色</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3853"/>
        <source>尺寸设置：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3865"/>
        <source>统一尺寸</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3875"/>
        <source>自定义尺寸</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3899"/>
        <source>统一列宽:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3919"/>
        <source>统一行高:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3975"/>
        <source>更多</source>
        <translation type="unfinished">Más</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3998"/>
        <source>电池配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4006"/>
        <source>边框圆角角度</source>
        <translation type="unfinished">Ángulo de borde redondeado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4020"/>
        <source>头部圆角角度</source>
        <translation type="unfinished">Ángulo redondeado superior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4051"/>
        <source>百分比值:</source>
        <translation type="unfinished">Relación porcentual:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4058"/>
        <source>内部</source>
        <translation type="unfinished">Interno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4076"/>
        <source>字体大小</source>
        <translation type="unfinished">Tamaño de fuente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4093"/>
        <source>小数点位数</source>
        <translation type="unfinished">Decimales</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4124"/>
        <source>显示单位</source>
        <translation type="unfinished">Unidades de visualización</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4134"/>
        <source>数值颜色：</source>
        <translation type="unfinished">Color numérico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4200"/>
        <source>平铺</source>
        <translation type="unfinished">Mosaico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4207"/>
        <source>居中</source>
        <translation type="unfinished">Centrado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4217"/>
        <source>拉伸</source>
        <translation type="unfinished">Estirar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4262"/>
        <source>文件尺寸：</source>
        <translation type="unfinished">Tamaño de archivo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4269"/>
        <source>填充方式：</source>
        <translation type="unfinished">Modo de relleno:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4278"/>
        <source>宽度：  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4292"/>
        <source>高度：  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4344"/>
        <source>前景决策</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4350"/>
        <source>可编辑</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4377"/>
        <source>仪表盘配置</source>
        <translation type="unfinished">Config. de tablero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4385"/>
        <source>轨道颜色：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4411"/>
        <source>最大刻度：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4441"/>
        <source>最小刻度：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4448"/>
        <source>单位颜色：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4465"/>
        <source>单位</source>
        <translation type="unfinished">Unidad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4472"/>
        <source>刻度颜色：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4479"/>
        <source>仪表盘颜色：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4502"/>
        <source>图例：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4544"/>
        <source>图元/设备</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4550"/>
        <source>批量布局方向：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4579"/>
        <source>环形图</source>
        <translation type="unfinished">Gráfico de anillo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4587"/>
        <source>显示图例</source>
        <translation type="unfinished">Mostrar leyenda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4594"/>
        <source>图例位置：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4614"/>
        <source>显示值</source>
        <translation type="unfinished">Mostrar valores</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4621"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4972"/>
        <source>后缀：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4645"/>
        <source>环上显示值</source>
        <translation type="unfinished">Valores mostrados en anillo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4652"/>
        <source>内环半径：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4662"/>
        <source>环间距：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4699"/>
        <source>环的个数：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4709"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4831"/>
        <source>起始角度：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4723"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4848"/>
        <source>结束角度：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4792"/>
        <source>饼图</source>
        <translation type="unfinished">Gráfico circular</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4886"/>
        <source>饼图显示值</source>
        <translation type="unfinished">Valores mostrados en gráfico circular</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4911"/>
        <source>大小</source>
        <translation type="unfinished">Tamaño</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4934"/>
        <source>孔大小</source>
        <translation type="unfinished">Tamaño de agujero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4962"/>
        <source>位置：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="25"/>
        <source>重置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Restablecer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="32"/>
        <source>应用发布</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Publicación de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="612"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1003"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1545"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1793"/>
        <source>字体类型：</source>
        <translation type="unfinished">Familia de fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="629"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1020"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1562"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1810"/>
        <source>对齐方式：</source>
        <translation type="unfinished">Alineación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="652"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1043"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1585"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1833"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2391"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="3225"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4418"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4672"/>
        <source>字体大小：</source>
        <translation type="unfinished">Tamaño de fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="669"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1060"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1602"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1850"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2993"/>
        <source>字体颜色：</source>
        <translation type="unfinished">Color de la fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="699"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1090"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1632"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1880"/>
        <source>显示方式：</source>
        <translation type="unfinished">Modo de visualización:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="706"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1097"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1639"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1887"/>
        <source>竖排</source>
        <translation type="unfinished">Fila vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="734"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1125"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1667"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1915"/>
        <source>字体效果：</source>
        <translation type="unfinished">Efecto de fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="741"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1132"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1674"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1922"/>
        <source>粗体</source>
        <translation type="unfinished">Negrita (tipo de letra)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="748"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1139"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1681"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1929"/>
        <source>斜体</source>
        <translation type="unfinished">Cursiva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="755"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1146"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1688"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1936"/>
        <source>删除线</source>
        <translation type="unfinished">Línea tachada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="762"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1153"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1695"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1943"/>
        <source>下划线</source>
        <translation type="unfinished">Subrayado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="883"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1425"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2132"/>
        <source>填充:</source>
        <translation type="unfinished">Relleno:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="1215"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="4893"/>
        <source>小数点位数：</source>
        <translation type="unfinished">Lugares decimales:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="48"/>
        <source>图形设计高级配置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Configuración Avanzada del Diseñador Gráfica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.ui" line="2631"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="109"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="312"/>
        <source>无</source>
        <translation type="unfinished">Ninguno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="110"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="313"/>
        <source>实线</source>
        <translation type="unfinished">Línea sólida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="111"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="314"/>
        <source>虚线</source>
        <translation type="unfinished">Línea discontinua</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="112"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="315"/>
        <source>点线</source>
        <translation type="unfinished">Línea punteada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="113"/>
        <source>点划线</source>
        <translation type="unfinished">Línea de puntos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="114"/>
        <source>点点划线</source>
        <translation type="unfinished">Línea de puntos y rayas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="187"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="755"/>
        <source>水平</source>
        <translation type="unfinished">Horizontal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="188"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="755"/>
        <source>垂直</source>
        <translation type="unfinished">Vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="189"/>
        <source>左斜</source>
        <translation type="unfinished">Diagonal izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="190"/>
        <source>右斜</source>
        <translation type="unfinished">Diagonal derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="193"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="200"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="207"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="214"/>
        <source>中对齐</source>
        <translation type="unfinished">Alinear al centro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="194"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="201"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="208"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="215"/>
        <source>左对齐</source>
        <translation type="unfinished">Alinear a la izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="195"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="202"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="209"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="216"/>
        <source>右对齐</source>
        <translation type="unfinished">Alinear a la derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="196"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="203"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="210"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="217"/>
        <source>上对齐</source>
        <translation type="unfinished">Alinear arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="197"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="204"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="211"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="218"/>
        <source>下对齐</source>
        <translation type="unfinished">Alinear abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="233"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="242"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="250"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="318"/>
        <source>横向</source>
        <translation type="unfinished">Horizontal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="234"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="243"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="251"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="319"/>
        <source>纵向</source>
        <translation type="unfinished">Vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="322"/>
        <source>批量添加数值前景，画面中显示排序方向</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="323"/>
        <source>批量添加字符前景，画面中显示排序方向</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="324"/>
        <source>批量添加状态前景，画面中显示排序方向</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="325"/>
        <source>批量添加图元，画面中显示排序方向</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="326"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="328"/>
        <source>生效范围：画面文件(含不具备是否向右拓展选择性功能的图元)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="327"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="329"/>
        <source>功能:绘制区域不变，区域内容向右延伸显示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="330"/>
        <source>仅适用于画面上的前景图元，控制该类图元属性编辑框中决策是否可编辑</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="331"/>
        <source>控制批量添加图元时，在画布上布局方向(除数值、字符、状态前景图元)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="656"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="684"/>
        <source>右上</source>
        <translation type="unfinished">Superior derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="657"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="685"/>
        <source>右下</source>
        <translation type="unfinished">Inferior derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="658"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="686"/>
        <source>左下</source>
        <translation type="unfinished">Inferior izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="659"/>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="687"/>
        <source>左上</source>
        <translation type="unfinished">Superior izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="701"/>
        <source>日曲线</source>
        <translation type="unfinished">Curva diaria</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="701"/>
        <source>月曲线</source>
        <translation type="unfinished">Curva mensual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="701"/>
        <source>年曲线</source>
        <translation type="unfinished">Curva anual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="701"/>
        <source>区间曲线</source>
        <translation type="unfinished">Curva de intervalo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="701"/>
        <source>实时曲线</source>
        <translation type="unfinished">Curva en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="705"/>
        <source>线</source>
        <translation type="unfinished">Línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="705"/>
        <source>向下填充</source>
        <translation type="unfinished">Relleno hacia abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="750"/>
        <source>上左</source>
        <translation type="unfinished">Superior izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="750"/>
        <source>上中</source>
        <translation type="unfinished">Centro superior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="750"/>
        <source>上右</source>
        <translation type="unfinished">Superior derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="750"/>
        <source>中左</source>
        <translation type="unfinished">Centro izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="750"/>
        <source>正中</source>
        <translation type="unfinished">Centro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="750"/>
        <source>中右</source>
        <translation type="unfinished">Centro derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="750"/>
        <source>下左</source>
        <translation type="unfinished">Inferior izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="750"/>
        <source>下中</source>
        <translation type="unfinished">Centro inferior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="751"/>
        <source>下右</source>
        <translation type="unfinished">Inferior derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="965"/>
        <source>信息</source>
        <translation type="unfinished">Información</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="966"/>
        <source>成功保存至%1%2%3</source>
        <translation type="unfinished">Guardado con éxito a %1%2%3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="966"/>
        <source>图形设计(监视)工具需重启生效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="971"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="971"/>
        <source>是否重置</source>
        <translation type="unfinished">Desea restablecerlo</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_general_advanced_plug/graphic_general_advanced_widget.cpp" line="1476"/>
        <source>图形高级配置</source>
        <comment>toolName</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
