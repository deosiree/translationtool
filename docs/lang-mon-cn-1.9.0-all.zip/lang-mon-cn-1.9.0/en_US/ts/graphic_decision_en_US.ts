<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>GraphicDecision</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_decision/graphic_decision.cpp" line="268"/>
        <location filename="../../../../src/plat/gui/api/graphic_decision/graphic_decision.cpp" line="395"/>
        <source>默认字符</source>
        <translation type="unfinished">Default character</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_decision/graphic_decision.cpp" line="555"/>
        <location filename="../../../../src/plat/gui/api/graphic_decision/graphic_decision.cpp" line="654"/>
        <source>默认值</source>
        <translation type="unfinished">Default value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_decision/graphic_decision.cpp" line="3601"/>
        <location filename="../../../../src/plat/gui/api/graphic_decision/graphic_decision.cpp" line="3634"/>
        <source>[%1]颜色决策</source>
        <translation type="unfinished">[%1] Color decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_decision/graphic_decision.cpp" line="3606"/>
        <location filename="../../../../src/plat/gui/api/graphic_decision/graphic_decision.cpp" line="3638"/>
        <source>[%1]符号决策</source>
        <translation type="unfinished">[%1] symbol decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_decision/graphic_decision.cpp" line="3611"/>
        <location filename="../../../../src/plat/gui/api/graphic_decision/graphic_decision.cpp" line="3642"/>
        <source>[%1]闪烁决策</source>
        <translation type="unfinished">[%1] flashing decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_decision/graphic_decision.cpp" line="3616"/>
        <location filename="../../../../src/plat/gui/api/graphic_decision/graphic_decision.cpp" line="3646"/>
        <source>[%1]字符决策</source>
        <translation type="unfinished">[%1] character decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_decision/graphic_decision.cpp" line="3621"/>
        <location filename="../../../../src/plat/gui/api/graphic_decision/graphic_decision.cpp" line="3654"/>
        <source>[%1]使能决策</source>
        <translation type="unfinished">[%1] Enable decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_decision/graphic_decision.cpp" line="3650"/>
        <source>[%1]功能函数决策</source>
        <translation type="unfinished">[%1] function decision</translation>
    </message>
</context>
</TS>
