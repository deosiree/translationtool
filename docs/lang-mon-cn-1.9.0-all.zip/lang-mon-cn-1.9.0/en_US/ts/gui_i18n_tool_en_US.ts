<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>FileComparatorComponent::ChooseFileWidget</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/filecomparewidget.h" line="34"/>
        <source>选择文件</source>
        <translation type="unfinished">Select File</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/filecomparewidget.h" line="35"/>
        <source>请选择QM文件</source>
        <translation type="unfinished">Please select QM file</translation>
    </message>
</context>
<context>
    <name>FileComparatorComponent::FileComparsionPage</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/filecomparewidget.h" line="173"/>
        <source>开启词条定位功能</source>
        <translation type="unfinished">Enable the entry positioning function</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/filecomparewidget.h" line="176"/>
        <source>QM文件: </source>
        <translation type="unfinished">QM file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/filecomparewidget.h" line="177"/>
        <source>TS文件: </source>
        <translation type="unfinished">TS file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/filecomparewidget.h" line="178"/>
        <source>比对</source>
        <translation type="unfinished">compare</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/filecomparewidget.h" line="181"/>
        <source>仅展示TS文件不存在的词条</source>
        <translation type="unfinished">Only display entries that do not exist in TS files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/filecomparewidget.h" line="182"/>
        <source>仅展示QM件不存在的词条</source>
        <translation type="unfinished">Only display entries that do not exist in QM files</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="249"/>
        <source>文件列表</source>
        <translation type="unfinished">File List</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="257"/>
        <source>DIC文件</source>
        <translation type="unfinished">DIC file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="261"/>
        <source>TS文件</source>
        <translation type="unfinished">TS Files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="275"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="276"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1586"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2079"/>
        <source>新增词条</source>
        <translation type="unfinished">Add entry</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="282"/>
        <source>删除词条</source>
        <translation type="unfinished">Delete Entry </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="298"/>
        <source>注意</source>
        <translation type="unfinished">Notice</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="298"/>
        <source>TS文件禁止清空</source>
        <translation type="unfinished">TS file cannot be cleared</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="312"/>
        <source>发布新版本翻译</source>
        <translation type="unfinished">Release a new version of translation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="329"/>
        <source>过滤出未翻译的词条</source>
        <translation type="unfinished">Filter out untranslated entries</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="355"/>
        <source>输入搜索内容...</source>
        <translation type="unfinished">Enter search content ..</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="361"/>
        <source>所有列</source>
        <translation type="unfinished">All columns</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="362"/>
        <source>Source</source>
        <translation type="unfinished">Source</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="363"/>
        <source>Tag</source>
        <translation type="unfinished">Tag</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="365"/>
        <source>Translation</source>
        <translation type="unfinished">Translation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="640"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="645"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="661"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="672"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="678"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1103"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1112"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1212"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1275"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1279"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1295"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1322"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1713"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1716"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1733"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1743"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1816"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1821"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="641"/>
        <source>处理文件时发生错误: %1</source>
        <translation type="unfinished">Error occurred while processing file: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="645"/>
        <source>处理文件时发生未知错误</source>
        <translation type="unfinished">Unknown error occurred while processing file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="661"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1103"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1733"/>
        <source>无法打开文件：</source>
        <translation type="unfinished">Unable to open file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="672"/>
        <source>JSON解析错误：</source>
        <translation type="unfinished">JSON parsing error:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="678"/>
        <source>JSON文件格式错误：需要数组格式</source>
        <translation type="unfinished">JSON file format error: requires array format</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="198"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="227"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="509"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="512"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="818"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1126"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1129"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1147"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1150"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1158"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1173"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1179"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1185"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1192"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1196"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1240"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1286"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1443"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1456"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="818"/>
        <source>当前服务存在异常</source>
        <translation type="unfinished">Current service error.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1112"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1743"/>
        <source>无法解析XML文件</source>
        <translation type="unfinished">Unable to parse XML file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1167"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1212"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1295"/>
        <source>无法保存文件：</source>
        <translation type="unfinished">Unable to save file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1255"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1307"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1255"/>
        <source>文件已保存</source>
        <translation type="unfinished">The file has been saved</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1276"/>
        <source>保存文件时发生错误: %1</source>
        <translation type="unfinished">An error occurred while saving the file: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1279"/>
        <source>保存文件时发生未知错误</source>
        <translation type="unfinished">Unknown error occurred while saving file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1307"/>
        <source>配置文件已保存</source>
        <translation type="unfinished">The config file has been saved</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1322"/>
        <source>配置文件保存失败</source>
        <translation type="unfinished">Failed to save config file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1368"/>
        <source>文件不存在</source>
        <translation type="unfinished">File not found</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1368"/>
        <source>当前需要同步的文件路径不存在,无法同步该文件,路径为: %1</source>
        <translation type="unfinished">The file path that needs to be synchronized currently does not exist, so the file cannot be synchronized. The path is: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1377"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1417"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1473"/>
        <source>文件同步</source>
        <translation type="unfinished">Sync Files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1378"/>
        <source>目前要同步的文件的相对路径为: %1,是否要继续同步文件</source>
        <translation type="unfinished">The relative path of the file to be synchronized at present is: %1. Whether to continue synchronizing the file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1417"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1473"/>
        <source>已取消文件同步</source>
        <translation type="unfinished">File synchronization has been canceled</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1425"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1479"/>
        <source>文件同步服务执行异常</source>
        <translation type="unfinished">File synchronization service execution exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1268"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1352"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1425"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1479"/>
        <source>失败</source>
        <translation type="unfinished">Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="140"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="324"/>
        <source>文件比对</source>
        <translation type="unfinished">File comparison</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="198"/>
        <source>文件比对页面功能加载失败</source>
        <translation type="unfinished">File comparison page function failed to load</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="227"/>
        <source>初始化语言管理功能失败,错误码%1</source>
        <translation type="unfinished">Failed to initialize language management function, error code %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="241"/>
        <source>搜索文件: </source>
        <translation type="unfinished">Search files:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="143"/>
        <source>导入词条</source>
        <translation type="unfinished">Import entry</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2155"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2166"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2180"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2185"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2190"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2192"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2195"/>
        <source>信息</source>
        <translation type="unfinished">info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="325"/>
        <source>TS与对应的QM二进制文件比对</source>
        <translation type="unfinished">Comparison between TS and corresponding QM binary files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="509"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="512"/>
        <source>文件查询失败,服务异常</source>
        <translation type="unfinished">File query failed, service exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1126"/>
        <source>保存的TS文件的词条的source不能为空字符串, 保存操作终止</source>
        <translation type="unfinished">The source of the entry in the saved TS file cannot be an empty string, save operation terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1129"/>
        <source>当前服务异常,异常状态码为: %1,%2, 保存操作终止</source>
        <translation type="unfinished">The current service is abnormal, with exception status codes: %1,%2, save operation terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1147"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1150"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1192"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1196"/>
        <source>TS文件存在异常,异常状态码为: %1, 保存操作终止</source>
        <translation type="unfinished">TS file error: status code %1. Save terminated.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1158"/>
        <source>TS文件存在异常,两个&lt;context/&gt;标签检测到相同的&lt;name&gt;%1&lt;name/&gt;,本工具无法执行保存操作,请自行打开TS文件进行修改</source>
        <translation type="unfinished">TS file error: 2 &lt;context/&gt; tags have same &lt;name&gt;%1&lt;/name&gt;. Save disabled. Open TS to modify.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1167"/>
        <source>没有需要保存的更改, 保存操作终止</source>
        <translation type="unfinished">No changes need to be saved, save operation terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1173"/>
        <source>删除词条失败,异常状态码为: %1, 保存操作终止</source>
        <translation type="unfinished">Delete entry failed with exception code: %1, save operation terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1179"/>
        <source>新增加词条失败,异常状态码为: %1, 保存操作终止</source>
        <translation type="unfinished">Failed to add entry, exception status code: %1, save operation terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1185"/>
        <source>更新词条失败,异常状态码为: %1, 保存操作终止</source>
        <translation type="unfinished">Update entry failed with exception code: %1, save operation terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1240"/>
        <source>无法保存QM文件,在获取QM文件路径时出错,请查看日志</source>
        <translation type="unfinished">Unable to save QM file, error occurred while retrieving QM file path, please check the log</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1268"/>
        <source>文件保存失败,%1;%2</source>
        <translation type="unfinished">File save failed, %1; %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1286"/>
        <source>DIC文件不允许清空词条, 至少要保留一个词条</source>
        <translation type="unfinished">DIC files do not allow clearing entries, at least one entry must be retained</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1352"/>
        <source>文件同步异常, 请检查系统是否正常开启, 文件同步服务是否正常开启</source>
        <translation type="unfinished">File synchronization exception, please check if the system is turned on properly and if the file synchronization service is turned on properly</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1357"/>
        <source>完成</source>
        <translation type="unfinished">complete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1358"/>
        <source>文件同步已完成, 文件同步成功的节点的翻译需在系统停止条件下发布新版本的翻译文件后方可生效, 各节点的详细信息如下: %1</source>
        <translation type="unfinished">The file synchronization has been completed. The translation of nodes that have successfully synchronized the files needs to release a new version of the translation file under system shutdown conditions before it can take effect. The detailed information of each node is as follows: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1443"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1456"/>
        <source>内部服务异常,无法进行文件同步</source>
        <translation type="unfinished">Internal service exception, unable to synchronize files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1565"/>
        <source>重复词条</source>
        <translation type="unfinished">Duplicate entries</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1565"/>
        <source>存在重复的词条, 建议删除或修改重复的词条, 请检查标红的词条</source>
        <translation type="unfinished">Duplicate entries. Delete/modify. Check red-highlighted.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1657"/>
        <source>确认删除</source>
        <translation type="unfinished">Confirm to delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1658"/>
        <source>确定要删除这个词条吗？</source>
        <translation type="unfinished">Are you sure you want to delete this entry?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1713"/>
        <source>加载文件时发生错误: %1</source>
        <translation type="unfinished">Error occurred while loading file: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1716"/>
        <source>加载文件时发生未知错误</source>
        <translation type="unfinished">Unknown error occurred while loading file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1817"/>
        <source>解析文件时发生错误: %1</source>
        <translation type="unfinished">An error occurred while parsing the file: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1821"/>
        <source>解析文件时发生未知错误</source>
        <translation type="unfinished">Unknown error occurred while parsing file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1928"/>
        <source>当前选中: Source=&apos;%1&apos; | Context=&apos;%2&apos; | Location=&apos;%3&apos;</source>
        <translation type="unfinished">Currently selected: Source=&apos;%1&apos; | Context=&apos;%2&apos; | Location=&apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1952"/>
        <source>处理表格点击时发生错误: %1</source>
        <translation type="unfinished">Error occurred while processing table click: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1971"/>
        <source>表格操作</source>
        <translation type="unfinished">Table operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1973"/>
        <source>复制</source>
        <translation type="unfinished">Copy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1974"/>
        <source>粘贴</source>
        <translation type="unfinished">Paste</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="1975"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2042"/>
        <source>找到 %1 个匹配项</source>
        <translation type="unfinished">Found %1 matches</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2156"/>
        <source>注意, 保存成功, 仅代表dic/ts文件保存成功, 程序实际使用的.rd/.qm文件需在系统停止状态下点击%1按钮生效</source>
        <translation type="unfinished">Note that successful saving only means successful saving of the dic/ts file. The.rd/.qm file actually used by the program needs to be activated by clicking the %1 button when the system is stopped</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2167"/>
        <source>当前存在最新版本的(.rd/.qm)文件的路径为: %2, 如需使最新的翻译生效, 请停系统并点击%1按钮生效, 如果想忽略该文件(.rd/.qm), 可自行删除或通过该工具修改(.dic/.ts)文件, 程序会自动覆盖最新版本的(.rd/.qm)文件</source>
        <translation type="unfinished">The current path to the latest version of the (.rd/.qm) file is: %2. To make the latest translation effective, please stop the system and click the %1 button. If you want to ignore this file (.rd/.qm), you can delete it yourself or modify it using this tool. The program will automatically overwrite the latest version of the (.rd/.qm) file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2180"/>
        <source>请确认是否更新翻译文件(.rd/.qm)</source>
        <translation type="unfinished">Please confirm whether to update the translation files (.rd/.qm)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2185"/>
        <source>更新翻译文件(.rd/.qm)需保证系统在未启动状态下进行, 请手动停系统</source>
        <translation type="unfinished">Updating translation files (.rd/.qm) requires ensuring that the system is not started. Please manually shut down the system</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2190"/>
        <source>翻译文件(.rd/.qm)更新失败, 请稍后重试</source>
        <translation type="unfinished">Translation file (.rd/.qm) update failed, please try again later</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2192"/>
        <source>翻译文件(.rd/.qm)更新完成,请重启相应进程查看翻译结果</source>
        <translation type="unfinished">The translation file (.rd/.qm) has been updated. Please restart the corresponding process to view the translation results</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="2195"/>
        <source>更新翻译文件(.rd/.qm)流程已终止</source>
        <translation type="unfinished">The process of updating translation files (.rd/.qm) has been terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.cpp" line="364"/>
        <source>Comments</source>
        <translation>Comments</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.h" line="176"/>
        <source>文件编辑</source>
        <translation type="unfinished">file editing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/mainwindow.h" line="177"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
</context>
<context>
    <name>commonwidget::EntrySearchWidget</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="181"/>
        <source>翻译: </source>
        <translation type="unfinished">Translation:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="182"/>
        <source>重置条件</source>
        <translation type="unfinished">Reset Filter </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="199"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="211"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="199"/>
        <source>系统服务存在异常</source>
        <translation type="unfinished">System svc error.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="202"/>
        <source>搜索</source>
        <translation type="unfinished">search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="211"/>
        <source>切换搜索框搜索翻译语种类型时出现异常, 请联系研发</source>
        <translation type="unfinished">If there is an exception when switching the search box to search for translation language types, please contact R&amp;D</translation>
    </message>
</context>
<context>
    <name>commonwidget::FilesSelectedWidget</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="311"/>
        <source>选择文件</source>
        <translation type="unfinished">Select File</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="312"/>
        <source>添加文件</source>
        <translation type="unfinished">Add file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="313"/>
        <source>删除文件</source>
        <translation type="unfinished">Delete file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="315"/>
        <source>添加文件路径</source>
        <translation type="unfinished">Add file path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="316"/>
        <source>删除文件路径</source>
        <translation type="unfinished">Delete file path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="327"/>
        <source>信息</source>
        <translation type="unfinished">info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="327"/>
        <source>请选择要删除的文件路径</source>
        <translation type="unfinished">Please select the file path to delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.h" line="151"/>
        <source>已选文件: </source>
        <translation type="unfinished">Selected files:</translation>
    </message>
</context>
<context>
    <name>commonwidget::TranslationFilesDisplayWidget</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="417"/>
        <source>搜索文件: </source>
        <translation type="unfinished">Search files:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/commonwidget.cpp" line="418"/>
        <source>搜索</source>
        <translation type="unfinished">search</translation>
    </message>
</context>
<context>
    <name>exportwidget::ExportDisplayWidget</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="19"/>
        <source>文件路径: </source>
        <translation type="unfinished">File path:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="20"/>
        <source>选择文件</source>
        <translation type="unfinished">Select File</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="28"/>
        <source>选择全部</source>
        <translation type="unfinished">Select All</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="30"/>
        <source>取消全选</source>
        <translation type="unfinished">Deselect all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="34"/>
        <source>预览词条</source>
        <translation type="unfinished">Preview entries</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="35"/>
        <source>导出</source>
        <translation type="unfinished">export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="50"/>
        <source>可导出的.dic文件列表</source>
        <translation type="unfinished">List of exportable .dic files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="109"/>
        <source>点击右侧的按钮选择要导出词条的文件存放的位置</source>
        <translation type="unfinished">Click the button on the right to select the location where the file containing the exported entries should be stored</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="113"/>
        <source>是否导出</source>
        <translation type="unfinished">Exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="179"/>
        <source>选择导出文件的位置</source>
        <translation type="unfinished">Select the location for exporting files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="230"/>
        <source>导入出错</source>
        <translation type="unfinished">Import error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="230"/>
        <source>dic文件解析出错: %1</source>
        <translation type="unfinished">DIC file parsing error: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="239"/>
        <source>加载成功</source>
        <translation type="unfinished">Loaded successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="239"/>
        <source>加载数据成功, 请查看表格数据</source>
        <translation type="unfinished">Data loading successful, please check the table data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="257"/>
        <source>文件已存在</source>
        <translation type="unfinished">File already exists.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="257"/>
        <source>当前文件已存在, 确定是否覆盖原文件</source>
        <translation type="unfinished">The current file already exists. Please confirm whether to overwrite the original file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="259"/>
        <source>已取消导出</source>
        <translation type="unfinished">Export canceled</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="259"/>
        <source>已经取消导出操作</source>
        <translation type="unfinished">The export operation has been canceled</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="268"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="268"/>
        <source>文件导出时出现异常,异常信息为: %1</source>
        <translation type="unfinished">An exception occurred while exporting the file, with the exception message being: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="270"/>
        <source>导出成功</source>
        <translation type="unfinished">Export successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/exportwidget.cpp" line="270"/>
        <source>导出文件成功</source>
        <translation type="unfinished">Export file successfully</translation>
    </message>
</context>
<context>
    <name>importwidget::EntryOverrideDialog</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="838"/>
        <source>新添加的词条和已有的词条完全相同, 需要确定导入后每个词条采用的翻译</source>
        <translation type="unfinished">The newly entry is exactly the same as the existing entry, and it is necessary to determine the translation used for each entry after import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="839"/>
        <source>被勾选的翻译代表要保存的,点击%1或关闭该对话框可以终止词条导入</source>
        <translation type="unfinished">The selected represents the one to be saved. Click %1 or close this dialog box to terminate the term import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="868"/>
        <source>词条翻译选择</source>
        <translation type="unfinished">Entry translation selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="890"/>
        <source>信息</source>
        <translation type="unfinished">info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="890"/>
        <source>获取冲突解决后的词条失败</source>
        <translation type="unfinished">Failed to obtain entries after conflict resolution</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="954"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="961"/>
        <source>原先的翻译结果</source>
        <translation type="unfinished">The original translation result</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="961"/>
        <source>新导入的翻译</source>
        <translation type="unfinished">Newly imported translation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.h" line="256"/>
        <source>取消导入</source>
        <translation type="unfinished">Cancel import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.h" line="258"/>
        <source>全部使用新的翻译</source>
        <translation type="unfinished">Use all new translations</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.h" line="260"/>
        <source>全部使用新的翻译(翻译不为空)</source>
        <translation type="unfinished">All use new translation (translation is not empty)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.h" line="262"/>
        <source>保留已有的翻译</source>
        <translation type="unfinished">Keep existing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.h" line="264"/>
        <source>保留已有的翻译(翻译为空的除外)</source>
        <translation type="unfinished">Keep existing (except empty)</translation>
    </message>
</context>
<context>
    <name>importwidget::ImportDisplayWidget</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="71"/>
        <source>选择全部</source>
        <translation type="unfinished">Select All</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="72"/>
        <source>取消全选</source>
        <translation type="unfinished">Deselect all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="73"/>
        <source>预览词条</source>
        <translation type="unfinished">Preview entries</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="74"/>
        <source>导入到文件</source>
        <translation type="unfinished">Import to file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="76"/>
        <source>可选导入语言: </source>
        <translation type="unfinished">Optional import language:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="77"/>
        <source>要导入词条的文件为: </source>
        <translation type="unfinished">The file to import the entry is:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="78"/>
        <source>请选择要导入词条的文件</source>
        <translation type="unfinished">Please select the file to import the entries into</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="85"/>
        <source>已选要导入的文件: </source>
        <translation type="unfinished">Selected files to import:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="87"/>
        <source>已选择的词条: </source>
        <translation type="unfinished">Selected entries:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="88"/>
        <source>重复词条: </source>
        <translation type="unfinished">Duplicate entries:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="89"/>
        <source>开启自动搜索: </source>
        <translation type="unfinished">Enable auto search:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="90"/>
        <source>进度: </source>
        <translation type="unfinished">Progress:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="94"/>
        <source>勾选</source>
        <translation type="unfinished">Checked</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="95"/>
        <source>取消勾选</source>
        <translation type="unfinished">Uncheck</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="196"/>
        <source>是否导入</source>
        <translation type="unfinished">Imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="226"/>
        <source>词条导入</source>
        <translation type="unfinished">Import entry</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="248"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="454"/>
        <source>选择文件</source>
        <translation type="unfinished">Select File</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="260"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="290"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="355"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="443"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="530"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="533"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="565"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="571"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="584"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="592"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="607"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="610"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="617"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="625"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="628"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="636"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="641"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="647"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="650"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="656"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="660"/>
        <source>信息</source>
        <translation type="unfinished">info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="260"/>
        <source>添加文件失败, 以下添加的文件路径重复: %1</source>
        <translation type="unfinished">Failed to add file, the following added file paths are duplicated: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="290"/>
        <source>请选择要导入的文件的路径</source>
        <translation type="unfinished">Please select the path of the file to be imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="355"/>
        <source>注意: 此时搜索的翻译语种为: %1, 与准备导入的词条的翻译的语种不符</source>
        <translation type="unfinished">Attention: The translation language searched at this time is %1, which does not match the translation language of the entry to be imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="443"/>
        <source>请确认要关闭当前页面吗</source>
        <translation type="unfinished">Whether to close the current page</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="510"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="597"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="510"/>
        <source>当前文件不存在: %1</source>
        <translation type="unfinished">This file does not exist: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="515"/>
        <source>解析文件出错</source>
        <translation type="unfinished">Error parsing file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="515"/>
        <source>解析文件: %1时出错, 错误原因: %2</source>
        <translation type="unfinished">Error parsing file: %1, reason for error: %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="530"/>
        <source>词条加载成功</source>
        <translation type="unfinished">Entry loaded successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="533"/>
        <source>词条加载成功, 其中存在重复的词条(source,tag,comments相同),上述词条已经提供背景色, 请查看</source>
        <translation type="unfinished">The entry has been successfully loaded, but there are duplicate entries (source, tag, comments are the same). The above entries have been provided with background colors, please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="565"/>
        <source>请选择要导入的词条</source>
        <translation type="unfinished">Please select the entries to import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="571"/>
        <source>请选择要导入到的文件</source>
        <translation type="unfinished">Please select the file to import into</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="584"/>
        <source>当前选择导入的词条中存在重复的词条(source,tag,comments相同), 请取消选择重复的词条后再导入</source>
        <translation type="unfinished">Selected entries: duplicate (source, tag, comment same). Uncheck duplicates before import.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="597"/>
        <source>系统服务异常,请查看日志</source>
        <translation type="unfinished">System service exception, please check the logs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="617"/>
        <source>解析dic文件时出现异常, %1 , 无法向该文件导入词条</source>
        <translation type="unfinished">Exception occurred while parsing DIC file, %1, unable to import entries into the file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="625"/>
        <source>系统服务异常</source>
        <translation type="unfinished">System service exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="628"/>
        <source>已终止导入</source>
        <translation type="unfinished">Import terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="636"/>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="660"/>
        <source>系统服务异常,导入失败, 请查看日志联系研发</source>
        <translation type="unfinished">System service exception, import failed, please check the logs and contact R&amp;D</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="641"/>
        <source>系统服务异常, 请联系研发,mainwindow is null</source>
        <translation type="unfinished">System service exception, please contact R&amp;D, mainwindow is null</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="647"/>
        <source>词条成功导入, 已保存到对应文件, 可在文件编辑页面重新打开文件查看</source>
        <translation type="unfinished">The entry has been successfully imported and saved. Reopen the file to view it on the file editing page</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="651"/>
        <source>注意, 保存成功, 仅代表dic/ts文件保存成功, 程序实际使用的.rd/.qm文件需在系统停止状态下在编辑页面点击%1按钮生效</source>
        <translation type="unfinished">Note that successful saving only means that the dic/ts file has been saved successfully. The.rd/.qm file actually used by the program needs to be activated by clicking the %1 button on the editing page while the system is stopped</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="656"/>
        <source>文件导入失败, 请稍后重试</source>
        <translation type="unfinished">File import failed, please try again later</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="592"/>
        <source>请选择要导入的词条对应的翻译语种</source>
        <translation type="unfinished">Please select the translation language corresponding to the entries to be imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="604"/>
        <source>异常</source>
        <translation type="unfinished">abnormal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="604"/>
        <source>系统服务发生异常, 请查看日志</source>
        <translation type="unfinished">System service encountered an exception, please check the logs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="607"/>
        <source>请确认, 当前准备将词条导入到%1中, 导入的词条翻译语种为: %2</source>
        <translation type="unfinished">Please confirm that the current plan is to import the entry into %1, and the translation language of the imported entry is: %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/importwidget.cpp" line="610"/>
        <source>已取消导入</source>
        <translation type="unfinished">Import canceled</translation>
    </message>
</context>
<context>
    <name>model::ChoosedFilesModel</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/model/model.cpp" line="890"/>
        <source>文件名</source>
        <translation type="unfinished">File name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/model/model.cpp" line="893"/>
        <source>文件绝对路径</source>
        <translation type="unfinished">Absolute file path</translation>
    </message>
</context>
<context>
    <name>model::ConflictEntryTableModel</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/model/model.cpp" line="1145"/>
        <source>未知</source>
        <translation type="unfinished">unknown</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/model/model.h" line="478"/>
        <source>翻译结果1</source>
        <translation type="unfinished">Translation result 1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/model/model.h" line="478"/>
        <source>翻译结果2</source>
        <translation type="unfinished">Translation result 2</translation>
    </message>
</context>
<context>
    <name>model::DefaultEntryEntityModel</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/model/model.cpp" line="502"/>
        <source>词条来源</source>
        <translation type="unfinished">Entry source </translation>
    </message>
</context>
<context>
    <name>model::TranslationFilesModel</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/model/model.cpp" line="212"/>
        <source>DIC文件</source>
        <translation type="unfinished">DIC file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/model/model.cpp" line="213"/>
        <source>TS文件</source>
        <translation type="unfinished">TS Files</translation>
    </message>
</context>
<context>
    <name>tabledelegate::ItemSelectedDelegate</name>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/delegate/tabledelegate.cpp" line="139"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/i18n/tools/translateTool/src/widget/delegate/tabledelegate.cpp" line="139"/>
        <source>修改单元格数据失败</source>
        <translation type="unfinished">Failed to modify cell data</translation>
    </message>
</context>
</TS>
