<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_enumtool/main.cpp" line="95"/>
        <source>参数解析失败</source>
        <translation type="unfinished">Params parsing failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_enumtool/main.cpp" line="95"/>
        <source>请检查输入的命令行参数</source>
        <translation type="unfinished">Please check the command line params you entered</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_enumtool/main.cpp" line="107"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_enumtool/main.cpp" line="108"/>
        <source>平台注册失败！</source>
        <translation type="unfinished">Platform reg failed!</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui_enumtool::MainWindow</name>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_enumtool/mainwindow.ui" line="14"/>
        <source>枚举工具</source>
        <translation type="unfinished">Enumeration Tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_enumtool/mainwindow.ui" line="77"/>
        <location filename="../../../../src/plat/base/tool/gui_enumtool/mainwindow.ui" line="80"/>
        <source>刷新</source>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_enumtool/mainwindow.ui" line="92"/>
        <location filename="../../../../src/plat/base/tool/gui_enumtool/mainwindow.ui" line="95"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_enumtool/mainwindow.ui" line="107"/>
        <location filename="../../../../src/plat/base/tool/gui_enumtool/mainwindow.ui" line="110"/>
        <source>编辑</source>
        <translation type="unfinished">Edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_enumtool/mainwindow.cpp" line="48"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_enumtool/mainwindow.cpp" line="48"/>
        <source>初始化失败</source>
        <translation type="unfinished">Init failed</translation>
    </message>
</context>
</TS>
