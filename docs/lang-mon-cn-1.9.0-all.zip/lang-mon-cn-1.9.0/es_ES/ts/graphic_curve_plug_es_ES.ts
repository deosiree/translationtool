<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CurveEditorPlugin</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_editor_plugin.cpp" line="38"/>
        <source>曲线插件集合</source>
        <translation type="unfinished">Colección de plugins de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_editor_plugin.cpp" line="46"/>
        <source>曲线插件</source>
        <translation type="unfinished">Plugin de curva</translation>
    </message>
</context>
<context>
    <name>CurveMainWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="105"/>
        <source>日期设置</source>
        <translation type="unfinished">Config. de fecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="345"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="361"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="375"/>
        <source>曲线文件%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="345"/>
        <source>曲线组名称不可为空</source>
        <translation type="unfinished">Nombre de grupo de curva no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="361"/>
        <source>暂未实现，敬请期待</source>
        <translation type="unfinished">No implementado, espere</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="375"/>
        <source>打开曲线</source>
        <translation type="unfinished">Abrir curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="418"/>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="455"/>
        <source>开启实时刷新</source>
        <translation type="unfinished">Habilitar actualización en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_curve_plug/curve_mainwidget.cpp" line="667"/>
        <source>至</source>
        <translation type="unfinished">Hasta</translation>
    </message>
</context>
</TS>
