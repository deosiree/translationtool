<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>DataBlockParaDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_datablock_para.ui" line="14"/>
        <source>数据块配置</source>
        <translation type="unfinished">Config data block</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_datablock_para.ui" line="20"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_datablock_para.ui" line="27"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_datablock_para.cpp" line="49"/>
        <source>数据块(%1)</source>
        <translation type="unfinished">Data block (%1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_datablock_para.cpp" line="62"/>
        <source>动态库名称：</source>
        <translation type="unfinished">Dynamic DB name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_datablock_para.cpp" line="71"/>
        <source>方法名称：</source>
        <translation type="unfinished">Method name:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/main.cpp" line="204"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/main.cpp" line="450"/>
        <source>%1 没有此工具的打开权限</source>
        <comment>gui_reportviewer::main</comment>
        <translation type="unfinished">%1 does not have open permission for this tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/main.cpp" line="205"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/main.cpp" line="243"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/main.cpp" line="451"/>
        <source>提示</source>
        <comment>gui_reportviewer::main</comment>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/main.cpp" line="244"/>
        <source>注册失败</source>
        <comment>gui_reportviewer::main</comment>
        <translation type="unfinished">Reg failed</translation>
    </message>
</context>
<context>
    <name>ReportViewer</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="68"/>
        <source>报表浏览工具(节点名：%1)</source>
        <comment>toolName</comment>
        <translation type="unfinished">Report Viewer (Node: %1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="92"/>
        <source>报表列表</source>
        <comment>toolName</comment>
        <translation type="unfinished">Report List</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="121"/>
        <source>异常输入</source>
        <translation type="unfinished">Abnormal input</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="121"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished">Abnormal query data, please re-enter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="228"/>
        <source>测点参数</source>
        <comment>toolName</comment>
        <translation type="unfinished">Measuring Point Params</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="376"/>
        <source>登录时限：</source>
        <translation type="unfinished">Login time limit:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="407"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="472"/>
        <source>%1 暂无此工具的权限</source>
        <translation type="unfinished">%1 no permission for this tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="408"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="473"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="497"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="702"/>
        <source>报表刷新</source>
        <translation type="unfinished">Report refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="499"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="706"/>
        <source>开启定时刷新</source>
        <translation type="unfinished">Turn on timer refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="501"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="710"/>
        <source>设置定时刷新周期</source>
        <translation type="unfinished">Set timer refresh cycle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="503"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="714"/>
        <source>关闭定时刷新</source>
        <translation type="unfinished">Turn off timer refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="505"/>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="698"/>
        <source>重置查询时间</source>
        <translation type="unfinished">Reset time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="507"/>
        <source>报表导出</source>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="509"/>
        <source>报表打印</source>
        <translation type="unfinished">Print</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="511"/>
        <source>打印预览</source>
        <translation type="unfinished">Print preview</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="513"/>
        <source>报表编辑</source>
        <translation type="unfinished">Edit report</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="954"/>
        <source>设置</source>
        <translation type="unfinished">Settings</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="954"/>
        <source>刷新周期（1-600秒）：</source>
        <translation type="unfinished">Refresh cycle (1-600s):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1139"/>
        <source>实时对象</source>
        <translation type="unfinished">Real-time object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1147"/>
        <source>历史对象</source>
        <translation type="unfinished">History object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1150"/>
        <source>历史对象选择时间</source>
        <translation type="unfinished">Select history object time </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1152"/>
        <source>月底</source>
        <translation type="unfinished">Month-End</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1153"/>
        <source>年</source>
        <translation type="unfinished">Year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1154"/>
        <source>月</source>
        <translation type="unfinished">Month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1155"/>
        <source>周</source>
        <translation type="unfinished">Week</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1156"/>
        <source>日</source>
        <translation type="unfinished">Day</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1157"/>
        <source>时</source>
        <translation type="unfinished">Hour</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1158"/>
        <source>分</source>
        <translation type="unfinished">Minute</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1159"/>
        <source>本</source>
        <translation type="unfinished">Current</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1160"/>
        <source>前</source>
        <translation type="unfinished">Previous</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1161"/>
        <source>后</source>
        <translation type="unfinished">Next</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1162"/>
        <source>求和</source>
        <translation type="unfinished">Sum</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1163"/>
        <source>首部减去尾部</source>
        <translation type="unfinished">Head minus Tail</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1164"/>
        <source>尾部减去首部</source>
        <translation type="unfinished">Tail minus Head</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1167"/>
        <source>历史对象实际时间</source>
        <translation type="unfinished">History object actual time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1175"/>
        <source>公式</source>
        <translation type="unfinished">Formula</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1236"/>
        <source>通知</source>
        <translation type="unfinished">Notification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/report_viewer.cpp" line="1236"/>
        <source>该报表中不包含数据块内容</source>
        <translation type="unfinished">The report does not include data block content</translation>
    </message>
</context>
<context>
    <name>WildCardConfigaDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="14"/>
        <source>动态模板属性配置</source>
        <translation type="unfinished">Dynamic template attrs config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="24"/>
        <source>通配符替换配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Wildcard Replacement Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="31"/>
        <source>通配符</source>
        <translation type="unfinished">Wildcard</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="36"/>
        <source>描述</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="41"/>
        <source>替换值</source>
        <translation type="unfinished">Replace value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="50"/>
        <source>应用库实例替换配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">App DB Instance Replacement Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="57"/>
        <source>源集合</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Source set</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="62"/>
        <source>源应用</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Source app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="67"/>
        <source>源库名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Source db name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="72"/>
        <source>源实例</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Source instance</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="77"/>
        <source>目标应用</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Dest app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="82"/>
        <source>目标库名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Dest db name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="87"/>
        <source>目标实例</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Dest instance</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="112"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_reportviewer/dialogs/dlg_wildcard_config.ui" line="119"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
</TS>
