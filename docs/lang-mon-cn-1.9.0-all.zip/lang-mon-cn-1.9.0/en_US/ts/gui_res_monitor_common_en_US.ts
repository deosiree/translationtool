<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CWarnItemModel</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="482"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="484"/>
        <source>时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="486"/>
        <source>告警节点</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alarm node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="488"/>
        <source>告警项</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alarm item</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="490"/>
        <source>告警对象</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alarm object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="492"/>
        <source>告警等级</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alarm level</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="494"/>
        <source>告警内容</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alarm content</translation>
    </message>
</context>
<context>
    <name>CommonWidget</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_widget.cpp" line="38"/>
        <source>参数配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Params Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_widget.cpp" line="37"/>
        <source>资源监视</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Monitor</translation>
    </message>
</context>
<context>
    <name>choos_tool_time</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.ui" line="20"/>
        <source>工具进程选取时间范围：</source>
        <translation type="unfinished">Tool process time range:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.ui" line="30"/>
        <source>开始时间：</source>
        <translation type="unfinished">Start time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.ui" line="40"/>
        <source>结束时间：</source>
        <translation type="unfinished">End time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.ui" line="69"/>
        <source>设置全部节点</source>
        <translation type="unfinished">Set all nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.ui" line="76"/>
        <source>设置当前节点</source>
        <translation type="unfinished">Set the current node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.ui" line="83"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.cpp" line="23"/>
        <source>时间设置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Clock</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.cpp" line="39"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/choos_tool_time.cpp" line="39"/>
        <source>请检查检索起止时间设置</source>
        <translation type="unfinished">Please check the retrieval start and end time settings</translation>
    </message>
</context>
<context>
    <name>common_curve</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="11"/>
        <source>曲线图</source>
        <translation type="unfinished">Curve graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="12"/>
        <source>柱状图</source>
        <translation type="unfinished">Bar chart</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="19"/>
        <source>导出CSV</source>
        <comment>menuName</comment>
        <translation type="unfinished">Export csv</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="22"/>
        <source>数据详情</source>
        <comment>menuName</comment>
        <translation type="unfinished">Data detail</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="322"/>
        <source>查询时间间隔过短，不能小于60秒</source>
        <translation type="unfinished">Query time interval is too short, which cannot be less than 60 seconds</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="680"/>
        <source>采样数据</source>
        <comment>toolName</comment>
        <translation type="unfinished">Sampled Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="689"/>
        <source>无数据</source>
        <comment>toolName</comment>
        <translation type="unfinished">No Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="738"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="796"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="738"/>
        <source>采集值</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Collection value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="738"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="796"/>
        <source>单位</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Unit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="738"/>
        <source>采集值占比(%)</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Percentage of collected values (%)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="738"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="796"/>
        <source>采集时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Collection time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="796"/>
        <source>采样值</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Sample value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="315"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="322"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.cpp" line="315"/>
        <source>日期选择错误</source>
        <translation type="unfinished">Date selection error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.ui" line="85"/>
        <source>开始：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Start:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.ui" line="95"/>
        <source>结束：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">End:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_curve.ui" line="118"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Query</translation>
    </message>
</context>
<context>
    <name>common_proc_para</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.ui" line="32"/>
        <source>参数：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Params:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.ui" line="39"/>
        <source>采样</source>
        <translation type="unfinished">Sampling</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.ui" line="46"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.ui" line="59"/>
        <source>预警</source>
        <translation type="unfinished">Advance warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.ui" line="72"/>
        <source>配额</source>
        <translation type="unfinished">Quota</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.ui" line="98"/>
        <source>重置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Reset</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.ui" line="105"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.cpp" line="203"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.cpp" line="372"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.cpp" line="203"/>
        <source>参数保存失败</source>
        <translation type="unfinished">Param save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/common_proc_para.cpp" line="372"/>
        <source>参数修改成功</source>
        <translation type="unfinished">Param modification successful</translation>
    </message>
</context>
<context>
    <name>config_para</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="145"/>
        <source>转发流量</source>
        <translation type="unfinished">Forwarding traffic</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="66"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="243"/>
        <source>采样周期</source>
        <translation type="unfinished">Samp. cycle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1497"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1736"/>
        <source>  数据采样</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Data sample</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1545"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1777"/>
        <source>  告警阈值</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alarm threshold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="204"/>
        <source>转发流量：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Forwarding traffic:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="235"/>
        <source>转发数据包：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Forwarding packets:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="324"/>
        <source>采样周期：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Samp. cycle:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="355"/>
        <source>存历史周期(倍率)：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">History storage cycle (multiplier):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="386"/>
        <source>告警间隔：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alarm interval:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="417"/>
        <source>资源检查周期：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Resource inspection cycle:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="448"/>
        <source>预警计算周期：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">AdvWarn calculation cycle:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="541"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1031"/>
        <source>内存</source>
        <translation type="unfinished">Memory</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="548"/>
        <source>网络流量</source>
        <translation type="unfinished">Net traffic</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="562"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1526"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1758"/>
        <source>磁盘值</source>
        <translation type="unfinished">Disk value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="555"/>
        <source>节点句柄</source>
        <translation type="unfinished">Node handle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="687"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1126"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1349"/>
        <source>内存：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Memory:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="718"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1157"/>
        <source>网络：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Net:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="749"/>
        <source>磁盘：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Disk:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="780"/>
        <source>句柄：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Handle:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1848"/>
        <source>  预警</source>
        <comment>subTitle</comment>
        <translation type="unfinished">AdvWarn</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="848"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1417"/>
        <source>内存预警：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Memory advWarn:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="879"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1684"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1888"/>
        <source>容量预警：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Capacity advWarn:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="910"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1448"/>
        <source>句柄预警：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Handle advWarn:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1188"/>
        <source>数据包：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Data packet:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1219"/>
        <source>磁盘速率：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Disk speed:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1250"/>
        <source>进程句柄：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Process handle:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1585"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1817"/>
        <source>磁盘值：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Disk value:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1616"/>
        <source>连接数：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Number of connections:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1644"/>
        <source>  预警</source>
        <translation type="unfinished">Advance warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1940"/>
        <source>  默认监视文件</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Default monitoring file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="2037"/>
        <source>重置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Reset</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="2044"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1024"/>
        <source>网络</source>
        <translation type="unfinished">Net </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="101"/>
        <source>现场</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Site</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="123"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="975"/>
        <source>数据采样</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Data sampling</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="164"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="616"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1064"/>
        <source>告警阈值</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alarm threshold</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="284"/>
        <source>资源监视服务</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Resource monitor service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="503"/>
        <source>节点</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="519"/>
        <source>数据采样</source>
        <translation type="unfinished">Data sampling</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="591"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1007"/>
        <source>CPU采样方式：</source>
        <translation type="unfinished">CPU sampling method:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="808"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1377"/>
        <source>预警</source>
        <comment>subTitle</comment>
        <translation type="unfinished">AdvWarn</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="959"/>
        <source>进程</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Process</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1038"/>
        <source>磁盘速率</source>
        <translation type="unfinished">Disk speed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1045"/>
        <source>进程句柄</source>
        <translation type="unfinished">Process handle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1278"/>
        <source>配额</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Quota</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1519"/>
        <source>连接数</source>
        <translation type="unfinished">Connections count</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1959"/>
        <source>新增</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1966"/>
        <source>编辑</source>
        <translation type="unfinished">Edit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.ui" line="1973"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="89"/>
        <source>序号</source>
        <comment>subTitle</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="89"/>
        <source>目录名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">DIR name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="89"/>
        <source>描述</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="89"/>
        <source>相对路径</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Relative path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="348"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="352"/>
        <source>平均值</source>
        <translation type="unfinished">AVG</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="348"/>
        <source>瞬时值</source>
        <translation type="unfinished">Instantaneous Value</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="592"/>
        <source>参数保存失败</source>
        <translation type="unfinished">Param save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="596"/>
        <source>参数保存成功</source>
        <translation type="unfinished">Param saved successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="626"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="668"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="661"/>
        <source>参数加载失败</source>
        <translation type="unfinished">Param loading failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/config_para.cpp" line="665"/>
        <source>参数加载成功</source>
        <translation type="unfinished">Param loading successful</translation>
    </message>
</context>
<context>
    <name>tips_curve_wg</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="131"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="147"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="180"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="199"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="218"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="330"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="336"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="671"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="702"/>
        <source>发:</source>
        <translation type="unfinished">Send:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="133"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="149"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="182"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="201"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="220"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="331"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="337"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="672"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="703"/>
        <source>收:</source>
        <translation type="unfinished">Receive:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="163"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="348"/>
        <source>读:</source>
        <translation type="unfinished">Read:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="165"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="349"/>
        <source>写:</source>
        <translation type="unfinished">Write:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="317"/>
        <source>异常告警</source>
        <translation type="unfinished">Abnormal Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="322"/>
        <source>CPU/内存</source>
        <translation type="unfinished">CPU/Memory</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="328"/>
        <source>网络</source>
        <translation type="unfinished">Net </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="334"/>
        <source>包吞吐量</source>
        <translation type="unfinished">Packet throughput</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="340"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="370"/>
        <source>句柄</source>
        <translation type="unfinished">Handle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="346"/>
        <source>磁盘速率</source>
        <translation type="unfinished">Disk speed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="352"/>
        <source>连接数</source>
        <translation type="unfinished">Connections count</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="358"/>
        <source>已用容量</source>
        <translation type="unfinished">Used capacity</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="364"/>
        <source>内存</source>
        <translation type="unfinished">Memory</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="657"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="666"/>
        <source>跨现场流量：%1</source>
        <translation type="unfinished">Cross-site traffic: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="688"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/tips_curve_wg.cpp" line="697"/>
        <source>跨现场包率：%1</source>
        <translation type="unfinished">Cross-site package rate: %1</translation>
    </message>
</context>
<context>
    <name>warn_query_wg</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="60"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="65"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="125"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="157"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="328"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="355"/>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="363"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="60"/>
        <source>日期选择错误</source>
        <translation type="unfinished">Date selection error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="65"/>
        <source>告警类型为空</source>
        <translation type="unfinished">Alarm type is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="125"/>
        <source>查询失败，请检查历史数据服务是否正常</source>
        <translation type="unfinished">Query failed. Please check whether the historical data service is normal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="157"/>
        <source>查询完成</source>
        <translation type="unfinished">Query completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="221"/>
        <source>所有类型</source>
        <translation type="unfinished">All types</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="271"/>
        <source>本现场所有节点</source>
        <translation type="unfinished">All nodes on site</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="328"/>
        <source>复归失败，请检查数据服务</source>
        <translation type="unfinished">Reset failed, please check the data service</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="355"/>
        <source>告警重置失败</source>
        <translation type="unfinished">Alarm reset failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.cpp" line="363"/>
        <source>告警重置成功</source>
        <translation type="unfinished">Alarm reset successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.ui" line="23"/>
        <source>开始：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Start:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.ui" line="33"/>
        <source>结束：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">End:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.ui" line="56"/>
        <source>查询</source>
        <comment>toolName</comment>
        <translation type="unfinished">Query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.ui" line="63"/>
        <source>告警重置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Alarm Reset</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.ui" line="76"/>
        <source>告警项：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alarm item:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/res_plugins/res_common/warn_query_wg.ui" line="86"/>
        <source>告警节点：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alarm node:</translation>
    </message>
</context>
</TS>
