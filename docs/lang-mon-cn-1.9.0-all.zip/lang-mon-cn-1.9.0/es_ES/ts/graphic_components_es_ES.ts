<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CommonTableWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="111"/>
        <source>全部</source>
        <translation type="unfinished">Todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="112"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="807"/>
        <source>颜色决策</source>
        <translation type="unfinished">Decisión de color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="113"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="808"/>
        <source>符号决策</source>
        <translation type="unfinished">Decisión de símbolo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="114"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="809"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Decisión de parpadeo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="115"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="810"/>
        <source>字符决策</source>
        <translation type="unfinished">Decisión de carácter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="116"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="811"/>
        <source>使能决策</source>
        <translation type="unfinished">Decisión de habilitación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="120"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="882"/>
        <source>实时因子</source>
        <translation type="unfinished">Factor en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="121"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="883"/>
        <source>历史因子</source>
        <translation type="unfinished">Factor histórico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="122"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="884"/>
        <source>扩展因子</source>
        <translation type="unfinished">Factor de expansión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="125"/>
        <source>选择路径</source>
        <translation type="unfinished">Seleccione ruta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="129"/>
        <source>选择动态库路径</source>
        <translation type="unfinished">Seleccione la ruta de base de datos dinámica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="133"/>
        <source>选择实时表域</source>
        <translation type="unfinished">Seleccione el campo de tabla en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="137"/>
        <source>选择历史表域</source>
        <translation type="unfinished">Seleccione el campo de tabla histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="485"/>
        <source>打开画面</source>
        <translation type="unfinished">Abrir gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="488"/>
        <source>新窗口打开</source>
        <translation type="unfinished">Abrir nueva ventana</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="640"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="661"/>
        <source>闪烁</source>
        <translation type="unfinished">Parpadeo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="644"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="662"/>
        <source>不闪烁</source>
        <translation type="unfinished">No parpadea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="699"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="720"/>
        <source>使能</source>
        <translation type="unfinished">Habilitar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="703"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="721"/>
        <source>不使能</source>
        <translation type="unfinished">No habilitado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="771"/>
        <source>定位</source>
        <translation type="unfinished">Posición</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/common_table_widget.cpp" line="847"/>
        <source>查看子集</source>
        <translation type="unfinished">Ver subconjunto</translation>
    </message>
</context>
<context>
    <name>DecisionConfigWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="28"/>
        <source>决策类型：</source>
        <translation type="unfinished">Tipo de decisión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="45"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="75"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="142"/>
        <source>增加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="82"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="149"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="182"/>
        <source>退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="189"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.ui" line="99"/>
        <source>详细信息：</source>
        <translation type="unfinished">Detalles:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="50"/>
        <source>编辑决策集合</source>
        <comment>toolName</comment>
        <translation type="unfinished">Editar Conjunto de Decisiones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="104"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="105"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="118"/>
        <source>全部</source>
        <translation type="unfinished">Todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="106"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="107"/>
        <source>颜色决策</source>
        <translation type="unfinished">Decisión de color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="108"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="109"/>
        <source>符号决策</source>
        <translation type="unfinished">Decisión de símbolo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="110"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="111"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Decisión de parpadeo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="112"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="113"/>
        <source>字符决策</source>
        <translation type="unfinished">Decisión de carácter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="114"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="115"/>
        <source>使能决策</source>
        <translation type="unfinished">Decisión de habilitación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="137"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="178"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="143"/>
        <source>决策集合名称</source>
        <translation type="unfinished">Nombre del conjunto de decisiones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="149"/>
        <source>备注</source>
        <translation type="unfinished">Comentario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="155"/>
        <source>类型</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="184"/>
        <source>应用名</source>
        <translation type="unfinished">Nombre de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="190"/>
        <source>数据库名</source>
        <translation type="unfinished">Nombre de la base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="196"/>
        <source>表名</source>
        <translation type="unfinished">Nombre de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="202"/>
        <source>别名</source>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="208"/>
        <source>操作</source>
        <translation type="unfinished">Operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="522"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1167"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1172"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1267"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1272"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="522"/>
        <source>名称数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="891"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1178"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1218"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1278"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1283"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1327"/>
        <source>保存失败</source>
        <translation type="unfinished">Fallo al guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="891"/>
        <source>查看日志了解详细错误</source>
        <translation type="unfinished">Ver logs para errores detallados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="896"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="896"/>
        <source>所有修改已保存</source>
        <translation type="unfinished">Todas las modif. guardadas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1084"/>
        <source>跳转失败</source>
        <translation type="unfinished">Fallo al cambiar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1084"/>
        <source>检测到未保存的更改</source>
        <translation type="unfinished">Cambios sin guardar detectados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1167"/>
        <source>决策集合名称数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1172"/>
        <source>决策集合名称[%1] 长度超过[%2]，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1178"/>
        <source>决策集合名称不可为空</source>
        <translation type="unfinished">Nombre de conjunto de decisión no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1267"/>
        <source>决策应用表名称数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1272"/>
        <source>决策集合名称[%1] 决策应用[%2][%3] 表名称长度超过[%4]，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1278"/>
        <source>决策应用名称不可为空</source>
        <translation type="unfinished">Nombre de app de decisión no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1283"/>
        <source>决策库名称不可为空</source>
        <translation type="unfinished">Nombre de BD de decisión no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1362"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1432"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1567"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1572"/>
        <source>提示</source>
        <translation type="unfinished">Consejo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1362"/>
        <source>决策名已修改，是否替换关联的决策定义</source>
        <translation type="unfinished">Nombre de decisión modif., ¿reemplazar def.?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1363"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1433"/>
        <source>是</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Verdadero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1364"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1434"/>
        <source>否</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1593"/>
        <source>退出决策编辑</source>
        <comment>toolName</comment>
        <translation type="unfinished">Salir de la Edición de Decisiones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1598"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1599"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1421"/>
        <source>检查到需要修改的图元：</source>
        <translation type="unfinished">Figuras detectadas que necesitan modif.:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1218"/>
        <source>决策集合名称: %1 重复</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1327"/>
        <source>决策应用名称: %1 重复</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1429"/>
        <source>检查到需要修改的画面：</source>
        <translation type="unfinished">Pantallas detectadas que necesitan modif.:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1431"/>
        <source>是否继续</source>
        <translation type="unfinished">¿Continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1492"/>
        <source>已修改的图元：</source>
        <translation type="unfinished">Figuras modificadas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1500"/>
        <source>已修改的画面：</source>
        <translation type="unfinished">Pantallas modificadas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1502"/>
        <source>请重新加载相关画面进行验证</source>
        <translation type="unfinished">Recargue pantalla para verificar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1547"/>
        <source>图元错误信息：</source>
        <translation type="unfinished">Mensaje de error de figura:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1555"/>
        <source>画面错误信息：</source>
        <translation type="unfinished">Mensaje de error de pantalla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1572"/>
        <source>未找到需要修改的图元或画面</source>
        <translation type="unfinished">No se encontró figura o pantalla a modificar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1580"/>
        <source>操作成功</source>
        <translation type="unfinished">Operación exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1580"/>
        <source>未检测到需要保存的更改</source>
        <translation type="unfinished">No se detectaron cambios para guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/decision_config_widget.cpp" line="1595"/>
        <source>检测到未保存的更改，是否退出</source>
        <translation type="unfinished">Cambios sin guardar, ¿salir?</translation>
    </message>
</context>
<context>
    <name>DictMoveToFileMgrWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="24"/>
        <source>画面列表</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Lista de gráficas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="39"/>
        <source>全部选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="46"/>
        <source>全部取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="53"/>
        <source> 迁移画面</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Migrar gráfica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="97"/>
        <source>报表列表</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Lista de informes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="112"/>
        <source>全部选择</source>
        <translation type="unfinished">Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="119"/>
        <source>全部取消</source>
        <translation type="unfinished">Cancelar todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="71"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="144"/>
        <source>  迁移信息：</source>
        <translation type="unfinished">Info. de migración:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.ui" line="126"/>
        <source> 迁移报表</source>
        <translation type="unfinished">Reporte de migración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="131"/>
        <source>开始迁移所选画面：</source>
        <translation type="unfinished">Iniciar migración de los gráficos seleccionados:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="145"/>
        <source>开始迁移画面：%1</source>
        <translation type="unfinished">Comenzar a migrar gráfica: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="156"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="346"/>
        <source>开始删除旧文件路径，远程路径：%1</source>
        <translation type="unfinished">Iniciar elim. de archivo viejo, ruta:%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="164"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="354"/>
        <source>开始删除目标文件，远程路径：%1</source>
        <translation type="unfinished">Iniciar eliminación del archivo de destino, ruta remota: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="180"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="370"/>
        <source>开始备份当前版本：</source>
        <translation type="unfinished">Iniciar copia de seguridad de la versión actual:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="199"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="389"/>
        <source>开始迁移版本：%1</source>
        <translation type="unfinished">Iniciar migración de versión: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="218"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="408"/>
        <source>开始上传托管版本，相对路径：%1，文件名：%2，版本文件名：%3，文件描述：%4 备注信息：%5</source>
        <translation type="unfinished">Iniciar carga de la versión gestionada, ruta relativa: %1, nombre de archivo: %2, nombre de archivo de versión: %3, descripción del archivo: %4 Información de nota: %5</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="238"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="428"/>
        <source>上传文件到文件服务失败,错误原因：%1 </source>
        <translation type="unfinished">Fallo al subir archivo a servicio, error:%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="245"/>
        <source>开始更新画面最新版本号：%1</source>
        <translation type="unfinished">Iniciar actualización de la última versión del gráfico: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="250"/>
        <source>更新画面版本号失败 </source>
        <translation type="unfinished">Error al actualizar el número de versión de la gráfica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="255"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="445"/>
        <source>开始删除旧版本文件：%1</source>
        <translation type="unfinished">Iniciar elim. de archivos viejos:%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="259"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="449"/>
        <source>迁移版本：%1成功</source>
        <translation type="unfinished">Migrar versión: %1 exitoso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="278"/>
        <source>迁移画面：%1成功</source>
        <translation type="unfinished">Migrar gráfico: %1 exitoso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="283"/>
        <source>迁移画面：%1失败</source>
        <translation type="unfinished">Migrar gráfico: %1 fallo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="321"/>
        <source>开始迁移所选报表：</source>
        <translation type="unfinished">Iniciar migración del informe seleccionado:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="335"/>
        <source>开始迁移报表：%1</source>
        <translation type="unfinished">Iniciar migración del informe: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="435"/>
        <source>开始更新报表最新版本号：%1</source>
        <translation type="unfinished">Iniciar actualización del informe con el número de versión más reciente: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="440"/>
        <source>更新报表版本号失败 </source>
        <translation type="unfinished">Fallo al actualizar versión de reporte</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="468"/>
        <source>迁移报表：%1成功</source>
        <translation type="unfinished">Migrar informe: %1 exitoso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dict_moveto_filemgr_widget.cpp" line="473"/>
        <source>迁移报表：%1失败</source>
        <translation type="unfinished">Informe de migración: %1 fallo</translation>
    </message>
</context>
<context>
    <name>DlgApDbInstSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_db_inst_set.ui" line="14"/>
        <source>应用库实例号展示</source>
        <translation type="unfinished">Mostrar núm. de instancia de BD app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_db_inst_set.ui" line="21"/>
        <source>源合集</source>
        <translation type="unfinished">Conjunto fuente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_db_inst_set.ui" line="26"/>
        <source>源应用</source>
        <translation type="unfinished">App fuente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_db_inst_set.ui" line="31"/>
        <source>新库名</source>
        <translation type="unfinished">Nombre de nueva BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_db_inst_set.ui" line="36"/>
        <source>源实例</source>
        <translation type="unfinished">Instancia fuente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_db_inst_set.ui" line="57"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_db_inst_set.ui" line="64"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>DlgAppAndDbDefine</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="14"/>
        <source>应用定义</source>
        <translation type="unfinished">Definición de app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="35"/>
        <source>添加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="42"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="52"/>
        <source>菜单描述</source>
        <translation type="unfinished">Descripción de menú</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="57"/>
        <source>应用名</source>
        <translation type="unfinished">Nombre de app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="62"/>
        <source>库名</source>
        <translation type="unfinished">Nombre de BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="67"/>
        <source>所属模板应用</source>
        <translation type="unfinished">App de plantilla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="72"/>
        <source>所属模板库</source>
        <translation type="unfinished">BD de plantilla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="77"/>
        <source>层列表</source>
        <translation type="unfinished">Lista de capas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="100"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_app_and_db_define.ui" line="107"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>DlgDecisionConfig</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_decision_config.cpp" line="29"/>
        <source>编辑决策集合</source>
        <comment>toolName</comment>
        <translation type="unfinished">Editar Conjunto de Decisiones</translation>
    </message>
</context>
<context>
    <name>DlgDefaultPic</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.ui" line="28"/>
        <source>画面选择：</source>
        <translation type="unfinished">Selección de pantalla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.ui" line="67"/>
        <source>已选画面:</source>
        <translation type="unfinished">Pantallas seleccionadas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.ui" line="99"/>
        <source>打开工具时默认打开该画面</source>
        <translation type="unfinished">Abrir esta pantalla al iniciar herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.ui" line="165"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.ui" line="172"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.cpp" line="135"/>
        <source>启动画面设置</source>
        <comment>toolName</comment>
        <translation type="unfinished">Configuración de la Gráfica de Inicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.cpp" line="141"/>
        <source>画面选择</source>
        <comment>toolName</comment>
        <translation type="unfinished">Seleccionar Gráfica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.cpp" line="161"/>
        <source>画面列表</source>
        <translation type="unfinished">Lista de pantallas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_default_pic.cpp" line="161"/>
        <source>对象源名称</source>
        <translation type="unfinished">Nombre de fuente de objeto</translation>
    </message>
</context>
<context>
    <name>DlgDictMoveToFileMgr</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_dict_moveto_filemgr.cpp" line="28"/>
        <source>迁移画面/报表版本到文件管理</source>
        <comment>toolName</comment>
        <translation type="unfinished">Migrar Versiones de Gráficas/Informes a la Gestión de Archivos</translation>
    </message>
</context>
<context>
    <name>DlgElementStateList</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_element_state_list.cpp" line="61"/>
        <source>图元态列表</source>
        <comment>toolName</comment>
        <translation type="unfinished">Lista de Estados de Iconos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_element_state_list.cpp" line="95"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_element_state_list.cpp" line="95"/>
        <source>名称数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_element_state_list.cpp" line="129"/>
        <source>提示</source>
        <translation type="unfinished">Consejo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_element_state_list.cpp" line="129"/>
        <source>未选择图元态</source>
        <translation type="unfinished">Estado de figura no seleccionado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_element_state_list.ui" line="54"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_element_state_list.ui" line="61"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>DlgExpressionEdit</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="28"/>
        <source>基本属性：</source>
        <translation type="unfinished">Atributos básicos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="38"/>
        <source>填充颜色说明：用于设备，填充色影响图元态绘制颜色；用于状态前景，使用图元时影响图元态绘制颜色，不使用图元时影响矩形区域填充色；用于数值/字符前景，影响矩形区域填充色</source>
        <translation type="unfinished">Descripción del Color de Relleno: Para el dispositivo, el color de relleno afecta el color de dibujo del estado primitivo. Para el Primer Plano del Estado, afecta el color del estado del icono si se utiliza un icono, o el color de relleno del rectángulo si no. Para el Primer Plano numérico/carácter, afecta el color de relleno del rectángulo.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="71"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="148"/>
        <source>增加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="78"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="155"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="188"/>
        <source>退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="195"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="95"/>
        <source>表达式详情：</source>
        <translation type="unfinished">Detalles de expresión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.ui" line="105"/>
        <source>可在【因子路径、实时表域、历史表域】列做右键选择</source>
        <translation type="unfinished">Use clic derecho en [ruta, dominio real/hist.]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="43"/>
        <source>子集详情[%1_%2应用_%3数据库]</source>
        <translation type="unfinished">Detalles del subconjunto [%1_%2 Aplicación_%3 base de datos]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="113"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="199"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="119"/>
        <source>决策名</source>
        <translation type="unfinished">Nombre de decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="125"/>
        <source>决策表达式</source>
        <translation type="unfinished">Expresión de decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="131"/>
        <source>字符颜色</source>
        <translation type="unfinished">Color de carácter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="136"/>
        <source>决策值</source>
        <translation type="unfinished">Valor de decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="145"/>
        <source>填充颜色</source>
        <translation type="unfinished">Color de relleno</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="150"/>
        <source>决策值2</source>
        <translation type="unfinished">Valor de decisión 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="159"/>
        <source>边框颜色</source>
        <translation type="unfinished">Color del borde</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="164"/>
        <source>决策值3</source>
        <translation type="unfinished">Valor de decisión 3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="205"/>
        <source>因子名称</source>
        <translation type="unfinished">Nombre del factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="211"/>
        <source>因子路径</source>
        <translation type="unfinished">Ruta del factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="217"/>
        <source>因子类别</source>
        <translation type="unfinished">Tipo de factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="229"/>
        <source>实时表域</source>
        <translation type="unfinished">Campo de tabla en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="241"/>
        <source>历史表域</source>
        <translation type="unfinished">Campo de tabla histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="247"/>
        <source>扩展数据源类名</source>
        <translation type="unfinished">Extender el nombre de clase de la fuente de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="253"/>
        <source>扩展数据源动态库路径</source>
        <translation type="unfinished">Extender la ruta de la base de datos dinámica de la fuente de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="259"/>
        <source>备用扩展数据源参数</source>
        <translation type="unfinished">Parámetros de fuente de datos extendida alternativos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="265"/>
        <source>备用扩展数据源参数2</source>
        <translation type="unfinished">Parámetro de fuente de datos extendida alternativo 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="780"/>
        <source>解析表达式有误</source>
        <translation type="unfinished">Error al analizar la expresión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="824"/>
        <source>存在未定义的因子</source>
        <translation type="unfinished">Hay factores indefinidos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="855"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="862"/>
        <source>表达式名称：</source>
        <translation type="unfinished">Nombre de la expresión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="855"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="862"/>
        <source>错误信息：</source>
        <translation type="unfinished">Mensaje de error:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="868"/>
        <source>检查到表达式内容有误：</source>
        <translation type="unfinished">Contenido de expresión inválido detectado:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="868"/>
        <source>请检查并修改后再保存</source>
        <translation type="unfinished">Verifique y modifique antes de guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="869"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1248"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1617"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1657"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1779"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1819"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1847"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1855"/>
        <source>保存失败</source>
        <translation type="unfinished">Fallo al guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1248"/>
        <source>查看日志了解详细错误</source>
        <translation type="unfinished">Ver logs para detalles de error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1253"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1364"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1382"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1387"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1392"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1397"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1418"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1426"/>
        <source>格式解析错误</source>
        <translation type="unfinished">Error de análisis de formato</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1364"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1392"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1418"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1426"/>
        <source>输入内容格式：表名.域名</source>
        <translation type="unfinished">Formato de entrada: tabla.dominio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1382"/>
        <source>域id获取失败</source>
        <translation type="unfinished">Fallo al obtener el ID del campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1387"/>
        <source>表id获取失败</source>
        <translation type="unfinished">¡Fallo al obtener el ID de la tabla!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1397"/>
        <source>数据库链接获取失败</source>
        <translation type="unfinished">Fallo al obtener el enlace de la base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1580"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1585"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1592"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1597"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1605"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1610"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1691"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1696"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1702"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1707"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1713"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1718"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1724"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1729"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1735"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1740"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1746"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1751"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1757"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1762"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1768"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1773"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1580"/>
        <source>决策表达式名称数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1585"/>
        <source>决策表达式名称[%1] 长度超过[%2]，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1592"/>
        <source>决策表达式数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1597"/>
        <source>决策表达式名称[%1] 表达式长度超过[%2]，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1605"/>
        <source>决策值数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1610"/>
        <source>决策表达式名称[%1] 决策值长度超过[%2]，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1617"/>
        <source>决策表达式名称不可为空</source>
        <translation type="unfinished">Nombre de expr. de decisión no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1691"/>
        <source>决策因子名称数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1696"/>
        <source>决策表达式名称[%1] 因子名称[%2] 长度超过[%3]，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1702"/>
        <source>决策因子路径数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1707"/>
        <source>决策表达式名称[%1] 因子名称[%2] 因子路径长度超过[%3]，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1713"/>
        <source>决策因子历史表名数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1718"/>
        <source>决策表达式名称[%1] 因子名称[%2] 历史表名长度超过[%3]，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1724"/>
        <source>决策因子历史域名数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1729"/>
        <source>决策表达式名称[%1] 因子名称[%2] 历史域名长度超过[%3]，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1735"/>
        <source>决策因子扩展数据源动态库路径数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1740"/>
        <source>决策表达式名称[%1] 因子名称[%2] 扩展数据源动态库路径长度超过[%3]，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1746"/>
        <source>决策因子扩展数据源类名称数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1751"/>
        <source>决策表达式名称[%1] 因子名称[%2] 扩展数据源类名称长度超过[%3]，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1757"/>
        <source>决策因子备用扩展数据源参数数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1762"/>
        <source>决策表达式名称[%1] 因子名称[%2] 备用扩展数据源参数长度超过[%3]，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1768"/>
        <source>决策因子备用扩展数据源参数2数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1773"/>
        <source>决策表达式名称[%1] 因子名称[%2] 备用扩展数据源参数2长度超过[%3]，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1779"/>
        <source>决策因子名称不可为空</source>
        <translation type="unfinished">Nombre de factor de decisión no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1830"/>
        <source>保存父对象</source>
        <comment>toolName</comment>
        <translation type="unfinished">Guardar Objeto Padre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1835"/>
        <source>是</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Verdadero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1836"/>
        <source>否</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1897"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1898"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1832"/>
        <source>检测到未保存的更改，是否保存</source>
        <translation type="unfinished">Detectados cambios sin guardar, ¿guardar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1657"/>
        <source>决策表达式名称: %1 重复</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1819"/>
        <source>决策因子名称: %1 重复</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1847"/>
        <source>添加父决策集合失败</source>
        <translation type="unfinished">Fallo al agregar colección de decisión padre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1855"/>
        <source>添加父决策应用失败</source>
        <translation type="unfinished">Fallo al agregar app de decisión padre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1879"/>
        <source>操作成功</source>
        <translation type="unfinished">Operación exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1879"/>
        <source>未检测到需要保存的更改</source>
        <translation type="unfinished">No se detectaron cambios para guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1892"/>
        <source>退出子集编辑</source>
        <translation type="unfinished">Salir de la edición de subconjunto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_expression_edit.cpp" line="1894"/>
        <source>检测到未保存的更改，是否退出</source>
        <translation type="unfinished">Detectados cambios sin guardar, ¿salir?</translation>
    </message>
</context>
<context>
    <name>DlgPlaneDefine</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_plane_define.ui" line="14"/>
        <source>层定义</source>
        <translation type="unfinished">Definición de capa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_plane_define.ui" line="35"/>
        <source>添加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_plane_define.ui" line="42"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_plane_define.ui" line="66"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_plane_define.ui" line="73"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_plane_define.ui" line="83"/>
        <source>层名</source>
        <translation type="unfinished">Nombre de capa</translation>
    </message>
</context>
<context>
    <name>DlgQuickSet</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.ui" line="14"/>
        <source>快速配置</source>
        <translation type="unfinished">Config. rápida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.ui" line="38"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.ui" line="45"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.cpp" line="50"/>
        <source>路径</source>
        <translation type="unfinished">Ruta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.cpp" line="54"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.cpp" line="55"/>
        <source>前缀</source>
        <translation type="unfinished">Prefijo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.cpp" line="56"/>
        <source>通配符</source>
        <translation type="unfinished">Comodín</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.cpp" line="57"/>
        <source>后缀</source>
        <translation type="unfinished">Sufijo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_quick_set.cpp" line="59"/>
        <source>唯一标识</source>
        <translation type="unfinished">Identificador único</translation>
    </message>
</context>
<context>
    <name>DlgTemplateProperty</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="14"/>
        <source>动态属性编辑</source>
        <translation type="unfinished">Edición de atributos dinámicos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="22"/>
        <source>多条件语句的统一配置,建议优先使用该配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="25"/>
        <source>快速配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="32"/>
        <source>复制列值</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Copiar valor de vol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="39"/>
        <source>定义动态模板中需要替换的通配字符建议格式：数字%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="42"/>
        <source>通配符定义</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="62"/>
        <source>静态文本替换定义</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Definir reemplazo de texto estático</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="113"/>
        <source>将当前界面的配置内容清空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="116"/>
        <source>清空配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Borrar configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="123"/>
        <source>重新获取文件里的数据链接并且将旧的配置内容全部清除(清空并重新获取链接功能)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="126"/>
        <source>重置数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="76"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="83"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="90"/>
        <source>将当前界面内容还原至画面中存储的原始状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.ui" line="93"/>
        <source>重载配置</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Recargar configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.cpp" line="68"/>
        <source>路径</source>
        <translation type="unfinished">Ruta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.cpp" line="72"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.cpp" line="73"/>
        <source>前缀</source>
        <translation type="unfinished">Prefijo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.cpp" line="74"/>
        <source>通配符</source>
        <translation type="unfinished">Comodín</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.cpp" line="75"/>
        <source>后缀</source>
        <translation type="unfinished">Sufijo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_template_property.cpp" line="77"/>
        <source>唯一标识</source>
        <translation type="unfinished">Identificador único</translation>
    </message>
</context>
<context>
    <name>DlgWildcardDefine</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.ui" line="14"/>
        <source>通配符定义</source>
        <translation type="unfinished">Definición de comodín</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.ui" line="27"/>
        <source>查询</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.ui" line="51"/>
        <source>新增</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.ui" line="58"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.ui" line="65"/>
        <source>修改</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.ui" line="94"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.ui" line="101"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.cpp" line="47"/>
        <source>标识</source>
        <translation type="unfinished">Identificador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.cpp" line="51"/>
        <source>通配符名称</source>
        <translation type="unfinished">Nombre de comodín</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.cpp" line="55"/>
        <source>源字符串值</source>
        <translation type="unfinished">Valor de cadena fuente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.cpp" line="58"/>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.cpp" line="141"/>
        <source>描述</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.cpp" line="62"/>
        <source>默认值</source>
        <translation type="unfinished">Valor por defecto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.cpp" line="66"/>
        <source>目标字符值</source>
        <translation type="unfinished">Valor de cadena objetivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_components/dialogs/dlg_wildcard_define.cpp" line="137"/>
        <source>通配符</source>
        <translation type="unfinished">Comodín</translation>
    </message>
</context>
</TS>
