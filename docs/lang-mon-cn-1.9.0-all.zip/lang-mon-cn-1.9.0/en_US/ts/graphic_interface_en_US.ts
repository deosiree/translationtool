<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_base_check_interface.cpp" line="27"/>
        <source>图元场景信息获取失败</source>
        <translation type="unfinished">Failed to retrieve icon scene information</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_base_check_interface.cpp" line="47"/>
        <source>图元视图信息获取失败</source>
        <translation type="unfinished">Icon view information retrieval failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_base_check_interface.cpp" line="68"/>
        <source>图元文件解析错误</source>
        <translation type="unfinished">Error in parsing the icon file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_base_check_interface.cpp" line="138"/>
        <source>画面场景信息获取错误</source>
        <translation type="unfinished">Graph scene information retrieval failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_base_check_interface.cpp" line="158"/>
        <source>画面视图信息获取错误</source>
        <translation type="unfinished">Error in retrieving graph view information</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_base_check_interface.cpp" line="179"/>
        <source>画面文件解析错误</source>
        <translation type="unfinished">Error in parsing the graph file</translation>
    </message>
</context>
<context>
    <name>iasp::gui::GraphicImpExpInterface</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_imp_exp_interface.cpp" line="70"/>
        <source>导入包设置类型错误</source>
        <translation type="unfinished">Error in the import package setting type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_imp_exp_interface.cpp" line="80"/>
        <source>用于导入导出的对话框没有被创建</source>
        <translation type="unfinished">The dialog for import and export was not created</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_imp_exp_interface.cpp" line="90"/>
        <source>当前导入检查界面已加载,请关闭后再进行检查</source>
        <translation type="unfinished">The current import check interface has been loaded. Please close it before proceeding with the check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_imp_exp_interface.cpp" line="105"/>
        <source>导入包检查类型错误</source>
        <translation type="unfinished">Error in the import package check type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_imp_exp_interface.cpp" line="121"/>
        <source>当前导出检查界面已加载,请关闭后再进行检查</source>
        <translation type="unfinished">The current export check interface has been loaded. Please close it before proceeding with the check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_imp_exp_interface.cpp" line="136"/>
        <source>导出包检查类型错误</source>
        <translation type="unfinished">Error in the export package check type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_imp_exp_interface.cpp" line="150"/>
        <source>导入/导出前请先做检查</source>
        <translation type="unfinished">Please conduct a check before import/export</translation>
    </message>
</context>
</TS>
