<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QDeclarativeGeoMap</name>
    <message>
        <source>No Map</source>
        <translation>Sin mapa</translation>
    </message>
    <message>
        <source>Plugin does not support mapping.</source>
        <translation>El complemento no admite mapeo.</translation>
    </message>
</context>
<context>
    <name>QDeclarativeGeoRouteModel</name>
    <message>
        <source>Plugin does not support routing.</source>
        <translation>El complemento no admite enrutamiento.</translation>
    </message>
    <message>
        <source>Cannot route, plugin not set.</source>
        <translation>No se puede enrutar, el complemento no está configurado.</translation>
    </message>
    <message>
        <source>Cannot route, route manager not set.</source>
        <translation>No se puede enrutar, el administrador de rutas no está configurado.</translation>
    </message>
    <message>
        <source>Cannot route, valid query not set.</source>
        <translation>No se puede enrutar, consulta válida no establecida.</translation>
    </message>
    <message>
        <source>Not enough waypoints for routing.</source>
        <translation>No hay suficientes puntos de referencia para el enrutamiento.</translation>
    </message>
</context>
<context>
    <name>QDeclarativeGeocodeModel</name>
    <message>
        <source>Cannot geocode, plugin not set.</source>
        <translation>No se puede geocodificar, el complemento no está establecido.</translation>
    </message>
    <message>
        <source>Cannot geocode, geocode manager not set.</source>
        <translation>No se puede geocodificar, el gestor de geocodificación no está establecido.</translation>
    </message>
    <message>
        <source>Cannot geocode, valid query not set.</source>
        <translation>No se puede geocodificar, consulta válida no establecida.</translation>
    </message>
    <message>
        <source>Plugin does not support (reverse) geocoding.</source>
        <translation>El complemento no soporta geocodificación (inversa).</translation>
    </message>
</context>
<context>
    <name>QGeoServiceProviderFactoryMapbox</name>
    <message>
        <source>Mapbox plugin requires a &apos;mapbox.access_token&apos; parameter.
Please visit https://www.mapbox.com</source>
        <translation>El complemento de Mapbox requiere un parámetro &apos;mapbox.access_token&apos;.
Por favor visita https://www.mapbox.com</translation>
    </message>
</context>
<context>
    <name>QGeoTileFetcherNokia</name>
    <message>
        <source>Mapping manager no longer exists</source>
        <translation>El gestor de mapeo ya no existe</translation>
    </message>
</context>
<context>
    <name>QGeoTiledMappingManagerEngineMapbox</name>
    <message>
        <source>Street</source>
        <extracomment>Noun describing map type &apos;Street map&apos;</extracomment>
        <translation>Calle</translation>
    </message>
    <message>
        <source>Light</source>
        <extracomment>Noun describing type of a map using light colors (weak contrast)</extracomment>
        <translation>Ligero</translation>
    </message>
    <message>
        <source>Dark</source>
        <extracomment>Noun describing type of a map using dark colors</extracomment>
        <translation>Oscuro</translation>
    </message>
    <message>
        <source>Satellite</source>
        <extracomment>Noun describing type of a map created by satellite</extracomment>
        <translation>Satélite</translation>
    </message>
    <message>
        <source>Streets Satellite</source>
        <extracomment>Noun describing type of a street map created by satellite</extracomment>
        <translation>Calles Satélite</translation>
    </message>
    <message>
        <source>Wheatpaste</source>
        <extracomment>Noun describing type of a map using wheat paste colors</extracomment>
        <translation>Wheatpaste</translation>
    </message>
    <message>
        <source>Streets Basic</source>
        <extracomment>Noun describing type of a basic street map</extracomment>
        <translation>Calles Básico</translation>
    </message>
    <message>
        <source>Comic</source>
        <extracomment>Noun describing type of a map using cartoon-style fonts</extracomment>
        <translation>Cómic</translation>
    </message>
    <message>
        <source>Outdoors</source>
        <extracomment>Noun describing type of a map for outdoor activities</extracomment>
        <translation>Exteriores</translation>
    </message>
    <message>
        <source>Run Bike Hike</source>
        <extracomment>Noun describing type of a map for sports</extracomment>
        <translation>Correr Bicicleta Caminata</translation>
    </message>
    <message>
        <source>Pencil</source>
        <extracomment>Noun describing type of a map drawn by pencil</extracomment>
        <translation>Lápiz</translation>
    </message>
    <message>
        <source>Pirates</source>
        <extracomment>Noun describing type of a treasure map with pirate boat watermark</extracomment>
        <translation>Piratas</translation>
    </message>
    <message>
        <source>Emerald</source>
        <extracomment>Noun describing type of a map using emerald colors</extracomment>
        <translation>Esmeralda</translation>
    </message>
    <message>
        <source>High Contrast</source>
        <extracomment>Noun describing type of a map with high contrast</extracomment>
        <translation>Alto Contraste</translation>
    </message>
</context>
<context>
    <name>QGeoTiledMappingManagerEngineNokia</name>
    <message>
        <source>Street Map</source>
        <translation>Mapa de Calles</translation>
    </message>
    <message>
        <source>Normal map view in daylight mode</source>
        <translation>Vista de mapa normal en modo diurno</translation>
    </message>
    <message>
        <source>Satellite Map</source>
        <translation>Mapa Satelital</translation>
    </message>
    <message>
        <source>Satellite map view in daylight mode</source>
        <translation>Vista de mapa satelital en modo diurno</translation>
    </message>
    <message>
        <source>Terrain Map</source>
        <translation>Mapa de Terreno</translation>
    </message>
    <message>
        <source>Terrain map view in daylight mode</source>
        <translation>Vista de mapa de terreno en modo diurno</translation>
    </message>
    <message>
        <source>Hybrid Map</source>
        <translation>Mapa Híbrido</translation>
    </message>
    <message>
        <source>Satellite map view with streets in daylight mode</source>
        <translation>Vista de mapa satelital con calles en modo diurno</translation>
    </message>
    <message>
        <source>Transit Map</source>
        <translation>Mapa de Tránsito</translation>
    </message>
    <message>
        <source>Color-reduced map view with public transport scheme in daylight mode</source>
        <translation>Vista de mapa con colores reducidos y esquema de transporte público en modo diurno</translation>
    </message>
    <message>
        <source>Gray Street Map</source>
        <translation>Mapa de Calle en Gris</translation>
    </message>
    <message>
        <source>Color-reduced map view in daylight mode</source>
        <translation>Vista de mapa con colores reducidos en modo diurno</translation>
    </message>
    <message>
        <source>Mobile Street Map</source>
        <translation>Mapa de Calle Móvil</translation>
    </message>
    <message>
        <source>Mobile normal map view in daylight mode</source>
        <translation>Vista de mapa normal móvil en modo diurno</translation>
    </message>
    <message>
        <source>Mobile Terrain Map</source>
        <translation>Mapa de Terreno Móvil</translation>
    </message>
    <message>
        <source>Mobile terrain map view in daylight mode</source>
        <translation>Vista de mapa de terreno móvil en modo diurno</translation>
    </message>
    <message>
        <source>Mobile Hybrid Map</source>
        <translation>Mapa Híbrido Móvil</translation>
    </message>
    <message>
        <source>Mobile satellite map view with streets in daylight mode</source>
        <translation>Vista de mapa satelital móvil con calles en modo diurno</translation>
    </message>
    <message>
        <source>Mobile Transit Map</source>
        <translation>Mapa de Tránsito Móvil</translation>
    </message>
    <message>
        <source>Mobile color-reduced map view with public transport scheme in daylight mode</source>
        <translation>Vista de mapa móvil con colores reducidos y esquema de transporte público en modo diurno</translation>
    </message>
    <message>
        <source>Mobile Gray Street Map</source>
        <translation>Mapa de Calles Grises Móvil</translation>
    </message>
    <message>
        <source>Mobile color-reduced map view in daylight mode</source>
        <translation>Vista de mapa móvil con colores reducidos en modo diurno</translation>
    </message>
    <message>
        <source>Custom Street Map</source>
        <translation>Mapa de Calle Personalizado</translation>
    </message>
    <message>
        <source>Night Street Map</source>
        <translation>Mapa de Calles Nocturno</translation>
    </message>
    <message>
        <source>Normal map view in night mode</source>
        <translation>Vista de mapa normal en modo nocturno</translation>
    </message>
    <message>
        <source>Mobile Night Street Map</source>
        <translation>Mapa de Calle Nocturno Móvil</translation>
    </message>
    <message>
        <source>Mobile normal map view in night mode</source>
        <translation>Vista de mapa normal móvil en modo nocturno</translation>
    </message>
    <message>
        <source>Gray Night Street Map</source>
        <translation>Mapa de Calle Nocturno en Gris</translation>
    </message>
    <message>
        <source>Color-reduced map view in night mode (especially used for background maps)</source>
        <translation>Vista de mapa con colores reducidos en modo nocturno (especialmente usado para mapas de fondo)</translation>
    </message>
    <message>
        <source>Mobile Gray Night Street Map</source>
        <translation>Mapa de Calles Nocturno Gris Móvil</translation>
    </message>
    <message>
        <source>Mobile color-reduced map view in night mode (especially used for background maps)</source>
        <translation>Vista de mapa móvil con colores reducidos en modo nocturno (especialmente usado para mapas de fondo)</translation>
    </message>
    <message>
        <source>Pedestrian Street Map</source>
        <translation>Mapa de Calle Peatonal</translation>
    </message>
    <message>
        <source>Pedestrian map view in daylight mode</source>
        <translation>Vista de mapa peatonal en modo diurno</translation>
    </message>
    <message>
        <source>Mobile Pedestrian Street Map</source>
        <translation>Mapa de Calle Peatonal Móvil</translation>
    </message>
    <message>
        <source>Mobile pedestrian map view in daylight mode for mobile usage</source>
        <translation>Vista de mapa peatonal móvil en modo diurno para uso móvil</translation>
    </message>
    <message>
        <source>Pedestrian Night Street Map</source>
        <translation>Mapa de Calle Peatonal Nocturno</translation>
    </message>
    <message>
        <source>Pedestrian map view in night mode</source>
        <translation>Vista de mapa peatonal en modo nocturno</translation>
    </message>
    <message>
        <source>Mobile Pedestrian Night Street Map</source>
        <translation>Mapa de Calles Nocturno Peatonal Móvil</translation>
    </message>
    <message>
        <source>Mobile pedestrian map view in night mode for mobile usage</source>
        <translation>Vista de mapa peatonal móvil en modo nocturno para uso móvil</translation>
    </message>
    <message>
        <source>Car Navigation Map</source>
        <translation>Mapa de Navegación para Automóviles</translation>
    </message>
    <message>
        <source>Normal map view in daylight mode for car navigation</source>
        <translation>Vista de mapa normal en modo diurno para navegación en coche</translation>
    </message>
</context>
<context>
    <name>QGeoTiledMappingManagerEngineOsm</name>
    <message>
        <source>Street Map</source>
        <translation>Mapa de Calles</translation>
    </message>
    <message>
        <source>Street map view in daylight mode</source>
        <translation>Vista de mapa de calles en modo diurno</translation>
    </message>
    <message>
        <source>Satellite Map</source>
        <translation>Mapa Satelital</translation>
    </message>
    <message>
        <source>Satellite map view in daylight mode</source>
        <translation>Vista de mapa satelital en modo diurno</translation>
    </message>
    <message>
        <source>Cycle Map</source>
        <translation>Mapa de Ciclo</translation>
    </message>
    <message>
        <source>Cycle map view in daylight mode</source>
        <translation>Vista de mapa de ciclo en modo diurno</translation>
    </message>
    <message>
        <source>Transit Map</source>
        <translation>Mapa de Tránsito</translation>
    </message>
    <message>
        <source>Public transit map view in daylight mode</source>
        <translation>Vista de mapa de transporte público en modo diurno</translation>
    </message>
    <message>
        <source>Night Transit Map</source>
        <translation>Mapa de Tránsito Nocturno</translation>
    </message>
    <message>
        <source>Public transit map view in night mode</source>
        <translation>Vista de mapa de transporte público en modo nocturno</translation>
    </message>
    <message>
        <source>Terrain Map</source>
        <translation>Mapa de Terreno</translation>
    </message>
    <message>
        <source>Terrain map view</source>
        <translation>Vista de mapa de terreno</translation>
    </message>
    <message>
        <source>Hiking Map</source>
        <translation>Mapa de Senderismo</translation>
    </message>
    <message>
        <source>Hiking map view</source>
        <translation>Vista de mapa de senderismo</translation>
    </message>
    <message>
        <source>Custom URL Map</source>
        <translation>Mapa de URL Personalizado</translation>
    </message>
    <message>
        <source>Custom url map view set via urlprefix parameter</source>
        <translation>Vista de mapa de URL personalizado configurada mediante el parámetro urlprefix</translation>
    </message>
</context>
<context>
    <name>QPlaceManagerEngineOsm</name>
    <message>
        <source>Aeroway</source>
        <translation>Aerovía</translation>
    </message>
    <message>
        <source>Amenity</source>
        <translation>Amenidad</translation>
    </message>
    <message>
        <source>Building</source>
        <translation>Edificio</translation>
    </message>
    <message>
        <source>Highway</source>
        <translation>Carretera</translation>
    </message>
    <message>
        <source>Historic</source>
        <translation>Histórico</translation>
    </message>
    <message>
        <source>Land use</source>
        <translation>Uso del suelo</translation>
    </message>
    <message>
        <source>Leisure</source>
        <translation>Ocio</translation>
    </message>
    <message>
        <source>Man made</source>
        <translation>Hecho por el hombre</translation>
    </message>
    <message>
        <source>Natural</source>
        <translation>Natural</translation>
    </message>
    <message>
        <source>Place</source>
        <translation>Lugar</translation>
    </message>
    <message>
        <source>Railway</source>
        <translation>Ferrocarril</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Tienda</translation>
    </message>
    <message>
        <source>Tourism</source>
        <translation>Turismo</translation>
    </message>
    <message>
        <source>Waterway</source>
        <translation>Vía fluvial</translation>
    </message>
    <message>
        <source>Network request error</source>
        <translation>Error de solicitud de red</translation>
    </message>
</context>
<context>
    <name>QPlaceSearchReplyOsm</name>
    <message>
        <source>Response parse error</source>
        <translation>Error de análisis de respuesta</translation>
    </message>
</context>
<context>
    <name>QtLocationQML</name>
    <message>
        <source>Plugin property is not set.</source>
        <translation>La propiedad del complemento no está configurada.</translation>
    </message>
    <message>
        <source>Plugin Error (%1): %2</source>
        <translation>Error de plugin (%1): %2</translation>
    </message>
    <message>
        <source>Plugin Error (%1): Could not instantiate provider</source>
        <translation>Error de plugin (%1): No se pudo instanciar el proveedor</translation>
    </message>
    <message>
        <source>Plugin is not valid</source>
        <translation>El complemento no es válido</translation>
    </message>
    <message>
        <source>Unable to initialize categories</source>
        <translation>No se pueden inicializar las categorías</translation>
    </message>
    <message>
        <source>Unable to create request</source>
        <translation>No se puede crear la solicitud</translation>
    </message>
    <message>
        <source>Index &apos;%1&apos; out of range</source>
        <translation>Índice &apos;%1&apos; fuera de rango</translation>
    </message>
    <message>
        <source>Qt Location requires apiKey parameter.
Please register at https://developer.here.com/ to get your personal application credentials.</source>
        <translation>Qt Location requiere el parámetro apiKey.
Por favor regístrese en https://developer.here.com/ para obtener sus credenciales personales de aplicación.</translation>
    </message>
    <message>
        <source>Saving places is not supported.</source>
        <translation>No se admite guardar lugares.</translation>
    </message>
    <message>
        <source>Removing places is not supported.</source>
        <translation>No se admite la eliminación de lugares.</translation>
    </message>
    <message>
        <source>Saving categories is not supported.</source>
        <translation>No se admite guardar categorías.</translation>
    </message>
    <message>
        <source>Removing categories is not supported.</source>
        <translation>No se admite eliminar categorías.</translation>
    </message>
    <message>
        <source>Error parsing response.</source>
        <translation>Error al analizar la respuesta.</translation>
    </message>
    <message>
        <source>Network error.</source>
        <translation>Error de red.</translation>
    </message>
    <message>
        <source>Request was canceled.</source>
        <translation>La solicitud fue cancelada.</translation>
    </message>
    <message>
        <source>The response from the service was not in a recognizable format.</source>
        <translation>La respuesta del servicio no estaba en un formato reconocible.</translation>
    </message>
    <message>
        <source>Qt Location requires app_id and token parameters.
Please register at https://developer.here.com/ to get your personal application credentials.</source>
        <translation type="vanished">Qt Location requiere parámetros app_id y token.
Por favor regístrese en https://developer.here.com/ para obtener sus credenciales personales de aplicación.</translation>
    </message>
</context>
<context>
    <name>QGeoRouteParserOsrmV5</name>
    <message>
        <source>North</source>
        <extracomment>Translations exist at https://github.com/Project-OSRM/osrm-text-instructions. Always used in &quot;Head %1 [onto &lt;street name&gt;]&quot;</extracomment>
        <translation>Norte</translation>
    </message>
    <message>
        <source>East</source>
        <translation>Este</translation>
    </message>
    <message>
        <source>South</source>
        <translation>Sur</translation>
    </message>
    <message>
        <source>West</source>
        <translation>Oeste</translation>
    </message>
    <message>
        <source>first</source>
        <comment>roundabout exit</comment>
        <extracomment>always used in &quot; and take the %1 exit [onto &lt;street name&gt;]&quot;</extracomment>
        <translation>primero</translation>
    </message>
    <message>
        <source>second</source>
        <comment>roundabout exit</comment>
        <translation>segundo</translation>
    </message>
    <message>
        <source>third</source>
        <comment>roundabout exit</comment>
        <translation>tercero</translation>
    </message>
    <message>
        <source>fourth</source>
        <comment>roundabout exit</comment>
        <translation>cuarto</translation>
    </message>
    <message>
        <source>fifth</source>
        <comment>roundabout exit</comment>
        <translation>quinto</translation>
    </message>
    <message>
        <source>sixth</source>
        <comment>roundabout exit</comment>
        <translation>sexto</translation>
    </message>
    <message>
        <source>seventh</source>
        <comment>roundabout exit</comment>
        <translation>séptimo</translation>
    </message>
    <message>
        <source>eighth</source>
        <comment>roundabout exit</comment>
        <translation>octavo</translation>
    </message>
    <message>
        <source>ninth</source>
        <comment>roundabout exit</comment>
        <translation>noveno</translation>
    </message>
    <message>
        <source>tenth</source>
        <comment>roundabout exit</comment>
        <translation>décimo</translation>
    </message>
    <message>
        <source>eleventh</source>
        <comment>roundabout exit</comment>
        <translation>undécimo</translation>
    </message>
    <message>
        <source>twelfth</source>
        <comment>roundabout exit</comment>
        <translation>duodécimo</translation>
    </message>
    <message>
        <source>thirteenth</source>
        <comment>roundabout exit</comment>
        <translation>decimotercero</translation>
    </message>
    <message>
        <source>fourteenth</source>
        <comment>roundabout exit</comment>
        <translation>decimocuarto</translation>
    </message>
    <message>
        <source>fifteenth</source>
        <comment>roundabout exit</comment>
        <translation>decimoquinto</translation>
    </message>
    <message>
        <source>sixteenth</source>
        <comment>roundabout exit</comment>
        <translation>decimosexto</translation>
    </message>
    <message>
        <source>seventeenth</source>
        <comment>roundabout exit</comment>
        <translation>decimoséptimo</translation>
    </message>
    <message>
        <source>eighteenth</source>
        <comment>roundabout exit</comment>
        <translation>decimoctavo</translation>
    </message>
    <message>
        <source>nineteenth</source>
        <comment>roundabout exit</comment>
        <translation>decimonoveno</translation>
    </message>
    <message>
        <source>twentieth</source>
        <comment>roundabout exit</comment>
        <translation>vigésimo</translation>
    </message>
    <message>
        <source> and take the %1 exit</source>
        <extracomment>Always appended to one of the following strings: - &quot;Enter the roundabout&quot; - &quot;Enter the rotary&quot; - &quot;Enter the rotary &lt;rotaryname&gt;&quot;</extracomment>
        <translation> y toma la salida %1</translation>
    </message>
    <message>
        <source> and take the %1 exit onto %2</source>
        <translation> y tome la salida %1 hacia %2</translation>
    </message>
    <message>
        <source>You have arrived at your destination, straight ahead</source>
        <translation>Ha llegado a su destino, justo enfrente</translation>
    </message>
    <message>
        <source>You have arrived at your destination, on the left</source>
        <translation>Ha llegado a su destino, a la izquierda</translation>
    </message>
    <message>
        <source>You have arrived at your destination, on the right</source>
        <translation>Ha llegado a su destino, a la derecha</translation>
    </message>
    <message>
        <source>You have arrived at your destination</source>
        <translation>Ha llegado a su destino</translation>
    </message>
    <message>
        <source>Continue straight</source>
        <translation>Continuar recto</translation>
    </message>
    <message>
        <source>Continue straight on %1</source>
        <translation>Continúe recto en %1</translation>
    </message>
    <message>
        <source>Continue left</source>
        <translation>Continúe a la izquierda</translation>
    </message>
    <message>
        <source>Continue left onto %1</source>
        <translation>Continúe a la izquierda en %1</translation>
    </message>
    <message>
        <source>Continue slightly left</source>
        <translation>Continúa ligeramente a la izquierda</translation>
    </message>
    <message>
        <source>Continue slightly left on %1</source>
        <translation>Continúe ligeramente a la izquierda en %1</translation>
    </message>
    <message>
        <source>Continue right</source>
        <translation>Continúe a la derecha</translation>
    </message>
    <message>
        <source>Continue right onto %1</source>
        <translation>Continuar a la derecha hacia %1</translation>
    </message>
    <message>
        <source>Continue slightly right</source>
        <translation>Continúe ligeramente a la derecha</translation>
    </message>
    <message>
        <source>Continue slightly right on %1</source>
        <translation>Continúe ligeramente a la derecha en %1</translation>
    </message>
    <message>
        <source>Make a U-turn</source>
        <translation>Da una vuelta en U</translation>
    </message>
    <message>
        <source>Make a U-turn onto %1</source>
        <translation>Da una vuelta en U en %1</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Continuar</translation>
    </message>
    <message>
        <source>Continue on %1</source>
        <translation>Continuar en %1</translation>
    </message>
    <message>
        <source>Head %1</source>
        <extracomment>%1 is &quot;North&quot;, &quot;South&quot;, &quot;East&quot; or &quot;West&quot;</extracomment>
        <translation>Dirigirse %1</translation>
    </message>
    <message>
        <source>Head %1 onto %2</source>
        <translation>Dirígete %1 en %2</translation>
    </message>
    <message>
        <source>Depart</source>
        <translation>Partir</translation>
    </message>
    <message>
        <source>Depart onto %1</source>
        <translation>Sal en %1</translation>
    </message>
    <message>
        <source>At the end of the road, turn left</source>
        <translation>Al final de la carretera, gire a la izquierda</translation>
    </message>
    <message>
        <source>At the end of the road, turn left onto %1</source>
        <translation>Al final del camino, girar a la izquierda hacia %1</translation>
    </message>
    <message>
        <source>At the end of the road, turn right</source>
        <translation>Al final de la carretera, gire a la derecha</translation>
    </message>
    <message>
        <source>At the end of the road, turn right onto %1</source>
        <translation>Al final del camino, girar a la derecha hacia %1</translation>
    </message>
    <message>
        <source>At the end of the road, make a U-turn</source>
        <translation>Al final del camino, da una vuelta en U</translation>
    </message>
    <message>
        <source>At the end of the road, make a U-turn onto %1</source>
        <translation>Al final del camino, dé la vuelta en U hacia %1</translation>
    </message>
    <message>
        <source>At the end of the road, continue straight</source>
        <translation>Al final del camino, continúe recto</translation>
    </message>
    <message>
        <source>At the end of the road, continue straight onto %1</source>
        <translation>Al final del camino, continúa recto hacia %1</translation>
    </message>
    <message>
        <source>At the end of the road, continue</source>
        <translation>Al final del camino, continúa</translation>
    </message>
    <message>
        <source>At the end of the road, continue onto %1</source>
        <translation>Al final del camino, continúa en %1</translation>
    </message>
    <message>
        <source>Take the ferry</source>
        <translation>Toma el ferry</translation>
    </message>
    <message>
        <source>At the fork, take a sharp left</source>
        <translation>En la bifurcación, tomar una curva cerrada a la izquierda</translation>
    </message>
    <message>
        <source>At the fork, take a sharp left onto %1</source>
        <translation>En la bifurcación, tomar una curva cerrada a la izquierda hacia %1</translation>
    </message>
    <message>
        <source>At the fork, turn left</source>
        <translation>En la bifurcación, gira a la izquierda</translation>
    </message>
    <message>
        <source>At the fork, turn left onto %1</source>
        <translation>En la bifurcación, gire a la izquierda en %1</translation>
    </message>
    <message>
        <source>At the fork, keep left</source>
        <translation>En la bifurcación, mantente a la izquierda</translation>
    </message>
    <message>
        <source>At the fork, keep left onto %1</source>
        <translation>En la bifurcación, mantenerse a la izquierda hacia %1</translation>
    </message>
    <message>
        <source>At the fork, take a sharp right</source>
        <translation>En la bifurcación, toma una curva cerrada a la derecha</translation>
    </message>
    <message>
        <source>At the fork, take a sharp right onto %1</source>
        <translation>En la bifurcación, tome una curva cerrada a la derecha en %1</translation>
    </message>
    <message>
        <source>At the fork, turn right</source>
        <translation>En la bifurcación, gire a la derecha</translation>
    </message>
    <message>
        <source>At the fork, turn right onto %1</source>
        <translation>En la bifurcación, girar a la derecha hacia %1</translation>
    </message>
    <message>
        <source>At the fork, keep right</source>
        <translation>En la bifurcación, manténgase a la derecha</translation>
    </message>
    <message>
        <source>At the fork, keep right onto %1</source>
        <translation>En la bifurcación, mantenerse a la derecha hacia %1</translation>
    </message>
    <message>
        <source>At the fork, continue straight ahead</source>
        <translation>En la bifurcación, continúe recto</translation>
    </message>
    <message>
        <source>At the fork, continue straight ahead onto %1</source>
        <translation>En la bifurcación, continúa recto hacia %1</translation>
    </message>
    <message>
        <source>At the fork, continue</source>
        <translation>En la bifurcación, continúa</translation>
    </message>
    <message>
        <source>At the fork, continue onto %1</source>
        <translation>En la bifurcación, continuar hacia %1</translation>
    </message>
    <message>
        <source>Merge sharply left</source>
        <translation>Incorpórese bruscamente a la izquierda</translation>
    </message>
    <message>
        <source>Merge sharply left onto %1</source>
        <translation>Incorpórese bruscamente a la izquierda hacia %1</translation>
    </message>
    <message>
        <source>Merge left</source>
        <translation>Incorpórate a la izquierda</translation>
    </message>
    <message>
        <source>Merge left onto %1</source>
        <translation>Incorpórese a la izquierda hacia %1</translation>
    </message>
    <message>
        <source>Merge slightly left</source>
        <translation>Incorpórate ligeramente a la izquierda</translation>
    </message>
    <message>
        <source>Merge slightly left on %1</source>
        <translation>Incorpórese ligeramente a la izquierda en %1</translation>
    </message>
    <message>
        <source>Merge sharply right</source>
        <translation>Incorpórese bruscamente a la derecha</translation>
    </message>
    <message>
        <source>Merge sharply right onto %1</source>
        <translation>Incorpórese bruscamente a la derecha en %1</translation>
    </message>
    <message>
        <source>Merge right</source>
        <translation>Incorpórese a la derecha</translation>
    </message>
    <message>
        <source>Merge right onto %1</source>
        <translation>Incorpórese a la derecha en %1</translation>
    </message>
    <message>
        <source>Merge slightly right</source>
        <translation>Incorporarse levemente a la derecha</translation>
    </message>
    <message>
        <source>Merge slightly right on %1</source>
        <translation>Incorpórese ligeramente a la derecha en %1</translation>
    </message>
    <message>
        <source>Merge straight</source>
        <translation>Incorpórate recto</translation>
    </message>
    <message>
        <source>Merge straight on %1</source>
        <translation>Incorporarse recto en %1</translation>
    </message>
    <message>
        <source>Merge</source>
        <translation>Incorpórese</translation>
    </message>
    <message>
        <source>Merge onto %1</source>
        <translation>Incorpórate en %1</translation>
    </message>
    <message>
        <source>Take a sharp left</source>
        <translation>Toma una curva cerrada a la izquierda</translation>
    </message>
    <message>
        <source>Take a sharp left onto %1</source>
        <translation>Tome una curva cerrada a la izquierda en %1</translation>
    </message>
    <message>
        <source>Turn left</source>
        <translation>Gire a la izquierda</translation>
    </message>
    <message>
        <source>Turn left onto %1</source>
        <translation>Gira a la izquierda en %1</translation>
    </message>
    <message>
        <source>Continue slightly left onto %1</source>
        <translation>Continúe ligeramente a la izquierda hacia %1</translation>
    </message>
    <message>
        <source>Take a sharp right</source>
        <translation>Tome una curva cerrada a la derecha</translation>
    </message>
    <message>
        <source>Take a sharp right onto %1</source>
        <translation>Tome una curva cerrada a la derecha en %1</translation>
    </message>
    <message>
        <source>Turn right</source>
        <translation>Gira a la derecha</translation>
    </message>
    <message>
        <source>Turn right onto %1</source>
        <translation>Girar a la derecha hacia %1</translation>
    </message>
    <message>
        <source>Continue slightly right onto %1</source>
        <translation>Continúa ligeramente a la derecha en %1</translation>
    </message>
    <message>
        <source>Continue straight onto %1</source>
        <translation>Continúe recto hacia %1</translation>
    </message>
    <message>
        <source>Continue onto %1</source>
        <translation>Continúe en %1</translation>
    </message>
    <message>
        <source>Continue on the left</source>
        <translation>Continúe por la izquierda</translation>
    </message>
    <message>
        <source>Continue on the left on %1</source>
        <translation>Continúa a la izquierda en %1</translation>
    </message>
    <message>
        <source>Continue on the right</source>
        <translation>Continúa a la derecha</translation>
    </message>
    <message>
        <source>Continue on the right on %1</source>
        <translation>Continuar por la derecha en %1</translation>
    </message>
    <message>
        <source>Take the ramp on the left</source>
        <translation>Tome la rampa a la izquierda</translation>
    </message>
    <message>
        <source>Take the ramp on the left onto %1</source>
        <translation>Tomar la rampa a la izquierda hacia %1</translation>
    </message>
    <message>
        <source>Take the ramp on the right</source>
        <translation>Toma la rampa a la derecha</translation>
    </message>
    <message>
        <source>Take the ramp on the right onto %1</source>
        <translation>Tome la rampa a la derecha en %1</translation>
    </message>
    <message>
        <source>Take the ramp</source>
        <translation>Tome la rampa</translation>
    </message>
    <message>
        <source>Take the ramp onto %1</source>
        <translation>Tomar la rampa hacia %1</translation>
    </message>
    <message>
        <source>Get off the bike and push</source>
        <translation>Bajarse de la bicicleta y empujar</translation>
    </message>
    <message>
        <source>Get off the bike and push onto %1</source>
        <translation>Bájese de la bicicleta y empuje en %1</translation>
    </message>
    <message>
        <source>Enter the rotary</source>
        <extracomment>This string will be prepended to &quot; and take the &lt;nth&gt; exit [onto &lt;streetname&gt;]</extracomment>
        <translation>Entra en la rotonda</translation>
    </message>
    <message>
        <source>Enter the roundabout</source>
        <extracomment>This string will be prepended to &quot; and take the &lt;nth&gt; exit [onto &lt;streetname&gt;]</extracomment>
        <translation>Entre en la rotonda</translation>
    </message>
    <message>
        <source>At the roundabout, continue straight</source>
        <translation>En la rotonda, continúe recto</translation>
    </message>
    <message>
        <source>At the roundabout, continue straight on %1</source>
        <translation>En la rotonda, continúe recto en %1</translation>
    </message>
    <message>
        <source>At the roundabout, turn left</source>
        <translation>En la rotonda, gire a la izquierda</translation>
    </message>
    <message>
        <source>At the roundabout, turn left onto %1</source>
        <translation>En la rotonda, gira a la izquierda en %1</translation>
    </message>
    <message>
        <source>At the roundabout, turn right</source>
        <translation>En la rotonda, gira a la derecha</translation>
    </message>
    <message>
        <source>At the roundabout, turn right onto %1</source>
        <translation>En la rotonda, gire a la derecha en %1</translation>
    </message>
    <message>
        <source>At the roundabout, turn around</source>
        <translation>En la rotonda, dar la vuelta</translation>
    </message>
    <message>
        <source>At the roundabout, turn around onto %1</source>
        <translation>En la rotonda, da la vuelta en %1</translation>
    </message>
    <message>
        <source>At the roundabout, continue</source>
        <translation>En la rotonda, continuar</translation>
    </message>
    <message>
        <source>At the roundabout, continue onto %1</source>
        <translation>En la rotonda, continúe en %1</translation>
    </message>
    <message>
        <source>Take the train</source>
        <translation>Tomar el tren</translation>
    </message>
    <message>
        <source>Take the train [%1]</source>
        <translation>Tome el tren [%1]</translation>
    </message>
    <message>
        <source>Go straight</source>
        <translation>Sigue recto</translation>
    </message>
    <message>
        <source>Go straight onto %1</source>
        <translation>Siga recto en %1</translation>
    </message>
    <message>
        <source>Turn slightly left</source>
        <translation>Gire ligeramente a la izquierda</translation>
    </message>
    <message>
        <source>Turn slightly left onto %1</source>
        <translation>Gire ligeramente a la izquierda en %1</translation>
    </message>
    <message>
        <source>Turn slightly right</source>
        <translation>Gira ligeramente a la derecha</translation>
    </message>
    <message>
        <source>Turn slightly right onto %1</source>
        <translation>Gire ligeramente a la derecha hacia %1</translation>
    </message>
    <message>
        <source>Turn</source>
        <translation>Girar</translation>
    </message>
    <message>
        <source>Turn onto %1</source>
        <translation>Gire hacia %1</translation>
    </message>
    <message>
        <source> and continue straight</source>
        <extracomment>This string will be prepended with lane instructions. E.g., &quot;Use the left or the right lane and continue straight&quot;</extracomment>
        <translation> y continúe recto</translation>
    </message>
    <message>
        <source> and continue straight onto %1</source>
        <translation> y continuar directamente hacia %1</translation>
    </message>
    <message>
        <source> and make a sharp left</source>
        <translation> y da una curva cerrada a la izquierda</translation>
    </message>
    <message>
        <source> and make a sharp left onto %1</source>
        <translation> y haz una curva cerrada a la izquierda en %1</translation>
    </message>
    <message>
        <source> and turn left</source>
        <translation> y gire a la izquierda</translation>
    </message>
    <message>
        <source> and turn left onto %1</source>
        <translation> y gira a la izquierda en %1</translation>
    </message>
    <message>
        <source> and make a slight left</source>
        <translation> y girar levemente a la izquierda</translation>
    </message>
    <message>
        <source> and make a slight left onto %1</source>
        <translation> y haga una ligera izquierda en %1</translation>
    </message>
    <message>
        <source> and make a sharp right</source>
        <translation> y haga una curva cerrada a la derecha</translation>
    </message>
    <message>
        <source> and make a sharp right onto %1</source>
        <translation> y haga una curva cerrada a la derecha en %1</translation>
    </message>
    <message>
        <source> and turn right</source>
        <translation> y gira a la derecha</translation>
    </message>
    <message>
        <source> and turn right onto %1</source>
        <translation> y gire a la derecha en %1</translation>
    </message>
    <message>
        <source> and make a slight right</source>
        <translation> y girar levemente a la derecha</translation>
    </message>
    <message>
        <source> and make a slight right onto %1</source>
        <translation> y haga una ligera derecha en %1</translation>
    </message>
    <message>
        <source> and make a U-turn</source>
        <translation> y da una vuelta en U</translation>
    </message>
    <message>
        <source> and make a U-turn onto %1</source>
        <translation> y dar la vuelta en U hacia %1</translation>
    </message>
</context>
<context>
    <name>GeoServiceProviderFactoryEsri</name>
    <message>
        <source>Esri plugin requires a &apos;esri.token&apos; parameter.
Please visit https://developers.arcgis.com/authentication/accessing-arcgis-online-services/</source>
        <translation>El complemento de Esri requiere un parámetro &apos;esri.token&apos;.
Por favor visite https://developers.arcgis.com/authentication/accessing-arcgis-online-services/</translation>
    </message>
</context>
<context>
    <name>PlaceSearchReplyEsri</name>
    <message>
        <source>Response parse error</source>
        <translation>Error de análisis de respuesta</translation>
    </message>
</context>
<context>
    <name>QGeoMappingManagerEngineItemsOverlay</name>
    <message>
        <source>Empty Map</source>
        <translation>Mapa vacío</translation>
    </message>
</context>
<context>
    <name>QGeoCodeReplyMapbox</name>
    <message>
        <source>Response parse error</source>
        <translation>Error de análisis de respuesta</translation>
    </message>
</context>
<context>
    <name>QPlaceSearchReplyMapbox</name>
    <message>
        <source>Response parse error</source>
        <translation>Error de análisis de respuesta</translation>
    </message>
</context>
<context>
    <name>QPlaceSearchSuggestionReplyMapbox</name>
    <message>
        <source>Response parse error</source>
        <translation>Error de análisis de respuesta</translation>
    </message>
</context>
<context>
    <name>QGeoMapMapboxGL</name>
    <message>
        <source>Development access token, do not use in production.</source>
        <translation>Token de acceso de desarrollo, no usar en producción.</translation>
    </message>
</context>
<context>
    <name>QGeoMappingManagerEngineMapboxGL</name>
    <message>
        <source>China Streets</source>
        <translation>China Streets</translation>
    </message>
    <message>
        <source>China Light</source>
        <translation>China Light</translation>
    </message>
    <message>
        <source>China Dark</source>
        <translation>China Oscuro</translation>
    </message>
    <message>
        <source>Streets</source>
        <translation>Calles</translation>
    </message>
    <message>
        <source>Basic</source>
        <translation>Básico</translation>
    </message>
    <message>
        <source>Bright</source>
        <translation>Brillante</translation>
    </message>
    <message>
        <source>Outdoors</source>
        <translation>Exteriores</translation>
    </message>
    <message>
        <source>Satellite</source>
        <translation>Satélite</translation>
    </message>
    <message>
        <source>Satellite Streets</source>
        <translation>Calles satelitales</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Ligero</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Oscuro</translation>
    </message>
    <message>
        <source>Navigation Preview Day</source>
        <translation>Vista previa de navegación diurna</translation>
    </message>
    <message>
        <source>Navigation Preview Night</source>
        <translation>Vista previa de navegación nocturna</translation>
    </message>
    <message>
        <source>Navigation Guidance Day</source>
        <translation>Guía de navegación diurna</translation>
    </message>
    <message>
        <source>Navigation Guidance Night</source>
        <translation>Guía de navegación nocturna</translation>
    </message>
    <message>
        <source>User provided style</source>
        <translation>Estilo proporcionado por el usuario</translation>
    </message>
</context>
<context>
    <name>QGeoRouteParserOsrmV4</name>
    <message>
        <source>Go straight.</source>
        <translation>Siga recto.</translation>
    </message>
    <message>
        <source>Go straight onto %1.</source>
        <translation>Siga recto en %1.</translation>
    </message>
    <message>
        <source>Turn slightly right.</source>
        <translation>Gire ligeramente a la derecha.</translation>
    </message>
    <message>
        <source>Turn slightly right onto %1.</source>
        <translation>Gire ligeramente a la derecha en %1.</translation>
    </message>
    <message>
        <source>Turn right.</source>
        <translation>Gire a la derecha.</translation>
    </message>
    <message>
        <source>Turn right onto %1.</source>
        <translation>Gire a la derecha en %1.</translation>
    </message>
    <message>
        <source>Make a sharp right.</source>
        <translation>Gire bruscamente a la derecha.</translation>
    </message>
    <message>
        <source>Make a sharp right onto %1.</source>
        <translation>Gire bruscamente a la derecha en %1.</translation>
    </message>
    <message>
        <source>When it is safe to do so, perform a U-turn.</source>
        <translation>Cuando sea seguro hacerlo, realice un cambio de sentido.</translation>
    </message>
    <message>
        <source>Make a sharp left.</source>
        <translation>Gire bruscamente a la izquierda.</translation>
    </message>
    <message>
        <source>Make a sharp left onto %1.</source>
        <translation>Gire bruscamente a la izquierda en %1.</translation>
    </message>
    <message>
        <source>Turn left.</source>
        <translation>Gire a la izquierda.</translation>
    </message>
    <message>
        <source>Turn left onto %1.</source>
        <translation>Gire a la izquierda en %1.</translation>
    </message>
    <message>
        <source>Turn slightly left.</source>
        <translation>Gire ligeramente a la izquierda.</translation>
    </message>
    <message>
        <source>Turn slightly left onto %1.</source>
        <translation>Gire ligeramente a la izquierda en %1.</translation>
    </message>
    <message>
        <source>Reached waypoint.</source>
        <translation>Ha llegado al punto de referencia.</translation>
    </message>
    <message>
        <source>Head on.</source>
        <translation>Siga adelante.</translation>
    </message>
    <message>
        <source>Head onto %1.</source>
        <translation>Diríjase a %1.</translation>
    </message>
    <message>
        <source>Enter the roundabout.</source>
        <translation>Entre en la rotonda.</translation>
    </message>
    <message>
        <source>At the roundabout take the first exit.</source>
        <translation>En la rotonda, tome la primera salida.</translation>
    </message>
    <message>
        <source>At the roundabout take the first exit onto %1.</source>
        <translation>En la rotonda, tome la primera salida en %1.</translation>
    </message>
    <message>
        <source>At the roundabout take the second exit.</source>
        <translation>En la rotonda, tome la segunda salida.</translation>
    </message>
    <message>
        <source>At the roundabout take the second exit onto %1.</source>
        <translation>En la rotonda, toma la segunda salida hacia %1.</translation>
    </message>
    <message>
        <source>At the roundabout take the third exit.</source>
        <translation>En la rotonda, tome la tercera salida.</translation>
    </message>
    <message>
        <source>At the roundabout take the third exit onto %1.</source>
        <translation>En la rotonda, toma la tercera salida hacia %1.</translation>
    </message>
    <message>
        <source>At the roundabout take the fourth exit.</source>
        <translation>En la rotonda, tome la cuarta salida.</translation>
    </message>
    <message>
        <source>At the roundabout take the fourth exit onto %1.</source>
        <translation>En la rotonda, tome la cuarta salida en %1.</translation>
    </message>
    <message>
        <source>At the roundabout take the fifth exit.</source>
        <translation>En la rotonda, tome la quinta salida.</translation>
    </message>
    <message>
        <source>At the roundabout take the fifth exit onto %1.</source>
        <translation>En la rotonda, tome la quinta salida en %1.</translation>
    </message>
    <message>
        <source>At the roundabout take the sixth exit.</source>
        <translation>En la rotonda, tome la sexta salida.</translation>
    </message>
    <message>
        <source>At the roundabout take the sixth exit onto %1.</source>
        <translation>En la rotonda, tome la sexta salida en %1.</translation>
    </message>
    <message>
        <source>At the roundabout take the seventh exit.</source>
        <translation>En la rotonda, tome la séptima salida.</translation>
    </message>
    <message>
        <source>At the roundabout take the seventh exit onto %1.</source>
        <translation>En la rotonda, tome la séptima salida en %1.</translation>
    </message>
    <message>
        <source>At the roundabout take the eighth exit.</source>
        <translation>En la rotonda, toma la octava salida.</translation>
    </message>
    <message>
        <source>At the roundabout take the eighth exit onto %1.</source>
        <translation>En la rotonda, tome la octava salida en %1.</translation>
    </message>
    <message>
        <source>At the roundabout take the ninth exit.</source>
        <translation>En la rotonda, tome la novena salida.</translation>
    </message>
    <message>
        <source>At the roundabout take the ninth exit onto %1.</source>
        <translation>En la rotonda, tome la novena salida en %1.</translation>
    </message>
    <message>
        <source>Leave the roundabout.</source>
        <translation>Salga de la rotonda.</translation>
    </message>
    <message>
        <source>Leave the roundabout onto %1.</source>
        <translation>Salga de la rotonda en %1.</translation>
    </message>
    <message>
        <source>Stay on the roundabout.</source>
        <translation>Permanezca en la rotonda.</translation>
    </message>
    <message>
        <source>Start at the end of the street.</source>
        <translation>Comience al final de la calle.</translation>
    </message>
    <message>
        <source>Start at the end of %1.</source>
        <translation>Comience al final de %1.</translation>
    </message>
    <message>
        <source>You have reached your destination.</source>
        <translation>Ha llegado a su destino.</translation>
    </message>
    <message>
        <source>Don&apos;t know what to say for &apos;%1&apos;</source>
        <translation>No sé qué decir para &apos;%1&apos;</translation>
    </message>
</context>
</TS>
