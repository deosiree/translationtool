<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CommonUtility</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/common_utility.cpp" line="32"/>
        <source>yyyy&apos;年&apos;M&apos;月&apos;d&apos;日&apos;</source>
        <translation type="unfinished">d&apos;Día&apos;M&apos;Mes&apos;yyyy&apos;Año&apos;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/common_utility.cpp" line="35"/>
        <source>HH&apos;时&apos;mm&apos;分&apos;ss&apos;秒&apos;</source>
        <translation type="unfinished">HH&apos;Hora&apos;mm&apos;Minuto&apos;ss&apos;Segundo&apos;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/common_utility.cpp" line="84"/>
        <source>版本%1</source>
        <translation type="unfinished">Versión %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/common_utility.cpp" line="86"/>
        <source>草稿版本</source>
        <translation type="unfinished">Versión de borrador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/common_utility.cpp" line="88"/>
        <source>最新版本</source>
        <translation type="unfinished">Última versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/common_utility.cpp" line="96"/>
        <source>模板：</source>
        <translation type="unfinished">Plantilla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/common_utility.cpp" line="328"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/common_utility.cpp" line="338"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/common_utility.cpp" line="328"/>
        <source>草稿文件不存在</source>
        <translation type="unfinished">Archivo borrador no existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/common_utility.cpp" line="338"/>
        <source>历史版本文件下载失败</source>
        <translation type="unfinished">Descarga de archivo de versión hist. falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/common_utility.cpp" line="421"/>
        <source>全责区</source>
        <translation type="unfinished">Área de responsabilidad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/common_utility.cpp" line="422"/>
        <source>责任区1</source>
        <translation type="unfinished">AOR 1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/common_utility.cpp" line="423"/>
        <source>责任区2</source>
        <translation type="unfinished">AOR 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/common_utility.cpp" line="424"/>
        <source>责任区3</source>
        <translation type="unfinished">AOR 3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/common_utility.cpp" line="425"/>
        <source>责任区4</source>
        <translation type="unfinished">AOR 4</translation>
    </message>
</context>
<context>
    <name>DataBlockDetailDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_datablock_detail.ui" line="14"/>
        <source>数据块配置</source>
        <translation type="unfinished">Configurar bloque de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_datablock_detail.ui" line="20"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_datablock_detail.ui" line="27"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>FilePugiXmlHandle</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_pugixml_handle.cpp" line="26"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_pugixml_handle.cpp" line="653"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_pugixml_handle.cpp" line="659"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_pugixml_handle.cpp" line="27"/>
        <source>文件%1保存失败，请修改循环引用</source>
        <translation type="unfinished">Fallo al guardar %1, modifique ref. cíclica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_pugixml_handle.cpp" line="200"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_pugixml_handle.cpp" line="202"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_pugixml_handle.cpp" line="208"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_pugixml_handle.cpp" line="210"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_pugixml_handle.cpp" line="33"/>
        <source>文件保存中</source>
        <translation type="unfinished">Guardando archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_pugixml_handle.cpp" line="200"/>
        <source>成功导出到：%1</source>
        <translation type="unfinished">Exportado con éxito a: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_pugixml_handle.cpp" line="202"/>
        <source>导出失败</source>
        <translation type="unfinished">Fallo al exportar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_pugixml_handle.cpp" line="208"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_pugixml_handle.cpp" line="210"/>
        <source>保存失败</source>
        <translation type="unfinished">Fallo al guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_pugixml_handle.cpp" line="653"/>
        <source>报表文件无效</source>
        <translation type="unfinished">Archivo de reporte inválido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_pugixml_handle.cpp" line="679"/>
        <source>文件读取中</source>
        <translation type="unfinished">Leyendo archivo</translation>
    </message>
</context>
<context>
    <name>FileXlsxHandle</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xlsx_handle.cpp" line="311"/>
        <source>询问</source>
        <translation type="unfinished">Solicitar</translation>
    </message>
</context>
<context>
    <name>FileXmlHandle</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="27"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="405"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="410"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="417"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="424"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="28"/>
        <source>文件%1保存失败，请修改循环引用</source>
        <translation type="unfinished">Fallo al guardar %1, modifique ref. cíclica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="35"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="35"/>
        <source>文件打开或创建失败</source>
        <translation type="unfinished">Fallo al abrir o crear archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="39"/>
        <source>文件保存中</source>
        <translation type="unfinished">Guardando archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="182"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="182"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="370"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="405"/>
        <source>文件不存在</source>
        <translation type="unfinished">Archivo no existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="382"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="417"/>
        <source>操作的文件不是XML格式</source>
        <translation type="unfinished">Archivo no es formato XML</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="438"/>
        <source>文件读取中</source>
        <translation type="unfinished">Leyendo archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="375"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="410"/>
        <source>文件打开失败</source>
        <translation type="unfinished">Fallo al abrir archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="723"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xml_handle.cpp" line="729"/>
        <source>报表文件格式无效</source>
        <translation type="unfinished">Formato de archivo de reporte inválido</translation>
    </message>
</context>
<context>
    <name>GraphicPropDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_graphic_property.ui" line="14"/>
        <source>图片大小</source>
        <translation type="unfinished">Tamaño de imagen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_graphic_property.ui" line="35"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_graphic_property.ui" line="42"/>
        <source>宽度：</source>
        <translation type="unfinished">Ancho:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_graphic_property.ui" line="62"/>
        <source>高度：</source>
        <translation type="unfinished">Altura:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_graphic_property.ui" line="72"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_graphic_property.ui" line="112"/>
        <source>%</source>
        <translation type="unfinished">%</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_graphic_property.ui" line="85"/>
        <source>缩放高度：</source>
        <translation type="unfinished">Zoom altura:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_graphic_property.ui" line="105"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_graphic_property.ui" line="125"/>
        <source>锁定纵横比</source>
        <translation type="unfinished">Bloquear la relación de aspecto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_graphic_property.ui" line="132"/>
        <source>缩放宽度：</source>
        <translation type="unfinished">Zoom ancho:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_graphic_property.ui" line="139"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_graphic_property.ui" line="146"/>
        <source>像素</source>
        <translation type="unfinished">Píxel</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/file_xlsx_handle.cpp" line="312"/>
        <source>Excel文件的行数(%1)或者列数(%2)超过原有表格的行列数,可能存在内容截断，是否继续</source>
        <translation type="unfinished">Filas (%1) o cols (%2) exceden tabla, ¿continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/format_commands.cpp" line="41"/>
        <source>告警</source>
        <comment>DataChangedCommand::chanegDisplayData</comment>
        <translation type="unfinished">Alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/operate_commands.cpp" line="285"/>
        <source>自定义数据块</source>
        <comment>DeleteLinksCommand::undo</comment>
        <translation type="unfinished">Bloque de datos personalizado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/operate_commands.cpp" line="389"/>
        <source>自定义数据块</source>
        <comment>DeleteContentsCommand::undo</comment>
        <translation type="unfinished">Bloque de datos personalizado</translation>
    </message>
</context>
<context>
    <name>QueryTimeDlg</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_query_time.cpp" line="25"/>
        <source>设置查询时间</source>
        <comment>toolName</comment>
        <translation type="unfinished">Establecer Tiempo de Consulta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_query_time.cpp" line="29"/>
        <source>开始时间：</source>
        <translation type="unfinished">Hora de inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_query_time.cpp" line="38"/>
        <source>结束时间：</source>
        <translation type="unfinished">Hora de finalización:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_query_time.cpp" line="66"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_query_time.cpp" line="70"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_query_time.cpp" line="101"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/dialogs/dlg_query_time.cpp" line="101"/>
        <source>日期选择错误，请重新选择</source>
        <translation type="unfinished">Error en selección de fecha, reintente</translation>
    </message>
</context>
<context>
    <name>ReportDictionaryTree</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="46"/>
        <source>报表列表</source>
        <translation type="unfinished">Lista de reportes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="46"/>
        <source>对象源名称</source>
        <translation type="unfinished">Nombre de fuente de objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="89"/>
        <source>删除版本</source>
        <translation type="unfinished">Eliminar versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="108"/>
        <source>新建报表分类</source>
        <translation type="unfinished">Nueva categoría de informe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="109"/>
        <source>新建模板分类</source>
        <translation type="unfinished">Nueva categoría de plantilla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="110"/>
        <source>新建动态模板分类</source>
        <translation type="unfinished">Nueva categoría de plantilla dinámica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="332"/>
        <source>历史版本</source>
        <translation type="unfinished">Versión histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="346"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="354"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="643"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="646"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="848"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="851"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="942"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1010"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1201"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1245"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1253"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1263"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1303"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1345"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1376"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1405"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1434"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1470"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1512"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1541"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1656"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="346"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="354"/>
        <source>未找到有效版本</source>
        <translation type="unfinished">No se encontró versión válida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="472"/>
        <source>分类名称</source>
        <translation type="unfinished">Nombre de categoría</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="472"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="573"/>
        <source>请输入%1分类名称：</source>
        <translation type="unfinished">Por favor, ingrese el nombre de la categoría %1:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="486"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="491"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="514"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="519"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="587"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="592"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="605"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="611"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="668"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="727"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="758"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="764"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="875"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1679"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1790"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1795"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="2230"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="486"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="587"/>
        <source>分类名称不可为空</source>
        <translation type="unfinished">Nombre de clasif. no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1254"/>
        <source>是</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1255"/>
        <source>否</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1264"/>
        <source>归零</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Regresar a cero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1265"/>
        <source>不归零</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No regresar a cero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="491"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="592"/>
        <source>分类名称超长</source>
        <translation type="unfinished">Nombre de clasif. demasiado largo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="101"/>
        <source>刷新列表</source>
        <translation type="unfinished">Actualizar Lista</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="126"/>
        <source>向导新建</source>
        <comment>menuName</comment>
        <translation type="unfinished">Nuevo asis</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="127"/>
        <source>新建报表</source>
        <comment>menuName</comment>
        <translation type="unfinished">Nuevo inf</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="128"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="2176"/>
        <source>新建模板</source>
        <comment>menuName</comment>
        <translation type="unfinished">Nuevo mod</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="129"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="2158"/>
        <source>新建子分类</source>
        <comment>menuName</comment>
        <translation type="unfinished">Nueva sub</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="130"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="153"/>
        <source>修改</source>
        <comment>menuName</comment>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="131"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="154"/>
        <source>删除</source>
        <comment>menuName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="152"/>
        <source>版本发布</source>
        <comment>menuName</comment>
        <translation type="unfinished">Pub vers</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="157"/>
        <source>清空历史版本</source>
        <comment>menuName</comment>
        <translation type="unfinished">Borr vers hist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="479"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="580"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="479"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="580"/>
        <source>名称数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="514"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="605"/>
        <source>%1子分类已存在</source>
        <translation type="unfinished">Subclasif. %1 ya existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="519"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="611"/>
        <source>%1子分类插入数据库失败</source>
        <translation type="unfinished">Subclasif. %1 falló al insertar en BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="573"/>
        <source>修改分类名称</source>
        <translation type="unfinished">Modificar nombre de categoría</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="643"/>
        <source>删除失败，该分类不为空</source>
        <translation type="unfinished">Eliminación falló, clasif. no vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="646"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="851"/>
        <source>是否删除</source>
        <translation type="unfinished">¿Eliminar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="668"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="875"/>
        <source>删除失败</source>
        <translation type="unfinished">Eliminación falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="727"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="2230"/>
        <source>%1分类不存在</source>
        <translation type="unfinished">Clasif. %1 no existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="758"/>
        <source>%1已存在</source>
        <translation type="unfinished">%1 ya existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="764"/>
        <source>%1插入数据库失败</source>
        <translation type="unfinished">%1 inserción en BD falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="781"/>
        <source>草稿版本</source>
        <translation type="unfinished">Versión de borrador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="848"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="942"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1010"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1245"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1656"/>
        <source>报表已在节点：%1,进程号：%2,注册名：%3 中打开</source>
        <translation type="unfinished">El informe se ha abierto en el nodo: %1, ID del proceso: %2, nombre registrado: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1201"/>
        <source>暂无历史版本，无需清理</source>
        <translation type="unfinished">No hay versión hist., no hay que limpiar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1253"/>
        <source>此操作将删除所有历史版本，是否继续</source>
        <translation type="unfinished">Eliminará todas las versiones hist., ¿seguir?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1266"/>
        <source>取消操作</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="2170"/>
        <source>新建动态模板子分类</source>
        <comment>menuName</comment>
        <translation type="unfinished">Nueva sub mod din</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="2171"/>
        <source>新建动态模板</source>
        <comment>menuName</comment>
        <translation type="unfinished">Nuevo mod din</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="2175"/>
        <source>新建模板子分类</source>
        <comment>menuName</comment>
        <translation type="unfinished">Nueva sub mod</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1263"/>
        <source>是否版本归零</source>
        <translation type="unfinished">¿Volver versión a cero?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1303"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1376"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1405"/>
        <source>版本归零成功</source>
        <translation type="unfinished">Reinicio de versión exitoso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1345"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1434"/>
        <source>版本归零失败</source>
        <translation type="unfinished">Reinicio de versión falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1470"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1541"/>
        <source>清空历史版本成功</source>
        <translation type="unfinished">Limpieza de versión hist. exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1512"/>
        <source>清空历史版本失败</source>
        <translation type="unfinished">Fallo al limpiar versión histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1679"/>
        <source>草稿版本不存在，发布失败</source>
        <translation type="unfinished">Versión borrador no existe, pub. falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1663"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1727"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1738"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1663"/>
        <source>发布中止</source>
        <translation type="unfinished">Publicación abortada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1727"/>
        <source>发布成功</source>
        <translation type="unfinished">Publicado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1738"/>
        <source>发布失败</source>
        <translation type="unfinished">Publicación falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1790"/>
        <source>暂无草稿版本</source>
        <translation type="unfinished">Sin versión borrador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="1795"/>
        <source>暂无历史版本，禁止删除草稿版本</source>
        <translation type="unfinished">No hay versión hist., borrar borrador prohibido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="2263"/>
        <source>模板</source>
        <translation type="unfinished">Plantilla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_dictionary_tree.cpp" line="2263"/>
        <source>报表</source>
        <translation type="unfinished">Informe</translation>
    </message>
</context>
<context>
    <name>ReportFillHandle</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="11"/>
        <source>星期一</source>
        <translation type="unfinished">Lunes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="11"/>
        <source>星期二</source>
        <translation type="unfinished">Martes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="11"/>
        <source>星期三</source>
        <translation type="unfinished">Miércoles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="12"/>
        <source>星期四</source>
        <translation type="unfinished">Jueves</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="12"/>
        <source>星期五</source>
        <translation type="unfinished">Viernes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="12"/>
        <source>星期六</source>
        <translation type="unfinished">Sábado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="12"/>
        <source>星期日</source>
        <translation type="unfinished">Domingo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="13"/>
        <source>一月</source>
        <translation type="unfinished">Un mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="13"/>
        <source>二月</source>
        <translation type="unfinished">Febrero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="13"/>
        <source>三月</source>
        <translation type="unfinished">Marzo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="14"/>
        <source>四月</source>
        <translation type="unfinished">Abril</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="14"/>
        <source>五月</source>
        <translation type="unfinished">May</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="14"/>
        <source>六月</source>
        <translation type="unfinished">Junio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="14"/>
        <source>七月</source>
        <translation type="unfinished">Julio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="14"/>
        <source>八月</source>
        <translation type="unfinished">Agosto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="14"/>
        <source>九月</source>
        <translation type="unfinished">Septiembre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="15"/>
        <source>十月</source>
        <translation type="unfinished">Octubre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="15"/>
        <source>十一月</source>
        <translation type="unfinished">Noviembre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_fill_handle.cpp" line="15"/>
        <source>十二月</source>
        <translation type="unfinished">Diciembre</translation>
    </message>
</context>
<context>
    <name>ReportModel</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_model.cpp" line="76"/>
        <source>月底</source>
        <translation type="unfinished">Final de mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_model.cpp" line="77"/>
        <source>年</source>
        <translation type="unfinished">Año</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_model.cpp" line="78"/>
        <source>月</source>
        <translation type="unfinished">Mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_model.cpp" line="79"/>
        <source>周</source>
        <translation type="unfinished">Semana</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_model.cpp" line="80"/>
        <source>日</source>
        <translation type="unfinished">Dom</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_model.cpp" line="81"/>
        <source>时</source>
        <translation type="unfinished">Hora</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_model.cpp" line="82"/>
        <source>分</source>
        <translation type="unfinished">Minuto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_model.cpp" line="83"/>
        <source>本</source>
        <translation type="unfinished">Corriente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_model.cpp" line="84"/>
        <source>前</source>
        <translation type="unfinished">Anterior</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_model.cpp" line="85"/>
        <source>后</source>
        <translation type="unfinished">Siguiente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_model.cpp" line="86"/>
        <source>求和</source>
        <translation type="unfinished">Suma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_model.cpp" line="87"/>
        <source>首部减去尾部</source>
        <translation type="unfinished">Cabeza menos Cola</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_model.cpp" line="88"/>
        <source>尾部减去首部</source>
        <translation type="unfinished">Cola menos Cabeza</translation>
    </message>
</context>
<context>
    <name>ReportTable</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="338"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="440"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1075"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1082"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1105"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1160"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1166"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1211"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1217"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="338"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="440"/>
        <source>数据块区域不可粘贴</source>
        <translation type="unfinished">Área de bloque de datos no se puede pegar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="774"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="827"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="874"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="877"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1801"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1858"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1916"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1918"/>
        <source>通知</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="774"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="827"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="874"/>
        <source>未查询到匹配的数据</source>
        <translation type="unfinished">No se encontraron datos coincidentes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="877"/>
        <source>搜索已完成并进行了%1处的替换</source>
        <translation type="unfinished">Búsqueda completada con %1 reemplazos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1008"/>
        <source>填充柄功能支持填充序列(等差、等比)、星期、月份、日期时间</source>
        <translation type="unfinished">La función de arrastre de relleno admite llenar secuencias (diferencia constante, proporción constante), día de la semana, mes, fecha y hora.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1075"/>
        <source>有数据块的区域，不支持使用填充柄功能</source>
        <translation type="unfinished">Rellenar no soportado en áreas con bloques</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1082"/>
        <source>有合并单元格的区域，不支持使用填充柄功能</source>
        <translation type="unfinished">Rellenar no soportado en celdas fusionadas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1105"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1160"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1166"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1211"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1217"/>
        <source>有公式/测点/时间/图片的区域，不支持使用填充柄功能</source>
        <translation type="unfinished">Rellenar no soportado en área con fórmula</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1558"/>
        <source>自定义数据块</source>
        <translation type="unfinished">Bloques de datos personalizados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1664"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1686"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1770"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1823"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1898"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1664"/>
        <source>是否保存对%1的更改</source>
        <translation type="unfinished">¿Desea guardar los cambios en %1?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1665"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1899"/>
        <source>是</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1666"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1900"/>
        <source>否</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1667"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1688"/>
        <source>中止操作</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Abortar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1687"/>
        <source>放弃</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Abandonar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1686"/>
        <source>当前用户无操作权限，是否放弃对%1的更改</source>
        <translation type="unfinished">Usuario sin permiso, ¿descartar cambios a %1?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1765"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1773"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1818"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1826"/>
        <source>无缩放</source>
        <translation type="unfinished">Sin escala</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1766"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1777"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1819"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1830"/>
        <source>将所有列打印在一页</source>
        <translation type="unfinished">Imprimir todas las columnas en una página</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1767"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1781"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1820"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1834"/>
        <source>将所有行打印在一页</source>
        <translation type="unfinished">Imprimir todas las filas en una página</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1768"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1821"/>
        <source>将所有内容打印在一页</source>
        <translation type="unfinished">Imprimir todo el contenido en una página</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1770"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1823"/>
        <source>请选择缩放模式</source>
        <translation type="unfinished">Por favor, seleccione el modo de zoom</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1801"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1858"/>
        <source>打印成功</source>
        <translation type="unfinished">Impresión exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1867"/>
        <source>导出Xlsx文件</source>
        <translation type="unfinished">Exportar archivo xlsx</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1898"/>
        <source>表格包含公式，可能与xlsx不兼容，是否导出</source>
        <translation type="unfinished">Tabla con fórmulas, ¿exportar a xlsx?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1916"/>
        <source>导出到：%1成功</source>
        <translation type="unfinished">Exportado a:%1 con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/report_table.cpp" line="1918"/>
        <source>导出失败</source>
        <translation type="unfinished">Exportación falló</translation>
    </message>
</context>
<context>
    <name>TableFormulaRule</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/table_formula_rule.cpp" line="112"/>
        <source>%1可能存在循环引用，请修改</source>
        <translation type="unfinished">%1 puede tener ref. cíclica, modifique</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/table_formula_rule.cpp" line="144"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/table_formula_rule.cpp" line="157"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_base_api/table_formula_rule.cpp" line="144"/>
        <location filename="../../../../src/plat/gui/api/report_base_api/table_formula_rule.cpp" line="157"/>
        <source>公式解析错误</source>
        <translation type="unfinished">Error al analizar fórmula</translation>
    </message>
</context>
</TS>
