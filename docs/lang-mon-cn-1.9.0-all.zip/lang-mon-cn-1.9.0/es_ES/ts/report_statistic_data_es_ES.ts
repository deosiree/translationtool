<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/data/report_statistic_data.cpp" line="22"/>
        <source>数据块测试数据</source>
        <comment>ReportStatisticData::getDataBlockData</comment>
        <translation type="unfinished">Datos de prueba de bloque</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/data/report_statistic_data.cpp" line="23"/>
        <source>测试1</source>
        <comment>ReportStatisticData::getDataBlockData</comment>
        <translation type="unfinished">Prueba 1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/data/report_statistic_data.cpp" line="23"/>
        <source>测试2</source>
        <comment>ReportStatisticData::getDataBlockData</comment>
        <translation type="unfinished">Prueba 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/data/report_statistic_data.cpp" line="36"/>
        <source>序号</source>
        <comment>ReportStatisticData::getDataBlockData</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/report_statistic_interface/data/report_statistic_data.cpp" line="36"/>
        <source>对象</source>
        <comment>ReportStatisticData::getDataBlockData</comment>
        <translation type="unfinished">Objeto</translation>
    </message>
</context>
</TS>
