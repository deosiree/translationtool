<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/pluginsecuserlogininfo.cpp" line="49"/>
        <source>用户登录信息</source>
        <translation type="unfinished">Info de inicio de sesión</translation>
    </message>
</context>
<context>
    <name>UserLoginInfo</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/userlogininfo.ui" line="14"/>
        <source>UserLoginInfo</source>
        <translation type="unfinished">UserLoginInfo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/userlogininfo.ui" line="32"/>
        <source>用户登录信息</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Info de inicio de sesión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/userlogininfo.ui" line="80"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/userlogininfo.cpp" line="143"/>
        <source>用户名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/userlogininfo.cpp" line="143"/>
        <source>工具名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de la herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/userlogininfo.cpp" line="143"/>
        <source>节点名称</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre del nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/userlogininfo.cpp" line="143"/>
        <source>节点别名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Alias del nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/userlogininfo.cpp" line="143"/>
        <source>节点类型</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tipo de nodo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/userlogininfo.cpp" line="143"/>
        <source>登录时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Hora de inicio de sesión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/userlogininfo.cpp" line="143"/>
        <source>超时退出时间</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Tiempo de espera</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/userlogininfo.cpp" line="157"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/userlogininfo.cpp" line="185"/>
        <source>系统节点</source>
        <translation type="unfinished">Nodo del sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/userlogininfo.cpp" line="157"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/userlogininfo.cpp" line="185"/>
        <source>系统外节点</source>
        <translation type="unfinished">Nodo fuera del sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/userlogininfo.cpp" line="230"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secuserlogininfo/userlogininfo.cpp" line="230"/>
        <source>刷新成功</source>
        <translation type="unfinished">Actualización exitosa</translation>
    </message>
</context>
</TS>
