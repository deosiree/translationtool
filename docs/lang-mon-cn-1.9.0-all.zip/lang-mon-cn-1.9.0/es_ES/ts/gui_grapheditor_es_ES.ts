<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>DlgAddField</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_add_field.ui" line="22"/>
        <source>图元层:</source>
        <translation type="unfinished">Capa de iconos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_add_field.ui" line="49"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_add_field.ui" line="56"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>DlgAddStatus</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_add_status.ui" line="14"/>
        <source>态</source>
        <translation type="unfinished">Modo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_add_status.ui" line="25"/>
        <source>图元状态:</source>
        <comment>internal</comment>
        <translation type="unfinished">Estado del icono:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_add_status.ui" line="43"/>
        <source>态值：</source>
        <translation type="unfinished">Valor de estado:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_add_status.ui" line="80"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_add_status.ui" line="87"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>DlgChangeAllVoltage</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_change_all_voltage.ui" line="14"/>
        <source>电压等级修改</source>
        <translation type="unfinished">Modificación Nivel Voltaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_change_all_voltage.ui" line="24"/>
        <source>请修改电压等级:</source>
        <translation type="unfinished">Modificar nivel voltaje:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_change_all_voltage.ui" line="64"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_change_all_voltage.ui" line="71"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>DlgConditionReplace</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="216"/>
        <source>条件路径替换</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="234"/>
        <source>替换规则管理</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="241"/>
        <source>查找内容</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="241"/>
        <source>替换为</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="248"/>
        <source>添加规则</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="249"/>
        <source>删除规则</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="250"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1407"/>
        <source>应用规则</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="262"/>
        <source>匹配选项</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="267"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1850"/>
        <source>区分大小写</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="268"/>
        <source>全字匹配</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="299"/>
        <source>路径对比</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="308"/>
        <source>路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="308"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1840"/>
        <source>OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="374"/>
        <source>全部替换</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="376"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1409"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1993"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2134"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2237"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2292"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="851"/>
        <source>检测到 %1 个规则冲突，可能产生链式替换效应</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="916"/>
        <source>总数: %1 项（%2 个唯一路径）  |  匹配: %3 项（%4 个唯一）  |  将替换: %5 项（%6 个唯一）</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="925"/>
        <source>总数: %1 项  |  匹配: %2 项  |  将替换: %3 项</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="958"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2236"/>
        <source>正在更新界面显示...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="968"/>
        <source>正在更新界面显示... (%1/%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1016"/>
        <source>路径无变化：%1（共%2个相同路径）</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1018"/>
        <source>路径无变化：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1038"/>
        <source>OID查询失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1053"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1055"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1185"/>
        <source>原始：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1076"/>
        <source>原始路径：%1（共%2个相同路径）</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1078"/>
        <source>原始路径：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1086"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1088"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1227"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2509"/>
        <source>替换：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1118"/>
        <source>替换后路径：%1（共%2个相同路径）</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1120"/>
        <source>替换后路径：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1127"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1231"/>
        <source>应用规则：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1139"/>
        <source>应用的替换规则</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1166"/>
        <source>界面更新完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1332"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1332"/>
        <source>没有需要替换的项目</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1339"/>
        <source>规则冲突警告</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1340"/>
        <source>检测到 %1 个规则冲突，可能产生意外结果。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1341"/>
        <source>系统将使用基于原始文本的算法防止链式替换。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1342"/>
        <source>是否继续？</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1358"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1665"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1669"/>
        <source>更新失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1359"/>
        <source>OID和别名条件更新失败，替换操作已取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1408"/>
        <source>正在计算预览路径，请稍候...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1430"/>
        <source>正在计算预览路径... (%1/%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1455"/>
        <source>预览计算完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1503"/>
        <source>确定要应用 %1 个规则替换 %2 个路径吗？</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1507"/>
        <source>OID查询状态警告：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1508"/>
        <source>• 查询成功：%1 个路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1509"/>
        <source>• 查询失败：%1 个路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1521"/>
        <source>继续操作将：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1522"/>
        <source>• 成功查询到OID的路径：更新OID和别名条件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1523"/>
        <source>• 查询失败的路径：仅更新路径，保持原有OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1525"/>
        <source>✓ 所有替换后的路径都已成功查询到OID（%1 个）</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1526"/>
        <source>将同时更新OID和别名条件信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1558"/>
        <source>确认多规则替换</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1599"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1790"/>
        <source>无法获取数据库连接句柄</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1607"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1796"/>
        <source>无法获取数据库连接 [%1:%2:%3]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1638"/>
        <source>更新别名条件异常 [%1]: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1640"/>
        <source>更新别名条件发生未知异常 [%1]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1646"/>
        <source>OID和别名条件更新完成：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1647"/>
        <source>• 更新OID：%1 个</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1648"/>
        <source>• 更新别名条件：%1 个</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1651"/>
        <source>遇到 %1 个错误：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1656"/>
        <source>... 还有 %1 个错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2048"/>
        <source>OID查询完成！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2049"/>
        <source>成功：%1 个，失败：%2 个</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1660"/>
        <source>更新结果</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1666"/>
        <source>更新OID和别名条件时发生异常：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1670"/>
        <source>更新OID和别名条件时发生未知异常</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1781"/>
        <source>路径、应用名或数据库名为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1804"/>
        <source>查询失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1809"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2205"/>
        <source>未找到匹配的OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1819"/>
        <source>查询过程发生异常: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1822"/>
        <source>查询过程发生未知异常</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1833"/>
        <source>过滤:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1837"/>
        <source>全部</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1838"/>
        <source>原始路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1839"/>
        <source>替换路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1844"/>
        <source>过滤路径/OID...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1848"/>
        <source>仅显示变更</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1849"/>
        <source>仅OID查询失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1853"/>
        <source>清除</source>
        <translation type="unfinished">Borrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1991"/>
        <source>OID查询进度</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="1992"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2291"/>
        <source>正在查询替换后路径的OID，请稍候...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2016"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2333"/>
        <source>正在查询第 %1/%2 个路径的OID...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2051"/>
        <source>OID查询全部完成！共查询 %1 个路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2070"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2074"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2214"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2217"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2373"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2377"/>
        <source>查询异常</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2071"/>
        <source>OID查询过程中发生异常：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2075"/>
        <source>OID查询过程中发生未知异常</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2132"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2235"/>
        <source>处理进度</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2133"/>
        <source>正在批量查询OID...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2162"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2177"/>
        <source>正在查询第 %1/%2 批...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2171"/>
        <source>无法获取数据库连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2192"/>
        <source>批量查询失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2214"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2374"/>
        <source>处理过程中发生异常：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2217"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2378"/>
        <source>处理过程中发生未知异常</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_condition_replace.cpp" line="2290"/>
        <source>处理路径替换</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgCreateSymbolFile</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_create_symbol_file.ui" line="14"/>
        <source>图元属性</source>
        <translation type="unfinished">Atributos del icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_create_symbol_file.ui" line="20"/>
        <source>图元类别名称</source>
        <translation type="unfinished">Nombre del tipo de icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_create_symbol_file.ui" line="30"/>
        <source>图元所属类别</source>
        <translation type="unfinished">Tipo de icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_create_symbol_file.ui" line="40"/>
        <source>图元应用类别</source>
        <translation type="unfinished">Tipo de aplicación de los iconos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_create_symbol_file.ui" line="65"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_create_symbol_file.ui" line="72"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_create_symbol_file.cpp" line="102"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_create_symbol_file.cpp" line="102"/>
        <source>请输入图元类别名称</source>
        <translation type="unfinished">Ingrese nombre de categoría de elemento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_create_symbol_file.cpp" line="110"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_create_symbol_file.cpp" line="110"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgEditAppInfo</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_appinfo.ui" line="14"/>
        <source>应用定义</source>
        <translation type="unfinished">Definición de App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_appinfo.ui" line="20"/>
        <source>应用定义</source>
        <comment>toolName</comment>
        <translation type="unfinished">Definición de Aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_appinfo.ui" line="41"/>
        <source>增加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_appinfo.ui" line="48"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_appinfo.ui" line="58"/>
        <source>是否启用</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Habilitado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_appinfo.ui" line="63"/>
        <source>模板应用名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de la aplicación del modelo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_appinfo.ui" line="68"/>
        <source>模板库名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de la BD del modelo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_appinfo.ui" line="94"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_appinfo.ui" line="101"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
</context>
<context>
    <name>DlgEditPlaneProperty</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_plane_property.ui" line="14"/>
        <source>层定义</source>
        <translation type="unfinished">Definir capa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_plane_property.ui" line="22"/>
        <source>模板应用名：</source>
        <translation type="unfinished">Nombre de app:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_plane_property.ui" line="34"/>
        <source>层配置</source>
        <translation type="unfinished">Configuración de capa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_plane_property.ui" line="55"/>
        <source>添加</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Agregar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_plane_property.ui" line="62"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_plane_property.ui" line="72"/>
        <source>模板应用名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de la aplicación del modelo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_plane_property.ui" line="77"/>
        <source>层名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de la capa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_plane_property.ui" line="82"/>
        <source>应用名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_plane_property.ui" line="87"/>
        <source>数据库名</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Nombre de la BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_plane_property.ui" line="92"/>
        <source>是否基础层</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Siendo la capa base</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_plane_property.ui" line="97"/>
        <source>是否有效</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Válido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_plane_property.ui" line="123"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_edit_plane_property.ui" line="130"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>DlgIconAttrEdit</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="14"/>
        <source>图元属性</source>
        <translation type="unfinished">Atributos del icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1158"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="70"/>
        <source>测点配置</source>
        <translation type="unfinished">Configuración de puntos de medición</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="113"/>
        <source>基本信息</source>
        <translation type="unfinished">Información básica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="119"/>
        <source>图元类型</source>
        <translation type="unfinished">Tipo de icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="136"/>
        <source>所属类型</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="143"/>
        <source>图元名称</source>
        <translation type="unfinished">Nombre del icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="153"/>
        <source>是否在监视工具中保留原电压等级颜色</source>
        <translation type="unfinished">¿Mantener el color original del nivel de voltaje en la herramienta de monitoreo?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="156"/>
        <source>是否保留图元实例化原色</source>
        <translation type="unfinished">¿Retener los colores primarios instanciados del icono?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="166"/>
        <source>图元大小</source>
        <translation type="unfinished">Tamaño del icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="187"/>
        <source>图元宽度</source>
        <translation type="unfinished">Ancho del icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="194"/>
        <source>图元高度</source>
        <translation type="unfinished">Altura del icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="221"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="234"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="250"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="263"/>
        <source>功能暂不可用</source>
        <translation type="unfinished">La función aún no está disponible</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="224"/>
        <source>真实高度</source>
        <translation type="unfinished">Altura real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="253"/>
        <source>真实宽度</source>
        <translation type="unfinished">Ancho real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="293"/>
        <source>应用：</source>
        <translation type="unfinished">Aplicación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="303"/>
        <source>库名：</source>
        <translation type="unfinished">Nombre de la base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="313"/>
        <source>实例号：</source>
        <translation type="unfinished">Número de instancia:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="327"/>
        <source>域ID：</source>
        <translation type="unfinished">ID de dominio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="337"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="771"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="915"/>
        <source>域检索</source>
        <translation type="unfinished">Búsqueda de dominio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="348"/>
        <source>条件：</source>
        <translation type="unfinished">Condición:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="358"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="764"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="908"/>
        <source>清除</source>
        <translation type="unfinished">Borrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="37"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="44"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="51"/>
        <source>帮助</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Ayuda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="64"/>
        <source>基本属性</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Atributos Básicos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="91"/>
        <source>添加测点+</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Agregar punto de medición +</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="98"/>
        <source>删除测点-</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Eliminar punto -</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="282"/>
        <source>数据配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Datos de Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="368"/>
        <source>决策配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="374"/>
        <source>配置模板</source>
        <translation type="unfinished">Plantillas de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="382"/>
        <source>应用:</source>
        <translation type="unfinished">Aplicación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="389"/>
        <source>...</source>
        <translation type="unfinished">…</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="406"/>
        <source>库名:</source>
        <translation type="unfinished">Nombre de la base de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="413"/>
        <source>应用路径:</source>
        <translation type="unfinished">Ruta de la aplicación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="429"/>
        <source>作图属性</source>
        <translation type="unfinished">Atributos de dibujo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="448"/>
        <source>根据上述应用路径进行属性的解析，并生成默认配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="451"/>
        <source>根据应用路径初始化</source>
        <translation type="unfinished">Iniciar por Ruta de la Aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="459"/>
        <source>表名</source>
        <translation type="unfinished">Nombre de la tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="464"/>
        <source>域名</source>
        <translation type="unfinished">Nombre del campo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="469"/>
        <source>通配符</source>
        <translation type="unfinished">Comodín</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="474"/>
        <source>作图属性名</source>
        <translation type="unfinished">Nombre de atributo gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="479"/>
        <source>作图属性类型</source>
        <translation type="unfinished">Tipo de atributos gráficos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="484"/>
        <source>作图存储字段名</source>
        <translation type="unfinished">Nombres de los campos que almacenan la imagen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="498"/>
        <source>操作提示</source>
        <translation type="unfinished">Indicaciones de operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="506"/>
        <source>决策前景定义</source>
        <translation type="unfinished">Primer plano de decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="512"/>
        <source>图元决策</source>
        <translation type="unfinished">Decisión de iconos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="520"/>
        <source>颜色决策</source>
        <translation type="unfinished">Decisión de color</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="534"/>
        <source>符号决策</source>
        <translation type="unfinished">Decisión de símbolo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="548"/>
        <source>闪烁决策</source>
        <translation type="unfinished">Decisión de parpadeo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="563"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="781"/>
        <source>前景定义</source>
        <translation type="unfinished">Definición del primer plano</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="573"/>
        <source>+数值前景</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="580"/>
        <source>+状态前景</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="587"/>
        <source>-删除前景</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="596"/>
        <source>&gt; 前景预览    </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="643"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="657"/>
        <source>注意提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="669"/>
        <source>配置汇总</source>
        <translation type="unfinished">Resumen de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="677"/>
        <source>所有应用下的属性合集</source>
        <translation type="unfinished">Colección de atributos de todas las aplicaciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="680"/>
        <source>属性汇总</source>
        <translation type="unfinished">Resumen de los atributos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="690"/>
        <source>所有应用下的属性合集值</source>
        <translation type="unfinished">Valor de colección de atributos para todas las aplicaciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="699"/>
        <source>所有应用的配置信息汇总</source>
        <translation type="unfinished">Resumen de la información de configuración de todas las aplicaciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="703"/>
        <source>库名</source>
        <translation type="unfinished">Nombre de la base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="708"/>
        <source>配置类型</source>
        <translation type="unfinished">Tipo de configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="713"/>
        <source>配置内容</source>
        <translation type="unfinished">Contenido de la configuración</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="725"/>
        <source>标签配置</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Etiqueta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="731"/>
        <source>标签属性</source>
        <translation type="unfinished">Atributos de etiqueta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="745"/>
        <source>是否启用标签</source>
        <translation type="unfinished">¿Habilitar etiqueta?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="754"/>
        <source>文本取值域:</source>
        <translation type="unfinished">Dominio valor texto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="795"/>
        <source>文本样式：</source>
        <translation type="unfinished">Estilo de texto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="809"/>
        <source>竖排</source>
        <translation type="unfinished">Vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="816"/>
        <source>加粗</source>
        <translation type="unfinished">Negrita</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="829"/>
        <source>字体类型：</source>
        <translation type="unfinished">Tipo de fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="843"/>
        <source>字体大小：</source>
        <translation type="unfinished">Tamaño de fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="857"/>
        <source>字体颜色：</source>
        <translation type="unfinished">Color de fuente:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="864"/>
        <source>字体颜色</source>
        <translation type="unfinished">Color de fuente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="875"/>
        <source>标签位置：</source>
        <translation type="unfinished">Posición de etiqueta:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="889"/>
        <source>是否带前缀</source>
        <translation type="unfinished">¿Con prefijo?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.ui" line="898"/>
        <source>前缀取值域：</source>
        <translation type="unfinished">Dominio valor prefijo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="114"/>
        <source>此处建议应用路径发生变更后需要点击右侧恢复默认按钮，能够自动根据路径进行内容解析并生成默认配置方案</source>
        <translation type="unfinished">Se recomienda que después de cambiar la ruta de la aplicación, haga clic en el botón restaurar por defecto a la derecha para analizar automáticamente el contenido según la ruta y generar un plan de configuración por defecto.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="117"/>
        <source>注意：图元发生属性和决策修改，建议重启图形监视工具查看新的效果生效</source>
        <translation type="unfinished">Nota: Si los atributos y decisiones del icono son modificados, se recomienda reiniciar la herramienta de monitoreo del gráfico para que los nuevos efectos tengan efecto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="412"/>
        <source>标识</source>
        <translation type="unfinished">ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="413"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="414"/>
        <source>名称</source>
        <translation type="unfinished">Nombre</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="415"/>
        <source>别名</source>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="757"/>
        <source>应用路径</source>
        <translation type="unfinished">Ruta de la aplicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="765"/>
        <source>决策定义</source>
        <translation type="unfinished">Decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="809"/>
        <source>图元名称不能为空，请重新输入！</source>
        <translation type="unfinished">¡El nombre del icono no puede estar vacío, por favor ingréselo nuevamente!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="809"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="825"/>
        <source>创建图元失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="814"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="814"/>
        <source>图元名称不可使用内部路径名</source>
        <translation type="unfinished">Nombre icono no usa rutas internas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="825"/>
        <source>图元名称已存在，请重新输入！</source>
        <translation type="unfinished">¡El nombre del icono ya existe, por favor ingréselo nuevamente!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1158"/>
        <source>改变应用是否保存当前应用数据?</source>
        <translation type="unfinished">¿Desea guardar los datos actuales de la aplicación cuando cambie la aplicación?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1282"/>
        <source>测点名</source>
        <translation type="unfinished">Nombre del punto de medición</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1286"/>
        <source>测点别名</source>
        <translation type="unfinished">Alias de estación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1315"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1323"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1376"/>
        <source>请链接数据库</source>
        <translation type="unfinished">Por favor, vincule con la base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1315"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1323"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1376"/>
        <source>数据库未连接,请连接数据库</source>
        <translation type="unfinished">La base de datos no está conectada. Por favor, conéctese a la base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1394"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1527"/>
        <source>字符串</source>
        <translation type="unfinished">Cadena</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1527"/>
        <source>电压等级</source>
        <translation type="unfinished">Nivel de tensión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1624"/>
        <source>中对齐</source>
        <translation type="unfinished">Alineación centro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1625"/>
        <source>左对齐</source>
        <translation type="unfinished">Alineación izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1626"/>
        <source>右对齐</source>
        <translation type="unfinished">Alineación derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1627"/>
        <source>上对齐</source>
        <translation type="unfinished">Alineación arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1628"/>
        <source>下对齐</source>
        <translation type="unfinished">Alineación abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1638"/>
        <source>中间</source>
        <translation type="unfinished">Medio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1639"/>
        <source>上方</source>
        <translation type="unfinished">Arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1640"/>
        <source>下方</source>
        <translation type="unfinished">Abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1641"/>
        <source>左方</source>
        <translation type="unfinished">Izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1642"/>
        <source>右方</source>
        <translation type="unfinished">Derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1771"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1771"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1795"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1806"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1815"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1821"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1795"/>
        <source>数据配置的标签表名与数值取值域的表不一致</source>
        <translation type="unfinished">El nombre de la tabla de etiquetas de la configuración de datos no coincide con la tabla en el campo de valor numérico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1806"/>
        <source>数据配置的条件库与标签文本取值库不一致</source>
        <translation type="unfinished">La biblioteca de condiciones para la configuración de datos es inconsistente con la biblioteca de valores de texto de la etiqueta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1815"/>
        <source>数据配置的条件表名与标签文本取值域的表不一致</source>
        <translation type="unfinished">Tabla de condición difiere de dominio de texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_icon_attr_edit.cpp" line="1821"/>
        <source>数据配置的条件表名与数值取值域的表不一致</source>
        <translation type="unfinished">Tabla de condición difiere de dominio numérico</translation>
    </message>
</context>
<context>
    <name>DlgModifyField</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_modify_field.ui" line="14"/>
        <source>区域修改</source>
        <translation type="unfinished">Modificación de zona</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_modify_field.ui" line="22"/>
        <source>原始区域：</source>
        <translation type="unfinished">Área original:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_modify_field.ui" line="40"/>
        <source>目标区域：</source>
        <translation type="unfinished">Área de destino:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_modify_field.ui" line="67"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_modify_field.ui" line="74"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>DlgModifyStatus</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_modify_status.ui" line="14"/>
        <source>修改当前状态</source>
        <comment>internal</comment>
        <translation type="unfinished">Editar estado actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_modify_status.ui" line="22"/>
        <source>原始态：</source>
        <translation type="unfinished">Estado original:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_modify_status.ui" line="40"/>
        <source>目标态：</source>
        <translation type="unfinished">Estado de destino:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_modify_status.ui" line="54"/>
        <source>态值：</source>
        <translation type="unfinished">Valor de estado:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_modify_status.ui" line="91"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/element/dlg_modify_status.ui" line="98"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>DlgSaveAsIconItem</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_iconitem.ui" line="22"/>
        <source>图元名：</source>
        <translation type="unfinished">Nombre del icono:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_iconitem.ui" line="65"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_iconitem.ui" line="72"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_iconitem.cpp" line="53"/>
        <source>图元选择</source>
        <translation type="unfinished">Seleccionar icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_iconitem.cpp" line="82"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_iconitem.cpp" line="82"/>
        <source>请选择一个目录</source>
        <translation type="unfinished">Por favor, seleccione un directorio</translation>
    </message>
</context>
<context>
    <name>DlgSaveAsItem</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_item.ui" line="22"/>
        <source>画面名:</source>
        <translation type="unfinished">Nombre del gráfico:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_item.ui" line="65"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_item.ui" line="72"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_item.cpp" line="24"/>
        <source>文件选择</source>
        <translation type="unfinished">Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_item.cpp" line="62"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_item.cpp" line="62"/>
        <source>画面名称重复</source>
        <translation type="unfinished">Nombre de gráfico duplicado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_item.cpp" line="69"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_item.cpp" line="75"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_item.cpp" line="81"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_item.cpp" line="69"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_item.cpp" line="75"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/edit/dlg_saveas_item.cpp" line="81"/>
        <source>未找到正确的画面类型</source>
        <translation type="unfinished">No se encontró el tipo de gráfico correcto</translation>
    </message>
</context>
<context>
    <name>IconBtn</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="105"/>
        <source>加入常用图元</source>
        <translation type="unfinished">Agregar iconos comunes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="119"/>
        <source>移出常用图元</source>
        <translation type="unfinished">Eliminar iconos comunes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="275"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="392"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="431"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="514"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="553"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="565"/>
        <source>提示</source>
        <translation type="unfinished">Consejo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="276"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="554"/>
        <source>图元文件不存在</source>
        <translation type="unfinished">Archivo de figura no existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="392"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="431"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="514"/>
        <source>前景指针为空</source>
        <translation type="unfinished">Puntero de primer plano vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="410"/>
        <source>属性配置: %1 %2</source>
        <comment>toolName</comment>
        <translation type="unfinished">Config de Propiedad: %1 %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="418"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="457"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="500"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="540"/>
        <source>属性配置: %1</source>
        <comment>toolName</comment>
        <translation type="unfinished">Config de Propiedad: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="449"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="492"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="532"/>
        <source>属性配置: %1 %2</source>
        <translation type="unfinished">Configuración de propiedad: %1 %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_button.cpp" line="565"/>
        <source>图元指针为空</source>
        <translation type="unfinished">Puntero de figura vacío</translation>
    </message>
</context>
<context>
    <name>IconDock</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_dock.cpp" line="23"/>
        <source>图元列表页</source>
        <comment>toolName</comment>
        <translation type="unfinished">Lista de Iconos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_dock.cpp" line="79"/>
        <source>正在读取图元...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_dock.cpp" line="79"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_dock.cpp" line="80"/>
        <source>加载图元</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_dock.cpp" line="93"/>
        <source>正在读取图元: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_dock.cpp" line="93"/>
        <source>进度: %1/%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_dock.cpp" line="113"/>
        <source>读取图元出错</source>
        <translation type="unfinished">Error al leer figuras</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_dock.cpp" line="124"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_dock.cpp" line="124"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_dock.cpp" line="130"/>
        <source>图元文件[%1]读取出错</source>
        <translation type="unfinished">Error al leer archivo de figura [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_dock.cpp" line="145"/>
        <source>间隔模板</source>
        <translation type="unfinished">Intervalo temporal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_dock.cpp" line="326"/>
        <source>快捷图元</source>
        <translation type="unfinished">Iconos de acceso directo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_dock.cpp" line="464"/>
        <source>动态库图元</source>
        <translation type="unfinished">Iconos de base de datos dinámica</translation>
    </message>
</context>
<context>
    <name>IconDockCo</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1149"/>
        <source>图元库</source>
        <comment>toolName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1604"/>
        <source>正在读取图元...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1604"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1605"/>
        <source>加载图元</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1618"/>
        <source>正在读取图元: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1618"/>
        <source>进度: %1/%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1639"/>
        <source>读取图元出错</source>
        <translation type="unfinished">Error al leer figuras</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1650"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1650"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1655"/>
        <source>图元文件[%1]读取出错</source>
        <translation type="unfinished">Error al leer archivo de figura [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1669"/>
        <source>图元类型指针为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1673"/>
        <source>间隔模板</source>
        <translation type="unfinished">Intervalo temporal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1686"/>
        <source>添加图元失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1722"/>
        <source>添加插件失败</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IconItemButton</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="160"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="195"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="255"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="287"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="372"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="380"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="160"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="195"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="255"/>
        <source>前景指针为空</source>
        <translation type="unfinished">Puntero de primer plano vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="172"/>
        <source>属性配置: %1 %2</source>
        <comment>toolName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="180"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="215"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="240"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="275"/>
        <source>属性配置: %1</source>
        <comment>toolName</comment>
        <translation type="unfinished">Config de Propiedad: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="207"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="232"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="267"/>
        <source>属性配置: %1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="287"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="372"/>
        <source>图元文件不存在</source>
        <translation type="unfinished">Archivo de figura no existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="380"/>
        <source>图元指针为空</source>
        <translation type="unfinished">Puntero de figura vacío</translation>
    </message>
</context>
<context>
    <name>IconListTab</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_tabwidget.cpp" line="11"/>
        <source>图元列表页</source>
        <comment>toolName</comment>
        <translation type="unfinished">Lista de Iconos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_tabwidget.cpp" line="14"/>
        <source>常用</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Uso Común</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_tabwidget.cpp" line="24"/>
        <source>图元</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_tabwidget.cpp" line="34"/>
        <source>插件</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Complementos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/icon_tabwidget.cpp" line="38"/>
        <source>模板</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Modelo</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="232"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="562"/>
        <source>%1 没有此工具的打开权限</source>
        <translation type="unfinished">%1 sin permiso para abrir esta herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="233"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="563"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2822"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2998"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3079"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3090"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3101"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3112"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3216"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3296"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3382"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3435"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3439"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3443"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3447"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3460"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3522"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3526"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3958"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3967"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3985"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4006"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4144"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4149"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4162"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4250"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4280"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4317"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4732"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4808"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4888"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5086"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5096"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5242"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5316"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5480"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5485"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5490"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5495"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5819"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5864"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5948"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5953"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6317"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6514"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6640"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6644"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6676"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6690"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6763"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6816"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6827"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6902"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6912"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6916"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6990"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7001"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7082"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7137"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7177"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7296"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7449"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7531"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7716"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7721"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7842"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="8013"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="9036"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="9624"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11192"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11232"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11309"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11388"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11400"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11494"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11550"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11558"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11590"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12804"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12820"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12854"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12870"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12877"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13932"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13948"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14422"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14452"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14761"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14776"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14790"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14797"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14811"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14891"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14986"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15101"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15105"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15184"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15338"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15342"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15399"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15436"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15490"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15820"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15825"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="16646"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="17400"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="17415"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="17440"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="531"/>
        <source> 登录时限：</source>
        <translation type="unfinished">Límite de tiempo de login:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="661"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="764"/>
        <source>图元字典</source>
        <translation type="unfinished">Diccionario de iconos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="693"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="863"/>
        <source>异常输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="693"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="863"/>
        <source>查询数据异常，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="821"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="828"/>
        <source>画面字典</source>
        <translation type="unfinished">Diccionario de gráficos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1057"/>
        <source>模板字典</source>
        <translation type="unfinished">Diccionario de plantillas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1080"/>
        <source>设备列表</source>
        <translation type="unfinished">Lista de dispositivos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1090"/>
        <source>元素插入</source>
        <translation type="unfinished">Insertar elemento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1099"/>
        <source>基本</source>
        <translation type="unfinished">Básico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1114"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1685"/>
        <source>直线</source>
        <translation type="unfinished">Línea recta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1124"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1687"/>
        <source>矩形</source>
        <translation type="unfinished">Rectángulo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1133"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1689"/>
        <source>椭圆</source>
        <translation type="unfinished">Elipse</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1142"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1691"/>
        <source>圆形</source>
        <translation type="unfinished">Redondo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1151"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1693"/>
        <source>弧线</source>
        <translation type="unfinished">Arco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1160"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1695"/>
        <source>多边形</source>
        <translation type="unfinished">Polígono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1169"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1697"/>
        <source>折线</source>
        <translation type="unfinished">Línea rota</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1178"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1699"/>
        <source>图片</source>
        <translation type="unfinished">Imagen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1187"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1701"/>
        <source>文字</source>
        <translation type="unfinished">Texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1196"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1703"/>
        <source>连接点</source>
        <translation type="unfinished">Puntos conectados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1205"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1705"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1884"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="16509"/>
        <source>状态前景</source>
        <translation type="unfinished">Estado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1214"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1707"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1882"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="16540"/>
        <source>数值前景</source>
        <translation type="unfinished">Número</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1223"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1709"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1886"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="16571"/>
        <source>字符前景</source>
        <translation type="unfinished">Carácter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1543"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1731"/>
        <source>新建</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1544"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1732"/>
        <source>打开</source>
        <translation type="unfinished">Abrir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1545"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1733"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1546"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1734"/>
        <source>另存为</source>
        <translation type="unfinished">Guardar como</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1547"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1802"/>
        <source>退出</source>
        <translation type="unfinished">Salir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1549"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1804"/>
        <source>导入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1551"/>
        <source>导入图元</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1556"/>
        <source>导出图元</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1560"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1562"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1809"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1811"/>
        <source>撤销</source>
        <translation type="unfinished">Deshacer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1561"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1563"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1810"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1812"/>
        <source>恢复</source>
        <translation type="unfinished">Recuperar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1564"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1813"/>
        <source>剪切</source>
        <translation type="unfinished">Cortar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1565"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1814"/>
        <source>复制</source>
        <translation type="unfinished">Copiar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1566"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1815"/>
        <source>粘贴</source>
        <translation type="unfinished">Pegar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1567"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1816"/>
        <source>删除</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1568"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1683"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1835"/>
        <source>选择</source>
        <translation type="unfinished">Seleccionar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1570"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1837"/>
        <source>平移</source>
        <translation type="unfinished">Traducir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1572"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1839"/>
        <source>全选</source>
        <translation type="unfinished">Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1573"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1840"/>
        <source>文字格式</source>
        <translation type="unfinished">Formato de texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1577"/>
        <source>刷新</source>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1578"/>
        <source>缩小</source>
        <translation type="unfinished">Alejar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1579"/>
        <source>放大</source>
        <translation type="unfinished">Ampliar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1580"/>
        <source>重置缩放</source>
        <translation type="unfinished">Restablecer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1581"/>
        <source>全屏</source>
        <translation type="unfinished">Pantalla completa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1582"/>
        <source>满屏</source>
        <translation type="unfinished">Ajustar a pantalla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1583"/>
        <source>网格</source>
        <translation type="unfinished">Rejilla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1585"/>
        <source>标尺</source>
        <translation type="unfinished">Personal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1587"/>
        <source>同类元素</source>
        <translation type="unfinished">Elementos Similares</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1589"/>
        <source>层叠</source>
        <translation type="unfinished">apilar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1591"/>
        <source>置于顶层</source>
        <translation type="unfinished">Mover al top</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1593"/>
        <source>置于底层</source>
        <translation type="unfinished">Mover al fondo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1595"/>
        <source>上移一层</source>
        <translation type="unfinished">Subir un nivel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1597"/>
        <source>下移一层</source>
        <translation type="unfinished">Mover hacia atrás</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1608"/>
        <source>对齐</source>
        <translation type="unfinished">Alinear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1610"/>
        <source>左对齐</source>
        <translation type="unfinished">Alinear a la izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1612"/>
        <source>右对齐</source>
        <translation type="unfinished">Alinear a la derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1614"/>
        <source>垂直居中</source>
        <translation type="unfinished">Centro vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1616"/>
        <source>水平居中</source>
        <translation type="unfinished">Centro horizontal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1618"/>
        <source>顶对齐</source>
        <translation type="unfinished">Alinear arriba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1620"/>
        <source>底对齐</source>
        <translation type="unfinished">Alinear abajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1623"/>
        <source>纵向分布</source>
        <translation type="unfinished">Distribución vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1625"/>
        <source>横向分布</source>
        <translation type="unfinished">Distribución horizontal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1638"/>
        <source>缩放</source>
        <translation type="unfinished">Zoom</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1640"/>
        <source>同宽缩放</source>
        <translation type="unfinished">Escala de ancho uniforme</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1642"/>
        <source>同高缩放</source>
        <translation type="unfinished">Escala de altura igual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1644"/>
        <source>同等缩放</source>
        <translation type="unfinished">Escala igual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1656"/>
        <source>旋转</source>
        <translation type="unfinished">rotar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1658"/>
        <source>左转90度</source>
        <translation type="unfinished">Girar a la izquierda 90 grados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1660"/>
        <source>右转90度</source>
        <translation type="unfinished">Girar a la derecha 90 grados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1663"/>
        <source>左转15度</source>
        <translation type="unfinished">Girar a la izquierda 15 grados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1665"/>
        <source>右转15度</source>
        <translation type="unfinished">Girar a la derecha 15 grados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1668"/>
        <source>垂直翻转</source>
        <translation type="unfinished">Voltear vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1670"/>
        <source>水平翻转</source>
        <translation type="unfinished">Volteo horizontal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1712"/>
        <source>默认旋转</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1714"/>
        <source>垂直旋转</source>
        <translation type="unfinished">Rotación vertical</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1718"/>
        <source>属性编辑</source>
        <translation type="unfinished">Editar atributos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1720"/>
        <source>全图元发布</source>
        <translation type="unfinished">Publicar todos los iconos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1721"/>
        <source>全部保存</source>
        <translation type="unfinished">Guardar todo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1737"/>
        <source>全画面发布</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1746"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6707"/>
        <source>导出翻译词条</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1767"/>
        <source>导出所有G文件(2011规范)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1769"/>
        <source>导出指定G文件(2011规范)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1771"/>
        <source>导出所有G文件(2013规范)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1773"/>
        <source>导出指定G文件(2013规范)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1775"/>
        <source>导出所有G文件(2016规范)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1777"/>
        <source>导出指定G文件(2016规范)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1782"/>
        <source>导出画面</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1806"/>
        <source>导入画面</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3967"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14790"/>
        <source>导入成功！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4888"/>
        <source>请关闭除当前画面之外的其余画面！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6536"/>
        <source>画面发布进度</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6543"/>
        <source>正在发布画面，当前进度: %1/%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6676"/>
        <source>删除画面类型以及该画面类型下所有目录以及画面前请先关闭所有画面</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6690"/>
        <source>删除画面应用以及该画面应用下所有目录以及画面前请先关闭所有画面</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6720"/>
        <source>词条文件导出成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6725"/>
        <source>请打开需要导出翻译词条的画面</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="9698"/>
        <source>只能选择一个图元进行旋转操作！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="9708"/>
        <source>表格图元不支持旋转操作！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="9713"/>
        <source>表格子元素不支持旋转操作！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11000"/>
        <source>图层：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11018"/>
        <source>未知元素类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11309"/>
        <source>至少保留一个状态</source>
        <comment>internal</comment>
        <translation type="unfinished">Mantener al menos un estado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11314"/>
        <source>此操作将导致该状态[%1]下的所有图形被删除，是否继续</source>
        <comment>internal</comment>
        <translation type="unfinished">Esta operación causará que todas las gráficas en este estado [%1] sean eliminados. Desea continuar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11388"/>
        <source>状态名称不能为空</source>
        <comment>internal</comment>
        <translation type="unfinished">Nombre de estado no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11400"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11558"/>
        <source>状态名称重复</source>
        <comment>internal</comment>
        <translation type="unfinished">Nombre de estado repetido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11550"/>
        <source>态名不能为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12804"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12820"/>
        <source>动态模板不支持该功能</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12878"/>
        <source>请先选择包含条件路径的图元</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12879"/>
        <source>支持的图元类型：设备、母线、数值前景、状态前景、字符前景、光敏点、二维表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12959"/>
        <source>选中区域有二维表子元素，不参与条件替换。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12960"/>
        <source>请选择包含完整二维表的区域进行条件替换。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14761"/>
        <source>删除图元类型以及该图元类型下的所有图元请先关闭所有已打开的图元！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14999"/>
        <source>正在发布图元，当前进度: %1/%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15095"/>
        <source>图元[%1]缩略图上传失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15099"/>
        <source>图元[%1]上传失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15101"/>
        <source>全图元发布失败,原因：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15105"/>
        <source>全图元发布失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15184"/>
        <source>所有图元发布成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15399"/>
        <source>未检测到需要清除的草稿</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15405"/>
        <source>清除草稿将放弃当前所有未发布的更改，是否继续</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15436"/>
        <source>进行清除草稿操作请先关闭所有已打开的图元</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15444"/>
        <source>图元清除草稿进度</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15449"/>
        <source>正在清除图元草稿，当前进度: %1/%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15490"/>
        <source>所有图元清除草稿成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="16646"/>
        <source>常驻检索器不支持二维表子元素的检索关联</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="17400"/>
        <source>超出图元限制总个数:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="17415"/>
        <source>打开画面限制总个数:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="17440"/>
        <source>超出画面限制总个数:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1725"/>
        <source>关于</source>
        <translation type="unfinished">Acerca de</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1735"/>
        <source>发布</source>
        <translation type="unfinished">Publicar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1738"/>
        <source>预览</source>
        <translation type="unfinished">Vista previa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1740"/>
        <source>填库</source>
        <translation type="unfinished">Escribir en DB</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1748"/>
        <source>自动成图</source>
        <translation type="unfinished">Imagen automática</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1762"/>
        <source>打印</source>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1554"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1765"/>
        <source>导出</source>
        <translation type="unfinished">Exportar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1779"/>
        <source>导出CIME文件</source>
        <translation type="unfinished">Exportar archivo CIME</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1785"/>
        <source>导入G文件</source>
        <translation type="unfinished">Importar archivo G</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1792"/>
        <source>导出SVG文件</source>
        <translation type="unfinished">Exportar archivo SVG</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1795"/>
        <source>导入SVG文件</source>
        <translation type="unfinished">Importar archivo SVG</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1817"/>
        <source>组合</source>
        <translation type="unfinished">Habilitar casilla de verificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1826"/>
        <source>撤销组合</source>
        <translation type="unfinished">Deshacer grupo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1846"/>
        <source>柱状图</source>
        <translation type="unfinished">Gráfico de barras</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1865"/>
        <source>动态表格</source>
        <translation type="unfinished">Tabla dinámica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1868"/>
        <source>曲线</source>
        <translation type="unfinished">Curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1872"/>
        <source>饼图</source>
        <translation type="unfinished">Gráfico de pastel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1874"/>
        <source>进度条</source>
        <translation type="unfinished">Barra de progreso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1876"/>
        <source>环形图</source>
        <translation type="unfinished">Gráfico en anillo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1878"/>
        <source>仪表盘</source>
        <translation type="unfinished">Tablero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1880"/>
        <source>电池</source>
        <translation type="unfinished">Batería</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1888"/>
        <source>光敏点</source>
        <translation type="unfinished">Punto fotosensible</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1892"/>
        <source>重载</source>
        <translation type="unfinished">Sobrecarga</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1910"/>
        <source>显示连接</source>
        <translation type="unfinished">Mostrar conexión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1896"/>
        <source>操作锁定</source>
        <translation type="unfinished">Bloqueo de operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1898"/>
        <source>操作取消</source>
        <translation type="unfinished">Cancelar operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1900"/>
        <source>拖拽</source>
        <translation type="unfinished">Arrastrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1902"/>
        <source>获取OID</source>
        <translation type="unfinished">Obtener OID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1904"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12837"/>
        <source>文本替换</source>
        <translation type="unfinished">Reemplazo de texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1013"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1907"/>
        <source>常驻检索器</source>
        <translation type="unfinished">Recuperador residente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1723"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1909"/>
        <source>正确性检查</source>
        <translation type="unfinished">Verificación de corrección</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1923"/>
        <source>电压等级</source>
        <translation type="unfinished">Nivel de tensión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1925"/>
        <source>决策定义</source>
        <translation type="unfinished">Decisión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1926"/>
        <source>画面属性</source>
        <translation type="unfinished">Atributos del gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1928"/>
        <source>图元显示</source>
        <translation type="unfinished">Mostrar icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1930"/>
        <source>模板属性</source>
        <translation type="unfinished">Atributos de la plantilla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1932"/>
        <source>应用和库</source>
        <translation type="unfinished">App y base de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1934"/>
        <source>应用设置</source>
        <translation type="unfinished">Configuraciones de la App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1935"/>
        <source>平面设置</source>
        <translation type="unfinished">Configuraciones del plano</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1937"/>
        <source>信号与槽</source>
        <translation type="unfinished">Señal y ranura</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2351"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6720"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6725"/>
        <source>信息</source>
        <translation type="unfinished">Mensaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2351"/>
        <source>版本:V1.0</source>
        <translation type="unfinished">Versión: V1.0</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2468"/>
        <source>图元模式</source>
        <translation type="unfinished">Modo de Icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2469"/>
        <source>作图模式</source>
        <translation type="unfinished">Modo de gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2604"/>
        <source>常用</source>
        <translation type="unfinished">Uso común</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2605"/>
        <source>无图标action</source>
        <translation type="unfinished">Sin acción de icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2606"/>
        <source>有图标action</source>
        <translation type="unfinished">Con acción de icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2780"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2835"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5198"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5330"/>
        <source>提示</source>
        <comment>toolName</comment>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2781"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2836"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5199"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5331"/>
        <source>是否删除</source>
        <translation type="unfinished">¿Eliminar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2822"/>
        <source>删除的目录不为空，请先将子对象全部删除</source>
        <translation type="unfinished">El directorio a eliminar no está vacío. Elimine primero todos los subobjetos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3296"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6101"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6348"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="17377"/>
        <source>发布失败</source>
        <translation type="unfinished">Publicación fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3382"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6075"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6317"/>
        <source>发布成功</source>
        <translation type="unfinished">Publicación exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5449"/>
        <source>修改画面类型</source>
        <comment>toolName</comment>
        <translation type="unfinished">Editar Tipo de Gráfica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4153"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5824"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5866"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7453"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7533"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15408"/>
        <source>是</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4154"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5826"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5868"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7454"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7535"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15409"/>
        <source>否</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3079"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3435"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5480"/>
        <source>文件服务调用失败</source>
        <translation type="unfinished">Fallo al llamar al servicio de archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="244"/>
        <source>图形设计工具(节点名:%1)</source>
        <comment>toolName</comment>
        <translation type="unfinished">Diseñador Gráfica (Nodo: %1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="657"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="763"/>
        <source>图元字典</source>
        <comment>toolName</comment>
        <translation type="unfinished">Diccionario de Iconos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="768"/>
        <source>图元字典(待发布)</source>
        <comment>toolName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="769"/>
        <source>图元字典(待发布)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="833"/>
        <source>画面</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Gráfica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1062"/>
        <source>模板</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Modelo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1113"/>
        <source>直线</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Línea recta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1123"/>
        <source>矩形</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Rectángulo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1132"/>
        <source>椭圆</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Elipse</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1141"/>
        <source>圆形</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Redondear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1150"/>
        <source>弧线</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Arco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1159"/>
        <source>多边形</source>
        <comment>buttonName</comment>
        <translation type="unfinished">polígono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1168"/>
        <source>折线</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Línea rota</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1177"/>
        <source>图片</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Imagen</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1186"/>
        <source>文字</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Texto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1195"/>
        <source>连接点</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Puntos conectados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1204"/>
        <source>状态前景</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Estado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1213"/>
        <source>数值前景</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1222"/>
        <source>字符前景</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Carácter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1241"/>
        <source>基本元素</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Icono básico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1243"/>
        <source>其他元素</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Otros iconos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1472"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1501"/>
        <source>文件</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1476"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1505"/>
        <source>编辑</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1480"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1509"/>
        <source>视图</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Ver</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1484"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1513"/>
        <source>插入</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Insertar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1488"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1521"/>
        <source>设置</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Configuraciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1517"/>
        <source>操作</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1525"/>
        <source>常用</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Uso común</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1722"/>
        <source>清除草稿</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1745"/>
        <source>重置图形关联</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1749"/>
        <source>清除历史</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1750"/>
        <source>刷新合成光字</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1849"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="16509"/>
        <source>合成光字牌</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1852"/>
        <source>静态表格</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1855"/>
        <source>网格框</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1861"/>
        <source>光字牌</source>
        <translation type="unfinished">Anunciador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1903"/>
        <source>获取路径</source>
        <translation type="unfinished">Obtener ruta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1905"/>
        <source>条件替换</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1918"/>
        <source>清除数据库连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1921"/>
        <source>生成标签</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2959"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2968"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7198"/>
        <source>(草稿)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="2998"/>
        <source>图元删除草稿成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3090"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3439"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3526"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5485"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6916"/>
        <source>插入失败</source>
        <translation type="unfinished">Inserción fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3101"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3443"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5490"/>
        <source>类型已存在</source>
        <translation type="unfinished">Tipo ya existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3112"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3447"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5495"/>
        <source>插入失败,请检查错误码</source>
        <translation type="unfinished">Inserción fallida, por favor revise el código de error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3215"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14890"/>
        <source>检查到图元存在草稿，发布后草稿将被删除，请选择发布方式</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3218"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14893"/>
        <source>发布草稿</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3220"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14895"/>
        <source>发布最新版</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3460"/>
        <source>打开图元限制总个数:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3522"/>
        <source>图元名称重复</source>
        <translation type="unfinished">Nombre de elemento repetido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3958"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3985"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4317"/>
        <source>当前存在已打开的画面，请先关闭所有已打开的画面！</source>
        <translation type="unfinished">Actualmente hay gráficas abiertas, ¡por favor cierre todas las gráficas abiertas primero!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4006"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14811"/>
        <source>导出成功！</source>
        <translation type="unfinished">¡Exportación exitosa!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4028"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6398"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14928"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15404"/>
        <source>警告</source>
        <comment>toolName</comment>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4029"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6399"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14929"/>
        <source>&apos;%1&apos; 已经被修改,是否保存</source>
        <translation type="unfinished">&apos;%1&apos; Ha Sido Modificado, ¿Guardar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4032"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6402"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14932"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4033"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6403"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14933"/>
        <source>放弃</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Abandonar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4034"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6404"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14934"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4144"/>
        <source>进行全部历史版本清除请先关闭所有已打开的画面</source>
        <translation type="unfinished">Para Borrar Versiones Históricas, Cerrar Todos Gráficos Abiertos Primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4150"/>
        <source>此操作将删除所有画面的历史版本，是否继续</source>
        <translation type="unfinished">Esta Operación Eliminará Todas Versiones Históricas del Gráfico. ¿Continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4162"/>
        <source>是否版本归零</source>
        <translation type="unfinished">¿Restablecer Versión a Cero?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4164"/>
        <source>归零</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Volver a cero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4166"/>
        <source>不归零</source>
        <comment>buttonName</comment>
        <translation type="unfinished">No Establecer a Cero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4254"/>
        <source>共有 %1 个画面归零失败:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4284"/>
        <source>共有 %1 个画面历史版本清除失败:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4628"/>
        <source>打开图元</source>
        <translation type="unfinished">Abrir iconos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4639"/>
        <source>打开画面</source>
        <translation type="unfinished">Abrir gráfico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4664"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11054"/>
        <source>载入文件</source>
        <translation type="unfinished">Cargar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4731"/>
        <source>检查到图元存在草稿，请选择要打开的版本</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4734"/>
        <source>最新版本</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Última versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4736"/>
        <source>草稿版本</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Versión de borrador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4808"/>
        <source>文件打开失败</source>
        <translation type="unfinished">Apertura de archivo falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5096"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12854"/>
        <source>请先打开一个画面</source>
        <translation type="unfinished">Abra un gráfica primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5242"/>
        <source>删除的目录不为空，删除失败</source>
        <translation type="unfinished">Directorio eliminado no vacío, fallo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5317"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7138"/>
        <source>画面已在节点：%1,进程号：%2,注册名：%3 中打开</source>
        <translation type="unfinished">El gráfico ya está abierto en el nodo: %1, PID: %2, NombreReg: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5820"/>
        <source>画面名已修改，是否替换相关光敏点跳转信息</source>
        <translation type="unfinished">El nombre de la gráfica ha sido modificado. Desea reemplazar la información de salto del punto fotosensible relevante</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5863"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7528"/>
        <source>检查到需要修改的画面：</source>
        <translation type="unfinished">Pantallas detectadas que necesitan modif.:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5863"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7530"/>
        <source>是否继续</source>
        <translation type="unfinished">¿Continuar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5923"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7652"/>
        <source>已修改的画面：</source>
        <translation type="unfinished">Pantallas modificadas:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5924"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7654"/>
        <source>请重新加载相关画面进行验证</source>
        <translation type="unfinished">Recargue pantalla para verificar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5946"/>
        <source>错误信息：</source>
        <translation type="unfinished">Info. de error:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5953"/>
        <source>暂无需要修改的画面</source>
        <translation type="unfinished">No hay pantallas por modificar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5988"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6162"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7257"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7262"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="17218"/>
        <source>(草稿版本)</source>
        <translation type="unfinished">(Versión borrador)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5992"/>
        <source>草稿版本正在被修改，暂不发布</source>
        <translation type="unfinished">La versión de borrador está siendo modificada y no se publicará temporalmente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5995"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6169"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="17225"/>
        <source>(最新版本)</source>
        <translation type="unfinished">(Última versión)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6025"/>
        <source>草稿版本不存在，跳过发布</source>
        <translation type="unfinished">La versión de borrador no existe, omitir publicación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6235"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6348"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6716"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6748"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="17279"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="17377"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6235"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="17279"/>
        <source>草稿版本不存在，发布失败</source>
        <translation type="unfinished">Borrador no existe, fallo al publicar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6649"/>
        <source>共有 %1 个画面发布失败:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6748"/>
        <source>画面已经打开，关闭后再操作</source>
        <translation type="unfinished">La gráfica ha sido abierta, ciérrala antes de operar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6763"/>
        <source>选择图元</source>
        <translation type="unfinished">Seleccionar figura</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6775"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6932"/>
        <source>另存为</source>
        <comment>toolName</comment>
        <translation type="unfinished">Guardar Como</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6777"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6945"/>
        <source>_副本</source>
        <translation type="unfinished">_copia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6816"/>
        <source>请选择正确的图元类型</source>
        <translation type="unfinished">Seleccione tipo de figura correcto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6827"/>
        <source>未找到正确的图元类型</source>
        <translation type="unfinished">No se encontró tipo de figura correcto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6902"/>
        <source>图元另存为拷贝失败</source>
        <translation type="unfinished">Fallo al guardar copia de elemento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6912"/>
        <source>图元重名，插入失败</source>
        <translation type="unfinished">Elemento duplicado, inserción falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6990"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7177"/>
        <source>请选择正确的画面类型</source>
        <translation type="unfinished">Seleccione tipo de pantalla correcto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7001"/>
        <source>未找到正确的画面类型</source>
        <translation type="unfinished">No se encontró tipo de pantalla correcto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7010"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="9698"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="9708"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="9713"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11293"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11315"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11595"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12958"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7010"/>
        <source>画面名称重复</source>
        <translation type="unfinished">Nombre de pantalla repetido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7037"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11228"/>
        <source>草稿版本</source>
        <translation type="unfinished">Versión de borrador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7082"/>
        <source>拷贝文件失败</source>
        <translation type="unfinished">Copia de archivo falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7296"/>
        <source>暂无激活的编辑窗口</source>
        <translation type="unfinished">No hay ventana de edición activa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7450"/>
        <source>图元名已修改，是否替换关联的图元名称</source>
        <translation type="unfinished">Nombre de elemento cambiado, ¿reemplazar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7520"/>
        <source>检查到需要修改的图元：</source>
        <translation type="unfinished">Figuras detectadas que necesitan modif.:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7644"/>
        <source>已修改的图元：</source>
        <translation type="unfinished">Elementos modificados:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7697"/>
        <source>图元错误信息：</source>
        <translation type="unfinished">Mensaje de error de figura:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7705"/>
        <source>画面错误信息：</source>
        <translation type="unfinished">Error en pantalla:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7721"/>
        <source>未找到需要修改的图元或画面</source>
        <translation type="unfinished">No se encontró figura o pantalla a modificar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7795"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7841"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="8011"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11076"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15335"/>
        <source>保存文件</source>
        <translation type="unfinished">Guardar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7842"/>
        <source>保存成功</source>
        <translation type="unfinished">Guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7773"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7850"/>
        <source>注意</source>
        <translation type="unfinished">Notificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7774"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7851"/>
        <source>保存为草稿</source>
        <translation type="unfinished">Guardar como borrador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4268"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4298"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6663"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7781"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7858"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7782"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7859"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4608"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4612"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7978"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7999"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="3222"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4168"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4738"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14897"/>
        <source>取消操作</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4250"/>
        <source>全部版本归零成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4265"/>
        <source>全部归零结果</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4280"/>
        <source>全部历史版本清除成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4295"/>
        <source>全部历史版本清除结果</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4325"/>
        <source>光字合成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4326"/>
        <source>正在准备...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4608"/>
        <source>启动光字合成失败：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4612"/>
        <source>启动光字合成失败：未知异常！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="5086"/>
        <source>重置连接关系完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6514"/>
        <source>进行所有画面发布请先关闭所有已打开的画面</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6640"/>
        <source>暂无需要发布的画面</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6644"/>
        <source>所有画面发布成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="6660"/>
        <source>全部发布结果</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7979"/>
        <source>当前版本[%1]与库中最新版本[%2]不一致,文件保存失败</source>
        <translation type="unfinished">Versión [%1] no coincide con [%2], guardado falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="7999"/>
        <source>文件保存失败</source>
        <translation type="unfinished">Guardado de archivo falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="8013"/>
        <source>文件保存成功</source>
        <translation type="unfinished">Archivo guardado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="8916"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="8924"/>
        <source>删除失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="8916"/>
        <source>不能同时删除表格子元素和其他元素，请先选择对应的表格或分别删除。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="8924"/>
        <source>不能单独删除表格子元素，请选择对应的表格进行删除。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="9037"/>
        <source>已跳过%1个无法单独删除的表格子元素。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="10616"/>
        <source>创建连接关系</source>
        <comment>toolName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="10768"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="10775"/>
        <source>剪切失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="10768"/>
        <source>不能同时剪切表格子元素和其他元素，请先选择对应的表格或分别剪切。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="10775"/>
        <source>不能单独剪切表格子元素，请选择对应的表格进行剪切。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11012"/>
        <source>路径: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11192"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11232"/>
        <source>文件已经打开并激活，是否需要编辑</source>
        <translation type="unfinished">Archivo abierto y activado, ¿editar?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11228"/>
        <source>最新版本</source>
        <translation type="unfinished">Última versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11228"/>
        <source>版本</source>
        <translation type="unfinished">Versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11293"/>
        <source>图元层数不能超过10</source>
        <translation type="unfinished">Capas de elemento no exceden 10</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11494"/>
        <source>区域名称重复</source>
        <translation type="unfinished">Nombre de área repetido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11590"/>
        <source>至少保留一个区域</source>
        <translation type="unfinished">Mantener al menos una área</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="11594"/>
        <source>此操作将导致该区域[%1]下的所有图形被删除，是否继续</source>
        <translation type="unfinished">Esta operación causará que todas las gráficas en el área [%1] sean eliminados. Desea continuar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12137"/>
        <source>关于 %1</source>
        <translation type="unfinished">Acerca de %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12139"/>
        <source>版本  %2</source>
        <translation type="unfinished">Versión %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12290"/>
        <source>图元态选择</source>
        <translation type="unfinished">Seleccione el estado del icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12292"/>
        <source>图元层选择</source>
        <translation type="unfinished">Seleccionar capa de icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12299"/>
        <source>+态</source>
        <translation type="unfinished">+ Estado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12300"/>
        <source>增加图元态</source>
        <translation type="unfinished">Agregar estado de icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12302"/>
        <source>+区域</source>
        <translation type="unfinished">+ Área</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12303"/>
        <source>增加图元区域</source>
        <translation type="unfinished">Agregar área de icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12305"/>
        <source>-态</source>
        <translation type="unfinished">- Estado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12306"/>
        <source>删除图元态</source>
        <translation type="unfinished">Eliminar estado del icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12308"/>
        <source>-区域</source>
        <translation type="unfinished">- Área</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12309"/>
        <source>删除图元区域</source>
        <translation type="unfinished">Eliminar área de icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12311"/>
        <source>修改态</source>
        <translation type="unfinished">Editar estado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12312"/>
        <source>修改图元态</source>
        <translation type="unfinished">Editar el estado del icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12314"/>
        <source>修改区域</source>
        <translation type="unfinished">Editar área</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12315"/>
        <source>修改图元区域</source>
        <translation type="unfinished">Editar área del icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12514"/>
        <source>应用选择</source>
        <translation type="unfinished">Seleccionar App</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12516"/>
        <source>层选择</source>
        <translation type="unfinished">Seleccionar capa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12871"/>
        <source>没有获取到条件路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="12892"/>
        <source>条件路径替换完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13496"/>
        <source>替换</source>
        <translation type="unfinished">Reemplazar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13496"/>
        <source>是否替换所有静态文本？</source>
        <translation type="unfinished">¿Reemplazar todo el texto estático?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13491"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13580"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13690"/>
        <source>未找到静态文本</source>
        <translation type="unfinished">No se encontró texto estático</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13491"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13552"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13580"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13655"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13690"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13767"/>
        <source>替换结果</source>
        <translation type="unfinished">Resultado de reemplazo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13552"/>
        <source>已完成搜索并进行了%1处替换</source>
        <translation type="unfinished">Búsqueda completada, %1 reemplazos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13655"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13767"/>
        <source>未找到下一个静态文本</source>
        <translation type="unfinished">No se encontró siguiente texto estático</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13932"/>
        <source>检索对象为空</source>
        <translation type="unfinished">Objeto de búsqueda vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="13948"/>
        <source>请先选中一个图元</source>
        <translation type="unfinished">Seleccione figura primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14422"/>
        <source>请先选中一个元素</source>
        <translation type="unfinished">Seleccionar Elemento Primero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14776"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14797"/>
        <source>当前存在已打开的图元，请先关闭所有已打开的图元！</source>
        <translation type="unfinished">Actualmente hay iconos abiertos, ¡por favor cierre todos los iconos abiertos primero!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14986"/>
        <source>进行全图元发布请先关闭所有已打开的图元</source>
        <translation type="unfinished">Por favor cierre todos los iconos abiertos antes de publicar todos los iconos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14994"/>
        <source>图元发布进度</source>
        <translation type="unfinished">Progreso de publicación de elemento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15338"/>
        <source>全部保存成功</source>
        <translation type="unfinished">Todos guardados con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15342"/>
        <source>%1保存失败</source>
        <translation type="unfinished">Fallo al guardar %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="1919"/>
        <source>清除高亮</source>
        <translation type="unfinished">Borrar resaltados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="14452"/>
        <source>请先打开文件选中一个元素</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15820"/>
        <source>请输入搜索内容</source>
        <translation type="unfinished">Ingrese el contenido de búsqueda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15825"/>
        <source>未找到相关内容</source>
        <translation type="unfinished">No se encontró contenido relevante</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="16502"/>
        <source>状态前景图元：%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="16533"/>
        <source>数值前景图元：%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="16564"/>
        <source>字符前景图元：%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="16599"/>
        <source>属性配置：%1 %2</source>
        <translation type="unfinished">Configuración de propiedad: %1 %2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="16513"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="16544"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="16575"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="16604"/>
        <source>属性配置：%1</source>
        <translation type="unfinished">Configuración de propiedad: %1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/commands.cpp" line="561"/>
        <source>元素 位置 (%1, %2)</source>
        <comment>gui_grapheditor::createCommandString</comment>
        <translation type="unfinished">Posición del elemento (%1, %2)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/commands.cpp" line="1561"/>
        <source>修改静态表格</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/commands.cpp" line="1583"/>
        <source>删除静态表格</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/commands.cpp" line="1603"/>
        <source>添加静态表格</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/commands.cpp" line="2099"/>
        <source>批量替换文本: %1 -&gt; %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/main.cpp" line="215"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/main.cpp" line="487"/>
        <source>%1 没有此工具的打开权限</source>
        <comment>gui_grapheditor::main</comment>
        <translation type="unfinished">%1 sin permiso para esta herramienta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/main.cpp" line="216"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/main.cpp" line="255"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/main.cpp" line="488"/>
        <source>提示</source>
        <comment>gui_grapheditor::main</comment>
        <translation type="unfinished">Consejo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/main.cpp" line="256"/>
        <source>注册失败</source>
        <comment>gui_grapheditor::main</comment>
        <translation type="unfinished">Fallo al registrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4390"/>
        <source>草稿画面确认</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4393"/>
        <source>发布</source>
        <translation type="unfinished">Publicar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4460"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4462"/>
        <source>没有需要合成的光字牌。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4536"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4587"/>
        <source>光字合成结果</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4590"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4377"/>
        <source>检测到 %1 个草稿画面需要发布:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4385"/>
        <source>是否继续发布这些草稿画面？</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4566"/>
        <source>光字合成完成！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4568"/>
        <source>合成光字统计：成功 %1 个，失败 %2 个</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4572"/>
        <source>画面发布统计：成功 %1 个，失败 %2 个</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4577"/>
        <source>失败详情：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15642"/>
        <source>变更电压等级</source>
        <translation type="unfinished">Cambiar nivel voltaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15660"/>
        <source>生成相关间隔图</source>
        <translation type="unfinished">Generar un mapa de intervalos de correlación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15710"/>
        <source>检索</source>
        <translation type="unfinished">Buscar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15750"/>
        <source>二维表检索</source>
        <translation type="unfinished">Recuperación de tabla 2D</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15757"/>
        <source>搜索文本:</source>
        <translation type="unfinished">Buscar texto:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15765"/>
        <source>搜索</source>
        <translation type="unfinished">Buscar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="4394"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/mainwindow.cpp" line="15766"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="898"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1152"/>
        <source>图元</source>
        <translation type="unfinished">Icono</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="899"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1153"/>
        <source>插件</source>
        <translation type="unfinished">Complementos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="971"/>
        <source>图元抽屉配置文件[%1]获取失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="983"/>
        <source>资源配置文件[%1]格式解析错误</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SelectIconType</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="900"/>
        <source>更多图元</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/icon_dock_co.cpp" line="1060"/>
        <source>文件[%1]打开失败，词条导出失败</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SyntheticLightWorker</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="37"/>
        <source>正在初始化光字合成...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="41"/>
        <source>光字合成初始化失败！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="49"/>
        <source>正在检查是否需要合成...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="61"/>
        <source>正在检查草稿画面...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="84"/>
        <source>用户取消操作</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="92"/>
        <source>正在发布 %1 个草稿画面...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="99"/>
        <source>以下画面发布失败:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="105"/>
        <source>... 还有 %1 个失败画面</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="120"/>
        <source>正在执行光字合成...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="127"/>
        <source>合成完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="129"/>
        <source>没有处理任何文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="137"/>
        <source>正在检查合成结果...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="143"/>
        <source>光字合成检查失败！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="182"/>
        <source>画面：%1 合成光字：%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="228"/>
        <source>正在发布光字牌...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="237"/>
        <source>装库失败！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="240"/>
        <source>错误信息：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="265"/>
        <source>执行过程中发生异常：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/synthetic_light_worker.cpp" line="274"/>
        <source>执行过程中发生未知异常！</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TDMSummaryTableWgt</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/TDMSummaryTableWgt.cpp" line="137"/>
        <source>老师ID</source>
        <translation type="unfinished">ID del maestro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/TDMSummaryTableWgt.cpp" line="138"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/TDMSummaryTableWgt.cpp" line="139"/>
        <source>老师姓名</source>
        <translation type="unfinished">Nombre del maestro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/TDMSummaryTableWgt.cpp" line="140"/>
        <source>8月20日</source>
        <translation type="unfinished">08-20</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/TDMSummaryTableWgt.cpp" line="141"/>
        <source>8月19日</source>
        <translation type="unfinished">08-19</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/TDMSummaryTableWgt.cpp" line="142"/>
        <source>操作</source>
        <translation type="unfinished">Operación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/TDMSummaryTableWgt.cpp" line="143"/>
        <source>续报率</source>
        <translation type="unfinished">Tasa de renovación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/TDMSummaryTableWgt.cpp" line="144"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/TDMSummaryTableWgt.cpp" line="148"/>
        <source>新学员续报率</source>
        <translation type="unfinished">Tasa de renovación de nuevos aprendices</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/TDMSummaryTableWgt.cpp" line="145"/>
        <source>续报增长人数</source>
        <translation type="unfinished">Continuación del crecimiento reportado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/TDMSummaryTableWgt.cpp" line="146"/>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/TDMSummaryTableWgt.cpp" line="147"/>
        <source>续报增长率</source>
        <translation type="unfinished">Tasa de crecimiento</translation>
    </message>
</context>
<context>
    <name>WidgetCheck</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/widget_check.cpp" line="22"/>
        <source>画面异常列表</source>
        <translation type="unfinished">Lista de gráficas anormales</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_grapheditor/dialogs/view/widget_check.cpp" line="29"/>
        <source>图元异常列表</source>
        <translation type="unfinished">Lista Excepciones Icono</translation>
    </message>
</context>
</TS>
