<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>DemoMenuViewerPlugin</name>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_graph_menu_viewer_plugin_demo/demo_menu_viewer_plugin.cpp" line="32"/>
        <source>测试运行态菜单插件集合</source>
        <translation type="unfinished">Colección de plugins de menú en prueba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_graph_menu_viewer_plugin_demo/demo_menu_viewer_plugin.cpp" line="46"/>
        <source>测试运行态设备菜单项</source>
        <translation type="unfinished">Ítem de menú de equipo en prueba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_graph_menu_viewer_plugin_demo/demo_menu_viewer_plugin.cpp" line="47"/>
        <source>测试运行态设备菜单项信息提示</source>
        <translation type="unfinished">Info. de ítem de menú de equipo en prueba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_graph_menu_viewer_plugin_demo/demo_menu_viewer_plugin.cpp" line="58"/>
        <source>测试运行态设备子菜单</source>
        <translation type="unfinished">Submenú de equipo en prueba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_graph_menu_viewer_plugin_demo/demo_menu_viewer_plugin.cpp" line="69"/>
        <source>测试运行态设备子菜单项1</source>
        <translation type="unfinished">Submenú de equipo en prueba ítem 1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_graph_menu_viewer_plugin_demo/demo_menu_viewer_plugin.cpp" line="80"/>
        <source>测试运行态设备子菜单项2</source>
        <translation type="unfinished">Submenú de equipo en prueba ítem 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_graph_menu_viewer_plugin_demo/demo_menu_viewer_plugin.cpp" line="94"/>
        <source>测试运行态空白菜单项</source>
        <translation type="unfinished">Ítem de menú en blanco en prueba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_graph_menu_viewer_plugin_demo/demo_menu_viewer_plugin.cpp" line="105"/>
        <source>测试运行态空白子菜单</source>
        <translation type="unfinished">Submenú en blanco en prueba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_graph_menu_viewer_plugin_demo/demo_menu_viewer_plugin.cpp" line="110"/>
        <source>测试运行态空白子菜单项1</source>
        <translation type="unfinished">Submenú en blanco en prueba ítem 1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_graph_menu_viewer_plugin_demo/demo_menu_viewer_plugin.cpp" line="120"/>
        <source>测试运行态空白子菜单项2</source>
        <translation type="unfinished">Submenú en blanco en prueba ítem 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_graph_menu_viewer_plugin_demo/demo_menu_viewer_plugin.cpp" line="134"/>
        <source>测试运行态光敏点菜单项</source>
        <translation type="unfinished">Ítem de menú sensible a luz en prueba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_graph_menu_viewer_plugin_demo/demo_menu_viewer_plugin.cpp" line="135"/>
        <source>测试运行态光敏点菜单项信息提示</source>
        <translation type="unfinished">Info. de ítem de menú sensible a luz en prueba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_graph_menu_viewer_plugin_demo/demo_menu_viewer_plugin.cpp" line="167"/>
        <location filename="../../../../src/plat/demo/gui/graphic_graph_menu_viewer_plugin_demo/demo_menu_viewer_plugin.cpp" line="179"/>
        <source>提示</source>
        <translation type="unfinished">Consejo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_graph_menu_viewer_plugin_demo/demo_menu_viewer_plugin.cpp" line="167"/>
        <source>测试运行态设备菜单项响应</source>
        <translation type="unfinished">Respuesta de ítem de menú de equipo en prueba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/demo/gui/graphic_graph_menu_viewer_plugin_demo/demo_menu_viewer_plugin.cpp" line="179"/>
        <source>测试运行态光敏点菜单项响应</source>
        <translation type="unfinished">Respuesta de ítem de menú sensible en prueba</translation>
    </message>
</context>
</TS>
