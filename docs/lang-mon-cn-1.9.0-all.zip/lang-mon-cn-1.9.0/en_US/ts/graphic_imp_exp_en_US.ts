<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CommonMainWindow</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="258"/>
        <source>导出</source>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="261"/>
        <source>导入</source>
        <translation type="unfinished">Import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="275"/>
        <source>画面</source>
        <translation type="unfinished">Graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="278"/>
        <source>图元</source>
        <translation type="unfinished">Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="346"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="358"/>
        <source>操作</source>
        <translation type="unfinished">Operation</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="364"/>
        <source>%1文件:</source>
        <translation type="unfinished">%1 file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="364"/>
        <source>目标</source>
        <translation type="unfinished">Destination</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="364"/>
        <source>原</source>
        <translation type="unfinished">Original</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="423"/>
        <source>请选择一种导入方式:</source>
        <translation type="unfinished">Please select an import method:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="427"/>
        <source>在某个%1类型下导入(请选一个%2类型节点)</source>
        <translation type="unfinished">Import under a certain %1 type (please select a %2 type node)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="428"/>
        <source>在已有的%1树中导入</source>
        <translation type="unfinished">Import in the existing %1 tree</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="434"/>
        <source>待导入位置</source>
        <translation type="unfinished">Location to be imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="458"/>
        <source>画面字典</source>
        <translation type="unfinished">Graph dict</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="468"/>
        <source>图元字典</source>
        <translation type="unfinished">Icons dictionary</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="576"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="721"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1747"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1776"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2052"/>
        <source>草稿版本</source>
        <translation type="unfinished">Draft version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="580"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="725"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1742"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1780"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2047"/>
        <source>最新版本</source>
        <translation type="unfinished">Latest version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="584"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="729"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1784"/>
        <source>历史版本%1</source>
        <translation type="unfinished">Historical version %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="881"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1501"/>
        <source>即将删除所选对象，请确认</source>
        <translation type="unfinished">The selected object is about to be deleted, please confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1245"/>
        <source>画面[%1]文件拷贝失败，原文件[%2]，目标文件[%3]</source>
        <translation type="unfinished">Graph [%1] file copy failed; original: [%2]; destination: [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1348"/>
        <source>图元[%1]文件拷贝失败，原文件[%2]，目标文件[%3]</source>
        <translation type="unfinished">Failed to copy Icon [%1] file; original: [%2]; destination: [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2488"/>
        <source>思弘瑞压缩格式%1</source>
        <translation type="unfinished">SHR compression format %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2523"/>
        <source>加载导入文件格式错误，导入异常</source>
        <translation type="unfinished">The format of the imported file is incorrect and the import is abnormal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2531"/>
        <source>导入文件中没有可用的导入项，导入异常</source>
        <translation type="unfinished">No available import items found in the file. Import failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2673"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2897"/>
        <source>当前待导入的新决策[%1]与系统中的原决策存在差异，是否使用新决策</source>
        <translation type="unfinished">For the current new decision [%1] to be imported, it differs from the original decision in the system; whether to use the new decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2678"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2902"/>
        <source>决策拷贝重复</source>
        <comment>toolName</comment>
        <translation type="unfinished">Duplicate Decision Detected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="774"/>
        <source>当前版本(%1)</source>
        <translation type="unfinished">Current version (%1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="297"/>
        <source>待导出画面</source>
        <translation type="unfinished">To be exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="301"/>
        <source>待导出图元</source>
        <translation type="unfinished">To be exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="305"/>
        <source>待导入图元</source>
        <translation type="unfinished">To be imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="309"/>
        <source>待导入画面</source>
        <translation type="unfinished">To be imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="313"/>
        <source>未知信息</source>
        <translation type="unfinished">Unknown info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="371"/>
        <source>请选择一个用于%1导出的目录</source>
        <translation type="unfinished">Please select a dir for exporting %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="375"/>
        <source>请选择一个用于%1导入的思源压缩文件</source>
        <translation type="unfinished">Please select SHR Compressed File for importing %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="443"/>
        <source>%1列表</source>
        <translation type="unfinished">%1 list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="593"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="608"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="618"/>
        <source>,</source>
        <translation type="unfinished">,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="881"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1501"/>
        <source>删除对象</source>
        <translation type="unfinished">Delete object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1141"/>
        <source>%1正在导出中...</source>
        <translation type="unfinished">%1 is being exported...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1142"/>
        <source>%1导出进度</source>
        <translation type="unfinished">%1 export progress</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1195"/>
        <source>画面节点[%1]未找到，导出失败</source>
        <translation type="unfinished">Graph node [%1] not found, export failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1273"/>
        <source>画面节点[%1]决策写入失败</source>
        <translation type="unfinished">Decision for graph node [%1] failed to write</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1285"/>
        <source>画面节点[%1]决策导出失败</source>
        <translation type="unfinished">Decision for graph node [%1] failed to export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1291"/>
        <source>画面节点[%1]决策导出成功</source>
        <translation type="unfinished">Decision for graph node [%1] exported successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1305"/>
        <source>画面节点[%1]导出成功</source>
        <translation type="unfinished">Graph node [%1] exported successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1372"/>
        <source>图元节点[%1]导出成功</source>
        <translation type="unfinished">Icon node [%1] exported successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1378"/>
        <source>图元节点[%1]未找到，导出失败</source>
        <translation type="unfinished">Icon node [%1] not found; export failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1384"/>
        <source>共%1项（%2项成功，%3项失败）。</source>
        <translation type="unfinished">Total: %1 (%2 succeeded, %3 failed).</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1407"/>
        <source>图元决策导出失败</source>
        <translation type="unfinished">Icon decision failed to export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1413"/>
        <source>图元决策导出成功</source>
        <translation type="unfinished">Icon decision exported successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1890"/>
        <source>添加%1[%2]节点错误</source>
        <translation type="unfinished">Error in adding node %1 [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1893"/>
        <source>获取%1[%2]完整路径错误</source>
        <translation type="unfinished">Error getting full path of %1[%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1908"/>
        <source>删除%1[%2]节点失败</source>
        <translation type="unfinished">Failed to delete node %1[%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1911"/>
        <source>添加%1[%2]节点库失败</source>
        <translation type="unfinished">Failed to add node DB %1[%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1914"/>
        <source>添加%1[%2]节点文件失败</source>
        <translation type="unfinished">Failed to add node file %1[%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1917"/>
        <source>拷贝%1[%2]节点文件失败</source>
        <translation type="unfinished">Failed to copy node file %1[%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1920"/>
        <source>创建%1[%2]节点文件目录失败</source>
        <translation type="unfinished">Failed to create file dir of node %1 [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1923"/>
        <source>%1[%2]节点文件跳过</source>
        <translation type="unfinished">%1 [%2] node files skipped</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1926"/>
        <source>添加%1[%2]节点成功</source>
        <translation type="unfinished">Node [%1][%2] added successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1938"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2168"/>
        <source>当前导入信息为空，请重新选择导入对象</source>
        <translation type="unfinished">Empty import info. Please select one.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1974"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1975"/>
        <source>画面树类型信息空指针异常</source>
        <translation type="unfinished">Graph tree type info null pointer exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1980"/>
        <source>画面导入进度</source>
        <comment>toolName</comment>
        <translation type="unfinished">Graph Import Progress</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1988"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2220"/>
        <source>导入完成：</source>
        <translation type="unfinished">Import completed:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2004"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2232"/>
        <source>获取表行[%1]数据空指针异常</source>
        <translation type="unfinished">Null pointer exception for retrieving the data of table row [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2026"/>
        <source>无法获取画面节点[%1]信息</source>
        <translation type="unfinished">The info of the graph node [%1] cannot be retrieved</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2034"/>
        <source>画面节点[%1]匹配原始Oid[%2]失败</source>
        <translation type="unfinished">Graph node [%1] failed to match original Oid [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2042"/>
        <source>根据画面节点[%1]获取画面文件信息失败</source>
        <translation type="unfinished">Failed to retrieve graph file info based on graph node [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2127"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2330"/>
        <source>共%1项（%2项成功，%3项跳过，%4项失败）。</source>
        <translation type="unfinished">Total: %1 (%2 succeeded, %3 skipped, %4 failed)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2147"/>
        <source>发布画面</source>
        <translation type="unfinished">Publish graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2147"/>
        <source>是否发布已导入成功的画面，请确认</source>
        <translation type="unfinished">Please confirm whether to publish the successfully imported graphs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2203"/>
        <source>图元树空指针异常</source>
        <translation type="unfinished">The null pointer of the icon tree is abnormal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2208"/>
        <source>图元导入中...</source>
        <translation type="unfinished">Icon import in progress...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2209"/>
        <source>图元导入进度</source>
        <comment>toolName</comment>
        <translation type="unfinished">Icon Import Progress</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2252"/>
        <source>无法获取图元节点[%1]信息</source>
        <translation type="unfinished">Unable to retrieve info about the icon node [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2260"/>
        <source>根据图元节点[%1]获取层级目录失败</source>
        <translation type="unfinished">Failed to retrieve the hierarchical dir based on the icon node [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2349"/>
        <source>发布图元</source>
        <translation type="unfinished">Publish icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2349"/>
        <source>是否发布已导入成功的图元，请确认</source>
        <translation type="unfinished">Please confirm whether to publish the successfully imported icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2419"/>
        <source>当前没有选择可导出目录，请选择</source>
        <translation type="unfinished">No export dir is selected at present. Please select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2425"/>
        <source>导出目录为空，请重新选择</source>
        <translation type="unfinished">The export dir is empty, please select again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1741"/>
        <source>当前版本(最新版本)</source>
        <translation type="unfinished">Current version (latest version)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="350"/>
        <source>%1路径</source>
        <translation type="unfinished">%1 path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="354"/>
        <source>%1名称</source>
        <translation type="unfinished">%1 name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="380"/>
        <source>选择对象</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select obj</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="437"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="446"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="318"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1055"/>
        <source>删除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="752"/>
        <source>当前版本%1</source>
        <translation type="unfinished">Current version %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1152"/>
        <source>导出完成：</source>
        <translation type="unfinished">Export completed:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1254"/>
        <source>画面[%1]文件对应关系[%2]:[%3]配置信息写入失败</source>
        <translation type="unfinished">In the graph [%1], the config info of the file correspondence relationship [%2]: [%3] failed to be written</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1263"/>
        <source>画面[%1]文件层级[%2]配置信息写入失败</source>
        <translation type="unfinished">Config info of graph [%1] at file level [%2] failed to be written</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1297"/>
        <source>画面节点[%1]指针错误</source>
        <translation type="unfinished">Pointer of the graph node [%1] is incorrect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1359"/>
        <source>图元[%1]层级[%2]配置信息写入失败</source>
        <translation type="unfinished">The config info of icon [%1] at level [%2] failed to be written</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1422"/>
        <source>思源压缩包生成失败！</source>
        <translation type="unfinished">SHR Compressed Package failed to gen!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1423"/>
        <source>思源压缩包[%1]生成失败，导出异常！</source>
        <translation type="unfinished">SHR Compressed Package [%1] failed to gen, export exception!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1428"/>
        <source>思源压缩包生成成功！</source>
        <translation type="unfinished">SHR Compressed Package gened successfully!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1429"/>
        <source>思源压缩包[%1]生成成功！</source>
        <translation type="unfinished">SHR Compressed Package [%1] gened successfully!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1459"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2128"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2331"/>
        <source> 详情请看[操作记录]</source>
        <translation type="unfinished"> Please refer to the [Operation Record] for details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1748"/>
        <source>当前版本(草稿版本)</source>
        <translation type="unfinished">Current version (Draft version)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1842"/>
        <source>图元节点[%1]与图元路径[%2]不匹配</source>
        <translation type="unfinished">Icon node [%1] does not match icon path [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1887"/>
        <source>%1[%2]节点导入成功</source>
        <translation type="unfinished">%1 [%2] node import successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1896"/>
        <source>%1[%2]节点空指针</source>
        <translation type="unfinished">%1 [%2] node null pointer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1899"/>
        <source>%1[%2]版本信息为空</source>
        <translation type="unfinished">The version info of %1 [%2] is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1902"/>
        <source>%1[%2]版本文件不存在</source>
        <translation type="unfinished">%1 [%2] version file does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1215"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1324"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1905"/>
        <source>获取%1[%2]节点信息失败</source>
        <translation type="unfinished">Failed to retrieve the node info of %1 [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1938"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1946"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1974"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2168"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2176"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2419"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2425"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2441"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2516"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2525"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2533"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1946"/>
        <source>请先选择一个画面类型</source>
        <translation type="unfinished">Please select a graph type first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="1979"/>
        <source>画面导入中...</source>
        <translation type="unfinished">Importing graph...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2501"/>
        <source>思源压缩包[%1]设置成功。正在解压缩文件...</source>
        <translation type="unfinished">SHR Compressed Package [%1] set successfully. Extracting files ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2508"/>
        <source>思源压缩包解压成功。设置当前导入目录为</source>
        <translation type="unfinished">SHR Compressed Package extracted successfully. Set the current import dir to:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2514"/>
        <source>思源压缩包[%1]解压缩失败，导入异常</source>
        <translation type="unfinished">SHR Compressed Package [%1] failed to extract, import exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2080"/>
        <source>根据画面原始OID[%1]获取画面名称失败</source>
        <translation type="unfinished">Failed to retrieve the graph name based on the original OID [%1] of the graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2091"/>
        <source>画面节点[%1]决策导入失败</source>
        <translation type="unfinished">Decision for graph node [%1] failed to import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2176"/>
        <source>请先选择一个图元类型</source>
        <translation type="unfinished">Please select a icon type first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2291"/>
        <source>图元[%1]决策导入失败</source>
        <translation type="unfinished">Decision for icon [%1] failed to import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2441"/>
        <source>导出目录下[%1]无法创建文件或文件夹请检查</source>
        <translation type="unfinished">Files or folders cannot be created under [%1] in the export dir. Please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2460"/>
        <source>选择文件夹</source>
        <translation type="unfinished">Select folder</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="2492"/>
        <source>选择文件</source>
        <translation type="unfinished">Select file</translation>
    </message>
</context>
<context>
    <name>CopyDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/dialog_common.cpp" line="55"/>
        <source>详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/dialog_common.cpp" line="74"/>
        <source>源决策:</source>
        <translation type="unfinished">Source decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/dialog_common.cpp" line="79"/>
        <source>新决策:</source>
        <translation type="unfinished">New Decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/dialog_common.cpp" line="93"/>
        <source>不再提醒</source>
        <translation type="unfinished">Do not remind again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/dialog_common.cpp" line="98"/>
        <source>跳过</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Skip</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/dialog_common.cpp" line="114"/>
        <source>覆盖</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Overwrite</translation>
    </message>
</context>
<context>
    <name>ExportIconWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="985"/>
        <source>请选择一个用于图元导出的目录</source>
        <translation type="unfinished">Please select a dir for exporting icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1037"/>
        <source>图元列表</source>
        <translation type="unfinished">Icon list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1058"/>
        <source>图元字典</source>
        <translation type="unfinished">Icons dictionary</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1236"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1242"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1556"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1651"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1659"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1745"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1242"/>
        <source>导出目录为空，请重新选择</source>
        <translation type="unfinished">The export dir is empty, please select again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="967"/>
        <source>请输入用于导出搜索的字符串</source>
        <translation type="unfinished">Please enter the string used for export search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="969"/>
        <source>搜索</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="980"/>
        <source>导出目录:</source>
        <translation type="unfinished">Export dir:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="989"/>
        <source>选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="994"/>
        <source>导出前检查</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Check &amp;&amp; export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1023"/>
        <source>请输入用于导出过滤的字符串</source>
        <translation type="unfinished">Please enter the string used for export filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1026"/>
        <source>过滤</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1032"/>
        <source>请勾选图元列表获取需要被导出的图元</source>
        <translation type="unfinished">Please check the icon that needs to be exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1040"/>
        <source>全选图元列表</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select all icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1046"/>
        <source>重新加载图元列表</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Reload icon list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1207"/>
        <source>当前图元[%1]与导出列表中重复，不加入列表中</source>
        <translation type="unfinished">The current icon [%1] is duplicated in the export list and will not be added to the list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1236"/>
        <source>当前没有可导出项，请重新选择导出项</source>
        <translation type="unfinished">No exportable item. Please select one.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1433"/>
        <source>导出前检查错误</source>
        <translation type="unfinished">Check &amp;&amp; export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1318"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1556"/>
        <source>图元</source>
        <translation type="unfinished">Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1318"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1556"/>
        <source>无法获取，导出失败！</source>
        <translation type="unfinished">Unable to retrieve, export failed!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1414"/>
        <source>图元数据校验成功</source>
        <translation type="unfinished">Icon data verification successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1523"/>
        <source>图元导出前检查清除成功</source>
        <translation type="unfinished">Check and clear successfully before exporting icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1526"/>
        <source>图元导出前检查列表不存在</source>
        <translation type="unfinished">The pre-export checklist for icons does not exist.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1570"/>
        <source>图元导出前检查...</source>
        <translation type="unfinished">Pre-check before exporting icons...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1659"/>
        <source>操作成功！</source>
        <translation type="unfinished">Operation successful!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1743"/>
        <source>资源目录[%1]创建失败导出终止,</source>
        <translation type="unfinished">The creation of resource dir [%1] failed; export terminated,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1750"/>
        <source>资源目录创建成功[%1]</source>
        <translation type="unfinished">Resource dir created successfully [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1758"/>
        <source>图元导出进度</source>
        <translation type="unfinished">Progress of exporting icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1761"/>
        <source>导出完成：</source>
        <translation type="unfinished">Export completed:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1789"/>
        <source>当前待导出图元[%1]导出失败，请确认是否导出剩余未导出的图元</source>
        <translation type="unfinished">For the current icon [%1] to be exported, the export failed; please confirm whether to export the remaining icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1790"/>
        <source>图元导出失败</source>
        <comment>toolName</comment>
        <translation type="unfinished">Icon Export Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1791"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1792"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1822"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2028"/>
        <source>导出失败，</source>
        <translation type="unfinished">Export failed,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1843"/>
        <source>获取图元[%1]节点信息失败</source>
        <translation type="unfinished">Failed to retrieve node info for icon [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1866"/>
        <source>图元[%1]文件图元名称校验失败，无法获取图元文件中图元名称</source>
        <translation type="unfinished">Icon [%1] file name verification failed; unable to retrieve icon name from icon file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1874"/>
        <source>图元名称校验失败，图元文件中图元名称：%2，节点中的图元名称：%3</source>
        <translation type="unfinished">Icon name verification failed, icon name in icon file: %2, icon name in node: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1882"/>
        <source>图元[%1]文件拷贝失败，原文件[%2]，目标文件[%3]</source>
        <translation type="unfinished">Failed to copy Icon [%1] file; original: [%2]; destination: [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1928"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1935"/>
        <source>当前待导出图元[%1]的资源文件[%2]不在iasp目录下</source>
        <translation type="unfinished">For the current icon [%1] to be exported, the resource file [%2] is not in the IASP dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1946"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1969"/>
        <source>当前待导出图元[%1]的资源文件[%2]不存在</source>
        <translation type="unfinished">For the current icon [%1] to be exported, the resource file [%2] does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1951"/>
        <source>当前待导出图元[%1]拷贝失败，原文件[%2],目标文件[%3]</source>
        <translation type="unfinished">For the current icon [%1] to be exported, the copy failed; original: [%2]; destination: [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1962"/>
        <source>当前待导出图元[%1]的资源文件[%2]导出成功</source>
        <translation type="unfinished">For the current icon [%1] to be exported, the resource file [%2] succeeded in exporting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="1999"/>
        <source>图元[%1]名称与层级[%2]不匹配</source>
        <translation type="unfinished">Icon [%1] name does not match level [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2007"/>
        <source>图元[%1]层级[%2]配置信息写入失败</source>
        <translation type="unfinished">The config info of icon [%1] at level [%2] failed to be written</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2032"/>
        <source>共%1项（%2项成功，%3项失败，%4项未导出）。</source>
        <translation type="unfinished">Total: %1 (%2 succeeded, %3 failed, %4 not exported)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2053"/>
        <source>图元决策索引导出失败</source>
        <translation type="unfinished">Failed to export the decision index of icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2060"/>
        <source>图元决策索引导出成功</source>
        <translation type="unfinished">The decision index for icons has been successfully exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2144"/>
        <source>导出完成</source>
        <translation type="unfinished">Export completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2148"/>
        <source>导出错误</source>
        <translation type="unfinished">Export error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2193"/>
        <source>全选图元列表</source>
        <translation type="unfinished">Select all icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2187"/>
        <source>取消已选图元列表</source>
        <translation type="unfinished">Cancel icon selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="960"/>
        <source>导出图元</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Export icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2013"/>
        <source>图元节点[%1]导出成功</source>
        <translation type="unfinished">Icon node [%1] exported successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2016"/>
        <source>导出成功</source>
        <translation type="unfinished">Export successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2021"/>
        <source>图元节点[%1]未找到，导出失败</source>
        <translation type="unfinished">Icon node [%1] not found; export failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2074"/>
        <source>图元资源索引文件导出失败</source>
        <translation type="unfinished">Export of icon resource index file failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2081"/>
        <source>图元资源索引文件导出成功</source>
        <translation type="unfinished"> Icon resource index file exported successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2097"/>
        <source>思源压缩包生成失败！</source>
        <translation type="unfinished">SHR Compressed Package failed to gen!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2098"/>
        <source>思源压缩包[%1]生成失败，导出异常！</source>
        <translation type="unfinished">SHR Compressed Package [%1] failed to gen, export exception!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2104"/>
        <source>思源压缩包[%1]生成成功！</source>
        <translation type="unfinished">SHR Compressed Package [%1] gened successfully!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2164"/>
        <source>选择文件夹</source>
        <translation type="unfinished">Select folder</translation>
    </message>
</context>
<context>
    <name>ExportPictureWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="855"/>
        <source>请选择一个用于画面导出的目录</source>
        <translation type="unfinished">Please select a dir for exporting graphs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="864"/>
        <source>导出前检查</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Check &amp;&amp; export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="872"/>
        <source>导出画面</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Export graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="928"/>
        <source>画面列表</source>
        <translation type="unfinished">Graph list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="948"/>
        <source>画面字典</source>
        <translation type="unfinished">Graph dict</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1006"/>
        <source>草稿版本</source>
        <translation type="unfinished">Draft version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1010"/>
        <source>最新版本</source>
        <translation type="unfinished">Latest version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1014"/>
        <source>历史版本%1</source>
        <translation type="unfinished">Historical version %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1122"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1128"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1595"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1603"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1128"/>
        <source>导出目录为空，请重新选择</source>
        <translation type="unfinished">The export dir is empty, please select again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1770"/>
        <source>画面导出进度</source>
        <translation type="unfinished">Graph export progress</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1773"/>
        <source>导出完成：</source>
        <translation type="unfinished">Export completed:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1918"/>
        <source>画面[%1]文件拷贝失败，原文件[%2]，目标文件[%3]</source>
        <translation type="unfinished">Graph [%1] file copy failed; original: [%2]; destination: [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2152"/>
        <source>导出成功</source>
        <translation type="unfinished">Export successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2158"/>
        <source>画面节点[%1]未找到，导出失败</source>
        <translation type="unfinished">Graph node [%1] not found, export failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1875"/>
        <source>获取画面[%1]节点信息失败</source>
        <translation type="unfinished">Failed to retrieve node info for graph [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="850"/>
        <source>导出目录:</source>
        <translation type="unfinished">Export dir:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="859"/>
        <source>选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="879"/>
        <source>请输入用于导出搜索的字符串</source>
        <translation type="unfinished">Please enter the string used for export search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="882"/>
        <source>搜索</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Search</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="917"/>
        <source>请输入用于导出过滤的字符串</source>
        <translation type="unfinished">Please enter the string used for export filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="921"/>
        <source>过滤</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="931"/>
        <source>全选画面列表</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="937"/>
        <source>重新加载画面列表</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Reload graph list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1092"/>
        <source>当前画面[%1]与导出列表中重复，不加入列表中</source>
        <translation type="unfinished">The current graph [%1] is duplicated in the export list and will not be added to the list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1122"/>
        <source>当前没有可导出项，请重新选择导出项</source>
        <translation type="unfinished">No exportable item. Please select one.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1429"/>
        <source>导出前检查错误</source>
        <translation type="unfinished">Check &amp;&amp; export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1444"/>
        <source>画面导出前检查...</source>
        <translation type="unfinished">Pre-check before exporting graphs...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1283"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1477"/>
        <source>画面节点指针错误</source>
        <translation type="unfinished">Graph node pointer error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1023"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1038"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1048"/>
        <source>,</source>
        <translation type="unfinished">,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1408"/>
        <source>数据校验成功</source>
        <translation type="unfinished">Data verification successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1603"/>
        <source>操作成功！</source>
        <translation type="unfinished">Operation successful!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1753"/>
        <source>画面导出前检查清除成功</source>
        <translation type="unfinished">Check and clear successfully before exporting the graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1756"/>
        <source>画面导出前检查列表不存在</source>
        <translation type="unfinished">The checklist before exporting the graph does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1818"/>
        <source>当前待导出画面[%1]导出失败，请确认是否导出剩余未导出的画面</source>
        <translation type="unfinished">For the current icon [%1] to be exported, the export failed; please confirm whether to export the remaining graphs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1819"/>
        <source>画面导出失败</source>
        <comment>toolName</comment>
        <translation type="unfinished">Graph Export Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1820"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1821"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1851"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2166"/>
        <source>导出失败，</source>
        <translation type="unfinished">Export failed,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1910"/>
        <source>画面[%1]节点资源目录创建失败</source>
        <translation type="unfinished">Graph [%1] Node resource dir creation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1953"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1960"/>
        <source>当前待导出画面[%1]的资源文件[%2]不在iasp目录下</source>
        <translation type="unfinished">For the current graph [%1] to be exported, the resource file [%2] is not in the IASP dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1971"/>
        <source>当前待导出画面[%1]的资源文件[%2]不存在</source>
        <translation type="unfinished">For the current graph [%1] to be exported, the resource file [%2] does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1976"/>
        <source>当前待导出画面[%1]拷贝失败，原文件[%2],目标文件[%3]</source>
        <translation type="unfinished">Graph [%1] copy failed; original: [%2]; destination: [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1987"/>
        <source>当前待导出画面[%1]的资源文件[%2]导出成功</source>
        <translation type="unfinished">For the current graph [%1] to be exported, the resource file [%2] succeeded in exporting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="1994"/>
        <source>当前待导出画面[%1]的资源文件[%2]无法获取</source>
        <translation type="unfinished">For the current graph [%1] to be exported, the resource file [%2] could not be retrieved</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2015"/>
        <source>当前待导出画面中的[%1]资源文件导出完成</source>
        <translation type="unfinished">For the current graph to be exported, the resource file [%1] succeeded in exporting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2029"/>
        <source>画面节点[%1]资源索引生成失败</source>
        <translation type="unfinished">Graph node [%1] resource index generation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2036"/>
        <source>画面节点[%1]资源索引生成成功</source>
        <translation type="unfinished">Graph node [%1] resource index gened successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2045"/>
        <source>在画面节点[%1]里：</source>
        <translation type="unfinished">In graph node [%1]:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2080"/>
        <source>当前图元[%1]已经被成功导出过，跳过该图元导出</source>
        <translation type="unfinished">Current icon [%1] successfully exported; skip exporting this icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2090"/>
        <source>成功</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2108"/>
        <source>当前待导出画面[%1]图元[%2]导出失败,该画面导出失败</source>
        <translation type="unfinished">For the current graph [%1] to be exported, the icon [%2] failed to export; and the export of this graph has failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2125"/>
        <source>当前待导出画面中的[%1]图元导出完成</source>
        <translation type="unfinished">For the current graph to be exported, the icon [%1] succeeded in exporting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2134"/>
        <source>画面[%1]文件对应关系[%2]:[%3]配置信息写入失败</source>
        <translation type="unfinished">In the graph [%1], the config info of the file correspondence relationship [%2]: [%3] failed to be written</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2144"/>
        <source>画面[%1]文件层级[%2]配置信息写入失败</source>
        <translation type="unfinished">Config info of graph [%1] at file level [%2] failed to be written</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2169"/>
        <source>共%1项（%2项成功，%3项失败，%4未导出）。</source>
        <translation type="unfinished">Total: %1 (%2 succeeded, %3 failed, %4 not exported)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2286"/>
        <source>导出完成</source>
        <translation type="unfinished">Export completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2290"/>
        <source>导出错误</source>
        <translation type="unfinished">Export error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2334"/>
        <source>全选画面列表</source>
        <translation type="unfinished">Select All</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2328"/>
        <source>取消已选画面列表</source>
        <translation type="unfinished">Cancel graph selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2219"/>
        <source>画面图元资源索引文件导出失败</source>
        <translation type="unfinished">Export of icon resource index file failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2226"/>
        <source>画面图元资源索引文件导出成功</source>
        <translation type="unfinished">Icon resource index file exported successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2059"/>
        <source>画面节点[%1]决策导出失败</source>
        <translation type="unfinished">Decision for graph node [%1] failed to export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2066"/>
        <source>画面节点[%1]决策导出成功</source>
        <translation type="unfinished">Decision for graph node [%1] exported successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2150"/>
        <source>画面节点[%1]导出成功</source>
        <translation type="unfinished">Graph node [%1] exported successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2198"/>
        <source>画面图元决策导出失败</source>
        <translation type="unfinished">Icon decision export failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2205"/>
        <source>画面图元决策导出成功</source>
        <translation type="unfinished">Icon decision exported successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2239"/>
        <source>思源压缩包生成失败！</source>
        <translation type="unfinished">SHR Compressed Package failed to gen!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2240"/>
        <source>思源压缩包[%1]生成失败，导出异常！</source>
        <translation type="unfinished">SHR Compressed Package [%1] failed to gen, export exception!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2246"/>
        <source>思源压缩包[%1]生成成功！</source>
        <translation type="unfinished">SHR Compressed Package [%1] gened successfully!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2306"/>
        <source>选择文件夹</source>
        <translation type="unfinished">Select folder</translation>
    </message>
</context>
<context>
    <name>ExportTableWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="100"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="100"/>
        <source>%1路径</source>
        <translation type="unfinished">%1 path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="100"/>
        <source>%1名称</source>
        <translation type="unfinished">%1 name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="100"/>
        <source>导出结果</source>
        <translation type="unfinished">Export results</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="120"/>
        <source>画面</source>
        <translation type="unfinished">Graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="123"/>
        <source>图元</source>
        <translation type="unfinished">Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="389"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="406"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="488"/>
        <source>未导出</source>
        <translation type="unfinished">Not exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="547"/>
        <source>%1[%2]节点导入成功</source>
        <translation type="unfinished">%1 [%2] node import successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="550"/>
        <source>添加%1[%2]节点错误</source>
        <translation type="unfinished">Error in adding node %1 [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="553"/>
        <source>获取%1[%2]完整路径错误</source>
        <translation type="unfinished">Error getting full path of %1[%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="568"/>
        <source>删除%1[%2]节点失败</source>
        <translation type="unfinished">Failed to delete node %1[%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="571"/>
        <source>添加%1[%2]节点库失败</source>
        <translation type="unfinished">Failed to add node DB %1[%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="574"/>
        <source>添加%1[%2]节点文件失败</source>
        <translation type="unfinished">Failed to add node file %1[%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="577"/>
        <source>拷贝%1[%2]节点文件失败</source>
        <translation type="unfinished">Failed to copy node file %1[%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="580"/>
        <source>创建%1[%2]节点文件目录失败</source>
        <translation type="unfinished">Failed to create file dir of node %1 [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="589"/>
        <source>添加%1[%2]节点成功</source>
        <translation type="unfinished">Node [%1][%2] added successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="556"/>
        <source>%1[%2]节点空指针</source>
        <translation type="unfinished">%1 [%2] node null pointer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="559"/>
        <source>%1[%2]版本信息为空</source>
        <translation type="unfinished">The version info of %1 [%2] is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="562"/>
        <source>%1[%2]版本文件不存在</source>
        <translation type="unfinished">%1 [%2] version file does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="565"/>
        <source>获取%1[%2]节点信息失败</source>
        <translation type="unfinished">Failed to retrieve the node info of %1 [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="583"/>
        <source>%1[%2]节点文件跳过</source>
        <translation type="unfinished">%1 [%2] node files skipped</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="586"/>
        <source>%1[%2]节点与父节点类型不匹配</source>
        <translation type="unfinished">The type of %1 [%2] node does not match the type of parent node</translation>
    </message>
</context>
<context>
    <name>ImpExpBaseTree</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="74"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="78"/>
        <source>画面</source>
        <translation type="unfinished">Graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="74"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="78"/>
        <source>图元</source>
        <translation type="unfinished">Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="74"/>
        <source>正在全选所有%1</source>
        <translation type="unfinished">Selecting all %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="78"/>
        <source>取消选择所有%1</source>
        <translation type="unfinished">Cancel %1</translation>
    </message>
</context>
<context>
    <name>ImpExpCheckDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="98"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="99"/>
        <source>图元导入检查</source>
        <translation type="unfinished">Icon import check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="104"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="105"/>
        <source>图元导出检查</source>
        <translation type="unfinished">Icon export check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="110"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="111"/>
        <source>画面导入检查</source>
        <translation type="unfinished">Graph import check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="116"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="117"/>
        <source>画面导出检查</source>
        <translation type="unfinished">Graph export check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="241"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="318"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="447"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="505"/>
        <source>画面</source>
        <translation type="unfinished">Graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="242"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="285"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="318"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="352"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="403"/>
        <source>图元</source>
        <translation type="unfinished">Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="243"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="286"/>
        <source>决策</source>
        <translation type="unfinished">Decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="244"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="287"/>
        <source>资源</source>
        <translation type="unfinished">Resource</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="319"/>
        <source>导入</source>
        <translation type="unfinished">Import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="319"/>
        <source>导出</source>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="195"/>
        <source>导出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="202"/>
        <source>退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Exit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="344"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="391"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="435"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="487"/>
        <source>资源、</source>
        <translation type="unfinished">Resources, </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="349"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="397"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="440"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="493"/>
        <source>决策、</source>
        <translation type="unfinished">Decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="445"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="499"/>
        <source>图元、</source>
        <translation type="unfinished">Icon, </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="322"/>
        <source>当前%1%2：</source>
        <translation type="unfinished">Current %1 %2:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="333"/>
        <source>[资源、决策、图元]所有项校检成功，可以正常导出。</source>
        <translation type="unfinished">[Resources, Decisions, Icons] All items have been successfully verified and can be exported normally.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="353"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="448"/>
        <source>[%1]存在异常，</source>
        <translation type="unfinished">[%1] has an exception,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="361"/>
        <source>勾选确认强制导出其余正常图元,异常的图元将不会被导出。</source>
        <translation type="unfinished">Check the box to confirm forcing the export of other normal icons. Abnormal icons will not be exported.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="366"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="461"/>
        <source>无法进行导出。</source>
        <translation type="unfinished">Unable to export.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="378"/>
        <source>[资源、决策、图元]所有项校检成功，可以正常导入。</source>
        <translation type="unfinished">[Resources, Decisions, Icons] All items have been successfully verified and can be imported normally.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="406"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="508"/>
        <source>存在重复的[%1]需要处理。</source>
        <translation type="unfinished">Duplicate [%1] need to be processed.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="412"/>
        <source>勾选确认已经处理过重复的资源、决策或图元。</source>
        <translation type="unfinished">Check the box to confirm that duplicate resources, decisions, or icons have been processed.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="424"/>
        <source>[资源、决策、图元、画面]所有项校检成功，可以正常导出。</source>
        <translation type="unfinished">[Resources, Decisions, Icons, Graphs] All items have been verified successfully and can be exported normally.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="456"/>
        <source>勾选确认强制导出其余正常画面,异常的画面将不会被导出。</source>
        <translation type="unfinished">Check the box to confirm forcing the export of other normal graphs. Abnormal graphs will not be exported.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="474"/>
        <source>[资源、决策、图元、画面]所有项校检成功，可以正常导入。</source>
        <translation type="unfinished">[Resources, Decisions, Icons, Graphs] All items have been verified successfully and can be imported normally.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="514"/>
        <source>勾选确认已经处理过重复的资源、决策、图元或画面。</source>
        <translation type="unfinished">Check the box to confirm that duplicate resources, decisions, icons or graphs have been processed.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="591"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="618"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="624"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="642"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="648"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="679"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="1061"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="1085"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="591"/>
        <source>导出目录设置为空</source>
        <translation type="unfinished">Export dir set to empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="610"/>
        <source>导出包名称</source>
        <translation type="unfinished">Export package name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="610"/>
        <source>请输入导出包名称：</source>
        <translation type="unfinished">Please enter the export package name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="618"/>
        <source>导出包名不能包含路径“/”符号</source>
        <translation type="unfinished">Export package name cannot contain path &apos;/&apos; symbol</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="624"/>
        <source>导出包名不能为空</source>
        <translation type="unfinished">Export package name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="642"/>
        <source>文件重名，导出终止</source>
        <translation type="unfinished">File name is duplicated; export terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="648"/>
        <source>导出目录下[%1]无法创建文件或文件夹请检查</source>
        <translation type="unfinished">Files or folders cannot be created under [%1] in the export dir. Please check</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="678"/>
        <source>生成导出配置文件[%1]失败</source>
        <translation type="unfinished">Failed to gen export config file [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="776"/>
        <source>正在导出图元资源</source>
        <translation type="unfinished">Exporting icon resources</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="790"/>
        <source>正在导出图元决策</source>
        <translation type="unfinished">Exporting icon decisions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="799"/>
        <source>正在导出图元</source>
        <translation type="unfinished">Exporting icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="808"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="931"/>
        <source>导出完成</source>
        <translation type="unfinished">Export completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="810"/>
        <source>图元导出成功</source>
        <translation type="unfinished">Icon export successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="816"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="939"/>
        <source>思源压缩包生成失败！</source>
        <translation type="unfinished">SHR Compressed Package failed to gen!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="842"/>
        <source>正在导入图元资源</source>
        <translation type="unfinished">Importing icon resources</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="851"/>
        <source>正在导入图元决策</source>
        <translation type="unfinished">Importing icon decisions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="860"/>
        <source>正在导入图元</source>
        <translation type="unfinished">Importing icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="868"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="1001"/>
        <source>导入完成</source>
        <translation type="unfinished">Import completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="871"/>
        <source>图元导入成功，图元信息已发生改变，再次导入请退出当前页面重新检查</source>
        <translation type="unfinished">Icon import successful; icon info changed. Please exit the current page and recheck when importing again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="892"/>
        <source>正在导出画面资源</source>
        <translation type="unfinished">Exporting graph resources</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="906"/>
        <source>正在导出画面决策</source>
        <translation type="unfinished">Exporting decisions in the graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="915"/>
        <source>正在导出画面图元</source>
        <translation type="unfinished">Exporting icons in the graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="923"/>
        <source>正在导出画面</source>
        <translation type="unfinished">Exporting graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="933"/>
        <source>画面导出成功</source>
        <translation type="unfinished">Graph export successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="965"/>
        <source>正在导入画面以及画面图元资源</source>
        <translation type="unfinished">Importing graphs and their icon resources</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="974"/>
        <source>正在导入画面以及画面图元决策</source>
        <translation type="unfinished">Importing graphs and their icon decisions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="983"/>
        <source>正在导入画面图元</source>
        <translation type="unfinished">Importing icons in the graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="992"/>
        <source>正在导入画面</source>
        <translation type="unfinished">Importing graphs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="1003"/>
        <source>画面导入成功，画面信息已发生改变，再次导入请退出当前页面重新检查</source>
        <translation type="unfinished">Graph import successful, graph info has changed. Please exit the current page and recheck when importing again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="1052"/>
        <source>发布画面</source>
        <translation type="unfinished">Publish graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="1052"/>
        <source>是否发布已导入成功的画面，请确认</source>
        <translation type="unfinished">Please confirm whether to publish the successfully imported graphs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="1058"/>
        <source>画面信息已发生改变，再次导入请退出当前页面重新检查</source>
        <translation type="unfinished">Graph info has changed. Please exit the current page and recheck when importing again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_dialog.cpp" line="1077"/>
        <source>导出成功，导出包路径为：%1</source>
        <translation type="unfinished">Export successful, the export package path is: %1</translation>
    </message>
</context>
<context>
    <name>ImpExpCheckTableWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1750"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1753"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1756"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1759"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1771"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1774"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1777"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1780"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1750"/>
        <source>待导入资源文件路径</source>
        <translation type="unfinished">Path of resource file to be imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1750"/>
        <source>待导入资源校检</source>
        <translation type="unfinished">Verification of resources to be imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1750"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1753"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1756"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1759"/>
        <source>导入结果</source>
        <translation type="unfinished">Import results</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1753"/>
        <source>待导入决策名称</source>
        <translation type="unfinished">Decision name to be imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1753"/>
        <source>待导入决策校检</source>
        <translation type="unfinished">Verification of decisions to be imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1756"/>
        <source>待导入图元名称</source>
        <translation type="unfinished">Name of the icon to be imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1756"/>
        <source>待导入图元校检</source>
        <translation type="unfinished">Verification of icons to be imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1759"/>
        <source>源导入画面名称</source>
        <translation type="unfinished">Source import graph name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1759"/>
        <source>待导入画面校检</source>
        <translation type="unfinished">Verification of graphs to be imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1771"/>
        <source>待导出资源文件路径</source>
        <translation type="unfinished">Path of resource file to be exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1771"/>
        <source>待导出资源校检</source>
        <translation type="unfinished">Verification of resources to be exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1771"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1774"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1777"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1780"/>
        <source>导出结果</source>
        <translation type="unfinished">Export results</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1774"/>
        <source>待导出决策名称</source>
        <translation type="unfinished">Decision name to be exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1774"/>
        <source>待导出决策校检</source>
        <translation type="unfinished">Verification of decisions to be exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1777"/>
        <source>待导出图元名称</source>
        <translation type="unfinished">Name of the icon to be exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1777"/>
        <source>待导出图元校检</source>
        <translation type="unfinished">Verification of icons to be exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1780"/>
        <source>源导出画面名称</source>
        <translation type="unfinished">Source export graph name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1780"/>
        <source>待导出画面校检</source>
        <translation type="unfinished">Verification of graphs to be exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1932"/>
        <source>未导入</source>
        <translation type="unfinished">Not imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1948"/>
        <source>未导出</source>
        <translation type="unfinished">Not exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1988"/>
        <source>导入成功</source>
        <translation type="unfinished">Import successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1988"/>
        <source>导出成功</source>
        <translation type="unfinished">Export successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1993"/>
        <source>跳过导入</source>
        <translation type="unfinished">Skip import</translation>
    </message>
</context>
<context>
    <name>ImpExpDecisionCheckWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="1020"/>
        <source>决策列表</source>
        <translation type="unfinished">Decision list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="1112"/>
        <source>决策已存在，是否覆盖</source>
        <translation type="unfinished">Already exists; whether to overwrite</translation>
    </message>
</context>
<context>
    <name>ImpExpEditCommonDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3488"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3495"/>
        <source>导入导出工具</source>
        <translation type="unfinished">Import/Export Tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3545"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3546"/>
        <source>界面</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Interface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3553"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3554"/>
        <source>操作记录</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Operation record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3566"/>
        <source>画面导入</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Graph import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3567"/>
        <source>画面导出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Graph export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3571"/>
        <source>图元导入</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Icon import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3572"/>
        <source>图元导出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Icon export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3597"/>
        <source>画面</source>
        <translation type="unfinished">Graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3597"/>
        <source>图元</source>
        <translation type="unfinished">Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3599"/>
        <source>正在启动%1导入工具</source>
        <translation type="unfinished">Starting %1 Import Tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3607"/>
        <source>正在启动%1导出工具</source>
        <translation type="unfinished">Starting %1 Export Tool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3653"/>
        <source>画面导出记录</source>
        <translation type="unfinished">Graph export record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3657"/>
        <source>图元导出记录</source>
        <translation type="unfinished">Icon export record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3661"/>
        <source>图元导入记录</source>
        <translation type="unfinished">Icon import record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3665"/>
        <source>画面导入记录</source>
        <translation type="unfinished">Graph import record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3669"/>
        <source>未知记录</source>
        <translation type="unfinished">Unknown record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3604"/>
        <source>%1导入工具启动完成</source>
        <translation type="unfinished">%1 Import Tool started successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3612"/>
        <source>%1导出工具启动完成</source>
        <translation type="unfinished">%1 Export Tool started successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3622"/>
        <source>导入导出工具操作详情</source>
        <translation type="unfinished">Operation details of Import and Export tools</translation>
    </message>
</context>
<context>
    <name>ImpExpEditMainDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="172"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="173"/>
        <source>导入导出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Import and export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="180"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="181"/>
        <source>操作记录</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Operation record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="105"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="106"/>
        <source>画面导入</source>
        <translation type="unfinished">Graph import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="110"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="111"/>
        <source>画面导出</source>
        <translation type="unfinished">Graph export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="115"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="116"/>
        <source>图元导入</source>
        <translation type="unfinished">Icon import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="120"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="121"/>
        <source>图元导出</source>
        <translation type="unfinished">Icon export</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="227"/>
        <source>正在加载画面导入界面</source>
        <translation type="unfinished">Loading graph import interface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="244"/>
        <source>画面导入界面加载完成</source>
        <translation type="unfinished">Graph import interface loading completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="249"/>
        <source>正在加载图元导入界面</source>
        <translation type="unfinished">Loading icon import interface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="265"/>
        <source>图元导入界面加载完成</source>
        <translation type="unfinished">Icon import interface has been loaded and completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="270"/>
        <source>正在加载画面导出界面</source>
        <translation type="unfinished">Loading graph export interface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="290"/>
        <source>画面导出界面加载完成</source>
        <translation type="unfinished">Graph export interface loading completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="294"/>
        <source>正在加载图元导出界面</source>
        <translation type="unfinished">Loading icon export interface</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="314"/>
        <source>图元导出界面加载完成</source>
        <translation type="unfinished">Icon export interface loaded successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="340"/>
        <source>导入类型错误，非画面导入包或者图元导入包</source>
        <translation type="unfinished">Import type error, it is not graph or icon import package</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="374"/>
        <source>类型错误</source>
        <translation type="unfinished">Type error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="389"/>
        <source>导入类型错误，非画面导入前检查或者图元导入前检查</source>
        <translation type="unfinished">Import type error, it is not graph or icon check before importing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="403"/>
        <source>导入类型错误，非画面导出前检查或者图元导出前检查</source>
        <translation type="unfinished">Import type error, check before exporting non graph or icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="489"/>
        <source>导入导出操作详情</source>
        <translation type="unfinished">Details of Import and Export Operations</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="517"/>
        <source>画面导出记录</source>
        <translation type="unfinished">Graph export record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="521"/>
        <source>图元导出记录</source>
        <translation type="unfinished">Icon export record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="525"/>
        <source>图元导入记录</source>
        <translation type="unfinished">Icon import record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="529"/>
        <source>画面导入记录</source>
        <translation type="unfinished">Graph import record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="533"/>
        <source>未知记录</source>
        <translation type="unfinished">Unknown record</translation>
    </message>
</context>
<context>
    <name>ImpExpIconCheckWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1411"/>
        <source>图元列表</source>
        <translation type="unfinished">Icon list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1483"/>
        <source>图元已存在，是否覆盖</source>
        <translation type="unfinished">Already exists; whether to overwrite</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1710"/>
        <source>导入成功，</source>
        <translation type="unfinished">Import successful,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1719"/>
        <source>导入失败，</source>
        <translation type="unfinished">Import failed,</translation>
    </message>
</context>
<context>
    <name>ImpExpIconTree</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="1656"/>
        <source>图元列表</source>
        <translation type="unfinished">Icon list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="1656"/>
        <source>对象原名称</source>
        <translation type="unfinished">Original object name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="1749"/>
        <source>图元发布进度</source>
        <translation type="unfinished">Progress of icon publishing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="1760"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="1765"/>
        <source>图元节点</source>
        <translation type="unfinished">Icon nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="1760"/>
        <source>发布成功</source>
        <translation type="unfinished">Published successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="1765"/>
        <source>发布失败</source>
        <translation type="unfinished">Publish failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="1791"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="1871"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="1872"/>
        <source>图元已在节点：%1,进程号：%2,注册名：%3 中打开</source>
        <translation type="unfinished">Icon has been opened in node: %1, PID: %2, RegName: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="2095"/>
        <source>当前待导入图元[%1]在系统中已经存在，是否覆盖原图元</source>
        <translation type="unfinished">For the current icon [%1] to be imported, it already exists in the system; whether to overwrite the original icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="2096"/>
        <source>图元节点添加重复</source>
        <comment>toolName</comment>
        <translation type="unfinished">Adding Duplicate Icons</translation>
    </message>
</context>
<context>
    <name>ImpExpOperateWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1604"/>
        <source>详情</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1634"/>
        <source>是</source>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1635"/>
        <source>否</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1698"/>
        <source>原决策：</source>
        <translation type="unfinished">Original decision:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1699"/>
        <source>新决策：</source>
        <translation type="unfinished">New Decision:</translation>
    </message>
</context>
<context>
    <name>ImpExpPictureCheckWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1660"/>
        <source>画面列表</source>
        <translation type="unfinished">Graph list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1734"/>
        <source>画面已存在，是否覆盖</source>
        <translation type="unfinished">Already exists; whether to overwrite</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1982"/>
        <source>导入成功，</source>
        <translation type="unfinished">Import successful,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1991"/>
        <source>导入失败，</source>
        <translation type="unfinished">Import failed,</translation>
    </message>
</context>
<context>
    <name>ImpExpPictureTree</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="319"/>
        <source>画面列表</source>
        <translation type="unfinished">Graph list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="319"/>
        <source>对象原名称</source>
        <translation type="unfinished">Original object name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="515"/>
        <source>画面发布进度</source>
        <translation type="unfinished">Graph publish progress</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="527"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="532"/>
        <source>画面节点</source>
        <translation type="unfinished">Graph node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="527"/>
        <source>发布成功</source>
        <translation type="unfinished">Published successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="532"/>
        <source>发布失败</source>
        <translation type="unfinished">Publish failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="689"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="690"/>
        <source>画面已在节点：%1，进程号：%2,注册名：%3 中打开</source>
        <translation type="unfinished">The graph has been opened in node: %1, PID: %2, reg name: %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="948"/>
        <source>G文件错误，请修改</source>
        <translation type="unfinished">G-file error. Modify it</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="1388"/>
        <source>当前待导入画面[%1]在系统中已经存在，是否覆盖原画面</source>
        <translation type="unfinished">For the current graph [%1] to be imported, it already exists in the system; whether to overwrite the original graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="1389"/>
        <source>画面节点添加重复</source>
        <comment>toolName</comment>
        <translation type="unfinished">Adding Duplicate Graphs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="1586"/>
        <source>草稿版本</source>
        <translation type="unfinished">Draft version</translation>
    </message>
</context>
<context>
    <name>ImpExpResCheckWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="687"/>
        <source>资源列表</source>
        <translation type="unfinished">Resource list</translation>
    </message>
</context>
<context>
    <name>ImpExpSearchLayLayout</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1534"/>
        <source>请输入用于过滤的字符串</source>
        <translation type="unfinished">Please enter the string used for filtering</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1537"/>
        <source>过滤</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1544"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1573"/>
        <source>仅显示异常项</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Show abnormalities</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1568"/>
        <source>显示全部</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Show all</translation>
    </message>
</context>
<context>
    <name>ImpExportTitleBar</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/dialog_common.cpp" line="228"/>
        <source>最小化</source>
        <translation type="unfinished">Minimize</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/dialog_common.cpp" line="235"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/dialog_common.cpp" line="313"/>
        <source>最大化</source>
        <translation type="unfinished">Maximize</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/dialog_common.cpp" line="241"/>
        <source>关闭</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/dialog_common.cpp" line="319"/>
        <source>还原</source>
        <translation type="unfinished">Restore</translation>
    </message>
</context>
<context>
    <name>ImportIconWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2460"/>
        <source>请输入用于导入过滤的字符串</source>
        <translation type="unfinished">Please enter the string used for import filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2440"/>
        <source>在某个图元类型下导入(请选一个图元类型节点)</source>
        <translation type="unfinished">Import under a certain icon type (please select an icon type node)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2367"/>
        <source>导入图元</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Import icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2388"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2615"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2631"/>
        <source>显示已选导入图元</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Display the selected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2441"/>
        <source>在已有的图元树中导入</source>
        <translation type="unfinished">Import into an existing icon tree</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2481"/>
        <source>图元字典</source>
        <translation type="unfinished">Icons dictionary</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2625"/>
        <source>显示所有待导入图元</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Display all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2923"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2930"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2939"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2950"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3062"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3070"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3126"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3133"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3141"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3562"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3577"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3593"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3681"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2655"/>
        <source>当前图元[%1]与导入列表中重复，不加入列表中</source>
        <translation type="unfinished">The current icon [%1] is duplicated in the import list and will not be added to the list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2720"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2923"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3126"/>
        <source>当前导入信息为空，请重新选择导入对象</source>
        <translation type="unfinished">Empty import info. Please select one.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2939"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3141"/>
        <source>请先选择一个图元类型</source>
        <translation type="unfinished">Please select a icon type first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2960"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3164"/>
        <source>图元导入进度</source>
        <translation type="unfinished">Icon Import Progress</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3169"/>
        <source>导入完成：</source>
        <translation type="unfinished">Import completed:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3256"/>
        <source>无法获取图元节点[%1]信息</source>
        <translation type="unfinished">Unable to retrieve info about the icon node [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3265"/>
        <source>根据图元节点[%1]获取层级目录失败</source>
        <translation type="unfinished">Failed to retrieve the hierarchical dir based on the icon node [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3368"/>
        <source>图元[%1]资源文件索引[%2]解析失败</source>
        <translation type="unfinished">Icon [%1] resource file index [%2] parsing failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3537"/>
        <source>选择文件</source>
        <translation type="unfinished">Select file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2374"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2375"/>
        <source>请输入用于导入过滤的字符串（会保留已勾选图元信息）</source>
        <translation type="unfinished">Please enter the string used for import filter (retain the checked icons info)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2378"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2463"/>
        <source>过滤</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2384"/>
        <source>已选导入图元</source>
        <translation type="unfinished">Selected icons to be imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2404"/>
        <source>原文件:</source>
        <translation type="unfinished">Original file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2409"/>
        <source>请选择一个用于图元导入的思源压缩包</source>
        <translation type="unfinished">Please select a Sieyuan compressed package for importing icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2413"/>
        <source>选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2433"/>
        <source>请先勾选左侧待导入图元列表中需要被导入的图元</source>
        <translation type="unfinished">please first check the icons to be imported on the left</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2434"/>
        <source>选择一种导入方式</source>
        <translation type="unfinished">Choose an import method </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2444"/>
        <source>导入前检查</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Check &amp; import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2455"/>
        <source>导入位置</source>
        <translation type="unfinished">Import location</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2469"/>
        <source>重新加载图元列表</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Reload icon list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2838"/>
        <source>导入前检查错误</source>
        <translation type="unfinished">Check &amp;&amp; import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2727"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2930"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3133"/>
        <source>当前待导入图元数量为0，请在待导入图元列表中勾选需要被导入的图元</source>
        <translation type="unfinished">For the current icons to be imported, the count is 0; please check the icons to be imported in the list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2950"/>
        <source>获取的导入图元类型名称错误</source>
        <translation type="unfinished">The retrieved type name of the imported icon is incorrect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2707"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2969"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3671"/>
        <source>图元指针错误</source>
        <translation type="unfinished">Icon pointer error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2437"/>
        <source>当前按照图元的导出路径将图元导入到下方图元树中</source>
        <translation type="unfinished">Import icons into the icon tree below, according to the icon export path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2777"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2879"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3015"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3081"/>
        <source>图元[%1]无法获取原始图元信息</source>
        <translation type="unfinished">Icon [%1] cannot obtain original icon info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2807"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3045"/>
        <source>图元[%1]无法获取文件路径</source>
        <translation type="unfinished">Icon [%1] cannot retrieve file path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2822"/>
        <source>数据校验成功</source>
        <translation type="unfinished">Data verification successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2850"/>
        <source>图元导入前检查清除成功</source>
        <translation type="unfinished">Check and clear successfully before importing icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="2853"/>
        <source>图元导入前检查列表不存在</source>
        <translation type="unfinished">The pre-import checklist for icons does not exist.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3070"/>
        <source>操作成功！</source>
        <translation type="unfinished">Operation successful!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3193"/>
        <source>当前待导入图元[%1]导入失败，请确认是否导入剩余未导入的图元</source>
        <translation type="unfinished">For the current icon [%1] to be imported, the import failed; please confirm whether to import the remaining icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3194"/>
        <source>图元导入失败</source>
        <comment>toolName</comment>
        <translation type="unfinished">Icon Import Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3195"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3196"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3226"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3442"/>
        <source>导入失败，</source>
        <translation type="unfinished">Import failed,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3278"/>
        <source>根据图元节点[%1]获取文件信息失败</source>
        <translation type="unfinished">Failed to retrieve file info based on the icon node [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3317"/>
        <source>当前待导入图元[%1]在系统中已经存在，是否覆盖原图元</source>
        <translation type="unfinished">For the current icon [%1] to be imported, it already exists in the system; whether to overwrite the original icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3318"/>
        <source>图元节点添加重复</source>
        <comment>toolName</comment>
        <translation type="unfinished">Adding Duplicate Icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3350"/>
        <source>当前图元[%1]已存在,跳过图元导入</source>
        <translation type="unfinished">Icon [%1] already exists, skip import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3359"/>
        <source>当前图元[%1]已存在,导入覆盖原图元</source>
        <translation type="unfinished">Icon [%1] already exists; import will overwrite original icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3385"/>
        <source>图元资源导入失败,该图元[%1]导入失败</source>
        <translation type="unfinished">Icon resource import failed; icon [%1] import failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3397"/>
        <source>在图元[%1]里:</source>
        <translation type="unfinished">In icon [%1]:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3435"/>
        <source>导入成功</source>
        <translation type="unfinished">Import successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3453"/>
        <source>共%1项（%2项成功，%3项跳过，%4项失败，%5未导入）。</source>
        <translation type="unfinished">Total: %1 (%2 succeeded, %3 skipped, %4 failed, %5 not imported).</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3465"/>
        <source>导入完成</source>
        <translation type="unfinished">Import completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3511"/>
        <source>导入包设置成功</source>
        <translation type="unfinished">Import package settings successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3516"/>
        <source>导入包格式错误，后缀名不是.shrzip</source>
        <translation type="unfinished">Import package format error, suffix is not. shrzip</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3533"/>
        <source>思弘瑞压缩格式%1</source>
        <translation type="unfinished">SHR compression format %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3475"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3547"/>
        <source>思源压缩包[%1]设置成功。正在解压缩文件...</source>
        <translation type="unfinished">SHR Compressed Package [%1] set successfully. Extracting files ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3482"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3554"/>
        <source>思源压缩包解压成功。设置当前导入目录为</source>
        <translation type="unfinished">SHR Compressed Package extracted successfully. Set the current import dir to:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3488"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3560"/>
        <source>思源压缩包[%1]解压缩失败，导入异常</source>
        <translation type="unfinished">SHR Compressed Package [%1] failed to extract, import exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3506"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3591"/>
        <source>导入文件中没有可用的导入项，导入异常</source>
        <translation type="unfinished">No available import items found in the file. Import failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3614"/>
        <source>获取待导入包配置[%1]数据失败</source>
        <translation type="unfinished">Failed to retrieve config data for package to be imported [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3619"/>
        <source>当前待导入配置非图元类型[%1]</source>
        <translation type="unfinished">For the current config to be imported: it is not icon type [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3626"/>
        <source>无法获取到图元文件，待导入包错误</source>
        <translation type="unfinished">Unable to retrieve icon file; import package error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3648"/>
        <source>正在加载导入图元</source>
        <translation type="unfinished">Loading imported icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3681"/>
        <source>当前图元[%1]翻译重名,图元OID[%2]</source>
        <translation type="unfinished">The current icon [%1] has a duplicate translation name, icon OID [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3699"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3764"/>
        <source>当前总导入[%1]项，其中[%2]加载图元列表失败，跳过导入</source>
        <translation type="unfinished">The current total imported items are [%1], of which [ %2] failed to load the icon list, skipping the import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3701"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3766"/>
        <source>加载列表失败</source>
        <translation type="unfinished">Loading list failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="3817"/>
        <source>图元节点[%1]与图元路径[%2]不匹配</source>
        <translation type="unfinished">Icon node [%1] does not match icon path [%2]</translation>
    </message>
</context>
<context>
    <name>ImportPictureWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2614"/>
        <source>请输入用于导入过滤的字符串</source>
        <translation type="unfinished">Please enter the string used for import filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2561"/>
        <source>请选择一个用于画面导入的思源压缩文件</source>
        <translation type="unfinished">Please select a Sieyuan compressed file for importing graphs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2565"/>
        <source>选择对象</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2591"/>
        <source>在某个画面类型下导入(请选一个画面类型节点)</source>
        <translation type="unfinished">Import under a certain graph type (please select a graph type node)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2592"/>
        <source>在已有的画面树中导入</source>
        <translation type="unfinished">Import from an existing graph tree</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2634"/>
        <source>画面字典</source>
        <translation type="unfinished">Graph dict</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2696"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3940"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3969"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4332"/>
        <source>草稿版本</source>
        <translation type="unfinished">Draft version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2700"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3935"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3973"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4336"/>
        <source>最新版本</source>
        <translation type="unfinished">Latest version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2704"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3977"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4340"/>
        <source>历史版本%1</source>
        <translation type="unfinished">Historical version %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2728"/>
        <source>当前版本%1</source>
        <translation type="unfinished">Current version %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2750"/>
        <source>当前版本(%1)</source>
        <translation type="unfinished">Current version (%1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2717"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2958"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2965"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2979"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2989"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3134"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3142"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3261"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3268"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3276"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3300"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3820"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4106"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4114"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4122"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2519"/>
        <source>导入画面</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Import graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2540"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2656"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2672"/>
        <source>显示已选导入画面</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Display the selected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2597"/>
        <source>导入前检查</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Check &amp; import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2666"/>
        <source>显示所有待导入画面</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Display all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2717"/>
        <source>当前画面[%1]与导入列表中重复，不加入列表中</source>
        <translation type="unfinished">The current graph [%1] is duplicated in the import list and will not be added to the list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2783"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2958"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3261"/>
        <source>当前导入信息为空，请重新选择导入对象</source>
        <translation type="unfinished">Empty import info. Please select one.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2979"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3276"/>
        <source>请先选择一个画面类型</source>
        <translation type="unfinished">Please select a graph type first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3300"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3301"/>
        <source>决策类空指针异常</source>
        <translation type="unfinished">Decision class null pointer exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3326"/>
        <source>导入完成：</source>
        <translation type="unfinished">Import completed:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3417"/>
        <source>无法获取画面节点[%1]信息</source>
        <translation type="unfinished">The info of the graph node [%1] cannot be retrieved</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3426"/>
        <source>画面节点[%1]匹配原始Oid[%2]失败</source>
        <translation type="unfinished">Graph node [%1] failed to match original Oid [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3435"/>
        <source>根据画面节点[%1]获取画面文件信息失败</source>
        <translation type="unfinished">Failed to retrieve graph file info based on graph node [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3462"/>
        <source>根据画面原始OID[%1]获取画面名称失败</source>
        <translation type="unfinished">Failed to retrieve the graph name based on the original OID [%1] of the graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3538"/>
        <source>画面[%1]资源文件索引[%2]解析失败</source>
        <translation type="unfinished">Graph [%1] resource file index [%2] parsing failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3666"/>
        <source>发布画面</source>
        <translation type="unfinished">Publish graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3666"/>
        <source>是否发布已导入成功的画面，请确认</source>
        <translation type="unfinished">Please confirm whether to publish the successfully imported graphs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3934"/>
        <source>当前版本(最新版本)</source>
        <translation type="unfinished">Current version (latest version)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3941"/>
        <source>当前版本(草稿版本)</source>
        <translation type="unfinished">Current version (Draft version)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4064"/>
        <source>选择文件</source>
        <translation type="unfinished">Select file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2525"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2526"/>
        <source>请输入用于导入过滤的字符串（会保留已勾选画面信息）</source>
        <translation type="unfinished">Please enter the string used for import filter (retain the checked graphs info)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2530"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2618"/>
        <source>过滤</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2536"/>
        <source>已选导入画面</source>
        <translation type="unfinished">Selected graphs to be imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2556"/>
        <source>原文件:</source>
        <translation type="unfinished">Original file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2585"/>
        <source>请先勾选左侧待导入画面列表中需要被导入的画面</source>
        <translation type="unfinished">please first check the graphs to be imported on the left</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2586"/>
        <source>选择一种导入方式</source>
        <translation type="unfinished">Choose an import method </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2593"/>
        <source>在某个画面应用类型下导入(请选一个应用类型)</source>
        <translation type="unfinished">Import under a certain graph App type (please select an App type)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2609"/>
        <source>导入位置</source>
        <translation type="unfinished">Import location</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2624"/>
        <source>重新加载画面列表</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Reload graph list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2933"/>
        <source>导入前检查错误</source>
        <translation type="unfinished">Check &amp;&amp; import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2790"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2965"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3268"/>
        <source>当前待导入画面数量为0，请在待导入画面列表中勾选需要被导入的画面</source>
        <translation type="unfinished">For the current graphs to be imported, the count is 0; please check the graphs that need to be imported in the graph list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2989"/>
        <source>请先选择一个应用类型</source>
        <translation type="unfinished">Please select an App type first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3003"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3323"/>
        <source>画面导入进度</source>
        <translation type="unfinished">Graph Import Progress</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2769"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3012"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3810"/>
        <source>画面指针错误</source>
        <translation type="unfinished">Graph pointer error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2595"/>
        <source>当前按照画面的导出路径将画面导入到下方画面树中</source>
        <translation type="unfinished">Import graphs into graph tree below, according to the export path of graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2843"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3061"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3153"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3216"/>
        <source>画面[%1]无法获取原始画面信息</source>
        <translation type="unfinished">Graph [%1] unable to obtain original graph info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2916"/>
        <source>数据校验成功</source>
        <translation type="unfinished">Data verification successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2945"/>
        <source>画面导入前检查列表清除成功</source>
        <translation type="unfinished">Check list cleared successfully before importing graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="2948"/>
        <source>画面导入前检查列表不存在</source>
        <translation type="unfinished">The pre-import checklist for the graph does not exist.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3142"/>
        <source>操作成功！</source>
        <translation type="unfinished">Operation successful!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3315"/>
        <source>该导入包里面没有图元文件</source>
        <translation type="unfinished">Import package: no icon files.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3351"/>
        <source>当前待导入画面[%1]导入失败，请确认是否导入剩余未导入的画面</source>
        <translation type="unfinished">For the current graph [%1] to be imported: the import failed; please confirm whether to import the remaining graphs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3352"/>
        <source>画面导入失败</source>
        <comment>toolName</comment>
        <translation type="unfinished">Graph Import Failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3353"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3354"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3384"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3647"/>
        <source>导入失败，</source>
        <translation type="unfinished">Import failed,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3487"/>
        <source>当前待导入画面[%1]在系统中已经存在，是否覆盖原画面</source>
        <translation type="unfinished">For the current graph [%1] to be imported, it already exists in the system; whether to overwrite the original graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3488"/>
        <source>画面节点添加重复</source>
        <comment>toolName</comment>
        <translation type="unfinished">Adding Duplicate Graphs</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3520"/>
        <source>当前画面[%1]已存在,跳过画面导入</source>
        <translation type="unfinished">Graph [%1] already exists; skipping graph import.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3529"/>
        <source>当前画面[%1]已存在,导入覆盖原画面</source>
        <translation type="unfinished">Graph [%1] already exists, import will overwrite the original graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3563"/>
        <source>在画面节点[%1]里</source>
        <translation type="unfinished">In graph node [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3640"/>
        <source>导入成功</source>
        <translation type="unfinished">Import successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3658"/>
        <source>共%1项（%2项成功，%3项跳过，%4项失败，%5未导入）。</source>
        <translation type="unfinished">Total: %1 (%2 succeeded, %3 skipped, %4 failed, %5 not imported).</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3688"/>
        <source>导入完成</source>
        <translation type="unfinished">Import completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3732"/>
        <source>获取待导入包配置[%1]数据失败</source>
        <translation type="unfinished">Failed to retrieve config data for package to be imported [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3737"/>
        <source>当前待导入配置非画面类型[%1]</source>
        <translation type="unfinished">For the current config to be imported, it is not graph type [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3745"/>
        <source>无法获取到画面文件，导入包错误</source>
        <translation type="unfinished">Unable to retrieve graph file, import package error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3767"/>
        <source>正在加载导入画面</source>
        <translation type="unfinished">Loading import graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="3820"/>
        <source>当前画面[%1]翻译重名,画面OID[%2]</source>
        <translation type="unfinished">Current graph [%1] has a duplicate translation name, graph OID [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4039"/>
        <source>导入包设置成功</source>
        <translation type="unfinished">Import package settings successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4044"/>
        <source>导入包格式错误，后缀名不是.shrzip</source>
        <translation type="unfinished">Import package format error, suffix is not .shrzip</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4060"/>
        <source>思弘瑞压缩格式%1</source>
        <translation type="unfinished">SHR compression format %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4011"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4091"/>
        <source>思源压缩包[%1]设置成功。正在解压缩文件...</source>
        <translation type="unfinished">SHR Compressed Package [%1] set successfully. Extracting files ...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4018"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4098"/>
        <source>思源压缩包解压成功。设置当前导入目录为</source>
        <translation type="unfinished">SHR Compressed Package extracted successfully. Set the current import dir to:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4024"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4104"/>
        <source>思源压缩包[%1]解压缩失败，导入异常</source>
        <translation type="unfinished">SHR Compressed Package [%1] failed to extract, import exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4473"/>
        <source>画面[%1]资源文件[%2]已经被成功导入过</source>
        <translation type="unfinished">Graph [%1] Resource file [%2] has been successfully imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4486"/>
        <source>当前待导入画面[%1]的资源文件[%2]导入重复，是否覆盖</source>
        <translation type="unfinished">For the current graph [%1] to be imported, its resource file [%2] is duplicated; whether to overwrite it?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4521"/>
        <source>画面[%1]资源文件拷贝成功，原文件[%2]，目标文件[%3]</source>
        <translation type="unfinished">Graph [%1] resource file copied successfully; original: [%2]; destination: [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4540"/>
        <source>画面[%1]资源文件拷贝失败，原文件[%2]，目标文件[%3]</source>
        <translation type="unfinished">Graph [%1] resource file copy failed; original: [%2]; destination: [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4551"/>
        <source>当前待导入画面[%1]导入完成</source>
        <translation type="unfinished">For the current graph [%1] to be imported, the export succeeded</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4035"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4120"/>
        <source>导入文件中没有可用的导入项，导入异常</source>
        <translation type="unfinished">No available import items found in the file. Import failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4349"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4364"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4374"/>
        <source>,</source>
        <translation type="unfinished">,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4465"/>
        <source>原文件[%1]不存在</source>
        <translation type="unfinished">Original file [%1] does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4487"/>
        <source>画面资源文件重复</source>
        <comment>toolName</comment>
        <translation type="unfinished">Duplicate Graph Resource Files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4528"/>
        <source>画面[%1]资源目录文件[%2]不存在</source>
        <translation type="unfinished">Graph [%1] resource dir file [%2] does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="4534"/>
        <source>画面[%1]资源本地文件[%2]删除失败</source>
        <translation type="unfinished">Graph [%1] Resource local file [%2] deletion failed</translation>
    </message>
</context>
<context>
    <name>ImportTableWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="756"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="756"/>
        <source>%1路径</source>
        <translation type="unfinished">%1 path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="756"/>
        <source>%1名称</source>
        <translation type="unfinished">%1 name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="756"/>
        <source>导入结果</source>
        <translation type="unfinished">Import results</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="780"/>
        <source>画面</source>
        <translation type="unfinished">Graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="783"/>
        <source>图元</source>
        <translation type="unfinished">Icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="845"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1364"/>
        <source>未导入</source>
        <translation type="unfinished">Not imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1098"/>
        <source>删除对象</source>
        <translation type="unfinished">Delete object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1098"/>
        <source>即将删除所选对象，请确认</source>
        <translation type="unfinished">The selected object is about to be deleted, please confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1465"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1510"/>
        <source>添加并发布%1[%2]节点成功</source>
        <translation type="unfinished">Node [%1][%2] added and published successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1468"/>
        <source>添加%1[%2]节点错误</source>
        <translation type="unfinished">Error in adding node %1 [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1471"/>
        <source>获取%1[%2]完整路径错误</source>
        <translation type="unfinished">Error getting full path of %1[%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1486"/>
        <source>删除%1[%2]节点失败</source>
        <translation type="unfinished">Failed to delete node %1[%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1489"/>
        <source>添加%1[%2]节点库失败</source>
        <translation type="unfinished">Failed to add node DB %1[%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1492"/>
        <source>添加%1[%2]节点文件失败</source>
        <translation type="unfinished">Failed to add node file %1[%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1495"/>
        <source>拷贝%1[%2]节点文件失败</source>
        <translation type="unfinished">Failed to copy node file %1[%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1498"/>
        <source>创建%1[%2]节点文件目录失败</source>
        <translation type="unfinished">Failed to create file dir of node %1 [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1507"/>
        <source>发布%1[%2]节点失败</source>
        <translation type="unfinished">Failed to publish node %1[%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1474"/>
        <source>%1[%2]节点空指针</source>
        <translation type="unfinished">%1 [%2] node null pointer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1477"/>
        <source>%1[%2]版本信息为空</source>
        <translation type="unfinished">The version info of %1 [%2] is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1480"/>
        <source>%1[%2]版本文件不存在</source>
        <translation type="unfinished">%1 [%2] version file does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1483"/>
        <source>获取%1[%2]节点信息失败</source>
        <translation type="unfinished">Failed to retrieve the node info of %1 [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1501"/>
        <source>%1[%2]节点文件跳过</source>
        <translation type="unfinished">%1 [%2] node files skipped</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/common/widget_common.cpp" line="1504"/>
        <source>%1[%2]节点与父节点类型不匹配</source>
        <translation type="unfinished">The type of %1 [%2] node does not match the type of parent node</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="1788"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4836"/>
        <source>发布成功%1,项，发布失败%2项</source>
        <translation type="unfinished">Successfully published %1 items, failed to publish %2 items</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="2770"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="2887"/>
        <source>草稿版本</source>
        <comment>PictureItem::displayChildren</comment>
        <translation type="unfinished">Draft version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="2815"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="2903"/>
        <source>最新版本</source>
        <comment>PictureItem::displayChildren</comment>
        <translation type="unfinished">Latest version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="2931"/>
        <source>历史版本</source>
        <comment>PictureItem::displayChildren</comment>
        <translation type="unfinished">History version</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="2989"/>
        <source>版本%1</source>
        <comment>HistoryItem::displayChildren</comment>
        <translation type="unfinished">Version %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3435"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3447"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="60"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="72"/>
        <source>信息</source>
        <translation type="unfinished">Info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3438"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="63"/>
        <source>告警</source>
        <translation type="unfinished">Alarm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3441"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="66"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_edit_common_dialog.cpp" line="3444"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_main_dialog.cpp" line="69"/>
        <source>缺陷</source>
        <translation type="unfinished">Defect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="90"/>
        <source>图元资源文件重复</source>
        <comment>toolName</comment>
        <translation type="unfinished">Duplicate Icon Resource Files</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="135"/>
        <source>图元[%1]资源本地文件[%2]删除失败</source>
        <translation type="unfinished">Icon [%1] resource local file [%2] deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="89"/>
        <source>当前待导入图元[%1]的资源文件[%2]导入重复，是否覆盖原资源文件</source>
        <translation type="unfinished">For the current icon [%1] to be imported, its resource file [%2] is duplicated; whether to overwrite the original resource file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="154"/>
        <source>图元[%1]的资源文件[%2]无法获取</source>
        <translation type="unfinished">For the icon [%1], the resource file [%2] could not be retrieved</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="161"/>
        <source>图元[%1]资源文件获取为空</source>
        <translation type="unfinished">Retrieved icon [%1] resource file is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="820"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="914"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="314"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="408"/>
        <source>决策[%1]导入失败</source>
        <translation type="unfinished">Decision [%1] import failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="840"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="333"/>
        <source>当前待导入的新决策[%1]与系统中的原决策存在差异，是否使用新决策</source>
        <translation type="unfinished">For the current new decision [%1] to be imported, it differs from the original decision in the system; whether to use the new decision</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="845"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="338"/>
        <source>决策拷贝重复</source>
        <comment>toolName</comment>
        <translation type="unfinished">Duplicate Decision Detected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4013"/>
        <source>获取画面中的图元文件名称失败，画面文件路径[%1]</source>
        <translation type="unfinished">Failed to retrieve the name of the icon file in the graph, graph file path [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4042"/>
        <source>获取画面图元层级索引文件信息失败，画面图元索引文件[%1]</source>
        <translation type="unfinished">Failed to retrieve info on the hierarchical index file of the icon, icon index file [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4050"/>
        <source>获取画面图元对应关系索引文件信息失败，画面图元索引文件[%1]</source>
        <translation type="unfinished">Failed to retrieve the index file info for the correspondence between graph and icon, icon index file [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4058"/>
        <source>图元获取数据库空指针异常</source>
        <translation type="unfinished">Exception in retrieving db null pointer for icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4087"/>
        <source>画面图元[%1]导入时被跳过，不重新导入</source>
        <translation type="unfinished">Icon [%1] skipped during import. Not re-imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4912"/>
        <source>画面图元[%1]文件拷贝失败，原文件[%2]，目标文件[%3]，该图元导出终止</source>
        <translation type="unfinished">Icon [%1] file copy failed; original: [%2]; destination: [%3]. Export aborted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4918"/>
        <source>画面图元[%1]文件拷贝成功，原文件[%2]，目标文件[%3]</source>
        <translation type="unfinished">Icon [%1] file copied successfully; original: [%2]; destination: [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4965"/>
        <source>当前待导出画面中的图元[%1]拷贝失败，原文件[%2]，目标文件[%3]</source>
        <translation type="unfinished">For the current graph to be exported, the icon [%1] failed to copy; original: [%2]; destination: [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4976"/>
        <source>当前待导出画面中的图元[%1]拷贝成功，原文件[%2]，目标文件[%3]</source>
        <translation type="unfinished">For the current graph to be exported, the icon [%1] succeeded in copying; original: [%2]; destination: [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4099"/>
        <source>当前待导入画面中的图元[%1]在系统中已经存在，是否覆盖原画面图元</source>
        <translation type="unfinished">For the current graph to be imported, the icon [%1] already exists in the system; whether to overwrite the original icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4860"/>
        <source>画面图元目录创建失败[%1]，该图元导出终止</source>
        <translation type="unfinished">Failed to create icon dir [%1]; export of this icon terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4867"/>
        <source>画面图元资源目录创建失败[%1]，该图元导出终止</source>
        <translation type="unfinished">The creation of the icon resource dir failed [%1]; export of this icon terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4876"/>
        <source>获取图元字典指针失败，该图元导出终止</source>
        <translation type="unfinished">Failed to retrieve the pointer to the icons dictionary; export of this icon terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4886"/>
        <source>获取画面图元[%1]节点信息失败，该图元导出终止</source>
        <translation type="unfinished">Failed to retrieve node info for icon [%1]; export of this icon terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4942"/>
        <source>当前待导出画面中的图元[%1]的资源文件[%2]已被成功导出过</source>
        <translation type="unfinished">For the current graph to be exported, the resource file [%2] of the icon [%1] has been successfully exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4960"/>
        <source>当前待导出画面中的图元[%1]的资源文件[%2]不存在</source>
        <translation type="unfinished">For the current graph to be exported, the resource file [%2] of the icon [%1] does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4983"/>
        <source>当前待导出画面中的图元[%1]的资源文件[%2]无法获取</source>
        <translation type="unfinished">For the current graph to be exported, the resource file [%2] of the icon [%1] could not be retrieved</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4992"/>
        <source>当前待导出画面中的图元[%1]的资源文件[%2]导出失败，该图元导出终止</source>
        <translation type="unfinished">For the current graph to be exported, the resource file [%2] of the icon [%1] failed to export; export of this icon terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="5011"/>
        <source>画面图元[%1]层级[%2]配置信息写入失败，该图元导出终止</source>
        <translation type="unfinished">Failed to write config info for icon [%1] level [%2]; export of this icon terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="5017"/>
        <source>画面图元[%1]对应关系[%2]配置信息写入失败，该图元导出终止</source>
        <translation type="unfinished">Icon [%1] correspondence relationship [%2] config info writing failed; export of this icon terminated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4160"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4169"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4179"/>
        <source>画面文件[%1]中的图元[%2]没有被导出</source>
        <translation type="unfinished">Graph [%1] icon [%2] was not exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="121"/>
        <source>图元[%1]资源文件拷贝成功，原文件[%2]，目标文件[%3]</source>
        <translation type="unfinished">Icon [%1] resource file copied successfully; original: [%2]; destination: [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="129"/>
        <source>图元[%1]资源目录原文件[%2]不存在</source>
        <translation type="unfinished">Original file [%2] not found in Icon [%1] resource dir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="141"/>
        <source>图元[%1]资源文件拷贝失败，原文件[%2]，目标文件[%3]</source>
        <translation type="unfinished">Failed to copy Icon [%1] resource file; original: [%2]; destination: [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="147"/>
        <source>图元[%1]资源文件拷贝未知错误，原文件[%2]，目标文件[%3]</source>
        <translation type="unfinished">Unknown error copying Icon [%1] resource file; original: [%2]; destination: [%3]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4081"/>
        <source>画面文件[%1]中的图元[%2]已经被成功导入过</source>
        <translation type="unfinished">In graph file [%1], icon [%2] has been successfully imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="51"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4343"/>
        <source>图元[%1]与层级[%2]信息不匹配</source>
        <translation type="unfinished">Icon [%1] does not match level [%2] info</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4352"/>
        <source>图元[%1]获取数据库空指针异常</source>
        <translation type="unfinished">Icon [%1] encountered a DB null pointer exception</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="123"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4421"/>
        <source>图元类型[%1]添加失败</source>
        <translation type="unfinished">Failed to add icon type [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="164"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4493"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4540"/>
        <source>旧图元[%1]重复，删除失败</source>
        <translation type="unfinished">Duplicate old Icon [%1]; deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="217"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4555"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4585"/>
        <source>图元[%1]添加失败</source>
        <translation type="unfinished">Icon [%1] failed to add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="257"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4624"/>
        <source>图元[%1]添加成功</source>
        <translation type="unfinished">Icon [%1] added successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="262"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4629"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4634"/>
        <source>图元[%1]发布失败</source>
        <translation type="unfinished">Icon [%1] failed to publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="267"/>
        <source>图元[%1]发布成功</source>
        <translation type="unfinished">Icon [%1] published successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="272"/>
        <source>图元[%1]信息获取失败</source>
        <translation type="unfinished">Failed to retrieve information for the icon [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="566"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="805"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="828"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="899"/>
        <source>图元字典获取失败</source>
        <translation type="unfinished">Failed to retrieve the icon dict</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="586"/>
        <source>在状态前景图元[%1]里：</source>
        <translation type="unfinished">In state foreground icon [%1]:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="692"/>
        <source>图元[%1]信息无法在图元列表中找到</source>
        <translation type="unfinished">Icon [%1] info cannot be found in the icon list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="735"/>
        <source>图元校检成功</source>
        <translation type="unfinished">Icon verification successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="752"/>
        <source>画面信息为空</source>
        <translation type="unfinished">Graph info is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="785"/>
        <source>画面图元[%1]决策校验错误</source>
        <translation type="unfinished">Icon [%1] decision verification error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="791"/>
        <source>画面图元[%1]资源校验错误</source>
        <translation type="unfinished">Icon [%1] resource verification error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="843"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="914"/>
        <source>图元配置文件[%1]读取失败</source>
        <translation type="unfinished">Icon config file [%1] read failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="851"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="922"/>
        <source>图元配置文件[%1]解析错误</source>
        <translation type="unfinished">Error parsing icon config file [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="883"/>
        <source>图元配置文件[%1]加载错误</source>
        <translation type="unfinished">Icon config file [%1] loading error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1115"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1219"/>
        <source>图元[%1]校验错误</source>
        <translation type="unfinished">Icon [%1] verification error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1126"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1230"/>
        <source>当前图元文件[%1]不存在</source>
        <translation type="unfinished">The current icon file [%1] does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1593"/>
        <source>资源数据信息获取失败</source>
        <translation type="unfinished">Failed to retrieve resource data information  </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1676"/>
        <source>图元数据信息获取失败</source>
        <translation type="unfinished">Icon data Information retrieval failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="237"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4604"/>
        <source>原图元文件[%1]到目标图元文件[%2]拷贝失败</source>
        <translation type="unfinished">Failed to copy original icon file [%1] to destination [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="192"/>
        <source>图模图元[%1]已被添加过</source>
        <translation type="unfinished">The icon [%1] has already been added</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="178"/>
        <source>旧图元[%1]删除成功，新图元添加失败</source>
        <translation type="unfinished">Old icon [%1] deleted successfully, new icon addition failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="59"/>
        <source>获取图元[%1]数据库信息失败</source>
        <translation type="unfinished">Failed to retrieve database information for icon [%1]  </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="203"/>
        <source>旧图元[%1]重复，导入失败</source>
        <translation type="unfinished">Old icon [%1] duplicated, import failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="705"/>
        <source>图元[%1]不存在</source>
        <translation type="unfinished">The icon [%1] does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1131"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1235"/>
        <source>当前图元文件拷贝失败，原文件[%1],目标文件[%2]</source>
        <translation type="unfinished">Current Icon file copy failed; original: [%1]; destination: [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1148"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1251"/>
        <source>当前图元[%1]无法在导出列表中找到</source>
        <translation type="unfinished">Current Icon [%1] not found in export list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1152"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1667"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1393"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1927"/>
        <source>导出成功</source>
        <translation type="unfinished">Export successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1183"/>
        <source>图元[%1]无法在图元列表中无法找到</source>
        <translation type="unfinished">Icon [%1] cannot be found in the icon list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1201"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1607"/>
        <source>图元目录创建失败</source>
        <translation type="unfinished">Icon dir creation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1265"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1662"/>
        <source>图元索引文件导出失败</source>
        <translation type="unfinished">Icon index file export failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1270"/>
        <source>图元索引文件导出成功</source>
        <translation type="unfinished">Icon index file exported successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1289"/>
        <source>图元原文件[%1]不存在</source>
        <translation type="unfinished">The original icon file [%1] does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1297"/>
        <source>图元原文件[%1]中无法获取图元名称</source>
        <translation type="unfinished">Unable to retrieve the name of the icon from the original icon file [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1305"/>
        <source>图元原文件[%1]中图元名称与图元节点中名称[%2]不一致</source>
        <translation type="unfinished">The name of the icon in the original file [%1] is inconsistent with the name in the icon node [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1347"/>
        <source>图元导入目录[%1]创建失败</source>
        <translation type="unfinished">Failed to create the icon import directory [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1367"/>
        <source>当前图元节点下存在重名图元[%1]，无法加载图元导入包</source>
        <translation type="unfinished">Current icon node: duplicate icon [%1]. Import package load failed.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1354"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1382"/>
        <source>图元校验成功</source>
        <translation type="unfinished">Icon verification successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1177"/>
        <source>获取图元[%1]导入信息失败</source>
        <translation type="unfinished">Failed to retrieve import information for the icon [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1280"/>
        <source>图元信息获取失败</source>
        <translation type="unfinished">Failed to obtain icon information</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1360"/>
        <source>图元在新节点中已存在</source>
        <translation type="unfinished">Icon already exists in the new node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1377"/>
        <source>节点下不存在该图元[%1]</source>
        <translation type="unfinished">Icon does not exist under the node [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1388"/>
        <source>图元[%1]在该节点中存在重名图元，无法导出</source>
        <translation type="unfinished">Icon [%1] has a duplicate name in this node and cannot be exported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1630"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1888"/>
        <source>导出失败，</source>
        <translation type="unfinished">Export failed,</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_icon.cpp" line="1697"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1970"/>
        <source>导入跳过</source>
        <translation type="unfinished">Skip import</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4100"/>
        <source>画面图元节点添加重复</source>
        <comment>toolName</comment>
        <translation type="unfinished">Adding Duplicate Icons Of Graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4132"/>
        <source>当前画面图元[%1]已存在,跳过画面图元导入</source>
        <translation type="unfinished">Icon [%1] already exists, skip importing icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4139"/>
        <source>当前画面图元[%1]已存在,导入覆盖原画面图元</source>
        <translation type="unfinished">Icon [%1] already exists; import will overwrite original icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4189"/>
        <source>画面图元[%1]资源文件索引[%2]解析失败</source>
        <translation type="unfinished">Icon [%1] resource file index [%2] parsing failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4219"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4929"/>
        <source>在画面图元[%1]里：</source>
        <translation type="unfinished">In icon [%1]:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4236"/>
        <source>该画面文件[%1]图元导入完成</source>
        <translation type="unfinished">The icon for the graph file [%1] import completed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4454"/>
        <source>当前待导入画面中的图元[%1]在系统中已经存在，是否覆盖图元</source>
        <translation type="unfinished">For the current graph to be imported, the icon [%1] already exists in the system; whether to overwrite the icon</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4455"/>
        <source>图元节点添加重复</source>
        <comment>toolName</comment>
        <translation type="unfinished">Adding Duplicate Icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4473"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4510"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4525"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4570"/>
        <source>图元[%1]重复导入时跳过</source>
        <translation type="unfinished">Skip when importing icon [%1] duplicatedly</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4639"/>
        <source>图元[%1]节点指针为空</source>
        <translation type="unfinished">Node pointer of icon [%1] is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4789"/>
        <source>图元发布进度</source>
        <translation type="unfinished">Progress of icon publishing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4808"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4813"/>
        <source>图元节点</source>
        <translation type="unfinished">Icon nodes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4808"/>
        <source>发布成功</source>
        <translation type="unfinished">Published successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4813"/>
        <source>发布失败</source>
        <translation type="unfinished">Publish failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="58"/>
        <source>目录名称已存在,创建应用类型失败</source>
        <translation type="unfinished">The dir name already exists, creating application type failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="63"/>
        <source>添加应用类型失败</source>
        <translation type="unfinished">Failed to add application type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="98"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="138"/>
        <source>该节点下画面类型已存在,创建画面类型失败</source>
        <translation type="unfinished">The graph type already exists under this node, creating the graph type failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="103"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="143"/>
        <source>画面类型添加失败</source>
        <translation type="unfinished">Graph type addition failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="210"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="621"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1351"/>
        <source>画面目录[%1]创建失败</source>
        <translation type="unfinished">Graph dir [%1] creation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="222"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="633"/>
        <source>画面文件拷贝失败,原文件[%1]，目标文件[%2]</source>
        <translation type="unfinished">Graph file copying failed, original file [%1], destination file [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="241"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="662"/>
        <source>画面导入成功</source>
        <translation type="unfinished">Graph import successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="257"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="569"/>
        <source>画面文件[%1]读取失败</source>
        <translation type="unfinished">Graph file [%1] read failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="263"/>
        <source>画面文件[%1]格式错误，无法解析</source>
        <translation type="unfinished">Graph file [%1] format error, unable to parse</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="273"/>
        <source>画面文件[%1]标识错误，无法解析</source>
        <translation type="unfinished">Graph file [%1] has an incorrect identifier and cannot be parsed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="333"/>
        <source>被添加画面节点的目录层级[%1]错误</source>
        <translation type="unfinished">The dir hierarchy [%1] of the added graph node is incorrect</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="488"/>
        <source>画面[%1]的节点重复添加失败</source>
        <translation type="unfinished">Node duplicate addition failed for graph [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="578"/>
        <source>画面[%1]删除失败</source>
        <translation type="unfinished">Graph [%1] deletion failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="597"/>
        <source>画面[%1]添加失败</source>
        <translation type="unfinished">Graph [%1] failed to add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="89"/>
        <source>获取画面类型信息失败</source>
        <translation type="unfinished">Failed to obtain graph type information</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="129"/>
        <source>获取画面类型父节点信息失败</source>
        <translation type="unfinished">Failed to obtain the information of the parent node of the graph type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="168"/>
        <source>画面信息获取失败,画面[%1]导入失败</source>
        <translation type="unfinished">Failed to obtain graph information, import of graph [%1] failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="316"/>
        <source>画面信息获取失败,画面[%1]添加失败</source>
        <translation type="unfinished">Failed to obtain graph information, failed to add graph [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="438"/>
        <source>获取画面[%1]信息失败</source>
        <translation type="unfinished">Failed to obtain information for graph [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="517"/>
        <source>获取被删除的画面[%1]信息失败</source>
        <translation type="unfinished">Failed to obtain information about the deleted graph [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="675"/>
        <source>画面获取失败，发布失败</source>
        <translation type="unfinished">Failed to capture the graph, failed to publish</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="682"/>
        <source>画面[%1]获取OID错误，发布失败</source>
        <translation type="unfinished">Graph [%1] error in retrieving OID, publishing failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="691"/>
        <source>画面[%1]获取属性错误，发布失败</source>
        <translation type="unfinished">Graph [%1] retrieved attr error, publishing failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="784"/>
        <source>导入成功，画面发布成功</source>
        <translation type="unfinished">Import successful, graph successfully published</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="809"/>
        <source>导入失败，画面发布失败</source>
        <translation type="unfinished">Import failed, graph publishing failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="831"/>
        <source>画面发布进度</source>
        <translation type="unfinished">Graph publish progress</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="864"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="546"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="1780"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4828"/>
        <source>全部发布成功</source>
        <translation type="unfinished">All successfully published</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="868"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="550"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="1784"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4832"/>
        <source>全部发布失败</source>
        <translation type="unfinished">All publishing failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="872"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="554"/>
        <source>发布成功%1项，发布失败%2项</source>
        <translation type="unfinished">Successfully published %1 items, failed to publish %2 items</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="875"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_common_tree.cpp" line="557"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="4839"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="883"/>
        <source>获取被删除画面[%1]信息失败</source>
        <translation type="unfinished">Failed to obtain information about the deleted graph [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1003"/>
        <source>画面获取失败</source>
        <translation type="unfinished">Failed to capture the graph</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1087"/>
        <source>画面导入目录[%1]创建失败</source>
        <translation type="unfinished">Failed to create the graph import directory [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1208"/>
        <source>获取导出画面信息失败</source>
        <translation type="unfinished">Failed to obtain exported graph information</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1280"/>
        <source>获取导入画面信息失败</source>
        <translation type="unfinished">Failed to obtain import graph information</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1304"/>
        <source>获取画面[%1]导入信息失败</source>
        <translation type="unfinished">Failed to obtain import information for graph [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1322"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1941"/>
        <source>获取画面发布信息失败</source>
        <translation type="unfinished">Failed to obtain the graph publishing information</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1949"/>
        <source>获取被导入画面信息失败</source>
        <translation type="unfinished">Failed to obtain the imported graph information</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1013"/>
        <source>画面原文件[%1]不存在</source>
        <translation type="unfinished">The original graph file [%1] does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1051"/>
        <source>节点下不存在该画面[%1]</source>
        <translation type="unfinished">Graph does not exist under the node [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1058"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1096"/>
        <source>画面校验成功</source>
        <translation type="unfinished">Graph verification successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1072"/>
        <source>当前节点下存在重名画面[%1]，无法加载画面导入包</source>
        <translation type="unfinished">Current node: duplicate graph [%1]. Import package load failed.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1102"/>
        <source>画面在新节点中已存在</source>
        <translation type="unfinished">The graph already exists in the new node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1110"/>
        <source>画面[%1]在新节点中存在重名画面，无法导入</source>
        <translation type="unfinished">Graph [%1] has a duplicate name in the new node and cannot be imported</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1197"/>
        <source>画面[%1]信息无法在画面列表中找到</source>
        <translation type="unfinished">Graph [%1] info cannot be found in the graph list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1220"/>
        <source>获取画面[%1]Oid失败</source>
        <translation type="unfinished">Failed to retrieve graph [%1] Oid</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1310"/>
        <source>画面[%1]无法在画面列表中无法找到</source>
        <translation type="unfinished">Graph [%1] cannot be found in the graph list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1338"/>
        <source>画面[%1]校验错误</source>
        <translation type="unfinished">Graph [%1] verification error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1358"/>
        <source>当前画面文件[%1]不存在</source>
        <translation type="unfinished">The current graph file [%1] does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1363"/>
        <source>当前画面文件拷贝失败，原文件[%1],目标文件[%2]</source>
        <translation type="unfinished">For the current graph to be exported, the copy failed; original: [%1]; destination: [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1389"/>
        <source>当前画面列表中[%1]无法在导出列表中找到</source>
        <translation type="unfinished">Graph [%1] not found in export list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1403"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1504"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1851"/>
        <source>获取画面数据失败</source>
        <translation type="unfinished">Failed to obtain graph data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1427"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1528"/>
        <source>画面配置文件[%1]读取失败</source>
        <translation type="unfinished">Graph config file [%1] loading error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1436"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1537"/>
        <source>画面配置文件[%1]解析错误</source>
        <translation type="unfinished">Graph config file [%1] loading error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1487"/>
        <source>画面配置文件[%1]加载错误</source>
        <translation type="unfinished">Graph config file [%1] loading error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1865"/>
        <source>画面目录创建失败</source>
        <translation type="unfinished">Graph dir creation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_picture.cpp" line="1922"/>
        <source>画面索引文件导出失败</source>
        <translation type="unfinished">Graph index file export failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="5027"/>
        <source>画面图元节点[%1]导出成功</source>
        <translation type="unfinished">Icon node [%1] exported successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="61"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="90"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="46"/>
        <source>图元名称为空</source>
        <translation type="unfinished">Icon name is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="219"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="295"/>
        <source>决策校验成功</source>
        <translation type="unfinished">Decision verification successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="230"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="280"/>
        <source>决策[%1]数据库查询失败</source>
        <translation type="unfinished">Decision [%1] db query failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="243"/>
        <source>新决策重名，但与原决策数据一致，校验成功</source>
        <translation type="unfinished">The new decision is duplicated, but it is consistent with the original decision data, and the verification is successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="248"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="270"/>
        <source>决策[%1]存在重名</source>
        <translation type="unfinished">Decision [%1] name is duplicated</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="256"/>
        <source>当前节点下存在重名决策[%1]，无法进行导入</source>
        <translation type="unfinished">Current node: duplicate decision [%1]. Import failed.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="265"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="311"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="337"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="363"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="389"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="571"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="591"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="611"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="631"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="651"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="671"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="673"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="693"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="713"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="733"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="753"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="773"/>
        <source>决策[%1]获取失败</source>
        <translation type="unfinished">Decision [%1] retrieval failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="289"/>
        <source>决策[%1]数据为空</source>
        <translation type="unfinished">Decision [%1] data is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="315"/>
        <source>决策[%1]校验错误</source>
        <translation type="unfinished">Decision [%1] verification error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="327"/>
        <source>当前决策[%1]无法在导出列表中找到</source>
        <translation type="unfinished">Current decision [%1] not found in export list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="366"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="383"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="405"/>
        <source>导入失败，添加新决策[%1]失败</source>
        <translation type="unfinished">Import failed, adding new decision [%1] failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="372"/>
        <source>导入失败，删除原决策[%1]失败</source>
        <translation type="unfinished">Import failed, deleting original decision [%1] failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="412"/>
        <source>导入失败，该决策[%1]无法在决策列表中找到</source>
        <translation type="unfinished">Import failed, decision [%1] cannot be found in the decision list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="430"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="1180"/>
        <source>决策目录创建失败</source>
        <translation type="unfinished">Decision dir creation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="454"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="1216"/>
        <source>决策索引文件导出失败</source>
        <translation type="unfinished">Export of decision index file failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="459"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="1221"/>
        <source>决策索引文件导出成功</source>
        <translation type="unfinished">Decision index file exported successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="478"/>
        <source>决策配置文件[%1]读取出错</source>
        <translation type="unfinished">Error reading decision config file [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="486"/>
        <source>决策配置文件[%1]格式错误</source>
        <translation type="unfinished">Format error in decision config file [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="578"/>
        <source>画面决策[%1]不在决策列表中</source>
        <translation type="unfinished">Graph decision [%1] is not in the decision list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="621"/>
        <source>图元决策[%1]不在决策列表中</source>
        <translation type="unfinished">Icon decision [%1] is not in the decision list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="636"/>
        <source>画面[%1]文件[%2]读取失败</source>
        <translation type="unfinished">Graph [%1] File [%2] read failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="643"/>
        <source>画面[%1]文件[%2]解析错误</source>
        <translation type="unfinished">Graph [%1] File [%2] parsing error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="653"/>
        <source>画面[%1]文件[%2]格式错误</source>
        <translation type="unfinished">Graph [%1] file [%2] format error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="871"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="463"/>
        <source>获取图元决策类型错误</source>
        <translation type="unfinished">Error in retrieving decision type for icons</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="901"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="493"/>
        <source>获取图元文件读取错误，文件路径：%1</source>
        <translation type="unfinished">Error reading icon file, file path: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="909"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="500"/>
        <source>获取图元文件解析错误，文件路径：%1</source>
        <translation type="unfinished">Error retrieving icon file; file path:%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="919"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_icon_widget.cpp" line="510"/>
        <source>获取图元文件格式错误，文件路径：%1</source>
        <translation type="unfinished">Error in retrieving the format of the icon file, file path: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="1166"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_decision.cpp" line="1229"/>
        <source>决策数据获取失败</source>
        <translation type="unfinished">Failed to retrieve decision data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="78"/>
        <source>画面名称为空</source>
        <translation type="unfinished">Graph name is empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="155"/>
        <source>无法获取到资源名称</source>
        <translation type="unfinished">Unable to retrieve resource name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="166"/>
        <source>当前资源文件[%1]不存在</source>
        <translation type="unfinished">The current resource file [%1] does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="202"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="825"/>
        <source>资源目录创建失败</source>
        <translation type="unfinished">Resource dir creation failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="225"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="861"/>
        <source>资源索引文件导出失败</source>
        <translation type="unfinished">Export of resource index file failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="230"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="866"/>
        <source>资源索引文件导出成功</source>
        <translation type="unfinished">Resource index file exported successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="246"/>
        <source>导入失败，当前资源文件[%1]不存在</source>
        <translation type="unfinished">Import failed, current resource file [%1] does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="171"/>
        <source>当前资源文件拷贝失败，原文件[%1],目标文件[%2]</source>
        <translation type="unfinished">Current resource file copy failed; original: [%1]; destination: [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="184"/>
        <source>当前资源文件[%1]无法在导出列表中找到</source>
        <translation type="unfinished">Current resource file [%1] not found in export list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="251"/>
        <source>导入失败，当前资源文件拷贝失败，原文件[%1],目标文件[%2]</source>
        <translation type="unfinished">Import failed. Current resource file copy failed; original: [%1]; destination: [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="261"/>
        <source>导入失败，当前资源文件[%1]无法在资源列表中找到</source>
        <translation type="unfinished">Import failed, current resource file [%1] cannot be found in the resource list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="281"/>
        <source>资源配置文件[%1]读取出错</source>
        <translation type="unfinished">Error reading resource config file [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="289"/>
        <source>资源配置文件[%1]格式解析错误</source>
        <translation type="unfinished">Error parsing resource config file [%1] format</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="381"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="429"/>
        <source>画面资源[%1]不在资源列表中</source>
        <translation type="unfinished">Graph resource [%1] is not in the resource list</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="443"/>
        <source>资源文件[%1]读取失败</source>
        <translation type="unfinished">Resource file [%1] read failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="450"/>
        <source>资源文件[%1]非xml文件</source>
        <translation type="unfinished">Resource file [%1] is not XML file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="460"/>
        <source>资源文件[%1]格式错误</source>
        <translation type="unfinished">Resource file [%1] format error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="584"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="618"/>
        <source>资源文件[%1]不存在</source>
        <translation type="unfinished">Resource file [%1] does not exist</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="594"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="602"/>
        <source>资源文件[%1]不在iasp运行目录[%2]下</source>
        <translation type="unfinished">The destination resource file [%1] is not located in the iasp running dir [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="607"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="663"/>
        <source>资源文件校验成功</source>
        <translation type="unfinished">Resource file verification successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="629"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="637"/>
        <source>目标资源文件目录[%1]不在iasp运行目录[%2]下</source>
        <translation type="unfinished">The resource dir [%1] is not located in the iasp running dir [%2]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="646"/>
        <source>无法根据目标资源文件[%1]解析目录</source>
        <translation type="unfinished">Failed to parse dir from destination resource file [%1]</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="656"/>
        <source>资源文件已存在,是否覆盖</source>
        <translation type="unfinished">Already exists; whether to overwrite</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="811"/>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/check/imp_exp_check_res.cpp" line="888"/>
        <source>获取资源数据信息失败</source>
        <translation type="unfinished">Failed to obtain resource data information</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="576"/>
        <source>画面文件[%1]解析错误</source>
        <translation type="unfinished">Graph file [%1] parsing error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_imp_exp/imp_exp_picture_widget.cpp" line="586"/>
        <source>画面文件[%1]格式错误</source>
        <translation type="unfinished">Graph file [%1] format error</translation>
    </message>
</context>
</TS>
