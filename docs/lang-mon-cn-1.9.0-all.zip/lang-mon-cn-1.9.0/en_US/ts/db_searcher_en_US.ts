<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>DbSearcherWgt</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.ui" line="63"/>
        <source>对象信息：</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Object info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.ui" line="77"/>
        <source>清除</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.ui" line="89"/>
        <source>反显</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Auto-sync display</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_dlg.cpp" line="41"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="74"/>
        <source>实时检索器</source>
        <comment>toolName</comment>
        <translation type="unfinished">Real-Time Retriever</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_dlg.cpp" line="59"/>
        <source>历史检索器</source>
        <translation type="unfinished">History Retriever</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_dlg.cpp" line="63"/>
        <source>实时检索器</source>
        <translation type="unfinished">Real-Time Retriever</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_dlg.cpp" line="159"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_dlg.cpp" line="160"/>
        <source>是否关闭检索器？</source>
        <translation type="unfinished">Whether to close the retriever?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="75"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="76"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="78"/>
        <source>数据关联</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Data link</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="79"/>
        <source>父级对象</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Parent object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="80"/>
        <source>目标对象</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Dest object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="81"/>
        <source>条件过滤</source>
        <translation type="unfinished">Condition filter</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="83"/>
        <source>字段选择</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Field Selection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="84"/>
        <source>所有字段</source>
        <translation type="unfinished">All fields</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="365"/>
        <source>无效连接</source>
        <translation type="unfinished">Invalid connection</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="365"/>
        <source>该接口不会主动连库，需要主动传入TDBConnection*</source>
        <translation type="unfinished">This interface will not actively connect to the db and needs to actively pass in TDBConnection*</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="1064"/>
        <source>未选对象</source>
        <translation type="unfinished">Unselected object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="1065"/>
        <source>还未选择对象,无效选择,是否退出操作？</source>
        <translation type="unfinished">The object has not been selected. Invalid selection. Whether to exit the operation?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="1092"/>
        <source>未选字段</source>
        <translation type="unfinished">Unselected fields</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="1093"/>
        <source>还未选择字段,无效选择,是否退出操作？</source>
        <translation type="unfinished">The field has not been selected and the selection is invalid. Whether to exit the operation?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="1167"/>
        <source>是否取消</source>
        <translation type="unfinished">Whether to cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="1168"/>
        <source>是否取消操作并退出？</source>
        <translation type="unfinished">Whether to cancel the operation and exit?</translation>
    </message>
</context>
<context>
    <name>iasp::dbms::DbSearcherWgt</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="110"/>
        <source>对象详细信息</source>
        <translation type="unfinished">Object details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="1118"/>
        <source>对象信息(%1)：</source>
        <translation type="unfinished">Object info (%1):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="1184"/>
        <source>对象信息：</source>
        <translation type="unfinished">Object info:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="1243"/>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="1244"/>
        <source>（未选字段）</source>
        <translation type="unfinished">(Unselected fields)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="1250"/>
        <source>（字段：%1...）</source>
        <translation type="unfinished">(Fields: %1...)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="1254"/>
        <source>（字段：%1）</source>
        <translation type="unfinished">(Field: %1)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/db_searcher_wgt.cpp" line="1257"/>
        <source>已选字段：%1</source>
        <translation type="unfinished">Selected field: %1</translation>
    </message>
</context>
<context>
    <name>iasp::dbms::RetInfoDialog</name>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/ret_info_dialog.cpp" line="11"/>
        <source>对象信息详情</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Object details</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/ret_info_dialog.cpp" line="30"/>
        <source>应用：</source>
        <translation type="unfinished">App:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/ret_info_dialog.cpp" line="30"/>
        <source>库：</source>
        <translation type="unfinished">DB:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/ret_info_dialog.cpp" line="30"/>
        <source>表：</source>
        <translation type="unfinished">Table:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/ret_info_dialog.cpp" line="47"/>
        <source>字段：</source>
        <translation type="unfinished">Field:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/ret_info_dialog.cpp" line="76"/>
        <source>OID</source>
        <translation type="unfinished">OID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/dbms/api/db_selector/db_searcher/ret_info_dialog.cpp" line="77"/>
        <source>条件/路径</source>
        <translation type="unfinished">Condition/Path</translation>
    </message>
</context>
</TS>
