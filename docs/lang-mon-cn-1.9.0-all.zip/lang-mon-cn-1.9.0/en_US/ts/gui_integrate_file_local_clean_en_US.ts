<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.ui" line="20"/>
        <source>DirCgfWidget</source>
        <translation type="unfinished">DirCgfWidget</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.ui" line="34"/>
        <source>节点名：</source>
        <translation type="unfinished">Node name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.ui" line="72"/>
        <source>配置模板名：</source>
        <translation type="unfinished">Config template name :</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.ui" line="93"/>
        <source>安装目录磁盘大小限制：</source>
        <translation type="unfinished">Disk size limit of installation directory :</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.ui" line="114"/>
        <source>%</source>
        <translation type="unfinished">％</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.ui" line="141"/>
        <source>新增配置</source>
        <translation type="unfinished">New Configurations</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.ui" line="155"/>
        <source>自动删除记录</source>
        <translation type="unfinished">Auto-delete Records</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.ui" line="189"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="30"/>
        <source>file_local_clean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="68"/>
        <source>新增</source>
        <translation type="unfinished">New</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="69"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="95"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="95"/>
        <source>删除文件类型</source>
        <translation type="unfinished">Delete file type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="95"/>
        <source>最大空间(MB)</source>
        <translation type="unfinished">Maximum space (MB)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="95"/>
        <source>清理后目标空间(MB)</source>
        <translation type="unfinished">Target space after cleanup (MB)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="115"/>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="346"/>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="353"/>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="371"/>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="419"/>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="423"/>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="449"/>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="472"/>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="482"/>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="555"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="115"/>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="346"/>
        <source>配置模板名不能为空</source>
        <translation type="unfinished">The configuration template name cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="163"/>
        <source>配置新名称</source>
        <translation type="unfinished">Config name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="173"/>
        <source>确定</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="174"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="184"/>
        <source>配置模板名称选择</source>
        <translation type="unfinished">Select template name for configuration</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="228"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="228"/>
        <source>未选中任何行</source>
        <translation type="unfinished">No rows selected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="232"/>
        <source>删除选中行</source>
        <translation type="unfinished">Delete selected row</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="232"/>
        <source>是否删除？</source>
        <translation type="unfinished">Do you want to delete?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="353"/>
        <source>数据发生变化，是否保存？</source>
        <translation type="unfinished">Datas have changed? Should it be saved?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="371"/>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="555"/>
        <source>请输入0~100</source>
        <translation type="unfinished">Please enter 0~100</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="419"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="423"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="449"/>
        <source>请选择安装目录下的目录</source>
        <translation type="unfinished">Please select a directory under the installation directory</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="472"/>
        <source>请输入大于0数字</source>
        <translation type="unfinished">Please enter a number greater than 0</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="482"/>
        <source>当前没有文件被删除</source>
        <translation type="unfinished">Currently, no files have been deleted</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="488"/>
        <source>*内容仅为：本节点根据清除配置，删除的文件历史记录</source>
        <translation type="unfinished">*The content is only: The history of deleted files in this node is based on the clearing configuration</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="493"/>
        <source>清理时间</source>
        <translation type="unfinished">Clean time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="493"/>
        <source>文件名称</source>
        <translation type="unfinished">File Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="493"/>
        <source>文件路径</source>
        <translation type="unfinished">File path</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="493"/>
        <source>文件大小</source>
        <translation type="unfinished">File size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="493"/>
        <source>最后修改时间</source>
        <translation type="unfinished">Last modified time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_file_local_cleaner/mainwindow.cpp" line="493"/>
        <source>执行结果</source>
        <translation type="unfinished">Execute results</translation>
    </message>
</context>
</TS>
