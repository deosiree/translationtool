<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>mainWindow</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="14"/>
        <source>mainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="24"/>
        <source>备份根目录：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="55"/>
        <source>备份类型：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="65"/>
        <source>可执行文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="72"/>
        <source>配置文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="79"/>
        <source>画面文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="86"/>
        <source>资源文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="93"/>
        <source>文件服务文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="100"/>
        <source>实时数据库</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="107"/>
        <source>历史数据库</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="114"/>
        <source>脚本文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="121"/>
        <source>环境变量文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="128"/>
        <source>日志文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="135"/>
        <source>数据文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="151"/>
        <source>备份内容：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="183"/>
        <source>生成模板</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="190"/>
        <source>重新加载</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.ui" line="197"/>
        <source>保存</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.cpp" line="209"/>
        <source>序号</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.cpp" line="209"/>
        <source>相对路径</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>myButton</name>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.cpp" line="374"/>
        <source>标题</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.cpp" line="375"/>
        <source>数据1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.cpp" line="377"/>
        <source>数据2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/sysops/tool/gui_backup_config/src/mainwindow.cpp" line="378"/>
        <source>图片</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
