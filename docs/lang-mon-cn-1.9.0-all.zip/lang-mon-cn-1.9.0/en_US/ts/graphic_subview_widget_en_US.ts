<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>GraphicSubviewWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_subview_widget/graphic_subview_widget.cpp" line="1317"/>
        <source>决策查询</source>
        <translation type="unfinished">Decision query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_subview_widget/graphic_subview_widget.cpp" line="1327"/>
        <source>清空标识</source>
        <translation type="unfinished">Clear ID</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_subview_widget/graphic_subview_widget.cpp" line="1336"/>
        <source>对象信息查询</source>
        <translation type="unfinished">Object info query</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_subview_widget/graphic_subview_widget.cpp" line="1345"/>
        <source>画面信息查询</source>
        <translation type="unfinished">Graph info query</translation>
    </message>
</context>
</TS>
