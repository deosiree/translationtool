<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>PluginSecCheck</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sec/plugin_sec_check.ui" line="14"/>
        <source>PluginSecCheck</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sec/plugin_sec_check.ui" line="30"/>
        <source>信息检查：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sec/plugin_sec_check.ui" line="50"/>
        <source>重置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sec/plugin_sec_check.ui" line="57"/>
        <source>一键查验</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/tool/sysops/plugin_sysops/plugin_check_sec/pluginseccheck.cpp" line="49"/>
        <source>安全信息检查</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
