<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="87"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="116"/>
        <source>设备监视系统</source>
        <translation type="unfinished">Sistema de monitoreo de equipos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="87"/>
        <source>网络连接已存在，不可以无系统方式登录</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="271"/>
        <source>已连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="303"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="304"/>
        <source>用户登出</source>
        <translation type="unfinished">Cerrar sesión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="346"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="347"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="389"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="390"/>
        <source>用户校验</source>
        <translation type="unfinished">Verificación de usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="972"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="1115"/>
        <source>切换用户</source>
        <translation type="unfinished">Cambiar Usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="974"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="1117"/>
        <source>是否切换</source>
        <translation type="unfinished">Desea cambiar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="975"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="1118"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="976"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="1119"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="1155"/>
        <source>注销用户</source>
        <translation type="unfinished">Cerrar sesión </translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_mgmt_impl.cpp" line="1156"/>
        <source>是否注销用户</source>
        <translation type="unfinished">Desea cerrar sesión del usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="26"/>
        <source>修改密码</source>
        <comment>toolName</comment>
        <translation type="unfinished">Cambiar Contraseña</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/send_aud_alarm.cpp" line="73"/>
        <source>节点[%1]工具[%2]%3</source>
        <translation type="unfinished">Nodo [%1] Herramienta [%2] %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1637"/>
        <source>登录输入用户名[%1]包含异常字符，可能存在篡改、恶意攻击行为</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>change_pwd_dlg</name>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_pwd_dlg.ui" line="29"/>
        <source>当前密码：</source>
        <translation type="unfinished">Contraseña actual:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_pwd_dlg.ui" line="51"/>
        <source>新密码：</source>
        <translation type="unfinished">Nueva contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_pwd_dlg.ui" line="73"/>
        <source>确认密码：</source>
        <translation type="unfinished">Confirmar contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_pwd_dlg.ui" line="99"/>
        <source>确认</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
</context>
<context>
    <name>iasp::security::CChangePwdDlgImp</name>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="92"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="96"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="108"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="117"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="125"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="133"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="146"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="160"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="172"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="183"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="212"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="97"/>
        <source>参数错误</source>
        <translation type="unfinished">Error de parámetro</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="109"/>
        <source>用户不存在</source>
        <translation type="unfinished">El usuario no existe</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="118"/>
        <source>请补全信息</source>
        <translation type="unfinished">Complete la información</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="126"/>
        <source>两次输入的密码不一致</source>
        <translation type="unfinished">¡Las contraseñas ingresadas son diferentes!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="134"/>
        <source>新旧密码不能相同，请重新填写</source>
        <translation type="unfinished">Las contraseñas nueva y antigua no pueden ser iguales, por favor ingrese nuevamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="147"/>
        <source>密码输入有误，请重新输入</source>
        <translation type="unfinished">Contraseña incorrecta, por favor reingrese</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="161"/>
        <source>密码复杂度不满足要求:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="173"/>
        <source>密码生成失败，请检查</source>
        <translation type="unfinished">Fallo en la generación de la contraseña, por favor verifique</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="184"/>
        <source>密码已使用，请修改</source>
        <translation type="unfinished">La contraseña ha sido usada, por favor cámbiela</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="199"/>
        <source>密码更新成功</source>
        <translation type="unfinished">Contraseña actualizada con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/change_password_dlg.cpp" line="208"/>
        <source>密码更新失败</source>
        <translation type="unfinished">Error al actualizar la contraseña</translation>
    </message>
</context>
<context>
    <name>iasp::security::CLoginDlg</name>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="59"/>
        <source>登录管理</source>
        <translation type="unfinished">Gestión de inicio de sesión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="143"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/sec_login_dlg.cpp" line="275"/>
        <source>用户登录</source>
        <translation type="unfinished">Inicio de Sesión de Usuario</translation>
    </message>
</context>
<context>
    <name>iasp::security::CLoginDlgImp</name>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="393"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="401"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="524"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="532"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="642"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="650"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="703"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="708"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="713"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="718"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="723"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="728"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="733"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="754"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="821"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1071"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1080"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1091"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1142"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="755"/>
        <source>用户数据初始化失败，请检查</source>
        <translation type="unfinished">Falló la inicialización de datos del usuario, por favor verifique</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="771"/>
        <source>指纹校验：</source>
        <translation type="unfinished">Verificación de huella digital:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="782"/>
        <source>UKey：</source>
        <translation type="unfinished">UKey:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1001"/>
        <source>连接</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1053"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1368"/>
        <source>连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1143"/>
        <source>网络注册连接切换失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1158"/>
        <source>已连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1345"/>
        <source>IP：</source>
        <translation type="unfinished">IP:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1351"/>
        <source>请输入端口</source>
        <translation type="unfinished">Por favor, ingrese el puerto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1390"/>
        <source>用户名：</source>
        <translation type="unfinished">Nombre de usuario:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1420"/>
        <source>密码：</source>
        <translation type="unfinished">Contraseña:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1425"/>
        <source>请输入密码</source>
        <translation type="unfinished">Por favor, ingrese su contraseña</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1437"/>
        <source>双因子：</source>
        <translation type="unfinished">Doble factor:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1441"/>
        <source>校验通过</source>
        <translation type="unfinished">Verificación aprobada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1455"/>
        <source>验证码：</source>
        <translation type="unfinished">Código de verificación:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1459"/>
        <source>请输入验证码</source>
        <translation type="unfinished">Por favor ingrese el código de verificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="162"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="775"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="786"/>
        <source>点击登录后进行校验</source>
        <translation type="unfinished">Haga clic para iniciar sesión y realizar la verificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="176"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="420"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="551"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="695"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="753"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="820"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="955"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="972"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1068"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="177"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="421"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="552"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="894"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="919"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="936"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="956"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="973"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="999"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1327"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="197"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="205"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="211"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="227"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="239"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="255"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="269"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="283"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="291"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="299"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="307"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="315"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="323"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="331"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="339"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="347"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="355"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="363"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="371"/>
        <source>登录失败</source>
        <comment>toolName</comment>
        <translation type="unfinished">Inicio de Sesión Fallido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="198"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="438"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="566"/>
        <source>用户名或密码错误</source>
        <translation type="unfinished">Nombre de usuario o contraseña incorrectos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="206"/>
        <source>权限校验失败</source>
        <translation type="unfinished">Fallo en la verificación de permisos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="212"/>
        <source>服务登录请求认证失败，请检查</source>
        <translation type="unfinished">Fallo en la autenticación de la solicitud de inicio de sesión del servicio, por favor verifique</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="228"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="454"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="580"/>
        <source>用户已被锁定，剩余锁定时长： %1 分 %2 秒， 预计将于 %3 解锁 </source>
        <translation type="unfinished">El usuario ha sido bloqueado. Tiempo restante de bloqueo: %1 min %2 seg. Se estima que se desbloqueará a las %3</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="243"/>
        <source>用户已登录，用户 %1 已经于 %2 在 %3 节点登录 %4 。</source>
        <translation type="unfinished">Usuario %1 en %2 en el nodo %3 inició sesión en %4</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="256"/>
        <source>用户密码未初始化，是否初始化</source>
        <translation type="unfinished">La contraseña del usuario no está inicializada, ¿desea inicializar la contraseña?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="270"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="480"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="602"/>
        <source>用户密码已失效，是否更新</source>
        <translation type="unfinished">Su contraseña ha expirado. Desea actualizarla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="284"/>
        <source>用户登录信息生成失败，请检查</source>
        <translation type="unfinished">Fallo en la generación de información de inicio de sesión del usuario, por favor verifique</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="292"/>
        <source>认证失败</source>
        <translation type="unfinished">Autenticación fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="300"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="494"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="614"/>
        <source>用户双因子校验失败</source>
        <translation type="unfinished">Error en la autenticación de dos factores del usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="308"/>
        <source>APP不可多次登录</source>
        <translation type="unfinished">No se puede iniciar sesión en la aplicación varias veces</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="316"/>
        <source>用户未录入指纹</source>
        <translation type="unfinished">La huella digital del usuario no está registrada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="324"/>
        <source>指纹校验失败，请重试</source>
        <translation type="unfinished">La verificación de huella digital falló, por favor intente de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="332"/>
        <source>指纹仪加载失败，请检查</source>
        <translation type="unfinished">Falló la carga del escáner de huellas digitales, por favor verifique</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="340"/>
        <source>用户信息认证失败，请检查</source>
        <translation type="unfinished">Fallo en la autenticación de la información del usuario, por favor verifique</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="348"/>
        <source>UKey校验失败，请重试</source>
        <translation type="unfinished">Fallo en la verificación de UKey, por favor intente de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="356"/>
        <source>UKey初始化失败，请检查</source>
        <translation type="unfinished">Fallo en la inicialización de UKey, por favor verifique</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="364"/>
        <source>用户录入UKey与实际UKey不匹配</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="372"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="502"/>
        <source>密码复杂度较低，是否更新密码</source>
        <translation type="unfinished">Baja complejidad de la contraseña, ¿desea actualizar la contraseña?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="394"/>
        <source>用户登录超时，请重试</source>
        <translation type="unfinished">Tiempo de espera de inicio de sesión del usuario, por favor intente de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="402"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="533"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="651"/>
        <source>校验结果获取失败，请检查</source>
        <translation type="unfinished">Fallo en la obtención del resultado de la verificación, por favor verifique</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="437"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="453"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="465"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="479"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="493"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="501"/>
        <source>登出失败</source>
        <comment>toolName</comment>
        <translation type="unfinished">Cierre de Sesión Fallido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="466"/>
        <source>用户密码未初始化,是否初始化</source>
        <translation type="unfinished">La contraseña del usuario no está inicializada, ¿desea inicializar la contraseña?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="525"/>
        <source>用户退出操作超时，请重试</source>
        <translation type="unfinished">Tiempo de espera de la operación de salida del usuario, por favor intente de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="565"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="579"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="589"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="601"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="613"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="619"/>
        <source>校验失败</source>
        <comment>toolName</comment>
        <translation type="unfinished">Verificación Fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="590"/>
        <source>用户未进行初始化设置,是否初始化密码</source>
        <translation type="unfinished">El usuario no ha completado la configuración inicial. Desea inicializar la contraseña</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="620"/>
        <source>密码复杂度较低，是否更新</source>
        <translation type="unfinished">Baja complejidad de la contraseña, ¿desea actualizarla?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="643"/>
        <source>用户校验超时，请重试</source>
        <translation type="unfinished">Tiempo de espera de verificación del usuario, por favor intente de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="704"/>
        <source>用户名不可为空</source>
        <translation type="unfinished">El nombre de usuario no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="709"/>
        <source>输入非法，请重新输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="714"/>
        <source>密码不可为空</source>
        <translation type="unfinished">La contraseña no puede estar vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="719"/>
        <source>自定义登录时长不可为空</source>
        <translation type="unfinished">La duración de inicio de sesión personalizada no puede estar vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="724"/>
        <source>验证码不可为空</source>
        <translation type="unfinished">El código de verificación no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="729"/>
        <source>工作目录不可为空</source>
        <translation type="unfinished">El directorio de trabajo no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="734"/>
        <source>请检查输入内容是否完整</source>
        <translation type="unfinished">Verifique si el contenido ingresado está completo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1638"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1643"/>
        <source>系统</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="160"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="773"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="784"/>
        <source>点击确认后进行校验</source>
        <translation type="unfinished">Clic Confirmar para Validar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="822"/>
        <source>插件:%1参数错误，请检查数据库配置</source>
        <translation type="unfinished">Complemento:%1 error de parámetro, por favor verifique la configuración de la BD</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="884"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="909"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1000"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1328"/>
        <source>登录</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Iniciar sesión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="887"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="912"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="992"/>
        <source>退出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="891"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="916"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="996"/>
        <source>注销</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cerrar sesión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="896"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="921"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1004"/>
        <source>用户登录</source>
        <comment>toolName</comment>
        <translation type="unfinished">Inicio de Sesión de Usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="937"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1329"/>
        <source>登出</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cerrar sesión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="942"/>
        <source>用户登出</source>
        <comment>toolName</comment>
        <translation type="unfinished">Cerrar Sesión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="958"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="975"/>
        <source>用户校验</source>
        <comment>toolName</comment>
        <translation type="unfinished">Verificación de Usuario</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1072"/>
        <source>IP地址不可为空</source>
        <translation type="unfinished">La dirección IP no puede estar vacía</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1081"/>
        <source>端口号不可为空</source>
        <translation type="unfinished">El ID del puerto no puede estar vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1092"/>
        <source>IP地址错误</source>
        <translation type="unfinished">Error de dirección IP</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1313"/>
        <source>欢迎登录</source>
        <comment>tabBarTitle</comment>
        <translation type="unfinished">Bienvenido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1460"/>
        <source>发送验证码</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Enviar código</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1477"/>
        <source>登录有效期：</source>
        <translation type="unfinished">Expiración del inicio de sesión:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1484"/>
        <source>30分钟</source>
        <translation type="unfinished">30min</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1488"/>
        <source>60分钟</source>
        <translation type="unfinished">60min</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1491"/>
        <source>3小时</source>
        <translation type="unfinished">3h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1494"/>
        <source>6小时</source>
        <translation type="unfinished">6h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1497"/>
        <source>12小时</source>
        <translation type="unfinished">12h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1500"/>
        <source>24小时</source>
        <translation type="unfinished">24h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1512"/>
        <source>分钟   </source>
        <translation type="unfinished">min</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1576"/>
        <source>工作目录：</source>
        <translation type="unfinished">Directorio de trabajo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1580"/>
        <source>请设置工作路径</source>
        <translation type="unfinished">Por favor, configure la ruta de trabajo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1582"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/clogin_dlg_imp.cpp" line="1747"/>
        <source>选择目录</source>
        <translation type="unfinished">Seleccione directorio</translation>
    </message>
</context>
<context>
    <name>userAuthFunc</name>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1087"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1104"/>
        <source>未录指纹</source>
        <translation type="unfinished">Huella digital no registrada</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1114"/>
        <source>无指纹设备</source>
        <translation type="unfinished">No hay dispositivo de huella digital</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1125"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1132"/>
        <source>指纹仪加载失败</source>
        <translation type="unfinished">Fallo al cargar el medidor de huellas dactilares</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1136"/>
        <source>请开始指纹校验</source>
        <translation type="unfinished">¡Por favor, inicie la verificación de huellas dactilares!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1142"/>
        <source>指纹校验失败，请重试</source>
        <translation type="unfinished">La verificación de huella digital falló, por favor intente de nuevo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1145"/>
        <source>指纹校验失败</source>
        <translation type="unfinished">Fallo en la verificación de huella dactilar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1160"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1198"/>
        <source>用户未制作UKey</source>
        <translation type="unfinished">El usuario no creó un UKey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1178"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1192"/>
        <source>用户未制作个人证书</source>
        <translation type="unfinished">El usuario no creó un certificado personal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1214"/>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1222"/>
        <source>UKey证书错误</source>
        <translation type="unfinished">Error en el certificado de UKey</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1253"/>
        <source>UKey不匹配，加载失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1262"/>
        <source>加载证书失败</source>
        <translation type="unfinished">Fallo al cargar el certificado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/api/sec_login_dlg/cbase_auth_func.cpp" line="1272"/>
        <source>UKey校验失败</source>
        <translation type="unfinished">La verificación de UKey falla.</translation>
    </message>
</context>
</TS>
