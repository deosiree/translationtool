<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.ui" line="37"/>
        <source>外现场：</source>
        <translation type="unfinished">Escena exterior:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.ui" line="84"/>
        <source>数据源：</source>
        <translation type="unfinished">Fuente de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.ui" line="103"/>
        <source>节点：</source>
        <translation type="unfinished">Nodo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.ui" line="165"/>
        <source>目录：</source>
        <translation type="unfinished">Directorio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.ui" line="242"/>
        <source>上传</source>
        <translation type="unfinished">Subir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.ui" line="266"/>
        <source>下载</source>
        <translation type="unfinished">Descargar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="22"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="22"/>
        <source>无系统模式</source>
        <translation type="unfinished">Sin modo de sistema</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="122"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="122"/>
        <source>目前无值班节点</source>
        <translation type="unfinished">Ningún nodo está actualmente en servicio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="169"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="237"/>
        <source>错误信息</source>
        <translation type="unfinished">Mensaje de error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="217"/>
        <source>目录</source>
        <translation type="unfinished">Directorio</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="217"/>
        <source>文件大小</source>
        <translation type="unfinished">Tamaño del archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="217"/>
        <source>修改时间</source>
        <translation type="unfinished">Tiempo de modificación</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="311"/>
        <source>选择文件</source>
        <translation type="unfinished">Seleccionar archivo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="311"/>
        <source>All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="335"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="339"/>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="438"/>
        <source>信息</source>
        <translation type="unfinished">Mensaje</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="335"/>
        <source>上传失败</source>
        <translation type="unfinished">Carga fallida</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="339"/>
        <source>上传成功</source>
        <translation type="unfinished">Subida exitosa</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/filemgr/plug/file_cross_sync/mainwindow.cpp" line="438"/>
        <source>下载完成</source>
        <translation type="unfinished">Descarga completada</translation>
    </message>
</context>
</TS>
