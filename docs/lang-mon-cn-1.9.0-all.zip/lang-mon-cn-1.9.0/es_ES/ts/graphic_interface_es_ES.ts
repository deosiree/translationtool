<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_base_check_interface.cpp" line="27"/>
        <source>图元场景信息获取失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_base_check_interface.cpp" line="47"/>
        <source>图元视图信息获取失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_base_check_interface.cpp" line="68"/>
        <source>图元文件解析错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_base_check_interface.cpp" line="138"/>
        <source>画面场景信息获取错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_base_check_interface.cpp" line="158"/>
        <source>画面视图信息获取错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_base_check_interface.cpp" line="179"/>
        <source>画面文件解析错误</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>iasp::gui::GraphicImpExpInterface</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_imp_exp_interface.cpp" line="70"/>
        <source>导入包设置类型错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_imp_exp_interface.cpp" line="80"/>
        <source>用于导入导出的对话框没有被创建</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_imp_exp_interface.cpp" line="90"/>
        <source>当前导入检查界面已加载,请关闭后再进行检查</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_imp_exp_interface.cpp" line="105"/>
        <source>导入包检查类型错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_imp_exp_interface.cpp" line="121"/>
        <source>当前导出检查界面已加载,请关闭后再进行检查</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_imp_exp_interface.cpp" line="136"/>
        <source>导出包检查类型错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_interface/graphic_imp_exp_interface.cpp" line="150"/>
        <source>导入/导出前请先做检查</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
