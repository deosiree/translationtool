<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CalcEditorImpl</name>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.ui" line="34"/>
        <source>公式名称:</source>
        <translation type="unfinished">Nombre de la fórmula:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.ui" line="44"/>
        <source>目标路径:</source>
        <translation type="unfinished">Ruta objetivo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.ui" line="54"/>
        <source>检索</source>
        <translation type="unfinished">Buscar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.ui" line="72"/>
        <source>因子列表</source>
        <translation type="unfinished">Lista de factores</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.ui" line="91"/>
        <source>表达式</source>
        <translation type="unfinished">Expresión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.ui" line="99"/>
        <source>快捷函数</source>
        <translation type="unfinished">Funciones rápidas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.ui" line="125"/>
        <source>取消</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.ui" line="132"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
</context>
<context>
    <name>CalcFactorModel</name>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="388"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="409"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="436"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="459"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="388"/>
        <source>数据类型不匹配,目标类型为bool</source>
        <translation type="unfinished">Desajuste de tipo de datos, el tipo objetivo es bool</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="409"/>
        <source>数据类型不匹配,目标类型为double</source>
        <translation type="unfinished">Desajuste de tipo de datos, el tipo objetivo es double</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="436"/>
        <source>数据类型不匹配,目标类型为long long</source>
        <translation type="unfinished">Desajuste de tipo de datos, el tipo objetivo es long long</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="459"/>
        <source>数据类型不匹配,目标类型为无符号</source>
        <translation type="unfinished">Desajuste de tipo de datos, el tipo objetivo es unsigned</translation>
    </message>
</context>
<context>
    <name>CalcFormulaEditor</name>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="72"/>
        <source>快捷函数：</source>
        <translation type="unfinished">Función rápida:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="177"/>
        <source>试算</source>
        <translation type="unfinished">Cálculo de prueba</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="192"/>
        <source>基本操作</source>
        <translation type="unfinished">Básico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="201"/>
        <source>(</source>
        <translation type="unfinished">(</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="211"/>
        <source>)</source>
        <translation type="unfinished">)</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="221"/>
        <source>==</source>
        <translation type="unfinished">==</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="231"/>
        <source>!=</source>
        <translation type="unfinished">! =</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="241"/>
        <source>&gt;</source>
        <translation type="unfinished">&gt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="251"/>
        <source>&lt;</source>
        <translation type="unfinished">&lt;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="261"/>
        <source>&gt;=</source>
        <translation type="unfinished">&gt;=</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="271"/>
        <source>&lt;=</source>
        <translation type="unfinished">&lt;=</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="281"/>
        <source>AND</source>
        <translation type="unfinished">AND</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="291"/>
        <source>OR</source>
        <translation type="unfinished">OR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="301"/>
        <source>NOT</source>
        <translation type="unfinished">NOT</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="311"/>
        <source>%</source>
        <translation type="unfinished">%</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="321"/>
        <source>+</source>
        <translation type="unfinished">+</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="331"/>
        <source>-</source>
        <translation type="unfinished">-</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="341"/>
        <source>×</source>
        <translation type="unfinished">×</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="351"/>
        <source>÷</source>
        <translation type="unfinished">÷</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="368"/>
        <source>IF用例</source>
        <translation type="unfinished">Caso IF</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="376"/>
        <source>高级操作</source>
        <translation type="unfinished">Avanzado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="384"/>
        <source>类型：</source>
        <translation type="unfinished">Tipo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="400"/>
        <source>说明</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.ui" line="408"/>
        <source>计算引擎内部支持的函数说明</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="236"/>
        <source>函数名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="236"/>
        <source>函数说明</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="236"/>
        <source>示例</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="255"/>
        <source>浮点数x向下取整</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="259"/>
        <source>浮点数x向上取整</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="263"/>
        <source>浮点数x四舍五入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="396"/>
        <source>单点全与等于0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="397"/>
        <source>单点全与等于1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="398"/>
        <source>单点全或等于0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="399"/>
        <source>单点全或等于1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="59"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="323"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="177"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="256"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="284"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="296"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="349"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="424"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="59"/>
        <source>是否清除公式?</source>
        <translation type="unfinished">¿Está seguro de que desea limpiar la fórmula?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="76"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="254"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="264"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="246"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="253"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="288"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="188"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="235"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="285"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="325"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="526"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="543"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="76"/>
        <source>括号个数不匹配!</source>
        <translation type="unfinished">¡El número de paréntesis no coincide!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="252"/>
        <source>计算失败</source>
        <translation type="unfinished">Cálculo fallido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="254"/>
        <source>试算失败:%1,注意检查公式</source>
        <translation type="unfinished">Error de prueba:%1, revise la fórmula</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="260"/>
        <source>公式不合法</source>
        <translation type="unfinished">La fórmula es ilegal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_base_editor.cpp" line="264"/>
        <source>公式不合法:%1</source>
        <translation type="unfinished">La fórmula es ilegal: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="246"/>
        <source>表达式无效! : %1</source>
        <translation type="unfinished">¡La expresión es inválida! : %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="253"/>
        <source>保存失败，表达式为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="324"/>
        <source>因子[%1]未在公式中使用!</source>
        <translation type="unfinished">¡El factor [%1] no se utiliza en la fórmula!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="289"/>
        <source>因子[%1]在因子列表中未找到!</source>
        <translation type="unfinished">¡Factor [%1] no encontrado en la lista de factores!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="42"/>
        <source>因子</source>
        <translation type="unfinished">Factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="44"/>
        <source>因子路径</source>
        <translation type="unfinished">Ruta del factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="46"/>
        <source>因子值描述</source>
        <translation type="unfinished">Descripción del valor del factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="48"/>
        <source>因子值</source>
        <translation type="unfinished">Valor de factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="50"/>
        <source>按单点计算</source>
        <translation type="unfinished">Calcular por punto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="189"/>
        <source>因子[%1]已存在,不再添加</source>
        <translation type="unfinished">El factor [%1] ya existe y no se agregará nuevamente</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="235"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="285"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_model.cpp" line="326"/>
        <source>因子已存在:%1</source>
        <translation type="unfinished">El factor ya existe:%1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="136"/>
        <source>增加因子</source>
        <translation type="unfinished">Agregar factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="172"/>
        <source>删除因子</source>
        <translation type="unfinished">Eliminar Factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="177"/>
        <source>确定删除选中的因子吗？</source>
        <translation type="unfinished">¿Está seguro de que desea eliminar los factores seleccionados?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="193"/>
        <source>修改因子</source>
        <translation type="unfinished">Editar factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="219"/>
        <source>编辑因子</source>
        <translation type="unfinished">Editar factor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="246"/>
        <source>查看关联计算目标</source>
        <translation type="unfinished">Ver objetivos de cálculo vinculados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="256"/>
        <source>没有计算目标</source>
        <translation type="unfinished">Sin objetivo calculado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="264"/>
        <source>计算目标</source>
        <translation type="unfinished">Objetivo de cálculo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="271"/>
        <source>查看嵌套计算目标</source>
        <translation type="unfinished">Ver objetivos de cálculo anidados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="284"/>
        <source>存在多个相同计算目标</source>
        <translation type="unfinished">Hay múltiples objetivos de cálculo idénticos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="296"/>
        <source>没有嵌套目标</source>
        <translation type="unfinished">Sin objetivos anidados</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_factor_wgt.cpp" line="300"/>
        <source>嵌套目标</source>
        <translation type="unfinished">Objetivo anidado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="185"/>
        <source>加</source>
        <translation type="unfinished">Sumar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="186"/>
        <source>减</source>
        <translation type="unfinished">Reducir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="187"/>
        <source>乘</source>
        <translation type="unfinished">Multiplicar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="188"/>
        <source>除</source>
        <translation type="unfinished">Dividir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="189"/>
        <source>取模</source>
        <translation type="unfinished">Tomar molde</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="190"/>
        <source>等于</source>
        <translation type="unfinished">Igual a</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="191"/>
        <source>不等于</source>
        <translation type="unfinished">Diferente de</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="192"/>
        <source>小于</source>
        <translation type="unfinished">Menor que</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="193"/>
        <source>小于等于</source>
        <translation type="unfinished">Menor o igual que</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="194"/>
        <source>大于</source>
        <translation type="unfinished">Mayor que</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="195"/>
        <source>大于等于</source>
        <translation type="unfinished">Mayor o igual que</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="196"/>
        <source>逻辑与</source>
        <translation type="unfinished">AND</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="197"/>
        <source>逻辑或</source>
        <translation type="unfinished">OR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="198"/>
        <source>逻辑非</source>
        <translation type="unfinished">NOT</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="199"/>
        <source>清空</source>
        <translation type="unfinished">Borrar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="269"/>
        <source>常量</source>
        <translation type="unfinished">Constante</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="270"/>
        <source>位运算</source>
        <translation type="unfinished">Operación de bits</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="271"/>
        <source>生成表达式</source>
        <translation type="unfinished">Generar expresión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="349"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="425"/>
        <source>是否清空当前公式?</source>
        <translation type="unfinished">¿Desea borrar la fórmula actual?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="371"/>
        <source>真</source>
        <translation type="unfinished">Verdadero</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="372"/>
        <source>假</source>
        <translation type="unfinished">Falso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="373"/>
        <source>年</source>
        <translation type="unfinished">Año</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="374"/>
        <source>月</source>
        <translation type="unfinished">Mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="375"/>
        <source>日</source>
        <translation type="unfinished">Día</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="376"/>
        <source>时</source>
        <translation type="unfinished">Hora</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="377"/>
        <source>分</source>
        <translation type="unfinished">Minuto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="378"/>
        <source>秒</source>
        <translation type="unfinished">seg</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="379"/>
        <source>π</source>
        <translation type="unfinished">π</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="384"/>
        <source>右移</source>
        <translation type="unfinished">Desplazamiento a la derecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="385"/>
        <source>左移</source>
        <translation type="unfinished">Desplazamiento a la izquierda</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="386"/>
        <source>异或</source>
        <translation type="unfinished">XOR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="387"/>
        <source>按位与</source>
        <translation type="unfinished">Y a nivel de bits</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="388"/>
        <source>按位或</source>
        <translation type="unfinished">O a nivel de bits</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="389"/>
        <source>按位非</source>
        <translation type="unfinished">No a nivel de bits</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="393"/>
        <source>生成求和表达式</source>
        <translation type="unfinished">Generar expresión SUM</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="394"/>
        <source>生成与表达式</source>
        <translation type="unfinished">Generar expresión AND</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="395"/>
        <source>生成或表达式</source>
        <translation type="unfinished">Generar expresión OR</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="396"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="397"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="398"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="399"/>
        <source>例:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="526"/>
        <source>参数的个数和函数所需参数个数不匹配!</source>
        <translation type="unfinished">El número de parámetros no coincide con el número de parámetros requeridos por la función</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_formula_editor.cpp" line="543"/>
        <source>函数参数[%1]类型不符合输入要求!</source>
        <translation type="unfinished">El tipo de parámetro de función [%1] no cumple con los requisitos de entrada</translation>
    </message>
</context>
<context>
    <name>iasp::calc::CalcEditorImpl</name>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="279"/>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="314"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="281"/>
        <source>部分因子在因子列表中未找到!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/comcalc/plugin/calc_editor_base/calc_editor_impl.cpp" line="316"/>
        <source>部分因子未在公式中使用!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
