<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CurveMainWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="260"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="511"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="276"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="260"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="511"/>
        <source>曲线组名称不可为空</source>
        <translation type="unfinished">Nombre de grupo de curva no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="276"/>
        <source>暂未实现，敬请期待</source>
        <translation type="unfinished">No implementado, espere</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="290"/>
        <source>打开曲线</source>
        <translation type="unfinished">Abrir curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="290"/>
        <source>曲线文件%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="319"/>
        <source>开启实时刷新</source>
        <translation type="unfinished">Habilitar actualización en tiempo real</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_mainwidget.cpp" line="627"/>
        <source>至</source>
        <translation type="unfinished">a</translation>
    </message>
</context>
<context>
    <name>CurveTableWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="88"/>
        <source>分</source>
        <translation type="unfinished">Minuto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="95"/>
        <source>秒</source>
        <translation type="unfinished">seg</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="115"/>
        <source>时</source>
        <translation type="unfinished">Hora</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="129"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="167"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="232"/>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="149"/>
        <source>日</source>
        <translation type="unfinished">th</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="192"/>
        <source>周一</source>
        <translation type="unfinished">Lunes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="195"/>
        <source>周二</source>
        <translation type="unfinished">Martes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="198"/>
        <source>周三</source>
        <translation type="unfinished">Miércoles</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="201"/>
        <source>周四</source>
        <translation type="unfinished">Jueves</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="204"/>
        <source>周五</source>
        <translation type="unfinished">Viernes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="207"/>
        <source>周六</source>
        <translation type="unfinished">Sábado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/curve_table_widget.cpp" line="210"/>
        <source>周日</source>
        <translation type="unfinished">Domingo</translation>
    </message>
</context>
<context>
    <name>CurveViewerDialog</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="128"/>
        <source>曲线查询</source>
        <comment>toolName</comment>
        <translation type="unfinished">Consulta de Curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="217"/>
        <source>导出曲线数据</source>
        <translation type="unfinished">Exportar datos de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="219"/>
        <source>今日曲线</source>
        <translation type="unfinished">Curva de hoy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="220"/>
        <source>昨日曲线</source>
        <translation type="unfinished">Curva de ayer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="221"/>
        <source>历史日曲线</source>
        <translation type="unfinished">Curva diaria histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="222"/>
        <source>本时曲线</source>
        <translation type="unfinished">Curva de la hora actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="223"/>
        <source>某时曲线</source>
        <translation type="unfinished">Curva Temporal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="224"/>
        <source>本周曲线</source>
        <translation type="unfinished">Curva de esta semana</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="225"/>
        <source>某周曲线</source>
        <translation type="unfinished">Curva semanal</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="226"/>
        <source>本月曲线</source>
        <translation type="unfinished">Curva del Mes Actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="227"/>
        <source>某月曲线</source>
        <translation type="unfinished">Curva del mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="228"/>
        <source>放大</source>
        <translation type="unfinished">Ampliar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="229"/>
        <source>缩小</source>
        <translation type="unfinished">Alejar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="230"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="328"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1740"/>
        <source>切换表格</source>
        <translation type="unfinished">Cambiar tabla</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="231"/>
        <source>设置</source>
        <translation type="unfinished">Configuraciones</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="232"/>
        <source>曲线比较</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="233"/>
        <source>显示阈值</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="237"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1343"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2169"/>
        <source>显示游标</source>
        <translation type="unfinished">Mostrar cursor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="246"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="250"/>
        <source>平滑曲线</source>
        <translation type="unfinished">Curva suave</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="678"/>
        <source>今时曲线已存在，请按今时曲线按钮激活！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="761"/>
        <source>本月曲线已存在，请按本月曲线按钮激活！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="3089"/>
        <source>下限值需小于上限值！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="218"/>
        <source>打印</source>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="241"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1336"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2165"/>
        <source>隐藏游标</source>
        <translation type="unfinished">Ocultar cursor</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="255"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="259"/>
        <source>曲线详情</source>
        <translation type="unfinished">Detalles de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="315"/>
        <source>切换曲线</source>
        <translation type="unfinished">Cambiar curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="420"/>
        <source>今日</source>
        <translation type="unfinished">Hoy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="441"/>
        <source>昨日</source>
        <translation type="unfinished">Ayer</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="471"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="477"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="490"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="678"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="689"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="761"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="771"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2465"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2478"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="3089"/>
        <source>告警</source>
        <translation type="unfinished">Alarma</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="471"/>
        <source>昨日曲线已存在，请按昨日曲线按钮激活！</source>
        <translation type="unfinished">La curva de ayer ya existe. ¡Presione el botón de la curva de ayer para activarla!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="477"/>
        <source>今日曲线已存在，请按今日曲线按钮激活！</source>
        <translation type="unfinished">La curva de hoy ya existe, ¡por favor presione el botón de curva para activarla!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="490"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="689"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="771"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2478"/>
        <source>选择日期已超出当前日期，请重新选择！</source>
        <translation type="unfinished">La fecha seleccionada ha excedido la fecha actual, ¡por favor seleccione de nuevo!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="497"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1484"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1489"/>
        <source>天前</source>
        <translation type="unfinished">hace días</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="650"/>
        <source>本时</source>
        <translation type="unfinished">Este momento</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="696"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1497"/>
        <source>小时前</source>
        <translation type="unfinished">Hace horas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="731"/>
        <source>本月</source>
        <translation type="unfinished">Este mes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="778"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1493"/>
        <source>月前</source>
        <translation type="unfinished">hace meses</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1119"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1592"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2897"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="3185"/>
        <source>W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="1501"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2488"/>
        <source>周前</source>
        <translation type="unfinished">hace semanas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2050"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2074"/>
        <source>秒</source>
        <translation type="unfinished">seg</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2062"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2086"/>
        <source>分钟</source>
        <translation type="unfinished">min</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2436"/>
        <source>本周</source>
        <translation type="unfinished">Esta semana</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.cpp" line="2465"/>
        <source>本周曲线已存在，请按本周曲线按钮激活！</source>
        <translation type="unfinished">La curva de esta semana ya existe. ¡Presione el botón &quot;Curva de esta semana&quot; para activarla!</translation>
    </message>
</context>
<context>
    <name>DlgCurveCompare</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="57"/>
        <source>比较曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="131"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="280"/>
        <source>空心圆</source>
        <translation type="unfinished">Círculo hueco</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="132"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="280"/>
        <source>实心圆</source>
        <translation type="unfinished">Círculo sólido</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="133"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="280"/>
        <source>正方形</source>
        <translation type="unfinished">Cuadrado</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="134"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="280"/>
        <source>三角形</source>
        <translation type="unfinished">Triángulo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="142"/>
        <source>基本属性</source>
        <translation type="unfinished">Atributos básicos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="149"/>
        <source>确认</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="152"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="178"/>
        <source>新增比较曲线</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="180"/>
        <source>删除比较曲线</source>
        <comment>buttonName</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="203"/>
        <source>曲线名称</source>
        <translation type="unfinished">Nombre de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="203"/>
        <source>线色</source>
        <translation type="unfinished">Color de línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="203"/>
        <source>线宽</source>
        <translation type="unfinished">Ancho de línea</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="203"/>
        <source>数据单位</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="203"/>
        <source>小数精度</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="203"/>
        <source>基本点形状</source>
        <translation type="unfinished">Forma de punto básico</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="203"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="290"/>
        <source>显示数据点</source>
        <translation type="unfinished">Mostrar puntos de datos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="234"/>
        <source>线色：</source>
        <translation type="unfinished">Color de línea:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="238"/>
        <source>单位:</source>
        <translation type="unfinished">Unidad:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="240"/>
        <source>请输入单位</source>
        <translation type="unfinished">Ingrese unidad</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="256"/>
        <source>小数点精度：</source>
        <translation type="unfinished">Precisión decimal:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="261"/>
        <source>线宽：</source>
        <translation type="unfinished">Ancho de línea:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="277"/>
        <source>数据点形状：</source>
        <translation type="unfinished">Forma de punto de datos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="339"/>
        <source>警告</source>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="339"/>
        <source>比较曲线测点数不多于两个。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="490"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="499"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="516"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="522"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="538"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="553"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="559"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="567"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="579"/>
        <source>告警</source>
        <translation type="unfinished">Alerta</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="490"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="499"/>
        <source>所选测点已存在，请重新选择！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="516"/>
        <source>查询历史表信息失败，请重新选择！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="522"/>
        <source>查询历史表数量为空, 该点未配置历史点，请重新选择！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="538"/>
        <source>配置了统计没有配置采样，请重新选择！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="553"/>
        <source>查询历史对象信息失败，请重新选择！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="559"/>
        <source>查询历史采样点数量为空, 该点未配置历史点，请重新选择！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="567"/>
        <source>查询历史采样点失败，请重新选择！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="579"/>
        <source>当前测点采样周期与基础采样周期不同，请重新选择！</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="759"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="1084"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="759"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="1084"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">Falso</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="789"/>
        <source>今日曲线-</source>
        <translation type="unfinished">Curva del día -</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="807"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="1038"/>
        <source>昨日曲线-</source>
        <translation type="unfinished">Curva de ayer -</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="825"/>
        <source>历史日曲线-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="843"/>
        <source>当月曲线-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="861"/>
        <source>历史月曲线-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="879"/>
        <source>本时曲线-</source>
        <translation type="unfinished">Curva de tiempo local -</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="897"/>
        <source>历史时曲线-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="915"/>
        <source>本周曲线-</source>
        <translation type="unfinished">Curva de la semana -</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="933"/>
        <source>历史周曲线-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="1034"/>
        <source>今时/日/周/月曲线-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="1042"/>
        <source>历史时/日/周/月曲线-</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GraphicMenuCurvePlug</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/graphic_menu_curve_plug.cpp" line="38"/>
        <source>曲线查询</source>
        <translation type="unfinished">Consulta de curva</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/graphic_menu_curve_plug.cpp" line="63"/>
        <source>今日曲线</source>
        <translation type="unfinished">Curva de hoy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/graphic_menu_curve_plug.cpp" line="64"/>
        <source>查看今日曲线</source>
        <translation type="unfinished">Ver la curva de hoy</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/graphic_menu_curve_plug.cpp" line="107"/>
        <source>打开失败</source>
        <translation type="unfinished">Fallo al abrir</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/graphic_menu_curve_plug.cpp" line="107"/>
        <source>确定</source>
        <translation type="unfinished">Confirmar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/graphic_menu_curve_plug.cpp" line="107"/>
        <source>该点历史曲线查询失败</source>
        <translation type="unfinished">Fallo al consultar curva histórica del punto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/graphic_menu_curve_plug.cpp" line="254"/>
        <source>本日</source>
        <translation type="unfinished">Hoy</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="753"/>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_curve_compare.cpp" line="1079"/>
        <source>未知(%1)</source>
        <translation type="unfinished">Desconocido (%1)</translation>
    </message>
</context>
<context>
    <name>dlg_day_curve</name>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.ui" line="168"/>
        <source>采样周期:</source>
        <extracomment>采样周期:</extracomment>
        <translation type="unfinished">Ciclo de muestreo:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.ui" line="194"/>
        <source>历史取数周期:</source>
        <extracomment>历史取数周期:</extracomment>
        <translation type="unfinished">Ciclo de datos históricos:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.ui" line="217"/>
        <source>x采样周期</source>
        <extracomment>x采样周期</extracomment>
        <translation type="unfinished">Muestreo X Ciclo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.ui" line="230"/>
        <source>实时采样周期:</source>
        <extracomment>实时采样周期:</extracomment>
        <translation type="unfinished">Ciclo de muestreo RT:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.ui" line="259"/>
        <source>秒</source>
        <extracomment>秒</extracomment>
        <translation type="unfinished">seg</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.ui" line="275"/>
        <source>上限阈值:</source>
        <extracomment>上限阈值:</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/plug/graphic_menu_curve_plug/dlg_day_curve.ui" line="298"/>
        <source>下限阈值:</source>
        <extracomment>下限阈值:</extracomment>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
