<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>BaseCheckWiget</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="89"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="89"/>
        <source>错误等级</source>
        <translation type="unfinished">Calificación de error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="89"/>
        <source>检查类型</source>
        <translation type="unfinished">Tipo de inspección</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="89"/>
        <source>详情描述</source>
        <translation type="unfinished">Detalles descripción</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="119"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="209"/>
        <source>显示所有标记</source>
        <translation type="unfinished">Mostrar etiquetas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="126"/>
        <source>清除定位标记</source>
        <translation type="unfinished">Borrar marcadores</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="134"/>
        <source>重新绘制唯一标识</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="140"/>
        <source>删除部分超出画布外元素</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="148"/>
        <source>删除完全超出画布外元素</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="154"/>
        <source>处理异常的图元态</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="199"/>
        <source>隐藏所有标记</source>
        <translation type="unfinished">Ocultar etiquetas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="222"/>
        <source>该操作将自动处理所有的图元态异常且不可恢复，详情请见图元正确性检查异常列表，是否继续？</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="268"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="303"/>
        <source>处理完成，若使本次操作生效,请保存并发布该图元</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="278"/>
        <source>图元信息获取失败，该操作终止</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="283"/>
        <source>非图元正确性检查操作，当前不做处理</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="297"/>
        <source>若使本次重绘操作生效,请保存并发布该画面</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="221"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="311"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="568"/>
        <source>警告</source>
        <comment>toolName</comment>
        <translation type="unfinished">Advertencia</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="312"/>
        <source>该操作将删除所有全部超出画布外元素，且不可恢复，是否继续？</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="225"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="315"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="572"/>
        <source>继续</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Continuar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="226"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="316"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="573"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="428"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="437"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="723"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="732"/>
        <source>删除失败</source>
        <translation type="unfinished">Eliminación falló</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="429"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="724"/>
        <source>不能同时删除表格子元素和其他元素，请先选择对应的表格或分别删除。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="437"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="732"/>
        <source>不能单独删除表格子元素，请选择对应的表格进行删除。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="524"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="819"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="525"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="820"/>
        <source>已跳过%1个无法单独删除的表格子元素。</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="561"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="856"/>
        <source>删除成功</source>
        <translation type="unfinished">Eliminado con éxito</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="569"/>
        <source>该操作将删除所有部分超出画布外元素，且不可恢复，是否继续？</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CheckPictureTree</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="27"/>
        <source>画面列表</source>
        <translation type="unfinished">Lista de gráficas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="27"/>
        <source>对象源名称</source>
        <translation type="unfinished">Nombre de origen del objeto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="239"/>
        <source>最新版本</source>
        <translation type="unfinished">Última versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="243"/>
        <source>草稿版本</source>
        <translation type="unfinished">Versión de borrador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="247"/>
        <source>历史版本%1</source>
        <translation type="unfinished">Versión histórica %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="301"/>
        <source>正在加载画面列表</source>
        <translation type="unfinished">Cargando lista de gráficos</translation>
    </message>
</context>
<context>
    <name>IconCheckBase</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/icon_check_base.cpp" line="49"/>
        <source>隐藏所有标记</source>
        <translation type="unfinished">Ocultar etiquetas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/icon_check_base.cpp" line="74"/>
        <source>正在加载正确性检查项...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/icon_check_base.cpp" line="260"/>
        <source>当前图元自检完成!异常项(%1)</source>
        <translation type="unfinished">¡Autocomprobación icono actual completada! Elemento excepción (%1)</translation>
    </message>
</context>
<context>
    <name>PictureCheckBase</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/picture_check_base.cpp" line="60"/>
        <source>隐藏所有标记</source>
        <translation type="unfinished">Ocultar etiquetas</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/picture_check_base.cpp" line="81"/>
        <source>正在加载正确性检查项...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/picture_check_base.cpp" line="255"/>
        <source>当前画面自检完成!异常项(%1)</source>
        <translation type="unfinished">¡La autoprueba de la gráfica actual está completa! Elemento de excepción (%1)</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="268"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="273"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="278"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="283"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="297"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="303"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="561"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_widget/base_check_widget.cpp" line="856"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="551"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="647"/>
        <source>草稿版本</source>
        <comment>PictureItem::displayChildren</comment>
        <translation type="unfinished">Versión de borrador</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="590"/>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="663"/>
        <source>最新版本</source>
        <comment>PictureItem::displayChildren</comment>
        <translation type="unfinished">Última versión</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="691"/>
        <source>历史版本</source>
        <comment>PictureItem::displayChildren</comment>
        <translation type="unfinished">Versión histórica</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/api/graphic_base_check/check_tree/check_pic_tree.cpp" line="773"/>
        <source>版本%1</source>
        <comment>HistoryItem::displayChildren</comment>
        <translation type="unfinished">Versión %1</translation>
    </message>
</context>
</TS>
