<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/main.cpp" line="196"/>
        <source>登录时限：</source>
        <translation type="unfinished">Límite de tiempo de inicio:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/main.cpp" line="287"/>
        <source>参数解析失败</source>
        <translation type="unfinished">Fallo al analizar los parámetros</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/main.cpp" line="287"/>
        <source>请检查输入的命令行参数</source>
        <translation type="unfinished">Por favor, revise los parámetros de la línea de comandos que ingresó</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/main.cpp" line="297"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/main.cpp" line="297"/>
        <source>平台注册失败！</source>
        <translation type="unfinished">¡El registro de plataforma falló!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/mainwindow.cpp" line="97"/>
        <source>配置管理工具</source>
        <translation type="unfinished">Herramienta de gestión de config.</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::MainCfg</name>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/mainwindow.cpp" line="143"/>
        <source>正在编辑</source>
        <translation type="unfinished">Editando</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/mainwindow.cpp" line="144"/>
        <source>当前有文件正在编辑，确认退出？</source>
        <translation type="unfinished">Hay Archivo Editándose, ¿Seguro Salir?</translation>
    </message>
</context>
<context>
    <name>cfgtool::gui::MainWindow</name>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/mainwindow.ui" line="17"/>
        <source>配置文件管理工具</source>
        <translation type="unfinished">Gestión de archivos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/mainwindow.ui" line="506"/>
        <source>刷新</source>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/mainwindow.ui" line="509"/>
        <source>F5</source>
        <translation type="unfinished">F5</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/mainwindow.ui" line="518"/>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/mainwindow.ui" line="521"/>
        <source>保存</source>
        <translation type="unfinished">Guardar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/mainwindow.ui" line="533"/>
        <source>编辑</source>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/mainwindow.ui" line="536"/>
        <source>编辑当前配置组</source>
        <translation type="unfinished">Editar el grupo de configuración actual</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/mainwindow.cpp" line="42"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/base/tool/gui_cfgtool/mainwindow.cpp" line="42"/>
        <source>初始化失败：</source>
        <translation type="unfinished">Inicialización fallida:</translation>
    </message>
</context>
</TS>
