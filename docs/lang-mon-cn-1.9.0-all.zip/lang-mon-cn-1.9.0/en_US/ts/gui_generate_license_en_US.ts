<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>DlgGenerateLicense</name>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="27"/>
        <source>请输入产品名称</source>
        <translation type="unfinished">Please enter the product name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="31"/>
        <source>请输入客户名称</source>
        <translation type="unfinished">Please enter customer name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="35"/>
        <source>请输入版本号</source>
        <translation type="unfinished">Please enter the version number</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="92"/>
        <source>已将 license 复制到剪贴板!</source>
        <translation type="unfinished">The license has been copied to the clipboard! 	</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="108"/>
        <source>Save File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="108"/>
        <source>Text Files (*.txt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="115"/>
        <source>打开文件失败!</source>
        <translation type="unfinished">Failed to open file! 	</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="122"/>
        <source>已将 license 导出到 %1</source>
        <translation type="unfinished">Exported license to %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="69"/>
        <source>必填信息为空!</source>
        <translation type="unfinished">Required information is empty!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="84"/>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.cpp" line="101"/>
        <source>内容为空!</source>
        <translation type="unfinished">The content is empty!</translation>
    </message>
</context>
<context>
    <name>dlg_generate_license</name>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="43"/>
        <source>信息配置区</source>
        <translation type="unfinished">Information configuration area</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="81"/>
        <source>有效期(天)：</source>
        <translation type="unfinished">Validity period (days):</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="67"/>
        <source>产品名称：</source>
        <translation type="unfinished">Product name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="51"/>
        <source>版本号：</source>
        <translation type="unfinished">Version No.:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="74"/>
        <source>客户名称：</source>
        <translation type="unfinished">Customer name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="114"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="127"/>
        <source>生成</source>
        <translation type="unfinished">Generate</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="139"/>
        <source>生成结果</source>
        <translation type="unfinished">Generate results</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="169"/>
        <source>复制注册码</source>
        <translation type="unfinished">Copy the registration code</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/license/tool/gui_generate_license/src/dlg_generate_license.ui" line="182"/>
        <source>导出注册码</source>
        <translation type="unfinished">Export registration code</translation>
    </message>
</context>
</TS>
