<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CSecCipherWidget</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="49"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="118"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="502"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="606"/>
        <source>算法名：</source>
        <translation type="unfinished">Algorithm name:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="156"/>
        <source>密钥参数：    </source>
        <translation type="unfinished">Key params:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="219"/>
        <source>私钥文件：</source>
        <translation type="unfinished">Private key file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="33"/>
        <source>摘要算法</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Summary algorithm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="102"/>
        <source>对称加密</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Symmetric encryption</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="203"/>
        <source>非对称算法</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Asymmetric algorithm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="273"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="343"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="413"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="483"/>
        <source>选择</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="289"/>
        <source>证书文件：</source>
        <translation type="unfinished">Certificate file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="359"/>
        <source>CA文件：  </source>
        <translation type="unfinished">CA file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="429"/>
        <source>CRL文件： </source>
        <translation type="unfinished">CRL file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="537"/>
        <source>配套摘要算法：</source>
        <translation type="unfinished">Companion hashing algorithm:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="590"/>
        <source>CRC算法</source>
        <comment>subTitle</comment>
        <translation type="unfinished">CRC algorithm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="681"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.ui" line="706"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Refresh</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.cpp" line="313"/>
        <source>打开</source>
        <translation type="unfinished">Open</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.cpp" line="341"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.cpp" line="357"/>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.cpp" line="424"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.cpp" line="341"/>
        <source>刷新成功</source>
        <translation type="unfinished">Refresh successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.cpp" line="357"/>
        <source>密钥不能为空，请重新填写</source>
        <translation type="unfinished">The key cannot be empty, please fill in again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.cpp" line="424"/>
        <source>修改成功</source>
        <translation type="unfinished">Modified successfully</translation>
    </message>
</context>
<context>
    <name>CSecFileView</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.cpp" line="33"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.cpp" line="34"/>
        <source>大小</source>
        <translation type="unfinished">Size</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.cpp" line="35"/>
        <source>修改时间</source>
        <translation type="unfinished">Modification time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.cpp" line="65"/>
        <source>确定</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.cpp" line="66"/>
        <source>取消</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/seccipherwidget.cpp" line="74"/>
        <source>打开</source>
        <translation type="unfinished">Open</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_seccipher/pluginseccipher.cpp" line="42"/>
        <source>加密算法配置</source>
        <translation type="unfinished">Encryption Algorithm Config</translation>
    </message>
</context>
</TS>
