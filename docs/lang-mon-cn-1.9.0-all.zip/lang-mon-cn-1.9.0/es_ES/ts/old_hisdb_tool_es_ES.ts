<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/include/copy_sql_dlg.h" line="18"/>
        <source>sql语句</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/include/copy_sql_dlg.h" line="25"/>
        <source>确认</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/include/copy_sql_dlg.h" line="29"/>
        <source>复制</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/main.cpp" line="339"/>
        <source>登录时限：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/query_result_model.cpp" line="149"/>
        <source>序号</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/query_result_model.cpp" line="518"/>
        <source>不支持的数据类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="83"/>
        <source>结构查询</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="84"/>
        <source>数据查询</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="85"/>
        <source>数据同步</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="86"/>
        <source>导入/导出</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="131"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="138"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="143"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="148"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="162"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="438"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="456"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="471"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="864"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1639"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1646"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1826"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1831"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2031"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2035"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2360"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2366"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2506"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2512"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2574"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2580"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2676"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2701"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2713"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="131"/>
        <source>访问sysmdl失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="138"/>
        <source>获取历史库应用失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="143"/>
        <source>历史库应用不唯一</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="148"/>
        <source>历史库应用为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="162"/>
        <source>查找部署指定服务进程的节点名失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="390"/>
        <source>IP: %1, 端口: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="397"/>
        <source>连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="438"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="865"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2713"/>
        <source>获取%1节点表信息失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="445"/>
        <source>已连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="457"/>
        <source>获取%1节点库类型失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="471"/>
        <source>连接%1节点库成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="645"/>
        <source>字段名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="645"/>
        <source>字段类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="646"/>
        <source>字段大小</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="646"/>
        <source>数据偏移</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="647"/>
        <source>数据来源</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="647"/>
        <source>属性ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="825"/>
        <source>%1 表 %2 无法同步 , 获取标签和主键失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="848"/>
        <source>%1 表 %2 无法同步 , 目标库不存在该表且无法建表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="929"/>
        <source>%1 开始同步表: %2 (%3/%4)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="943"/>
        <source>%1 表 %2 无法同步 , 标签和主键不一致</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="978"/>
        <source>%1 表 %2 无法同步</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1000"/>
        <source>%1 表 %2 同步成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1013"/>
        <source>%1 表 %2 同步失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1147"/>
        <source>%1 %2表获取标签和主键失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1155"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1277"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1356"/>
        <source>%1 %2表信息不一致</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1164"/>
        <source>%1获取表信息失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1175"/>
        <source>%1没有%2表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1187"/>
        <source>%1 %2表查询数据总数</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1194"/>
        <source>%1 %2表查询数据总数失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1200"/>
        <source>%1 %2表查询到%3条数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1233"/>
        <source>%1 开始查询源节点%2表 %3 ~ %4 / %5 数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1251"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1330"/>
        <source>%1 查询源节点%2表 %3 ~ %4 / %5 数据失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1260"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1340"/>
        <source>%1 查询源节点%2表 %3 ~ %4 / %5 数据成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1285"/>
        <source>%1 源节点%2表 %3 ~ %4 / %5 数据开始插入目标节点</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1294"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1367"/>
        <source>%1 源节点%2表 %3 ~ %4 / %5 数据插入目标节点失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1305"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1376"/>
        <source>%1 源节点%2表 %3 ~ %4 / %5 数据插入目标节点成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1502"/>
        <source>首页</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1503"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2315"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2452"/>
        <source>上一页</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1504"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2316"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2453"/>
        <source>下一页</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1505"/>
        <source>尾页</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1639"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2360"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2506"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2574"/>
        <source>表信息不一致</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1646"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2366"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2512"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2580"/>
        <source>获取表信息失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1805"/>
        <source>删除表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1816"/>
        <source>是否删除表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1817"/>
        <source>是否删除%1表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1826"/>
        <source>删除%1表失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1832"/>
        <source>删除%1表成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2020"/>
        <source>是否清除</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2021"/>
        <source>是否清除待同步信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2031"/>
        <source>清除失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2035"/>
        <source>清除成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2267"/>
        <source>待同步信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2278"/>
        <source>待同步数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2279"/>
        <source>待同步表结构</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2306"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2443"/>
        <source>总共0条数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2676"/>
        <source>请先连接一个库节点</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2701"/>
        <source>打开%1节点失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/titlel_mainwindow.cpp" line="37"/>
        <source>历史库管理工具</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::sdb_mgr_main</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="241"/>
        <source>获取数据类型枚举失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="763"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="988"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1572"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1601"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1611"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1618"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1628"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1700"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1705"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1839"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1916"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1922"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1942"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1948"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1968"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1974"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1994"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2000"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2014"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2087"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2224"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2232"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2237"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2255"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2260"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2350"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2412"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2493"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2561"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2627"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="763"/>
        <source>请选择要同步的表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="988"/>
        <source>同步完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1073"/>
        <source>列名: %1 的数据类型不匹配!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1074"/>
        <source>源数据类型: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1075"/>
        <source>目标数据类型: %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1083"/>
        <source>列名: %1 的数据长度不匹配!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1084"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1449"/>
        <source>源数据长度: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1085"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1450"/>
        <source>目标数据长度: %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1447"/>
        <source>字符串: %1 的源数据长度小于目的数据长度!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1558"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1587"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1670"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2162"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2185"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2210"/>
        <source>/ %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1562"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1591"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1674"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2166"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2189"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2214"/>
        <source>/ 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1572"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1922"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1974"/>
        <source>已经是第一页</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1601"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1948"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2000"/>
        <source>已经是最后一页</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1611"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2232"/>
        <source>请选择要查询的表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1618"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2237"/>
        <source>开始时间不能大于结束时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1628"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2350"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2493"/>
        <source>获取标签和主键失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1655"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2062"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2374"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2520"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2588"/>
        <source>总共%1条数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1659"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1700"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1916"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1942"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1968"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1994"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2058"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2087"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2378"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2412"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2524"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2561"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2592"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2627"/>
        <source>查询失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1705"/>
        <source>查询成功,共%1条数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1839"/>
        <source>获取表信息失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1905"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1931"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1957"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="1983"/>
        <source>Page %1 of %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2014"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2255"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2260"/>
        <source>没有%1表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2224"/>
        <source>页数不合法</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2293"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2430"/>
        <source>Context Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2385"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2531"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2599"/>
        <source>Page 1 of %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2389"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2535"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.cpp" line="2603"/>
        <source>Page 1 of 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sdb_mgr_main</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="51"/>
        <source>库节点</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="113"/>
        <source>连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="130"/>
        <source>表名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="146"/>
        <source>Tab 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="177"/>
        <source>Tab 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="216"/>
        <source>sdbkey开始时间：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="223"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="237"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="437"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="451"/>
        <source>yyyy/M/d HH:mm:ss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="230"/>
        <source>sdbkey结束时间：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="255"/>
        <source>总共0条数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="292"/>
        <source>条件字符串：    </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="328"/>
        <source>查询</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="361"/>
        <source>sql</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="381"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="617"/>
        <source>页</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="389"/>
        <source>节点：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="396"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="410"/>
        <source>未连接库</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="403"/>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="444"/>
        <source>-&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="430"/>
        <source>时段：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="488"/>
        <source>待同步信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="528"/>
        <source>开始同步</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="561"/>
        <source>详情</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="572"/>
        <source>源表名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="582"/>
        <source>目的表名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="592"/>
        <source>全选</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/sdb_mgr/src/sdb_mgr_main.ui" line="632"/>
        <source>库名称</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
