<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CurveMainWidget</name>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_curveeditor/curve_mainwidget.cpp" line="83"/>
        <source>日期设置</source>
        <translation type="unfinished">Configuración de fecha</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_curveeditor/curve_mainwidget.cpp" line="342"/>
        <source>错误</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_curveeditor/curve_mainwidget.cpp" line="342"/>
        <source>曲线组名称不可为空</source>
        <translation type="unfinished">Nombre de grupo de curva no vacío</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_curveeditor/curve_mainwidget.cpp" line="358"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_curveeditor/curve_mainwidget.cpp" line="358"/>
        <source>暂未实现，敬请期待</source>
        <translation type="unfinished">No implementado, espere</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/gui/tool/gui_curveeditor/curve_mainwidget.cpp" line="416"/>
        <source>开启实时刷新</source>
        <translation type="unfinished">Habilitar actualización en tiempo real</translation>
    </message>
</context>
</TS>
