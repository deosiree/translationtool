<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="238"/>
        <source>历史数据统计</source>
        <translation type="unfinished">Historical data statistics</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="1147"/>
        <source>打开 %1 库失败</source>
        <translation type="unfinished">Failed to open DB %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="1148"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
</context>
<context>
    <name>ReStaTaskEditor</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="59"/>
        <source>任务名: %1</source>
        <translation type="unfinished">Task name: %1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="82"/>
        <source>任务状态:</source>
        <translation type="unfinished">Task status:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="83"/>
        <source>待执行</source>
        <translation type="unfinished">Pending execution</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="88"/>
        <source>重统计开始时间:</source>
        <translation type="unfinished">Re-statistics start time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="101"/>
        <source>重统计结束时间:</source>
        <translation type="unfinished">Re-statistics end time:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="131"/>
        <source>确认取消</source>
        <translation type="unfinished">Confirm cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="131"/>
        <source>是否确认取消？</source>
        <translation type="unfinished">Whether to cancel?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="139"/>
        <source>确认执行</source>
        <translation type="unfinished">Confirm execution</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="139"/>
        <source>是否确认执行？</source>
        <translation type="unfinished">Whether to execute?</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="156"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="162"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="209"/>
        <source>保存失败</source>
        <translation type="unfinished">Save failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="156"/>
        <source>重统计开始时间不能晚于结束时间，请重新设置！</source>
        <translation type="unfinished">Re-statistics start time cannot be later than the end time. Please reset it!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="162"/>
        <source>保存失败：数据库连接失败，请稍后重试！</source>
        <translation type="unfinished">Save failed: DB connection failed. Please try again later!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="197"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="260"/>
        <source>操作成功</source>
        <translation type="unfinished">Operation successful</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="197"/>
        <source>重统计任务启动成功！</source>
        <translation type="unfinished">Re-statistics task started successfully!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="209"/>
        <source>保存失败，请稍后重试！</source>
        <translation type="unfinished">Save failed. Please try again later!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="260"/>
        <source>已成功取消重统计任务</source>
        <translation type="unfinished">The re-statistics task has been successfully canceled</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="292"/>
        <source>未选择统计任务</source>
        <translation type="unfinished">No statistics task selected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="294"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="306"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="321"/>
        <source>未知</source>
        <translation type="unfinished">Unknown</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="304"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="319"/>
        <source>暂不可访问</source>
        <translation type="unfinished">Cannot be accessed temporarily</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="341"/>
        <source>重统计运行中</source>
        <translation type="unfinished">Re-statistics in progress...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="342"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="348"/>
        <source>未执行重统计</source>
        <translation type="unfinished">Re-statistics not executed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="67"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/re_stat_task_editor.cpp" line="349"/>
        <source>执行</source>
        <translation type="unfinished">Execute</translation>
    </message>
</context>
<context>
    <name>StaMdlEditor</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/sta_mdl_editor.ui" line="33"/>
        <source>数据类型</source>
        <translation type="unfinished">Data type</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/sta_mdl_editor.ui" line="45"/>
        <source>清空</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/sta_mdl_editor.ui" line="52"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/sta_mdl_editor.ui" line="78"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/sta_mdl_editor.ui" line="92"/>
        <source>别名</source>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/sta_mdl_editor.ui" line="106"/>
        <source>源表名称</source>
        <translation type="unfinished">Source table name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/sta_mdl_editor.ui" line="124"/>
        <source>统计公式</source>
        <translation type="unfinished">Statistical formula</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/sta_mdl_editor.ui" line="138"/>
        <source>源数据列名1</source>
        <translation type="unfinished">Source column name 1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/sta_mdl_editor.ui" line="152"/>
        <source>源数据列名2</source>
        <translation type="unfinished">Source column name 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/sta_mdl_editor.ui" line="170"/>
        <source>统计时段</source>
        <translation type="unfinished">Statistical period</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/sta_mdl_editor.ui" line="184"/>
        <source>起始动作名</source>
        <translation type="unfinished">Start name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/sta_mdl_editor.ui" line="198"/>
        <source>结束动作名</source>
        <translation type="unfinished">End action name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/sta_mdl_editor.ui" line="214"/>
        <source>统计约束条件</source>
        <translation type="unfinished">Statistical constraints</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="51"/>
        <source>获取数据类型枚举失败</source>
        <translation type="unfinished">Failed to retrieve data type enumeration</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="67"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="92"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="221"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="363"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="728"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="67"/>
        <source>名称和别名不能为空！</source>
        <translation type="unfinished">Names and aliases cannot be null!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="77"/>
        <source>未选择统计公式</source>
        <translation type="unfinished">No statistical formula selected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="77"/>
        <source>请选择一个统计公式</source>
        <translation type="unfinished">Please select a statistical formula</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="92"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="221"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="363"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="728"/>
        <source>数据类型枚举获取失败</source>
        <translation type="unfinished">Failed to retrieve data type enumeration</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="110"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="123"/>
        <source>未选择源数据列</source>
        <translation type="unfinished">No source data column selected</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="110"/>
        <source>请选择一个源数据列1</source>
        <translation type="unfinished">Please select a source data column 1</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="123"/>
        <source>请选择一个源数据列2</source>
        <translation type="unfinished">Please select a source data column 2</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="252"/>
        <source>未配置数据源表</source>
        <translation type="unfinished">Unconfigured Data Source Table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="254"/>
        <source>统计任务</source>
        <translation type="unfinished">Statistical missions</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="255"/>
        <source>数据源表：</source>
        <translation type="unfinished">Data source table:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_editor.cpp" line="304"/>
        <source>新增统计模型</source>
        <translation type="unfinished">Add statistics model</translation>
    </message>
</context>
<context>
    <name>StatMdlMain</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_mdl_main.ui" line="14"/>
        <source>StatMdlMain</source>
        <translation type="unfinished">StatMdlMain</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_mdl_main.ui" line="35"/>
        <source>当前应用</source>
        <translation type="unfinished">Current app</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_mdl_main.ui" line="48"/>
        <source>统计任务表</source>
        <translation type="unfinished">Statistical Task Table</translation>
    </message>
</context>
<context>
    <name>StatTaskEditor</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="31"/>
        <source>清空</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="38"/>
        <source>保存</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="51"/>
        <source>名称</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="65"/>
        <source>别名</source>
        <translation type="unfinished">Alias</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="79"/>
        <source>统计数据周期</source>
        <translation type="unfinished">Statistical data cycle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="93"/>
        <source>统计执行周期</source>
        <translation type="unfinished">Statistics execution cycle</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="107"/>
        <source>最大存储时间</source>
        <translation type="unfinished">Maximum storage time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="128"/>
        <source>数据源表</source>
        <translation type="unfinished">Data source table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="146"/>
        <source>是否启用起效时间</source>
        <translation type="unfinished">Enabled the effective time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="153"/>
        <source>启用</source>
        <translation type="unfinished">Enable</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="169"/>
        <source>起效时间</source>
        <translation type="unfinished">Effective time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="183"/>
        <source>失效时间</source>
        <translation type="unfinished">Expiration time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="199"/>
        <source>工作时间</source>
        <translation type="unfinished">Working hours</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="213"/>
        <source>数据时段</source>
        <translation type="unfinished">Data period</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="231"/>
        <source>时间单位</source>
        <translation type="unfinished">Time unit</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="245"/>
        <source>是否起效</source>
        <translation type="unfinished">Effective</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="253"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="278"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="303"/>
        <source>否</source>
        <comment>UI</comment>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="258"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="283"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="308"/>
        <source>是</source>
        <comment>UI</comment>
        <translation type="unfinished">Yes</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="270"/>
        <source>启动重新统计</source>
        <translation type="unfinished">Start Re-statistics</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/stat_task_editor.ui" line="295"/>
        <source>停止统计</source>
        <translation type="unfinished">Stop counting</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="339"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="344"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="349"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="355"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="489"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="339"/>
        <source>名称和别名不能为空！</source>
        <translation type="unfinished">Names and aliases cannot be null!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="33"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="44"/>
        <source>通知</source>
        <translation type="unfinished">Notification</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="33"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="44"/>
        <source>历史参数获取失败</source>
        <translation type="unfinished">Failed to retrieve historical parameters</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="344"/>
        <source>统计数据周期不能为空</source>
        <translation type="unfinished">The statistical data cycle cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="349"/>
        <source>统计执行周期不能为空</source>
        <translation type="unfinished">The statistical execution cycle cannot be empty</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="355"/>
        <source>请选择数据源表</source>
        <translation type="unfinished">Please select the data source table</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="489"/>
        <source>选择的起始日期大于结束日期,请重新选择！</source>
        <translation type="unfinished">The selected start date is greater than the end date, please select again!</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="675"/>
        <source>数据字典</source>
        <translation type="unfinished">Data dictionary</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="689"/>
        <source>新增统计任务</source>
        <translation type="unfinished">Add statistics task</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="715"/>
        <source>年</source>
        <translation type="unfinished">year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="715"/>
        <source>月</source>
        <translation type="unfinished">month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="715"/>
        <source>日</source>
        <translation type="unfinished">th</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="715"/>
        <source>时</source>
        <translation type="unfinished">h</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="825"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_editor.cpp" line="839"/>
        <source>不设置</source>
        <translation type="unfinished">Unset</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::AddObjectDialog</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="51"/>
        <source>获取数据</source>
        <translation type="unfinished">Query data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="52"/>
        <source>正在获取数据，请稍后...</source>
        <translation type="unfinished">Getting data now, please wait...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="133"/>
        <source>保存数据</source>
        <translation type="unfinished">Save data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="134"/>
        <source>正在保存数据，请稍后...</source>
        <translation type="unfinished">Saving data, please wait...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="163"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="168"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="210"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="279"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="163"/>
        <source>请勾选至少一个存储对象</source>
        <translation type="unfinished">Please check at least one storage object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="168"/>
        <source>统计对象保存失败</source>
        <translation type="unfinished">Failed to save the statistics object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="173"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="173"/>
        <source>统计对象保存成功</source>
        <translation type="unfinished">Statistics object saved successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="210"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="279"/>
        <source>正在获取数据，请稍后再尝试关闭窗口。</source>
        <translation type="unfinished">Data is being retrieved, please try closing the window again later.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="221"/>
        <source>选择统计对象</source>
        <translation type="unfinished">Selection of statistical objects</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="231"/>
        <source>帮助</source>
        <translation type="unfinished">Help</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="237"/>
        <source>保存</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="243"/>
        <source>退出</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="251"/>
        <source>正在保存，请稍后...</source>
        <translation type="unfinished">Saving, please wait...</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/add_object_dialog.cpp" line="254"/>
        <source>保存进度</source>
        <translation type="unfinished">Save progress</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::HisDictionaryModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/his_dictionary_model.cpp" line="156"/>
        <source>不存历史</source>
        <translation type="unfinished">No history</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/his_dictionary_model.cpp" line="158"/>
        <source>采样存储</source>
        <translation type="unfinished">Sample storage</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/his_dictionary_model.cpp" line="160"/>
        <source>事件存储</source>
        <translation type="unfinished">Event storage</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/his_dictionary_model.cpp" line="162"/>
        <source>统计存储</source>
        <translation type="unfinished">Statistical storage</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/his_dictionary_model.cpp" line="164"/>
        <source>采样+事件存储</source>
        <translation type="unfinished">Sampling+Event storage</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/his_dictionary_model.cpp" line="166"/>
        <source>未配置</source>
        <translation type="unfinished">No Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/his_dictionary_model.cpp" line="325"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/his_dictionary_model.cpp" line="359"/>
        <source>唯一标识</source>
        <translation type="unfinished">OnlyNo</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::HisSampleObjectModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/his_sample_object_model.cpp" line="370"/>
        <source>checkbox</source>
        <translation type="unfinished">checkbox</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/his_sample_object_model.cpp" line="371"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/his_sample_object_model.cpp" line="402"/>
        <source>唯一标识</source>
        <translation type="unfinished">OnlyNo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/his_sample_object_model.cpp" line="413"/>
        <source>路径</source>
        <translation type="unfinished">Path</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::StaMdlModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_model.cpp" line="224"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_model.cpp" line="241"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_model.cpp" line="256"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_model.cpp" line="454"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_model.cpp" line="224"/>
        <source>名称重复</source>
        <translation type="unfinished">Duplicate name</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_model.cpp" line="241"/>
        <source>更新失败</source>
        <translation type="unfinished">Update failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_model.cpp" line="256"/>
        <source>新增失败</source>
        <translation type="unfinished">Failed to add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_model.cpp" line="349"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_model.cpp" line="373"/>
        <source>获取枚举失败</source>
        <translation type="unfinished">Failed to retrieve enumeration</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_model.cpp" line="363"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_model.cpp" line="387"/>
        <source>未配置</source>
        <translation type="unfinished">No Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_model.cpp" line="454"/>
        <source>请先保存当前新增记录</source>
        <translation type="unfinished">Please save the currently added record first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_model.cpp" line="612"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_mdl_model.cpp" line="644"/>
        <source>唯一标识</source>
        <translation type="unfinished">OnlyNo</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::StaObjectModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_object_model.cpp" line="365"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_object_model.cpp" line="397"/>
        <source>唯一标识</source>
        <translation type="unfinished">OnlyNo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/sta_object_model.cpp" line="408"/>
        <source>路径</source>
        <translation type="unfinished">Path</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::StatMdlMain</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="159"/>
        <source>统计对象</source>
        <translation type="unfinished">Statistical objects</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="179"/>
        <source>统计模型</source>
        <translation type="unfinished">Statistical models</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="552"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="562"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="596"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="602"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="609"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="621"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="633"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="647"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="666"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="673"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="790"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="824"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="937"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="998"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="1067"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="666"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="790"/>
        <source>请选择一个树节点</source>
        <translation type="unfinished">Please select a tree node</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="562"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="673"/>
        <source>保存成功</source>
        <translation type="unfinished">Save successfully</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="552"/>
        <source>请选择一个数据字典</source>
        <translation type="unfinished">Please select a data dictionary</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="596"/>
        <source>条件字符串中不能包含;</source>
        <translation type="unfinished">The condition string cannot contain ;</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="602"/>
        <source>条件字符串中不能包含--</source>
        <translation type="unfinished">The condition string cannot contain --</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="609"/>
        <source>条件字符串中不能包含/*或*/</source>
        <translation type="unfinished">The condition string cannot contain /* or */</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="621"/>
        <source>条件字符串中单引号数量必须为偶数</source>
        <translation type="unfinished">The number of single quotation marks in the condition string must be even</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="633"/>
        <source>条件字符串中双引号数量必须为偶数</source>
        <translation type="unfinished">The number of double quotation marks in the condition string must be even</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="648"/>
        <source>条件字符串中不能包含SQL关键字: </source>
        <translation type="unfinished">The condition string cannot contain SQL keywords:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="778"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="899"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="983"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="1038"/>
        <source>新增</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="814"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="927"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="994"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="1062"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="824"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="937"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="998"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="1067"/>
        <source>请至少选择一条记录删除</source>
        <translation type="unfinished">Please select at least one record</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="1133"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="1167"/>
        <source>警告</source>
        <translation type="unfinished">Warning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="1133"/>
        <source>建立模型出错</source>
        <translation type="unfinished">Error in building model</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_mdl_main.cpp" line="1167"/>
        <source>获取模型源表失败</source>
        <translation type="unfinished">Failed to retrieve the model source table</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::StatPreModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_pre_model.cpp" line="164"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_pre_model.cpp" line="166"/>
        <source>唯一标识</source>
        <translation type="unfinished">OnlyNo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_pre_model.cpp" line="168"/>
        <source>前置统计模型</source>
        <translation type="unfinished">FEP statistical model</translation>
    </message>
</context>
<context>
    <name>iasp::hisdata::StatTaskModel</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="157"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="170"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="183"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="196"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="209"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="249"/>
        <source>未配置</source>
        <translation type="unfinished">No Config</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="239"/>
        <source>获取枚举失败</source>
        <translation type="unfinished">Failed to retrieve enumeration</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="305"/>
        <source>不清理</source>
        <translation type="unfinished">Not cleaning</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="309"/>
        <source>历史库磁盘清理</source>
        <translation type="unfinished">HDB disk cleanup</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="325"/>
        <source>年</source>
        <translation type="unfinished">year</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="331"/>
        <source>月</source>
        <translation type="unfinished">month</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="337"/>
        <source>天</source>
        <translation type="unfinished">Day</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="343"/>
        <source>小时</source>
        <translation type="unfinished">Hour</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="348"/>
        <source>秒</source>
        <translation type="unfinished">sec</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="456"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="478"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="493"/>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="568"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="456"/>
        <source>与数据字典%1下统计任务名称重复</source>
        <translation type="unfinished">The name of the statistical task is the same as that in the data dictionary %1.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="478"/>
        <source>更新失败</source>
        <translation type="unfinished">Update failed</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="493"/>
        <source>新增失败</source>
        <translation type="unfinished">Failed to add</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="568"/>
        <source>请先保存当前新增记录</source>
        <translation type="unfinished">Please save the currently added record first</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="921"/>
        <source>序号</source>
        <translation type="unfinished">No.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/src/stat_task_model.cpp" line="954"/>
        <source>唯一标识</source>
        <translation type="unfinished">OnlyNo</translation>
    </message>
</context>
<context>
    <name>re_stat_task_editor</name>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/re_stat_task_editor.ui" line="14"/>
        <source>重统计编辑</source>
        <translation type="unfinished">Re-statistics editing</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/re_stat_task_editor.ui" line="26"/>
        <source>确认</source>
        <translation type="unfinished">Confirm</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/re_stat_task_editor.ui" line="39"/>
        <source>取消</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/re_stat_task_editor.ui" line="58"/>
        <source>是否执行重统计</source>
        <translation type="unfinished">Whether to execute re-statistics</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/re_stat_task_editor.ui" line="65"/>
        <source>重统计开始时间</source>
        <translation type="unfinished">Re-statistics start time</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/hisdata/tool/hisdata_statmdlcfg/ui/re_stat_task_editor.ui" line="78"/>
        <source>重统计结束时间</source>
        <translation type="unfinished">Re-statistics end time</translation>
    </message>
</context>
</TS>
