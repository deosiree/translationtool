<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="82"/>
        <source>源文件：</source>
        <translation type="unfinished">Original File:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="84"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="92"/>
        <source>请选择比对对象</source>
        <translation type="unfinished">Please select the comparison object</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="89"/>
        <source>目标文件：</source>
        <translation type="unfinished">Dest file:</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="97"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="102"/>
        <source>选择文件</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Select file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="193"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="475"/>
        <source>选择文件</source>
        <translation type="unfinished">Select File</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="144"/>
        <source>比对</source>
        <translation type="unfinished">Compare</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="159"/>
        <source>重新加载</source>
        <translation type="unfinished">Reload</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="234"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="249"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="514"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="521"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1244"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1248"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1653"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1657"/>
        <source>提示</source>
        <translation type="unfinished">Tips</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="249"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="521"/>
        <source>相同文件，请重新选择</source>
        <translation type="unfinished">Same file, please select again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="514"/>
        <source>不是同配置名，请重新选择</source>
        <translation type="unfinished">Not the same config name, please select again</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="295"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="545"/>
        <source>模型</source>
        <translation type="unfinished">Model</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="149"/>
        <source>展示全部</source>
        <translation type="unfinished">Show all</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="154"/>
        <source>仅看差异项</source>
        <translation type="unfinished">Differences only</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="234"/>
        <source>需清空目标配置，是否继续</source>
        <translation type="unfinished">Need to clear destination config, whether to continue</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="306"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="557"/>
        <source>自定义类型</source>
        <translation type="unfinished">Custom types</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="348"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="597"/>
        <source>配置项</source>
        <translation type="unfinished">Config items</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="374"/>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="623"/>
        <source>数据</source>
        <translation type="unfinished">Data</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1244"/>
        <source>有差异</source>
        <translation type="unfinished">Diffs exist.</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1248"/>
        <source>无差异</source>
        <translation type="unfinished">No difference</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1657"/>
        <source>配置文件加载失败</source>
        <translation type="unfinished">Failed to load config file</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1653"/>
        <source>加载完成</source>
        <translation type="unfinished">Loading completed</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/tool/dbms/gui_cfgcompare_tools/cfgcompare_base/mainwindow.cpp" line="1677"/>
        <source>配置文件比对工具</source>
        <comment>toolName</comment>
        <translation type="unfinished">Config Comparison</translation>
    </message>
</context>
</TS>
