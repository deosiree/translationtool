<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>PortInfo</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.ui" line="14"/>
        <source>PortInfo</source>
        <translation type="unfinished">PortInfo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.ui" line="32"/>
        <source>开放端口</source>
        <translation type="unfinished">Abrir Puerto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.ui" line="72"/>
        <source>刷新</source>
        <comment>buttonName</comment>
        <translation type="unfinished">Actualizar</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.cpp" line="71"/>
        <source>WINDOWS节点不支持加固，无法获取端口信息</source>
        <translation type="unfinished">Los nodos WINDOWS no soportan refuerzo y no pueden obtener información de puertos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.cpp" line="74"/>
        <source>端口信息</source>
        <translation type="unfinished">Información del puerto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.cpp" line="76"/>
        <source>当前节点未进行加固, 无法获取端口信息</source>
        <translation type="unfinished">El nodo actual no ha sido reforzado y no puede obtener información de puertos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.cpp" line="129"/>
        <source>协议</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Protocolo</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.cpp" line="129"/>
        <source>端口</source>
        <comment>subTitle</comment>
        <translation type="unfinished">Puerto</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.cpp" line="149"/>
        <source>提示</source>
        <translation type="unfinished">Consejos</translation>
    </message>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/port_info.cpp" line="149"/>
        <source>刷新成功</source>
        <translation type="unfinished">Actualización exitosa</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../../src/plat/security/tool/sec_config_plugin/plugin_secport/plugin_sec_port.cpp" line="42"/>
        <source>开放端口</source>
        <translation type="unfinished">Abrir Puerto</translation>
    </message>
</context>
</TS>
