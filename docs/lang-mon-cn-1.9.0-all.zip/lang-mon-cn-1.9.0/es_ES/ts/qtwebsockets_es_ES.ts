<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>QQmlWebSocket</name>
    <message>
        <source>Messages can only be sent when the socket is open.</source>
        <translation>Los mensajes solo se pueden enviar cuando el socket está abierto.</translation>
    </message>
    <message>
        <source>QQmlWebSocket is not ready.</source>
        <translation>QQmlWebSocket no está listo.</translation>
    </message>
</context>
<context>
    <name>QQmlWebSocketServer</name>
    <message>
        <source>QQmlWebSocketServer is not ready.</source>
        <translation>QQmlWebSocketServer no está listo.</translation>
    </message>
</context>
<context>
    <name>QWebSocket</name>
    <message>
        <source>Connection closed</source>
        <translation>Conexión cerrada</translation>
    </message>
    <message>
        <source>Invalid URL.</source>
        <translation>URL inválida.</translation>
    </message>
    <message>
        <source>Invalid resource name.</source>
        <translation>Nombre de recurso inválido.</translation>
    </message>
    <message>
        <source>SSL Sockets are not supported on this platform.</source>
        <translation>Los sockets SSL no son soportados en esta plataforma.</translation>
    </message>
    <message>
        <source>Out of memory.</source>
        <translation>Memoria insuficiente.</translation>
    </message>
    <message>
        <source>Unsupported WebSocket scheme: %1</source>
        <translation>Esquema de WebSocket no soportado: %1</translation>
    </message>
    <message>
        <source>Error writing bytes to socket: %1.</source>
        <translation>Error al escribir bytes en el socket: %1.</translation>
    </message>
    <message>
        <source>Bytes written %1 != %2.</source>
        <translation>Bytes escritos %1 != %2.</translation>
    </message>
    <message>
        <source>QWebSocketPrivate::processHandshake: Unsupported WWW-Authenticate challenge encountered.</source>
        <extracomment>&apos;WWW-Authenticate&apos; is the HTTP header.</extracomment>
        <translation>QWebSocketPrivate::processHandshake: Se encontró un desafío WWW-Authenticate no soportado.</translation>
    </message>
    <message>
        <source>QWebSocketPrivate::processHandshake: Unsupported WWW-Authenticate challenges encountered.</source>
        <translation>QWebSocketPrivate::processHandshake: Se encontraron desafíos WWW-Authenticate no soportados.</translation>
    </message>
    <message>
        <source>Header is too large</source>
        <translation>El encabezado es demasiado grande</translation>
    </message>
    <message>
        <source>Read handshake request header failed</source>
        <translation>Error al leer el encabezado de solicitud de apretón de manos</translation>
    </message>
    <message>
        <source>Read handshake request status failed</source>
        <translation>Error al leer el estado de solicitud de apretón de manos</translation>
    </message>
    <message>
        <source>Parsing handshake request header failed</source>
        <translation>Error al analizar el encabezado de solicitud de apretón de manos</translation>
    </message>
    <message>
        <source>WebSocket server has chosen protocol %1 which has not been requested</source>
        <translation>El servidor WebSocket ha elegido el protocolo %1 que no ha sido solicitado</translation>
    </message>
    <message>
        <source>Invalid parameter encountered during protocol upgrade: %1</source>
        <translation>Parámetro inválido encontrado durante la actualización del protocolo: %1</translation>
    </message>
    <message>
        <source>Invalid parameter(s) presented during protocol upgrade: %1</source>
        <translation type="vanished">Parámetro(s) inválido(s) presentado(s) durante la actualización del protocolo: %1</translation>
    </message>
    <message>
        <source>Invalid statusline in response: %1.</source>
        <translation type="vanished">Línea de estado inválida en la respuesta: %1.</translation>
    </message>
    <message>
        <source>QWebSocketPrivate::processHandshake: Connection closed while reading header.</source>
        <translation type="vanished">QWebSocketPrivate::processHandshake: Conexión cerrada mientras se leía el encabezado.</translation>
    </message>
    <message>
        <source>Accept-Key received from server %1 does not match the client key %2.</source>
        <translation>La clave de aceptación recibida del servidor %1 no coincide con la clave del cliente %2.</translation>
    </message>
    <message>
        <source>QWebSocketPrivate::processHandshake: Invalid statusline in response: %1.</source>
        <translation type="vanished">QWebSocketPrivate::processHandshake: Línea de estado inválida en la respuesta: %1.</translation>
    </message>
    <message>
        <source>Handshake: Server requests a version that we don&apos;t support: %1.</source>
        <translation>Apretón de manos: El servidor solicita una versión que no soportamos: %1.</translation>
    </message>
    <message>
        <source>QWebSocketPrivate::processHandshake: Unknown error condition encountered. Aborting connection.</source>
        <translation>QWebSocketPrivate::processHandshake: Se encontró una condición de error desconocida. Abortando conexión.</translation>
    </message>
    <message>
        <source>QWebSocket::processHandshake: Host requires authentication</source>
        <translation>QWebSocket::processHandshake: El host requiere autenticación</translation>
    </message>
    <message>
        <source>QWebSocketPrivate::processHandshake: Unhandled http status code: %1 (%2).</source>
        <translation>QWebSocketPrivate::processHandshake: Código de estado HTTP no manejado: %1 (%2).</translation>
    </message>
    <message>
        <source>The resource name contains newlines. Possible attack detected.</source>
        <translation>El nombre del recurso contiene saltos de línea. Se detectó un posible ataque.</translation>
    </message>
    <message>
        <source>The hostname contains newlines. Possible attack detected.</source>
        <translation>El nombre de host contiene saltos de línea. Se detectó un posible ataque.</translation>
    </message>
    <message>
        <source>The origin contains newlines. Possible attack detected.</source>
        <translation>El origen contiene saltos de línea. Se detectó un posible ataque.</translation>
    </message>
    <message>
        <source>The extensions attribute contains newlines. Possible attack detected.</source>
        <translation>El atributo de extensiones contiene saltos de línea. Se detectó un posible ataque.</translation>
    </message>
    <message>
        <source>The protocols attribute contains newlines. Possible attack detected.</source>
        <translation type="vanished">El atributo de protocolos contiene saltos de línea. Se detectó un posible ataque.</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>Conexión rechazada</translation>
    </message>
</context>
<context>
    <name>QWebSocketDataProcessor</name>
    <message>
        <source>Received Continuation frame, while there is nothing to continue.</source>
        <translation>Se recibió un marco de continuación, mientras no hay nada que continuar.</translation>
    </message>
    <message>
        <source>All data frames after the initial data frame must have opcode 0 (continuation).</source>
        <translation>Todos los marcos de datos después del marco de datos inicial deben tener el código de operación 0 (continuación).</translation>
    </message>
    <message>
        <source>Received message is too big.</source>
        <translation>El mensaje recibido es demasiado grande.</translation>
    </message>
    <message>
        <source>Invalid UTF-8 code encountered.</source>
        <translation>Se encontró un código UTF-8 inválido.</translation>
    </message>
    <message>
        <source>Payload of close frame is too small.</source>
        <translation>La carga útil del marco de cierre es demasiado pequeña.</translation>
    </message>
    <message>
        <source>Invalid close code %1 detected.</source>
        <translation>Se detectó un código de cierre inválido %1.</translation>
    </message>
    <message>
        <source>Invalid opcode detected: %1</source>
        <translation>Se detectó un código de operación inválido: %1</translation>
    </message>
    <message>
        <source>Timeout when reading data from socket.</source>
        <translation>Tiempo de espera al leer datos del socket.</translation>
    </message>
</context>
<context>
    <name>QWebSocketFrame</name>
    <message>
        <source>Timeout when reading data from socket.</source>
        <translation type="vanished">Tiempo de espera al leer datos del socket.</translation>
    </message>
    <message>
        <source>Waiting for more data from socket.</source>
        <translation>Esperando más datos del socket.</translation>
    </message>
    <message>
        <source>Error occurred while reading header from the network: %1</source>
        <translation>Se produjo un error al leer el encabezado de la red: %1</translation>
    </message>
    <message>
        <source>Error occurred while reading from the network: %1</source>
        <translation>Se produjo un error al leer de la red: %1</translation>
    </message>
    <message>
        <source>Lengths smaller than 126 must be expressed as one byte.</source>
        <translation>Las longitudes menores de 126 deben expresarse como un byte.</translation>
    </message>
    <message>
        <source>Something went wrong during reading from the network.</source>
        <translation>Algo salió mal durante la lectura de la red.</translation>
    </message>
    <message>
        <source>Highest bit of payload length is not 0.</source>
        <translation>El bit más alto de la longitud de la carga útil no es 0.</translation>
    </message>
    <message>
        <source>Lengths smaller than 65536 (2^16) must be expressed as 2 bytes.</source>
        <translation>Las longitudes menores de 65536 (2^16) deben expresarse como 2 bytes.</translation>
    </message>
    <message>
        <source>Error while reading from the network: %1.</source>
        <translation>Error al leer desde la red: %1.</translation>
    </message>
    <message>
        <source>Maximum framesize exceeded.</source>
        <translation>Se excedió el tamaño máximo del marco.</translation>
    </message>
    <message>
        <source>Some serious error occurred while reading from the network.</source>
        <translation>Ocurrió un error grave al leer desde la red.</translation>
    </message>
    <message>
        <source>Rsv field is non-zero</source>
        <translation>El campo Rsv no es cero.</translation>
    </message>
    <message>
        <source>Used reserved opcode</source>
        <translation>Se usó un código de operación reservado</translation>
    </message>
    <message>
        <source>Control frame is larger than 125 bytes</source>
        <translation>El marco de control es mayor de 125 bytes.</translation>
    </message>
    <message>
        <source>Control frames cannot be fragmented</source>
        <translation>Los marcos de control no pueden fragmentarse.</translation>
    </message>
</context>
<context>
    <name>QWebSocketHandshakeResponse</name>
    <message>
        <source>Access forbidden.</source>
        <translation>Acceso prohibido.</translation>
    </message>
    <message>
        <source>Unsupported version requested.</source>
        <translation>Se solicitó una versión no compatible.</translation>
    </message>
    <message>
        <source>One of the headers contains a newline. Possible attack detected.</source>
        <translation>Uno de los encabezados contiene una nueva línea. Se detectó un posible ataque.</translation>
    </message>
    <message>
        <source>Bad handshake request received.</source>
        <translation>Se recibió una solicitud de saludo incorrecta.</translation>
    </message>
</context>
<context>
    <name>QWebSocketServer</name>
    <message>
        <source>Server closed.</source>
        <translation>Servidor cerrado.</translation>
    </message>
    <message>
        <source>Header is too large.</source>
        <translation>El encabezado es demasiado grande.</translation>
    </message>
    <message>
        <source>Too many pending connections.</source>
        <translation>Demasiadas conexiones pendientes.</translation>
    </message>
    <message>
        <source>Read handshake request header failed.</source>
        <translation>Fallo al leer el encabezado de la solicitud de saludo.</translation>
    </message>
    <message>
        <source>Upgrade to WebSocket failed.</source>
        <translation>La actualización a WebSocket falló.</translation>
    </message>
    <message>
        <source>Invalid response received.</source>
        <translation>Se recibió una respuesta no válida.</translation>
    </message>
</context>
</TS>
